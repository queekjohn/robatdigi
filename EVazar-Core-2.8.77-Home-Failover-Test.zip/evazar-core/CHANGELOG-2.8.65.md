# EVazar Core 2.8.65

- Extended `evazar_cdn_image_url()` with optional size variants for zero-host-storage image delivery.
- Added safe Digikala OSS resize URL generation for 120/160/360/800px image variants.
- Existing URLs remain unchanged when no size is requested.
- Synchronized the embedded Cloudflare Worker with Worker 1.9.9.
