# EVazar Core 2.8.62
- Product Index migration now recreates tables when missing even if the stored DB version is already current.
- Backfill cron is re-ensured on normal init so plugin updates do not depend on activation hooks.
