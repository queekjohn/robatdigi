# EVazar Core 2.8.76

- Added a database-level unique constraint for queue `dkp` values, with a safe one-time duplicate cleanup before the index is created.
- `/existing-dkps` now separates imported products, active queue items, completed queue records and failed/retryable items, while keeping the legacy `dkps` field for Harvester 1.6.0 compatibility.
- Failed queue records are automatically requeued when their DKP is harvested again; completed records are only reactivated when the corresponding product is not actually present in WordPress.
- Queue ingest now checks each batch in bulk and no longer relies on stale per-DKP queue caches.
- Concurrent queue-ingest requests cannot create duplicate queue rows once the unique index is active.
