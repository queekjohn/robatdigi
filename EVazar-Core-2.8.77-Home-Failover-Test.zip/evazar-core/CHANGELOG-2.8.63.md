# EVazar Core 2.8.63

- Persist Worker `availability_source` in `_evazar_availability_source`.
- Product Index DB bumped to 1.1.0 with an `availability_source` column.
- Product Index `stock_status` now derives from current price > 0, with `explicit_unavailable` as a hard override.
- Initial imports and live stock/price sync store the availability source for consistent filtering and sorting.
