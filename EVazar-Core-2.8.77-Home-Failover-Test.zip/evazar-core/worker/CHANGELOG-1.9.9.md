# EVazar Worker 1.9.9

- Added controlled retries for transient Digikala image-origin/network failures.
- Added status-aware cache TTLs so 5xx responses are not cached as image assets.
- Added CDN cache-control metadata with stale-if-error guidance.
- Added upstream cache diagnostics via `X-Evazar-CDN-Cache`.
- Kept the local Cache API as a fast per-edge L1 while retaining `fetch()` caching for the origin subrequest.
