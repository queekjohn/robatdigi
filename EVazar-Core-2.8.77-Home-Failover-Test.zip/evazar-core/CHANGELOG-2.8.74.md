# EVazar Core 2.8.74

- Live product inquiry now uses `fresh=1` on the public product-page AJAX request.
- Cloudflare Worker bumped to `1.11.2`; fresh product requests bypass the Worker Product Cache and use a new cache namespace.
- Added `X-Evazar-Fresh` and clearer cache diagnostics to product responses.
- Preserved the lightweight per-product Product Index synchronization from 2.8.73.
- No full Product Index rebuild and no extra Digikala request is performed for the index sync itself.
