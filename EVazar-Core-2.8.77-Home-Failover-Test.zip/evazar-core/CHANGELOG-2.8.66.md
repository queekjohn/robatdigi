# EVazar Core 2.8.66

- Preserves existing Digikala OSS `x-oss-process` transformations when generating CDN image URLs.
- Size variants are only added when the source URL has no existing image-processing directive.
- Restores the previous archive/product visual framing while keeping zero-host-storage CDN delivery.
- Keeps the embedded Cloudflare Worker at 1.9.9.
