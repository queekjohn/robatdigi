# EVazar Core 2.8.67

- Replaces fixed 24-hour Gemini quota cooldown with Google's documented daily RPD reset at 00:00 Pacific time.
- Treats `quota_exceeded`/daily-quota 429 separately from transient RPM/TPM 429 errors.
- Prevents queue claims in Gemini-only mode while all Gemini Workers are in quota cooldown.
- When a batch encounters a Gemini daily-quota stop, unprocessed claimed items are returned to `pending` without increasing retry count and deferred until the next quota reset.
- Cloudflare Worker code is unchanged.
