# EVazar Core 2.8.77

- Added browser-side image failover for the zero-host-storage image architecture.
- Normal path remains `img.evazar.ir` / Cloudflare Worker; the first failed Evazar CDN image automatically switches the page to `dkstatics-public.digikala.com`.
- Failover also rewrites `src`, `srcset` and common lazy-loading attributes so lazy-loaded and responsive images do not switch back to the failed CDN path.
- A short `sessionStorage` cooldown keeps subsequent pages on direct Digikala images after a detected CDN path failure, then automatically returns to the normal proxy path after 10 minutes.
- No Cloudflare Worker change is required for this client-side failover.
- Virtual EVazar thumbnails now pass through the Evazar CDN helper so they participate in the same failover architecture.
