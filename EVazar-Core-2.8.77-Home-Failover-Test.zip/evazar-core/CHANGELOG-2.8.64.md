# EVazar Core 2.8.64

- Added automatic queue retry with exponential backoff (up to 4 automatic retries; 5th failure remains failed).
- Added `next_attempt_at` to queue items so failed/stuck jobs do not retry immediately and create request bursts.
- Improved stale-claim recovery: stuck jobs are requeued safely and eventually marked failed instead of looping forever.
- Queue claims now respect `next_attempt_at`.
- Manual retry resets retry scheduling state.
- Added price/stock sync reliability metadata: `_evazar_price_sync_status`, `_evazar_price_sync_failed_at`, `_evazar_price_sync_error`, `_evazar_price_sync_last_success`.
- A failed live price inquiry no longer overwrites valid existing price/stock data.
- Preserved the existing Theme → Core → Worker contract; no Worker change required.
