# Evazar Core 2.8.73

- Live Inquiry now performs a lightweight per-product Product Index synchronization after a successful live check.
- Only price, old price, discount, stock status, availability source, and stock-check timestamp are updated in the existing index row.
- No Product Index rebuild and no additional Digikala/Worker request are performed for this synchronization.
- If the product is missing from the index, only that single product is fully indexed as a fallback.
- Preserves the existing 2.8.72 live-availability detection and bundled Worker changes.
