# EVazar Core 2.8.75

- Added a canonical Related Product Engine backed by the Product Index.
- Related ranking uses category, branch, brand and publication date without per-candidate postmeta queries.
- Out-of-stock filtering uses the Core Product Index `stock_status` value.
- Theme integration is ID-only: the Theme renders products while Core owns recommendation logic.
