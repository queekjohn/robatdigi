# EVazar Core 2.8.70

- Gemini model name is normalized before every Worker request.
- Fixed malformed model names such as `-3.5-flash-lite` and `3.5-flash-lite`.
- Updated Gemini settings to use currently supported model IDs, with `gemini-3.5-flash-lite` as the default.
- Removed shut-down Gemini 2.0/1.5 options from the settings UI.
- Cloudflare Worker updated to v1.10.0 with the same defensive model normalization.
- Gemini quota/cooldown and manual single-product bypass logic preserved.
