# EVazar Core 2.8.68

- Adds a post-reset Gemini quota Health Check.
- After a daily quota cooldown expires, only one real Gemini request is allowed to probe whether Google has actually released the quota.
- Concurrent queue runs are blocked from sending duplicate post-reset probe requests.
- If the probe still receives a daily-quota 429, the Gemini cooldown is restored instead of continuing requests.
- If the probe succeeds, the current reset cycle is marked healthy and the queue continues normally.
- If the probe fails for a temporary non-quota reason, the probe lock is released so a later queue run can retry without creating a false daily cooldown.
- Cloudflare Worker code is unchanged.
