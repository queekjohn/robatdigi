<?php

/**
 * Plugin Name: Evazar Core (ÙØ³ØªÙ Ø§Ø®ØªØµØ§ØµÛ Ø§ÛÙØ§Ø²Ø§Ø±)
 * Description: Ø³ÛØ³ØªÙ Ø¨ÙÙÛ ÙØ¯ÛØ±ÛØª Ú©Ø§ÙØ§ÙØ§Ø Ø¯ÛÙ¾âÙÛÙÚ©âÙØ§Û Ø§ÙÛÙÛÙ Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§ Ù ÛÚ©Ù¾Ø§Ø±ÚÙâØ³Ø§Ø²Û Ø¨Ø§ Ø³Ø¦Ù Ø¨Ø¯ÙÙ ÙÛØ§Ø² Ø¨Ù ÙÙÚ©Ø§ÙØ±Ø³.
 * Version: 2.8.77
 * Author: Moblak / Antigravity
 * Text Domain: evazar-core
 */

if (! defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// ==========================================
// 1. Ø«Ø¨Øª Ù¾Ø³ØªâØªØ§ÛÙ¾ Ø§Ø®ØªØµØ§ØµÛ Ú©Ø§ÙØ§ÙØ§ (Custom Post Type)
// ==========================================
require_once plugin_dir_path(__FILE__) . 'product-index.php';
require_once plugin_dir_path(__FILE__) . 'importer.php';
require_once plugin_dir_path(__FILE__) . 'queue-manager.php';

register_activation_hook(__FILE__, 'evazar_core_activate');
function evazar_core_activate()
{
    evazar_queue_create_table();
    evazar_queue_schedule_cron();
    evazar_stock_sync_schedule();
    evazar_product_index_ensure_tables();
    evazar_product_index_schedule_backfill();
    delete_option('evazar_cat_tree_repaired_v3');
    delete_option('evazar_core_sitemap_flushed_v4');
    flush_rewrite_rules(false);
}

register_deactivation_hook(__FILE__, 'evazar_core_deactivate');
function evazar_core_deactivate()
{
    evazar_queue_clear_cron();
    evazar_stock_sync_clear_schedule();
    evazar_product_index_clear_schedule();
}

add_action('init', 'evazar_register_product_cpt');
add_action('init', 'evazar_product_index_maybe_upgrade', 5);
function evazar_register_product_cpt()
{
    $labels = array(
        'name'                  => 'Ú©Ø§ÙØ§ÙØ§',
        'singular_name'         => 'Ú©Ø§ÙØ§',
        'menu_name'             => 'Ú©Ø§ÙØ§ÙØ§Û Ø§ÛÙØ§Ø²Ø§Ø±',
        'add_new'               => 'Ø§ÙØ²ÙØ¯Ù Ú©Ø§ÙØ§Û Ø¬Ø¯ÛØ¯',
        'add_new_item'          => 'Ø§ÙØ²ÙØ¯Ù Ú©Ø§ÙØ§Û Ø¬Ø¯ÛØ¯',
        'edit_item'             => 'ÙÛØ±Ø§ÛØ´ Ú©Ø§ÙØ§',
        'new_item'              => 'Ú©Ø§ÙØ§Û Ø¬Ø¯ÛØ¯',
        'view_item'             => 'ÙÙØ§ÛØ´ Ú©Ø§ÙØ§',
        'search_items'          => 'Ø¬Ø³ØªØ¬ÙÛ Ú©Ø§ÙØ§ÙØ§',
        'not_found'             => 'Ú©Ø§ÙØ§ÛÛ ÛØ§ÙØª ÙØ´Ø¯',
        'not_found_in_trash'    => 'Ú©Ø§ÙØ§ÛÛ Ø¯Ø± Ø²Ø¨Ø§ÙÙâØ¯Ø§Ù ÛØ§ÙØª ÙØ´Ø¯',
        'all_items'             => 'ÙÙÙ Ú©Ø§ÙØ§ÙØ§'
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'product'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-cart', // Ø¢ÛÚ©ÙÙ ÙØ±ÙØ´Ú¯Ø§ÙÛ
        'supports'           => array('title', 'editor', 'thumbnail', 'excerpt'),
        'show_in_rest'       => true, // Ù¾Ø´ØªÛØ¨Ø§ÙÛ Ø§Ø² Ú¯ÙØªÙØ¨Ø±Ú¯
    );

    register_post_type('evazar_product', $args);

    // Ø«Ø¨Øª Ø¯Ø³ØªÙâØ¨ÙØ¯Û Ø§Ø®ØªØµØ§ØµÛ (Taxonomy)
    register_taxonomy(
        'evazar_category',
        'evazar_product',
        array(
            'labels' => array(
                'name'              => 'Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§',
                'singular_name'     => 'Ø¯Ø³ØªÙâØ¨ÙØ¯Û',
                'menu_name'         => 'Ø¯Ø³ØªÙâØ¨ÙØ¯Û Ú©Ø§ÙØ§ÙØ§',
                'search_items'      => 'Ø¬Ø³ØªØ¬ÙÛ Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§',
                'all_items'         => 'ÙÙÙ Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§',
                'parent_item'       => 'Ø¯Ø³ØªÙ ÙØ§ÙØ¯',
                'parent_item_colon' => 'Ø¯Ø³ØªÙ ÙØ§ÙØ¯:',
                'edit_item'         => 'ÙÛØ±Ø§ÛØ´ Ø¯Ø³ØªÙâØ¨ÙØ¯Û',
                'update_item'       => 'Ø¨ÙâØ±ÙØ²Ø±Ø³Ø§ÙÛ Ø¯Ø³ØªÙâØ¨ÙØ¯Û',
                'add_new_item'      => 'Ø§ÙØ²ÙØ¯Ù Ø¯Ø³ØªÙ Ø¬Ø¯ÛØ¯',
                'new_item_name'     => 'ÙØ§Ù Ø¯Ø³ØªÙ Ø¬Ø¯ÛØ¯',
            ),
            'rewrite'           => array('slug' => 'product-category', 'with_front' => false),
            'hierarchical'      => true,
            'show_admin_column' => true,
            'show_in_rest'      => true,
        )
    );

    // Ø«Ø¨Øª Ø¨Ø±ÙØ¯ Ø§Ø®ØªØµØ§ØµÛ Ú©Ø§ÙØ§ÙØ§ (Taxonomy)
    register_taxonomy(
        'evazar_brand',
        'evazar_product',
        array(
            'labels' => array(
                'name'              => 'Ø¨Ø±ÙØ¯ÙØ§',
                'singular_name'     => 'Ø¨Ø±ÙØ¯',
                'menu_name'         => 'Ø¨Ø±ÙØ¯ÙØ§',
                'search_items'      => 'Ø¬Ø³ØªØ¬ÙÛ Ø¨Ø±ÙØ¯ÙØ§',
                'all_items'         => 'ÙÙÙ Ø¨Ø±ÙØ¯ÙØ§',
                'edit_item'         => 'ÙÛØ±Ø§ÛØ´ Ø¨Ø±ÙØ¯',
                'update_item'       => 'Ø¨ÙâØ±ÙØ²Ø±Ø³Ø§ÙÛ Ø¨Ø±ÙØ¯',
                'add_new_item'      => 'Ø§ÙØ²ÙØ¯Ù Ø¨Ø±ÙØ¯ Ø¬Ø¯ÛØ¯',
                'new_item_name'     => 'ÙØ§Ù Ø¨Ø±ÙØ¯ Ø¬Ø¯ÛØ¯',
            ),
            'rewrite'           => array('slug' => 'brand', 'with_front' => false),
            'hierarchical'      => false,
            'show_admin_column' => true,
            'show_in_rest'      => true,
        )
    );
}

add_action('init', 'evazar_ensure_brand_rewrites', 99);
function evazar_ensure_brand_rewrites()
{
    if (get_option('evazar_brand_rewrite_v2') !== '1') {
        flush_rewrite_rules(false);
        update_option('evazar_brand_rewrite_v2', '1');
    }
}

// ÙÙØ§ÙÛÙ Ø±ÛâØ±Ø§ÛØª Ø§Ø®ØªØµØ§ØµÛ Ø¨Ø±Ø§Û ÙÙØ´ÙâÙØ§Û Ø³Ø§ÛØª Ù Ø¯Ø³ØªØ±Ø³ÛâÙØ§Û Ø¬Ø§ÛÚ¯Ø²ÛÙ ÙØ±ÙØ´Ú¯Ø§Ù
add_action('init', 'evazar_core_register_sitemap_rewrites', 1);
function evazar_core_register_sitemap_rewrites() {
    add_rewrite_rule('^sitemap_index\.xml$', 'index.php?sitemap=1', 'top');
    add_rewrite_rule('^sitemap\.xml$', 'index.php?sitemap=1', 'top');
    add_rewrite_rule('^([^/]+?)-sitemap([0-9]+)?\.xml$', 'index.php?sitemap=$matches[1]&sitemap_n=$matches[2]', 'top');
    add_rewrite_rule('^([a-zA-Z0-9_-]+)-sitemap\.xsl$', 'index.php?xsl=$matches[1]', 'top');
    add_rewrite_rule('^main-sitemap\.xsl$', 'index.php?xsl=main', 'top');
    add_rewrite_rule('^products/?$', 'index.php?post_type=evazar_product', 'top');
    add_rewrite_rule('^shop/?$', 'index.php?post_type=evazar_product', 'top');
    add_rewrite_rule('^store/?$', 'index.php?post_type=evazar_product', 'top');
    add_rewrite_rule('^kala/?$', 'index.php?post_type=evazar_product', 'top');

    if (get_option('evazar_core_sitemap_flushed_v4') !== '1') {
        flush_rewrite_rules(false);
        update_option('evazar_core_sitemap_flushed_v4', '1');
    }
}

add_filter('query_vars', function($vars) {
    $vars[] = 'sitemap';
    $vars[] = 'sitemap_n';
    $vars[] = 'xsl';
    return $vars;
});

// Ø±ÙÚ¯ÛØ±Û ÙØ³ØªÙÛÙ Ø¯Ø± ØµÙØ±Øª Ø¹Ø¯Ù Ø§Ø¬Ø±Ø§Û Ø±ÛâØ±Ø§ÛØª
add_action('parse_request', 'evazar_core_sitemap_parse_request_handler', 1);
function evazar_core_sitemap_parse_request_handler($wp) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');

    if ($path === 'sitemap_index.xml' || $path === 'sitemap.xml') {
        $wp->query_vars['sitemap'] = '1';
        return;
    }

    if (preg_match('#^([a-zA-Z0-9_-]+?)-sitemap([0-9]+)?\.xml$#i', $path, $matches)) {
        $wp->query_vars['sitemap'] = $matches[1];
        if (!empty($matches[2])) {
            $wp->query_vars['sitemap_n'] = $matches[2];
        }
        return;
    }

    if ($path === 'main-sitemap.xsl' || preg_match('#^([a-zA-Z0-9_-]+?)-sitemap\.xsl$#i', $path, $matches)) {
        $wp->query_vars['xsl'] = !empty($matches[1]) ? $matches[1] : 'main';
        return;
    }

    if ($path === 'products' || $path === 'shop' || $path === 'store' || $path === 'kala') {
        $wp->query_vars['post_type'] = 'evazar_product';
        return;
    }
}

// Ø´ÙÙÙÛØª ÙØ·Ø¹Û Ú©Ø§ÙØ§ÙØ§Û Ø§ÛÙØ§Ø²Ø§Ø±Ø Ø¯Ø³ØªÙâÙØ§ Ù Ø¨Ø±ÙØ¯ÙØ§ Ø¯Ø± ÙÙØ´Ù Ø³Ø§ÛØª Ø±ÙÚ©âÙØ«
add_filter('rank_math/sitemap/post_types', function($post_types) {
    if (!isset($post_types['evazar_product'])) {
        $post_types['evazar_product'] = 'evazar_product';
    }
    return $post_types;
});
add_filter('rank_math/sitemap/taxonomies', function($taxonomies) {
    if (!isset($taxonomies['evazar_category'])) {
        $taxonomies['evazar_category'] = 'evazar_category';
    }
    if (!isset($taxonomies['evazar_brand'])) {
        $taxonomies['evazar_brand'] = 'evazar_brand';
    }
    return $taxonomies;
});

// ÙÙÚ¯Ø§ÙâØ³Ø§Ø²Û Ù ØªØ±ÙÛÙ Ø®ÙØ¯Ú©Ø§Ø± Ø³Ø§Ø®ØªØ§Ø± Ø¯Ø±Ø®ØªÛ Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§ Ø¯Ø± Ø¯ÛØªØ§Ø¨ÛØ³
add_action('admin_init', 'evazar_auto_repair_category_tree');
function evazar_auto_repair_category_tree()
{
    if (get_option('evazar_cat_tree_repaired_v3') === '1') {
        return;
    }

    $prods = get_posts([
        'post_type'      => 'evazar_product',
        'posts_per_page' => 100,
        'post_status'    => 'any',
        'meta_query'     => [
            [
                'key'     => '_evazar_breadcrumbs',
                'compare' => 'EXISTS'
            ]
        ]
    ]);

    if (!empty($prods) && function_exists('evazar_sync_product_categories')) {
        foreach ($prods as $p) {
            $bc = get_post_meta($p->ID, '_evazar_breadcrumbs', true);
            $cat = get_post_meta($p->ID, '_evazar_category', true);
            $brand = get_post_meta($p->ID, '_evazar_brand', true);
            if (!empty($bc)) {
                evazar_sync_product_categories($p->ID, $bc, $cat, $brand);
            }
        }
    }

    update_option('evazar_cat_tree_repaired_v3', '1');
}

// ==========================================
// 2. ØªÙØ¸ÛÙØ§Øª Ø§ÙØ²ÙÙÙ (ÙÛÙÚ© Ø¹ÙÙÙÛ Ø§ÙÛÙÛÙ)
// ==========================================
add_action('admin_menu', 'evazar_core_add_admin_menu');
function evazar_core_add_admin_menu()
{
    add_submenu_page(
        'edit.php?post_type=evazar_product',
        'ØªÙØ¸ÛÙØ§Øª Ø§ÙÛÙÛØª Ø§ÛÙØ§Ø²Ø§Ø±',
        'ØªÙØ¸ÛÙØ§Øª Ø§ÙÛÙÛØª',
        'manage_options',
        'evazar-affiliate-settings',
        'evazar_core_settings_page'
    );
}

add_action('admin_init', 'evazar_core_settings_init');
function evazar_core_settings_init()
{
    register_setting('evazar_core_settings_group', 'evazar_cf_worker_url', ['sanitize_callback' => 'esc_url_raw']);
    register_setting('evazar_core_settings_group', 'evazar_cf_worker_token', ['sanitize_callback' => 'sanitize_text_field']);
    register_setting('evazar_core_settings_group', 'evazar_image_cdn_domain', ['sanitize_callback' => 'esc_url_raw']);
    add_settings_section('evazar_core_worker_section', 'ÙØ±Ú©Ø± Ú©ÙÙØ¯ÙÙØ± Ù Ø´Ø¨Ú©Ù ØªÙØ²ÛØ¹ ØªØµØ§ÙÛØ± (Cloudflare Worker & Image CDN)', null, 'evazar-affiliate-settings');
    add_settings_field('evazar_cf_worker_url', 'Ø¢Ø¯Ø±Ø³ ÙØ±Ú©Ø± Ú©ÙÙØ¯ÙÙØ± (Worker URL)', 'evazar_cf_worker_url_render', 'evazar-affiliate-settings', 'evazar_core_worker_section');
    add_settings_field('evazar_cf_worker_token', 'ØªÙÚ©Ù Ø¯Ø§Ø®ÙÛ Ø§Ø±ØªØ¨Ø§Ø· Ø¨Ø§ Worker', 'evazar_cf_worker_token_render', 'evazar-affiliate-settings', 'evazar_core_worker_section');
    add_settings_field('evazar_image_cdn_domain', 'Ø¯Ø§ÙÙÙ ØªÙØ²ÛØ¹ Ù Ú©Ø´ ØªØµØ§ÙÛØ± (Image CDN Subdomain)', 'evazar_image_cdn_domain_render', 'evazar-affiliate-settings', 'evazar_core_worker_section');

    // Affiliate Settings
    register_setting('evazar_core_settings_group', 'evazar_base_affiliate_link');
    add_settings_section('evazar_core_main_section', 'ØªÙØ¸ÛÙØ§Øª ÙÛÙÚ© Ø¹ÙÙÙÛ Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§ (Ø§ÙÛÙÛÙ)', null, 'evazar-affiliate-settings');
    add_settings_field('evazar_base_affiliate_link', 'ÙÛÙÚ© Ø¹ÙÙÙÛ Ø§ÙÛÙÛÙ (Ø­Ø§ÙÛ {redirect_to})', 'evazar_base_affiliate_link_render', 'evazar-affiliate-settings', 'evazar_core_main_section');
    // ØªÙØ¸ÛÙØ§Øª UX ØµÙØ­Ù Ø§ÙØªÙØ§Ù Ø§ÙÛÙÛØª ÙÙØ· Ø§Ø² Ù¾ÙÙ Â«ØªÙØ¸ÛÙØ§Øª ÙØ§ÙØ¨ Ø§ÛÙØ§Ø²Ø§Ø±Â» ÙØ¯ÛØ±ÛØª ÙÛâØ´ÙØ¯.

    // AI Settings (Fully Decoupled Dual Engine)
    register_setting('evazar_core_settings_group', 'evazar_ai_enabled');
    register_setting('evazar_core_settings_group', 'evazar_ai_taxonomy_enabled');
    register_setting('evazar_core_settings_group', 'evazar_ai_taxonomy_exclude_misc');
    register_setting('evazar_core_settings_group', 'evazar_ai_taxonomy_exclude_keywords');
    register_setting('evazar_core_settings_group', 'evazar_ai_engine_mode');
    register_setting('evazar_core_settings_group', 'evazar_openai_api_key');
    register_setting('evazar_core_settings_group', 'evazar_openai_model');
    register_setting('evazar_core_settings_group', 'evazar_openai_api_url');
    register_setting('evazar_core_settings_group', 'evazar_gemini_api_key');
    register_setting('evazar_core_settings_group', 'evazar_gemini_model');
    register_setting('evazar_core_settings_group', 'evazar_gemini_api_url');
    register_setting('evazar_core_settings_group', 'evazar_ai_provider');
    register_setting('evazar_core_settings_group', 'evazar_ai_api_key');
    register_setting('evazar_core_settings_group', 'evazar_ai_api_url');
    register_setting('evazar_core_settings_group', 'evazar_ai_model');
    register_setting('evazar_core_settings_group', 'evazar_ai_prompt');
    register_setting('evazar_core_settings_group', 'evazar_ai_product_prompt_v4');
    register_setting('evazar_core_settings_group', 'evazar_ai_product_prompt_v5');
    register_setting('evazar_core_settings_group', 'evazar_ai_product_prompt_v6');
    register_setting('evazar_core_settings_group', 'evazar_ai_product_prompt_v7');
    register_setting('evazar_core_settings_group', 'evazar_ai_category_prompt_v4');
    register_setting('evazar_core_settings_group', 'evazar_ai_brand_prompt_v4');
    register_setting('evazar_core_settings_group', 'evazar_ai_timeout');

    add_settings_section('evazar_core_ai_section', 'ÙÙØ´ ÙØµÙÙØ¹Û (AI) - ØªÙÙÛØ¯ Ø®ÙØ¯Ú©Ø§Ø± ÙØ­ØªÙØ§Û Ú©Ø§ÙØ§Ø Ø¯Ø³ØªÙ Ù Ø¨Ø±ÙØ¯', null, 'evazar-affiliate-settings');
    add_settings_field('evazar_ai_enabled', 'ÙØ¶Ø¹ÛØª Ø³ÛØ³ØªÙ AI Ú©Ø§ÙØ§ÙØ§', 'evazar_ai_enabled_render', 'evazar-affiliate-settings', 'evazar_core_ai_section');
    add_settings_field('evazar_ai_taxonomy_enabled', 'ØªÙÙÛØ¯ ÙØ­ØªÙØ§ Ø¨Ø±Ø§Û Ø¯Ø³ØªÙ Ù Ø¨Ø±ÙØ¯', 'evazar_ai_taxonomy_enabled_render', 'evazar-affiliate-settings', 'evazar_core_ai_section');
    add_settings_field('evazar_ai_taxonomy_exclude_misc', 'Ø§Ø³ØªØ«ÙØ§Û Ø¯Ø³ØªÙâÙØ§Û ÙØªÙØ±ÙÙ Ø§Ø² ØªÙÙÛØ¯ ÙØ­ØªÙØ§', 'evazar_ai_taxonomy_exclude_misc_render', 'evazar-affiliate-settings', 'evazar_core_ai_section');
    add_settings_field('evazar_ai_engine_mode', 'ÙÙØªÙØ± Ù Ø§Ø³ØªØ±Ø§ØªÚÛ Ù¾Ø±Ø¯Ø§Ø²Ø´ ÙÙØ´ ÙØµÙÙØ¹Û', 'evazar_ai_engine_mode_render', 'evazar-affiliate-settings', 'evazar_core_ai_section');
    add_settings_field('evazar_openai_settings_box', 'Ù¾ÛÚ©Ø±Ø¨ÙØ¯Û Ø§Ø®ØªØµØ§ØµÛ OpenAI (ChatGPT)', 'evazar_openai_settings_render', 'evazar-affiliate-settings', 'evazar_core_ai_section');
    add_settings_field('evazar_gemini_settings_box', 'Ù¾ÛÚ©Ø±Ø¨ÙØ¯Û Ø§Ø®ØªØµØ§ØµÛ Google Gemini', 'evazar_gemini_settings_render', 'evazar-affiliate-settings', 'evazar_core_ai_section');
    add_settings_field('evazar_ai_timeout', 'ÙÙÙØª Ø²ÙØ§ÙÛ Ù¾Ø§Ø³Ø® ÙÙØ´ ÙØµÙÙØ¹Û (Ø«Ø§ÙÛÙ)', 'evazar_ai_timeout_render', 'evazar-affiliate-settings', 'evazar_core_ai_section');
    add_settings_field('evazar_ai_prompt', 'ÙØ­Ù Ù Ù¾Ø±Ø§ÙÙ¾Øª Ø¨Ø§Ø²ÙÙÛØ³Û ØªÙØ¶ÛØ­Ø§Øª Ú©Ø§ÙØ§ÙØ§', 'evazar_ai_prompt_render', 'evazar-affiliate-settings', 'evazar_core_ai_section');
    add_settings_field('evazar_ai_category_prompt', 'Ù¾Ø±Ø§ÙÙ¾Øª Ø±Ø§ÙÙÙØ§Û Ø®Ø±ÛØ¯ Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§', 'evazar_ai_category_prompt_render', 'evazar-affiliate-settings', 'evazar_core_ai_section');
    add_settings_field('evazar_ai_brand_prompt', 'Ù¾Ø±Ø§ÙÙ¾Øª ÙØ¹Ø±ÙÛ Ù Ø±Ø§ÙÙÙØ§Û Ø®Ø±ÛØ¯ Ø¨Ø±ÙØ¯ÙØ§', 'evazar_ai_brand_prompt_render', 'evazar-affiliate-settings', 'evazar_core_ai_section');

    // ØªÙØ¸ÛÙØ§Øª ÙØªØ§ØªÚ¯âÙØ§ Ù Ø³Ø¦ÙÛ Ø±ÙÚ©âÙØ« Ú©Ø§ÙØ§ÙØ§
    register_setting('evazar_core_settings_group', 'evazar_product_title_template', [
        'sanitize_callback' => 'sanitize_text_field'
    ]);
    register_setting('evazar_core_settings_group', 'evazar_product_desc_template', [
        'sanitize_callback' => 'sanitize_textarea_field'
    ]);

    add_settings_section('evazar_core_seo_section', 'Ø§ÙÚ¯ÙÙØ§Û Ø³Ø¦Ù Ù Ø¹ÙØ§ÙÛÙ ÙØªØ§Û Ú©Ø§ÙØ§ Ø¯Ø± Ú¯ÙÚ¯Ù (Rank Math & Meta Title Patterns)', null, 'evazar-affiliate-settings');
    add_settings_field('evazar_product_title_template', 'Ø§ÙÚ¯ÙÛ Ø¹ÙÙØ§Ù ÙØªØ§Û Ú©Ø§ÙØ§ÙØ§ (Meta Title)', 'evazar_product_title_template_render', 'evazar-affiliate-settings', 'evazar_core_seo_section');
    add_settings_field('evazar_product_desc_template', 'Ø§ÙÚ¯ÙÛ ØªÙØ¶ÛØ­Ø§Øª ÙØªØ§Û Ù¾ÛØ´âÙØ±Ø¶ Ú©Ø§ÙØ§ (Meta Description)', 'evazar_product_desc_template_render', 'evazar-affiliate-settings', 'evazar_core_seo_section');
}

function evazar_cf_worker_url_render()
{
    $url = get_option('evazar_cf_worker_url', '');
    echo '<input type="url" name="evazar_cf_worker_url" value="' . esc_attr($url) . '" style="width: 100%; max-width: 600px; direction: ltr;" placeholder="https://evazar-digikala-worker.yourname.workers.dev">';
    echo '<p class="description">Ø¢Ø¯Ø±Ø³ ÙØ±Ú©Ø± ÙØ³ØªÙØ± Ø¯Ø± Ú©ÙÙØ¯ÙÙØ± (Ú©Ø¯ <code>digikala-worker.js</code>). Ø¯Ø±ÛØ§ÙØª ÙÛÙØª/ÙÙØ¬ÙØ¯Û Ù ÙØ§Ø±Ø¯Ø§Øª Ø§Ø² Ø·Ø±ÛÙ ÙÙÛÙ ÙØ³ÛØ± Ø§ÙØ¬Ø§Ù ÙÛâØ´ÙØ¯Ø TTL Ø¯Ø± ÙØ³Ø®Ù Ø¬Ø¯ÛØ¯ Ú©ÙØªØ§Ù Ù ÙØ§Ø¨Ù Ú©ÙØªØ±Ù Ø§Ø³Øª.</p>';
}

function evazar_cf_worker_token_render()
{
    $token = get_option('evazar_cf_worker_token', '');
    echo '<input type="password" name="evazar_cf_worker_token" value="' . esc_attr($token) . '" style="width: 100%; max-width: 600px; direction: ltr;" autocomplete="new-password" placeholder="ÛÚ© ØªÙÚ©Ù ØªØµØ§Ø¯ÙÛ Ù Ø·ÙÙØ§ÙÛ">';
    echo '<p class="description">Ø§ÛÙ ØªÙÚ©Ù Ø¨Ø§ÛØ¯ Ø¯ÙÛÙØ§Ù Ø¯Ø± Secret ÙØ±Ú©Ø± Ø¨Ø§ ÙØ§Ù <code>EVAZAR_INTERNAL_TOKEN</code> ÙØ±Ø§Ø± Ú¯ÛØ±Ø¯. Ø¨Ø±Ø§Û Ø§Ø³ØªØ¹ÙØ§Ù ÙØ­ØµÙÙ Ù ÙØ³ÛØ±ÙØ§Û Ø¯Ø§Ø®ÙÛ Ø§Ø³ØªÙØ§Ø¯Ù ÙÛâØ´ÙØ¯ Ù ÙØ¨Ø§ÛØ¯ Ø¯Ø± Ú©Ø¯ ÙØ±Ø§ÙØªâØ§ÙØ¯ ÙØ±Ø§Ø± Ú¯ÛØ±Ø¯.</p>';
}

function evazar_image_cdn_domain_render()
{
    $domain = get_option('evazar_image_cdn_domain', 'https://img.evazar.ir');
    echo '<input type="url" name="evazar_image_cdn_domain" value="' . esc_attr($domain) . '" style="width: 100%; max-width: 600px; direction: ltr;" placeholder="https://img.evazar.ir">';
    echo '<p class="description">Ø¢Ø¯Ø±Ø³ Ø³Ø§Ø¨âØ¯Ø§ÙÙÙ Ø§Ø®ØªØµØ§ØµÛ ØªØµØ§ÙÛØ± Ú©ÙÙØ¯ÙÙØ± (Ù¾ÛØ´âÙØ±Ø¶: <code>https://img.evazar.ir</code>). Ø¨Ø§ Ø§ØªØµØ§Ù Ø§ÛÙ Ø³Ø§Ø¨âØ¯Ø§ÙÙÙ Ø¨Ù ÙØ±Ú©Ø±Ø ØªØµØ§ÙÛØ± Ø¨Ø§ Ú©Ø´ ÙØ¨ÙâØ§Û Û± Ø³Ø§ÙÙ Ú©ÙÙØ¯ÙÙØ± Ù Ø¨Ø±ÙØ¯ Ø§ÛÙØ§Ø²Ø§Ø± ÙÙØ¯ ÙÛâØ´ÙÙØ¯.</p>';
}

function evazar_base_affiliate_link_render()
{
    $link = get_option('evazar_base_affiliate_link', '');
    echo '<input type="text" name="evazar_base_affiliate_link" value="' . esc_attr($link) . '" style="width: 100%; max-width: 600px; direction: ltr;" placeholder="https://publisher.affilio.ir/click?utm_data=...&landing={redirect_to}">';
    echo '<p class="description">Ø³ÛØ³ØªÙ Ø¯Ø± ØµÙØ­Ù Ú©Ø§ÙØ§Ø ÙÛÙÚ© Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§ Ø±Ø§ Ø§ÙÚ©ÙØ¯ Ú©Ø±Ø¯Ù Ù Ø¬Ø§ÛÚ¯Ø²ÛÙ <code>{redirect_to}</code> ÙÛâÚ©ÙØ¯.</p>';
}


function evazar_ai_enabled_render()
{
    $val = get_option('evazar_ai_enabled', '');
    echo '<label><input type="checkbox" name="evazar_ai_enabled" value="yes" ' . checked($val, 'yes', false) . '> ÙØ¹Ø§ÙâØ³Ø§Ø²Û ØªÙÙÛØ¯ Ù Ø¨Ø§Ø²ÙÙÛØ³Û ØªÙØ¶ÛØ­Ø§Øª Ú©Ø§ÙØ§ Ø¨Ø§ ÙÙØ´ ÙØµÙÙØ¹Û Ø¯Ø± ÙÙÚ¯Ø§Ù ÙØ§Ø±Ø¯Ø§Øª</label>';
}

function evazar_ai_taxonomy_enabled_render()
{
    $val = get_option('evazar_ai_taxonomy_enabled', 'yes');
    echo '<label><input type="checkbox" name="evazar_ai_taxonomy_enabled" value="yes" ' . checked($val, 'yes', false) . '> ØªÙÙÛØ¯ Ø®ÙØ¯Ú©Ø§Ø± ÙÙØ§ÙÙ Ø±Ø§ÙÙÙØ§Û Ø®Ø±ÛØ¯ Ø³Ø¦Ù Ø´Ø¯Ù Ø¨Ø±Ø§Û Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§ Ù Ø¨Ø±ÙØ¯ÙØ§Û Ø¬Ø¯ÛØ¯ (ÙÙØ· ÛÚ©âØ¨Ø§Ø± ÙÙÚ¯Ø§Ù Ø³Ø§Ø®Øª)</label>';
    echo '<p class="description">Ø¨Ø±Ø§Û Ø¬ÙÙÚ¯ÛØ±Û Ø§Ø² Ø§ØªÙØ§Ù ØªÙÚ©ÙØ Ø§ÛÙ ÙÙØ§ÙÙ ÙÙØ· ÛÚ©âØ¨Ø§Ø± ÙÙÚ¯Ø§Ù Ø³Ø§Ø®ØªÙ Ø´Ø¯Ù Ø¯Ø³ØªÙ/Ø¨Ø±ÙØ¯ ØªÙÙÛØ¯ ÙÛâØ´ÙØ¯ Ù Ø¨Ø±Ø§Û Ú©Ø§ÙØ§ÙØ§Û Ø¨Ø¹Ø¯Û ØªÚ©Ø±Ø§Ø± ÙÙÛâØ´ÙØ¯.</p>';
}

function evazar_ai_taxonomy_exclude_misc_render()
{
    $val = get_option('evazar_ai_taxonomy_exclude_misc', 'yes');
    $keywords = get_option('evazar_ai_taxonomy_exclude_keywords', 'ÙØªÙØ±ÙÙ, miscellaneous, Ø¹ÙÙÙÛ');
    echo '<label><input type="checkbox" name="evazar_ai_taxonomy_exclude_misc" value="yes" ' . checked($val, 'yes', false) . '> <strong>Ø¹Ø¯Ù ØªÙÙÛØ¯ ÙØ­ØªÙØ§Û ÙÙØ´ ÙØµÙÙØ¹Û Ø¨Ø±Ø§Û Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§ ÛØ§ Ø¨Ø±ÙØ¯ÙØ§Û ÙØªÙØ±ÙÙ Ù Ø¨Ø¯ÙÙ Ø¨Ø±ÙØ¯</strong></label>';
    echo '<p class="description" style="margin-top: 8px;">Ú©ÙÙØ§Øª Ú©ÙÛØ¯Û Ø§Ø³ØªØ«ÙØ§ (Ø¨Ø§ Ú©Ø§ÙØ§ Ø§ÙÚ¯ÙÛØ³Û <code>,</code> Ø¬Ø¯Ø§ Ú©ÙÛØ¯):</p>';
    echo '<input type="text" name="evazar_ai_taxonomy_exclude_keywords" value="' . esc_attr($keywords) . '" style="width: 100%; max-width: 500px;" placeholder="ÙØªÙØ±ÙÙ, miscellaneous, Ø¹ÙÙÙÛ">';
    echo '<p class="description">Ø§Ú¯Ø± Ø¹ÙÙØ§Ù ÛØ§ ÙØ§ÙÚ© (Ø§Ø³ÙØ§Ú¯) Ø¯Ø³ØªÙ/Ø¨Ø±ÙØ¯ Ø´Ø§ÙÙ Ø§ÛÙ Ú©ÙÙØ§Øª Ø¨Ø§Ø´Ø¯ (ÙØ§ÙÙØ¯ Â«Ú©ÛÙ Ù Ú©Ø§ÙØ± Ú¯ÙØ´Û ÙØªÙØ±ÙÙÂ»)Ø Ø³ÛØ³ØªÙ ÙÙØ´ ÙØµÙÙØ¹Û Ø¨Ù ÙÛÚ ÙØ¬Ù Ø¨Ø±Ø§Û Ø¢Ù ÙØ­ØªÙØ§ ØªÙÙÛØ¯ ÙÚ©Ø±Ø¯Ù Ù ØªÙÚ©ÙÛ ÙØµØ±Ù ÙÙÛâØ´ÙØ¯.</p>';
}

function evazar_ai_engine_mode_render()
{
    $val = get_option('evazar_ai_engine_mode', '');
    if (empty($val)) {
        $legacy = get_option('evazar_ai_provider', 'openai');
        $val = ($legacy === 'gemini') ? 'gemini_fallback_openai' : 'openai_fallback_gemini';
    }
    echo '<select name="evazar_ai_engine_mode" style="min-width: 380px; font-weight: bold; font-size: 13px;">';
    echo '<option value="openai_only" ' . selected($val, 'openai_only', false) . '>Û±. ØµØ±ÙØ§Ù OpenAI (Ø§Ø®ØªØµØ§ØµÛ Ù Ú©Ø§ÙÙØ§Ù Ø§ÛØ²ÙÙÙ Ø¨Ø¯ÙÙ Ø¯Ø®Ø§ÙØª Ø¬ÛÙÙØ§Û)</option>';
    echo '<option value="gemini_only" ' . selected($val, 'gemini_only', false) . '>Û². ØµØ±ÙØ§Ù Google Gemini (ÙØ³ØªÙÙØ Ø§ÙØªØµØ§Ø¯Û Ù Ø§Ø±Ø²Ø§Ù)</option>';
    echo '<option value="gemini_fallback_openai" ' . selected($val, 'gemini_fallback_openai', false) . '>Û³. Ø¯ÙÚ¯Ø§ÙÙ ÙÙØ´ÙÙØ¯ (ØªÙØµÛÙâØ´Ø¯Ù): Ø§ÙÙÙÛØª GeminiØ Ø¯Ø± ØµÙØ±Øª Ø³ÙÙ Ø³ÙÙÛÙ (429) Ø³ÙÛÛÚ Ø¨Ù OpenAI</option>';
    echo '<option value="openai_fallback_gemini" ' . selected($val, 'openai_fallback_gemini', false) . '>Û´. Ø¯ÙÚ¯Ø§ÙÙ ÙÙØ´ÙÙØ¯: Ø§ÙÙÙÛØª OpenAIØ Ø¯Ø± ØµÙØ±Øª Ø§ØªÙØ§Ù Ø´Ø§Ø±Ú Ø³ÙÛÛÚ Ø¨Ù Gemini</option>';
    echo '</select>';
    echo '<p class="description" style="margin-top: 6px;">Ø§ÙØªØ®Ø§Ø¨ Ø§Ø³ØªØ±Ø§ØªÚÛ Ù¾Ø±Ø¯Ø§Ø²Ø´. Ø¯Ø± Ø­Ø§ÙØªâÙØ§Û Ø¯ÙÚ¯Ø§ÙÙØ Ø§Ú¯Ø± ÛÚ©Û Ø§Ø² Ø³Ø±ÙÛØ³âÙØ§ Ø¨Ù Ø³ÙÙ Ø³ÙÙÛÙ (429 Rate Limit) Ø¨Ø±Ø®ÙØ±Ø¯ Ú©ÙØ¯Ø Ø³ÛØ³ØªÙ Ø¨Ø¯ÙÙ ØªÙÙÙ ÙØ±Ø¢ÛÙØ¯ ÙØ§Ø±Ø¯Ø§ØªØ ÙÙØ±Ø§Ù Ø¨Ø§ ÙÙØªÙØ± Ø¯ÙÙ ÙØ­ØªÙØ§ Ø±Ø§ Ø¨Ø§Ø²ÙÙÛØ³Û ÙÛâÚ©ÙØ¯.</p>';
}

function evazar_openai_settings_render()
{
    $key_val = get_option('evazar_openai_api_key', '');
    if (empty(trim($key_val))) {
        $legacy = get_option('evazar_ai_api_key', '');
        if (function_exists('evazar_extract_api_keys_by_prefix')) {
            $extracted = evazar_extract_api_keys_by_prefix($legacy, 'openai');
            if (!empty($extracted)) {
                $key_val = implode("\n", $extracted);
            }
        }
    }

    $model_val = get_option('evazar_openai_model', '');
    if (empty($model_val) || strpos($model_val, 'gemini') !== false) {
        $legacy_model = get_option('evazar_ai_model', '');
        $model_val = (!empty($legacy_model) && strpos($legacy_model, 'gemini') === false) ? $legacy_model : 'gpt-4o-mini';
    }

    $url_val = get_option('evazar_openai_api_url', '');
    if (empty($url_val)) {
        $legacy_url = get_option('evazar_ai_api_url', '');
        if (!empty($legacy_url) && strpos($legacy_url, 'googleapis') === false) {
            $url_val = $legacy_url;
        }
    }

    $models = [
        'gpt-4o-mini' => 'GPT-4o Mini (Ø³Ø±ÛØ¹âØªØ±ÛÙØ Ø¨Ø³ÛØ§Ø± Ø¨Ø§Ú©ÛÙÛØª Ù Ø¨Ø§ Ø­Ø¯Ø§ÙÙ ÙØ²ÛÙÙ ØªÙÚ©Ù - Ø§Ø³ØªØ§ÙØ¯Ø§Ø±Ø¯ Ø¬ÙØ§ÙÛ)',
        'gpt-4o'      => 'GPT-4o (Ø¨Ø§ÙØ§ØªØ±ÛÙ Ú©ÛÙÛØª ØªÙÙÛØ¯ ÙØªÙ Ù Ø§Ø³ØªØ¯ÙØ§Ù)',
        'gpt-6-luna'  => 'GPT-6 Luna (Ø³Ø±ÛØ¹ Ù Ø§ÙØªØµØ§Ø¯Û ÙÛÚÙ Ú©Ø§Ø±ÙØ§Û Ù¾Ø±Ø­Ø¬Ù - Ø¯Ø± ØµÙØ±Øª ÙØ¹Ø§Ù Ø¨ÙØ¯Ù Ø¯Ø± Ø§Ú©Ø§ÙØª)',
        'gpt-6.1-sol' => 'GPT-6.1 Sol (ÙØ¯Ù ØªØ¹Ø§Ø¯ÙÛ Ø¬Ø¯ÛØ¯)',
        'gpt-3.5-turbo' => 'GPT-3.5 Turbo (ÙØ¯Ù Ø³Ø¨Ú© Ú©ÙØ§Ø³ÛÚ©)',
    ];

    echo '<div style="background: #f8fafc; border: 1px solid #e2e8f0; border-right: 4px solid #10a37f; border-radius: 8px; padding: 16px; max-width: 750px;">';
    echo '<h4 style="margin: 0 0 12px 0; color: #0f172a; display: flex; align-items: center; gap: 8px;"><span style="background: #10a37f; color: #fff; padding: 2px 8px; border-radius: 4px; font-size: 11px;">OpenAI Engine</span> Ú©ÙÛØ¯ÙØ§ Ù Ù¾ÛÚ©Ø±Ø¨ÙØ¯Û Ø§Ø®ØªØµØ§ØµÛ OpenAI</h4>';
    
    echo '<p style="margin: 0 0 6px 0; font-weight: 600; font-size: 13px;">Ú©ÙÛØ¯ÙØ§Û API Ø§Ø®ØªØµØ§ØµÛ OpenAI (ÙØ± Ø®Ø· ÛÚ© Ú©ÙÛØ¯ Ø¨Ø§ Ù¾ÛØ´ÙÙØ¯ <code>sk-</code>):</p>';
    echo '<textarea name="evazar_openai_api_key" style="width: 100%; height: 90px; direction: ltr; font-family: monospace; font-size: 12px;" placeholder="sk-proj-...&#10;sk-...">' . esc_textarea($key_val) . '</textarea>';
    echo '<p class="description" style="margin-top: 4px;">Ø³ÛØ³ØªÙ Ø¨Ù ØµÙØ±Øª Ø®ÙØ¯Ú©Ø§Ø± Ø¨ÛÙ Ú©ÙÛØ¯ÙØ§Û OpenAI ÚØ±Ø®Ø´ (Rotation) Ø§ÙØ¬Ø§Ù ÙÛâØ¯ÙØ¯.</p>';

    echo '<div style="margin-top: 14px;">';
    echo '<label style="display: block; font-weight: 600; font-size: 13px; margin-bottom: 6px;">ÙØ¯Ù ÙÙØ´ ÙØµÙÙØ¹Û OpenAI:</label>';
    echo '<select name="evazar_openai_model" style="min-width: 320px; direction: ltr; font-weight: 500;">';
    foreach ($models as $k => $v) {
        echo '<option value="' . esc_attr($k) . '" ' . selected($model_val, $k, false) . '>' . esc_html($v) . '</option>';
    }
    echo '</select>';
    echo '<p class="description" style="margin-top: 4px;">Ù¾ÛØ´ÙÙØ§Ø¯ ÙØ·Ø¹Û: <code>GPT-4o Mini</code> Ø¨Ø§ ÙØ²ÛÙÙ Ø¨Ø³ÛØ§Ø± ÙØ§ÚÛØ² Ù Ø³Ø±Ø¹Øª ÙÙÙâØ§ÙØ¹Ø§Ø¯Ù Ø¨Ø§ÙØ§.</p>';
    echo '</div>';

    echo '<div style="margin-top: 14px;">';
    echo '<label style="display: block; font-weight: 600; font-size: 13px; margin-bottom: 6px;">Ø§ÙØ¯Ù¾ÙÛÙØª Ø§Ø®ØªØµØ§ØµÛ / Ù¾Ø±Ø§Ú©Ø³Û OpenAI (Ø§Ø®ØªÛØ§Ø±Û):</label>';
    echo '<input type="url" name="evazar_openai_api_url" value="' . esc_attr($url_val) . '" style="width: 100%; direction: ltr; font-family: monospace;" placeholder="Ù¾ÛØ´âÙØ±Ø¶: Ù¾Ø±ÙÚ©Ø³Û ÙØ±Ú©Ø± Ú©ÙÙØ¯ÙÙØ± Ø§ÛÙØ§Ø²Ø§Ø±">';
    echo '<p class="description" style="margin-top: 4px;">Ø¯Ø± Ø­Ø§ÙØª Ù¾ÛØ´âÙØ±Ø¶ Ø¯Ø±Ø®ÙØ§Ø³ØªâÙØ§ Ø§Ø² ÙØ±Ú©Ø± Ú©ÙÙØ¯ÙÙØ± Ø§ÛÙØ§Ø²Ø§Ø± Ø¹Ø¨ÙØ± ÙÛâÚ©ÙÙØ¯ ØªØ§ ØªØ­Ø±ÛÙ Ø¢ÛâÙ¾Û Ø§ÛØ±Ø§Ù Ù ÙØ³Ø¯ÙØ¯Ø³Ø§Ø²Û Ú©Ø§ÙÙ Ø¯ÙØ± Ø²Ø¯Ù Ø´ÙØ¯.</p>';
    echo '</div>';

    echo '</div>';
}

function evazar_gemini_settings_render()
{
    $key_val = get_option('evazar_gemini_api_key', '');
    if (empty(trim($key_val))) {
        $legacy = get_option('evazar_ai_api_key', '');
        if (function_exists('evazar_extract_api_keys_by_prefix')) {
            $extracted = evazar_extract_api_keys_by_prefix($legacy, 'gemini');
            if (!empty($extracted)) {
                $key_val = implode("\n", $extracted);
            }
        }
    }

    $model_val = get_option('evazar_gemini_model', '');
    if (empty($model_val) || strpos($model_val, 'gemini') === false) {
        $legacy_model = get_option('evazar_ai_model', '');
        $model_val = (!empty($legacy_model) && strpos($legacy_model, 'gemini') !== false) ? $legacy_model : 'gemini-3.5-flash-lite';
    if (strpos((string)$model_val, 'gemini-') !== 0) { $model_val = 'gemini-3.5-flash-lite'; }
    }

    $url_val = get_option('evazar_gemini_api_url', '');

    $models = [
        'gemini-3.5-flash-lite' => 'Google Gemini 3.5 Flash Lite (Ù¾ÛØ´ÙÙØ§Ø¯ Ø§ØµÙÛ Ø¨Ø±Ø§Û Ù¾Ø±Ø¯Ø§Ø²Ø´ Ù¾Ø±Ø­Ø¬Ù)',
        'gemini-3.1-flash-lite' => 'Google Gemini 3.1 Flash Lite (Ø³Ø±ÛØ¹ Ù Ø§ÙØªØµØ§Ø¯Û)',
        'gemini-3.5-flash'      => 'Google Gemini 3.5 Flash (Ú©ÛÙÛØª Ø¨Ø§ÙØ§ØªØ±)',
        'gemini-2.5-flash'      => 'Google Gemini 2.5 Flash (Ø¯Ø± ØµÙØ±Øª ÙØ¹Ø§Ù Ø¨ÙØ¯Ù Ø¨Ø±Ø§Û Ù¾Ø±ÙÚÙ)',
    ];

    echo '<div style="background: #f8fafc; border: 1px solid #e2e8f0; border-right: 4px solid #1a73e8; border-radius: 8px; padding: 16px; max-width: 750px;">';
    echo '<h4 style="margin: 0 0 12px 0; color: #0f172a; display: flex; align-items: center; gap: 8px;"><span style="background: #1a73e8; color: #fff; padding: 2px 8px; border-radius: 4px; font-size: 11px;">Google Gemini</span> Ú©ÙÛØ¯ÙØ§ Ù Ù¾ÛÚ©Ø±Ø¨ÙØ¯Û Ø§Ø®ØªØµØ§ØµÛ Google Gemini</h4>';
    
    echo '<p style="margin: 0 0 6px 0; font-weight: 600; font-size: 13px;">Ú©ÙÛØ¯ÙØ§Û API Ú¯ÙÚ¯Ù Ø¬ÛÙÙØ§Û (ÙØ± Ø®Ø· ÛÚ© Ú©ÙÛØ¯ Ø¨Ø§ Ù¾ÛØ´ÙÙØ¯ <code>AIza</code> ÛØ§ <code>AQ.</code>):</p>';
    echo '<textarea name="evazar_gemini_api_key" style="width: 100%; height: 90px; direction: ltr; font-family: monospace; font-size: 12px;" placeholder="AIzaSy...&#10;AQ....">' . esc_textarea($key_val) . '</textarea>';
    echo '<p class="description" style="margin-top: 4px;">Ø§ÙÚ©Ø§Ù ÙØ§Ø±Ø¯ Ú©Ø±Ø¯Ù ÚÙØ¯ÛÙ Ú©ÙÛØ¯ Ø¬ÛÙÙØ§Û Ø¬ÙØª ÚØ±Ø®Ø´ Ø®ÙØ¯Ú©Ø§Ø± Ú©ÙÛØ¯ÙØ§ Ø¯Ø± ØµÙØ±Øª ÙÙØ§Ø¬ÙÙ Ø¨Ø§ Ø®Ø·Ø§Û Ø³ÙÙÛÙ (429).</p>';

    echo '<div style="margin-top: 14px;">';
    echo '<label style="display: block; font-weight: 600; font-size: 13px; margin-bottom: 6px;">ÙØ¯Ù Google Gemini:</label>';
    echo '<select name="evazar_gemini_model" style="min-width: 320px; direction: ltr; font-weight: 500;">';
    foreach ($models as $k => $v) {
        echo '<option value="' . esc_attr($k) . '" ' . selected($model_val, $k, false) . '>' . esc_html($v) . '</option>';
    }
    echo '</select>';
    echo '<p class="description" style="margin-top: 4px;">Ù¾ÛØ´ÙÙØ§Ø¯ Ù¾ÛØ´âÙØ±Ø¶: <code>Gemini 3.5 Flash Lite</code> Ø³Ø§Ø²Ú¯Ø§Ø± Ø¨Ø§ Ù¾Ø±Ø§Ú©Ø³Û ÙØ±Ú©Ø± Ú©ÙÙØ¯ÙÙØ±.</p>';
    echo '</div>';

    echo '<div style="margin-top: 14px;">';
    echo '<label style="display: block; font-weight: 600; font-size: 13px; margin-bottom: 6px;">Ø§ÙØ¯Ù¾ÙÛÙØª Ø§Ø®ØªØµØ§ØµÛ / Ù¾Ø±Ø§Ú©Ø³Û Gemini (Ø§Ø®ØªÛØ§Ø±Û):</label>';
    echo '<input type="url" name="evazar_gemini_api_url" value="' . esc_attr($url_val) . '" style="width: 100%; direction: ltr; font-family: monospace;" placeholder="Ù¾ÛØ´âÙØ±Ø¶: Ø§ØªØµØ§Ù ÙÙØ´ÙÙØ¯ Ø¨Ø¯ÙÙ ØªØ­Ø±ÛÙ Ø§Ø² Ø·Ø±ÛÙ ÙØ±Ú©Ø± Ú©ÙÙØ¯ÙÙØ± Ø§ÛÙØ§Ø²Ø§Ø±">';
    echo '<p class="description" style="margin-top: 4px;">Ø¯Ø± Ø­Ø§ÙØª Ø¹Ø§Ø¯Û Ø®Ø§ÙÛ Ø¨Ú¯Ø°Ø§Ø±ÛØ¯ ØªØ§ Ø§Ø² Ù¾Ø±ÙÚ©Ø³Û ÙØ±Ú©Ø± Ø§Ø³ØªÙØ§Ø¯Ù Ø´ÙØ¯.</p>';
    echo '</div>';

    echo '</div>';
}

function evazar_ai_timeout_render()
{
    $val = intval(get_option('evazar_ai_timeout', 60));
    if ($val < 30) $val = 60;
    echo '<input type="number" name="evazar_ai_timeout" value="' . esc_attr($val) . '" min="30" max="180" step="5" style="width: 100px; text-align: center;">';
    echo '<p class="description" style="margin-top: 4px;">Ø­Ø¯Ø§Ú©Ø«Ø± ÙÙÙØª Ø²ÙØ§Ù Ø§ÙØªØ¸Ø§Ø± Ø¨Ø±Ø§Û Ø¯Ø±ÛØ§ÙØª Ù¾Ø§Ø³Ø® ÙÙØ´ ÙØµÙÙØ¹Û (Ù¾ÛØ´âÙØ±Ø¶: Û¶Û° Ø«Ø§ÙÛÙ). Ø¯Ø± Ú©Ø§ÙØ§ÙØ§Û Ø¨Ø§ ÙØ´Ø®ØµØ§Øª ÙÙÛ ÙÙØµÙ ÙØ§ÙÙØ¯ ÙÙ¾âØªØ§Ù¾ ÛØ§ ÙÙØ¨Ø§ÛÙØ ÙÙØ§Ø¯ÛØ± Ú©ÙØªØ± Ø§Ø² Û´Ûµ Ø«Ø§ÙÛÙ ÙÛâØªÙØ§ÙØ¯ ÙÙØ¬Ø¨ Ø®Ø·Ø§Û cURL error 28 Ø´ÙØ¯.</p>';
}

function evazar_ai_provider_render() { evazar_ai_engine_mode_render(); }
function evazar_ai_api_key_render() {}
function evazar_ai_api_url_render() {}
function evazar_ai_model_render() {}

function evazar_get_default_ai_product_prompt()
{
    return "Ø´ÙØ§ ÛÚ© Ú©Ù¾ÛâØ±Ø§ÛØªØ± Ø§Ø±Ø´Ø¯ ØªØ¬Ø§Ø±Øª Ø§ÙÚ©ØªØ±ÙÙÛÚ©Ø ÙÙÛØ³ÙØ¯Ù ØªØ®ØµØµÛ ÙÙØ¯ Ù Ø¨Ø±Ø±Ø³Û ÙØ­ØµÙÙØ§Øª Ù Ø§Ø³ØªØ±Ø§ØªÚÛØ³Øª Ø§Ø±Ø´Ø¯ Ø³Ø¦Ù ÙØ³ØªÛØ¯.\n"
         . "ÙØ¸ÛÙÙ Ø´ÙØ§ Ø¨Ø§Ø²ÙÙÛØ³ÛØ ØªØ­ÙÛÙ Ù Ø®ÙÙ ÛÚ© ÙØªÙ ÙÙØ¯ Ù Ø¨Ø±Ø±Ø³Û ØªØ®ØµØµÛØ Ú©Ø§ÙÙØ§Ù Ø±ÙØ§ÙØ Ø®ÙØ§ÙØ¯ÙÛ Ù ÚÙØ¯Ù¾Ø§Ø±Ø§Ú¯Ø±Ø§ÙÛ Ø¨Ø±Ø§Û ØµÙØ­Ù ÙØ­ØµÙÙ Ø¯Ø± ÙØ±ÙØ´Ú¯Ø§Ù Ø§ÛÙØªØ±ÙØªÛ Ø¨Ø± Ù¾Ø§ÛÙ Ø¯Ø§Ø¯ÙâÙØ§ Ù ÙØ´Ø®ØµØ§Øª ÙØ±ÙØ¯Û Ø§Ø³Øª.\n\n"
         . "ÙÙØ§ÙÛÙ Ù Ø§Ø³ØªØ§ÙØ¯Ø§Ø±Ø¯ÙØ§Û Ú©Ù¾ÛâØ±Ø§ÛØªÛÙÚ¯ ØªØ®ØµØµÛ (ÙØªÙ Ù¾ÙÛØ§Ø Ù¾ÛÙØ³ØªÙ Ù Ø¨Ø¯ÙÙ ØªÛØªØ±ÙØ§Û Ú©ÙÛØ´ÙâØ§Û):\n\n"
         . "Û±. Ø¹Ø¯Ù Ø¯Ø±Ø¬ ÙØ±Ú¯ÙÙÙ Ø¹ÙÙØ§ÙØ Ø³Ø±ÙØµÙ ÛØ§ Ø¨Ø±ÚØ³Ø¨ (Zero Headers / No Titles):\n"
         . "- Ø§Ú©ÛØ¯Ø§Ù ÙÛÚâÚ¯ÙÙÙ Ø¹ÙÙØ§ÙØ ØªÛØªØ±Ø Ø³Ø±ÙØµÙØ Ø¹ÙØ§ÙØª ÙØ¯Ø± ÙØ§Ø±Ú©âØ¯Ø§ÙÙ (ÙØ§ÙÙØ¯ ###) ÛØ§ Ú©ÙÙØ§Øª Ø¨Ø±ÚØ³Ø¨Û Ø§Ø¨ØªØ¯Ø§Û Ø®Ø· (ÙØ§ÙÙØ¯ Â«ÙØ¹Ø±ÙÛ:Â»Ø Â«Ø·Ø±Ø§Ø­Û:Â»Ø Â«Ø¹ÙÙÚ©Ø±Ø¯:Â»Ø Â«ÙÙØ¨Ø¹ ØªØºØ°ÛÙ:Â»Ø Â«Ø¬ÙØ¹âØ¨ÙØ¯Û:Â») ÙÙÙÛØ³ÛØ¯.\n"
         . "- ÙØªÙ Ø¨Ø§ÛØ¯ ÛÚ© ÙÙØ§ÙÙ ÛÚ©Ø¯Ø³ØªØ Ø§Ø±Ú¯Ø§ÙÛÚ©Ø Ø´ÛÚ© Ù Ù¾ÛÙØ³ØªÙ Ø¨Ø§Ø´Ø¯ Ú©Ù ÙÙØ¶ÙØ¹Ø§Øª Ø¨Ù ØµÙØ±Øª Ú©Ø§ÙÙØ§Ù Ø·Ø¨ÛØ¹ÛØ Ø±ÙØ§Ù Ù Ø¨Ø§ Ø§Ø¯Ø¨ÛØ§ØªÛ Ú¯ÛØ±Ø§ Ø¯Ø± ÙØ§ÙØ¨ ÚÙØ¯ Ø¨ÙØ¯ (Ù¾Ø§Ø±Ø§Ú¯Ø±Ø§Ù) ÙØ³ØªÙÙ Ù Ø¨Ù ÙÙ Ù¾ÛÙØ³ØªÙ Ø§Ø² Ù¾Û ÙÙ Ø¨ÛØ§ÛÙØ¯.\n\n"
         . "Û². Ø³Ø§Ø®ØªØ§Ø± ÚÙØ¯Ù¾Ø§Ø±Ø§Ú¯Ø±Ø§ÙÛ Ù¾ÙÛØ§ ÙØªÙØ§Ø³Ø¨ Ø¨Ø§ Ù¾ØªØ§ÙØ³ÛÙ ÙØ§ÙØ¹Û Ú©Ø§ÙØ§ (Ø§ØµÙ ØªÙØ§Ø³Ø¨ Ù Ù¾ÙÛØ§ÛÛ Ú©Ø§ÙÙ):\n"
         . "- ØªØ¹Ø¯Ø§Ø¯ Ù Ø­Ø¬Ù Ù¾Ø§Ø±Ø§Ú¯Ø±Ø§ÙâÙØ§ Ø¨Ø§ÛØ¯ Ú©Ø§ÙÙØ§Ù Ù¾ÙÛØ§ Ù ÙØªÙØ§Ø³Ø¨ Ø¨Ø§ Ø¹ÙÙ Ù Ù¾ØªØ§ÙØ³ÛÙ Ø§Ø·ÙØ§Ø¹Ø§Øª Ú©Ø§ÙØ§ Ø´Ú©Ù Ø¨Ú¯ÛØ±Ø¯:\n"
         . "  * Ø¨Ø±Ø§Û Ú©Ø§ÙØ§Û Ø³Ø§Ø¯Ù ÛØ§ Ú©ÙâÙØ´Ø®ØµØ§Øª: Û² ØªØ§ Û³ Ù¾Ø§Ø±Ø§Ú¯Ø±Ø§Ù Ø±ÙØ§ÙØ Ú©Ø§Ø±Ø¨Ø±Ø¯Û Ù ÙÙØ³Ø¬Ù Ø¨ÙÙÛØ³.\n"
         . "  * Ø¨Ø±Ø§Û Ú©Ø§ÙØ§Û ØºÙÛØ ÙÙÛ ÛØ§ Ù¾Ø±ÙØ´Ø®ØµØ§Øª: Û³ ØªØ§ Ûµ Ù¾Ø§Ø±Ø§Ú¯Ø±Ø§Ù Ø¹ÙÛÙØ ØªØ­ÙÛÙÛ Ù Ø¬Ø§ÙØ¹ Ø¨ÙÙÛØ³.\n"
         . "- Ù¾Ø§Ø±Ø§Ú¯Ø±Ø§ÙâÙØ§ Ø¨Ø§ Ø¯Ø§Ø¨Ù Ø§ÛÙØªØ± (\\n\\n) Ø§Ø² ÙÙ ØªÙÚ©ÛÚ© Ø´ÙÙØ¯ ØªØ§ ÚÛØ¯ÙØ§Ù Ø³Ø§ÛØª Ú©Ø§ÙÙØ§Ù ÙÙØ¸Ù Ù Ø®ÙØ§ÙØ§ Ø¨Ø§Ø´Ø¯.\n"
         . "- Ø¬Ø±ÛØ§Ù Ø·Ø¨ÛØ¹Û ÙØ­ØªÙØ§: Ø¨ÙØ¯ Ø§ÙÙ Ø§Ø² ÙØ¹Ø±ÙÛ ÙÙÛØª Ù Ú©Ø§Ø±Ø¨Ø±Ø¯ Ø§ØµÙÛ Ú©Ø§ÙØ§ Ø´Ø±ÙØ¹ Ø´ÙØ¯Ø Ø¨ÙØ¯ÙØ§Û ÙÛØ§ÙÛ Ø§Ø¨Ø¹Ø§Ø¯Ø Ø§Ø±Ú¯ÙÙÙÙÛØ Ø¹ÙÙÚ©Ø±Ø¯ ÙÙÛØ ÙØªØ±ÛØ§Ù Ù Ú©Ø§Ø±Ø§ÛÛ ÙØ§ÙØ¹Û Ø±Ø§ Ú©Ø§ÙØ¨Ø¯Ø´Ú©Ø§ÙÛ Ú©ÙÙØ¯ Ù Ø¨ÙØ¯ Ù¾Ø§ÛØ§ÙÛ Ø¨Ù Ø§Ø±Ø²ÛØ§Ø¨Û ÙÙØ§ÛÛ Ø§Ø±Ø²Ø´ Ø®Ø±ÛØ¯ Ù ØªÙØµÛÙ Ú©Ø§Ø±Ø¨Ø±Û Ø§Ø®ØªØµØ§Øµ ÛØ§Ø¨Ø¯.\n\n"
         . "Û³. ÙÙØ§Ø¯Ø§Ø±Û Ú©Ø§ÙÙ Ø¨Ù ÙØ´Ø®ØµØ§Øª ÙØ§ÙØ¹Û Ù Ø¹Ø¯Ù ØªØ®ÛÙ (Zero Hallucination):\n"
         . "- ØªÙØ§Ù Ø§Ø¹Ø¯Ø§Ø¯Ø Ø§Ø¨Ø¹Ø§Ø¯Ø ÙØ¯ÙØ Ø¬ÙØ³Ø Ø¸Ø±ÙÛØªØ ÙØ¯Øª Ø²ÙØ§Ù Ø´Ø§Ø±Ú/Ø´Ø§Ø±ÚØ¯ÙÛØ Ø±ÙÚ¯Ø Ø§ÙÙØ§Ù ÙÙØ±Ø§Ù Ù ÙÛÚÚ¯ÛâÙØ§Û ÙÙÛ Ø±Ø§ Ø¯ÙÛÙØ§Ù Ø¨Ø± Ù¾Ø§ÛÙ Ø¯Ø§Ø¯ÙâÙØ§Û ÙØ±ÙØ¯Û Ø­ÙØ¸ Ú©Ù.\n"
         . "- Ø§Ø² Ø§Ø®ØªØ±Ø§Ø¹ ÙØ´Ø®ØµØ§Øª ÙØ§ÙÙØ¬ÙØ¯ Ø§Ú©ÛØ¯Ø§Ù Ø®ÙØ¯Ø¯Ø§Ø±Û Ú©ÙØ Ø§ÙØ§ ÙØ²Ø§ÛØ§ Ù Ú©Ø§Ø±Ú©Ø±Ø¯ ÙØ´Ø®ØµØ§Øª ÙØ§ÙØ¹Û Ø±Ø§ Ø¨Ø±Ø§Û Ø®Ø±ÛØ¯Ø§Ø± ØªØ¨ÛÛÙ ÙÙØ§.\n"
         . "- ÙØ§Ù ÙØ§Ø±Ú©ØªâÙ¾ÙÛØ³âÙØ§Û Ø¯ÛÚ¯Ø± (ÙØ§ÙÙØ¯ Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§ Ù...)Ø ÙØ§Ù ÙØ±ÙØ´ÙØ¯Ú¯Ø§ÙØ Ø´Ø±Ø§ÛØ· Ø§Ø±Ø³Ø§Ù ÙØªÙØ±ÙÙ ÛØ§ ÙÛÙØªâÙØ§Û ÙÛØ¯ Ø´Ø¯Ù Ø¯Ø± ÙØªÙ ÙØ¨Ø¯Ø§ Ø±Ø§ Ú©Ø§ÙÙØ§Ù Ø­Ø°Ù Ú©Ù.\n\n"
         . "Û´. ÙÙØ± Ú©Ù¾ÛâØ±Ø§ÛØªÛÙÚ¯ Ù ØªØ¨Ø¯ÛÙ ÙÛÚÚ¯Û Ø¨Ù ÙÙÙØ¹Øª ÙÙÙÙØ³:\n"
         . "- Ø¨Ø±Ø§Û ÙØ± ÙØ´Ø®ØµÙ ÙÙÛØ Ú©Ø§Ø±Ø¨Ø±Ø¯ ÙÙÙÙØ³ Ø¢Ù Ø¯Ø± Ø²ÙØ¯Ú¯Û Ø®Ø±ÛØ¯Ø§Ø± Ø±Ø§ Ø¨ÛØ§Ù Ú©Ù (ÙØ´Ø§ÙØ± Ø®Ø±ÛØ¯ Ø¢Ú¯Ø§ÙØ Ø¨ÛâØ·Ø±Ù Ù Ø­Ø±ÙÙâØ§Û).\n"
         . "- Ø§Ø² Ø¬ÙÙØ§Øª Ø¨Ø§Ø²Ø§Ø±ÛØ§Ø¨Û Ú©ÙÛØ´ÙâØ§Û Ù Ù¾ÙÚ (ÙØ§ÙÙØ¯ Â«Ø§Ú¯Ø± Ø¨Ù Ø¯ÙØ¨Ø§Ù Ø¨ÙØªØ±ÛÙ ÙØ³ØªÛØ¯Â»Ø Â«Ø§ÙØªØ®Ø§Ø¨Û Ø¨ÛâÙØ¸ÛØ±Â») Ø§Ú©ÛØ¯Ø§Ù Ø®ÙØ¯Ø¯Ø§Ø±Û Ú©Ù.\n"
         . "- ÙØªÙ Ø¨Ø§ÛØ¯ Ú©Ø§ÙÙØ§Ù Ø±ÙØ§Ù Ø¨Ø§ Ø±Ø¹Ø§ÛØª Ø¯ÙÛÙ ÙÛÙâÙØ§ØµÙÙâÙØ§ Ù ÙÚ¯Ø§Ø±Ø´ Ø§Ø³ØªØ§ÙØ¯Ø§Ø±Ø¯ Ù Ø§ØµÛÙ Ø²Ø¨Ø§Ù ÙØ§Ø±Ø³Û Ø¨Ø§Ø´Ø¯.\n\n"
         . "Ûµ. ÛÚ©Ø¯Ø³ØªÛ Ø§Ø±ÙØ§Ù Ù ÙÚ¯Ø§Ø±Ø´ Ø§Ø¨Ø¹Ø§Ø¯ (ØµØ±ÙØ§Ù Ø¨Ø±Ø§Û Ø§Ø¨Ø¹Ø§Ø¯ ÙÛØ²ÛÚ©ÛØ ÙÙ ÙØ§Ù ÙØ¯ÙâÙØ§):\n"
         . "- Ø¯Ø± ÙÙØ´ØªÙ Ø§Ø¨Ø¹Ø§Ø¯ Ù Ø§ÙØ¯Ø§Ø²ÙâÙØ§Û ÙÛØ²ÛÚ©Û Ú©Ø§ÙØ§ (ÙØ§ÙÙØ¯ Ø·ÙÙØ Ø¹Ø±Ø¶Ø Ø§Ø±ØªÙØ§Ø¹Ø Ø¶Ø®Ø§ÙØª) Ø§Ú©ÛØ¯Ø§Ù Ø§Ø² Ø­Ø±Ù Ø§ÙÚ¯ÙÛØ³Û x Ø§Ø³ØªÙØ§Ø¯Ù ÙÚ©ÙØ Ø¨ÙÚ©Ù ÙÙØ­ØµØ±Ø§Ù Ø§Ø² Ø¹ÙØ§ÙØª Ø¶Ø±Ø¨Ø¯Ø± Ø§Ø³ØªØ§ÙØ¯Ø§Ø±Ø¯ (Ã) Ø§Ø³ØªÙØ§Ø¯Ù Ú©Ù Ù ØªÙØ§Ù Ø§Ø±ÙØ§Ù Ø¢Ù Ø±Ø§ Ø¨Ù ØµÙØ±Øª ÛÚ©Ø¯Ø³Øª ÙØ§Ø±Ø³Û (ÙØ§ÙÙØ¯ Û±Û¶Û° Ã Û±Û±Û° Ã Û¶Ûµ) Ø¨ÙÙÛØ³.\n"
         . "- Ø§Ø³ØªØ«ÙØ§Û Ø¨Ø³ÛØ§Ø± Ø­ÛØ§ØªÛ: Ø­Ø±Ù Ø§ÙÚ¯ÙÛØ³Û X Ø¯Ø± ÙØ§Ù ÙØ¯ÙâÙØ§Ø Ù¾Ø§Ø±ØªâÙØ§ÙØ¨Ø±ÙØ§Ø Ú©Ø¯ Ú©Ø§ÙØ§ÙØ§ ÛØ§ ÙØ·Ø¹Ø§Øª Ø³Ø®ØªâØ§ÙØ²Ø§Ø±Û (ÙØ§ÙÙØ¯ Vivobook 16 X1605 ÛØ§ iPhone X ÛØ§ Ù¾Ø±Ø¯Ø§Ø²ÙØ¯ÙâÙØ§ Ù Ú©Ø§Ø±ØªâÙØ§Û Ú¯Ø±Ø§ÙÛÚ©) Ø¬Ø²Ø¦Û Ø§Ø² ÙØ§Ù Ú©Ø§ÙØ§ Ø§Ø³Øª Ù Ø§Ú©ÛØ¯Ø§Ù ÙØ¨Ø§ÛØ¯ Ø¨Ù Ø¹ÙØ§ÙØª Ø¶Ø±Ø¨Ø¯Ø± (Ã) ØªØ¨Ø¯ÛÙ Ø´ÙØ¯.\n"
         . "- Ø§Ø² ØªØ±Ú©ÛØ¨ Ø§Ø±ÙØ§Ù Ø§ÙÚ¯ÙÛØ³Û Ù ÙØ§Ø±Ø³Û Ø¯Ø± ÛÚ© Ø¹Ø¯Ø¯ (ÙØ§ÙÙØ¯ Û³0000 ÛØ§ Û±Û¶0) Ø´Ø¯ÛØ¯Ø§Ù Ù¾Ø±ÙÛØ² Ú©Ù Ù ØªÙØ§Ù Ø§Ø¹Ø¯Ø§Ø¯ ÙØªÙÛ Ø±Ø§ Ø¨Ù ØµÙØ±Øª Ø§Ø±ÙØ§Ù ÙØ§Ø±Ø³Û ÛÚ©Ø¯Ø³Øª Ø¨ÙÙÛØ³.";
}

function evazar_ai_prompt_render()
{
    $default_prompt = evazar_get_default_ai_product_prompt();
    $val = get_option('evazar_ai_product_prompt_v7', '');
    
    // Ø§ÙØªÙØ§Ù Ø®ÙØ¯Ú©Ø§Ø± Ø§Ø² ÙØ³Ø®ÙâÙØ§Û ÙØ¨ÙÛ ÛØ§ Ø¬Ø§ÛÚ¯Ø²ÛÙÛ Ø¯Ø± ØµÙØ±Øª ÙØ¬ÙØ¯ ÙØ­Ø¯ÙØ¯ÛØª ÛØ§ ØªÛØªØ±ÙØ§Û Ø«Ø§Ø¨Øª Ø¯Ø± Ø¯ÛØªØ§Ø¨ÛØ³
    if (empty($val)) {
        $old_v6 = get_option('evazar_ai_product_prompt_v6', '');
        if (empty($old_v6) || strpos($old_v6, 'Û²Û¶Û°') !== false || strpos($old_v6, '260') !== false || strpos($old_v6, 'Û±Û°Û°') !== false || strpos($old_v6, '100') !== false || strpos($old_v6, 'ÙØªÙÛ Ø¨Ø³ÛØ§Ø± ÙØ´Ø±Ø¯Ù') !== false || strpos($old_v6, 'Ø³Ø±ÙØµÙâÙØ§Û ÙÙØ¶ÙØ¹Û') !== false || strpos($old_v6, '###') !== false) {
            $val = $default_prompt;
        } else {
            $val = $old_v6;
        }
        update_option('evazar_ai_product_prompt_v7', $val);
    }

    $js_default_prompt = json_encode($default_prompt, JSON_UNESCAPED_UNICODE);

    echo '<div style="max-width: 820px;">';
    echo '<textarea id="evazar_ai_product_prompt_input" name="evazar_ai_product_prompt_v7" style="width: 100%; height: 280px; font-size: 13px; line-height: 1.6; padding: 10px; border-radius: 6px; border: 1px solid #cbd5e1;">' . esc_textarea($val) . '</textarea>';
    echo '<div style="margin-top: 8px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 8px;">';
    echo '<button type="button" class="button" onclick="if(confirm(\'Ø¢ÛØ§ Ø§Ø² Ø¨Ø§Ø²ÙØ´Ø§ÙÛ Ù¾Ø±Ø§ÙÙ¾Øª Ø¨Ù ÙØ³Ø®Ù Ù¾ÙÛØ§Ø ÚÙØ¯Ù¾Ø§Ø±Ø§Ú¯Ø±Ø§ÙÛ Ù Ø¨Ø¯ÙÙ ØªÛØªØ±ÙØ§Û Ú©ÙÛØ´ÙâØ§Û ÙØ·ÙØ¦Ù ÙØ³ØªÛØ¯Ø\')){ document.getElementById(\'evazar_ai_product_prompt_input\').value = ' . $js_default_prompt . '; }">ð Ø¨Ø§Ø²ÙØ´Ø§ÙÛ Ø¨Ù Ù¾Ø±Ø§ÙÙ¾Øª Ù¾ÛØ´âÙØ±Ø¶ Ø¬Ø¯ÛØ¯ (Ù¾ÙÛØ§ Ù Ø¨Ø¯ÙÙ ØªÛØªØ±ÙØ§Û Ú©ÙÛØ´ÙâØ§Û)</button>';
    echo '<span style="color: #059669; font-size: 12px; font-weight: 500;">â ØªÙÙÛØ¯ ÙÙØ¯ Ù Ø¨Ø±Ø±Ø³Û Ù¾ÙÛØ§Ø ÚÙØ¯Ù¾Ø§Ø±Ø§Ú¯Ø±Ø§ÙÛ Ù Ø¨Ø¯ÙÙ Ø¹ÙØ§ÙÛÙ ØªÚ©Ø±Ø§Ø±Û ÙØ¹Ø§Ù Ø§Ø³Øª</span>';
    echo '</div>';
    echo '<p class="description" style="margin-top: 6px;">Ø§ÛÙ ÙØªÙ Ø¨Ù Ø¹ÙÙØ§Ù Ø¯Ø³ØªÙØ±Ø§ÙØ¹ÙÙ Ù¾Ø§ÛÙ Ø¨Ø§Ø²ÙÙÛØ³Û Ú©Ø§ÙØ§ Ø¨Ù ÙÙØ´ ÙØµÙÙØ¹Û Ø¯Ø§Ø¯Ù ÙÛâØ´ÙØ¯. Ø¯Ø± ØµÙØ±Øª ÙÛØ§Ø² ÙÛâØªÙØ§ÙÛØ¯ Ø¨Ø§ Ø¯Ú©ÙÙ Ø¨Ø§ÙØ§ Ø¢Ù Ø±Ø§ Ø¨Ù Ø¢Ø®Ø±ÛÙ ÙØ³Ø®Ù Ø§Ø³ØªØ§ÙØ¯Ø§Ø±Ø¯ Ø¨Ø§Ø²ÙØ´Ø§ÙÛ Ú©ÙÛØ¯.</p>';
    echo '</div>';
}

function evazar_ai_category_prompt_render()
{
    $default_prompt = "Ø´ÙØ§ ÛÚ© Ú©Ø§Ø±Ø´ÙØ§Ø³ Ø³Ø¦Ù Ù Ø±Ø§ÙÙÙØ§Û Ø®Ø±ÛØ¯ Ø¨Ø±Ø§Û ÙØ±ÙØ´Ú¯Ø§Ù Ø§ÛÙØªØ±ÙØªÛ Â«{site_name}Â» ÙØ³ØªÛØ¯.\n"
                    . "ÙØ§Ù Ø§ÛÙ Ø¯Ø³ØªÙâØ¨ÙØ¯Û ÙØ­ØµÙÙØ§Øª Â«{term_name}Â» Ø§Ø³Øª Ù Ø§Ø·ÙØ§Ø¹Ø§Øª Ù¾Ø§ÛÙ Ø¢Ù Ø¯Ø± Ø¨Ø§Ø²Ø§Ø± Ø¨Ø¯ÛÙ Ø´Ø±Ø­ Ø§Ø³Øª:\n{source_content}\n\n"
                    . "Ø¯Ø³ØªÙØ±Ø§ÙØ¹ÙÙ ÙÚ¯Ø§Ø±Ø´ (Ø§ØµÙ ØªÙØ§Ø³Ø¨ Ù Ø¹Ø¯Ù ØªØ®ÛÙ):\n"
                    . "Û±. Ø·ÙÙ Ù Ø¹ÙÙ ÙØªÙ Ø®Ø±ÙØ¬Û Ø±Ø§ Ø¯ÙÛÙØ§Ù ÙØªÙØ§Ø³Ø¨ Ø¨Ø§ ÙØªÙ ÙØ±ÙØ¯Û ØªÙØ¸ÛÙ Ú©ÙÛØ¯. Ø¨Ù ÙÛÚ Ø¹ÙÙØ§Ù Ø¯Ø§Ø³ØªØ§ÙâØ³Ø±Ø§ÛÛ Ù Ø­Ø¯Ø³ ÙØ²ÙÛØ¯ Ù Ø¨Ø±Ø§Û Ø·ÙÙØ§ÙÛ Ú©Ø±Ø¯Ù ÙØªÙ Ø¨Ù Ø¢Ù Ø¢Ø¨ ÙØ¨ÙØ¯ÛØ¯.\n"
                    . "Û². Ø¨Ø±Ø§Û Ø¯Ø³ØªÙâÙØ§Û Ø¬Ø§ÙØ¨Û ÛØ§ Ø¨Ø§ Ø§Ø·ÙØ§Ø¹Ø§Øª Ú©ÙØ Ø¨Ø¯ÙÙ Ú©Ø´ Ø¯Ø§Ø¯Ù Ø§Ø¶Ø§ÙÙØ ÙØªÙÛ Ú©Ø§Ø±Ø¨Ø±Ø¯ÛØ ÙÙÛØ¯ Ù ÙØªÙØ§Ø³Ø¨ Ø¨Ø§ Ø¯Ø§Ø¯ÙâÙØ§Û ÙÙØ¬ÙØ¯ Ø¨ÙÙÛØ³ÛØ¯.\n"
                    . "Û³. Ø¨Ø±Ø§Û Ø¯Ø³ØªÙâÙØ§Û Ø§ØµÙÛ Ù Ù¾Ø±ÙØ­ØµÙÙØ ÙØ¹ÛØ§Ø±ÙØ§Û ÙÙÙ Ø®Ø±ÛØ¯ Ù ÙÛÚÚ¯ÛâÙØ§Û Ø´Ø§Ø®Øµ Ø±Ø§ Ø¨Ø§ ØªÛØªØ±ÙØ§Û H2 Ù H3 Ø¨Ù Ø´Ú©Ù Ø´Ú©ÛÙ ÙØ±ØªØ¨ Ú©ÙÛØ¯.\n"
                    . "Û´. Ø¨Ù ÙÛÚ ÙØ¬Ù ÙØ§Ù Â«Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§Â» ÛØ§ ÙÛÚ ÙØ§Ø±Ú©ØªâÙ¾ÙÛØ³ Ø¯ÛÚ¯Ø±Û Ø°Ú©Ø± ÙØ´ÙØ¯Ø ÙØ±Ø¬Ø¹ Ø¨Ø±Ø±Ø³Û Ù Ø®Ø±ÛØ¯ Â«{site_name}Â» Ø§Ø³Øª.\n"
                    . "Ø®Ø±ÙØ¬Û Ø±Ø§ Ø¯Ø± ÙØ§ÙØ¨ Ú©Ø¯ÙØ§Û HTML ØªÙÛØ² Ù Ø§Ø³ØªØ§ÙØ¯Ø§Ø±Ø¯ (Ø¨Ø§ ØªÚ¯âÙØ§Û <h2>Ø <h3>Ø <p>Ø <ul>Ø <li>) Ø¨Ø¯ÙÙ ØªÚ¯âÙØ§Û Ø§Ø¶Ø§ÙÛ html Ù body Ø¨Ø±Ú¯Ø±Ø¯Ø§ÙÛØ¯.";

    $val = get_option('evazar_ai_category_prompt_v4', '');
    if (empty($val)) $val = $default_prompt;
    echo '<textarea name="evazar_ai_category_prompt_v4" style="width: 100%; max-width: 800px; height: 210px;">' . esc_textarea($val) . '</textarea>';
    echo '<p class="description">ÙØªØºÛØ±ÙØ§Û Ù¾ÙÛØ§: <code>{term_name}</code> (ÙØ§Ù Ø¯Ø³ØªÙâØ¨ÙØ¯Û)Ø <code>{source_content}</code> (ÙØªÙ Ø§Ø³ØªØ®Ø±Ø§Ø¬ Ø´Ø¯Ù Ø§Ø² Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§)Ø <code>{site_name}</code> (ÙØ§Ù Ø³Ø§ÛØª).</p>';
}

function evazar_ai_brand_prompt_render()
{
    $default_prompt = "Ø´ÙØ§ ÛÚ© ÙÛØ±Ø§Ø³ØªØ§Ø± Ø§Ø±Ø´Ø¯ Ù Ú©Ø§Ø±Ø´ÙØ§Ø³ Ø³Ø¦Ù Ø¨Ø±Ø§Û ÙØ±ÙØ´Ú¯Ø§Ù Ø§ÛÙØªØ±ÙØªÛ Â«{site_name}Â» ÙØ³ØªÛØ¯.\n"
                    . "ÙØ§Ù Ø§ÛÙ Ø¨Ø±ÙØ¯ Â«{term_name}Â» Ø§Ø³Øª Ù Ø¯Ø§Ø¯ÙâÙØ§Û ÙØ§ÙØ¹Û Ø¢Ù Ø¯Ø± Ø¨Ø§Ø²Ø§Ø± Ø¨Ù Ø§ÛÙ Ø´Ø±Ø­ Ø§Ø³Øª:\n{source_content}\n\n"
                    . "Ø¯Ø³ØªÙØ±Ø§ÙØ¹ÙÙ ÙÚ¯Ø§Ø±Ø´ (Ø§ØµÙ ØªÙØ§Ø³Ø¨ Ù Ø¹Ø¯Ù ØªØ®ÛÙ):\n"
                    . "Û±. Ø·ÙÙ Ù Ø¹ÙÙ ÙØªÙ Ø®Ø±ÙØ¬Û Ø¨Ø§ÛØ¯ Ú©Ø§ÙÙØ§Ù ÙØªÙØ§Ø³Ø¨ Ø¨Ø§ Ø­Ø¬Ù Ø§Ø·ÙØ§Ø¹Ø§Øª ÙÙØ¬ÙØ¯ Ø¯Ø± ÙØªÙ ÙÙØ¨Ø¹ Ø¨Ø§Ø´Ø¯. Ø¨Ù ÙÛÚ ÙØ¬Ù Ø¨Ø±Ø§Û Ø§ÙØ²Ø§ÛØ´ ØªØ¹Ø¯Ø§Ø¯ Ú©ÙÙØ§Øª Ø¨Ù ÙØªÙ Ø¢Ø¨ ÙØ¨ÙØ¯ÛØ¯ Ù ÙÛÚ Ø¯Ø§Ø³ØªØ§ÙØ ØªØ§Ø±ÛØ®ÚÙØ Ø¬ÙØ§ÛØ² ÛØ§ ÙØ­ØµÙÙØ§ØªÛ Ø§Ø®ØªØ±Ø§Ø¹ ÙÚ©ÙÛØ¯.\n"
                    . "Û². Ø§Ú¯Ø± Ø§Ø·ÙØ§Ø¹Ø§Øª Ù¾Ø§ÛÙ Ú©ÙØªØ§Ù Ø§Ø³ØªØ ØµØ±ÙØ§Ù Ø¨Ù ØµÙØ±Øª Ø±ÙØ§ÙØ Ú©Ø§Ø±Ø¨Ø±Ø¯Û Ù Ø¯Ø± Ø§ÙØ¯Ø§Ø²Ù ÙÙØ§Ù Ø§Ø·ÙØ§Ø¹Ø§Øª ÙÙØ¬ÙØ¯ Ø¨Ø§Ø²ÙÙÛØ³Û Ú©ÙÛØ¯.\n"
                    . "Û³. Ø§Ú¯Ø± Ø§Ø·ÙØ§Ø¹Ø§Øª Ù¾Ø§ÛÙ Ø¬Ø§ÙØ¹ Ø§Ø³ØªØ Ø¢Ù Ø±Ø§ Ø¨Ø§ ØªÛØªØ±ÙØ§Û Ø¬Ø°Ø§Ø¨ H2 Ù H3Ø ÙÚ©Ø§Øª Ú©ÙÛØ¯Û Ù Ø¯Ø³ØªÙâØ¨ÙØ¯Û ÙÙØ¸Ù Ø³Ø§Ø®ØªØ§Ø±Ø¯ÙÛ Ú©ÙÛØ¯.\n"
                    . "Û´. Ø§Ú©ÛØ¯Ø§Ù Ø§ÛÙ Ø¨Ø±ÙØ¯ Ø±Ø§ Ø¨Ø§ Ø¨Ø±ÙØ¯ÙØ§Û ÙØ´Ø§Ø¨Ù Ø¯Ø± ØµÙØ§ÛØ¹ Ø¯ÛÚ¯Ø± Ø§Ø´ØªØ¨Ø§Ù ÙÚ¯ÛØ±ÛØ¯.\n"
                    . "Ûµ. Ø¨Ù ÙÛÚ Ø¹ÙÙØ§Ù ÙØ§Ù Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§ Ø°Ú©Ø± ÙØ´ÙØ¯Ø ÙØ±Ø¬Ø¹ Ø¨Ø±Ø±Ø³Û Ù Ø®Ø±ÛØ¯ Â«{site_name}Â» Ø§Ø³Øª.\n"
                    . "Ø®Ø±ÙØ¬Û Ø±Ø§ Ø¯Ø± ÙØ§ÙØ¨ Ú©Ø¯ÙØ§Û HTML Ø§Ø³ØªØ§ÙØ¯Ø§Ø±Ø¯ Ù Ø´Ú©ÛÙ (Ø¨Ø§ ØªÚ¯âÙØ§Û <h2>Ø <h3>Ø <p>Ø <ul>Ø <li>) Ø¨Ø¯ÙÙ ØªÚ¯âÙØ§Û Ø§Ø¶Ø§ÙÛ html Ù body Ø¨Ø±Ú¯Ø±Ø¯Ø§ÙÛØ¯.";

    $val = get_option('evazar_ai_brand_prompt_v4', '');
    if (empty($val)) $val = $default_prompt;
    echo '<textarea name="evazar_ai_brand_prompt_v4" style="width: 100%; max-width: 800px; height: 210px;">' . esc_textarea($val) . '</textarea>';
    echo '<p class="description">ÙØªØºÛØ±ÙØ§Û Ù¾ÙÛØ§: <code>{term_name}</code> (ÙØ§Ù Ø¨Ø±ÙØ¯)Ø <code>{source_content}</code> (ÙØªÙ Ø§Ø³ØªØ®Ø±Ø§Ø¬ Ø´Ø¯Ù Ø§Ø² Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§)Ø <code>{site_name}</code> (ÙØ§Ù Ø³Ø§ÛØª).</p>';
}

function evazar_product_title_template_render()
{
    $default = 'ÙÛÙØª Ù Ø®Ø±ÛØ¯ {title} | {site_name}';
    $val = get_option('evazar_product_title_template', $default);
    echo '<input type="text" name="evazar_product_title_template" value="' . esc_attr($val) . '" style="width: 100%; max-width: 650px;" placeholder="' . esc_attr($default) . '">';
    echo '<p class="description" style="margin-top: 8px; line-height: 1.8;">';
    echo '<strong>ÙØªØºÛØ±ÙØ§Û ÙØ¬Ø§Ø² (Ø¨Ø§ Ú©ÙÛÚ© Ú©Ù¾Û ÙÛâØ´ÙÙØ¯):</strong><br>';
    echo '<code style="background:#e0f2fe; color:#0369a1; padding:2px 6px; border-radius:4px; cursor:pointer;" onclick="navigator.clipboard.writeText(\'{title}\'); alert(\'Ú©Ù¾Û Ø´Ø¯: {title}\');">{title}</code> (ÙØ§Ù Ú©Ø§ÙÙ Ú©Ø§ÙØ§) Ø ';
    echo '<code style="background:#e0f2fe; color:#0369a1; padding:2px 6px; border-radius:4px; cursor:pointer;" onclick="navigator.clipboard.writeText(\'{site_name}\'); alert(\'Ú©Ù¾Û Ø´Ø¯: {site_name}\');">{site_name}</code> (ÙØ§Ù Ø³Ø§ÛØª: Ø§ÛÙØ§Ø²Ø§Ø±) Ø ';
    echo '<code style="background:#e0f2fe; color:#0369a1; padding:2px 6px; border-radius:4px; cursor:pointer;" onclick="navigator.clipboard.writeText(\'{brand}\'); alert(\'Ú©Ù¾Û Ø´Ø¯: {brand}\');">{brand}</code> (Ø¨Ø±ÙØ¯ Ú©Ø§ÙØ§) Ø ';
    echo '<code style="background:#e0f2fe; color:#0369a1; padding:2px 6px; border-radius:4px; cursor:pointer;" onclick="navigator.clipboard.writeText(\'{category}\'); alert(\'Ú©Ù¾Û Ø´Ø¯: {category}\');">{category}</code> (Ø¯Ø³ØªÙâØ¨ÙØ¯Û) Ø ';
    echo '<code style="background:#e0f2fe; color:#0369a1; padding:2px 6px; border-radius:4px; cursor:pointer;" onclick="navigator.clipboard.writeText(\'{price}\'); alert(\'Ú©Ù¾Û Ø´Ø¯: {price}\');">{price}</code> (ÙÛÙØª ÙØ¹ÙÛ Ú©Ø§ÙØ§ Ø¨Ù ØªÙÙØ§Ù)';
    echo '</p>';
    echo '<p class="description" style="color: #64748b; font-size: 12px; line-height: 1.7; background: #f8fafc; border: 1px dashed #cbd5e1; padding: 10px; border-radius: 6px;">';
    echo '<strong>Ø§ÙÚ¯ÙÙØ§Û Ù¾ÛØ´ÙÙØ§Ø¯Û Ù¾Ø±Ú©Ø§Ø±Ø¨Ø±Ø¯:</strong><br>';
    echo 'â¢ <code>ÙÛÙØª Ù Ø®Ø±ÛØ¯ {title} | {site_name}</code> (ÙØ´Ø§Ø¨Ù Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§ Ù Ø¨ÛØ´ØªØ±ÛÙ ÙØ±Ø® Ú©ÙÛÚ© Ø®Ø±ÛØ¯ Ú©Ø§Ø±Ø¨Ø±Ø§Ù)<br>';
    echo 'â¢ <code>{title} - Ø¨Ø±Ø±Ø³ÛØ ÙØ´Ø®ØµØ§Øª Ù ÙÛÙØª Ø±ÙØ² | {site_name}</code> (ÙØ¯Ù ÙØ±Ø¬Ø¹ Ø¨Ø±Ø±Ø³Û ØªØ®ØµØµÛ Ú©Ø§ÙØ§)<br>';
    echo 'â¢ <code>Ø®Ø±ÛØ¯ {title} Ø¨Ø§ ØªØ¶ÙÛÙ Ø§ØµØ§ÙØª Ù Ø¨ÙØªØ±ÛÙ ÙÛÙØª | {site_name}</code>';
    echo '</p>';
}

function evazar_product_desc_template_render()
{
    $default = 'ÙÛÙØª Ù Ø®Ø±ÛØ¯ Ø¢ÙÙØ§ÛÙ {title} Ø¨Ø§ Ø¨ÙØªØ±ÛÙ ÙÛÙØª Ø±ÙØ² Ù ÙØ´Ø®ØµØ§Øª Ø¯Ø± {site_name}. ÙÙØ¯ Ù Ø¨Ø±Ø±Ø³Û Ù Ø¶ÙØ§ÙØª Ø§ØµØ§ÙØª Ú©Ø§ÙØ§.';
    $val = get_option('evazar_product_desc_template', $default);
    echo '<textarea name="evazar_product_desc_template" style="width: 100%; max-width: 650px; height: 60px;" placeholder="' . esc_attr($default) . '">' . esc_textarea($val) . '</textarea>';
    echo '<p class="description">Ø§ÛÙ ÙØªÙ Ø²ÙØ§ÙÛ Ú©Ù ÙÙØ´ ÙØµÙÙØ¹Û ØªÙØ¶ÛØ­Ø§Øª ÙØªØ§Û ÛÙÙÛÚ© ØªÙÙÛØ¯ ÙÚ©Ø±Ø¯Ù Ø¨Ø§Ø´Ø¯ ÛØ§ ÙÛÙØ¯ ÙØªØ§ Ø®Ø§ÙÛ Ø¨Ø§Ø´Ø¯ Ø¨Ù Ú©Ø§Ø± ÙÛâØ±ÙØ¯. ÙØªØºÛØ±ÙØ§Û <code>{title}</code>Ø <code>{site_name}</code>Ø <code>{brand}</code>Ø <code>{category}</code> Ù <code>{price}</code> Ù¾Ø´ØªÛØ¨Ø§ÙÛ ÙÛâØ´ÙÙØ¯.</p>';
}

function evazar_core_settings_page()
{
?>
    <div class="wrap" style="direction: rtl;">
        <h1>ØªÙØ¸ÛÙØ§Øª ÙØ³ØªÙ Ø§ÙÛÙÛØª Ø§ÛÙØ§Ø²Ø§Ø±</h1>
        <form action="options.php" method="post">
            <?php
            settings_fields('evazar_core_settings_group');
            do_settings_sections('evazar-affiliate-settings');
            submit_button('Ø°Ø®ÛØ±Ù ØªØºÛÛØ±Ø§Øª');
            ?>
        </form>
        
        <?php do_action('evazar_core_settings_page_bottom'); ?>
    </div>
<?php
}

// ==========================================
// 3. Ø§ÙØ²ÙØ¯Ù ÙØªØ§Ø¨Ø§Ú©Ø³âÙØ§Û Ø§Ø®ØªØµØ§ØµÛ Ø¨Ù ØµÙØ­Ù Ú©Ø§ÙØ§
// ==========================================
add_action('add_meta_boxes', 'evazar_core_add_product_metaboxes');
function evazar_core_add_product_metaboxes()
{
    add_meta_box(
        'evazar_product_data',
        'Ø§Ø·ÙØ§Ø¹Ø§Øª Ø§Ø®ØªØµØ§ØµÛ Ú©Ø§ÙØ§ (ÙÛÙØªØ Ø§ÙÛÙÛØª Ù Ø¨Ø±Ø±Ø³Û)',
        'evazar_core_product_metabox_html',
        'evazar_product', // ÙØªØµÙ ÙÙØ· Ø¨Ù Ù¾Ø³ØªâØªØ§ÛÙ¾ Ø§Ø®ØªØµØ§ØµÛ ÙØ§
        'normal',
        'high'
    );
}

function evazar_core_product_metabox_html($post)
{
    // ÙÛÙØªâÙØ§
    $old_price = get_post_meta($post->ID, '_evazar_old_price', true);
    $current_price = get_post_meta($post->ID, '_evazar_current_price', true);
    $discount_percent = get_post_meta($post->ID, '_evazar_discount_percent', true);

    // ÙÛÙÚ© Ù Ø¯ÛØªØ§
    $dk_url = get_post_meta($post->ID, '_evazar_dk_url', true);
    $rating = get_post_meta($post->ID, '_evazar_rating', true);
    $rating_count = get_post_meta($post->ID, '_evazar_rating_count', true);
    $satisfaction = get_post_meta($post->ID, '_evazar_satisfaction', true);
    $en_title = get_post_meta($post->ID, '_evazar_en_title', true);

    // Ø¯Ø§Ø¯ÙâÙØ§Û Ø³Ø¦Ù Ø±ÙÚ©âÙØ« (Rank Math SEO)
    $rm_title = get_post_meta($post->ID, 'rank_math_title', true);
    $rm_desc  = get_post_meta($post->ID, 'rank_math_description', true);
    $rm_kw    = get_post_meta($post->ID, 'rank_math_focus_keyword', true);

    // ÙØ­ØªÙØ§
    $pros = get_post_meta($post->ID, '_evazar_pros', true);
    $cons = get_post_meta($post->ID, '_evazar_cons', true);
    $features = get_post_meta($post->ID, '_evazar_key_features', true);

    // ØªØµØ§ÙÛØ± Ú©Ø§ÙØ§
    $main_img = get_post_meta($post->ID, '_evazar_main_image', true);
    $gallery_raw = get_post_meta($post->ID, '_evazar_gallery', true);
    $gallery = !empty($gallery_raw) ? (is_array($gallery_raw) ? $gallery_raw : explode(',', $gallery_raw)) : [];

    wp_nonce_field('evazar_product_save_nonce', 'evazar_nonce');
?>
    <style>
        .evazar-mb-row {
            margin-bottom: 15px;
        }

        .evazar-mb-row label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .evazar-mb-row input[type="text"],
        .evazar-mb-row textarea {
            width: 100%;
            max-width: 100%;
        }

        .evazar-mb-row textarea {
            height: 80px;
        }

        .evazar-mb-desc {
            font-size: 12px;
            color: #666;
            margin-top: 4px;
        }

        .evazar-grid-3 {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 20px;
        }

        .evazar-grid-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
    </style>

    <div class="evazar-mb-row" style="background: #f8fafc; padding: 15px; border-radius: 8px; border: 1px solid #e2e8f0;">
        <label style="color: #0f172a; margin-bottom: 8px; display: flex; align-items: center; justify-content: space-between;">
            <span>ð¸ ØªØµØ§ÙÛØ± Ú©Ø§ÙØ§ (ÙØ¹ÙØ§Ø±Û Ø°Ø®ÛØ±ÙâØ³Ø§Ø²Û ØµÙØ± ÙØ§Ø³Øª - Zero Host Storage)</span>
            <span style="font-size: 11px; background: #dcfce7; color: #166534; padding: 2px 8px; border-radius: 12px; font-weight: 600;">â¡ Ø¨Ø¯ÙÙ ÙØµØ±Ù ÙØ¶Ø§Û ÙØ§Ø³Øª</span>
        </label>
        <p class="evazar-mb-desc" style="margin-bottom: 10px; color: #475569;">ØªØµØ§ÙÛØ± Ø¨Ù ØµÙØ±Øª ÙØ³ØªÙÛÙ Ø§Ø² Ø´Ø¨Ú©Ù ØªÙØ²ÛØ¹ ÙØ­ØªÙØ§Û Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§ (CDN) ÙÙØ¯ ÙÛâØ´ÙÙØ¯ Ù ÙÛÚ ÙØ§ÛÙ ØªØµÙÛØ±Û Ø±ÙÛ ÙØ§Ø³Øª Ø´ÙØ§ Ø°Ø®ÛØ±Ù ÙÙÛâØ´ÙØ¯.</p>
        <div style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap; margin-bottom: 10px;">
            <?php if (!empty($main_img)): ?>
                <div style="text-align: center;">
                    <img src="<?php echo esc_url($main_img); ?>" style="width: 80px; height: 80px; object-fit: contain; border-radius: 8px; border: 2px solid #ef394e; background: #fff;" loading="lazy">
                    <div style="font-size: 10px; color: #ef394e; font-weight: bold; margin-top: 3px;">ØªØµÙÛØ± Ø§ØµÙÛ</div>
                </div>
            <?php endif; ?>
            <?php foreach ($gallery as $g_img):
                $g_img = trim($g_img);
                if (empty($g_img) || $g_img === $main_img) continue;
            ?>
                <div style="text-align: center;">
                    <img src="<?php echo esc_url($g_img); ?>" style="width: 70px; height: 70px; object-fit: contain; border-radius: 8px; border: 1px solid #cbd5e1; background: #fff;" loading="lazy">
                    <div style="font-size: 10px; color: #64748b; margin-top: 3px;">Ú¯Ø§ÙØ±Û</div>
                </div>
            <?php endforeach; ?>
            <?php if (empty($main_img) && empty($gallery)): ?>
                <span style="color: #94a3b8; font-size: 13px;">ØªØµÙÛØ±Û Ø¨Ø±Ø§Û Ø§ÛÙ Ú©Ø§ÙØ§ Ø«Ø¨Øª ÙØ´Ø¯Ù Ø§Ø³Øª.</span>
            <?php endif; ?>
        </div>
        <div>
            <label style="font-size: 12px; color: #475569;">Ø¢Ø¯Ø±Ø³ ÙØ³ØªÙÛÙ CDN ØªØµÙÛØ± Ø§ØµÙÛ:</label>
            <input type="text" name="evazar_main_image" value="<?php echo esc_attr($main_img); ?>" placeholder="https://dkstatics-public.digikala.com/..." dir="ltr" style="font-size: 11px;">
        </div>
    </div>

    <div class="evazar-mb-row">
        <label>ÙÛÙÚ© Ø³Ø§Ø¯Ù Ú©Ø§ÙØ§ Ø¯Ø± Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§ (ÙÙØ¨Ø¹ Ú©Ø§ÙØ§):</label>
        <input type="text" name="evazar_dk_url" value="<?php echo esc_attr($dk_url); ?>" placeholder="https://www.digikala.com/product/dkp-12345/" dir="ltr">
    </div>

    <div class="evazar-mb-row">
        <label>Ø¹ÙÙØ§Ù Ø§ÙÚ¯ÙÛØ³Û Ú©Ø§ÙØ§ (Ø²ÛØ±ØªÛØªØ±):</label>
        <input type="text" name="evazar_en_title" value="<?php echo esc_attr($en_title); ?>" placeholder="Apple iPhone 13 Pro Max" dir="ltr">
    </div>

    <div class="evazar-grid-3 evazar-mb-row">
        <div>
            <label>ÙÛÙØª Ø§ØµÙÛ (ØªÙÙØ§Ù - Ø§Ø®ØªÛØ§Ø±Û):</label>
            <input type="text" name="evazar_old_price" value="<?php echo esc_attr($old_price); ?>" placeholder="ÙØ«ÙØ§: 10,000,000">
        </div>
        <div>
            <label>ÙÛÙØª ÙÙØ§ÛÛ Ø¨Ø§ ØªØ®ÙÛÙ (ØªÙÙØ§Ù):</label>
            <input type="text" name="evazar_current_price" value="<?php echo esc_attr($current_price); ?>" placeholder="ÙØ«ÙØ§: 8,500,000">
        </div>
        <div>
            <label>Ø¨Ø¬ ØªØ®ÙÛÙ (Ø¯Ø±ØµØ¯ ÛØ§ ÙØªÙ):</label>
            <input type="text" name="evazar_discount_percent" value="<?php echo esc_attr($discount_percent); ?>" placeholder="ÙØ«ÙØ§: Û±ÛµÙª ØªØ®ÙÛÙ">
        </div>
    </div>

    <div class="evazar-grid-3 evazar-mb-row" style="display:grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px;">
        <div>
            <label>Ø§ÙØªÛØ§Ø² Ú©Ø§ÙØ§ (ÙØ«ÙØ§ Û´.Û´):</label>
            <input type="text" name="evazar_rating" value="<?php echo esc_attr($rating); ?>" placeholder="4.4">
        </div>
        <div>
            <label>ØªØ¹Ø¯Ø§Ø¯ Ø§ÙØªÛØ§Ø²Ø¯ÙÙØ¯Ú¯Ø§Ù / Ø®Ø±ÛØ¯Ø§Ø±Ø§Ù:</label>
            <input type="number" name="evazar_rating_count" value="<?php echo esc_attr($rating_count); ?>" placeholder="74">
        </div>
        <div>
            <label>Ø¯Ø±ØµØ¯ Ø±Ø¶Ø§ÛØª (ÙØ«ÙØ§ Û¹Û´Ùª):</label>
            <input type="text" name="evazar_satisfaction" value="<?php echo esc_attr($satisfaction); ?>" placeholder="Û¹Û´Ùª">
        </div>
    </div>

    <div class="evazar-mb-row">
        <label>ÙÛÚÚ¯ÛâÙØ§Û Ú©ÙÛØ¯Û (ÙØ± ÙÛÚÚ¯Û Ø¯Ø± ÛÚ© Ø®Ø·):</label>
        <textarea name="evazar_key_features"><?php echo esc_textarea($features); ?></textarea>
    </div>

    <div class="evazar-mb-row">
        <label>ÙÛÚÚ¯ÛâÙØ§ Ù ÙÙØ§Ø· ÙÙØª Ú©ÙÛØ¯Û Ú©Ø§ÙØ§ (Highlights & Pros) - ÙØ± ÙÙØ±Ø¯ ÛÚ© Ø®Ø·:</label>
        <textarea name="evazar_pros" style="height: 100px;"><?php echo esc_textarea($pros); ?></textarea>
        <input type="hidden" name="evazar_cons" value="">
    </div>

    <!-- Ø¨Ø®Ø´ Ø§Ø®ØªØµØ§ØµÛ Ø³Ø¦Ù Ù Ø±ÙÚ©âÙØ« -->
    <div class="evazar-mb-row" style="background: #f0fdf4; padding: 16px; border-radius: 8px; border: 1px solid #bbf7d0; margin-top: 15px;">
        <label style="color: #166534; margin-bottom: 8px; display: flex; align-items: center; justify-content: space-between;">
            <span>ð ØªÙØ¸ÛÙØ§Øª Ø³Ø¦Ù Ù ÙØªØ§Ø¯ÛØªØ§ÙØ§Û Ø±ÙÚ©âÙØ« (Rank Math Integration)</span>
            <span style="font-size: 11px; background: #22c55e; color: #fff; padding: 2px 8px; border-radius: 12px; font-weight: 600;">ÙÙÚ¯Ø§Ù Ø¨Ø§ Rank Math</span>
        </label>
        <p class="evazar-mb-desc" style="margin-bottom: 12px; color: #15803d; font-size: 12px;">
            Ø§ÛÙ ÙÛÙØ¯ÙØ§ ÙØ³ØªÙÛÙØ§Ù Ø¨Ø§ Ø§ÙØ²ÙÙÙ Rank Math ÙÙÚ¯Ø§Ù ÙØ³ØªÙØ¯. Ø¯Ø± ØµÙØ±Øª Ø®Ø§ÙÛ Ø¨ÙØ¯ÙØ Ø¨Ù Ø·ÙØ± Ø®ÙØ¯Ú©Ø§Ø± Ø§Ø² ÙÙØ´ ÙØµÙÙØ¹Û ÛØ§ ÙØ±ÙÙÙ Ø·ÙØ§ÛÛ Ø³Ø¦Ù Ø§Ø³ØªÙØ§Ø¯Ù ÙÛâØ´ÙØ¯.
        </p>

        <div style="margin-bottom: 12px;">
            <label style="font-size: 12px; color: #334155;">Ø¹ÙÙØ§Ù Ø§Ø®ØªØµØ§ØµÛ Ø³Ø¦Ù Ø¯Ø± Ú¯ÙÚ¯Ù (Meta Title):</label>
            <input type="text" name="rank_math_title" value="<?php echo esc_attr($rm_title); ?>" placeholder="ÙØ«ÙØ§Ù: ÙÛÙØª Ù Ø®Ø±ÛØ¯ <?php echo esc_attr(get_the_title($post->ID)); ?> | <?php echo esc_attr(get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±'); ?>">
            <div class="evazar-mb-desc">Ø¯Ø± ØµÙØ±Øª Ø®Ø§ÙÛ Ø¨ÙØ¯ÙØ Ø¨Ù ØµÙØ±Øª Ø®ÙØ¯Ú©Ø§Ø± Ø§Ø² ÙØ±ÙÙÙ Ø¨ÙÛÙÙ Ø±ÙÚ©âÙØ« Ø§Ø³ØªÙØ§Ø¯Ù Ø®ÙØ§ÙØ¯ Ø´Ø¯.</div>
        </div>

        <div style="margin-bottom: 12px;">
            <label style="font-size: 12px; color: #334155;">ØªÙØ¶ÛØ­Ø§Øª ÙØªØ§Û Ø³Ø¦Ù (Meta Description - Ø­Ø¯Ø§Ú©Ø«Ø± Û±Û¶Û° Ú©Ø§Ø±Ø§Ú©ØªØ±):</label>
            <textarea name="rank_math_description" style="height: 65px;" placeholder="ØªÙØ¶ÛØ­Ø§Øª Ú©ÙØªØ§Ù Ù ØªØ±ØºÛØ¨âÚ©ÙÙØ¯Ù Ø³Ø¦Ù Ø¨Ø±Ø§Û ÙÙØ§ÛØ´ Ø¯Ø± ØµÙØ­Ù Ø¬Ø³ØªØ¬ÙÛ Ú¯ÙÚ¯Ù..."><?php echo esc_textarea($rm_desc); ?></textarea>
            <div class="evazar-mb-desc">Ø§ÛÙ ÙØªÙ ØªÙØ³Ø· ÙÙØ´ ÙØµÙÙØ¹Û ÛØ§ Ø¨Ù ØµÙØ±Øª ÙÙØ´ÙÙØ¯ Ù¾Ø± ÙÛâØ´ÙØ¯ Ù ÚØ±Ø§Øº Ø³Ø¦ÙÛ Ø±ÙÚ©âÙØ« Ø±Ø§ Ø³Ø¨Ø² ÙÛâÚ©ÙØ¯.</div>
        </div>

        <div>
            <label style="font-size: 12px; color: #334155;">Ú©ÙÙÙ Ú©ÙÛØ¯Û Ú©Ø§ÙÙÙÛ (Focus Keyword):</label>
            <input type="text" name="rank_math_focus_keyword" value="<?php echo esc_attr($rm_kw); ?>" placeholder="ÙØ«ÙØ§Ù: Ø®Ø±ÛØ¯ Ú¯ÙØ´Û Ø³Ø§ÙØ³ÙÙÚ¯ A55">
        </div>
    </div>
<?php
}

// Ø°Ø®ÛØ±Ù Ø¯Ø§Ø¯ÙâÙØ§Û ÙØªØ§Ø¨Ø§Ú©Ø³
add_action('save_post_evazar_product', 'evazar_core_save_product_metaboxes');
function evazar_core_save_product_metaboxes($post_id)
{
    if (!isset($_POST['evazar_nonce']) || !wp_verify_nonce($_POST['evazar_nonce'], 'evazar_product_save_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    $fields = [
        'evazar_dk_url',
        'evazar_en_title',
        'evazar_old_price',
        'evazar_current_price',
        'evazar_discount_percent',
        'evazar_rating',
        'evazar_rating_count',
        'evazar_satisfaction',
        'evazar_key_features',
        'evazar_pros',
        'evazar_cons',
        'evazar_main_image'
    ];

    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            if (in_array($field, ['evazar_key_features', 'evazar_pros', 'evazar_cons'])) {
                $value = sanitize_textarea_field($_POST[$field]);
            } else {
                $value = sanitize_text_field($_POST[$field]);
            }
            update_post_meta($post_id, '_' . $field, $value);
        }
    }

    // Ø°Ø®ÛØ±Ù ÙÛÙØ¯ÙØ§Û Ø¨ÙÙÛ Ø±ÙÚ©âÙØ« (Rank Math Native Meta Keys)
    if (isset($_POST['rank_math_title'])) {
        update_post_meta($post_id, 'rank_math_title', sanitize_text_field($_POST['rank_math_title']));
    }
    if (isset($_POST['rank_math_description'])) {
        update_post_meta($post_id, 'rank_math_description', sanitize_textarea_field($_POST['rank_math_description']));
    }
    if (isset($_POST['rank_math_focus_keyword'])) {
        update_post_meta($post_id, 'rank_math_focus_keyword', sanitize_text_field($_POST['rank_math_focus_keyword']));
    }
}


// ==========================================
// 4. ØµÙØ­Ù Ø§ÙØªÙØ§Ù Ø§ÙÛÙÛØª + Ø±ÙÚ¯ÛØ±Û Ú©ÙÛÚ©
// ==========================================
add_action('init', 'evazar_register_affiliate_redirect_route', 5);
function evazar_register_affiliate_redirect_route()
{
    add_rewrite_rule('^go/([0-9]+)/?$', 'index.php?evazar_aff_go=$matches[1]', 'top');
    if (get_option('evazar_affiliate_redirect_rewrite_v1') !== '1') {
        flush_rewrite_rules(false);
        update_option('evazar_affiliate_redirect_rewrite_v1', '1', false);
    }
}

add_filter('query_vars', function ($vars) {
    $vars[] = 'evazar_aff_go';
    return $vars;
});

function evazar_affiliate_click_table_name()
{
    global $wpdb;
    return $wpdb->prefix . 'evazar_affiliate_clicks';
}

function evazar_affiliate_click_table_install()
{
    global $wpdb;
    $table = evazar_affiliate_click_table_name();
    $charset = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS {$table} (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        product_id bigint(20) unsigned NOT NULL,
        seller varchar(100) NOT NULL DEFAULT 'Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§',
        click_date date NOT NULL,
        clicks bigint(20) unsigned NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY product_seller_day (product_id, seller, click_date),
        KEY click_date (click_date),
        KEY product_id (product_id)
    ) {$charset};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

function evazar_affiliate_click_table_maybe_install()
{
    if (get_option('evazar_affiliate_click_table_v1') === '1') return;
    evazar_affiliate_click_table_install();
    update_option('evazar_affiliate_click_table_v1', '1', false);
}
add_action('init', 'evazar_affiliate_click_table_maybe_install', 6);

function evazar_record_affiliate_click($post_id)
{
    $post_id = absint($post_id);
    if (!$post_id || get_post_type($post_id) !== 'evazar_product') return;

    global $wpdb;
    $table = evazar_affiliate_click_table_name();
    $seller = get_post_meta($post_id, '_evazar_seller_name', true) ?: 'Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§';
    $seller = mb_substr(sanitize_text_field($seller), 0, 100);
    $date = current_time('Y-m-d');

    // ÛÚ© Ø±Ø¯ÛÙ Ø¨Ø±Ø§Û ÙØ± ÙØ­ØµÙÙ/ÙØ±ÙØ´ÙØ¯Ù/Ø±ÙØ²Ø ÙÙØ§Ø³Ø¨ Ø¨Ø±Ø§Û ØªØ±Ø§ÙÛÚ© Ø¨Ø§ÙØ§ Ù Ø¨Ø¯ÙÙ Ø°Ø®ÛØ±Ù IP.
    $sql = $wpdb->prepare(
        "INSERT INTO {$table} (product_id, seller, click_date, clicks) VALUES (%d, %s, %s, 1)
         ON DUPLICATE KEY UPDATE clicks = clicks + 1",
        $post_id, $seller, $date
    );
    $wpdb->query($sql);
}

function evazar_affiliate_redirect_countdown_enabled()
{
    return get_option('evazar_affiliate_redirect_countdown_enabled', '1') === '1';
}

function evazar_affiliate_redirect_delay()
{
    $delay = (int) get_option('evazar_affiliate_redirect_delay', 2);
    return max(1, min(5, $delay));
}

function evazar_affiliate_redirect_font_config()
{
    $font = get_option('evazar_opt_font', 'vazirmatn');
    switch ($font) {
        case 'yekanbakh':
            return [
                'family' => "'YekanBakh', sans-serif",
                'file'   => '/assets/fonts/yekanbakh/YekanBakhFaNum-Regular.woff2',
            ];
        case 'system':
            return [
                'family' => "system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Tahoma,Arial,sans-serif",
                'file'   => '',
            ];
        case 'vazirmatn':
        default:
            return [
                'family' => "'Vazirmatn', sans-serif",
                'file'   => '/assets/fonts/vazirmatn/VazirmatnVF.woff2',
            ];
    }
}

function evazar_affiliate_redirect_output($post_id, $target_url)
{
    $delay = evazar_affiliate_redirect_delay();
    $title = get_option('evazar_affiliate_redirect_title', 'Ø¯Ø± Ø­Ø§Ù Ø§ÙØªÙØ§Ù Ø¨Ù Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§');
    $description = get_option('evazar_affiliate_redirect_description', 'ÙÛÙÚ© Ø®Ø±ÛØ¯ Ø´ÙØ§ Ø¢ÙØ§Ø¯Ù Ø§Ø³ØªØ ØªØ§ ÚÙØ¯ ÙØ­Ø¸Ù Ø¯ÛÚ¯Ø± Ø¨Ù Ø³Ø§ÛØª ÙØ±ÙØ´ÙØ¯Ù ÙÙØªÙÙ ÙÛâØ´ÙÛØ¯.');
    $button = get_option('evazar_affiliate_redirect_button', 'Ø§ÙØªÙØ§Ù ÙÙØ±Û');
    $seller = get_post_meta($post_id, '_evazar_seller_name', true) ?: 'Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§';
    $seller = sanitize_text_field($seller);
    $font = evazar_affiliate_redirect_font_config();
    $theme_version = wp_get_theme()->get('Version');
    $theme_uri = get_stylesheet_directory_uri();
    $font_file_url = !empty($font['file']) ? get_theme_file_uri(ltrim($font['file'], '/')) : '';
    $fonts_css_url = get_theme_file_uri('assets/css/fonts.css');
    $primary = get_option('evazar_opt_primary_color', '#ef394e');
    if (!is_string($primary) || !preg_match('/^#[0-9a-fA-F]{6}$/', $primary)) $primary = '#ef394e';

    $target = esc_url($target_url);
    $title_esc = esc_html($title);
    $description_esc = esc_html($description);
    $button_esc = esc_html($button);
    $seller_esc = esc_html($seller);
    $delay_ms = $delay * 1000;
    $redirect_json = wp_json_encode($target_url, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $delay_json = wp_json_encode($delay_ms);
    $font_family_json = wp_json_encode($font['family']);
    $persian_digits = ['Û°','Û±','Û²','Û³','Û´','Ûµ','Û¶','Û·','Û¸','Û¹'];
    $delay_fa = strtr((string) $delay, ['0'=>'Û°','1'=>'Û±','2'=>'Û²','3'=>'Û³','4'=>'Û´','5'=>'Ûµ','6'=>'Û¶','7'=>'Û·','8'=>'Û¸','9'=>'Û¹']);

    status_header(200);
    nocache_headers();
    header('X-Robots-Tag: noindex, nofollow, noarchive', true);
    header('Referrer-Policy: strict-origin-when-cross-origin', true);
    header('Content-Security-Policy: default-src \'none\'; style-src \'self\' \'unsafe-inline\'; script-src \'unsafe-inline\'; font-src \'self\' data:; img-src \'self\' data:; base-uri \'none\'; frame-ancestors \'none\';', true);

    echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">';
    echo '<meta name="color-scheme" content="light">';
    echo '<meta http-equiv="refresh" content="' . esc_attr($delay) . ';url=' . esc_attr($target) . '">';
    echo '<title>' . $title_esc . ' | Ø§ÛÙØ§Ø²Ø§Ø±</title>';
    if (!empty($font['file'])) {
        echo '<link rel="preload" href="' . esc_url($theme_uri . $font['file']) . '?ver=' . rawurlencode($theme_version) . '" as="font" type="font/woff2" crossorigin="anonymous">';
    }
    echo '<link rel="stylesheet" href="' . esc_url($fonts_css_url) . '?ver=' . rawurlencode($theme_version) . '">';

    $redirect_css = ':root{--evz-primary:' . $primary . ';--evz-font:' . $font['family'] . ';--evz-duration:' . esc_attr($delay_ms) . 'ms}'
        . '*{box-sizing:border-box}'
        . 'html{direction:rtl;text-align:right}'
        . 'body{direction:rtl;text-align:right;unicode-bidi:plaintext}'
        . 'html,body{margin:0;min-width:0;min-height:100%;width:100%;font-family:var(--evz-font),sans-serif;background:#f8fafc;color:#0f172a}'
        . 'body{min-height:100svh;display:flex;align-items:center;justify-content:center;padding:clamp(16px,4vw,32px);overflow-x:hidden}'
        . '.evz-redirect{width:min(100%,560px);background:#fff;border:1px solid #e2e8f0;border-radius:clamp(16px,4vw,24px);box-shadow:0 18px 45px rgba(15,23,42,.08);padding:clamp(22px,5vw,34px) clamp(18px,5vw,30px);text-align:center;overflow:hidden}'
        . '.evz-logo{width:clamp(52px,14vw,62px);height:clamp(52px,14vw,62px);margin:0 auto 16px;border-radius:18px;background:#fff1f2;color:var(--evz-primary);display:flex;align-items:center;justify-content:center}'
        . '.evz-logo svg{width:clamp(27px,8vw,32px);height:clamp(27px,8vw,32px)}'
        . '.evz-title{font-size:clamp(18px,4.8vw,24px);line-height:1.6;font-weight:800;margin:0 0 10px;overflow-wrap:anywhere}'
        . '.evz-desc{font-size:clamp(13px,3.6vw,15px);line-height:2;color:#64748b;margin:0 auto 16px;max-width:440px;overflow-wrap:anywhere}'
        . '.evz-seller{display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:7px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:999px;padding:8px 12px;font-size:clamp(11px,3.1vw,12px);color:#475569;margin:0 auto 20px;max-width:100%;overflow-wrap:anywhere}'
        . '.evz-count-wrap{display:flex;align-items:center;justify-content:center;min-height:clamp(56px,15vw,72px)}'
        . '.evz-count{font-size:clamp(46px,13vw,66px);line-height:1;font-weight:900;color:var(--evz-primary);margin:2px 0 14px}'
        . '.evz-progress{height:7px;background:#f1f5f9;border-radius:999px;overflow:hidden;margin:0 0 20px;direction:rtl;position:relative;transform:translateZ(0)}'
        . '.evz-progress>i{display:block;position:absolute;inset-block:0;inset-inline-start:0;width:0;height:100%;background:var(--evz-primary);animation:evzGrow var(--evz-duration) linear forwards}'
        . '.evz-btn{display:flex;align-items:center;justify-content:center;width:100%;min-height:46px;padding:12px 18px;background:var(--evz-primary);color:#fff;text-decoration:none;border:0;border-radius:12px;font-size:clamp(13px,3.8vw,15px);font-weight:800;line-height:1.4;touch-action:manipulation;transition:transform .15s ease,filter .15s ease}'
        . '.evz-btn:hover{filter:brightness(.95);transform:translateY(-1px)}.evz-btn:focus-visible{outline:3px solid rgba(2,132,199,.25);outline-offset:3px}'
        . '.evz-note{font-size:clamp(10px,2.9vw,12px);line-height:1.8;color:#94a3b8;margin-top:13px;overflow-wrap:anywhere}'
        . '@keyframes evzGrow{from{width:0}to{width:100%}}'
        . '@media(max-width:380px){body{padding:10px}.evz-redirect{padding:20px 14px;border-radius:16px}.evz-seller{border-radius:14px}.evz-btn{min-height:48px}}'
        . '@media(prefers-reduced-motion:reduce){.evz-progress>i{animation:none;width:100%}.evz-btn{transition:none}}';
    echo '<style>' . $redirect_css . '</style></head><body>';
    echo '<main class="evz-redirect" aria-labelledby="evz-title">';
    echo '<div class="evz-logo" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l7 4v5c0 4.4-3 8.5-7 9-4-.5-7-4.6-7-9V7l7-4z"/><path d="M9.5 12l1.8 1.8L15 10"/></svg></div>';
    echo '<h1 class="evz-title" id="evz-title">' . $title_esc . '</h1>';
    echo '<p class="evz-desc">' . $description_esc . '</p>';
    echo '<div class="evz-seller"><span>ÙØ±ÙØ´ÙØ¯Ù:</span><strong>' . $seller_esc . '</strong></div>';
    echo '<div class="evz-count-wrap"><div class="evz-count" id="evz-count" dir="rtl" aria-label="Ø«Ø§ÙÛÙ Ø¨Ø§ÙÛâÙØ§ÙØ¯Ù" aria-live="polite" aria-atomic="true">' . esc_html($delay_fa) . '</div></div>';
    echo '<div class="evz-progress" aria-hidden="true"><i></i></div>';
    echo '<a class="evz-btn" id="evz-now" href="' . $target . '">' . $button_esc . '</a>';
    echo '<div class="evz-note">Ø´ÙØ§ Ø¨Ø±Ø§Û ØªÚ©ÙÛÙ Ø®Ø±ÛØ¯ Ø¨Ù Ø³Ø§ÛØª ÙØ±ÙØ´ÙØ¯Ù ÙÙØªÙÙ ÙÛâØ´ÙÛØ¯.</div>';
    echo '</main>';
    echo '<script>(function(){var t=' . $delay_json . ',u=' . $redirect_json . ',c=document.getElementById("evz-count"),a=document.getElementById("evz-now");function toFa(v){return String(v).replace(/[0-9]/g,function(d){return "Û°Û±Û²Û³Û´ÛµÛ¶Û·Û¸Û¹"[Number(d)]});}if(a)a.addEventListener("click",function(){window.location.replace(u)});var end=Date.now()+t;function tick(){var left=Math.max(0,end-Date.now()),sec=Math.ceil(left/1000);if(c)c.textContent=toFa(sec);if(left<=0){window.location.replace(u);return}setTimeout(tick,100)}tick();})();</script>';
    echo '</body></html>';
    exit;
}

add_action('template_redirect', 'evazar_handle_affiliate_redirect', 1);
function evazar_handle_affiliate_redirect()
{
    $post_id = absint(get_query_var('evazar_aff_go'));
    if (!$post_id) return;
    if (get_post_type($post_id) !== 'evazar_product' || get_post_status($post_id) !== 'publish') {
        status_header(404);
        nocache_headers();
        wp_safe_redirect(home_url('/'), 302);
        exit;
    }

    $target = evazar_get_final_affiliate_link($post_id);
    if (empty($target)) {
        $target = get_post_meta($post_id, '_evazar_dk_url', true);
    }
    if (empty($target)) {
        $target = home_url('/');
    }

    evazar_record_affiliate_click($post_id);
    if (!evazar_affiliate_redirect_countdown_enabled()) {
        $redirect_target = esc_url_raw($target);
        $parsed = wp_parse_url($redirect_target);
        if (!empty($parsed['scheme']) && in_array(strtolower($parsed['scheme']), ['http', 'https'], true)) {
            wp_redirect($redirect_target, 302, 'Evazar Affiliate');
            exit;
        }
    }
    evazar_affiliate_redirect_output($post_id, $target);
}

function evazar_get_affiliate_redirect_url($post_id = null)
{
    if (!$post_id) $post_id = get_the_ID();
    $post_id = absint($post_id);
    if (!$post_id || get_post_type($post_id) !== 'evazar_product') return '';
    return home_url('/go/' . $post_id . '/');
}

// ==========================================
// 4. ØªØ§Ø¨Ø¹ Ú©ÙÚ©Û ØªÙÙÛØ¯ ÙÛÙÚ© ÙÙØ§ÛÛ Ø§ÙÛÙÛØª
// ==========================================
function evazar_get_final_affiliate_link($post_id = null)
{
    if (!$post_id) $post_id = get_the_ID();
    $base_link = get_option('evazar_base_affiliate_link', '');
    $dk_url = get_post_meta($post_id, '_evazar_dk_url', true);

    if (empty($dk_url)) $dk_url = 'https://www.digikala.com/';
    if (empty($base_link) || strpos($base_link, '{redirect_to}') === false) return $dk_url;

    return str_replace('{redirect_to}', urlencode($dk_url), $base_link);
}

/**
 * ØªØ¨Ø¯ÛÙ Ø¢Ø¯Ø±Ø³ ØªØµÙÛØ± Ø¨Ù CDN Ú©ÙÙØ¯ÙÙØ± Ù Ø³Ø§Ø®Øª ÙØ³Ø®Ù Ø§ÙØ¯Ø§Ø²ÙâÚ¯Ø°Ø§Ø±ÛâØ´Ø¯Ù Ø¨Ø¯ÙÙ Ø°Ø®ÛØ±Ù ÙØ§ÛÙ Ø±ÙÛ ÙØ§Ø³Øª.
 */
if (!function_exists('evazar_cdn_image_url')) {
    function evazar_cdn_image_url($url, $size = null)
    {
        if (empty($url) || !is_string($url)) return '';

        $original_url = $url;
        $cdn_host = rtrim(trim(get_option('evazar_image_cdn_domain', 'https://img.evazar.ir')), '/');
        $is_digikala_image = stripos($url, 'dkstatics-public.digikala.com') !== false;
        $is_evazar_cdn = ($cdn_host !== '' && stripos($url, $cdn_host) === 0);

        if ($is_digikala_image && $cdn_host !== '') {
            $url = str_replace(
                ['https://dkstatics-public.digikala.com', 'http://dkstatics-public.digikala.com'],
                $cdn_host,
                $url
            );
            $is_evazar_cdn = true;
        }

        $size = is_numeric($size) ? absint($size) : 0;
        if ($size > 0 && $size <= 2000 && $is_evazar_cdn) {
            $parts = wp_parse_url($url);
            if (is_array($parts) && !empty($parts['host'])) {
                $query = [];
                if (!empty($parts['query'])) {
                    parse_str($parts['query'], $query);
                }
                // Preserve an existing OSS transformation so archive/product visuals do not change.
                // Only add our size variant when the source URL has no x-oss-process directive.
                if (empty($query['x-oss-process'])) {
                    $query['x-oss-process'] = 'image/resize,m_lfit,h_' . $size . ',w_' . $size;
                }
                $encoded_query = http_build_query($query, '', '&', PHP_QUERY_RFC3986);
                $scheme = !empty($parts['scheme']) ? $parts['scheme'] . '://' : '';
                $host = $parts['host'];
                $port = !empty($parts['port']) ? ':' . $parts['port'] : '';
                $path = isset($parts['path']) ? $parts['path'] : '';
                $fragment = !empty($parts['fragment']) ? '#' . $parts['fragment'] : '';
                $url = $scheme . $host . $port . $path . ($encoded_query !== '' ? '?' . $encoded_query : '') . $fragment;
            }
        }

        return $url ?: $original_url;
    }
}

/**
 * Failover ØªØµØ§ÙÛØ± Ø§ÛÙØ§Ø²Ø§Ø± Ø¯Ø± Ø³ÙØª ÙØ±ÙØ±Ú¯Ø±.
 *
 * ÙØ³ÛØ± Ø¹Ø§Ø¯Û: img.evazar.ir -> Cloudflare Worker -> CDN Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§
 * Ø¯Ø± ØµÙØ±Øª Ø´Ú©Ø³Øª ÙØ³ÛØ± CDN Ø§ÛÙØ§Ø²Ø§Ø± Ø¯Ø± ÙØ±ÙØ±Ú¯Ø±Ø ØªÙØ§Ù ØªØµØ§ÙÛØ± ÙÙÛÙ ØµÙØ­Ù Ø¨Ù
 * dkstatics-public.digikala.com ÙÙØªÙÙ ÙÛâØ´ÙÙØ¯ ØªØ§ ØªØµÙÛØ± Ø¨Ø¯ÙÙ Ø¹Ø¨ÙØ± Ø§Ø² Worker ÙÙØ¯ Ø´ÙØ¯.
 */
add_action('wp_head', 'evazar_register_image_failover_script', 1);
function evazar_register_image_failover_script()
{
    if (is_admin() || is_front_page()) return;

    $cdn_host = rtrim(trim(get_option('evazar_image_cdn_domain', 'https://img.evazar.ir')), '/');
    if (empty($cdn_host)) $cdn_host = 'https://img.evazar.ir';

    $cdn_host_json = wp_json_encode($cdn_host);
    $direct_host_json = wp_json_encode('https://dkstatics-public.digikala.com');
    ?>
    <script id="evazar-image-failover-js">
    (function () {
        'use strict';

        var CDN_HOST = <?php echo $cdn_host_json; ?>;
        var DIRECT_HOST = <?php echo $direct_host_json; ?>;
        var STORAGE_KEY = 'evazar_image_direct_mode_v1';
        var STORAGE_TTL = 10 * 60 * 1000;
        var observerStarted = false;

        function sameHost(url, host) {
            try {
                return new URL(url, window.location.href).hostname.toLowerCase() ===
                    new URL(host, window.location.href).hostname.toLowerCase();
            } catch (_) {
                return false;
            }
        }

        function toDirect(url) {
            if (!url || typeof url !== 'string') return url;
            if (!sameHost(url, CDN_HOST)) return url;

            try {
                var parsed = new URL(url, window.location.href);
                parsed.protocol = new URL(DIRECT_HOST).protocol;
                parsed.hostname = new URL(DIRECT_HOST).hostname;
                parsed.port = new URL(DIRECT_HOST).port;
                return parsed.toString();
            } catch (_) {
                return url;
            }
        }

        function toDirectSrcset(value) {
            if (!value || typeof value !== 'string') return value;
            return value.split(',').map(function (candidate) {
                var parts = candidate.trim().split(/\s+/);
                if (!parts[0]) return candidate;
                parts[0] = toDirect(parts[0]);
                return parts.join(' ');
            }).join(', ');
        }

        function rewriteImage(img) {
            if (!img || img.nodeType !== 1 || img.tagName !== 'IMG') return false;

            var changed = false;
            var attrs = [
                'src',
                'data-src',
                'data-lazy-src',
                'data-original',
                'data-original-src'
            ];

            attrs.forEach(function (name) {
                var value = img.getAttribute(name);
                if (!value) return;
                var direct = toDirect(value);
                if (direct !== value) {
                    img.setAttribute(name, direct);
                    changed = true;
                }
            });

            ['srcset', 'data-srcset', 'data-lazy-srcset'].forEach(function (name) {
                var value = img.getAttribute(name);
                if (!value) return;
                var direct = toDirectSrcset(value);
                if (direct !== value) {
                    img.setAttribute(name, direct);
                    changed = true;
                }
            });

            if (changed) {
                img.setAttribute('data-evazar-image-fallback', 'direct');
            }

            return changed;
        }

        function rewriteAllImages() {
            document.querySelectorAll('img').forEach(rewriteImage);
        }

        function activateDirectMode() {
            try {
                sessionStorage.setItem(STORAGE_KEY, String(Date.now()));
            } catch (_) {}

            rewriteAllImages();

            if (observerStarted || !window.MutationObserver) return;
            observerStarted = true;

            new MutationObserver(function (mutations) {
                mutations.forEach(function (mutation) {
                    mutation.addedNodes.forEach(function (node) {
                        if (node.nodeType !== 1) return;
                        if (node.tagName === 'IMG') rewriteImage(node);
                        if (node.querySelectorAll) {
                            node.querySelectorAll('img').forEach(rewriteImage);
                        }
                    });

                    if (mutation.type === 'attributes' && mutation.target && mutation.target.tagName === 'IMG') {
                        rewriteImage(mutation.target);
                    }
                });
            }).observe(document.documentElement, {
                subtree: true,
                childList: true,
                attributes: true,
                attributeFilter: ['src', 'srcset', 'data-src', 'data-srcset', 'data-lazy-src', 'data-lazy-srcset', 'data-original', 'data-original-src']
            });
        }

        function shouldStartDirectMode() {
            try {
                var saved = parseInt(sessionStorage.getItem(STORAGE_KEY) || '0', 10);
                return saved > 0 && (Date.now() - saved) < STORAGE_TTL;
            } catch (_) {
                return false;
            }
        }

        window.addEventListener('error', function (event) {
            var target = event && event.target;
            if (!target || target.tagName !== 'IMG') return;

            var source = target.currentSrc || target.src || '';
            if (!sameHost(source, CDN_HOST)) return;

            // Ø§ÙÙÛÙ Ø®Ø·Ø§Û CDN Ø±Ø§ Ø¨ÙâØ¹ÙÙØ§Ù Ø§ÙØª ÙØ³ÛØ± Ø¯Ø± ÙØ¸Ø± ÙÛâÚ¯ÛØ±ÛÙ Ù Ø¨Ø§ÙÛ ØµÙØ­Ù Ø±Ø§ ÙØ³ØªÙÛÙ ÙÛâÚ©ÙÛÙ.
            activateDirectMode();

            // Ø§Ø¬Ø§Ø²Ù ÙØ¯ÙÛÙ fallbackÙØ§Û ÙØ¯ÛÙÛ ÙØ§ÙØ¨ ØªØµÙÛØ± Ø±Ø§ Ù¾ÙÙØ§Ù Ú©ÙÙØ¯ ÛØ§ Ø¯ÙØ¨Ø§Ø±Ù Ø®Ø·Ø§Û ÙØ¨ÙÛ Ø±Ø§ Ø§Ø¬Ø±Ø§ Ú©ÙÙØ¯.
            target.onerror = null;
            if (event.stopImmediatePropagation) event.stopImmediatePropagation();

            // ÙÙØ§Ù ØªØµÙÛØ± Ø±Ø§ ÙÙØ±Ø§Ù Ø±ÙÛ CDN Ø§ØµÙÛ Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§ ÙØ±Ø§Ø± ÙÛâØ¯ÙÛÙ.
            var direct = toDirect(source);
            if (direct && direct !== source) {
                target.style.removeProperty('visibility');
                target.srcset = '';
                target.removeAttribute('data-srcset');
                target.removeAttribute('data-lazy-srcset');
                target.src = direct;
            }
        }, true);

        if (shouldStartDirectMode()) {
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', activateDirectMode, { once: true });
            } else {
                activateDirectMode();
            }
        }
    }());
    </script>
    <?php
}

// ==========================================
// 5. Ø³ØªÙÙâÙØ§Û Ø§Ø®ØªØµØ§ØµÛ ÙÛØ³Øª Ú©Ø§ÙØ§ÙØ§ Ø¯Ø± Ù¾ÛØ´Ø®ÙØ§Ù (Zero Host Storage)
// ==========================================
add_filter('manage_evazar_product_posts_columns', 'evazar_product_custom_admin_columns');
function evazar_product_custom_admin_columns($columns)
{
    $new_cols = [];
    foreach ($columns as $k => $title) {
        if ($k === 'title') {
            $new_cols['evazar_img'] = 'ØªØµÙÛØ± Ú©Ø§ÙØ§';
        }
        $new_cols[$k] = $title;
    }
    $new_cols['evazar_price'] = 'ÙÛÙØª ÙØ±ÙØ´';
    $new_cols['evazar_discount'] = 'ØªØ®ÙÛÙ';
    $new_cols['evazar_source'] = 'ÙÙØ¨Ø¹ Ú©Ø§ÙØ§';
    return $new_cols;
}

add_action('manage_evazar_product_posts_custom_column', 'evazar_product_render_admin_columns', 10, 2);
function evazar_product_render_admin_columns($column, $post_id)
{
    if ($column === 'evazar_img') {
        $img = get_post_meta($post_id, '_evazar_main_image', true);
        if ($img) {
            $cdn_img = evazar_cdn_image_url($img);
            echo '<img src="' . esc_url($cdn_img) . '" style="width: 46px; height: 46px; object-fit: contain; border-radius: 6px; border: 1px solid #e2e8f0; background: #fff;" loading="lazy">';
        } else {
            echo '<span style="color:#94a3b8; font-size:11px;">Ø¨Ø¯ÙÙ Ø¹Ú©Ø³</span>';
        }
    } elseif ($column === 'evazar_price') {
        $p = get_post_meta($post_id, '_evazar_current_price', true);
        echo $p ? '<strong>' . number_format((float)$p) . '</strong> <span style="font-size:10px; color:#64748b;">ØªÙÙØ§Ù</span>' : 'â';
    } elseif ($column === 'evazar_discount') {
        $d = get_post_meta($post_id, '_evazar_discount_percent', true);
        echo $d ? '<span style="background:#fee2e2; color:#b91c1c; padding:2px 6px; border-radius:4px; font-size:11px; font-weight:bold;">' . esc_html($d) . '</span>' : 'â';
    } elseif ($column === 'evazar_source') {
        $dk = get_post_meta($post_id, '_evazar_dk_url', true);
        if ($dk) {
            echo '<a href="' . esc_url($dk) . '" target="_blank" class="button button-small" style="font-size:11px;">Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§ â</a>';
        } else {
            echo 'â';
        }
    }
}

// ÙÛÙØªØ±ÙØ§Û ÙØ¬Ø§Ø²Û ØªØµÙÛØ± Ø´Ø§Ø®Øµ (Zero Host Storage Virtual Thumbnail)
add_filter('has_post_thumbnail', 'evazar_core_virtual_has_thumbnail', 10, 3);
function evazar_core_virtual_has_thumbnail($has, $post, $thumbnail_id)
{
    if ($has) return true;
    $pid = is_object($post) ? $post->ID : $post;
    if ($pid && get_post_type($pid) === 'evazar_product') {
        $img = get_post_meta($pid, '_evazar_main_image', true);
        if (!empty($img)) return true;
    }
    return $has;
}

add_filter('post_thumbnail_html', 'evazar_core_virtual_thumbnail_html', 10, 5);
function evazar_core_virtual_thumbnail_html($html, $post_id, $post_thumbnail_id, $size, $attr)
{
    if (!empty($html)) return $html;
    if (get_post_type($post_id) === 'evazar_product') {
        $img = get_post_meta($post_id, '_evazar_main_image', true);
        if (!empty($img)) {
            $class = isset($attr['class']) ? esc_attr($attr['class']) : 'attachment-' . esc_attr($size) . ' size-' . esc_attr($size) . ' wp-post-image';
            $alt = esc_attr(get_the_title($post_id));
            $cdn_img = evazar_cdn_image_url($img, 0);
            return '<img src="' . esc_url($cdn_img ?: $img) . '" class="' . $class . '" alt="' . $alt . '" loading="lazy" />';
        }
    }
    return $html;
}

// ==========================================
// 6. ÙÛØ±Ø§ÛØ´Ú¯Ø± Ù¾ÛØ´Ø±ÙØªÙ ÙØªÙÛ (Visual WYSIWYG Editor) Ø¨Ø±Ø§Û ØªÙØ¶ÛØ­Ø§Øª Ø¨Ø±ÙØ¯ÙØ§ Ù Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§
// ==========================================
// Ø­Ø°Ù ÙÛÙØªØ±ÙØ§Û ÙØ­Ø¯ÙØ¯Ú©ÙÙØ¯Ù ØªÚ¯âÙØ§Û HTML Ø¯Ø± ØªÙØ¶ÛØ­Ø§Øª ØªØ§Ú©Ø³ÙÙÙÙÛâÙØ§
remove_filter('pre_term_description', 'wp_filter_kses');
remove_filter('term_description', 'wp_kses_data');

add_action('evazar_brand_edit_form_fields', 'evazar_taxonomy_rich_editor_custom', 1, 2);
add_action('evazar_category_edit_form_fields', 'evazar_taxonomy_rich_editor_custom', 1, 2);
function evazar_taxonomy_rich_editor_custom($term, $taxonomy)
{
?>
    <tr class="form-field term-description-wrap" id="evazar-custom-editor-row">
        <th scope="row"><label for="description">ØªÙØ¶ÛØ­Ø§Øª Ù ÙØ­ØªÙØ§Û Ø³Ø¦Ù (ÙÛØ±Ø§ÛØ´Ú¯Ø± Ù¾ÛØ´Ø±ÙØªÙ):</label></th>
        <td>
            <?php
            $content = !empty($term->description) ? html_entity_decode($term->description, ENT_QUOTES, 'UTF-8') : '';
            $settings = array(
                'textarea_name' => 'description',
                'textarea_rows' => 12,
                'editor_class'  => 'evazar-rich-desc',
                'media_buttons' => true,
                'tinymce'       => array(
                    'toolbar1' => 'formatselect,bold,italic,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,unlink,undo,redo,wp_adv',
                    'toolbar2' => 'strikethrough,hr,forecolor,pastetext,removeformat,charmap,outdent,indent,fullscreen'
                ),
                'quicktags'     => true
            );
            wp_editor($content, 'evazar_term_desc_editor', $settings);
            ?>
            <p class="description">Ø§Ø² ÙÛØ±Ø§ÛØ´Ú¯Ø± ÙØªÙÛ Ù¾ÛØ´Ø±ÙØªÙ Ø¨Ø±Ø§Û ÙØ§ÙØ¨âØ¨ÙØ¯Û ÙØªÙÙØ ØªØ¹Ø±ÛÙ ØªÛØªØ±ÙØ§ (H2Ø H3)Ø ÙÛØ³ØªâÙØ§Ø ÙÛÙÚ©âÙØ§Û Ø¯Ø§Ø®ÙÛ Ù Ú©ÙÙØ§Øª Ú©ÙÛØ¯Û Ø³Ø¦Ù Ø§Ø³ØªÙØ§Ø¯Ù ÙØ±ÙØ§ÛÛØ¯.</p>
            <script>
                jQuery(document).ready(function($) {
                    $('tr.term-description-wrap').not('#evazar-custom-editor-row').remove();
                });
            </script>
        </td>
    </tr>
<?php
}

add_action('evazar_brand_add_form_fields', 'evazar_taxonomy_add_rich_editor', 10, 1);
add_action('evazar_category_add_form_fields', 'evazar_taxonomy_add_rich_editor', 10, 1);
function evazar_taxonomy_add_rich_editor($taxonomy)
{
?>
    <div class="form-field term-description-wrap" id="evazar-add-editor-wrap">
        <label for="description">ØªÙØ¶ÛØ­Ø§Øª Ù ÙØ­ØªÙØ§Û Ø³Ø¦Ù:</label>
        <?php
        $settings = array(
            'textarea_name' => 'description',
            'textarea_rows' => 6,
            'media_buttons' => false,
            'tinymce'       => true,
            'quicktags'     => true
        );
        wp_editor('', 'evazar_add_desc_editor', $settings);
        ?>
        <p class="description">ØªÙØ¶ÛØ­Ø§Øª Ø§ÙÙÛÙ Ø³Ø¦Ù Ø¨Ø±Ø§Û Ø§ÛÙ Ø¨Ø±Ú¯Ù Ø¢Ø±Ø´ÛÙ.</p>
        <script>
            jQuery(document).ready(function($) {
                $('.form-field.term-description-wrap').not('#evazar-add-editor-wrap').remove();
            });
        </script>
    </div>
<?php
}

// Ø§ÙØ²ÙØ¯Ù ÙÛÙØ¯ÙØ§Û ÙØªØ§Û Ø³Ø¦Ù (Ø¹ÙÙØ§Ù Ù ØªÙØ¶ÛØ­Ø§Øª ÙØªØ§) Ø¨Ù ÙØ±Ù ÙÛØ±Ø§ÛØ´ ØªØ§Ú©Ø³ÙÙÙÙÛâÙØ§Û Ø¯Ø³ØªÙ Ù Ø¨Ø±ÙØ¯
add_action('evazar_brand_edit_form_fields', 'evazar_taxonomy_seo_meta_edit_fields', 20, 2);
add_action('evazar_category_edit_form_fields', 'evazar_taxonomy_seo_meta_edit_fields', 20, 2);
function evazar_taxonomy_seo_meta_edit_fields($term, $taxonomy)
{
    $meta_title = get_term_meta($term->term_id, '_evazar_meta_title', true);
    $meta_desc  = get_term_meta($term->term_id, '_evazar_meta_description', true);
    ?>
    <tr class="form-field evazar-seo-meta-title-row">
        <th scope="row"><label for="evazar_meta_title">Ø¹ÙÙØ§Ù ÙØªØ§Û Ø§Ø®ØªØµØ§ØµÛ Ø³Ø¦Ù (Meta Title):</label></th>
        <td>
            <input type="text" name="evazar_meta_title" id="evazar_meta_title" value="<?php echo esc_attr($meta_title); ?>" style="width: 100%; max-width: 650px;" placeholder="ÙØ«Ø§Ù: Ø®Ø±ÛØ¯ Ù ÙÛÙØª Ø±ÙØ² Ø§ÙÙØ§Ø¹ <?php echo esc_attr($term->name); ?> | Ø§ÛÙØ§Ø²Ø§Ø±">
            <p class="description">Ø¹ÙÙØ§Ù Ø¯ÙØ®ÙØ§Ù Ø³Ø¦Ù Ø¨Ø±Ø§Û Ø§ÛÙ Ø¨Ø±Ú¯Ù Ø¯Ø± ØªØ¨ ÙØ±ÙØ±Ú¯Ø± Ù ÙØªØ§ÛØ¬ Ú¯ÙÚ¯Ù. <strong>Ø¯Ø± ØµÙØ±Øª Ø®Ø§ÙÛ Ø¨ÙØ¯Ù</strong>Ø ÙØ³ØªÙÛÙØ§Ù Ø§Ø² Ø§ÙÚ¯ÙÛ ÙØ±Ø¬Ø¹ Ø¯Ø± ØªÙØ¸ÛÙØ§Øª Ø§ÛÙØ§Ø²Ø§Ø± Ø®ÙØ§ÙØ¯Ù ÙÛâØ´ÙØ¯.</p>
        </td>
    </tr>
    <tr class="form-field evazar-seo-meta-desc-row">
        <th scope="row"><label for="evazar_meta_description">ØªÙØ¶ÛØ­Ø§Øª ÙØªØ§Û Ø§Ø®ØªØµØ§ØµÛ Ø³Ø¦Ù (Meta Description):</label></th>
        <td>
            <textarea name="evazar_meta_description" id="evazar_meta_description" rows="3" style="width: 100%; max-width: 650px;" placeholder="ØªÙØ¶ÛØ­Ø§Øª Ø§Ø®ØªØµØ§ØµÛ Ø³Ø¦Ù Ø¨Ø±Ø§Û ÙØªØ§ÛØ¬ Ú¯ÙÚ¯Ù (Ø­Ø¯Ø§Ú©Ø«Ø± Û±Û¶Û° Ú©Ø§Ø±Ø§Ú©ØªØ±)..."><?php echo esc_textarea($meta_desc); ?></textarea>
            <p class="description">ØªÙØ¶ÛØ­Ø§Øª ÙØªØ§Û Ú¯ÙÚ¯Ù Ø§Ø®ØªØµØ§ØµÛ Ø¨Ø±Ø§Û Ø§ÛÙ Ø¯Ø³ØªÙ/Ø¨Ø±ÙØ¯. <strong>Ø¯Ø± ØµÙØ±Øª Ø®Ø§ÙÛ Ø¨ÙØ¯Ù</strong>Ø Ø¨Ù Ø·ÙØ± Ø®ÙØ¯Ú©Ø§Ø± Ø§Ø² Ø§ÙÚ¯ÙÛ ÙØ±Ø¬Ø¹ ØªÙØ¸ÛÙØ§Øª ØªÙÙÛØ¯ ÙÛâØ´ÙØ¯.</p>
        </td>
    </tr>
    <?php
}

add_action('evazar_brand_add_form_fields', 'evazar_taxonomy_seo_meta_add_fields', 20, 1);
add_action('evazar_category_add_form_fields', 'evazar_taxonomy_seo_meta_add_fields', 20, 1);
function evazar_taxonomy_seo_meta_add_fields($taxonomy)
{
    ?>
    <div class="form-field evazar-seo-meta-title-wrap">
        <label for="evazar_meta_title">Ø¹ÙÙØ§Ù ÙØªØ§Û Ø§Ø®ØªØµØ§ØµÛ Ø³Ø¦Ù (Meta Title):</label>
        <input type="text" name="evazar_meta_title" id="evazar_meta_title" value="" placeholder="Ø®Ø§ÙÛ = Ø®ÙØ§ÙØ¯Ù Ø§Ø² Ø§ÙÚ¯ÙÛ ØªÙØ¸ÛÙØ§Øª ÙØ±Ø¬Ø¹">
        <p class="description">Ø¯Ø± ØµÙØ±Øª Ø®Ø§ÙÛ Ø¨ÙØ¯ÙØ ÙØ³ØªÙÛÙØ§Ù Ø§Ø² ØªÙØ¸ÛÙØ§Øª ÙØ±Ø¬Ø¹ Ø®ÙØ§ÙØ¯Ù ÙÛâØ´ÙØ¯.</p>
    </div>
    <div class="form-field evazar-seo-meta-desc-wrap">
        <label for="evazar_meta_description">ØªÙØ¶ÛØ­Ø§Øª ÙØªØ§Û Ø§Ø®ØªØµØ§ØµÛ Ø³Ø¦Ù (Meta Description):</label>
        <textarea name="evazar_meta_description" id="evazar_meta_description" rows="3" placeholder="Ø®Ø§ÙÛ = ØªÙÙÛØ¯ Ø®ÙØ¯Ú©Ø§Ø± Ø§Ø² Ø§ÙÚ¯ÙÛ ØªÙØ¸ÛÙØ§Øª ÙØ±Ø¬Ø¹"></textarea>
        <p class="description">Ø¯Ø± ØµÙØ±Øª Ø®Ø§ÙÛ Ø¨ÙØ¯ÙØ Ø¨Ù Ø·ÙØ± Ø®ÙØ¯Ú©Ø§Ø± Ø§Ø² Ø§ÙÚ¯ÙÛ ØªÙØ¸ÛÙØ§Øª ÙØ±Ø¬Ø¹ Ø³Ø§Ø®ØªÙ ÙÛâØ´ÙØ¯.</p>
    </div>
    <?php
}

add_action('edited_evazar_brand', 'evazar_save_taxonomy_seo_meta_fields');
add_action('edited_evazar_category', 'evazar_save_taxonomy_seo_meta_fields');
add_action('create_evazar_brand', 'evazar_save_taxonomy_seo_meta_fields');
add_action('create_evazar_category', 'evazar_save_taxonomy_seo_meta_fields');
function evazar_save_taxonomy_seo_meta_fields($term_id)
{
    if (isset($_POST['evazar_meta_title'])) {
        $meta_title = sanitize_text_field(wp_unslash($_POST['evazar_meta_title']));
        if (!empty($meta_title)) {
            update_term_meta($term_id, '_evazar_meta_title', $meta_title);
            update_term_meta($term_id, 'rank_math_title', $meta_title);
        } else {
            delete_term_meta($term_id, '_evazar_meta_title');
            delete_term_meta($term_id, 'rank_math_title');
        }
    }
    if (isset($_POST['evazar_meta_description'])) {
        $meta_desc = sanitize_textarea_field(wp_unslash($_POST['evazar_meta_description']));
        if (!empty($meta_desc)) {
            update_term_meta($term_id, '_evazar_meta_description', $meta_desc);
            update_term_meta($term_id, 'rank_math_description', $meta_desc);
        } else {
            delete_term_meta($term_id, '_evazar_meta_description');
            delete_term_meta($term_id, 'rank_math_description');
        }
    }
}

// ==========================================================================
// 6. ÙÙØ§ÙÙÚ¯âØ³Ø§Ø²Û Ø¹ÙÛÙ Ù Ø¨ÙÙÛ Ø¨Ø§ Ø±ÙÚ©âÙØ« (Rank Math Deep SEO & Schema Engine)
// ==========================================================================

// Ø§ÙÙ) ÙØ¹Ø§ÙâØ³Ø§Ø²Û ÙØªØ§Ø¨Ø§Ú©Ø³ Ù ØªØ­ÙÛÙâÙØ§Û Ø±ÙÚ©âÙØ« Ø¯Ø± Ù¾Ø³ØªâØªØ§ÛÙ¾ Ú©Ø§ÙØ§ÙØ§
add_filter('rank_math/metabox/post_types', 'evazar_rm_enable_metabox');
function evazar_rm_enable_metabox($post_types) {
    if (!in_array('evazar_product', $post_types)) {
        $post_types[] = 'evazar_product';
    }
    return $post_types;
}

// Ø¨) Ú¯ÙØ¬Ø§ÙØ¯Ù ÙØ·Ø¹Û Ù¾Ø³ØªâØªØ§ÛÙ¾ Ú©Ø§ÙØ§ÙØ§ Ø¯Ø± ÙÙØ´Ù Ø³Ø§ÛØª Ø±ÙÚ©âÙØ« (XML Sitemap)
add_filter('rank_math/sitemap/post_types', 'evazar_rm_enable_sitemap');
function evazar_rm_enable_sitemap($post_types) {
    if (!in_array('evazar_product', $post_types)) {
        $post_types[] = 'evazar_product';
    }
    return $post_types;
}

// ØªÙØ§Ø¨Ø¹ Ú©ÙÚ©Û ØªØ´Ø®ÛØµ Ø¨Ø±Ú¯ÙâÙØ§Û Ø¬Ø§ÙØ¹ Ø¯Ø§ÛØ±Ú©ØªÙØ±Û Ø¨Ø±ÙØ¯ÙØ§ Ù Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§
if (!function_exists('evazar_is_brand_directory')) {
    function evazar_is_brand_directory() {
        if (get_query_var('evazar_directory') === 'brand') {
            return true;
        }
        $req_uri    = $_SERVER['REQUEST_URI'] ?? '';
        $clean_path = trim(parse_url($req_uri, PHP_URL_PATH), '/');
        return (bool)preg_match('#(?:^|/)brands?(?:/page/\d+)?/?$#i', $clean_path);
    }
}

if (!function_exists('evazar_is_category_directory')) {
    function evazar_is_category_directory() {
        if (get_query_var('evazar_directory') === 'category') {
            return true;
        }
        $req_uri    = $_SERVER['REQUEST_URI'] ?? '';
        $clean_path = trim(parse_url($req_uri, PHP_URL_PATH), '/');
        return (bool)(preg_match('#(?:^|/)categories?(?:/page/\d+)?/?$#i', $clean_path) || preg_match('#(?:^|/)product-category(?:/page/\d+)?/?$#i', $clean_path));
    }
}

// Ø¬) ÙØ±ÙÙÙ Ø·ÙØ§ÛÛ Ø¹ÙÙØ§Ù ÙØ±Ø§ÙØªâØ§ÙØ¯ Ø¨Ø±Ø§Û Ú©Ø§ÙØ§ÙØ§Ø Ø¯Ø³ØªÙâÙØ§ Ù Ø¨Ø±ÙØ¯ÙØ§
add_filter('rank_math/frontend/title', 'evazar_rm_dynamic_frontend_title', 9999);
add_filter('rank_math/opengraph/facebook/title', 'evazar_rm_dynamic_frontend_title', 9999);
add_filter('rank_math/opengraph/twitter/title', 'evazar_rm_dynamic_frontend_title', 9999);
add_filter('wpseo_title', 'evazar_rm_dynamic_frontend_title', 9999);
function evazar_rm_dynamic_frontend_title($title) {
    if (evazar_is_brand_directory()) {
        $brand_title = get_option('evazar_opt_brands_page_title', 'Ø¨Ø±ÙØ¯ÙØ§Û Ú©Ø§ÙØ§') ?: 'Ø¨Ø±ÙØ¯ÙØ§Û Ú©Ø§ÙØ§';
        $site_name   = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
        return evazar_append_pagination_suffix(trim($brand_title) . ' | ' . $site_name);
    }
    if (evazar_is_category_directory()) {
        $cat_title = get_option('evazar_opt_categories_page_title', 'Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§Û Ú©Ø§ÙØ§') ?: 'Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§Û Ú©Ø§ÙØ§';
        $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
        return evazar_append_pagination_suffix(trim($cat_title) . ' | ' . $site_name);
    }
    if (is_singular('evazar_product')) {
        $post_id = get_the_ID() ?: get_queried_object_id();
        if (empty($post_id)) {
            return $title;
        }
        $custom_title = get_post_meta($post_id, 'rank_math_title', true);
        if (empty($custom_title)) {
            $prod_title = get_the_title($post_id);
            $site_name  = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
            $tpl        = get_option('evazar_product_title_template', 'ÙÛÙØª Ù Ø®Ø±ÛØ¯ {title} | {site_name}');
            if (empty(trim($tpl))) {
                $tpl = 'ÙÛÙØª Ù Ø®Ø±ÛØ¯ {title} | {site_name}';
            }

            $brand     = get_post_meta($post_id, '_evazar_brand', true) ?: '';
            $category  = get_post_meta($post_id, '_evazar_category', true) ?: '';
            $price_raw = get_post_meta($post_id, '_evazar_current_price', true);
            $price_fmt = $price_raw ? number_format(intval($price_raw)) . ' ØªÙÙØ§Ù' : '';

            $replacements = [
                '{title}'     => $prod_title,
                '{site_name}' => $site_name,
                '{brand}'     => $brand,
                '{category}'  => $category,
                '{price}'     => $price_fmt,
            ];

            return trim(str_replace(array_keys($replacements), array_values($replacements), $tpl));
        }
    } elseif (is_tax('evazar_brand')) {
        $term = get_queried_object();
        if ($term && !empty($term->term_id)) {
            $custom_title = get_term_meta($term->term_id, '_evazar_meta_title', true);
            if (!empty(trim($custom_title))) {
                return evazar_append_pagination_suffix(trim($custom_title));
            }
            $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
            $tpl = get_option('evazar_opt_brand_meta_title_template', 'Ø®Ø±ÛØ¯ Ù ÙÛÙØª Ø±ÙØ² Ø§ÙÙØ§Ø¹ ÙØ­ØµÙÙØ§Øª {brand} | {site_name}');
            if (empty(trim($tpl))) {
                $tpl = 'Ø®Ø±ÛØ¯ Ù ÙÛÙØª Ø±ÙØ² Ø§ÙÙØ§Ø¹ ÙØ­ØµÙÙØ§Øª {brand} | {site_name}';
            }
            $generated = trim(str_replace(['{brand}', '{site_name}', '{title}'], [$term->name, $site_name, $term->name], $tpl));
            return evazar_append_pagination_suffix($generated);
        }
    } elseif (is_tax('evazar_category')) {
        $term = get_queried_object();
        if ($term && !empty($term->term_id)) {
            $custom_title = get_term_meta($term->term_id, '_evazar_meta_title', true);
            if (!empty(trim($custom_title))) {
                return evazar_append_pagination_suffix(trim($custom_title));
            }
            $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
            $tpl = get_option('evazar_opt_category_meta_title_template', 'Ø®Ø±ÛØ¯ Ù ÙÛÙØª Ø±ÙØ² Ø§ÙÙØ§Ø¹ {category} | {site_name}');
            if (empty(trim($tpl))) {
                $tpl = 'Ø®Ø±ÛØ¯ Ù ÙÛÙØª Ø±ÙØ² Ø§ÙÙØ§Ø¹ {category} | {site_name}';
            }
            $generated = trim(str_replace(['{category}', '{site_name}', '{title}'], [$term->name, $site_name, $term->name], $tpl));
            return evazar_append_pagination_suffix($generated);
        }
    }
    if (in_array(trim($title), ['Archive', 'Archives', 'Ø¨Ø§ÛÚ¯Ø§ÙÛ'], true) || strpos($title, 'Archive ') === 0 || strpos($title, 'Archive -') === 0 || strpos($title, 'Archive |') === 0) {
        return 'Ú©Ø§ÙØ§ÙØ§Û Ø§ÛÙØ§Ø²Ø§Ø± | ' . (get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±');
    }
    return $title;
}

// ØªØ§Ø¨Ø¹ Ú©ÙÚ©Û Ø¯Ø±Ø¬ Ù¾Ø³ÙÙØ¯ Ø´ÙØ§Ø±Ù ØµÙØ­Ù Ø¯Ø± Ø¹ÙÙØ§Ù Ø³Ø¦Ù Ø¬ÙØª Ø±ÙØ¹ Ø¯Ø§Ù¾ÙÛÚ©ÛØª Ù Ø±ÙØ§Ø¨Øª ØµÙØ­Ø§Øª Ù¾ÛØ¬ÛÙÛØ´Ù
function evazar_append_pagination_suffix($title) {
    $paged = max(1, intval(get_query_var('paged', 1)), intval(get_query_var('page', 1)));
    if ($paged > 1) {
        $paged_fa = function_exists('evazar_to_fa_num') ? evazar_to_fa_num($paged) : $paged;
        if (strpos($title, ' | ') !== false) {
            $parts = explode(' | ', $title, 2);
            return $parts[0] . ' - ØµÙØ­Ù ' . $paged_fa . ' | ' . $parts[1];
        } else {
            return $title . ' - ØµÙØ­Ù ' . $paged_fa;
        }
    }
    return $title;
}

// ÙÛÙØªØ± Ø¹ÙÙØ§Ù ØªØ¨ ÙØ±ÙØ±Ú¯Ø± Ø¨Ø±Ø§Û Ø¢Ø±Ø´ÛÙ Ø¨Ø±ÙØ¯ÙØ§ Ù Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§
add_filter('document_title_parts', 'evazar_tax_meta_document_title_parts', 9999);
function evazar_tax_meta_document_title_parts($parts) {
    if (evazar_is_brand_directory()) {
        $brand_title = get_option('evazar_opt_brands_page_title', 'Ø¨Ø±ÙØ¯ÙØ§Û Ú©Ø§ÙØ§') ?: 'Ø¨Ø±ÙØ¯ÙØ§Û Ú©Ø§ÙØ§';
        $site_name   = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
        $parts['title'] = evazar_append_pagination_suffix(trim($brand_title) . ' | ' . $site_name);
        unset($parts['site'], $parts['tagline']);
        return $parts;
    }
    if (evazar_is_category_directory()) {
        $cat_title = get_option('evazar_opt_categories_page_title', 'Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§Û Ú©Ø§ÙØ§') ?: 'Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§Û Ú©Ø§ÙØ§';
        $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
        $parts['title'] = evazar_append_pagination_suffix(trim($cat_title) . ' | ' . $site_name);
        unset($parts['site'], $parts['tagline']);
        return $parts;
    }
    if (is_tax('evazar_brand')) {
        $term = get_queried_object();
        if ($term && !empty($term->name)) {
            $custom_title = get_term_meta($term->term_id, '_evazar_meta_title', true);
            if (!empty(trim($custom_title))) {
                $parts['title'] = evazar_append_pagination_suffix(trim($custom_title));
                unset($parts['site']);
            } else {
                $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
                $tpl = get_option('evazar_opt_brand_meta_title_template', 'Ø®Ø±ÛØ¯ Ù ÙÛÙØª Ø±ÙØ² Ø§ÙÙØ§Ø¹ ÙØ­ØµÙÙØ§Øª {brand} | {site_name}');
                if (empty(trim($tpl))) $tpl = 'Ø®Ø±ÛØ¯ Ù ÙÛÙØª Ø±ÙØ² Ø§ÙÙØ§Ø¹ ÙØ­ØµÙÙØ§Øª {brand} | {site_name}';
                $parts['title'] = evazar_append_pagination_suffix(trim(str_replace(['{brand}', '{site_name}', '{title}'], [$term->name, $site_name, $term->name], $tpl)));
                unset($parts['site']);
            }
        }
    } elseif (is_tax('evazar_category')) {
        $term = get_queried_object();
        if ($term && !empty($term->name)) {
            $custom_title = get_term_meta($term->term_id, '_evazar_meta_title', true);
            if (!empty(trim($custom_title))) {
                $parts['title'] = evazar_append_pagination_suffix(trim($custom_title));
                unset($parts['site']);
            } else {
                $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
                $tpl = get_option('evazar_opt_category_meta_title_template', 'Ø®Ø±ÛØ¯ Ù ÙÛÙØª Ø±ÙØ² Ø§ÙÙØ§Ø¹ {category} | {site_name}');
                if (empty(trim($tpl))) $tpl = 'Ø®Ø±ÛØ¯ Ù ÙÛÙØª Ø±ÙØ² Ø§ÙÙØ§Ø¹ {category} | {site_name}';
                $parts['title'] = evazar_append_pagination_suffix(trim(str_replace(['{category}', '{site_name}', '{title}'], [$term->name, $site_name, $term->name], $tpl)));
                unset($parts['site']);
            }
        }
    }
    if (isset($parts['title']) && in_array(trim($parts['title']), ['Archive', 'Archives', 'Ø¨Ø§ÛÚ¯Ø§ÙÛ'], true)) {
        $parts['title'] = 'Ú©Ø§ÙØ§ÙØ§Û Ø§ÛÙØ§Ø²Ø§Ø±';
    }
    return $parts;
}

add_filter('pre_get_document_title', 'evazar_tax_pre_get_document_title', 9999);
function evazar_tax_pre_get_document_title($title) {
    if (evazar_is_brand_directory()) {
        $brand_title = get_option('evazar_opt_brands_page_title', 'Ø¨Ø±ÙØ¯ÙØ§Û Ú©Ø§ÙØ§') ?: 'Ø¨Ø±ÙØ¯ÙØ§Û Ú©Ø§ÙØ§';
        $site_name   = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
        return evazar_append_pagination_suffix(trim($brand_title) . ' | ' . $site_name);
    }
    if (evazar_is_category_directory()) {
        $cat_title = get_option('evazar_opt_categories_page_title', 'Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§Û Ú©Ø§ÙØ§') ?: 'Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§Û Ú©Ø§ÙØ§';
        $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
        return evazar_append_pagination_suffix(trim($cat_title) . ' | ' . $site_name);
    }
    if (is_tax('evazar_brand')) {
        $term = get_queried_object();
        if ($term && !empty($term->name)) {
            $custom_title = get_term_meta($term->term_id, '_evazar_meta_title', true);
            if (!empty(trim($custom_title))) {
                return evazar_append_pagination_suffix(trim($custom_title));
            }
            $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
            $tpl = get_option('evazar_opt_brand_meta_title_template', 'Ø®Ø±ÛØ¯ Ù ÙÛÙØª Ø±ÙØ² Ø§ÙÙØ§Ø¹ ÙØ­ØµÙÙØ§Øª {brand} | {site_name}');
            if (empty(trim($tpl))) $tpl = 'Ø®Ø±ÛØ¯ Ù ÙÛÙØª Ø±ÙØ² Ø§ÙÙØ§Ø¹ ÙØ­ØµÙÙØ§Øª {brand} | {site_name}';
            return evazar_append_pagination_suffix(trim(str_replace(['{brand}', '{site_name}', '{title}'], [$term->name, $site_name, $term->name], $tpl)));
        }
    } elseif (is_tax('evazar_category')) {
        $term = get_queried_object();
        if ($term && !empty($term->name)) {
            $custom_title = get_term_meta($term->term_id, '_evazar_meta_title', true);
            if (!empty(trim($custom_title))) {
                return evazar_append_pagination_suffix(trim($custom_title));
            }
            $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
            $tpl = get_option('evazar_opt_category_meta_title_template', 'Ø®Ø±ÛØ¯ Ù ÙÛÙØª Ø±ÙØ² Ø§ÙÙØ§Ø¹ {category} | {site_name}');
            if (empty(trim($tpl))) $tpl = 'Ø®Ø±ÛØ¯ Ù ÙÛÙØª Ø±ÙØ² Ø§ÙÙØ§Ø¹ {category} | {site_name}';
            return evazar_append_pagination_suffix(trim(str_replace(['{category}', '{site_name}', '{title}'], [$term->name, $site_name, $term->name], $tpl)));
        }
    }
    if (in_array(trim($title), ['Archive', 'Archives', 'Ø¨Ø§ÛÚ¯Ø§ÙÛ'], true) || strpos($title, 'Archive ') === 0 || strpos($title, 'Archive -') === 0 || strpos($title, 'Archive |') === 0) {
        return 'Ú©Ø§ÙØ§ÙØ§Û Ø§ÛÙØ§Ø²Ø§Ø± | ' . (get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±');
    }
    return $title;
}

// Ø¯) ØªÙØ¶ÛØ­Ø§Øª ÙØªØ§Û Ù¾ÙÛØ§ Ù Ø®ÙØ¯Ú©Ø§Ø± Ø±ÙÚ©âÙØ«
add_filter('rank_math/frontend/description', 'evazar_rm_dynamic_frontend_desc', 20);
add_filter('rank_math/opengraph/facebook/description', 'evazar_rm_dynamic_frontend_desc', 20);
add_filter('rank_math/opengraph/twitter/description', 'evazar_rm_dynamic_frontend_desc', 20);
function evazar_rm_dynamic_frontend_desc($description) {
    if (evazar_is_brand_directory()) {
        $custom_desc = get_option('evazar_opt_brands_page_desc', '');
        if (!empty(trim($custom_desc))) {
            return trim(wp_strip_all_tags($custom_desc));
        }
        $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
        return 'Ø¨Ø±Ø±Ø³Û ÙÛÙØª Ø±ÙØ²Ø ÙÙØ§ÛØ³Ù ÙØ´Ø®ØµØ§Øª ÙÙÛ Ù Ø®Ø±ÛØ¯ ÙØ³ØªÙÛÙ Ø¨Ø§ Ø¨ÙØªØ±ÛÙ Ú¯Ø§Ø±Ø§ÙØªÛ Ù ØªØ¶ÙÛÙ Ø§ØµØ§ÙØª Ú©Ø§ÙØ§ Ø¯Ø± ' . $site_name . '.';
    }
    if (evazar_is_category_directory()) {
        $custom_desc = get_option('evazar_opt_categories_page_desc', '');
        if (!empty(trim($custom_desc))) {
            return trim(wp_strip_all_tags($custom_desc));
        }
        $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
        return 'ÙØ´Ø§ÙØ¯Ù ÙÛØ³Øª Ù Ø±Ø§ÙÙÙØ§Û Ø¬Ø§ÙØ¹ Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§Û Ú©Ø§ÙØ§Û ' . $site_name . 'Ø ÙÙØ§ÛØ³Ù ÙÛÙØªâÙØ§Ø ÙÙØ¯ Ù Ø¨Ø±Ø±Ø³Û Ù Ø®Ø±ÛØ¯ ÙÙØ´ÙÙØ¯Ø§ÙÙ Ø§Ø² ÙØ¹ØªØ¨Ø±ØªØ±ÛÙ ÙØ±ÙØ´Ú¯Ø§ÙâÙØ§.';
    }
    if (is_singular('evazar_product')) {
        if (empty($description)) {
            $post_id = get_the_ID() ?: get_queried_object_id();
            if (empty($post_id)) {
                return $description;
            }
            $saved_desc = get_post_meta($post_id, 'rank_math_description', true);
            if (!empty($saved_desc)) {
                return $saved_desc;
            }
            $title     = get_the_title($post_id);
            $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
            $tpl       = get_option('evazar_product_desc_template', 'ÙÛÙØª Ù Ø®Ø±ÛØ¯ Ø¢ÙÙØ§ÛÙ {title} Ø¨Ø§ Ø¨ÙØªØ±ÛÙ ÙÛÙØª Ø±ÙØ² Ù ÙØ´Ø®ØµØ§Øª Ø¯Ø± {site_name}. ÙÙØ¯ Ù Ø¨Ø±Ø±Ø³Û Ù Ø¶ÙØ§ÙØª Ø§ØµØ§ÙØª Ú©Ø§ÙØ§.');
            if (empty(trim($tpl))) {
                $tpl = 'ÙÛÙØª Ù Ø®Ø±ÛØ¯ Ø¢ÙÙØ§ÛÙ {title} Ø¨Ø§ Ø¨ÙØªØ±ÛÙ ÙÛÙØª Ø±ÙØ² Ù ÙØ´Ø®ØµØ§Øª Ø¯Ø± {site_name}. ÙÙØ¯ Ù Ø¨Ø±Ø±Ø³Û Ù Ø¶ÙØ§ÙØª Ø§ØµØ§ÙØª Ú©Ø§ÙØ§.';
            }

            $brand     = get_post_meta($post_id, '_evazar_brand', true) ?: '';
            $category  = get_post_meta($post_id, '_evazar_category', true) ?: '';
            $price_raw = get_post_meta($post_id, '_evazar_current_price', true);
            $price_fmt = $price_raw ? number_format(intval($price_raw)) . ' ØªÙÙØ§Ù' : '';

            $replacements = [
                '{title}'     => $title,
                '{site_name}' => $site_name,
                '{brand}'     => $brand,
                '{category}'  => $category,
                '{price}'     => $price_fmt,
            ];

            return trim(str_replace(array_keys($replacements), array_values($replacements), $tpl));
        }
    } elseif (is_tax(['evazar_category', 'evazar_brand'])) {
        if (empty($description)) {
            $term = get_queried_object();
            if ($term && !empty($term->term_id)) {
                $custom_desc = get_term_meta($term->term_id, '_evazar_meta_description', true);
                if (!empty(trim($custom_desc))) {
                    return trim($custom_desc);
                }
                $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
                if ($term->taxonomy === 'evazar_brand') {
                    $tpl = get_option('evazar_opt_brand_meta_desc_template', 'ÙØ´Ø§ÙØ¯Ù ÙÛØ³Øª ÙÛÙØª Ø±ÙØ²Ø ÙØ´Ø®ØµØ§Øª ÙÙÛ Ù Ø®Ø±ÛØ¯ Ø¢ÙÙØ§ÛÙ Ø§ÙÙØ§Ø¹ {brand} Ø¯Ø± {site_name} Ø¨Ø§ ØªØ¶ÙÛÙ Ø§ØµØ§ÙØª Ù Ø§Ø±Ø³Ø§Ù Ø³Ø±ÛØ¹.');
                    if (empty(trim($tpl))) $tpl = 'ÙØ´Ø§ÙØ¯Ù ÙÛØ³Øª ÙÛÙØª Ø±ÙØ²Ø ÙØ´Ø®ØµØ§Øª ÙÙÛ Ù Ø®Ø±ÛØ¯ Ø¢ÙÙØ§ÛÙ Ø§ÙÙØ§Ø¹ {brand} Ø¯Ø± {site_name} Ø¨Ø§ ØªØ¶ÙÛÙ Ø§ØµØ§ÙØª Ù Ø§Ø±Ø³Ø§Ù Ø³Ø±ÛØ¹.';
                    return trim(str_replace(['{brand}', '{site_name}', '{title}'], [$term->name, $site_name, $term->name], $tpl));
                } else {
                    $tpl = get_option('evazar_opt_category_meta_desc_template', 'ÙØ´Ø§ÙØ¯Ù ÙÛØ³Øª ÙÛÙØª Ø±ÙØ²Ø ÙØ´Ø®ØµØ§Øª ÙÙÛ Ù Ø®Ø±ÛØ¯ Ø¢ÙÙØ§ÛÙ Ø§ÙÙØ§Ø¹ {category} Ø¯Ø± {site_name} Ø¨Ø§ ØªØ¶ÙÛÙ Ø§ØµØ§ÙØª Ù Ø§Ø±Ø³Ø§Ù Ø³Ø±ÛØ¹.');
                    if (empty(trim($tpl))) $tpl = 'ÙØ´Ø§ÙØ¯Ù ÙÛØ³Øª ÙÛÙØª Ø±ÙØ²Ø ÙØ´Ø®ØµØ§Øª ÙÙÛ Ù Ø®Ø±ÛØ¯ Ø¢ÙÙØ§ÛÙ Ø§ÙÙØ§Ø¹ {category} Ø¯Ø± {site_name} Ø¨Ø§ ØªØ¶ÙÛÙ Ø§ØµØ§ÙØª Ù Ø§Ø±Ø³Ø§Ù Ø³Ø±ÛØ¹.';
                    return trim(str_replace(['{category}', '{site_name}', '{title}'], [$term->name, $site_name, $term->name], $tpl));
                }
            }
        }
    }
    return $description;
}

// ÙÛÙÚ© Ú©Ø§ÙÙÙÛÚ©Ø§Ù Ø§Ø®ØªØµØ§ØµÛ ØµÙØ­Ø§Øª Ø¬Ø§ÙØ¹ Ø¬ÙØª Ø¬ÙÙÚ¯ÛØ±Û Ø§Ø² Ú©Ø§ÙÙÙÛÚ©Ø§Ù Ø´Ø¯Ù Ø¨Ù ØµÙØ­Ù Ø§ØµÙÛ
add_filter('rank_math/frontend/canonical', 'evazar_rm_dynamic_frontend_canonical', 20);
function evazar_rm_dynamic_frontend_canonical($canonical) {
    if (evazar_is_brand_directory()) {
        return home_url('/brand/');
    }
    if (evazar_is_category_directory()) {
        return home_url('/product-category/');
    }
    return $canonical;
}

// ÙÙ) ØªØ²Ø±ÛÙ Ø§Ø³Ú©ÛÙØ§ Ù¾ÛØ´Ø±ÙØªÙ ÙØ­ØµÙÙ (Product Rich Snippet Schema JSON-LD) Ø¬ÙØª ÙÙØ§ÛØ´ Ø³ØªØ§Ø±ÙâÙØ§ Ù ÙÛÙØª Ø¯Ø± Ú¯ÙÚ¯Ù
add_filter('rank_math/json_ld', 'evazar_rm_inject_product_schema', 99, 2);
function evazar_rm_inject_product_schema($data, $jsonld) {
    if (is_singular('evazar_product')) {
        $post_id = get_the_ID() ?: get_queried_object_id();
        if (empty($post_id)) {
            return $data;
        }
        $price        = get_post_meta($post_id, '_evazar_current_price', true);
        $old_price    = get_post_meta($post_id, '_evazar_old_price', true);
        $rating       = get_post_meta($post_id, '_evazar_rating', true);
        $satisfaction = get_post_meta($post_id, '_evazar_satisfaction', true);
        $brand        = get_post_meta($post_id, '_evazar_brand', true);
        $sku          = get_post_meta($post_id, '_sku', true) ?: $post_id;
        $main_img     = get_post_meta($post_id, '_evazar_main_image', true) ?: get_the_post_thumbnail_url($post_id, 'full');
        $desc         = get_post_meta($post_id, 'rank_math_description', true) ?: wp_trim_words(get_the_excerpt($post_id), 30);
        $site_name    = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';

        if (function_exists('evazar_cdn_image_url') && $main_img) {
            $main_img = evazar_cdn_image_url($main_img);
        }

        $rating_val          = floatval($rating);
        $stored_rating_count = intval(get_post_meta($post_id, '_evazar_rating_count', true));

        $product_schema = [
            '@type'       => 'Product',
            '@id'         => get_permalink($post_id) . '#product',
            'name'        => get_the_title($post_id),
            'description' => esc_html($desc),
            'sku'         => (string)$sku,
        ];

        if (!empty($main_img)) {
            $product_schema['image'] = [esc_url($main_img)];
        }

        if (!empty($brand) && !in_array($brand, ['Ø¯ÛØ¬ÛâÚ©Ø§ÙØ§', 'Ø¯ÛØ¬ÛÚ©Ø§ÙØ§'])) {
            $product_schema['brand'] = [
                '@type' => 'Brand',
                'name'  => esc_html($brand)
            ];
        }

        if ($stored_rating_count > 0 && $rating_val > 0) {
            $product_schema['aggregateRating'] = [
                '@type'       => 'AggregateRating',
                'ratingValue' => (string)$rating_val,
                'bestRating'  => '5',
                'worstRating' => '1',
                'ratingCount' => (string)$stored_rating_count
            ];
        }

        if (!empty($price)) {
            $clean_price = preg_replace('/[^0-9]/', '', $price);
            if (!empty($clean_price)) {
                $product_schema['offers'] = [
                    '@type'           => 'Offer',
                    'price'           => (string)$clean_price,
                    'priceCurrency'   => 'IRT',
                    'priceValidUntil' => date('Y-12-31', strtotime('+1 year')),
                    'availability'    => 'https://schema.org/InStock',
                    'url'             => get_permalink($post_id),
                    'seller'          => [
                        '@type' => 'Organization',
                        'name'  => $site_name
                    ]
                ];
            }
        }

        $data['Product'] = $product_schema;
    }
    return $data;
}

// Ù) Ø®Ø±ÙØ¬Û ÙØªØ§ØªÚ¯ Ø¬Ø§ÛÚ¯Ø²ÛÙ Ø¯Ø± ØµÙØ±Øª ØºÛØ±ÙØ¹Ø§Ù Ø¨ÙØ¯Ù Ø±ÙÚ©âÙØ« (Zero-Conflict Fallback)
add_action('wp_head', 'evazar_fallback_seo_meta_tags', 1);
function evazar_fallback_seo_meta_tags() {
    if (defined('RANK_MATH_VERSION') || defined('WPSEO_VERSION')) {
        return;
    }
    if (evazar_is_brand_directory()) {
        $desc = get_option('evazar_opt_brands_page_desc', '');
        if (empty(trim($desc))) {
            $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
            $desc      = 'Ø¨Ø±Ø±Ø³Û ÙÛÙØª Ø±ÙØ²Ø ÙÙØ§ÛØ³Ù ÙØ´Ø®ØµØ§Øª ÙÙÛ Ù Ø®Ø±ÛØ¯ ÙØ³ØªÙÛÙ Ø¨Ø§ Ø¨ÙØªØ±ÛÙ Ú¯Ø§Ø±Ø§ÙØªÛ Ù ØªØ¶ÙÛÙ Ø§ØµØ§ÙØª Ú©Ø§ÙØ§ Ø¯Ø± ' . $site_name . '.';
        }
        echo '<meta name="description" content="' . esc_attr(wp_strip_all_tags($desc)) . '" />' . "\n";
        return;
    }
    if (evazar_is_category_directory()) {
        $desc = get_option('evazar_opt_categories_page_desc', '');
        if (empty(trim($desc))) {
            $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
            $desc      = 'ÙØ´Ø§ÙØ¯Ù ÙÛØ³Øª Ù Ø±Ø§ÙÙÙØ§Û Ø¬Ø§ÙØ¹ Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§Û Ú©Ø§ÙØ§Û ' . $site_name . 'Ø ÙÙØ§ÛØ³Ù ÙÛÙØªâÙØ§Ø ÙÙØ¯ Ù Ø¨Ø±Ø±Ø³Û Ù Ø®Ø±ÛØ¯ ÙÙØ´ÙÙØ¯Ø§ÙÙ Ø§Ø² ÙØ¹ØªØ¨Ø±ØªØ±ÛÙ ÙØ±ÙØ´Ú¯Ø§ÙâÙØ§.';
        }
        echo '<meta name="description" content="' . esc_attr(wp_strip_all_tags($desc)) . '" />' . "\n";
        return;
    }
    if (is_singular('evazar_product')) {
        $post_id   = get_the_ID();
        $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
        $desc      = get_post_meta($post_id, 'rank_math_description', true);
        if (empty($desc)) {
            $desc = "ÙØ´Ø®ØµØ§Øª ÙÙÛØ ÙÛÙØª Ù Ø®Ø±ÛØ¯ Ø§ÛÙØªØ±ÙØªÛ " . get_the_title($post_id) . " Ø¯Ø± " . $site_name . " Ø¨Ø§ Ø¶ÙØ§ÙØª Ø§ØµØ§ÙØª Ú©Ø§ÙØ§.";
        }
        echo '<meta name="description" content="' . esc_attr($desc) . '" />' . "\n";
    } elseif (is_tax(['evazar_category', 'evazar_brand'])) {
        $term = get_queried_object();
        if ($term && !empty($term->term_id)) {
            $custom_desc = get_term_meta($term->term_id, '_evazar_meta_description', true) ?: get_term_meta($term->term_id, 'rank_math_description', true);
            if (!empty(trim($custom_desc))) {
                $desc = trim($custom_desc);
            } else {
                $site_name = get_bloginfo('name') ?: 'Ø§ÛÙØ§Ø²Ø§Ø±';
                if ($term->taxonomy === 'evazar_brand') {
                    $tpl = get_option('evazar_opt_brand_meta_desc_template', 'ÙØ´Ø§ÙØ¯Ù ÙÛØ³Øª ÙÛÙØª Ø±ÙØ²Ø ÙØ´Ø®ØµØ§Øª ÙÙÛ Ù Ø®Ø±ÛØ¯ Ø¢ÙÙØ§ÛÙ Ø§ÙÙØ§Ø¹ {brand} Ø¯Ø± {site_name} Ø¨Ø§ ØªØ¶ÙÛÙ Ø§ØµØ§ÙØª Ù Ø§Ø±Ø³Ø§Ù Ø³Ø±ÛØ¹.');
                    if (empty(trim($tpl))) $tpl = 'ÙØ´Ø§ÙØ¯Ù ÙÛØ³Øª ÙÛÙØª Ø±ÙØ²Ø ÙØ´Ø®ØµØ§Øª ÙÙÛ Ù Ø®Ø±ÛØ¯ Ø¢ÙÙØ§ÛÙ Ø§ÙÙØ§Ø¹ {brand} Ø¯Ø± {site_name} Ø¨Ø§ ØªØ¶ÙÛÙ Ø§ØµØ§ÙØª Ù Ø§Ø±Ø³Ø§Ù Ø³Ø±ÛØ¹.';
                    $desc = trim(str_replace(['{brand}', '{site_name}', '{title}'], [$term->name, $site_name, $term->name], $tpl));
                } else {
                    $tpl = get_option('evazar_opt_category_meta_desc_template', 'ÙØ´Ø§ÙØ¯Ù ÙÛØ³Øª ÙÛÙØª Ø±ÙØ²Ø ÙØ´Ø®ØµØ§Øª ÙÙÛ Ù Ø®Ø±ÛØ¯ Ø¢ÙÙØ§ÛÙ Ø§ÙÙØ§Ø¹ {category} Ø¯Ø± {site_name} Ø¨Ø§ ØªØ¶ÙÛÙ Ø§ØµØ§ÙØª Ù Ø§Ø±Ø³Ø§Ù Ø³Ø±ÛØ¹.');
                    if (empty(trim($tpl))) $tpl = 'ÙØ´Ø§ÙØ¯Ù ÙÛØ³Øª ÙÛÙØª Ø±ÙØ²Ø ÙØ´Ø®ØµØ§Øª ÙÙÛ Ù Ø®Ø±ÛØ¯ Ø¢ÙÙØ§ÛÙ Ø§ÙÙØ§Ø¹ {category} Ø¯Ø± {site_name} Ø¨Ø§ ØªØ¶ÙÛÙ Ø§ØµØ§ÙØª Ù Ø§Ø±Ø³Ø§Ù Ø³Ø±ÛØ¹.';
                    $desc = trim(str_replace(['{category}', '{site_name}', '{title}'], [$term->name, $site_name, $term->name], $tpl));
                }
            }
            echo '<meta name="description" content="' . esc_attr($desc) . '" />' . "\n";
        }
    }
}

// Ø²) Ø¨ÙÛÙÙâØ³Ø§Ø²Û Ù¾ÛØ´Ø±ÙØªÙ Ø³Ø¦ÙÛ Ù¾ÛØ¬ÛÙÛØ´Ù: Ø¬ÙÙÚ¯ÛØ±Û Ø§Ø² Ø±ÙØ§Ø¨Øª ØµÙØ­Ø§Øª Û² Ø¨Ù Ø¨Ø¹Ø¯ Ø¨Ø§ ØµÙØ­Ù Ø§ØµÙÛ (Anti-Cannibalization)
add_filter('rank_math/frontend/robots', 'evazar_seo_pagination_robots_filter', 99);
function evazar_seo_pagination_robots_filter($robots) {
    if (is_archive() || is_tax(['evazar_category', 'evazar_brand']) || is_post_type_archive('evazar_product')) {
        $paged = max(1, intval(get_query_var('paged', 1)), intval(get_query_var('page', 1)));
        if ($paged > 1) {
            $robots['index'] = 'noindex';
            $robots['follow'] = 'follow';
        }
    }
    return $robots;
}

add_filter('wp_robots', 'evazar_seo_native_robots_filter', 99);
function evazar_seo_native_robots_filter($robots) {
    if (is_archive() || is_tax(['evazar_category', 'evazar_brand']) || is_post_type_archive('evazar_product')) {
        $paged = max(1, intval(get_query_var('paged', 1)), intval(get_query_var('page', 1)));
        if ($paged > 1) {
            $robots['noindex'] = true;
            $robots['follow'] = true;
        }
    }
    return $robots;
}


require_once plugin_dir_path(__FILE__) . 'batch-processor.php';

// ==========================================
// Ø­) Ø³ÛØ³ØªÙ Ø³Ø§Ø¯Ù Ù Ø³Ø±ÛØ¹ ÙÙÙ ÙØ­ØªÙØ§Û Ø¯Ø³ØªÙâÙØ§ Ù Ø¨Ø±ÙØ¯ÙØ§ (1-Click AJAX Lock)
// ==========================================

// Ø§ÙØ²ÙØ¯Ù Ø³ØªÙÙ Ø¨Ù Ø¬Ø¯ÙÙ Ø¯Ø³ØªÙâØ¨ÙØ¯ÛâÙØ§ Ù Ø¨Ø±ÙØ¯ÙØ§ Ø¯Ø± Ù¾ÛØ´Ø®ÙØ§Ù
add_filter('manage_edit-evazar_category_columns', 'evazar_core_add_lock_column');
add_filter('manage_edit-evazar_brand_columns', 'evazar_core_add_lock_column');
function evazar_core_add_lock_column($columns) {
    $columns['evazar_lock'] = 'ÙÙÙ ÙØ­ØªÙØ§ (Ø¯Ø³ØªÛ / AI)';
    return $columns;
}

// Ø±ÙØ¯Ø± Ø¯Ú©ÙÙ ØªØ¹Ø§ÙÙÛ Ø§ÛØ¬Ú©Ø³ Ø¯Ø± Ø³ØªÙÙ Ø¬Ø¯ÙÙ
add_filter('manage_evazar_category_custom_column', 'evazar_core_render_lock_column', 10, 3);
add_filter('manage_evazar_brand_custom_column', 'evazar_core_render_lock_column', 10, 3);
function evazar_core_render_lock_column($content, $column_name, $term_id) {
    if ($column_name === 'evazar_lock') {
        $is_locked = get_term_meta($term_id, '_evazar_lock_seo_content', true) === 'yes';
        $btn_class = $is_locked ? 'evazar-lock-pill is-locked' : 'evazar-lock-pill is-unlocked';
        $label = $is_locked ? 'ð ÙÙÙ Ø¯Ø³ØªÛ' : 'ð¤ ÙØ¬Ø§Ø² Ø¨Ø±Ø§Û AI';
        $title = $is_locked ? 'Ú©ÙÛÚ© Ú©ÙÛØ¯ ØªØ§ Ø¨Ø±Ø§Û Ø¨Ø§Ø²ÙÙÛØ³Û ÙÙØ´ ÙØµÙÙØ¹Û Ø¢Ø²Ø§Ø¯ Ø´ÙØ¯' : 'Ú©ÙÛÚ© Ú©ÙÛØ¯ ØªØ§ ÙÙÙ Ø´ÙØ¯ (Ø¬ÙÙÚ¯ÛØ±Û ÙØ·Ø¹Û Ø§Ø² ØªØºÛÛØ± ØªÙØ³Ø· ÙÙØ´ ÙØµÙÙØ¹Û)';
        $nonce = wp_create_nonce('evazar_lock_term_' . $term_id);

        return sprintf(
            '<button type="button" class="%s" data-term-id="%d" data-nonce="%s" title="%s">%s</button>',
            esc_attr($btn_class),
            intval($term_id),
            esc_attr($nonce),
            esc_attr($title),
            esc_html($label)
        );
    }
    return $content;
}

// ÙÙØ¯ÙØ± Ø§ÛØ¬Ú©Ø³ Ø³Ø±ÛØ¹ Ø¨Ø±Ø§Û ØªØºÛÛØ± ÙØ¶Ø¹ÛØª ÙÙÙ
add_action('wp_ajax_evazar_toggle_term_lock', 'evazar_core_ajax_toggle_term_lock');
function evazar_core_ajax_toggle_term_lock() {
    $term_id = intval($_POST['term_id'] ?? 0);
    if ($term_id <= 0) {
        wp_send_json_error(['message' => 'Ø´ÙØ§Ø³Ù ÙØ§ÙØ¹ØªØ¨Ø± Ø§Ø³Øª.']);
    }

    check_ajax_referer('evazar_lock_term_' . $term_id, 'nonce');

    if (!current_user_can('manage_categories')) {
        wp_send_json_error(['message' => 'Ø¹Ø¯Ù Ø¯Ø³ØªØ±Ø³Û Ú©Ø§ÙÛ']);
    }

    $current = get_term_meta($term_id, '_evazar_lock_seo_content', true);
    $new_status = ($current === 'yes') ? 'no' : 'yes';
    update_term_meta($term_id, '_evazar_lock_seo_content', $new_status);

    wp_send_json_success([
        'locked' => ($new_status === 'yes'),
        'label'  => ($new_status === 'yes') ? 'ð ÙÙÙ Ø¯Ø³ØªÛ' : 'ð¤ ÙØ¬Ø§Ø² Ø¨Ø±Ø§Û AI',
        'title'  => ($new_status === 'yes') ? 'Ú©ÙÛÚ© Ú©ÙÛØ¯ ØªØ§ Ø¨Ø±Ø§Û Ø¨Ø§Ø²ÙÙÛØ³Û ÙÙØ´ ÙØµÙÙØ¹Û Ø¢Ø²Ø§Ø¯ Ø´ÙØ¯' : 'Ú©ÙÛÚ© Ú©ÙÛØ¯ ØªØ§ ÙÙÙ Ø´ÙØ¯ (Ø¬ÙÙÚ¯ÛØ±Û ÙØ·Ø¹Û Ø§Ø² ØªØºÛÛØ± ØªÙØ³Ø· ÙÙØ´ ÙØµÙÙØ¹Û)'
    ]);
}

// ÙÙØ§ÛØ´ Ú¯Ø²ÛÙÙ ÙÙÙ Ø¯Ø± ÙØ±Ù ÙÛØ±Ø§ÛØ´ Ø¯Ø³ØªÙ Ù Ø¨Ø±ÙØ¯
add_action('evazar_category_edit_form_fields', 'evazar_core_render_term_lock_field', 10, 2);
add_action('evazar_brand_edit_form_fields', 'evazar_core_render_term_lock_field', 10, 2);
function evazar_core_render_term_lock_field($term, $taxonomy) {
    $is_locked = get_term_meta($term->term_id, '_evazar_lock_seo_content', true);
    ?>
    <tr class="form-field">
        <th scope="row"><label for="evazar_lock_seo_content">ÙÙÙ ÙØ­ØªÙØ§Û ÙÙØ´ ÙØµÙÙØ¹Û</label></th>
        <td>
            <label style="font-weight: 600; cursor: pointer;">
                <input type="checkbox" name="evazar_lock_seo_content" id="evazar_lock_seo_content" value="yes" <?php checked($is_locked, 'yes'); ?>>
                ð ÙÙÙ Ø¯Ø³ØªÛ ÙØ­ØªÙØ§ (Ø¬ÙÙÚ¯ÛØ±Û Û±Û°Û°Ùª Ø§Ø² ÙÛØ±Ø§ÛØ´ ÛØ§ Ø¨Ø§Ø²ÙÙÛØ³Û ØªÙØ³Ø· ÙÙØ´ ÙØµÙÙØ¹Û)
            </label>
            <p class="description">Ø§Ú¯Ø± Ø§ÛÙ Ú¯Ø²ÛÙÙ ØªÛÚ© Ø®ÙØ±Ø¯Ù Ø¨Ø§Ø´Ø¯Ø Ø³ÛØ³ØªÙ ÙÙØ´ ÙØµÙÙØ¹Û Ù Ø¹ÙÙÛØ§Øª Ø¯Ø³ØªÙâØ¬ÙØ¹Û Ø¨Ù ÙÛÚ ÙØ¬Ù ØªÙØ¶ÛØ­Ø§Øª Ø§ÛÙ Ø¨Ø±Ú¯Ù Ø±Ø§ ØªØºÛÛØ± ÙØ®ÙØ§ÙÙØ¯ Ø¯Ø§Ø¯.</p>
        </td>
    </tr>
    <?php
}

// Ø°Ø®ÛØ±Ù ÙÛÙØ¯ ÙØ±Ù ÙÛØ±Ø§ÛØ´ Ø¯Ø³ØªÙ Ù Ø¨Ø±ÙØ¯
add_action('edited_evazar_category', 'evazar_core_save_term_lock_field');
add_action('edited_evazar_brand', 'evazar_core_save_term_lock_field');
function evazar_core_save_term_lock_field($term_id) {
    if (isset($_POST['evazar_lock_seo_content']) && $_POST['evazar_lock_seo_content'] === 'yes') {
        update_term_meta($term_id, '_evazar_lock_seo_content', 'yes');
    } else {
        delete_term_meta($term_id, '_evazar_lock_seo_content');
    }
}

// Ø§Ø³Ú©Ø±ÛÙ¾Øª Ù Ø§Ø³ØªØ§ÛÙ ÙÙÙâØ§ÙØ¹Ø§Ø¯Ù Ø³Ø¨Ú© Ø§ÛØ¬Ú©Ø³ Ø¯Ø± Ù¾Ø§ÙØ±ÙÛ ØµÙØ­Ø§Øª ÙÛØ³Øª Ø¯Ø³ØªÙâØ¨ÙØ¯Û Ù Ø¨Ø±ÙØ¯
add_action('admin_footer-edit-tags.php', 'evazar_core_admin_lock_script');
function evazar_core_admin_lock_script() {
    $screen = get_current_screen();
    if (!$screen || !in_array($screen->taxonomy, ['evazar_category', 'evazar_brand'], true)) {
        return;
    }
    ?>
    <style>
        .evazar-lock-pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 4px 10px;
            font-size: 11px;
            font-weight: bold;
            border-radius: 20px;
            border: 1px solid transparent;
            cursor: pointer;
            transition: all 0.2s ease-in-out;
            outline: none;
            user-select: none;
        }
        .evazar-lock-pill.is-locked {
            background-color: #d4edda;
            color: #155724;
            border-color: #c3e6cb;
        }
        .evazar-lock-pill.is-locked:hover {
            background-color: #c3e6cb;
        }
        .evazar-lock-pill.is-unlocked {
            background-color: #f1f3f5;
            color: #495057;
            border-color: #dee2e6;
        }
        .evazar-lock-pill.is-unlocked:hover {
            background-color: #e9ecef;
            color: #212529;
        }
        .evazar-lock-pill.is-busy {
            opacity: 0.5;
            pointer-events: none;
        }
        .column-evazar_lock {
            width: 140px;
            text-align: center;
        }
    </style>
    <script>
    jQuery(document).ready(function($) {
        $(document).on('click', '.evazar-lock-pill', function(e) {
            e.preventDefault();
            var $btn = $(this);
            var termId = $btn.data('term-id');
            var nonce = $btn.data('nonce');

            $btn.addClass('is-busy');

            $.post(ajaxurl, {
                action: 'evazar_toggle_term_lock',
                term_id: termId,
                nonce: nonce
            }, function(response) {
                $btn.removeClass('is-busy');
                if (response.success && response.data) {
                    var data = response.data;
                    $btn.text(data.label);
                    $btn.attr('title', data.title);
                    if (data.locked) {
                        $btn.removeClass('is-unlocked').addClass('is-locked');
                    } else {
                        $btn.removeClass('is-locked').addClass('is-unlocked');
                    }
                } else {
                    alert('Ø®Ø·Ø§ Ø¯Ø± Ø°Ø®ÛØ±Ù ÙØ¶Ø¹ÛØª ÙÙÙ.');
                }
            }).fail(function() {
                $btn.removeClass('is-busy');
                alert('Ø®Ø·Ø§Û Ø§Ø±ØªØ¨Ø§Ø· Ø¨Ø§ Ø³Ø±ÙØ±.');
            });
        });
    });
    </script>
    <?php
}
