# EVazar Core 2.8.61
- Product Index: price, stock, brand, SKU/DKP, views, rating and satisfaction index tables.
- Incremental Product Index backfill: 250 products per scheduled run.
- Import and live-price/stock sync update the product index.
- Stock sync remains 50 products every 5 minutes and now correctly passes force-fresh to the Worker.
- OpenAI is Worker-first when Cloudflare Worker + internal token are configured; local OpenAI key is optional in this mode.
