# Evazar Core 2.8.72

- Product-page live inquiry now forces a fresh Worker/Digikala check, bypassing the local 90-second inquiry transient.
- Live availability detection checks other sellable variants when `default_variant` is incomplete.
- Explicit unavailable signals always override positive/fallback signals.
- Bundled Cloudflare Worker updated to 1.11.1.
- Plugin header version synchronized to 2.8.72.
