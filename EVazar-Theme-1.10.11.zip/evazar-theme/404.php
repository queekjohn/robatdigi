<?php
/**
 * The template for displaying 404 pages (not found)
 * Evazar Theme - Model 1: Modern Minimal with Intelligent Live Search
 */

get_header();

$opt_404_title    = get_option('evazar_opt_404_title', 'صفحه‌ای که دنبالش بودید پیدا نشد!');
$opt_404_subtitle = get_option('evazar_opt_404_subtitle', 'ممکن است آدرس را اشتباه تایپ کرده باشید یا این کالا دیگر در فروشگاه موجود نباشد.');

// دریافت ۳ دسته برتر جهت چیپ‌های دسترسی سریع
$popular_terms = get_terms([
    'taxonomy'   => 'evazar_category',
    'number'     => 3,
    'orderby'    => 'count',
    'order'      => 'DESC',
    'hide_empty' => true,
]);
?>

<main id="primary" class="site-main evazar-404-main">
    <div class="evazar-404-container">
        <div class="evazar-404-card">
            
            <div class="evazar-404-code">۴۰۴</div>
            
            <h1 class="evazar-404-title"><?php echo esc_html($opt_404_title); ?></h1>
            
            <p class="evazar-404-desc"><?php echo esc_html($opt_404_subtitle); ?></p>
            
            <!-- ماژول جستجوی زنده، هوشمند و فوق‌سریع ایوازار -->
            <div class="evazar-404-search-box">
                <?php
                if (function_exists('evazar_render_search_bar')) {
                    evazar_render_search_bar('search_404');
                } else {
                ?>
                <form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
                    <input type="search" class="search-field" placeholder="جستجو در کالاها..." value="<?php echo get_search_query(); ?>" name="s" />
                    <button type="submit" class="search-submit">جستجو</button>
                </form>
                <?php } ?>
            </div>

            <!-- چیپ‌های دسترسی سریع و پرطرفدار -->
            <div class="evazar-404-chips-title">یا از بخش‌های پرطرفدار زیر دیدن فرمایید:</div>
            
            <div class="evazar-404-chips">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="evazar-404-chip">
                    <span>🏠 صفحه اصلی</span>
                </a>

                <?php if (!empty($popular_terms) && !is_wp_error($popular_terms)): ?>
                    <?php foreach ($popular_terms as $p_term): ?>
                        <a href="<?php echo esc_url(get_term_link($p_term)); ?>" class="evazar-404-chip">
                            <span>🏷️ <?php echo esc_html($p_term->name); ?></span>
                        </a>
                    <?php endforeach; ?>
                <?php else: ?>
                    <a href="<?php echo esc_url(home_url('/#products')); ?>" class="evazar-404-chip">
                        <span>🔥 کالاهای پرفروش</span>
                    </a>
                    <a href="<?php echo esc_url(home_url('/#categories')); ?>" class="evazar-404-chip">
                        <span>📦 دسته‌بندی کالاها</span>
                    </a>
                <?php endif; ?>
            </div>

        </div>
    </div>
</main>

<?php
get_footer();
