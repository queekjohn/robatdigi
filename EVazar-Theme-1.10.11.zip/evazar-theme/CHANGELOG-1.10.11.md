# EVazar Theme 1.10.11

- Fixed an archive price-filter state bug where the slider's smart/default maximum could be rounded into a real `max_price` form value even when the user had never enabled the price filter.
- Kept smart minimum/maximum values as UI bounds only until the user explicitly changes a price handle or numeric field.
- Made slider endpoints exact so the real smart minimum/maximum are never rounded inward by the step size.
- Hardened pagination/sort URL merging so `min_price`/`max_price` are copied only while the price filter is explicitly active; stale/default values are removed from navigation URLs.
- No changes to EVazar Core 2.8.66, Worker 1.9.9, image delivery, archive-card markup, or current performance/image behavior.
