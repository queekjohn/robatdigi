# EVazar Theme 1.10.6

- Reduced archive/home product image payloads by requesting 360px CDN variants without storing files on the host.
- Product gallery thumbnails now use 160px CDN variants while keeping the full image URL for the actual gallery.
- Lightbox thumbnails now use 120px CDN variants.
- Added intrinsic 800x800 dimensions to the main product image to reduce layout shifts.
- Archive filter CSS/JS now loads only on relevant product archive, taxonomy, search, and directory views.
- Live product price inquiry is scheduled during browser idle time with a short timeout fallback so initial rendering and image loading receive priority.
- Added a preconnect resource hint for the configured image CDN.
