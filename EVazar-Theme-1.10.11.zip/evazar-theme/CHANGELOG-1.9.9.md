# EVazar Theme 1.9.9

- Separated smart price bounds from the user-selected price filter state.
- The price range remains visually inactive until the user actually selects a minimum or maximum price.
- Empty price inputs are no longer submitted through archive-filter AJAX requests.
- Archive base URL is normalized so filter/sort AJAX never treats `admin-ajax.php` or query parameters as the archive base.
- Filter count no longer double-counts the stock switch.
