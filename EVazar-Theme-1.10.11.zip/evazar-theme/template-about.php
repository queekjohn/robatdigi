<?php
/**
 * Template Name: برگه درباره ما (ایوازار)
 * Description: قالب اختصاصی برگه درباره ما - پلتفرم شفاف همکاری در فروش (مدل ۱ با بخش سوالات متداول تعاملی)
 */

get_header();

// خواندن تنظیمات اختصاصی برگه درباره ما
$hero_badge        = get_option('evazar_opt_about_hero_badge', 'سامانه تخصصی همکاری در فروش و هدایت هوشمند خرید');
$hero_title        = get_option('evazar_opt_about_hero_title', 'انتخابی دقیق‌تر، خریدی مطمئن‌تر و بدون واسطه از دیجی‌کالا');
$hero_desc         = get_option('evazar_opt_about_hero_desc', 'ایوازار یک پل هوشمند و مرجع مستقل برای بررسی، مقایسه و کشف باارزش‌ترین کالاهای بازار آنلاین است. ما به شما کمک می‌کنیم در میان میلیون‌ها کالای موجود، باکیفیت‌ترین محصولات را با بهترین قیمت و مستقیم از طریق بستر امن دیجی‌کالا خریداری کنید.');

$stat1_num         = get_option('evazar_opt_about_stat1_num', '+۵۰,۰۰۰');
$stat1_txt         = get_option('evazar_opt_about_stat1_txt', 'کالای پایش‌شده و ارزیابی‌شده');
$stat2_num         = get_option('evazar_opt_about_stat2_num', '۰ تومان');
$stat2_txt         = get_option('evazar_opt_about_stat2_txt', 'کارمزد یا هزینه اضافه برای خریدار');
$stat3_num         = get_option('evazar_opt_about_stat3_num', '۲۴/۷');
$stat3_txt         = get_option('evazar_opt_about_stat3_txt', 'رصد لحظه‌ای تخفیف‌های واقعی');
$stat4_num         = get_option('evazar_opt_about_stat4_num', '۱۰۰٪');
$stat4_txt         = get_option('evazar_opt_about_stat4_txt', 'پرداخت مستقیم در درگاه شاپرک دیجی‌کالا');

$disclosure_title  = get_option('evazar_opt_about_disclosure_title', 'بیانیه شفافیت در همکاری در فروش (Affiliate Disclosure)');
$disclosure_text   = get_option('evazar_opt_about_disclosure_text', "ایوازار چگونه درآمد کسب می‌کند؟\nما به عنوان پارتنر تاییدشده سیستم همکاری در فروش رسمی (افیلیو دیجی‌کالا)، در ازای معرفی خریداران و در صورت انجام خرید نهایی، پورسانت اندکی از فروشگاه مرجع دریافت می‌کنیم. این فرآیند هیچ هزینه، کارمزد یا افزایش قیمتی برای شما ندارد و شما دقیقا با همان قیمت، تخفیف‌ها و گارانتی‌های رسمی خرید می‌کنید. این مدل به ما امکان می‌دهد تمام ابزارها و نقد و بررسی‌ها را به صورت ۱۰۰٪ رایگان و بدون تبلیغات آزاردهنده در اختیارتان بگذاریم.");

$faq_enable        = get_option('evazar_opt_about_faq_enable', '1');
$faq_title         = get_option('evazar_opt_about_faq_title', 'پرسش‌های متداول درباره ایوازار و نحوه خرید');
$faq_raw           = get_option('evazar_opt_about_faq_items', "آیا خرید از ایوازار هزینه یا کارمزد اضافی دارد؟ | خیر، به هیچ وجه. شما دقیقا با همان قیمت مصوب دیجی‌کالا و بدون حتی یک ریال هزینه اضافه خرید می‌کنید.\nآیا کالاها گارانتی و مهلت بازگشت دارند؟ | بله، تمامی سفارش‌ها مستقیماً با ضمانت ۷ روزه بازگشت وجه، تضمین اصالت فیزیکی و فاکتور رسمی دیجی‌کالا ارائه می‌شوند.\nپرداخت وجه در چه درگاهی انجام می‌شود؟ | پرداخت تماماً در درگاه امن شاپرک تحت نظارت بانک مرکزی و متعلق به دیجی‌کالا صورت می‌پذیرد.\nارسال سفارش‌ها چگونه انجام می‌شود؟ | تحویل کالا با بسته‌بندی پلمپ و اصالت کالا توسط ناوگان اکسپرس و پست دیجی‌کالا به سراسر کشور انجام می‌شود.");

$cta_title         = get_option('evazar_opt_about_cta_title', 'خریدی هوشمندانه‌تر را از همین امروز تجربه کنید');
$cta_desc          = get_option('evazar_opt_about_cta_desc', 'هزاران کالای بررسی‌شده با تخفیف‌های واقعی و ضمانت رسمی دیجی‌کالا در انتظار انتخاب شماست.');
$cta_btn           = get_option('evazar_opt_about_cta_btn', 'ورود به کاتالوگ کالاهای منتخب');
$cta_link          = get_option('evazar_opt_about_cta_link', home_url('/'));

// تجزیه سوالات متداول
$faq_items = [];
if (!empty($faq_raw)) {
    $lines = explode("\n", str_replace("\r", "", $faq_raw));
    foreach ($lines as $line) {
        $line = trim($line);
        if (empty($line)) continue;
        if (strpos($line, '|') !== false) {
            $parts = explode('|', $line, 2);
            $faq_items[] = [
                'q' => trim($parts[0]),
                'a' => trim($parts[1])
            ];
        } else {
            $faq_items[] = [
                'q' => $line,
                'a' => ''
            ];
        }
    }
}
?>

<main id="primary" class="site-main evazar-about-page">
    <div class="evazar-about-wrap">
        
        <!-- ۱. هیرو بنر گرادیانی مدرن -->
        <section class="evazar-about-hero">
            <?php if (!empty($hero_badge)): ?>
                <span class="ab-hero-badge"><?php echo esc_html($hero_badge); ?></span>
            <?php endif; ?>
            
            <h1 class="ab-hero-title"><?php echo esc_html($hero_title); ?></h1>
            
            <?php if (!empty($hero_desc)): ?>
                <p class="ab-hero-desc"><?php echo nl2br(esc_html($hero_desc)); ?></p>
            <?php endif; ?>
        </section>

        <!-- ۲. کارت‌های ۴گانه آمار کلیدی -->
        <section class="ab-stats-grid">
            <div class="ab-stat-box">
                <div class="ab-stat-number"><?php echo esc_html(evazar_to_fa_num($stat1_num)); ?></div>
                <div class="ab-stat-label"><?php echo esc_html($stat1_txt); ?></div>
            </div>
            <div class="ab-stat-box">
                <div class="ab-stat-number"><?php echo esc_html(evazar_to_fa_num($stat2_num)); ?></div>
                <div class="ab-stat-label"><?php echo esc_html($stat2_txt); ?></div>
            </div>
            <div class="ab-stat-box">
                <div class="ab-stat-number"><?php echo esc_html(evazar_to_fa_num($stat3_num)); ?></div>
                <div class="ab-stat-label"><?php echo esc_html($stat3_txt); ?></div>
            </div>
            <div class="ab-stat-box">
                <div class="ab-stat-number"><?php echo esc_html(evazar_to_fa_num($stat4_num)); ?></div>
                <div class="ab-stat-label"><?php echo esc_html($stat4_txt); ?></div>
            </div>
        </section>

        <!-- ۳. بدنه اصلی محتوا و شفافیت خرید -->
        <div class="ab-body-card">

            <!-- مسیر ۴ مرحله‌ای خرید شفاف -->
            <div class="ab-heading-row">
                <h3>ایوازار چگونه کار می‌کند؟ (مسیر ساده و شفاف خرید)</h3>
                <p>شفافیت کامل از لحظه ورود به سایت تا تحویل کالا درب منزل شما</p>
            </div>

            <div class="ab-pillars-4">
                <div class="ab-pillar-item">
                    <span class="ab-pillar-icon">🔎</span>
                    <h4>۱. کشف و پایش بهترین کالاها</h4>
                    <p>الگوریتم‌های هوشمند و کارشناسان ما، کالاهای با بالاترین امتیاز رضایت خریداران و بهترین قیمت را شناسایی و دست‌چین می‌کنند.</p>
                </div>
                <div class="ab-pillar-item">
                    <span class="ab-pillar-icon">📝</span>
                    <h4>۲. نقد بی‌طرفانه و شفاف</h4>
                    <p>نقاط قوت، نقاط ضعف و مشخصات فنی واقعی کالا بدون هیچ‌گونه جانبداری ثبت می‌شود تا شما با آگاهی کامل تصمیم بگیرید.</p>
                </div>
                <div class="ab-pillar-item">
                    <span class="ab-pillar-icon">🔗</span>
                    <h4>۳. اتصال مستقیم به دیجی‌کالا</h4>
                    <p>با کلیک روی دکمه خرید، مستقیماً به صفحه رسمی همان کالا در دیجی‌کالا با همان قیمت مصوب هدایت می‌شوید.</p>
                </div>
                <div class="ab-pillar-item">
                    <span class="ab-pillar-icon">🚚</span>
                    <h4>۴. پرداخت امن و ارسال رسمی</h4>
                    <p>پرداخت در درگاه رسمی شاپرک دیجی‌کالا انجام شده و سفارش با ضمانت بازگشت ۷ روزه توسط ناوگان دیجی‌کالا ارسال می‌گردد.</p>
                </div>
            </div>

            <!-- جعبه بیانیه شفافیت همکاری در فروش (Affiliate Disclosure) -->
            <?php if (!empty($disclosure_text)): ?>
            <div class="ab-disclosure-card">
                <div class="ab-disclosure-title">
                    <span style="font-size: 1.5rem;">💡</span>
                    <h4><?php echo esc_html($disclosure_title); ?></h4>
                </div>
                <div class="ab-disclosure-text">
                    <?php echo nl2br(esc_html($disclosure_text)); ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- اصول اساسی سه‌گانه -->
            <div class="ab-heading-row">
                <h3>اصول اساسی ما در انتخاب و معرفی کالاها</h3>
                <p>معیارهایی که هرگز بر سر آن‌ها مصالحه نمی‌کنیم</p>
            </div>

            <div class="ab-values-3">
                <div class="ab-pillar-item">
                    <span class="ab-pillar-icon">⚖️</span>
                    <h4>استقلال کامل در نقد</h4>
                    <p>ما از هیچ فروشنده‌ای وجهی برای برجسته‌سازی کالا دریافت نمی‌کنیم؛ ارزش واقعی کالا تنها دلیل معرفی آن در ایوازار است.</p>
                </div>
                <div class="ab-pillar-item">
                    <span class="ab-pillar-icon">🛡️</span>
                    <h4>فیلتر فروشندگان نامعتبر</h4>
                    <p>تنها کالاهایی در ایوازار نمایش داده می‌شوند که فروشنده دارای امتیاز رضایت مشتریان بالا، نرخ بازگشت پایین و تعهد به اصالت کالا باشد.</p>
                </div>
                <div class="ab-pillar-item">
                    <span class="ab-pillar-icon">⚡</span>
                    <h4>به‌روزرسانی خودکار قیمت‌ها</h4>
                    <p>موتور هوشمند ایوازار به طور پیوسته قیمت‌ها و موجودی انبار را با دیجی‌کالا همگام می‌کند تا اطلاعات کالا همواره دقیق باشد.</p>
                </div>
            </div>

            <!-- ۴. بخش سوالات متداول آکاردئونی (FAQ Accordion) -->
            <?php if ($faq_enable === '1' && !empty($faq_items)): ?>
            <div class="ab-faq-section">
                <div class="ab-heading-row">
                    <h3><?php echo esc_html($faq_title); ?></h3>
                    <p>پاسخ به متداول‌ترین پرسش‌های شما درباره فرآیند خرید، قیمت‌ها و خدمات</p>
                </div>

                <div class="ab-faq-list">
                    <?php foreach ($faq_items as $f_idx => $faq): ?>
                        <div class="ab-faq-item <?php echo ($f_idx === 0) ? 'active' : ''; ?>">
                            <button type="button" class="ab-faq-trigger" aria-expanded="<?php echo ($f_idx === 0) ? 'true' : 'false'; ?>">
                                <span><?php echo esc_html($faq['q']); ?></span>
                                <span class="ab-faq-icon">
                                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                </span>
                            </button>
                            <?php if (!empty($faq['a'])): ?>
                                <div class="ab-faq-answer">
                                    <p><?php echo nl2br(esc_html($faq['a'])); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- ۵. بنر پایانی دعوت به اقدام (CTA) -->
            <?php if (!empty($cta_title)): ?>
            <div class="ab-cta-banner">
                <h3><?php echo esc_html($cta_title); ?></h3>
                <?php if (!empty($cta_desc)): ?>
                    <p><?php echo esc_html($cta_desc); ?></p>
                <?php endif; ?>
                <a href="<?php echo esc_url($cta_link ?: home_url('/')); ?>" class="ab-cta-btn">
                    <span><?php echo esc_html($cta_btn ?: 'ورود به کاتالوگ کالاهای منتخب'); ?></span>
                </a>
            </div>
            <?php endif; ?>

        </div> <!-- /.ab-body-card -->

    </div> <!-- /.evazar-about-wrap -->
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const faqItems = document.querySelectorAll('.ab-faq-item');
    faqItems.forEach(function(item) {
        const trigger = item.querySelector('.ab-faq-trigger');
        if (trigger) {
            trigger.addEventListener('click', function(e) {
                e.preventDefault();
                const isActive = item.classList.contains('active');
                
                // بستن بقیه آیتم‌ها جهت تمرکز بصری کاربر
                faqItems.forEach(function(other) {
                    other.classList.remove('active');
                    const otherBtn = other.querySelector('.ab-faq-trigger');
                    if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
                });

                if (!isActive) {
                    item.classList.add('active');
                    trigger.setAttribute('aria-expanded', 'true');
                }
            });
        }
    });
});
</script>

<?php
get_footer();
