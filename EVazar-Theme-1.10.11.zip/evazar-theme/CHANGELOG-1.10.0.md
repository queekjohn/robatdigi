# EVazar Theme 1.10.0

- Availability is now determined by current price > 0.
- Worker `explicit_unavailable` is a hard override even when a stale positive price exists.
- Archive stock filter, stock ordering and live-search stock filtering use the same canonical rule.
- Product Index price remains the fast source for archive availability checks.
