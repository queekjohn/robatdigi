/**
 * Evazar Search - Digikala & Moblak Inspired Ajax Search Controller
 * 100% Native, Vanilla JS, Zero Dependencies, Ultra-Fast
 */

document.addEventListener('DOMContentLoaded', function () {
    const STORAGE_KEY = 'evazar_recent_searches';
    const INSTOCK_KEY = 'evazar_search_instock';
    const MAX_RECENT = 6;
    let searchTimer = null;
    let currentAbortController = null;

    const containers = document.querySelectorAll('.evazar-search-container');
    if (!containers.length) return;

    // بارگذاری یا ذخیره وضعیت سوئیچ موجودی
    let isInstockOnly = localStorage.getItem(INSTOCK_KEY) === 'true';

    // توابع کار با LocalStorage برای تاریخچه جستجو
    function getRecentSearches() {
        try {
            const data = localStorage.getItem(STORAGE_KEY);
            return data ? JSON.parse(data) : [];
        } catch (e) {
            return [];
        }
    }

    function saveRecentSearch(term) {
        term = (term || '').trim();
        if (term.length < 2) return;
        try {
            let list = getRecentSearches();
            const normalizedTerm = normalizeClientText(term);
            list = list.filter(item => normalizeClientText(item) !== normalizedTerm);
            list.unshift(term);
            if (list.length > MAX_RECENT) list = list.slice(0, MAX_RECENT);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
        } catch (e) {}
    }

    function removeRecentSearch(term) {
        try {
            let list = getRecentSearches();
            const normalizedTerm = normalizeClientText(term);
            list = list.filter(item => normalizeClientText(item) !== normalizedTerm);
            localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
        } catch (e) {}
    }

    function clearAllRecentSearches() {
        try {
            localStorage.removeItem(STORAGE_KEY);
        } catch (e) {}
    }

    // راه‌اندازی هر فرم جستجو در صفحه
    containers.forEach(container => {
        const form = container.querySelector('.evazar-search-form');
        const input = container.querySelector('.evazar-search-input');
        const clearBtn = container.querySelector('.evazar-search-clear');
        const mobileClearBtn = container.querySelector('.evazar-search-mobile-clear');
        const dropdown = container.querySelector('.evazar-search-dropdown');
        const instockCheckbox = container.querySelector('.evazar-instock-checkbox');
        const recentSection = container.querySelector('.evazar-section-recent');
        const recentPills = container.querySelector('.evazar-recent-pills');
        const clearRecentBtn = container.querySelector('.evazar-clear-recent-all');
        const popularSection = container.querySelector('.evazar-section-popular');
        const loader = container.querySelector('.evazar-search-loader');
        const liveContent = container.querySelector('.evazar-search-live-content');
        const noResults = container.querySelector('.evazar-search-no-results');
        const didYouMean = container.querySelector('.evazar-did-you-mean');
        const dymLink = container.querySelector('.evazar-dym-link');
        const suggBox = container.querySelector('.evazar-search-suggestions');
        const suggList = container.querySelector('.evazar-suggestions-list');
        const catBox = container.querySelector('.evazar-matched-categories');
        const catList = container.querySelector('.evazar-categories-list');
        const brandBox = container.querySelector('.evazar-matched-brands');
        const brandList = container.querySelector('.evazar-brands-list');
        const viewAllLink = container.querySelector('.evazar-view-all-link');
        let activeSuggIndex = -1;

        // موبایل
        const mobileBack = container.querySelector('.evazar-search-mobile-back');
        const mobileInput = container.querySelector('.evazar-search-mobile-input');

        if (!form || !input || !dropdown) return;

        // تنظیم اولیه سوئیچ موجودی
        if (instockCheckbox) {
            instockCheckbox.checked = isInstockOnly;
            instockCheckbox.addEventListener('change', function () {
                isInstockOnly = this.checked;
                localStorage.setItem(INSTOCK_KEY, isInstockOnly ? 'true' : 'false');
                const q = (input.value || '').trim();
                if (q.length >= 2) {
                    performSearch(q);
                }
            });
        }

        // رندر تاریخچه جستجوهای اخیر
        function renderRecent() {
            if (!recentSection || !recentPills) return;
            const items = getRecentSearches();
            if (!items.length) {
                recentSection.style.display = 'none';
                return;
            }
            recentSection.style.display = 'block';
            recentPills.innerHTML = items.map(term => `
                <div class="evazar-search-pill" data-query="${escapeHtml(term)}">
                    <span>${escapeHtml(term)}</span>
                    <span class="evazar-pill-remove" data-term="${escapeHtml(term)}" title="حذف">✕</span>
                </div>
            `).join('');

            // کلیک روی تگ برای جستجو و انتقال مستقیم به صفحه نتایج
            recentPills.querySelectorAll('.evazar-search-pill').forEach(pill => {
                pill.addEventListener('click', function (e) {
                    if (e.target.classList.contains('evazar-pill-remove')) return;
                    const q = this.getAttribute('data-query');
                    if (!q) return;
                    input.value = q;
                    if (mobileInput) mobileInput.value = q;
                    toggleClearBtn();
                    const searchBase = window.evazar_search_vars ? window.evazar_search_vars.home_url : '/';
                    window.location.href = searchBase + '?s=' + encodeURIComponent(q) + '&post_type=evazar_product';
                });
            });

            // حذف تکی تگ
            recentPills.querySelectorAll('.evazar-pill-remove').forEach(rm => {
                rm.addEventListener('click', function (e) {
                    e.stopPropagation();
                    const t = this.getAttribute('data-term');
                    removeRecentSearch(t);
                    renderRecent();
                });
            });
        }

        if (clearRecentBtn) {
            clearRecentBtn.addEventListener('click', function (e) {
                e.preventDefault();
                clearAllRecentSearches();
                renderRecent();
            });
        }

        // کلیک روی کپسول‌های پرطرفدار و انتقال مستقیم به صفحه نتایج
        if (popularSection) {
            popularSection.querySelectorAll('.evazar-search-pill').forEach(pill => {
                pill.addEventListener('click', function (e) {
                    e.preventDefault();
                    const q = this.getAttribute('data-query');
                    if (!q) return;
                    input.value = q;
                    if (mobileInput) mobileInput.value = q;
                    toggleClearBtn();
                    saveRecentSearch(q);
                    const searchBase = window.evazar_search_vars ? window.evazar_search_vars.home_url : '/';
                    window.location.href = searchBase + '?s=' + encodeURIComponent(q) + '&post_type=evazar_product';
                });
            });
        }

        function setClearState(button, visible) {
            if (!button) return;
            button.classList.toggle('is-visible', visible);
            button.setAttribute('aria-hidden', visible ? 'false' : 'true');
            button.tabIndex = visible ? 0 : -1;
        }

        function toggleClearBtn() {
            const desktopHasValue = !!input && input.value.trim().length > 0;
            const mobileHasValue = !!mobileInput && mobileInput.value.trim().length > 0;
            setClearState(clearBtn, desktopHasValue);
            setClearState(mobileClearBtn, mobileHasValue);
        }

        function clearSearchValue(keepFocusInput) {
            input.value = '';
            if (mobileInput) mobileInput.value = '';
            toggleClearBtn();
            showSuggestions();
            const focusTarget = keepFocusInput || input;
            if (focusTarget && typeof focusTarget.focus === 'function') focusTarget.focus();
        }

        if (clearBtn) {
            clearBtn.addEventListener('click', function (e) {
                e.preventDefault();
                clearSearchValue(input);
            });
        }

        if (mobileClearBtn) {
            mobileClearBtn.addEventListener('click', function (e) {
                e.preventDefault();
                clearSearchValue(mobileInput || input);
            });
        }

        toggleClearBtn();

        function openDropdown() {
            dropdown.style.display = 'block';
            if (window.innerWidth <= 991) {
                dropdown.classList.add('is-mobile-open');
                document.body.classList.add('evazar-search-open');
                const stickyBuybox = document.getElementById('mobile-sticky-bar');
                if (stickyBuybox) {
                    stickyBuybox.style.setProperty('display', 'none', 'important');
                    stickyBuybox.style.setProperty('visibility', 'hidden', 'important');
                }
                if (mobileInput) {
                    mobileInput.value = input.value;
                    toggleClearBtn();
                    mobileInput.focus();
                }
            }
        }

        function closeDropdown() {
            dropdown.style.display = 'none';
            dropdown.classList.remove('is-mobile-open');
            // فقط در صورتی که هیچ دراپ‌داون جستجوی موبایل دیگری باز نباشد، کلاس سراسری و نوار خرید چسبان را ریست کن
            const anyOtherOpen = document.querySelector('.evazar-search-dropdown.is-mobile-open');
            if (!anyOtherOpen) {
                document.body.classList.remove('evazar-search-open');
                const stickyBuybox = document.getElementById('mobile-sticky-bar');
                if (stickyBuybox) {
                    stickyBuybox.style.removeProperty('display');
                    stickyBuybox.style.removeProperty('visibility');
                }
            }
        }

        if (mobileBack) {
            mobileBack.addEventListener('click', closeDropdown);
        }

        function showSuggestions() {
            activeSuggIndex = -1;
            renderRecent();
            if (popularSection) popularSection.style.display = 'block';
            if (loader) loader.style.display = 'none';
            if (liveContent) liveContent.style.display = 'none';
            if (noResults) noResults.style.display = 'none';
            if (suggBox) suggBox.style.display = 'none';
        }

        // هندلر فوکوس
        input.addEventListener('focus', function () {
            openDropdown();
            if (this.value.trim().length < 2) {
                showSuggestions();
            } else {
                performSearch(this.value.trim());
            }
        });

        // تایپ کاربر با Debounce
        input.addEventListener('input', function () {
            toggleClearBtn();
            const q = this.value.trim();
            if (mobileInput) mobileInput.value = this.value;
            toggleClearBtn();

            if (q.length < 2) {
                showSuggestions();
                return;
            }

            clearTimeout(searchTimer);
            searchTimer = setTimeout(() => {
                performSearch(q);
            }, 250);
        });

        if (mobileInput) {
            mobileInput.addEventListener('input', function () {
                input.value = this.value;
                toggleClearBtn();
                const q = this.value.trim();
                if (q.length < 2) {
                    showSuggestions();
                    return;
                }
                clearTimeout(searchTimer);
                searchTimer = setTimeout(() => {
                    performSearch(q);
                }, 250);
            });
        }

        // اجرای جستجوی آژاکس
        function performSearch(query) {
            if (recentSection) recentSection.style.display = 'none';
            if (popularSection) popularSection.style.display = 'none';
            if (loader) loader.style.display = 'flex';
            if (liveContent) liveContent.style.display = 'none';
            if (noResults) noResults.style.display = 'none';

            if (currentAbortController) {
                currentAbortController.abort();
            }
            currentAbortController = new AbortController();

            const ajaxUrl = window.evazar_search_vars ? window.evazar_search_vars.ajax_url : '/wp-admin/admin-ajax.php';
            const formData = new FormData();
            formData.append('action', 'evazar_ajax_search');
            formData.append('keyword', query);
            formData.append('in_stock_only', isInstockOnly ? '1' : '0');
            if (window.evazar_search_vars && window.evazar_search_vars.nonce) {
                formData.append('nonce', window.evazar_search_vars.nonce);
            }

            fetch(ajaxUrl, {
                method: 'POST',
                body: formData,
                signal: currentAbortController.signal
            })
            .then(res => res.json())
            .then(data => {
                if (loader) loader.style.display = 'none';
                if (!data || !data.success || !data.data) {
                    if (noResults) noResults.style.display = 'block';
                    return;
                }

                const res = data.data;
                activeSuggIndex = -1;
                const hasSuggestions = res.suggestions && res.suggestions.length > 0;
                const hasCats = res.categories && res.categories.length > 0;
                const hasBrands = res.brands && res.brands.length > 0;

                if (!hasSuggestions && !hasCats && !hasBrands) {
                    if (noResults) noResults.style.display = 'block';
                    return;
                }

                // Did You Mean
                if (didYouMean && dymLink) {
                    if (res.did_you_mean && res.did_you_mean !== query) {
                        didYouMean.style.display = 'flex';
                        dymLink.textContent = res.did_you_mean;
                        dymLink.onclick = function (e) {
                            e.preventDefault();
                            input.value = res.did_you_mean;
                            if (mobileInput) mobileInput.value = res.did_you_mean;
                            saveRecentSearch(res.did_you_mean);
                            performSearch(res.did_you_mean);
                        };
                    } else {
                        didYouMean.style.display = 'none';
                    }
                }

                // پیشنهادات هوشمند جستجو دیجی‌کالا (Digikala Smart Suggestions)
                if (suggBox && suggList) {
                    if (hasSuggestions) {
                        suggBox.style.display = 'block';
                        const seenSuggestionKeys = new Set();
                        const queryKey = normalizeClientText(query);
                        const uniqueSuggestions = res.suggestions.filter(item => {
                            const key = normalizeClientText(item.search_term || item.title || '');
                            const words = key.split(' ').filter(Boolean);
                            if (!key || seenSuggestionKeys.has(key)) return false;
                            if (key === queryKey) return false;
                            if (words.length >= 2 && words[0] === words[1]) return false;
                            seenSuggestionKeys.add(key);
                            return true;
                        });
                        suggList.innerHTML = uniqueSuggestions.map((item, idx) => {
                            const iconSvg = `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>`;
                            return `
                                <div class="evazar-sugg-item" data-index="${idx}" data-url="${escapeHtml(item.url || '')}" data-term="${escapeHtml(item.search_term || item.title)}" role="button" tabindex="0">
                                    <div class="evazar-sugg-right">
                                        <span class="evazar-sugg-icon is-query">${iconSvg}</span>
                                        <span class="evazar-sugg-title">${highlightKeyword(item.title, query)}</span>
                                    </div>
                                    <span class="evazar-sugg-arrow" aria-hidden="true">›</span>
                                </div>
                            `;
                        }).join('');

                        // رویدادهای کلیک روی آیتم‌های پیشنهاد هوشمند دیجی‌کالا
                        suggList.querySelectorAll('.evazar-sugg-item').forEach(itemEl => {
                            itemEl.addEventListener('click', function (e) {
                                const url = this.getAttribute('data-url');
                                const term = this.getAttribute('data-term');
                                const searchTerm = term || query;
                                if (searchTerm) {
                                    saveRecentSearch(searchTerm);
                                }

                                const searchBase = window.evazar_search_vars ? window.evazar_search_vars.home_url : '/';

                                // هر پیشنهاد هوشمند یک عبارت جستجو است و به صفحه نتایج همان عبارت می‌رود.
                                // برچسب «در ...» فقط اطلاعات زمینه‌ای است و مقصد جداگانه ندارد.

                                // هدایت قطعی کلیک سطر به برگه نتایج جستجوی همان عبارت
                                const targetUrl = (url && url.includes('?s='))
                                    ? url
                                    : (searchBase + '?s=' + encodeURIComponent(searchTerm) + '&post_type=evazar_product');

                                window.location.href = targetUrl;
                            });
                        });
                    } else {
                        suggBox.style.display = 'none';
                        suggList.innerHTML = '';
                    }
                }

                // Categories (در صورت وجود پیشنهادات هوشمند، جهت سادگی و تمیزی بصری مخفی می‌ماند)
                if (catBox && catList) {
                    if (hasCats) {
                        catBox.style.display = 'block';
                        catList.innerHTML = res.categories.map(c => `
                            <a href="${escapeHtml(c.url)}" class="evazar-cat-item" data-save-search="1">
                                <span class="evazar-cat-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"></rect><rect x="14" y="3" width="7" height="7" rx="1"></rect><rect x="3" y="14" width="7" height="7" rx="1"></rect><rect x="14" y="14" width="7" height="7" rx="1"></rect></svg></span>
                                <span>${escapeHtml(c.name)}</span>
                            </a>
                        `).join('');
                    } else {
                        catBox.style.display = 'none';
                    }
                }

                // Brands — مستقل از پیشنهادات هوشمند نمایش داده می‌شود و مستقیماً به صفحه برند می‌رود.
                if (brandBox && brandList) {
                    if (hasBrands) {
                        brandBox.style.display = 'block';
                        brandList.innerHTML = res.brands.map(b => `
                            <a href="${escapeHtml(b.url)}" class="evazar-brand-item" data-save-search="1">
                                <span class="evazar-brand-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20.5 13.5 13 21H6a3 3 0 0 1-3-3v-7l7.5-7.5a2 2 0 0 1 2.8 0l7.2 7.2a2 2 0 0 1 0 2.8Z"></path><circle cx="8.5" cy="15.5" r="1.2"></circle></svg></span>
                                <span>${escapeHtml(b.name)}</span>
                            </a>
                        `).join('');
                    } else {
                        brandBox.style.display = 'none';
                    }
                }

                // فهرست کالاها در این دراپ‌داون عمداً نمایش داده نمی‌شود؛
                // برای شلوغ نشدن Search مثل الگوی دیجی‌کالا فقط پیشنهاد، دسته و برند نمایش می‌دهیم.
                container.querySelectorAll('[data-save-search="1"]').forEach(function (link) {
                    link.addEventListener('click', function () { saveRecentSearch(query); });
                });

                // View All Link
                if (viewAllLink) {
                    const searchBase = window.evazar_search_vars ? window.evazar_search_vars.home_url : '/';
                    viewAllLink.href = `${searchBase}?s=${encodeURIComponent(query)}&post_type=evazar_product`;
                    viewAllLink.onclick = function () { saveRecentSearch(query); };
                }

                if (liveContent) liveContent.style.display = 'block';
            })
            .catch(err => {
                if (err.name === 'AbortError') return;
                if (loader) loader.style.display = 'none';
                if (noResults) noResults.style.display = 'block';
            });
        }

        // ثبت سرچ در Submit فرم
        form.addEventListener('submit', function () {
            const q = input.value.trim();
            if (q.length >= 2) {
                saveRecentSearch(q);
            }
        });

        // بستن با کلیک در خارج از المنت
        document.addEventListener('click', function (e) {
            if (!container.contains(e.target)) {
                // فقط اگر این دراپ‌داون در حال حاضر باز است اقدام به بستن کن تا با سایر فرم‌های جستجو تداخل نکند
                if (dropdown.style.display !== 'none' || dropdown.classList.contains('is-mobile-open')) {
                    closeDropdown();
                }
            }
        });

        // ناوبری با کلیدهای جهت‌نما کیبورد (ArrowDown / ArrowUp / Enter)
        function updateActiveSuggestion(items) {
            items.forEach((item, i) => {
                if (i === activeSuggIndex) {
                    item.classList.add('is-active');
                    item.scrollIntoView({ block: 'nearest' });
                } else {
                    item.classList.remove('is-active');
                }
            });
        }

        function handleKeyNavigation(e) {
            if (!suggList || !suggBox || suggBox.style.display === 'none') return;
            const items = suggList.querySelectorAll('.evazar-sugg-item');
            if (!items.length) return;

            if (e.key === 'ArrowDown') {
                e.preventDefault();
                activeSuggIndex = (activeSuggIndex + 1) % items.length;
                updateActiveSuggestion(items);
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                activeSuggIndex = (activeSuggIndex - 1 + items.length) % items.length;
                updateActiveSuggestion(items);
            } else if (e.key === 'Enter') {
                if (activeSuggIndex >= 0 && activeSuggIndex < items.length) {
                    e.preventDefault();
                    items[activeSuggIndex].click();
                }
            }
        }

        input.addEventListener('keydown', handleKeyNavigation);
        if (mobileInput) {
            mobileInput.addEventListener('keydown', handleKeyNavigation);
        }

        // بستن با کلید Escape
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                closeDropdown();
            }
        });
    });

    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function normalizeClientText(value) {
        const faDigits = '۰۱۲۳۴۵۶۷۸۹';
        const arDigits = '٠١٢٣٤٥٦٧٨٩';
        return String(value || '')
            .toLowerCase()
            .replace(/[يى]/g, 'ی')
            .replace(/[ك]/g, 'ک')
            .replace(/[ۀة]/g, 'ه')
            .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, '')
            .replace(/[۰-۹٠-٩]/g, c => {
                const faIndex = faDigits.indexOf(c);
                if (faIndex >= 0) return String(faIndex);
                const arIndex = arDigits.indexOf(c);
                return arIndex >= 0 ? String(arIndex) : c;
            })
            .replace(/[^\p{L}\p{N}]+/gu, ' ')
            .trim()
            .replace(/\s+/g, ' ');
    }

    function highlightKeyword(title, keyword) {
        if (!keyword || !title) return escapeHtml(title);
        const escapedKeyword = keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(`(${escapedKeyword})`, 'gi');
        return escapeHtml(title).replace(regex, '<mark>$1</mark>');
    }
});
