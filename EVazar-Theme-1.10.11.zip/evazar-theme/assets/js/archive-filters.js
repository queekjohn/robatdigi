document.addEventListener('DOMContentLoaded', function () {
    const vars = window.evazar_archive_filters_vars || {};
    let panel = document.getElementById('evazar-filter-panel');
    let trigger = document.querySelector('.evazar-mobile-filter-trigger');
    if (!panel || !trigger) return;

    let form = panel.querySelector('.evazar-filter-form');
    let debounceTimer = null;
    let requestController = null;
    let ajaxSerial = 0;
    let lastRequestKey = '';
    let lastAppliedUrl = window.location.href;
    let navigationInFlight = false;
    let navigationSerial = 0;

    function getPageFromUrl(url) {
        try {
            const parsed = new URL(url, window.location.href);
            const fromQuery = parsed.searchParams.get('paged');
            if (fromQuery && /^\d+$/.test(fromQuery)) return Math.max(1, parseInt(fromQuery, 10));
            const match = parsed.pathname.match(/\/page\/(\d+)(?:\/|$)/i);
            return match ? Math.max(1, parseInt(match[1], 10)) : 1;
        } catch (_) {
            return 1;
        }
    }

    function stripPageSegment(pathname) {
        return String(pathname || '/').replace(/\/page\/\d+\/?$/i, '/') || '/';
    }

    function urlHasFilterKey(searchParams, key) {
        for (const k of searchParams.keys()) {
            if (key === 'brand' && /^brand(?:\[\d*\])?$/.test(k)) return true;
            if (key === 'category' && /^category(?:\[\d*\])?$/.test(k)) return true;
        }
        return false;
    }

    function mergeCurrentFiltersIntoUrl(targetUrl) {
        const parsed = new URL(targetUrl, window.location.href);
        if (!form) return parsed.toString();

        // Pagination/sort links generated before a pending filter request can carry
        // stale filter parameters. The form is the authoritative current UI state.
        const removeKeys = [];
        for (const key of parsed.searchParams.keys()) {
            if (/^brand(?:\[\d*\])?$/.test(key) || /^category(?:\[\d*\])?$/.test(key) ||
                key === 'stock' || key === 'min_price' || key === 'max_price') {
                removeKeys.push(key);
            }
        }
        removeKeys.forEach(key => parsed.searchParams.delete(key));

        form.querySelectorAll('input[name="brand[]"]:checked, input[name="category[]"]:checked').forEach(el => {
            parsed.searchParams.append(el.name, el.value);
        });
        const stock = form.querySelector('input[name="stock"]');
        if (stock && stock.checked) parsed.searchParams.set('stock', '1');
        // Price values are navigation state only when the price filter is
        // genuinely active. Never let a stale/default input value (for example
        // a rounded slider endpoint) leak into pagination/sort URLs.
        const priceBox = form.querySelector('.evazar-price-range');
        const priceActive = priceBox?.dataset?.priceFilterActive === '1';
        ['min_price', 'max_price'].forEach(name => {
            const el = form.querySelector('input[name="'+name+'"]');
            const value = numericString(el?.value || '');
            if (priceActive && value !== '') parsed.searchParams.set(name, value);
            else parsed.searchParams.delete(name);
        });
        return parsed.toString();
    }

    function normalizeDigits(value) {
        return String(value ?? '')
            .replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
            .replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
    }

    function normalizeSearch(value) {
        let text = normalizeDigits(value)
            .replace(/[يى]/g, 'ی')
            .replace(/[ك]/g, 'ک')
            .replace(/[ۀة]/g, 'ه')
            .replace(/[ؤ]/g, 'و')
            .replace(/[أإآٱ]/g, 'ا')
            .replace(/[ً-ٰٟ]/g, '')
            .replace(/\u200c/g, ' ')
            .replace(/[-_]+/g, ' ')
            .replace(/\s+/g, ' ')
            .trim()
            .toLocaleLowerCase('fa-IR');
        return text;
    }

    function numericString(value) {
        return normalizeDigits(value).replace(/[٬,،\s]/g, '').replace(/[^0-9]/g, '');
    }

    function toFaDigits(value) {
        return String(value ?? '').replace(/[0-9]/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
    }

    function formatPriceNumber(value) {
        const n = Math.max(0, Math.round(Number(value) || 0));
        return toFaDigits(n.toLocaleString('en-US'));
    }

    function clampNumber(value, min, max) {
        const n = Number(value);
        if (!Number.isFinite(n)) return min;
        return Math.min(max, Math.max(min, n));
    }

    function setOpen(open) {
        panel = document.getElementById('evazar-filter-panel') || panel;
        trigger = document.querySelector('.evazar-mobile-filter-trigger') || trigger;
        if (!panel || !trigger) return;
        panel.classList.toggle('is-mobile-open', open);
        trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
        document.body.classList.toggle('evazar-filter-open', open);
        if (open && window.innerWidth <= 760) {
            window.setTimeout(() => {
                const focusTarget = panel.querySelector('.evazar-filter-search:not([hidden]), input:not([type="hidden"]):not([disabled]), .evazar-filter-section-title');
                if (focusTarget) focusTarget.focus({preventScroll: true});
            }, 60);
        }
    }

    trigger.addEventListener('click', () => setOpen(true));

    function updateFilterBadge(count) {
        trigger = document.querySelector('.evazar-mobile-filter-trigger') || trigger;
        if (!trigger) return;
        const old = trigger.querySelector('.evazar-filter-count');
        if (old) old.remove();
        if (count > 0) {
            const badge = document.createElement('span');
            badge.className = 'evazar-filter-count';
            badge.textContent = toFaDigits(count);
            trigger.appendChild(badge);
        }
    }

    function getContextElement() {
        return document.querySelector('.evazar-archive-page');
    }

    function currentBaseUrl() {
        const ctx = getContextElement();
        const raw = ctx?.dataset?.filterBaseUrl || (window.location.origin + stripPageSegment(window.location.pathname));
        try {
            const u = new URL(raw, window.location.href);
            u.search = '';
            u.hash = '';
            u.pathname = stripPageSegment(u.pathname);
            return u.toString();
        } catch (_) {
            return window.location.origin + stripPageSegment(window.location.pathname);
        }
    }

    function priceChipLabel(url) {
        try {
            const u = new URL(url, window.location.href);
            const clean = v => numericString(v);
            const min = clean(u.searchParams.get('min_price'));
            const max = clean(u.searchParams.get('max_price'));
            const hasMin = min !== '';
            const hasMax = max !== '';
            if (!hasMin && !hasMax) return null;
            if (hasMin && hasMax) return 'بازه قیمت: ' + formatPriceNumber(min) + ' تا ' + formatPriceNumber(max) + ' تومان';
            if (hasMin) return 'بازه قیمت: از ' + formatPriceNumber(min) + ' تومان';
            return 'بازه قیمت: تا ' + formatPriceNumber(max) + ' تومان';
        } catch (e) {
            return null;
        }
    }

    function ensureActivePriceChip(url) {
        const label = priceChipLabel(url);
        let host = document.querySelector('.evazar-active-filters');
        const oldChip = document.querySelector('.evazar-active-price');
        if (!label) {
            if (oldChip) oldChip.remove();
            return;
        }
        if (!host) {
            const layout = document.querySelector('.evazar-results-layout');
            if (!layout) return;
            layout.insertAdjacentHTML('beforebegin', '<div class="evazar-active-filters" aria-label="فیلترهای فعال"><span class="evazar-active-label">فیلترهای فعال:</span></div>');
            host = document.querySelector('.evazar-active-filters');
        }
        const clearUrl = new URL(url, window.location.href);
        clearUrl.searchParams.delete('min_price');
        clearUrl.searchParams.delete('max_price');
        clearUrl.searchParams.delete('paged');
        let chip = host.querySelector('.evazar-active-price');
        if (!chip) {
            chip = document.createElement('a');
            chip.className = 'evazar-active-chip evazar-active-price';
            const clear = host.querySelector('.evazar-active-clear');
            if (clear) host.insertBefore(chip, clear);
            else host.appendChild(chip);
        }
        chip.href = clearUrl.toString();
        chip.dataset.evazarFilterUrl = clearUrl.toString();
        chip.setAttribute('aria-label', 'حذف ' + label);
        chip.innerHTML = '<b>' + label + '</b><span aria-hidden="true">×</span>';
    }

    function initPriceSlider(scope) {
        const box = scope.querySelector('.evazar-price-range');
        if (!box || box.dataset.initialized === '1') return;
        box.dataset.initialized = '1';

        const track = box.querySelector('.evazar-price-range-slider');
        const fill = box.querySelector('.evazar-price-range-fill');
        const lowerHandle = box.querySelector('.evazar-price-range-handle-lower');
        const upperHandle = box.querySelector('.evazar-price-range-handle-upper');
        const minField = scope.querySelector('input[name="min_price"]');
        const maxField = scope.querySelector('input[name="max_price"]');
        const minOut = box.querySelector('.evazar-price-range-min-value');
        const maxOut = box.querySelector('.evazar-price-range-max-value');
        if (!track || !lowerHandle || !upperHandle) return;

        const minBound = Number(box.dataset.priceMin || 0);
        const maxBound = Number(box.dataset.priceMax || minBound);
        const step = Math.max(1, Number(box.dataset.priceStep || 1));
        if (!(maxBound > minBound)) {
            lowerHandle.disabled = true;
            upperHandle.disabled = true;
            return;
        }

        const fieldNumber = field => {
            if (!field) return NaN;
            const raw = numericString(field.value);
            if (raw === '') return NaN;
            const n = Number(raw);
            return Number.isFinite(n) ? n : NaN;
        };
        const roundToStep = value => {
            const n = Number(value);
            if (!Number.isFinite(n)) return minBound;
            // Keep the real slider endpoints exact. This prevents a non-step-aligned
            // smart bound from being rounded inward and accidentally becoming an
            // active price filter.
            if (n <= minBound) return minBound;
            if (n >= maxBound) return maxBound;
            const steps = Math.round((n - minBound) / step);
            const snapped = minBound + steps * step;
            return clampNumber(snapped, minBound, maxBound);
        };

        // smart_min/smart_max define the available slider bounds only.
        // Until the user explicitly changes a price handle/input, keep the
        // internal values exactly at the bounds and keep both form fields empty.
        const initiallyActive = box.dataset.priceFilterActive === '1';
        let minValue = initiallyActive && Number.isFinite(fieldNumber(minField)) ? clampNumber(fieldNumber(minField), minBound, maxBound) : minBound;
        let maxValue = initiallyActive && Number.isFinite(fieldNumber(maxField)) ? clampNumber(fieldNumber(maxField), minBound, maxBound) : maxBound;
        if (initiallyActive) {
            minValue = roundToStep(minValue);
            maxValue = roundToStep(maxValue);
        }
        if (minValue > maxValue) [minValue, maxValue] = [maxValue, minValue];
        let priceFilterActive = initiallyActive;

        let activeHandle = null;
        let dragging = false;
        let lastDragValue = null;

        const valueToPercent = value => ((value - minBound) / Math.max(1, maxBound - minBound)) * 100;
        const percentToValue = percent => roundToStep(minBound + (Math.max(0, Math.min(100, percent)) / 100) * (maxBound - minBound));

        const update = (sendRequest = false) => {
            if (minValue > maxValue) [minValue, maxValue] = [maxValue, minValue];
            priceFilterActive = priceFilterActive || minValue > minBound || maxValue < maxBound;
            box.dataset.priceFilterActive = priceFilterActive ? '1' : '0';
            box.classList.toggle('is-active', priceFilterActive);
            const lowPct = valueToPercent(minValue);
            const highPct = valueToPercent(maxValue);
            if (fill) {
                fill.style.right = lowPct + '%';
                fill.style.left = (100 - highPct) + '%';
            }
            if (lowerHandle) {
                lowerHandle.style.right = lowPct + '%';
                lowerHandle.setAttribute('aria-valuenow', String(minValue));
                lowerHandle.setAttribute('aria-valuetext', formatPriceNumber(minValue) + ' تومان');
                lowerHandle.classList.toggle('is-active', activeHandle === lowerHandle);
            }
            if (upperHandle) {
                upperHandle.style.right = highPct + '%';
                upperHandle.setAttribute('aria-valuenow', String(maxValue));
                upperHandle.setAttribute('aria-valuetext', formatPriceNumber(maxValue) + ' تومان');
                upperHandle.classList.toggle('is-active', activeHandle === upperHandle);
            }
            if (minOut) minOut.textContent = formatPriceNumber(minValue);
            if (maxOut) maxOut.textContent = formatPriceNumber(maxValue);
            if (minField) minField.value = minValue > minBound ? formatPriceNumber(minValue) : '';
            if (maxField) maxField.value = maxValue < maxBound ? formatPriceNumber(maxValue) : '';
            if (sendRequest) scheduleAjax(160);
        };

        const setFromClientX = (clientX, handle = null) => {
            const rect = track.getBoundingClientRect();
            if (!rect.width) return;
            // در رابط RTL: راست = کمترین قیمت، چپ = بیشترین قیمت.
            const percent = ((rect.right - clientX) / rect.width) * 100;
            const next = percentToValue(percent);
            const chosen = handle || activeHandle || (Math.abs(next - minValue) <= Math.abs(next - maxValue) ? lowerHandle : upperHandle);
            if (chosen === lowerHandle) {
                minValue = Math.min(next, maxValue);
                activeHandle = lowerHandle;
                lastDragValue = minValue;
            } else {
                maxValue = Math.max(next, minValue);
                activeHandle = upperHandle;
                lastDragValue = maxValue;
            }
            priceFilterActive = true;
            update(false);
        };

        const beginDrag = (event, handle = null) => {
            if (event.button !== undefined && event.button !== 0 && event.pointerType !== 'touch') return;
            event.preventDefault();
            if (handle) activeHandle = handle;
            setFromClientX(event.clientX, activeHandle);
            dragging = true;
            lastDragValue = activeHandle === lowerHandle ? minValue : maxValue;
            try { event.currentTarget?.setPointerCapture?.(event.pointerId); } catch (_) {}
            document.documentElement.classList.add('evazar-price-dragging');
            attachDragListeners();
        };

        track.addEventListener('pointerdown', event => beginDrag(event));
        [lowerHandle, upperHandle].forEach(handle => {
            handle.addEventListener('pointerdown', event => beginDrag(event, handle));
            handle.addEventListener('keydown', event => {
                let next = null;
                if (event.key === 'ArrowLeft') next = (handle === lowerHandle ? minValue : maxValue) + step;
                else if (event.key === 'ArrowRight') next = (handle === lowerHandle ? minValue : maxValue) - step;
                else if (event.key === 'Home') next = minBound;
                else if (event.key === 'End') next = maxBound;
                else return;
                event.preventDefault();
                activeHandle = handle;
                next = clampNumber(next, minBound, maxBound);
                if (handle === lowerHandle) minValue = Math.min(next, maxValue);
                else maxValue = Math.max(next, minValue);
                priceFilterActive = true;
                update(true);
            });
        });

        const moveDrag = event => {
            if (!dragging) return;
            setFromClientX(event.clientX, activeHandle);
        };
        const endDrag = () => {
            if (!dragging) return;
            dragging = false;
            document.documentElement.classList.remove('evazar-price-dragging');
            document.removeEventListener('pointermove', moveDrag);
            document.removeEventListener('pointerup', endDrag);
            document.removeEventListener('pointercancel', endDrag);
            if (lastDragValue !== null) scheduleAjax(120);
            lastDragValue = null;
        };
        const attachDragListeners = () => {
            document.addEventListener('pointermove', moveDrag, {passive:true});
            document.addEventListener('pointerup', endDrag, {passive:true});
            document.addEventListener('pointercancel', endDrag, {passive:true});
        };

        const syncFromField = field => {
            const raw = numericString(field?.value || '');
            if (raw === '') return;
            const parsed = roundToStep(Number(raw));
            if (field === minField) minValue = Math.min(parsed, maxValue);
            else maxValue = Math.max(parsed, minValue);
            priceFilterActive = true;
            update(false);
            scheduleAjax(420);
        };
        const bindNumeric = field => {
            if (!field) return;
            field.addEventListener('input', function () {
                const raw = numericString(this.value);
                this.value = raw === '' ? '' : formatPriceNumber(raw);
                syncFromField(this);
            });
            field.addEventListener('blur', function () {
                const raw = numericString(this.value);
                if (raw === '') {
                    if (this === minField) minValue = minBound;
                    else maxValue = maxBound;
                    priceFilterActive = minValue > minBound || maxValue < maxBound;
                    update(false);
                    scheduleAjax(180);
                    return;
                }
                this.value = formatPriceNumber(roundToStep(Number(raw)));
                syncFromField(this);
            });
        };
        bindNumeric(minField);
        bindNumeric(maxField);

        update(false);
    }

    function collectContextData(fd) {
        const context = getContextElement();
        fd.append('context_taxonomy', context?.dataset?.filterTaxonomy || '');
        fd.append('context_term_id', context?.dataset?.filterTermId || '0');
        fd.append('search', context?.dataset?.filterSearch || '');
        fd.append('on_sale', context?.dataset?.filterSale || '0');
        return fd;
    }

    function serializeForm() {
        const fd = new FormData(form);
        ['min_price', 'max_price'].forEach(name => {
            const el = form.querySelector('input[name="'+name+'"]');
            if (!el || numericString(el.value) === '') fd.delete(name);
        });
        fd.append('action', 'evazar_archive_filter');
        fd.append('nonce', vars.nonce || '');
        collectContextData(fd);
        fd.append('paged', '1');
        fd.append('base_url', currentBaseUrl());
        return fd;
    }

    function scheduleAjax(delay = 0) {
        clearTimeout(debounceTimer);
        debounceTimer = window.setTimeout(applyAjax, delay);
    }

    function scrollToResultsTop() {
        const target = document.querySelector('.evazar-results-content') || document.querySelector('.evazar-results-layout');
        if (!target) return;

        const header = document.querySelector('.evazar-header, header.site-header, .site-header');
        const headerHeight = header ? header.getBoundingClientRect().height : 0;
        const top = Math.max(0, window.scrollY + target.getBoundingClientRect().top - headerHeight - 24);
        const behavior = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth';
        window.scrollTo({ top, behavior });
    }

    async function replaceFromAjax(data, fallbackUrl) {
        const nextUrl = data.url || fallbackUrl;
        const holder = document.createElement('div');
        holder.innerHTML = data.filters_html || '';
        const replacement = holder.firstElementChild;
        if (replacement && panel.parentNode) {
            panel.replaceWith(replacement);
            panel = replacement;
        }

        const activeHost = document.querySelector('.evazar-active-filters');
        if (activeHost) {
            activeHost.outerHTML = data.active_html || '';
        } else if (data.active_html) {
            const layout = document.querySelector('.evazar-results-layout');
            if (layout) layout.insertAdjacentHTML('beforebegin', data.active_html);
        }

        const content = document.querySelector('.evazar-results-content');
        if (content) content.innerHTML = data.results_html || '';

        ensureActivePriceChip(nextUrl);
        trigger = document.querySelector('.evazar-mobile-filter-trigger') || trigger;
        bindPanel();
        updateFilterBadge(Number(data.active_count || 0));
        setOpen(false);
        window.history.replaceState({}, '', nextUrl);
        lastAppliedUrl = new URL(nextUrl, window.location.origin).href;
        window.requestAnimationFrame(scrollToResultsTop);
    }

    async function applyAjax() {
        if (!form || !vars.ajax_url) return;
        if (requestController) requestController.abort();
        requestController = new AbortController();
        const serial = ++ajaxSerial;
        const fd = serializeForm();
        const requestKey = new URLSearchParams(fd).toString();
        if (requestKey === lastRequestKey && lastAppliedUrl === window.location.href) return;
        lastRequestKey = requestKey;
        document.body.classList.add('evazar-filter-loading');
        panel.classList.add('evazar-filter-busy');
        try {
            const response = await fetch(vars.ajax_url, { method: 'POST', body: fd, credentials: 'same-origin', signal: requestController.signal });
            const json = await response.json();
            if (serial !== ajaxSerial) return;
            if (!json.success) throw new Error('filter_error');
            await replaceFromAjax(json.data || {}, window.location.href);
        } catch (error) {
            if (error.name !== 'AbortError') console.error('Evazar filter:', error);
        } finally {
            if (serial === ajaxSerial && !navigationInFlight) {
                panel.classList.remove('evazar-filter-busy');
                document.body.classList.remove('evazar-filter-loading');
            }
        }
    }

    function initTaxonomyLiveSearch(input, options, endpoint, emptyText) {
        if (!input || !options) return;
        const initialHTML = options.innerHTML;
        let timer = null;
        let controller = null;
        const clearButton = input.parentElement?.querySelector('.evazar-filter-search-clear');

        const renderLocal = needle => {
            const items = Array.from(options.querySelectorAll('.evazar-filter-check'));
            let visible = 0;
            items.forEach(item => {
                const hay = normalizeSearch(item.getAttribute('data-filter-text') || item.textContent || '');
                const show = !needle || hay.includes(needle);
                item.hidden = !show;
                if (show) visible++;
            });
            return visible;
        };

        const reset = () => {
            if (controller) controller.abort();
            options.innerHTML = initialHTML;
            input.value = '';
            if (clearButton) clearButton.hidden = true;
        };

        input.addEventListener('input', function () {
            const needle = normalizeSearch(this.value);
            if (clearButton) clearButton.hidden = needle === '';
            clearTimeout(timer);
            if (controller) controller.abort();
            if (needle === '') {
                options.innerHTML = initialHTML;
                return;
            }
            if (needle.length < 2) {
                const visible = renderLocal(needle);
                if (!visible) options.innerHTML = '<div class="evazar-filter-search-empty">' + emptyText + '</div>';
                return;
            }
            timer = window.setTimeout(async () => {
                if (!vars.ajax_url) return;
                controller = new AbortController();
                const fd = new FormData();
                fd.append('action', endpoint);
                fd.append('nonce', vars.nonce || '');
                fd.append('q', needle);
                const context = getContextElement();
                fd.append('context_taxonomy', context?.dataset?.filterTaxonomy || '');
                fd.append('context_term_id', context?.dataset?.filterTermId || '0');
                if (form) {
                    form.querySelectorAll('input[name="brand[]"]:checked, input[name="category[]"]:checked, input[name="stock"], input[name="min_price"], input[name="max_price"]').forEach(el => {
                        fd.append(el.name, el.type === 'checkbox' ? (el.checked ? el.value : '') : el.value);
                    });
                }
                try {
                    const response = await fetch(vars.ajax_url, { method: 'POST', body: fd, credentials: 'same-origin', signal: controller.signal });
                    const json = await response.json();
                    if (!json.success) throw new Error('taxonomy_search');
                    options.innerHTML = json.data?.html || '<div class="evazar-filter-search-empty">' + emptyText + '</div>';
                } catch (error) {
                    if (error.name !== 'AbortError') options.innerHTML = '<div class="evazar-filter-search-empty">' + emptyText + '</div>';
                }
            }, 180);
        });

        clearButton?.addEventListener('click', function () {
            reset();
            input.focus();
        });
    }

    function bindPanel() {
        form = panel.querySelector('.evazar-filter-form');
        if (!form) return;
        const closeBtn = panel.querySelector('.evazar-filter-close');
        if (closeBtn) closeBtn.addEventListener('click', () => setOpen(false));

        panel.querySelectorAll('.evazar-filter-section-title').forEach(btn => {
            btn.addEventListener('click', function () {
                const body = this.nextElementSibling;
                const expanded = this.getAttribute('aria-expanded') !== 'false';
                this.setAttribute('aria-expanded', expanded ? 'false' : 'true');
                if (body) body.hidden = expanded;
            });
        });

        panel.addEventListener('click', async function (event) {
            const btn = event.target.closest('.evazar-category-tree-toggle[data-lazy-category="1"]');
            if (!btn || !panel.contains(btn)) return;
            event.preventDefault();
            event.stopPropagation();
            const item = btn.closest('.evazar-category-tree-item');
            const children = item ? item.querySelector(':scope > .evazar-category-tree-children') : null;
            if (!item || !children) return;
            const expanded = btn.getAttribute('aria-expanded') === 'true';
            if (expanded) {
                btn.setAttribute('aria-expanded', 'false');
                btn.classList.remove('is-open');
                item.classList.remove('is-expanded');
                children.hidden = true;
                return;
            }
            if (children.dataset.categoryChildrenLoaded !== '1') {
                btn.classList.add('is-loading');
                btn.setAttribute('aria-busy', 'true');
                const fd = new FormData();
                fd.append('action', 'evazar_filter_category_children');
                fd.append('nonce', vars.nonce || '');
                fd.append('parent_id', btn.dataset.parentId || item.dataset.categoryId || '0');
                fd.append('depth', String((parseInt(item.parentElement?.className?.match(/level-(\d+)/)?.[1] || '0', 10) + 1)));
                const context = getContextElement();
                fd.append('context_taxonomy', context?.dataset?.filterTaxonomy || '');
                fd.append('context_term_id', context?.dataset?.filterTermId || '0');
                if (form) {
                    form.querySelectorAll('input[name="brand[]"]:checked, input[name="category[]"]:checked, input[name="stock"], input[name="min_price"], input[name="max_price"]').forEach(el => {
                        if (el.type === 'checkbox') { if (el.checked) fd.append(el.name, el.value); }
                        else if (el.value !== '') fd.append(el.name, el.value);
                    });
                }
                try {
                    const response = await fetch(vars.ajax_url, { method:'POST', body:fd, credentials:'same-origin' });
                    const json = await response.json();
                    if (!json.success) throw new Error('category_children');
                    const html = json.data?.html || '';
                    if (!html) { btn.remove(); return; }
                    children.innerHTML = html;
                    children.dataset.categoryChildrenLoaded = '1';
                } catch (error) {
                    console.error('Evazar category tree:', error);
                    return;
                } finally {
                    btn.classList.remove('is-loading');
                    btn.removeAttribute('aria-busy');
                }
            }
            btn.setAttribute('aria-expanded', 'true');
            btn.classList.add('is-open');
            item.classList.add('is-expanded');
            children.hidden = false;
        });

        initTaxonomyLiveSearch(
            panel.querySelector('.evazar-filter-brand-search'),
            panel.querySelector('.evazar-filter-brand-options'),
            'evazar_filter_brand_search',
            'برندی با این عبارت پیدا نشد'
        );
        initTaxonomyLiveSearch(
            panel.querySelector('.evazar-filter-category-search'),
            panel.querySelector('.evazar-filter-category-options'),
            'evazar_filter_category_search',
            'دسته‌ای با این عبارت پیدا نشد'
        );

        form.addEventListener('change', function (event) {
            const target = event.target;
            if (!target || !target.matches('input[type="checkbox"]')) return;
            const label = target.closest('.evazar-filter-check');
            if (label && target.name === 'category[]') {
                label.classList.toggle('is-selected', target.checked);
            }
            scheduleAjax(0);
        });

        initPriceSlider(panel);
        const clear = panel.querySelector('.evazar-filter-clear');
        if (clear) clear.addEventListener('click', function (event) {
            event.preventDefault();
            applyAjaxFromUrl(this.href);
        });
    }

    async function applyAjaxFromUrl(url, options = {}) {
        const mergeFilters = options.mergeFilters === true;
        const replaceHistory = options.replaceHistory !== false;
        const targetUrl = mergeFilters ? mergeCurrentFiltersIntoUrl(url) : url;
        const page = getPageFromUrl(targetUrl);

        // Latest navigation wins. Abort any older filter/navigation request so a
        // slow previous response can never consume or overwrite the current click.
        if (navigationInFlight && requestController && options.allowParallel !== true) {
            try { requestController.abort(); } catch (_) {}
        }
        navigationInFlight = true;
        const localNavigationSerial = ++navigationSerial;

        try {
            const parsed = new URL(targetUrl, window.location.href);
            const fd = new FormData();
            fd.append('action', 'evazar_archive_filter');
            fd.append('nonce', vars.nonce || '');
            parsed.searchParams.forEach((value, key) => {
                if (/^brand(?:\[\d*\])?$/.test(key)) fd.append('brand[]', value);
                else if (/^category(?:\[\d*\])?$/.test(key)) fd.append('category[]', value);
            });
            if (parsed.searchParams.get('stock') === '1') fd.append('stock', '1');
            if (parsed.searchParams.has('min_price')) fd.append('min_price', parsed.searchParams.get('min_price'));
            if (parsed.searchParams.has('max_price')) fd.append('max_price', parsed.searchParams.get('max_price'));
            const context = getContextElement();
            fd.append('context_taxonomy', context?.dataset?.filterTaxonomy || '');
            fd.append('context_term_id', context?.dataset?.filterTermId || '0');
            fd.append('on_sale', context?.dataset?.filterSale || '0');
            fd.append('search', parsed.searchParams.get('s') || context?.dataset?.filterSearch || '');
            fd.append('sort', parsed.searchParams.get('sort') || 'relevant');
            fd.append('paged', String(page));
            // Always send the canonical archive path without /page/N/ to PHP.
            fd.append('base_url', parsed.origin + stripPageSegment(parsed.pathname));

            if (requestController) requestController.abort();
            requestController = new AbortController();
            document.body.classList.add('evazar-filter-loading');
            panel.classList.add('evazar-filter-busy');

            const response = await fetch(vars.ajax_url, {
                method: 'POST',
                body: fd,
                credentials: 'same-origin',
                signal: requestController.signal,
                headers: { 'X-Requested-With': 'XMLHttpRequest' }
            });

            if (!response.ok) throw new Error('http_'+response.status);
            const json = await response.json();
            if (localNavigationSerial !== navigationSerial) return;
            if (!json.success) throw new Error('filter_error');

            await replaceFromAjax(json.data || {}, targetUrl);
            if (replaceHistory && localNavigationSerial === navigationSerial) {
                const finalUrl = json.data?.url || targetUrl;
                window.history.replaceState({ evazarArchive: true, url: finalUrl }, '', finalUrl);
                lastAppliedUrl = new URL(finalUrl, window.location.href).href;
            }
        } catch (error) {
            if (error.name !== 'AbortError') {
                console.error('Evazar filter navigation:', error);
                // Graceful fallback to a real navigation if AJAX fails.
                window.location.assign(targetUrl);
            }
        } finally {
            if (localNavigationSerial === navigationSerial) {
                panel?.classList.remove('evazar-filter-busy');
                document.body.classList.remove('evazar-filter-loading');
                navigationInFlight = false;
            }
        }
    }

    // One delegated navigation handler for pagination/sort/filter chips.
    // Capture phase prevents competing theme/plugin click handlers from racing it.
    document.addEventListener('click', function (event) {
        const chip = event.target.closest('.evazar-active-chip, .evazar-active-clear');
        if (chip && chip.dataset.evazarFilterUrl) {
            event.preventDefault();
            event.stopPropagation();
            if (event.stopImmediatePropagation) event.stopImmediatePropagation();
            applyAjaxFromUrl(chip.dataset.evazarFilterUrl, { mergeFilters: false });
            return;
        }

        const navigation = event.target.closest('.evazar-results-content .evazar-pagination a, .evazar-results-content .dk-sort-btn');
        if (!navigation || !navigation.href) return;
        const href = new URL(navigation.href, window.location.href);
        if (href.origin !== window.location.origin) return;

        // Legacy/failed AJAX-rendered sort links may point to admin-ajax.php.
        // Canonicalize them back to the real archive URL before sending the request.
        if (/\/wp-admin\/admin-ajax\.php$/i.test(href.pathname)) {
            const canonical = new URL(currentBaseUrl(), window.location.href);
            href.pathname = stripPageSegment(canonical.pathname);
            href.search = navigation.href ? new URL(navigation.href, window.location.href).search : href.search;
        }

        event.preventDefault();
        event.stopPropagation();
        if (event.stopImmediatePropagation) event.stopImmediatePropagation();

        // Keep the current filter form state when pagination/sort was clicked while
        // a previous filter response is still being rendered.
        applyAjaxFromUrl(href.toString(), { mergeFilters: true });
    }, true);

    document.addEventListener('keydown', event => {
        if (event.key === 'Escape' && panel.classList.contains('is-mobile-open')) setOpen(false);
    });
    window.addEventListener('popstate', () => applyAjaxFromUrl(window.location.href, { mergeFilters: false }));

    bindPanel();
    ensureActivePriceChip(window.location.href);
    const initialUrl = new URL(window.location.href);
    const initialPriceActive = initialUrl.searchParams.has('min_price') || initialUrl.searchParams.has('max_price');
    const initialStockActive = initialUrl.searchParams.get('stock') === '1';
    const checkedFilters = panel.querySelectorAll('input[name="brand[]"]:checked, input[name="category[]"]:checked').length;
    const initialCount = checkedFilters + (initialStockActive ? 1 : 0) + (initialPriceActive ? 1 : 0);
    updateFilterBadge(initialCount);
});
