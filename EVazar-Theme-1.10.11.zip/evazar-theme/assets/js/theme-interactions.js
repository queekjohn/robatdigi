/**
 * اسکریپت تعاملی و ناوبری ارگونومیک پوسته ایوازار (Evazar Theme Interactions)
 * ناوبری روان با دکمه‌های اسکرول (Prev / Next) و چرخ ماوس بدون تداخل لمسی در دسکتاپ
 * کلیک ۱۰۰٪ آنی، بومی و بدون هرگونه وقفه روی تمامی لینک‌ها و کارت‌ها
 */
document.addEventListener('DOMContentLoaded', function () {
    'use strict';

    // ۱. ناوبری دکمه‌ای و چرخ ماوس برای نوار زیردسته‌ها
    initRailNavigation({
        containerSelector: '.archive-subcats-bar .subcats-scroll-wrapper',
        sliderSelector: '.archive-subcats-bar .subcats-chips-wrapper',
        prevBtnSelector: '.archive-subcats-bar .subcats-btn-prev',
        nextBtnSelector: '.archive-subcats-bar .subcats-btn-next',
        step: 260
    });

    // ۲. ناوبری دکمه‌ای و چرخ ماوس برای ریل برندهای صفحه اصلی
    initRailNavigation({
        containerSelector: '.home-brands-section .home-brands-scroll-wrap',
        sliderSelector: '.home-brands-section .home-brands-rail',
        prevBtnSelector: '.home-brands-section .brands-nav-prev',
        nextBtnSelector: '.home-brands-section .brands-nav-next',
        step: 280
    });

    // ۳. ناوبری دکمه‌ای و چرخ ماوس برای بخش محصولات تخفیف شگفت‌انگیز صفحه اصلی
    initRailNavigation({
        containerSelector: '.home-deals-section .deals-slider-wrapper',
        sliderSelector: '.home-deals-section .deals-slider-rail',
        prevBtnSelector: '.home-deals-section .deals-nav-prev',
        nextBtnSelector: '.home-deals-section .deals-nav-next',
        step: 280
    });

    // ۴. ناوبری دکمه‌ای و چرخ ماوس برای قفسه‌های موضوعی و جدیدترین‌های صفحه اصلی (Shelves & Latest)
    var shelfWraps = document.querySelectorAll('.home-category-shelf-section .shelf-slider-wrap, .home-latest-products-section .shelf-slider-wrap');
    if (shelfWraps.length) {
        shelfWraps.forEach(function (wrap) {
            var rail = wrap.querySelector('.shelf-slider-rail');
            var prev = wrap.querySelector('.shelf-nav-prev');
            var next = wrap.querySelector('.shelf-nav-next');
            if (rail) {
                initRailElement(rail, wrap, prev, next, 270);
            }
        });
    }

    // ۴-الف: ناوبری اسلایدر ریل برای تب‌های دسته‌بندی صفحه اصلی (Cat Tabs Rails)
    var catTabWraps = document.querySelectorAll('.cat-tabs-section .cat-tab-slider-wrap');
    if (catTabWraps.length) {
        catTabWraps.forEach(function (wrap) {
            var rail = wrap.querySelector('.cat-tab-slider-rail');
            var prev = wrap.querySelector('.cat-tab-nav-prev');
            var next = wrap.querySelector('.cat-tab-nav-next');
            if (rail) {
                initRailElement(rail, wrap, prev, next, 270);
            }
        });
    }

    // ۵. تعویض آنی و بدون پرش تب‌های دسته‌بندی در صفحه اصلی (Tabs)
    initCategoryTabs();

    function initCategoryTabs() {
        var tabBtns = document.querySelectorAll('.cat-tabs-section .cat-tab-btn');
        if (!tabBtns.length) return;

        tabBtns.forEach(function (btn) {
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                var targetId = this.getAttribute('data-tab');
                var container = this.closest('.cat-tabs-section');
                if (!container) return;

                container.querySelectorAll('.cat-tab-btn').forEach(function (b) {
                    b.classList.remove('is-active');
                });
                this.classList.add('is-active');

                container.querySelectorAll('.cat-tab-panel').forEach(function (p) {
                    p.classList.remove('is-active');
                });
                var targetPanel = container.querySelector('#' + targetId);
                if (targetPanel) {
                    targetPanel.classList.add('is-active');
                    var activeRail = targetPanel.querySelector('.cat-tab-slider-rail');
                    if (activeRail && activeRail._updateButtons) {
                        setTimeout(activeRail._updateButtons, 60);
                    }
                }

                var catUrl = this.getAttribute('data-url');
                var viewAllLink = container.querySelector('.section-view-all-link');
                if (viewAllLink && catUrl) {
                    viewAllLink.href = catUrl;
                    var catName = this.querySelector('.cat-tab-name');
                    if (catName) {
                        viewAllLink.textContent = 'مشاهده همه کالاهای ' + catName.textContent.trim() + ' ←';
                    }
                }
            });
        });
    }

    function initRailElement(slider, container, prevBtn, nextBtn, step) {
        if (!slider) return;
        step = step || 260;
        slider._updateButtons = updateButtons;


        if (prevBtn) {
            prevBtn.addEventListener('click', function (e) {
                e.preventDefault();
                slider.scrollBy({ left: step, behavior: 'smooth' });
                setTimeout(updateButtons, 350);
            });
        }

        if (nextBtn) {
            nextBtn.addEventListener('click', function (e) {
                e.preventDefault();
                slider.scrollBy({ left: -step, behavior: 'smooth' });
                setTimeout(updateButtons, 350);
            });
        }

        function updateButtons() {
            if (!prevBtn && !nextBtn) return;
            var isOverflowing = slider.scrollWidth > (slider.clientWidth + 4);
            if (!isOverflowing) {
                if (prevBtn) prevBtn.style.display = 'none';
                if (nextBtn) nextBtn.style.display = 'none';
                if (container) container.classList.remove('can-scroll-prev', 'can-scroll-next');
                return;
            }

            var maxScroll = slider.scrollWidth - slider.clientWidth;
            var currentScroll = Math.abs(slider.scrollLeft);

            var atStart = currentScroll <= 4;
            var atEnd = currentScroll >= (maxScroll - 6);

            if (prevBtn) {
                prevBtn.style.display = 'flex';
                prevBtn.disabled = atStart;
                prevBtn.classList.toggle('is-disabled', atStart);
            }
            if (nextBtn) {
                nextBtn.style.display = 'flex';
                nextBtn.disabled = atEnd;
                nextBtn.classList.toggle('is-disabled', atEnd);
            }

            if (container) {
                container.classList.toggle('can-scroll-prev', !atStart);
                container.classList.toggle('can-scroll-next', !atEnd);
            }
        }

        slider.addEventListener('scroll', updateButtons, { passive: true });
        window.addEventListener('resize', updateButtons);
        setTimeout(updateButtons, 120);
    }

    function initRailNavigation(config) {
        var slider = document.querySelector(config.sliderSelector);
        if (!slider) return;

        var container = document.querySelector(config.containerSelector) || slider.parentElement;
        var prevBtn = container ? container.querySelector(config.prevBtnSelector) : document.querySelector(config.prevBtnSelector);
        var nextBtn = container ? container.querySelector(config.nextBtnSelector) : document.querySelector(config.nextBtnSelector);
        var step = config.step || 250;

        initRailElement(slider, container, prevBtn, nextBtn, step);
    }
});
