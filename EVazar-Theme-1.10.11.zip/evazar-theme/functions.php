<?php
/**
 * توابع اصلی و هسته پوسته اختصاصی ایوازار
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// 1. بارگذاری موتور تنظیمات پوسته
require_once get_template_directory() . '/theme-options.php';

// 2. پشتیبانی‌های پایه وردپرس
function evazar_theme_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption' ) );
}
add_action( 'after_setup_theme', 'evazar_theme_setup' );


/**
 * ارتقای متن‌های قدیمی به نسخه Affiliate-safe در زمان ارتقای پوسته.
 * فقط مقادیر دقیقاً برابر با متن‌های پیش‌فرض قدیمی تغییر می‌کنند تا تنظیمات سفارشی مدیر حفظ شوند.
 */
function evazar_theme_upgrade_1510() {
    if (get_option('evazar_theme_migration_1510_done') === '1') {
        return;
    }

    $safe_updates = [
        'evazar_opt_product_guarantee_text' => [
            '🔒 خرید شما کاملاً از طریق بستر رسمی دیجی‌کالا انجام می‌شود و قیمت برای شما هیچ تفاوتی نخواهد داشت.',
            'ایوازار فروشنده کالا نیست؛ برای خرید به سایت فروشنده منتقل می‌شوید و پرداخت و ارسال در همان سایت انجام می‌شود.',
        ],
        'evazar_opt_footer_trust_title' => [
            'خرید امن و مطمئن',
            'ایوازار فروشنده کالا نیست',
        ],
        'evazar_opt_footer_trust_text' => [
            'ایوازار به عنوان پارتنر رسمی معرفی محصولات دیجی‌کالا، در فرآیند خرید هیچ هزینه‌ای از شما دریافت نمی‌کند و تمامی سفارش‌ها با تضمین اصالت و گارانتی رسمی در درگاه امن دیجی‌کالا ثبت می‌شوند.',
            'ایوازار قیمت و اطلاعات کالا را نمایش می‌دهد و برای خرید شما را به سایت فروشنده منتقل می‌کند. پرداخت، ارسال، گارانتی و مرجوعی توسط فروشنده انجام می‌شود.',
        ],
        'evazar_opt_footer_about_text' => [
            'ایوازار، سامانه هوشمند کشف، بررسی تخصصی و مقایسه قیمت کالاهای دیجی‌کالا است. هدف ما ارائه تحلیل‌های بی‌طرفانه، راهنمایی خرید با هوش مصنوعی و اتصال امن کاربران به درگاه رسمی دیجی‌کالا است.',
            'ایوازار سامانه‌ای برای کشف، بررسی تخصصی و مقایسه قیمت کالاهاست. برای خرید، کاربر به سایت فروشنده هدایت می‌شود و پرداخت، ارسال و مرجوعی توسط همان فروشنده انجام می‌شود.',
        ],
        'evazar_opt_brand_meta_desc_template' => [
            'مشاهده لیست قیمت روز، مشخصات فنی و خرید آنلاین انواع {brand} در {site_name} با تضمین اصالت و ارسال سریع.',
            'مشاهده لیست قیمت روز و مشخصات فنی انواع {brand} در {site_name} و بررسی گزینه‌های خرید از فروشندگان معتبر.',
        ],
        'evazar_opt_category_meta_desc_template' => [
            'مشاهده لیست قیمت روز، مشخصات فنی و خرید آنلاین انواع {category} در {site_name} با تضمین اصالت و ارسال سریع.',
            'مشاهده لیست قیمت روز و مشخصات فنی انواع {category} در {site_name} و بررسی گزینه‌های خرید از فروشندگان معتبر.',
        ],
    ];

    foreach ($safe_updates as $key => $pair) {
        $current = get_option($key, null);
        if ($current !== null && (string) $current === (string) $pair[0]) {
            update_option($key, $pair[1], false);
        }
    }

    // FAQ قدیمیِ فروشگاه مستقیم؛ فقط در صورت برابری کامل با مقدار پیش‌فرض قدیمی جایگزین می‌شود.
    $legacy_faq = "آیا خرید از ایوازار هزینه یا کارمزد اضافی دارد؟ | خیر، به هیچ وجه. شما دقیقا با همان قیمت مصوب دیجی‌کالا و بدون حتی یک ریال هزینه اضافه خرید می‌کنید.\nآیا کالاها گارانتی و مهلت بازگشت دارند؟ | بله، تمامی سفارش‌ها مستقیماً با ضمانت ۷ روزه بازگشت وجه، تضمین اصالت فیزیکی و فاکتور رسمی دیجی‌کالا ارائه می‌شوند.\nپرداخت وجه در چه درگاهی انجام می‌شود؟ | پرداخت تماماً در درگاه امن شاپرک تحت نظارت بانک مرکزی و متعلق به دیجی‌کالا صورت می‌پذیرد.\nارسال سفارش‌ها چگونه انجام می‌شود؟ | تحویل کالا با بسته‌بندی پلمپ و اصالت کالا توسط ناوگان اکسپرس و پست دیجی‌کالا به سراسر کشور انجام می‌شود.";
    $safe_faq = "آیا خرید از ایوازار هزینه یا کارمزد اضافی دارد؟ | خیر. ایوازار فروشنده نیست و برای خرید شما را به سایت فروشنده هدایت می‌کند.\nآیا گارانتی و مهلت بازگشت کالا در ایوازار ارائه می‌شود؟ | خیر. گارانتی، مرجوعی و شرایط خدمات پس از فروش مطابق قوانین و شرایط فروشنده در سایت مقصد است.\nپرداخت وجه در کجا انجام می‌شود؟ | پرداخت مستقیماً در سایت فروشنده انجام می‌شود و اطلاعات کارت بانکی در ایوازار دریافت نمی‌شود.\nقیمت و موجودی کالا چقدر به‌روز است؟ | ایوازار قیمت و موجودی را از منبع فروشنده بررسی و در بازه‌های زمانی مشخص به‌روزرسانی می‌کند.";
    $faq_current = get_option('evazar_opt_about_faq_items', null);
    if ($faq_current !== null && (string)$faq_current === $legacy_faq) {
        update_option('evazar_opt_about_faq_items', $safe_faq, false);
    }

    update_option('evazar_theme_migration_1510_done', '1', false);
}
add_action('after_setup_theme', 'evazar_theme_upgrade_1510', 20);

// 3. لود فونت‌ها، متغیرهای داینامیک رنگ و کدهای سفارشی
function evazar_theme_resource_hints($urls, $relation_type) {
    if ($relation_type !== 'preconnect') {
        return $urls;
    }

    $cdn = trim(get_option('evazar_image_cdn_domain', 'https://img.evazar.ir'));
    $host = wp_parse_url($cdn, PHP_URL_HOST);
    if ($host && !in_array('https://' . $host, $urls, true)) {
        $urls[] = 'https://' . $host;
    }
    return $urls;
}
add_filter('wp_resource_hints', 'evazar_theme_resource_hints', 10, 2);

function evazar_theme_enqueue_scripts() {
    $theme_obj = wp_get_theme();
    $theme_ver = ($theme_obj && $theme_obj->exists()) ? $theme_obj->get('Version') : '1.10.10';

    // بارگذاری فونت‌های محلی و فوق‌سریع پوسته (۱۰۰٪ آفلاین و بدون وابستگی به سرورهای خارجی)
    wp_enqueue_style( 'evazar-local-fonts', get_theme_file_uri('assets/css/fonts.css'), array(), $theme_ver );

    $font = get_option('evazar_opt_font', 'vazirmatn');
    switch ($font) {
        case 'yekanbakh':
            $font_family = "'YekanBakh', 'Vazirmatn', sans-serif";
            break;
        case 'system':
            $font_family = "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Tahoma, sans-serif";
            break;
        case 'vazirmatn':
        default:
            $font_family = "'Vazirmatn', sans-serif";
            break;
    }

    // استایل اصلی پوسته
    wp_enqueue_style( 'evazar-style', get_stylesheet_uri(), array(), $theme_ver );

    // ماژول اختصاصی جستجوی زنده و هوشمند ایوازار (سبک دیجی‌کالا و مبلک)
    wp_enqueue_style( 'evazar-search', get_template_directory_uri() . '/assets/css/search.css', array('evazar-style'), $theme_ver );
    wp_enqueue_script( 'evazar-search', get_theme_file_uri('assets/js/search.js'), array(), $theme_ver, true );
    wp_localize_script( 'evazar-search', 'evazar_search_vars', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'home_url' => home_url('/'),
        'nonce'    => wp_create_nonce('evazar_search_nonce'),
    ));

    // تعاملات ارگونومیک، ناوبری لمسی و درگ دسکتاپ
    wp_enqueue_script( 'evazar-interactions', get_theme_file_uri('assets/js/theme-interactions.js'), array(), $theme_ver, true );

    // فیلترهای آرشیو فقط در صفحاتی که واقعاً از آن‌ها استفاده می‌کنند.
    $evazar_archive_assets = (
        is_post_type_archive('evazar_product') ||
        is_tax(array('evazar_brand', 'evazar_category')) ||
        is_search() ||
        in_array((string) get_query_var('evazar_directory'), array('brand', 'category'), true)
    );

    if ($evazar_archive_assets) {
        wp_enqueue_style( 'evazar-archive-filters', get_theme_file_uri('assets/css/archive-filters.css'), array('evazar-style'), $theme_ver );
        wp_enqueue_script( 'evazar-archive-filters', get_theme_file_uri('assets/js/archive-filters.js'), array(), $theme_ver, true );
        wp_localize_script( 'evazar-archive-filters', 'evazar_archive_filters_vars', array(
            'ajax_url'       => admin_url('admin-ajax.php'),
            'nonce'          => wp_create_nonce('evazar_archive_filters_nonce'),
            'home_url'       => home_url('/'),
            'posts_per_page' => intval(get_option('evazar_opt_archive_posts_per_page', 16)),
        ) );
    }


    // تزریق استایل‌های داینامیک تنظیمات (رنگ‌ها، فونت، ستون‌ها، هدر چسبان و CSS اختصاصی)
    $primary_color        = get_option('evazar_opt_primary_color', '#ef394e');
    $secondary_color      = get_option('evazar_opt_secondary_color', '#0284c7');
    $top_notice_bg        = get_option('evazar_opt_top_notice_bg', '#0f172a');
    $top_notice_color     = get_option('evazar_opt_top_notice_color', '#ffffff');
    $archive_desktop_cols = get_option('evazar_opt_archive_desktop_cols', '5');
    $archive_mobile_cols  = get_option('evazar_opt_archive_mobile_cols', '2');
    $header_sticky        = get_option('evazar_opt_header_sticky', '1');
    $custom_css           = get_option('evazar_opt_custom_css', '');

    $readmore_desk        = intval(get_option('evazar_opt_readmore_desktop_height', 280));
    $readmore_mob         = intval(get_option('evazar_opt_readmore_mobile_height', 200));

    $dynamic_css = "
    :root {
        --primary: {$primary_color};
        --secondary: {$secondary_color};
        --font-main: {$font_family};
        --evazar-readmore-desktop-height: {$readmore_desk}px;
        --evazar-readmore-mobile-height: {$readmore_mob}px;
    }
    body, body * {
        font-family: var(--font-main);
    }
    .evazar-top-notice {
        background: {$top_notice_bg} !important;
        color: {$top_notice_color} !important;
    }";

    if ($header_sticky === '0') {
        $dynamic_css .= "\n.evazar-header { position: static !important; }";
    } else {
        $dynamic_css .= "\n.evazar-header { position: -webkit-sticky !important; position: sticky !important; top: 0 !important; z-index: 1000 !important; }";
    }

    $trust_bar_mob = get_option('evazar_opt_trust_bar_mobile', '1');
    if ($trust_bar_mob === '0') {
        $dynamic_css .= "\n@media (max-width: 768px) { .evazar-trust-bar-section.trust-hide-mobile { display: none !important; } }";
    }

    // تنظیم هوشمند و آبشاری تعداد ستون‌های محصولات در انواع رزولوشن (Zero Overflow)
    switch ($archive_desktop_cols) {
        case '6':
            $dynamic_css .= "\n@media (min-width: 1450px) { .evazar-archive-grid { grid-template-columns: repeat(6, 1fr) !important; gap: 16px !important; } }";
            $dynamic_css .= "\n@media (max-width: 1449px) and (min-width: 1200px) { .evazar-archive-grid { grid-template-columns: repeat(5, 1fr) !important; } }";
            $dynamic_css .= "\n@media (max-width: 1199px) and (min-width: 950px) { .evazar-archive-grid { grid-template-columns: repeat(4, 1fr) !important; } }";
            $dynamic_css .= "\n@media (max-width: 949px) and (min-width: 721px) { .evazar-archive-grid { grid-template-columns: repeat(3, 1fr) !important; } }";
            break;
        case '5':
            $dynamic_css .= "\n@media (min-width: 1350px) { .evazar-archive-grid { grid-template-columns: repeat(5, 1fr) !important; gap: 18px !important; } }";
            $dynamic_css .= "\n@media (max-width: 1349px) and (min-width: 1050px) { .evazar-archive-grid { grid-template-columns: repeat(4, 1fr) !important; } }";
            $dynamic_css .= "\n@media (max-width: 1049px) and (min-width: 721px) { .evazar-archive-grid { grid-template-columns: repeat(3, 1fr) !important; } }";
            break;
        case '3':
            $dynamic_css .= "\n@media (min-width: 950px) { .evazar-archive-grid { grid-template-columns: repeat(3, 1fr) !important; gap: 22px !important; } }";
            $dynamic_css .= "\n@media (max-width: 949px) and (min-width: 721px) { .evazar-archive-grid { grid-template-columns: repeat(2, 1fr) !important; } }";
            break;
        case 'auto':
            $dynamic_css .= "\n@media (min-width: 721px) { .evazar-archive-grid { grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)) !important; gap: 18px !important; } }";
            break;
        case '4':
        default:
            $dynamic_css .= "\n@media (min-width: 1150px) { .evazar-archive-grid { grid-template-columns: repeat(4, 1fr) !important; gap: 20px !important; } }";
            $dynamic_css .= "\n@media (max-width: 1149px) and (min-width: 721px) { .evazar-archive-grid { grid-template-columns: repeat(3, 1fr) !important; } }";
            break;
    }

    if ($archive_mobile_cols === '1') {
        $dynamic_css .= "\n@media (max-width: 720px) { .evazar-archive-grid { grid-template-columns: 1fr !important; } }";
    } else {
        $dynamic_css .= "\n@media (max-width: 720px) { .evazar-archive-grid { grid-template-columns: repeat(2, 1fr) !important; gap: 10px !important; } }";
    }

    if (!empty($custom_css)) {
        $dynamic_css .= "\n" . $custom_css;
    }

    wp_add_inline_style( 'evazar-style', $dynamic_css );
}
add_action( 'wp_enqueue_scripts', 'evazar_theme_enqueue_scripts' );

// 4. خروجی Preload فونت محلی، فاوآیکون و کدهای سفارشی در تگ Head
function evazar_theme_head_tags() {
    $font = get_option('evazar_opt_font', 'vazirmatn');
    $tpl_uri = get_theme_file_uri('');
    
    // پیش‌بارگذاری بهینه و پرسرعت وب‌فونت (Preload WOFF2)
    if ($font === 'vazirmatn' || empty($font)) {
        echo '<link rel="preload" href="' . esc_url($tpl_uri . '/assets/fonts/vazirmatn/VazirmatnVF.woff2') . '" as="font" type="font/woff2" crossorigin="anonymous">' . "\n";
    } elseif ($font === 'yekanbakh') {
        echo '<link rel="preload" href="' . esc_url($tpl_uri . '/assets/fonts/yekanbakh/YekanBakhFaNum-Regular.woff2') . '" as="font" type="font/woff2" crossorigin="anonymous">' . "\n";
    }

    $favicon = get_option('evazar_opt_favicon', '');
    if ($favicon) {
        echo '<link rel="shortcut icon" href="' . esc_url($favicon) . '" />' . "\n";
    }

    $header_scripts = get_option('evazar_opt_header_scripts', '');
    if (!empty($header_scripts)) {
        echo $header_scripts . "\n";
    }
}
add_action( 'wp_head', 'evazar_theme_head_tags' );

// 5. ثبت و پشتیبانی از مسیرهای تمیز دایرکتوری، نقشه‌های سایت (Sitemap) و اصلاح خطاهای ۴۰۴
add_action('init', 'evazar_register_directory_rewrites', 1);
function evazar_register_directory_rewrites() {
    add_rewrite_rule('^brand/?$', 'index.php?evazar_directory=brand', 'top');
    add_rewrite_rule('^brands/?$', 'index.php?evazar_directory=brand', 'top');
    add_rewrite_rule('^product-category/?$', 'index.php?evazar_directory=category', 'top');
    add_rewrite_rule('^categories/?$', 'index.php?evazar_directory=category', 'top');

    // قوانین ری‌رایت اختصاصی برای نقشه‌های سایت و حل قطعی خطای ۴۰۴ در رنک‌مث
    add_rewrite_rule('^sitemap_index\.xml$', 'index.php?sitemap=1', 'top');
    add_rewrite_rule('^sitemap\.xml$', 'index.php?sitemap=1', 'top');
    add_rewrite_rule('^([^/]+?)-sitemap([0-9]+)?\.xml$', 'index.php?sitemap=$matches[1]&sitemap_n=$matches[2]', 'top');
    add_rewrite_rule('^([a-zA-Z0-9_-]+)-sitemap\.xsl$', 'index.php?xsl=$matches[1]', 'top');
    add_rewrite_rule('^main-sitemap\.xsl$', 'index.php?xsl=main', 'top');

    // مسیرهای جایگزین و پرکاربرد فروشگاه برای جلوگیری از خطای ۴۰۴
    add_rewrite_rule('^products/?$', 'index.php?post_type=evazar_product', 'top');
    add_rewrite_rule('^shop/?$', 'index.php?post_type=evazar_product', 'top');
    add_rewrite_rule('^store/?$', 'index.php?post_type=evazar_product', 'top');
    add_rewrite_rule('^kala/?$', 'index.php?post_type=evazar_product', 'top');

    // فلاش هوشمند و یک‌باره ری‌رایت رولز در پایگاه داده
    if (get_option('evazar_sitemap_rules_flushed_v4') !== '1') {
        flush_rewrite_rules(false);
        update_option('evazar_sitemap_rules_flushed_v4', '1');
    }
}

add_filter('query_vars', function($vars) {
    $vars[] = 'evazar_directory';
    $vars[] = 'sitemap';
    $vars[] = 'sitemap_n';
    $vars[] = 'xsl';
    return $vars;
});

/**
 * رهگیری آنی و بدون خطای درخواست‌های نقشه سایت در مرحله Parse Request
 * حل تضمینی خطای ۴۰۴ نقشه سایت رنک‌مث حتی قبل از لود ری‌رایت‌های دیتابیس
 */
add_action('parse_request', 'evazar_sitemap_parse_request_handler', 1);
function evazar_sitemap_parse_request_handler($wp) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');

    // ۱. نقشه اصلی سایت
    if ($path === 'sitemap_index.xml' || $path === 'sitemap.xml') {
        $wp->query_vars['sitemap'] = '1';
        return;
    }

    // ۲. نقشه‌های فرعی (مانند post-sitemap.xml یا evazar_product-sitemap.xml)
    if (preg_match('#^([a-zA-Z0-9_-]+?)-sitemap([0-9]+)?\.xml$#i', $path, $matches)) {
        $wp->query_vars['sitemap'] = $matches[1];
        if (!empty($matches[2])) {
            $wp->query_vars['sitemap_n'] = $matches[2];
        }
        return;
    }

    // ۳. فایل‌های استایل‌شیت XSL رنک‌مث
    if ($path === 'main-sitemap.xsl' || preg_match('#^([a-zA-Z0-9_-]+?)-sitemap\.xsl$#i', $path, $matches)) {
        $wp->query_vars['xsl'] = !empty($matches[1]) ? $matches[1] : 'main';
        return;
    }

    // ۴. مسیرهای جایگزین آرشیو کالاها
    if ($path === 'products' || $path === 'shop' || $path === 'store' || $path === 'kala') {
        $wp->query_vars['post_type'] = 'evazar_product';
        return;
    }
}

/**
 * هندلر پشتیبان در مرحله template_redirect برای اجرای مستقیم روتر رنک‌مث در صورت نیاز
 */
add_action('template_redirect', 'evazar_sitemap_template_redirect_fallback', 1);
function evazar_sitemap_template_redirect_fallback() {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $path = trim(parse_url($uri, PHP_URL_PATH), '/');

    if ($path === 'sitemap_index.xml' || $path === 'sitemap.xml' || preg_match('#-sitemap[0-9]*\.(xml|xsl)$#i', $path)) {
        if (class_exists('\RankMath\Sitemap\Router')) {
            if (empty(get_query_var('sitemap')) && ($path === 'sitemap_index.xml' || $path === 'sitemap.xml')) {
                set_query_var('sitemap', '1');
            } elseif (empty(get_query_var('sitemap')) && preg_match('#^([a-zA-Z0-9_-]+?)-sitemap([0-9]+)?\.xml$#i', $path, $m)) {
                set_query_var('sitemap', $m[1]);
                if (!empty($m[2])) set_query_var('sitemap_n', $m[2]);
            }
            \RankMath\Sitemap\Router::get()->template_redirect();
            exit;
        }
    }
}

/**
 * شمولیت قطعی کالاهای ایوازار، دسته‌ها و برندها در نقشه سایت رنک‌مث
 */
add_filter('rank_math/sitemap/post_types', function($post_types) {
    if (!isset($post_types['evazar_product'])) {
        $post_types['evazar_product'] = 'evazar_product';
    }
    return $post_types;
});
add_filter('rank_math/sitemap/taxonomies', function($taxonomies) {
    if (!isset($taxonomies['evazar_category'])) {
        $taxonomies['evazar_category'] = 'evazar_category';
    }
    if (!isset($taxonomies['evazar_brand'])) {
        $taxonomies['evazar_brand'] = 'evazar_brand';
    }
    return $taxonomies;
});

/**
 * بومی‌سازی و فارسی‌سازی کامل عنوان برگه خطای ۴۰۴ در تب مرورگر و سئو
 * رفع عنوان انگلیسی ناخوشایند Page Not Found
 */
add_filter('document_title_parts', 'evazar_theme_404_document_title', 9999);
function evazar_theme_404_document_title($parts) {
    if (is_404()) {
        $parts['title'] = get_option('evazar_opt_404_tab_title', 'صفحه مورد نظر یافت نشد (خطای ۴۰۴)');
    }
    return $parts;
}

add_filter('pre_get_document_title', 'evazar_theme_404_pre_title', 9999);
function evazar_theme_404_pre_title($title) {
    if (is_404()) {
        $custom_title = get_option('evazar_opt_404_tab_title', 'صفحه مورد نظر یافت نشد (خطای ۴۰۴)');
        $site_name = get_bloginfo('name');
        return $custom_title . ($site_name ? ' - ' . $site_name : '');
    }
    return $title;
}

add_filter('rank_math/frontend/title', 'evazar_theme_rank_math_404_title', 9999);
function evazar_theme_rank_math_404_title($title) {
    if (is_404()) {
        $custom_title = get_option('evazar_opt_404_tab_title', 'صفحه مورد نظر یافت نشد (خطای ۴۰۴)');
        $site_name = get_bloginfo('name');
        return $custom_title . ($site_name ? ' - ' . $site_name : '');
    }
    return $title;
}

add_filter('wp_title', 'evazar_theme_404_wp_title', 9999, 2);
function evazar_theme_404_wp_title($title, $sep) {
    if (is_404()) {
        $custom_title = get_option('evazar_opt_404_tab_title', 'صفحه مورد نظر یافت نشد (خطای ۴۰۴)');
        $site_name = get_bloginfo('name');
        return $custom_title . ($sep ? ' ' . trim($sep) . ' ' : ' - ') . $site_name;
    }
    return $title;
}

// توابع کمکی هوشمند تشخیص برگه‌های جامع دایرکتوری برندها و دسته‌بندی‌ها در پوسته
if (!function_exists('evazar_is_brand_directory')) {
    function evazar_is_brand_directory() {
        if (get_query_var('evazar_directory') === 'brand') {
            return true;
        }
        $req_uri    = $_SERVER['REQUEST_URI'] ?? '';
        $clean_path = trim(parse_url($req_uri, PHP_URL_PATH), '/');
        return (bool)preg_match('#(?:^|/)brands?(?:/page/\d+)?/?$#i', $clean_path);
    }
}

if (!function_exists('evazar_is_category_directory')) {
    function evazar_is_category_directory() {
        if (get_query_var('evazar_directory') === 'category') {
            return true;
        }
        $req_uri    = $_SERVER['REQUEST_URI'] ?? '';
        $clean_path = trim(parse_url($req_uri, PHP_URL_PATH), '/');
        return (bool)(preg_match('#(?:^|/)categories?(?:/page/\d+)?/?$#i', $clean_path) || preg_match('#(?:^|/)product-category(?:/page/\d+)?/?$#i', $clean_path));
    }
}

/**
 * سیستم حل قطعی و هوشمند عنوان صفحات برندها، دسته‌ها و آرشیوها (جلوگیری ۱۰۰٪ از نمایش عنوان انگلیسی Archive)
 */
function evazar_theme_get_clean_page_title() {
    $site_name = get_bloginfo('name') ?: 'ایوازار';
    $paged = max(1, intval(get_query_var('paged', 1)), intval(get_query_var('page', 1)));
    $paged_suffix = ($paged > 1) ? ' - صفحه ' . (function_exists('evazar_to_fa_num') ? evazar_to_fa_num($paged) : $paged) : '';

    // ۱. دایرکتوری برندها
    if (evazar_is_brand_directory()) {
        $brand_title = get_option('evazar_opt_brands_page_title', 'برندهای کالا') ?: 'برندهای کالا';
        return trim($brand_title) . $paged_suffix . ' | ' . $site_name;
    }

    // ۲. دایرکتوری دسته‌بندی‌ها
    if (evazar_is_category_directory()) {
        $cat_title = get_option('evazar_opt_categories_page_title', 'دسته‌بندی‌های کالا') ?: 'دسته‌بندی‌های کالا';
        return trim($cat_title) . $paged_suffix . ' | ' . $site_name;
    }

    // ۳. آرشیو تخفیف‌های ویژه و شگفت‌انگیز
    if (isset($_GET['on_sale']) || isset($_GET['discount'])) {
        $sale_title = get_option('evazar_opt_special_offers_title', 'تخفیف‌های ویژه و شگفت‌انگیز') ?: 'تخفیف‌های ویژه و شگفت‌انگیز';
        return trim($sale_title) . $paged_suffix . ' | ' . $site_name;
    }

    // ۴. برگه تکی تاکسونومی برند (مانند /brand/samsung/)
    if (is_tax('evazar_brand')) {
        $term = get_queried_object();
        if ($term && !empty($term->name)) {
            $custom_title = get_term_meta($term->term_id, '_evazar_meta_title', true);
            if (!empty(trim($custom_title))) {
                return trim($custom_title) . $paged_suffix;
            }
            $tpl = get_option('evazar_opt_brand_meta_title_template', 'خرید و قیمت روز انواع محصولات {brand} | {site_name}');
            if (empty(trim($tpl))) $tpl = 'خرید و قیمت روز انواع محصولات {brand} | {site_name}';
            $t = str_replace(['{brand}', '{site_name}', '{title}'], [$term->name, $site_name, $term->name], $tpl);
            return trim($t) . $paged_suffix;
        }
    }

    // ۵. برگه تکی تاکسونومی دسته‌بندی (مانند /category/mobile/)
    if (is_tax('evazar_category') || is_category()) {
        $term = get_queried_object();
        if ($term && !empty($term->name)) {
            $custom_title = get_term_meta($term->term_id, '_evazar_meta_title', true);
            if (!empty(trim($custom_title))) {
                return trim($custom_title) . $paged_suffix;
            }
            $tpl = get_option('evazar_opt_category_meta_title_template', 'خرید و قیمت روز انواع {category} | {site_name}');
            if (empty(trim($tpl))) $tpl = 'خرید و قیمت روز انواع {category} | {site_name}';
            $t = str_replace(['{category}', '{site_name}', '{title}'], [$term->name, $site_name, $term->name], $tpl);
            return trim($t) . $paged_suffix;
        }
    }

    // ۶. آرشیو محصولات یا فروشگاه
    if (is_post_type_archive('evazar_product') || (isset($_GET['post_type']) && $_GET['post_type'] === 'evazar_product')) {
        return 'فروشگاه و آرشیو محصولات' . $paged_suffix . ' | ' . $site_name;
    }

    // ۷. بررسی مستقیم URL جهت اطمینان صددرصدی در انواع ساختارهای پیوند یکتا
    $req_uri    = $_SERVER['REQUEST_URI'] ?? '';
    $clean_path = trim(parse_url($req_uri, PHP_URL_PATH), '/');
    if (preg_match('#(^|/)brands?/?$#i', $clean_path)) {
        $brand_title = get_option('evazar_opt_brands_page_title', 'برندهای کالا') ?: 'برندهای کالا';
        return trim($brand_title) . $paged_suffix . ' | ' . $site_name;
    }
    if (preg_match('#(^|/)categories?/?$#i', $clean_path) || preg_match('#(^|/)product-category/?$#i', $clean_path)) {
        $cat_title = get_option('evazar_opt_categories_page_title', 'دسته‌بندی‌های کالا') ?: 'دسته‌بندی‌های کالا';
        return trim($cat_title) . $paged_suffix . ' | ' . $site_name;
    }

    return null;
}

// فیلتر عنوان سند برای وردپرس استاندارد
add_filter('document_title_parts', 'evazar_theme_directory_document_title_parts', 9999);
function evazar_theme_directory_document_title_parts($parts) {
    $custom = evazar_theme_get_clean_page_title();
    if ($custom) {
        $parts['title'] = $custom;
        unset($parts['site'], $parts['tagline']);
        return $parts;
    }
    // پاکسازی قطعی کلمه انگلیسی Archive
    if (isset($parts['title']) && in_array(trim($parts['title']), ['Archive', 'Archives', 'بایگانی'], true)) {
        $parts['title'] = 'کالاهای ایوازار';
    }
    return $parts;
}

add_filter('pre_get_document_title', 'evazar_theme_directory_pre_title', 9999);
function evazar_theme_directory_pre_title($title) {
    $custom = evazar_theme_get_clean_page_title();
    if ($custom) {
        return $custom;
    }
    if (in_array(trim($title), ['Archive', 'Archives', 'بایگانی'], true) || strpos($title, 'Archive ') === 0 || strpos($title, 'Archive -') === 0 || strpos($title, 'Archive |') === 0) {
        return 'کالاهای ایوازار | ' . (get_bloginfo('name') ?: 'ایوازار');
    }
    return $title;
}

add_filter('wp_title', 'evazar_theme_directory_wp_title', 9999, 2);
function evazar_theme_directory_wp_title($title, $sep) {
    $custom = evazar_theme_get_clean_page_title();
    if ($custom) {
        return $custom;
    }
    if (in_array(trim($title), ['Archive', 'Archives', 'بایگانی'], true)) {
        return 'کالاهای ایوازار | ' . (get_bloginfo('name') ?: 'ایوازار');
    }
    return $title;
}

// فیلترهای یکپارچه برای افزونه‌های سئو (Rank Math و Yoast SEO)
add_filter('rank_math/frontend/title', 'evazar_theme_rank_math_archive_title', 9999);
add_filter('rank_math/opengraph/facebook/title', 'evazar_theme_rank_math_archive_title', 9999);
add_filter('rank_math/opengraph/twitter/title', 'evazar_theme_rank_math_archive_title', 9999);
add_filter('wpseo_title', 'evazar_theme_rank_math_archive_title', 9999);
function evazar_theme_rank_math_archive_title($title) {
    $custom = evazar_theme_get_clean_page_title();
    if ($custom) {
        return $custom;
    }
    if (in_array(trim($title), ['Archive', 'Archives', 'بایگانی'], true) || strpos($title, 'Archive ') === 0 || strpos($title, 'Archive -') === 0 || strpos($title, 'Archive |') === 0) {
        return 'کالاهای ایوازار | ' . (get_bloginfo('name') ?: 'ایوازار');
    }
    return $title;
}

/**
 * نگاشت هوشمند آیکون‌های متناسب با نام دسته‌بندی‌ها (سبک ۴: توپر بولد Bold Solid Glyph با کنتراست بالا)
 */
function evazar_get_category_icon($cat_name) {
    $n = mb_strtolower($cat_name);
    // ۱. دسته‌بندی اختصاصی موبایل، گوشی و تبلت (آیکون گوشی هوشمند مدرن و بولد)
    if (strpos($n, 'موبایل') !== false || strpos($n, 'گوشی') !== false || strpos($n, 'تبلت') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M17 1.01L7 1c-1.1 0-2 .9-2 2v18c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V3c0-1.1-.9-1.99-2-1.99zM17 19H7V5h10v14zm-5-3c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5-1.5-.67-1.5-1.5.67-1.5 1.5-1.5z"/></svg>';
    }
    // ۲. کالای دیجیتال، کامپیوتر و لپ‌تاپ (آیکون لپ‌تاپ)
    if (strpos($n, 'دیجیتال') !== false || strpos($n, 'لپ') !== false || strpos($n, 'کامپیوتر') !== false || strpos($n, 'مانیتور') !== false || strpos($n, 'pc') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M20 18c1.1 0 1.99-.9 1.99-2L22 5c0-1.1-.9-2-2-2H4c-1.1 0-2 .9-2 2v11c0 1.1.9 2 2 2H0c0 1.1.9 2 2 2h20c1.1 0 2-.9 2-2h-4zM4 5h16v11H4V5z"/></svg>';
    }
    if (strpos($n, 'ذخیره') !== false || strpos($n, 'هارد') !== false || strpos($n, 'فلش') !== false || strpos($n, 'رم') !== false || strpos($n, 'کارت حافظه') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M2 20h20v-4H2v4zm2-3h2v2H4v-2zM2 4v4h20V4H2zm4 3H4V5h2v2zm-4 7h20v-4H2v4zm2-3h2v2H4v-2z"/></svg>';
    }
    if (strpos($n, 'بازی') !== false || strpos($n, 'گیم') !== false || strpos($n, 'کنسول') !== false || strpos($n, 'پلی‌استیشن') !== false || strpos($n, 'ایکس باکس') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M21 6H3c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-10 7H8v3H6v-3H3v-2h3V8h2v3h3v2zm4.5 2c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm3-3c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z"/></svg>';
    }
    if (strpos($n, 'صوتی') !== false || strpos($n, 'هدفون') !== false || strpos($n, 'اسپیکر') !== false || strpos($n, 'موزیک') !== false || strpos($n, 'هندزفری') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M12 1a9 9 0 0 0-9 9v7c0 1.66 1.34 3 3 3h3v-8H5v-2c0-3.87 3.13-7 7-7s7 3.13 7 7v2h-4v8h3c1.66 0 3-1.34 3-3v-7a9 9 0 0 0-9-9z"/></svg>';
    }
    if (strpos($n, 'خانه') !== false || strpos($n, 'آشپزخانه') !== false || strpos($n, 'فرش') !== false || strpos($n, 'مبل') !== false || strpos($n, 'دکور') !== false || strpos($n, 'پخت') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/></svg>';
    }
    if (strpos($n, 'مد') !== false || strpos($n, 'پوشاک') !== false || strpos($n, 'لباس') !== false || strpos($n, 'کفش') !== false || strpos($n, 'کیف') !== false || strpos($n, 'ساعت') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M21.6 4.4L16 2a4 4 0 0 1-8 0L2.4 4.4c-.6.3-.9.9-.8 1.6l1 6c.1.6.6 1 1.2 1H6v7c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2v-7h2.2c.6 0 1.1-.4 1.2-1l1-6c.1-.7-.2-1.3-.8-1.6z"/></svg>';
    }
    if (strpos($n, 'زیبایی') !== false || strpos($n, 'سلامت') !== false || strpos($n, 'آرایش') !== false || strpos($n, 'عطر') !== false || strpos($n, 'پوست') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>';
    }
    if (strpos($n, 'سوپرمارکت') !== false || strpos($n, 'خوراکی') !== false || strpos($n, 'مواد غذایی') !== false || strpos($n, 'تنقلات') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/></svg>';
    }
    if (strpos($n, 'ورزش') !== false || strpos($n, 'سفر') !== false || strpos($n, 'کمپ') !== false || strpos($n, 'کوهنوردی') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>';
    }
    if (strpos($n, 'خودرو') !== false || strpos($n, 'ابزار') !== false || strpos($n, 'صنعتی') !== false || strpos($n, 'موتور') !== false || strpos($n, 'یدکی') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"/></svg>';
    }
    if (strpos($n, 'کتاب') !== false || strpos($n, 'تحریر') !== false || strpos($n, 'هنر') !== false || strpos($n, 'لوازم تحریر') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 4h5v8l-2.5-1.5L6 12V4z"/></svg>';
    }
    if (strpos($n, 'کودک') !== false || strpos($n, 'نوزاد') !== false || strpos($n, 'اسباب بازی') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-1.99.9-1.99 2v3.8H3.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h3.8v-1.5c0-1.49 1.21-2.7 2.7-2.7 1.49 0 2.7 1.21 2.7 2.7V22H17c1.1 0 2-.9 2-2v-4h1.5c1.49 0 2.7-1.21 2.7-2.7s-1.21-2.7-2.7-2.7z"/></svg>';
    }
    // ۱۳. محصولات بومی، محلی، سنتی و صنایع دستی (آیکون اصیل کوزه سنتی و صنایع دستی)
    if (strpos($n, 'بومی') !== false || strpos($n, 'محلی') !== false || strpos($n, 'سنتی') !== false || strpos($n, 'صنایع دستی') !== false || strpos($n, 'سوغات') !== false || strpos($n, 'روستایی') !== false || strpos($n, 'دستباف') !== false || strpos($n, 'سفال') !== false || strpos($n, 'گیوه') !== false || strpos($n, 'زعفران') !== false) {
        return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M19 12h-2.15c-.29-2.3-1.67-4.22-3.85-5.18V4h1V2H10v2h1v2.82C8.82 7.78 7.44 9.7 7.15 12H5c-1.1 0-2 .9-2 2v1c0 2.21 1.79 4 4 4h.18C8.2 20.31 9.97 21.5 12 21.5s3.8-.99 4.82-2.5H17c2.21 0 4-1.79 4-4v-1c0-1.1-.9-2-2-2zm-14 3v-1h2.05c.04.34.1.67.19 1H5zm14 0h-2.24c.09-.33.15-.66.19-1H19v1z"/></svg>';
    }
    return '<svg class="dk-cat-icon-svg" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z"/></svg>';
}

/**
 * تبدیل هوشمند ارقام انگلیسی به فارسی (ویژه قیمت‌ها، تخفیف‌ها، امتیازات و شمارنده‌ها - بدون تغییر نام کالا)
 */
function evazar_to_fa_num($str) {
    if ($str === null || $str === '') return '';
    $en = ['0','1','2','3','4','5','6','7','8','9'];
    $fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    return str_replace($en, $fa, (string)$str);
}

/**
 * تبدیل هوشمند ارقام فارسی و عربی به انگلیسی
 */
function evazar_to_en_num($str) {
    if ($str === null || $str === '') return '';
    $fa = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹', '٠','١','٢','٣','٤','٥','٦','٧','٨','٩'];
    $en = ['0','1','2','3','4','5','6','7','8','9', '0','1','2','3','4','5','6','7','8','9'];
    return str_replace($fa, $en, (string)$str);
}

/**
 * اصلاح و یکدست‌سازی هوشمند ابعاد و ارقام در متن نقد و بررسی کالا
 * - جایگزینی حرف انگلیسی x در ابعاد با علامت ضربدر استاندارد × (مانند ۱۶۰ × ۱۱۰ × ۶۵)
 * - تبدیل ارقام وصله‌پینه‌ای هوش مصنوعی (مانند ۳0000 یا ۱۶0) به ارقام یکدست فارسی
 */
function evazar_clean_product_review_content($content) {
    if (empty($content) || !is_string($content)) return $content;

    // ۱. اصلاح ابعاد ترکیبی (تبدیل x به علامت ضربدر × و فارسی‌سازی اعداد ابعاد مانند ۱۶۰ × ۱۱۰ × ۶۵)
    $content = preg_replace_callback('/([0-9۰-۹]+(?:\.[0-9۰-۹]+)?)\s*[xX×]\s*([0-9۰-۹]+(?:\.[0-9۰-۹]+)?)(?:\s*[xX×]\s*([0-9۰-۹]+(?:\.[0-9۰-۹]+)?))?/u', function($m) {
        $n1 = evazar_to_fa_num($m[1]);
        $n2 = evazar_to_fa_num($m[2]);
        if (!empty($m[3])) {
            $n3 = evazar_to_fa_num($m[3]);
            return "{$n1} × {$n2} × {$n3}";
        }
        return "{$n1} × {$n2}";
    }, $content);

    // ۲. اصلاح ارقام چسبیده وصله‌پینه‌ای (مانند ۳0000 یا ۱۶0) به فارسی یکدست
    $content = preg_replace_callback('/([۰-۹]+[0-9]+|[0-9]+[۰-۹]+)/u', function($m) {
        return evazar_to_fa_num($m[0]);
    }, $content);

    return $content;
}
add_filter('the_content', 'evazar_clean_product_review_content', 15);

/**
 * فرمت‌بندی هوشمند شماره‌های تماس و پشتیبانی به فارسی استاندارد با چینش صحیح در زبان راست‌چین
 */
function evazar_format_phone_display($phone) {
    if (empty($phone)) return '';
    $phone_str = trim((string)$phone);
    // تبدیل ارقام به فارسی
    $phone_fa = evazar_to_fa_num($phone_str);
    return $phone_fa;
}

/**
 * فرمت‌بندی هوشمند قیمت با ارقام زیبای فارسی
 */
function evazar_format_price($price) {
    if ($price === null || $price === '' || $price === false) return '';
    $clean = str_replace([',', ' ', '،'], '', evazar_to_en_num((string)$price));
    if (!is_numeric($clean)) return evazar_to_fa_num(esc_html($price));
    $formatted = number_format(floatval($clean));
    return evazar_to_fa_num($formatted);
}

/**
 * استخراج و تولید نشان تمیز درصد تخفیف کالا (دقیقاً مشابه دیجی‌کالا مانند ۲۲٪ یا ۸٪)
 * جلوگیری از نمایش ناقص درصد تخفیف و محاسبه خودکار در صورت وجود تفاوت قیمت قدیم و جدید
 */
function evazar_get_clean_discount_badge($discount_raw = '', $old_price = 0, $current_price = 0) {
    $disc_num = 0;
    if (!empty($discount_raw)) {
        $discount_en = evazar_to_en_num((string)$discount_raw);
        if (preg_match('/(\d+)/', $discount_en, $m)) {
            $disc_num = intval($m[1]);
        }
    }
    // در صورت خالی بودن متادیتای درصد تخفیف، محاسبه ریاضی از روی تفاوت قیمت قدیم و جدید
    if ($disc_num <= 0) {
        $c_old_raw = evazar_to_en_num((string)$old_price);
        $c_cur_raw = evazar_to_en_num((string)$current_price);
        $c_old = floatval(str_replace([',', ' ', '،'], '', $c_old_raw));
        $c_cur = floatval(str_replace([',', ' ', '،'], '', $c_cur_raw));
        if ($c_old > 0 && $c_cur > 0 && $c_old > $c_cur) {
            $disc_num = round((($c_old - $c_cur) / $c_old) * 100);
        }
    }
    if ($disc_num > 0 && $disc_num < 100) {
        return evazar_to_fa_num($disc_num) . '٪';
    }
    return '';
}

/**
 * بازگرداندن آیکون‌های وکتوری مدرن و واکنش‌گرا برای نوار مزایای خرید (Trust Bar Icons)
 */
function evazar_get_trust_icon_svg($icon = 'shield') {
    switch ($icon) {
        case 'zap':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>';
        case 'ai':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="10" rx="2"></rect><circle cx="12" cy="5" r="2"></circle><path d="M12 7v4"></path><line x1="8" y1="16" x2="8.01" y2="16"></line><line x1="16" y1="16" x2="16.01" y2="16"></line></svg>';
        case 'lock':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>';
        case 'truck':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>';
        case 'return':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"></polyline><polyline points="23 20 23 14 17 14"></polyline><path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"></path></svg>';
        case 'support':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 18v-6a9 9 0 0 1 18 0v6"></path><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"></path></svg>';
        case 'star':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>';
        case 'shield':
        default:
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><path d="m9 12 2 2 4-4"></path></svg>';
    }
}

/**
 * تابع رندر سیستم مشاهده بیشتر و محوشدگی متون (Read More System)
 * الهام‌گرفته از پوسته اختصاصی مبلک با عملکرد ۱۰۰٪ ایزوله و گرادیان شیشه‌ای
 */
function evazar_render_readmore($content, $section = 'general', $custom_threshold = null) {
    if (empty(trim(strip_tags($content)))) {
        return $content;
    }

    $enable_all = get_option('evazar_opt_enable_readmore', '1');
    if ($enable_all !== '1') {
        return $content;
    }

    // بررسی فعال بودن بخش درخواستی
    if (($section === 'product' || $section === 'product_short') && get_option('evazar_opt_readmore_product', '1') !== '1') {
        return $content;
    }
    if ($section === 'archive' && get_option('evazar_opt_readmore_archive', '1') !== '1') {
        return $content;
    }
    if ($section === 'home' && get_option('evazar_opt_readmore_home', '1') !== '1') {
        return $content;
    }
    if ($section === 'footer' && get_option('evazar_opt_readmore_footer', '1') !== '1') {
        return $content;
    }

    $threshold = $custom_threshold !== null ? intval($custom_threshold) : intval(get_option('evazar_opt_readmore_char_threshold', 220));
    $plain_len = mb_strlen(trim(strip_tags($content)));

    if ($plain_len < $threshold) {
        return $content;
    }

    $desk_h = intval(get_option('evazar_opt_readmore_desktop_height', 280));
    $mob_h  = intval(get_option('evazar_opt_readmore_mobile_height', 200));

    $unique_id = 'evazar-rm-' . wp_rand(1000, 99999);
    $extra_class = ($section === 'product_short') ? ' is-short-desc' : '';

    ob_start();
    ?>
    <div class="evazar-readmore-wrapper has-readmore<?php echo esc_attr($extra_class); ?>" id="<?php echo esc_attr($unique_id); ?>" data-readmore="true" data-section="<?php echo esc_attr($section); ?>" data-desk-h="<?php echo esc_attr($desk_h); ?>" data-mob-h="<?php echo esc_attr($mob_h); ?>" style="--evazar-readmore-desktop-height: <?php echo esc_attr($desk_h); ?>px; --evazar-readmore-mobile-height: <?php echo esc_attr($mob_h); ?>px;">
        <div class="evazar-readmore-content">
            <?php echo $content; ?>
        </div>
        <button type="button" class="evazar-readmore-btn" aria-expanded="false" aria-controls="<?php echo esc_attr($unique_id); ?>">
            <span class="readmore-text">مشاهده بیشتر</span>
            <svg class="readmore-icon" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
        </button>
    </div>
    <?php
    return ob_get_clean();
}

// خروجی اسکریپت‌های انتهای صفحه در تگ footer و موتور تعاملی مشاهده بیشتر و پرتال آبشاری
add_action('wp_footer', 'evazar_theme_footer_scripts_output');
function evazar_theme_footer_scripts_output() {
    $footer_scripts = get_option('evazar_opt_footer_scripts', '');
    if (!empty($footer_scripts)) {
        echo $footer_scripts . "\n";
    }
    ?>
    <script>
    (function() {
        // ۱. موتور تعاملی مشاهده بیشتر (Universal ReadMore System - Moblak Inspired)
        function initEvazarReadMore() {
            var wrappers = document.querySelectorAll('.evazar-readmore-wrapper[data-readmore="true"]');
            wrappers.forEach(function(wrap) {
                var content = wrap.querySelector('.evazar-readmore-content');
                var btn = wrap.querySelector('.evazar-readmore-btn');
                if (!content || !btn) return;

                var isMobile = window.innerWidth <= 768;
                var rootStyles = getComputedStyle(document.documentElement);
                var dataDesk = wrap.getAttribute('data-desk-h');
                var dataMob = wrap.getAttribute('data-mob-h');
                var maxH;

                if (isMobile) {
                    maxH = dataMob ? parseInt(dataMob, 10) : parseInt(rootStyles.getPropertyValue('--evazar-readmore-mobile-height') || 200, 10);
                } else {
                    maxH = dataDesk ? parseInt(dataDesk, 10) : parseInt(rootStyles.getPropertyValue('--evazar-readmore-desktop-height') || 280, 10);
                }
                
                // بررسی آستانه ارتفاع محتوا
                if (content.scrollHeight <= maxH + 4) {
                    wrap.classList.remove('has-readmore');
                    btn.style.display = 'none';
                    content.style.maxHeight = 'none';
                } else {
                    if (!wrap.classList.contains('is-expanded')) {
                        wrap.classList.add('has-readmore');
                        content.style.maxHeight = maxH + 'px';
                    }
                    btn.style.display = 'inline-flex';
                }
            });
        }

        // سیستم کلیک دلیگیتد قطعی برای تضمین باز و بسته شدن دکمه‌های مشاهده بیشتر متون
        document.addEventListener('click', function(e) {
            var btn = e.target.closest('.evazar-readmore-btn');
            if (!btn) return;
            var wrap = btn.closest('.evazar-readmore-wrapper');
            if (!wrap) return;

            e.preventDefault();
            e.stopPropagation();

            var content = wrap.querySelector('.evazar-readmore-content');
            var isExpanded = wrap.classList.toggle('is-expanded');
            btn.setAttribute('aria-expanded', isExpanded ? 'true' : 'false');
            btn.classList.toggle('is-expanded', isExpanded);
            var txt = btn.querySelector('.readmore-text');
            if (txt) {
                txt.textContent = isExpanded ? 'بستن' : 'مشاهده بیشتر';
            }

            if (content) {
                if (isExpanded) {
                    content.style.maxHeight = (content.scrollHeight + 100) + 'px';
                } else {
                    var isMobile = window.innerWidth <= 768;
                    var curMaxH = isMobile ? (parseInt(wrap.getAttribute('data-mob-h'), 10) || 200) : (parseInt(wrap.getAttribute('data-desk-h'), 10) || 280);
                    content.style.maxHeight = curMaxH + 'px';
                    wrap.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                }
            }
        });

        // سیستم کلیک دکمه مشاهده بیشتر در ویژگی‌های برجسته کالا (Features Box Toggle)
        document.addEventListener('click', function(e) {
            var featBtn = e.target.closest('.features-toggle-btn');
            if (!featBtn) return;

            e.preventDefault();
            e.stopPropagation();

            var fBox = featBtn.closest('.features-box');
            if (!fBox) return;

            var isExp = fBox.classList.toggle('is-expanded');
            featBtn.setAttribute('aria-expanded', isExp ? 'true' : 'false');
            var txt = featBtn.querySelector('.feat-btn-text');
            if (txt) {
                var extraItems = fBox.querySelectorAll('.feature-item-extra');
                txt.textContent = isExp ? 'بستن ویژگی‌ها' : ('+ مشاهده بیشتر (' + extraItems.length + ' ویژگی دیگر)');
            }
        });

        // ۲. موتور تعاملی پرتال آبشاری دسته‌بندی‌ها در صفحه آرشیو
        function initDkCascade() {
            var cascadeWrap = document.querySelector('.archive-categories-hub .dk-cascade-wrapper');
            if (!cascadeWrap) return;
            var sideItems = cascadeWrap.querySelectorAll('.dk-sidebar .dk-side-item');
            var panels = cascadeWrap.querySelectorAll('.dk-main-panel');

            function activateCat(catId, itemEl) {
                sideItems.forEach(function(it) { it.classList.remove('active'); });
                if (itemEl) itemEl.classList.add('active');
                
                panels.forEach(function(pan) {
                    if (pan.getAttribute('data-cat-id') === String(catId)) {
                        pan.classList.add('active');
                        pan.style.display = 'flex';
                    } else {
                        pan.classList.remove('active');
                        pan.style.display = 'none';
                    }
                });
            }

            sideItems.forEach(function(item) {
                var catId = item.getAttribute('data-cat-id');
                item.addEventListener('mouseenter', function() {
                    if (window.innerWidth > 900) {
                        activateCat(catId, item);
                    }
                });
                item.addEventListener('click', function(e) {
                    activateCat(catId, item);
                });
            });
        }

        // ۳. موتور تعاملی منوی آبشاری دسته‌بندی‌ها در هدر سایت (Digikala Header Mega Menu)
        function initDkHeaderMega() {
            var megaWrapper = document.getElementById('dk-header-mega-wrapper');
            var trigger = document.getElementById('dk-mega-trigger');
            var backdrop = document.getElementById('dk-mega-backdrop');
            if (!megaWrapper || !trigger) return;

            var closeTimer = null;

            function openMega() {
                if (closeTimer) clearTimeout(closeTimer);
                megaWrapper.classList.add('is-open');
                document.body.classList.add('dk-mega-open');
                trigger.setAttribute('aria-expanded', 'true');
            }

            function closeMega() {
                if (closeTimer) clearTimeout(closeTimer);
                closeTimer = setTimeout(function() {
                    megaWrapper.classList.remove('is-open');
                    document.body.classList.remove('dk-mega-open');
                    trigger.setAttribute('aria-expanded', 'false');
                }, 220);
            }

            function closeMegaNow() {
                if (closeTimer) clearTimeout(closeTimer);
                megaWrapper.classList.remove('is-open');
                document.body.classList.remove('dk-mega-open');
                trigger.setAttribute('aria-expanded', 'false');
            }

            // هاور ماوس در دسکتاپ با ثبات کامل و بدون لرزش
            megaWrapper.addEventListener('mouseenter', function() {
                if (window.innerWidth > 768) openMega();
            });
            megaWrapper.addEventListener('mouseleave', function() {
                if (window.innerWidth > 768) closeMega();
            });

            var megaDropdown = document.getElementById('dk-header-mega-dropdown');
            if (megaDropdown) {
                megaDropdown.addEventListener('mouseenter', function() {
                    if (closeTimer) clearTimeout(closeTimer);
                });
                megaDropdown.addEventListener('mouseleave', function() {
                    if (window.innerWidth > 768) closeMega();
                });
            }

            // کلیک روی دکمه در تمام دستگاه‌ها (همیشه تاگل باز و بسته شدن بدون ریفرش صفحه)
            trigger.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                if (megaWrapper.classList.contains('is-open')) {
                    closeMegaNow();
                } else {
                    openMega();
                }
            });

            if (backdrop) {
                backdrop.addEventListener('click', function() {
                    closeMegaNow();
                });
            }

            var btnCloseMobile = document.getElementById('btn-close-dk-menu');
            if (btnCloseMobile) {
                btnCloseMobile.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    closeMegaNow();
                });
            }

            // بستن با کلیک خارج از مگامنو
            document.addEventListener('click', function(e) {
                if (!megaWrapper.contains(e.target)) {
                    closeMegaNow();
                }
            });

            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape') {
                    megaWrapper.classList.remove('is-open');
                    document.body.classList.remove('dk-mega-open');
                    trigger.setAttribute('aria-expanded', 'false');
                }
            });

            // مدیریت سوئیچ دسته‌های منوی هدر
            var headerSideItems = megaWrapper.querySelectorAll('.dk-header-sidebar .dk-side-item');
            var headerPanels = megaWrapper.querySelectorAll('.dk-header-main-panels .dk-main-panel');

            headerSideItems.forEach(function(item) {
                var catId = item.getAttribute('data-cat-id');
                function activateHeaderCat() {
                    headerSideItems.forEach(function(it) { it.classList.remove('active'); });
                    item.classList.add('active');
                    headerPanels.forEach(function(pan) {
                        if (pan.getAttribute('data-cat-id') === String(catId)) {
                            pan.classList.add('active');
                            pan.style.display = 'flex';
                        } else {
                            pan.classList.remove('active');
                            pan.style.display = 'none';
                        }
                    });
                }
                item.addEventListener('mouseenter', activateHeaderCat);
                item.addEventListener('click', function(e) {
                    e.stopPropagation();
                    activateHeaderCat();
                });
            });
        }

        // راه‌اندازی فوری و مقاوم در برابر لود دیرهنگام
        function bootScripts() {
            initEvazarReadMore();
            initDkCascade();
            initDkHeaderMega();
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', bootScripts);
        } else {
            bootScripts();
        }

        window.addEventListener('resize', function() {
            initEvazarReadMore();
        });
    })();
    </script>
    <?php
}

// 5. رندر هدر یکپارچه، واکنش‌گرا و داینامیک سایت
function evazar_render_site_header() {
    $show_top_notice         = get_option('evazar_opt_show_top_notice', '1');
    $top_notice              = get_option('evazar_opt_top_notice', '✨ ایوازار (evazar.ir) | سیستم هوشمند معرفی و بررسی تخصصی کالاهای دیجی‌کالا');
    $show_partner_badge      = get_option('evazar_opt_show_partner_badge', '1');
    $partner_badge_text      = get_option('evazar_opt_partner_badge_text', 'پارتنر رسمی دیجی‌کالا');

    $logo_type               = get_option('evazar_opt_logo_type', 'text');
    $logo_image              = get_option('evazar_opt_logo_image', '');
    $logo_text               = get_option('evazar_opt_logo_text', 'ایــــوازار');
    $logo_letter             = get_option('evazar_opt_logo_letter', 'E');
    $logo_tagline            = get_option('evazar_opt_logo_tagline', 'راهنمای هوشمند انتخاب و خرید کالا');

    $header_show_search      = get_option('evazar_opt_header_show_search', '1');
    $search_placeholder      = get_option('evazar_opt_header_search_placeholder', 'جستجوی کالا، برند یا دسته‌بندی...');
    $show_quick_links        = get_option('evazar_opt_header_show_quick_links', '1');
    $mobile_search_visible   = get_option('evazar_opt_mobile_search_visible', '1');
    ?>
    <!-- TOP NOTIFY -->
    <?php if ($show_top_notice === '1' && !empty($top_notice)): ?>
    <div class="evazar-top-notice">
        <div class="evazar-container evazar-top-notice-content">
            <div class="top-notice-msg"><?php echo esc_html($top_notice); ?></div>
            <div class="badge-affiliate-status">
                <span>🛡 خرید مستقیم از درگاه رسمی دیجی‌کالا</span>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- HEADER NAVBAR -->
    <header class="evazar-header">
        <div class="evazar-container evazar-header-inner">
            <a href="<?php echo home_url('/'); ?>" class="brand-area">
                <?php if ($logo_type === 'image' && !empty($logo_image)): ?>
                    <img src="<?php echo esc_url($logo_image); ?>" alt="<?php echo esc_attr($logo_text); ?>" class="evazar-logo-image" style="max-height: 44px; width: auto; object-fit: contain;">
                <?php else: ?>
                    <div class="logo-box"><?php echo esc_html($logo_letter); ?></div>
                    <div class="logo-text">
                        <h1><?php echo esc_html($logo_text); ?></h1>
                        <?php if ($logo_tagline): ?>
                            <span><?php echo esc_html($logo_tagline); ?></span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </a>

            <?php if ($header_show_search === '1'): ?>
            <div class="header-search desktop-search">
                <?php evazar_render_search_bar(false); ?>
            </div>
            <?php endif; ?>

            <div class="header-actions">
                <?php if ($show_partner_badge === '1'): ?>
                <div class="btn-dk-badge">
                    <img src="https://www.digikala.com/statics/img/png/affiliate-logo.png" onerror="this.style.display='none'">
                    <span><?php echo esc_html($partner_badge_text); ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($header_show_search === '1' && $mobile_search_visible === '1'): ?>
        <!-- MOBILE DEDICATED SEARCH BAR -->
        <div class="evazar-container mobile-search-row">
            <?php evazar_render_search_bar(true); ?>
        </div>
        <?php endif; ?>

        <?php if ($show_quick_links === '1'): 
            $nav_parent_cats = get_terms([
                'taxonomy'   => 'evazar_category',
                'parent'     => 0,
                'hide_empty' => false,
            ]);
            $is_cat_screen = is_tax('evazar_category') || (function_exists('is_product_category') && is_product_category());
            $nav_show_count = get_option('evazar_opt_archive_show_count', '1');
        ?>
        <!-- HEADER QUICK NAV BAR WITH DIGIKALA MEGA MENU -->
        <nav class="header-quick-nav">
            <div class="evazar-container quick-nav-inner">

                <!-- DIGIKALA CASCADE MEGA DROPDOWN (منوی آبشاری دسته‌بندی‌ها در هدر) -->
                <div class="dk-header-mega-wrapper" id="dk-header-mega-wrapper">
                    <a href="<?php echo home_url('/product-category/'); ?>" class="quick-link dk-mega-trigger <?php echo $is_cat_screen ? 'active' : ''; ?>" id="dk-mega-trigger" aria-haspopup="true" aria-expanded="false">
                        <svg class="nav-grid-icon" viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M4 4h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 10h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 16h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4z"/></svg>
                        <span>دسته‌بندی کالاها</span>
                        <svg class="chevron-down" viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/></svg>
                    </a>

                    <?php if (!empty($nav_parent_cats) && !is_wp_error($nav_parent_cats)): ?>
                    <div class="dk-header-mega-dropdown" id="dk-header-mega-dropdown">
                        <!-- نوار بالای منوی تمام‌صفحه موبایل -->
                        <div class="dk-mobile-menu-header">
                            <div class="mobile-menu-title">
                                <svg class="nav-grid-icon" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M4 4h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 10h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 16h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4z"/></svg>
                                <span>دسته‌بندی کالاها</span>
                            </div>
                            <button type="button" class="btn-close-dk-menu" id="btn-close-dk-menu" aria-label="بستن منو">
                                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                            </button>
                        </div>
                        <div class="dk-cascade-wrapper dk-header-cascade">
                            <!-- ستون راست: دسته‌های والد منوی آبشاری هدر -->
                            <aside class="dk-sidebar dk-header-sidebar">
                                <?php foreach ($nav_parent_cats as $h_idx => $hp_cat): 
                                    $h_icon = function_exists('evazar_get_category_icon') ? evazar_get_category_icon($hp_cat->name) : '📁';
                                    $h_first = ($h_idx === 0);
                                ?>
                                <div class="dk-side-item <?php echo $h_first ? 'active' : ''; ?>" data-cat-id="<?php echo esc_attr($hp_cat->term_id); ?>">
                                    <div class="icon-title">
                                        <span class="dk-cat-icon"><?php echo $h_icon; ?></span>
                                        <span class="dk-cat-name"><?php echo esc_html($hp_cat->name); ?></span>
                                    </div>
                                    <div class="dk-side-meta">
                                        <?php if ($nav_show_count === '1' && $hp_cat->count > 0): ?>
                                            <span class="dk-cat-count"><?php echo evazar_to_fa_num(number_format_i18n($hp_cat->count)); ?></span>
                                        <?php endif; ?>
                                        <span class="arrow">‹</span>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </aside>

                            <!-- ستون چپ: پنل‌های زیردسته منوی آبشاری هدر -->
                            <div class="dk-main-panels dk-header-main-panels">
                                <?php foreach ($nav_parent_cats as $h_idx => $hp_cat): 
                                    $h_icon = function_exists('evazar_get_category_icon') ? evazar_get_category_icon($hp_cat->name) : '📁';
                                    $hp_link = get_term_link($hp_cat);
                                    $h_first = ($h_idx === 0);

                                    $h_sub_cats = get_terms([
                                        'taxonomy'   => 'evazar_category',
                                        'parent'     => $hp_cat->term_id,
                                        'hide_empty' => false,
                                    ]);

                                    $h_has_lvl3 = false;
                                    $h_lvl3_map = [];
                                    if (!empty($h_sub_cats) && !is_wp_error($h_sub_cats)) {
                                        foreach ($h_sub_cats as $hsc) {
                                            $hl3 = get_terms([
                                                'taxonomy'   => 'evazar_category',
                                                'parent'     => $hsc->term_id,
                                                'hide_empty' => false,
                                            ]);
                                            if (!empty($hl3) && !is_wp_error($hl3)) {
                                                $h_has_lvl3 = true;
                                                $h_lvl3_map[$hsc->term_id] = $hl3;
                                            }
                                        }
                                    }
                                ?>
                                <div class="dk-main-panel <?php echo $h_first ? 'active' : ''; ?>" data-cat-id="<?php echo esc_attr($hp_cat->term_id); ?>" style="<?php echo $h_first ? '' : 'display: none;'; ?>">
                                    <div class="dk-panel-header">
                                        <div class="title-group">
                                            <span class="dk-header-icon"><?php echo $h_icon; ?></span>
                                            <h3 class="dk-cat-heading">همه زیردسته‌های <?php echo esc_html($hp_cat->name); ?></h3>
                                        </div>
                                        <a href="<?php echo esc_url($hp_link); ?>" class="btn-view-all">مشاهده همه کالاهای این دسته ←</a>
                                    </div>

                                    <?php if (!empty($h_sub_cats) && !is_wp_error($h_sub_cats)): ?>
                                        <?php if ($h_has_lvl3): ?>
                                            <div class="dk-columns-grid">
                                                <?php foreach ($h_sub_cats as $hsc): 
                                                    $hsc_link = get_term_link($hsc);
                                                    $hl3_items = $h_lvl3_map[$hsc->term_id] ?? [];
                                                ?>
                                                <div class="dk-sub-column">
                                                    <h4>
                                                        <a href="<?php echo esc_url($hsc_link); ?>"><?php echo esc_html($hsc->name); ?></a>
                                                        <?php if ($nav_show_count === '1' && $hsc->count > 0): ?>
                                                            <span class="sub-qty">(<?php echo evazar_to_fa_num(number_format_i18n($hsc->count)); ?>)</span>
                                                        <?php endif; ?>
                                                    </h4>
                                                    <?php if (!empty($hl3_items)): ?>
                                                    <ul class="dk-sub-links">
                                                        <?php foreach ($hl3_items as $l3): ?>
                                                        <li>
                                                            <a href="<?php echo esc_url(get_term_link($l3)); ?>">
                                                                <span><?php echo esc_html($l3->name); ?></span>
                                                                <?php if ($nav_show_count === '1' && $l3->count > 0): ?>
                                                                    <span class="sub-count"><?php echo evazar_to_fa_num(number_format_i18n($l3->count)); ?></span>
                                                                <?php endif; ?>
                                                            </a>
                                                        </li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                    <?php endif; ?>
                                                </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php else: ?>
                                            <div class="dk-columns-grid dk-direct-grid">
                                                <?php 
                                                $chunks = array_chunk($h_sub_cats, max(1, ceil(count($h_sub_cats) / 3)));
                                                foreach ($chunks as $chunk):
                                                ?>
                                                <div class="dk-sub-column">
                                                    <ul class="dk-sub-links direct-sub-list">
                                                        <?php foreach ($chunk as $hsc): 
                                                            $hsc_link = get_term_link($hsc);
                                                        ?>
                                                        <li>
                                                            <a href="<?php echo esc_url($hsc_link); ?>" class="dk-direct-sub-item">
                                                                <span class="bullet-dot">›</span>
                                                                <span class="sub-name"><?php echo esc_html($hsc->name); ?></span>
                                                                <?php if ($nav_show_count === '1' && $hsc->count > 0): ?>
                                                                    <span class="sub-count"><?php echo evazar_to_fa_num(number_format_i18n($hsc->count)); ?> کالا</span>
                                                                <?php endif; ?>
                                                            </a>
                                                        </li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <div class="dk-empty-sub">
                                            <div class="dk-empty-icon"><?php echo $h_icon; ?></div>
                                            <p>کالاهای این دسته‌بندی به طور مستقیم فهرست شده‌اند.</p>
                                            <a href="<?php echo esc_url($hp_link); ?>" class="btn-view-all-pill">مشاهده کالاهای <?php echo esc_html($hp_cat->name); ?> ←</a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <a href="<?php echo home_url('/brand/'); ?>" class="quick-link <?php echo is_tax('evazar_brand') ? 'active' : ''; ?>">
                    <svg class="quick-icon" viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58.55 0 1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z"/></svg>
                    <span>برندهای محبوب</span>
                </a>
                <?php 
                $is_discount_active = isset($_GET['on_sale']) || isset($_GET['discount']) || (isset($_GET['s']) && trim($_GET['s']) === 'تخفیف');
                ?>
                <a href="<?php echo home_url('/?post_type=evazar_product&on_sale=1'); ?>" class="quick-link highlight <?php echo $is_discount_active ? 'active' : ''; ?>">
                    <svg class="quick-icon" viewBox="0 0 24 24" width="16" height="16" fill="#ef394e"><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>
                    <span>تخفیف‌های ویژه</span>
                </a>
            </div>
        </nav>
        <div class="dk-mega-backdrop" id="dk-mega-backdrop"></div>
        <?php endif; ?>
    </header>
    <?php
}

// هدایت قطعی درخواست‌های تخفیف‌های ویژه، دایرکتوری برندها و دسته‌ها به قالب آرشیو کالاها (جلوگیری ۱۰۰٪ از لود صفحه اصلی)
add_filter('template_include', 'evazar_theme_sale_template_include', 99);
function evazar_theme_sale_template_include($template) {
    if (is_admin()) {
        return $template;
    }
    $req_uri    = $_SERVER['REQUEST_URI'] ?? '';
    $clean_path = trim(parse_url($req_uri, PHP_URL_PATH), '/');

    $is_special_archive = (isset($_GET['on_sale']) || isset($_GET['discount']))
        || (get_query_var('evazar_directory') === 'brand')
        || (get_query_var('evazar_directory') === 'category')
        || preg_match('#(^|/)brands?/?$#i', $clean_path)
        || preg_match('#(^|/)categories?/?$#i', $clean_path)
        || preg_match('#(^|/)product-category/?$#i', $clean_path);

    if ($is_special_archive) {
        $archive_file = get_template_directory() . '/archive.php';
        if (file_exists($archive_file)) {
            return $archive_file;
        }
    }
    return $template;
}

// فیلتر کردن تعداد کالاهای هر صفحه آرشیو از طریق تنظیمات و یکپارچه‌سازی جستجو با کالاهای ایوازار و بخش تخفیف‌های ویژه
/**
 * فیلترهای سرورِ صفحات لیست کالاها.
 * پارامترهای عمومی URL:
 * brand[]=brand-slug&category[]=category-slug&stock=1&min_price=...&max_price=...
 */

/**
 * داده فیلترها: در درخواست AJAX از state موقت و در صفحه عادی از GET خوانده می‌شود.
 */
function evazar_archive_filter_request_data() {
    if (isset($GLOBALS['evazar_archive_filter_state']) && is_array($GLOBALS['evazar_archive_filter_state'])) {
        return $GLOBALS['evazar_archive_filter_state'];
    }
    return $_GET;
}

function evazar_archive_filter_state_from_array($input) {
    $input = is_array($input) ? $input : [];
    $brand = isset($input['brand']) ? $input['brand'] : [];
    $category = isset($input['category']) ? $input['category'] : [];
    $brand = is_array($brand) ? $brand : [$brand];
    $category = is_array($category) ? $category : [$category];
    $normalize_slugs = static function($values) {
        $values = array_map('sanitize_title', array_map('strval', wp_unslash($values)));
        return array_values(array_unique(array_filter($values)));
    };
    $state = [
        'brand'     => array_slice($normalize_slugs($brand), 0, 30),
        'category'  => array_slice($normalize_slugs($category), 0, 30),
        'stock'     => (!empty($input['stock']) && (string) wp_unslash($input['stock']) === '1') ? '1' : '',
        'min_price' => null,
        'max_price' => null,
    ];
    foreach (['min_price','max_price'] as $key) {
        if (!isset($input[$key]) || is_array($input[$key])) continue;
        $raw = trim((string) wp_unslash($input[$key]));
        $raw = str_replace(['٬', ',', '،', ' '], '', $raw);
        $raw = strtr($raw, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
        if ($raw !== '' && is_numeric($raw)) $state[$key] = max(0, (float)$raw);
    }
    return $state;
}

function evazar_archive_get_taxonomy_name($kind) {
    if ($kind === 'brand') return taxonomy_exists('evazar_brand') ? 'evazar_brand' : (taxonomy_exists('product_brand') ? 'product_brand' : '');
    return taxonomy_exists('evazar_category') ? 'evazar_category' : (taxonomy_exists('product_cat') ? 'product_cat' : '');
}

function evazar_archive_get_term_ids_by_slugs($taxonomy, $slugs) {
    if (!$taxonomy || empty($slugs)) return [];
    $terms = get_terms(['taxonomy'=>$taxonomy, 'slug'=>$slugs, 'hide_empty'=>false]);
    if (is_wp_error($terms) || !$terms) return [];
    return array_values(array_unique(array_map(static function($t){ return (int)$t->term_id; }, $terms)));
}

function evazar_archive_smart_sql_context($context, $state, $exclude = '') {
    global $wpdb;
    $where = ["p.post_type = 'evazar_product'", "p.post_status = 'publish'"];
    $params = [];
    $add_tax_exists = static function($taxonomy, $term_ids) use ($wpdb, &$where, &$params) {
        $term_ids = array_values(array_filter(array_map('intval', (array)$term_ids)));
        if (!$taxonomy || !$term_ids) return;
        $ph = implode(',', array_fill(0, count($term_ids), '%d'));
        $where[] = "EXISTS (SELECT 1 FROM {$wpdb->term_relationships} trx INNER JOIN {$wpdb->term_taxonomy} ttx ON ttx.term_taxonomy_id = trx.term_taxonomy_id WHERE trx.object_id = p.ID AND ttx.taxonomy = %s AND ttx.term_id IN ($ph))";
        $params[] = $taxonomy;
        array_push($params, ...$term_ids);
    };

    if (!empty($context['taxonomy']) && !empty($context['term_id'])) {
        $context_ids = [(int)$context['term_id']];
        if (is_taxonomy_hierarchical($context['taxonomy'])) {
            $children = get_term_children((int)$context['term_id'], $context['taxonomy']);
            if (!is_wp_error($children) && !empty($children)) {
                $context_ids = array_merge($context_ids, array_map('intval', $children));
            }
        }
        $add_tax_exists($context['taxonomy'], array_values(array_unique($context_ids)));
    }

    $brand_tax = evazar_archive_get_taxonomy_name('brand');
    $cat_tax   = evazar_archive_get_taxonomy_name('category');

    if ($exclude !== 'brand') {
        $brand_ids = evazar_archive_get_term_ids_by_slugs($brand_tax, $state['brand'] ?? []);
        $add_tax_exists($brand_tax, $brand_ids);
    }
    if ($exclude !== 'category') {
        $cat_ids = evazar_archive_get_term_ids_by_slugs($cat_tax, $state['category'] ?? []);
        $add_tax_exists($cat_tax, $cat_ids);
    }

    if ($exclude !== 'stock' && !empty($state['stock'])) {
        $where[] = evazar_archive_stock_sql_condition('p');
    }
    if ($exclude !== 'price') {
        if (($state['min_price'] ?? null) !== null) {
            $where[] = "EXISTS (SELECT 1 FROM {$wpdb->postmeta} pmin WHERE pmin.post_id = p.ID AND pmin.meta_key = '_evazar_current_price' AND CAST(REPLACE(REPLACE(REPLACE(pmin.meta_value, ',', ''), '٬', ''), '،', '') AS DECIMAL(18,2)) >= %f)";
            $params[] = (float)$state['min_price'];
        }
        if (($state['max_price'] ?? null) !== null) {
            $where[] = "EXISTS (SELECT 1 FROM {$wpdb->postmeta} pmax WHERE pmax.post_id = p.ID AND pmax.meta_key = '_evazar_current_price' AND CAST(REPLACE(REPLACE(REPLACE(pmax.meta_value, ',', ''), '٬', ''), '،', '') AS DECIMAL(18,2)) <= %f)";
            $params[] = (float)$state['max_price'];
        }
    }
    return [$where, $params];
}

function evazar_archive_smart_term_ids($taxonomy, $candidate_ids, $context, $state, $exclude) {
    global $wpdb;
    $candidate_ids = array_values(array_filter(array_map('intval', (array)$candidate_ids)));
    if (!$taxonomy || !$candidate_ids) return [];
    [$where, $params] = evazar_archive_smart_sql_context($context, $state, $exclude);
    $ph = implode(',', array_fill(0, count($candidate_ids), '%d'));
    $where[] = "tt.taxonomy = %s";
    $params[] = $taxonomy;
    $where[] = "tt.term_id IN ($ph)";
    array_push($params, ...$candidate_ids);
    $sql = "SELECT DISTINCT tt.term_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id = p.ID INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id WHERE " . implode(' AND ', $where);
    $prepared = $wpdb->prepare($sql, ...$params);
    $ids = $wpdb->get_col($prepared);
    return array_values(array_map('intval', $ids ?: []));
}

function evazar_get_smart_archive_filter_terms($context, $state) {
    $cache_key = 'evz_smart_facets_v191_' . md5(wp_json_encode(['c'=>$context,'s'=>$state]));
    $cached = get_transient($cache_key);
    if (is_array($cached) && isset($cached['brands'], $cached['categories'])) {
        // Term objects are serializable; keep the cache short to remain responsive to imports.
        return $cached;
    }
    $brand_tax = evazar_archive_get_taxonomy_name('brand');
    $cat_tax   = evazar_archive_get_taxonomy_name('category');
    $brands = [];
    $categories = [];

    if ($brand_tax && (($context['taxonomy'] ?? '') !== $brand_tax)) {
        $all_brands = get_terms(['taxonomy'=>$brand_tax, 'hide_empty'=>true, 'number'=>120, 'orderby'=>'name', 'order'=>'ASC']);
        if (!is_wp_error($all_brands) && $all_brands) {
            $candidate_ids = array_map(static function($t){ return (int)$t->term_id; }, $all_brands);
            $valid_ids = evazar_archive_smart_term_ids($brand_tax, $candidate_ids, $context, $state, 'brand');
            $valid_map = array_fill_keys($valid_ids, true);
            foreach ($all_brands as $term) if (isset($valid_map[(int)$term->term_id])) $brands[] = $term;
            foreach (($state['brand'] ?? []) as $slug) {
                $term = get_term_by('slug', $slug, $brand_tax);
                if ($term && !array_filter($brands, static function($x) use ($term){ return (int)$x->term_id === (int)$term->term_id; })) array_unshift($brands, $term);
            }
        }
    }

    if ($cat_tax) {
        // درخت فیلتر به‌صورت Lazy ساخته می‌شود؛ فقط شاخه‌های مستقیم Root را در HTML اولیه می‌آوریم.
        $root_parent = (($context['taxonomy'] ?? '') === $cat_tax && !empty($context['term_id'])) ? (int)$context['term_id'] : 0;
        $root_terms = evazar_get_smart_category_children_terms($root_parent, $context, $state);
        $categories = $root_terms;
    }


    // Smart range and stock availability based on current context + all other filters.
    global $wpdb;
    if (evazar_archive_has_product_index()) {
        $where_price = ["p.post_type = 'evazar_product'", "p.post_status = 'publish'"];
        $params_price = [];
        [$where_base_price, $params_base_price] = evazar_archive_smart_sql_context($context, $state, 'price');
        $where_price = $where_base_price;
        $where_price[] = 'evz_facet.price > 0';
        $sql_price = "SELECT MIN(evz_facet.price) AS min_price, MAX(evz_facet.price) AS max_price FROM {$wpdb->posts} p INNER JOIN " . evazar_archive_product_index_table() . " evz_facet ON evz_facet.product_id=p.ID WHERE " . implode(' AND ', $where_price);
        $price_row = $wpdb->get_row($wpdb->prepare($sql_price, ...$params_base_price));
    } else {
        [$where_price, $params_price] = evazar_archive_smart_sql_context($context, $state, 'price');
        $clean_price_sql = "CAST(REPLACE(REPLACE(REPLACE(COALESCE(pm.meta_value,'0'), ',', ''), '٬', ''), '،', '') AS DECIMAL(18,2))";
        $where_price[] = "{$clean_price_sql} > 0";
        $sql_price = "SELECT MIN({$clean_price_sql}) AS min_price, MAX({$clean_price_sql}) AS max_price FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_evazar_current_price' WHERE " . implode(' AND ', $where_price);
        $price_row = $wpdb->get_row($wpdb->prepare($sql_price, ...$params_price));
    }

    // مهم: total و available باید دقیقاً از یک مجموعه پایه محاسبه شوند؛
    // نیمه‌پر بودن Product Index نباید باعث ناپدید شدن فیلتر وضعیت کالا شود.
    [$where_stock, $params_stock] = evazar_archive_smart_sql_context($context, $state, 'stock');
    $stock_condition = evazar_archive_stock_sql_condition('p');
    $sql_stock = "SELECT COUNT(*) AS total_count, SUM(CASE WHEN ({$stock_condition}) THEN 1 ELSE 0 END) AS available_count FROM {$wpdb->posts} p WHERE " . implode(' AND ', $where_stock);
    $stock_row = $wpdb->get_row($wpdb->prepare($sql_stock, ...$params_stock));
    $total = $stock_row ? (int)$stock_row->total_count : 0;
    $available = $stock_row ? (int)$stock_row->available_count : 0;

    $result = [
        'brands' => $brands,
        'categories' => $categories,
        'min_price' => ($price_row && $price_row->min_price !== null) ? (float)$price_row->min_price : null,
        'max_price' => ($price_row && $price_row->max_price !== null) ? (float)$price_row->max_price : null,
        'stock_total' => $total,
        'stock_available' => $available,
        'stock_mixed' => ($total > 0 && $available > 0 && $available < $total),
    ];
    set_transient($cache_key, $result, 60);
    return $result;
}

function evazar_archive_filter_slugs($key) {
    $request = evazar_archive_filter_request_data();
    $value = $request[$key] ?? [];
    $value = is_array($value) ? $value : [$value];
    $value = array_map('sanitize_title', wp_unslash($value));
    $value = array_values(array_unique(array_filter($value)));
    return array_slice($value, 0, 30);
}

function evazar_archive_filter_numeric($key) {
    
    $request = evazar_archive_filter_request_data();
    if (!isset($request[$key])) return null;
    $raw = wp_unslash($request[$key]);
    $raw = is_string($raw) ? trim($raw) : '';
    if ($raw === '') return null;
    $raw = str_replace(['٬', ',', '،', ' '], '', $raw);
    $raw = strtr($raw, [
        '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
        '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
    ]);
    if (!is_numeric($raw)) return null;
    $num = (float) $raw;
    return $num >= 0 ? $num : null;
}

function evazar_archive_filter_args() {
    $args = [];
    $brands = evazar_archive_filter_slugs('brand');
    $cats   = evazar_archive_filter_slugs('category');
    if ($brands) $args['brand'] = $brands;
    if ($cats) $args['category'] = $cats;
    $request = evazar_archive_filter_request_data();
    if (!empty($request['stock']) && (string) wp_unslash($request['stock']) === '1') $args['stock'] = '1';
    $min = evazar_archive_filter_numeric('min_price');
    $max = evazar_archive_filter_numeric('max_price');
    if ($min !== null) $args['min_price'] = $min;
    if ($max !== null) $args['max_price'] = $max;
    return $args;
}

function evazar_apply_archive_product_filters($query) {
    $brands = evazar_archive_filter_slugs('brand');
    $cats   = evazar_archive_filter_slugs('category');
    $request = evazar_archive_filter_request_data();
    $stock  = !empty($request['stock']) && (string) wp_unslash($request['stock']) === '1';
    $min    = evazar_archive_filter_numeric('min_price');
    $max    = evazar_archive_filter_numeric('max_price');

    $is_product_context = $query->is_tax('evazar_category') || $query->is_tax('evazar_brand') || $query->is_post_type_archive('evazar_product') || $query->is_search();
    if (!$is_product_context) {
        return;
    }

    $tax_query = $query->get('tax_query') ?: [];
    if (!is_array($tax_query)) $tax_query = [];

    if (!empty($brands)) {
        $tax_query[] = [
            'taxonomy' => taxonomy_exists('evazar_brand') ? 'evazar_brand' : 'product_brand',
            'field'    => 'slug',
            'terms'    => $brands,
            'operator' => 'IN',
        ];
    }
    if (!empty($cats)) {
        $tax_query[] = [
            'taxonomy' => taxonomy_exists('evazar_category') ? 'evazar_category' : 'product_cat',
            'field'    => 'slug',
            'terms'    => $cats,
            'operator' => 'IN',
            'include_children' => true,
        ];
    }
    if (count($tax_query) > 1 && !isset($tax_query['relation'])) {
        $tax_query['relation'] = 'AND';
    }
    if (!empty($tax_query)) $query->set('tax_query', $tax_query);

    $meta_query = $query->get('meta_query') ?: [];
    if (!is_array($meta_query)) $meta_query = [];
    if ($stock) {
        // فیلتر موجودی با SQL هوشمند اعمال می‌شود تا برای کالاهای قدیمی/ناقص فقط به meta flag تکیه نکند.
        $query->set('evazar_stock_filter', 1);
    }
    if ($min !== null) $query->set('evazar_min_price_filter', (float)$min);
    if ($max !== null) $query->set('evazar_max_price_filter', (float)$max);
    if (!empty($meta_query)) $query->set('meta_query', $meta_query);
}

function evazar_get_archive_filter_terms() {
    $brand_tax = taxonomy_exists('evazar_brand') ? 'evazar_brand' : (taxonomy_exists('product_brand') ? 'product_brand' : '');
    $cat_tax   = taxonomy_exists('evazar_category') ? 'evazar_category' : (taxonomy_exists('product_cat') ? 'product_cat' : '');
    $brands = [];
    $cats = [];

    if ($brand_tax) {
        $brands = get_terms([
            'taxonomy' => $brand_tax,
            'hide_empty' => true,
            'number' => 80,
            'orderby' => 'count',
            'order' => 'DESC',
        ]);
        if (is_wp_error($brands)) $brands = [];
        $selected = evazar_archive_filter_slugs('brand');
        if ($selected) {
            $selected_terms = get_terms(['taxonomy'=>$brand_tax, 'slug'=>$selected, 'hide_empty'=>false]);
            if (!is_wp_error($selected_terms)) {
                $ids = array_fill_keys(array_map(function($t){ return (int) $t->term_id; }, $brands), true);
                foreach ($selected_terms as $term) {
                    if (!isset($ids[(int)$term->term_id])) array_unshift($brands, $term);
                }
            }
        }
    }

    if ($cat_tax) {
        $queried = is_tax($cat_tax) ? get_queried_object() : null;
        $args = [
            'taxonomy' => $cat_tax,
            'hide_empty' => true,
            'number' => 40,
            'orderby' => 'count',
            'order' => 'DESC',
        ];
        if ($queried && isset($queried->term_id)) {
            $children = get_terms($args + ['parent' => (int)$queried->term_id, 'orderby'=>'name', 'order'=>'ASC']);
            if (!is_wp_error($children) && !empty($children)) {
                $cats = $children;
            } else {
                $cats = [get_term((int)$queried->term_id, $cat_tax)];
            }
        } else {
            $cats = get_terms($args + ['parent'=>0]);
            if (is_wp_error($cats)) $cats = [];
        }
        $selected = evazar_archive_filter_slugs('category');
        if ($selected) {
            $selected_terms = get_terms(['taxonomy'=>$cat_tax, 'slug'=>$selected, 'hide_empty'=>false]);
            if (!is_wp_error($selected_terms)) {
                $ids = array_fill_keys(array_map(function($t){ return (int) $t->term_id; }, $cats), true);
                foreach ($selected_terms as $term) {
                    if (!isset($ids[(int)$term->term_id])) array_unshift($cats, $term);
                }
            }
        }
    }
    return ['brands'=>array_values(array_filter($brands)), 'categories'=>array_values(array_filter($cats))];
}

function evazar_archive_filter_base_url() {
    if (!empty($GLOBALS['evazar_archive_filter_base_url'])) {
        return $GLOBALS['evazar_archive_filter_base_url'];
    }
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
    return home_url($path);
}

function evazar_archive_product_index_table() {
    global $wpdb;
    return $wpdb->prefix . 'evazar_product_index';
}
function evazar_archive_category_index_table() {
    global $wpdb;
    return $wpdb->prefix . 'evazar_product_category_index';
}
function evazar_archive_has_product_index() {
    global $wpdb;
    static $ok = null;
    if ($ok !== null) return $ok;
    $table = evazar_archive_product_index_table();
    $ok = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table);
    return $ok;
}
function evazar_archive_index_scope_sql($posts_alias = 'p') {
    global $wpdb;
    if (!evazar_archive_has_product_index()) return '';
    return " INNER JOIN " . evazar_archive_product_index_table() . " evz_idx ON evz_idx.product_id = {$posts_alias}.ID ";
}
/**
 * موجودی canonical آرشیو ایوازار:
 * قیمت فعلی > 0 یعنی موجود، مگر اینکه Worker صراحتاً explicit_unavailable گزارش کرده باشد.
 * Product Index مرجع موجودی نیست؛ قیمت فعلی همان metaای است که کارت محصول نیز نمایش می‌دهد.
 */
function evazar_archive_stock_sql_condition($posts_alias = '') {
    global $wpdb;
    $posts_ref = $posts_alias !== '' ? $posts_alias : $wpdb->posts;
    $price_meta_sql = "CAST(REPLACE(REPLACE(REPLACE(COALESCE(eprice.meta_value,'0'), ',', ''), '٬', ''), '،', '') AS DECIMAL(18,2))";

    return "EXISTS (
        SELECT 1
        FROM {$wpdb->postmeta} eprice
        LEFT JOIN {$wpdb->postmeta} esrc
          ON esrc.post_id = eprice.post_id
         AND esrc.meta_key = '_evazar_availability_source'
        WHERE eprice.post_id = {$posts_ref}.ID
          AND eprice.meta_key = '_evazar_current_price'
          AND {$price_meta_sql} > 0
          AND COALESCE(esrc.meta_value, '') <> 'explicit_unavailable'
    )";
}

function evazar_archive_filter_remove_value_url($key, $value = null) {
    $params = $_GET;
    unset($params['paged'], $params['page']);
    if ($value !== null && isset($params[$key]) && is_array($params[$key])) {
        $params[$key] = array_values(array_filter($params[$key], function($item) use ($value) {
            return sanitize_title($item) !== sanitize_title($value);
        }));
        if (empty($params[$key])) unset($params[$key]);
    } else {
        unset($params[$key]);
    }
    return add_query_arg($params, home_url(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH)));
}


function evazar_archive_current_url_args_from_state($state, $search = '', $sort = '') {
    $args = [];
    if (!empty($state['brand'])) $args['brand'] = array_values($state['brand']);
    if (!empty($state['category'])) $args['category'] = array_values($state['category']);
    if (($state['stock'] ?? '') === '1') $args['stock'] = '1';
    if (($state['min_price'] ?? null) !== null) $args['min_price'] = $state['min_price'];
    if (($state['max_price'] ?? null) !== null) $args['max_price'] = $state['max_price'];
    if ($search !== '') $args['s'] = $search;
    if ($sort && $sort !== 'relevant') $args['sort'] = $sort;
    return $args;
}

function evazar_render_active_archive_filters() {
    $brands = evazar_archive_filter_slugs('brand');
    $cats = evazar_archive_filter_slugs('category');
    $request = evazar_archive_filter_request_data();
    $stock = !empty($request['stock']) && (string) wp_unslash($request['stock']) === '1';
    $min = evazar_archive_filter_numeric('min_price');
    $max = evazar_archive_filter_numeric('max_price');
    if (!$brands && !$cats && !$stock && $min === null && $max === null) return '';

    $request = evazar_archive_filter_request_data();
    $state = evazar_archive_filter_state_from_array($request);
    $current_path = evazar_archive_filter_base_url();
    $sort = sanitize_text_field($request['sort'] ?? '');
    $search = isset($request['s']) ? sanitize_text_field($request['s']) : '';
    $html = '<div class="evazar-active-filters" aria-label="فیلترهای فعال">';
    $html .= '<span class="evazar-active-label">فیلترهای فعال:</span>';
    $lookup = function($tax, $slugs) {
        if (!$tax || !$slugs) return [];
        $terms = get_terms(['taxonomy'=>$tax, 'slug'=>$slugs, 'hide_empty'=>false]);
        return is_wp_error($terms) ? [] : $terms;
    };
    if ($brands) {
        $tax = taxonomy_exists('evazar_brand') ? 'evazar_brand' : 'product_brand';
        foreach ($lookup($tax, $brands) as $term) {
            $next = $state; $next['brand'] = array_values(array_diff($next['brand'], [$term->slug]));
            $url = add_query_arg(evazar_archive_current_url_args_from_state($next, $search, $sort), $current_path);
            $html .= '<a class="evazar-active-chip" data-evazar-filter-url="' . esc_url($url) . '" href="' . esc_url($url) . '">' . esc_html($term->name) . ' <span aria-hidden="true">×</span></a>';
        }
    }
    if ($cats) {
        $tax = taxonomy_exists('evazar_category') ? 'evazar_category' : 'product_cat';
        foreach ($lookup($tax, $cats) as $term) {
            $next = $state; $next['category'] = array_values(array_diff($next['category'], [$term->slug]));
            $url = add_query_arg(evazar_archive_current_url_args_from_state($next, $search, $sort), $current_path);
            $html .= '<a class="evazar-active-chip" data-evazar-filter-url="' . esc_url($url) . '" href="' . esc_url($url) . '">' . esc_html($term->name) . ' <span aria-hidden="true">×</span></a>';
        }
    }
    if ($stock) {
        $next = $state; $next['stock'] = '';
        $url = add_query_arg(evazar_archive_current_url_args_from_state($next, $search, $sort), $current_path);
        $html .= '<a class="evazar-active-chip" data-evazar-filter-url="' . esc_url($url) . '" href="' . esc_url($url) . '">فقط موجود <span aria-hidden="true">×</span></a>';
    }
    if ($min !== null || $max !== null) {
        if ($min !== null && $max !== null) {
            $label = 'بازه قیمت: ' . evazar_to_fa_num(number_format_i18n($min, 0)) . ' تا ' . evazar_to_fa_num(number_format_i18n($max, 0)) . ' تومان';
        } elseif ($min !== null) {
            $label = 'بازه قیمت: از ' . evazar_to_fa_num(number_format_i18n($min, 0)) . ' تومان';
        } else {
            $label = 'بازه قیمت: تا ' . evazar_to_fa_num(number_format_i18n($max, 0)) . ' تومان';
        }
        $next = $state; $next['min_price'] = null; $next['max_price'] = null;
        $url = add_query_arg(evazar_archive_current_url_args_from_state($next, $search, $sort), $current_path);
        $html .= '<a class="evazar-active-chip evazar-active-price" data-evazar-filter-url="' . esc_url($url) . '" href="' . esc_url($url) . '" aria-label="حذف ' . esc_attr($label) . '">' . esc_html($label) . ' <span aria-hidden="true">×</span></a>';
    }
    $clear_state = ['brand'=>[],'category'=>[],'stock'=>'','min_price'=>null,'max_price'=>null];
    $clear_url = add_query_arg(evazar_archive_current_url_args_from_state($clear_state, $search, $sort), $current_path);
    $html .= '<a class="evazar-active-clear" data-evazar-filter-url="' . esc_url($clear_url) . '" href="' . esc_url($clear_url) . '">حذف همه</a>';
    $html .= '</div>';
    return $html;
}


function evazar_get_smart_category_children_terms($parent_id, $context, $state) {
    $tax = evazar_archive_get_taxonomy_name('category');
    if (!$tax) return [];
    $parent_id = max(0, (int)$parent_id);
    $terms = get_terms([
        'taxonomy'   => $tax,
        'parent'     => $parent_id,
        'hide_empty' => true,
        'number'     => 0,
        'orderby'    => 'name',
        'order'      => 'ASC',
    ]);
    if (is_wp_error($terms) || !$terms) return [];
    $candidate_ids = array_map(static fn($term) => (int)$term->term_id, $terms);
    $valid_ids = evazar_archive_smart_term_ids($tax, $candidate_ids, $context, $state, 'category');
    $valid_map = array_fill_keys(array_map('intval', $valid_ids), true);
    $selected = array_flip((array)($state['category'] ?? []));
    $result = [];
    foreach ($terms as $term) {
        if (isset($valid_map[(int)$term->term_id]) || isset($selected[$term->slug])) {
            $result[] = $term;
        }
    }
    return $result;
}

function evazar_category_term_has_children($term_id, $taxonomy) {
    $children = get_terms([
        'taxonomy' => $taxonomy,
        'parent' => (int)$term_id,
        'hide_empty' => true,
        'number' => 1,
        'fields' => 'ids',
    ]);
    return !is_wp_error($children) && !empty($children);
}

function evazar_render_lazy_category_nodes($terms, $selected, $depth = 0) {
    $tax = evazar_archive_get_taxonomy_name('category');
    if (!$tax || empty($terms)) return '';
    $html = '<ul class="evazar-category-tree-list evazar-category-tree-level-' . (int)$depth . '">';
    foreach ($terms as $term) {
        $id = (int)$term->term_id;
        $slug = (string)$term->slug;
        $name = (string)$term->name;
        $is_selected = in_array($slug, (array)$selected, true);
        $has_children = evazar_category_term_has_children($id, $tax);
        $html .= '<li class="evazar-category-tree-item' . ($is_selected ? ' is-selected' : '') . '" data-category-id="' . esc_attr($id) . '">';
        $html .= '<div class="evazar-category-tree-row">';
        $html .= '<label class="evazar-filter-check evazar-category-tree-select' . ($is_selected ? ' is-selected' : '') . '" data-filter-text="' . esc_attr(mb_strtolower(trim($name . ' ' . $slug), 'UTF-8')) . '">';
        $html .= '<input class="evazar-category-native-check" type="checkbox" name="category[]" value="' . esc_attr($slug) . '" ' . checked($is_selected, true, false) . '><span class="evazar-category-tree-name">' . esc_html($name) . '</span></label>';
        if ($has_children) {
            $html .= '<button type="button" class="evazar-category-tree-toggle" data-lazy-category="1" aria-expanded="false" aria-label="نمایش زیردسته‌های ' . esc_attr($name) . '" data-parent-id="' . esc_attr($id) . '"><span aria-hidden="true">‹</span></button>';
        } else {
            $html .= '<span class="evazar-category-tree-spacer" aria-hidden="true"></span>';
        }
        $html .= '</div>';
        if ($has_children) {
            $html .= '<div class="evazar-category-tree-children" data-category-children-loaded="0" hidden></div>';
        }
        $html .= '</li>';
    }
    $html .= '</ul>';
    return $html;
}

function evazar_render_filter_category_tree_nodes($parent_id, $children_map, $selected, $branch_ids, $depth = 0) {
    if (empty($children_map[$parent_id])) return '';
    $html = '<ul class="evazar-category-tree-list evazar-category-tree-level-' . (int)$depth . '">';
    foreach ($children_map[$parent_id] as $term) {
        $id = (int)$term->term_id;
        $slug = (string)$term->slug;
        $name = (string)$term->name;
        $children_html = evazar_render_filter_category_tree_nodes($id, $children_map, $selected, $branch_ids, $depth + 1);
        $has_children = $children_html !== '';
        $expanded = $has_children && isset($branch_ids[$id]);
        $html .= '<li class="evazar-category-tree-item' . ($expanded ? ' is-expanded' : '') . '" data-category-id="' . esc_attr($id) . '">';
        $html .= '<div class="evazar-category-tree-row">';
        $is_selected = in_array($slug, $selected, true);
        $html .= '<label class="evazar-filter-check evazar-category-tree-select' . ($is_selected ? ' is-selected' : '') . '" data-filter-text="' . esc_attr(mb_strtolower(trim($name . ' ' . $slug), 'UTF-8')) . '">';
        $html .= '<input class="evazar-category-native-check" type="checkbox" name="category[]" value="' . esc_attr($slug) . '" ' . checked($is_selected, true, false) . '><span class="evazar-category-tree-name">' . esc_html($name) . '</span></label>';
        if ($has_children) {
            $html .= '<button type="button" class="evazar-category-tree-toggle" aria-expanded="' . ($expanded ? 'true' : 'false') . '" aria-label="نمایش زیردسته‌های ' . esc_attr($name) . '"><span aria-hidden="true">‹</span></button>';
        } else {
            $html .= '<span class="evazar-category-tree-spacer" aria-hidden="true"></span>';
        }
        $html .= '</div>';
        if ($has_children) $html .= '<div class="evazar-category-tree-children"' . ($expanded ? '' : ' hidden') . '>' . $children_html . '</div>';
        $html .= '</li>';
    }
    $html .= '</ul>';
    return $html;
}

function evazar_render_filter_category_search_result_item($term, $path = '', $checked = false) {
    $slug = (string)$term->slug;
    $name = (string)$term->name;
    $text = trim($name . ' ' . $slug . ' ' . $path);
    $html = '<label class="evazar-filter-check evazar-category-search-result' . ($checked ? ' is-selected' : '') . '" data-filter-text="' . esc_attr(mb_strtolower($text, 'UTF-8')) . '">';
    $html .= '<input class="evazar-category-native-check" type="checkbox" name="category[]" value="' . esc_attr($slug) . '" ' . checked($checked, true, false) . '><span class="evazar-category-search-result-main"><b>' . esc_html($name) . '</b>';
    if ($path !== '') $html .= '<small>' . esc_html($path) . '</small>';
    $html .= '</span></label>';
    return $html;
}

function evazar_render_archive_filters() {
    $state = evazar_archive_filter_state_from_array(evazar_archive_filter_request_data());
    $context_tax = isset($GLOBALS['evazar_archive_filter_context']['taxonomy']) ? (string)$GLOBALS['evazar_archive_filter_context']['taxonomy'] : '';
    $context_term_id = isset($GLOBALS['evazar_archive_filter_context']['term_id']) ? absint($GLOBALS['evazar_archive_filter_context']['term_id']) : 0;
    $smart = evazar_get_smart_archive_filter_terms(['taxonomy'=>$context_tax,'term_id'=>$context_term_id], $state);
    $brands = $smart['brands'];
    $cats = $smart['categories'];
    $selected_brands = $state['brand'];
    $selected_cats = $state['category'];
    $stock = $state['stock'] === '1';
    $min = $state['min_price'];
    $max = $state['max_price'];
    $smart_min = $smart['min_price'];
    $smart_max = $smart['max_price'];
    $sort = sanitize_text_field(evazar_archive_filter_request_data()['sort'] ?? 'relevant');
    $order = get_option('evazar_opt_filter_sections_order', 'category,brand,stock,price');
    $order = array_values(array_intersect(explode(',', (string)$order), ['category','brand','stock','price']));
    foreach (['category','brand','stock','price'] as $fallback) if (!in_array($fallback, $order, true)) $order[]=$fallback;
    $action = esc_url(evazar_archive_filter_base_url());
    $hidden_search = isset(evazar_archive_filter_request_data()['s']) ? sanitize_text_field(evazar_archive_filter_request_data()['s']) : '';
    $hidden_post_type = 'evazar_product';

    // فقط شاخه‌های مستقیم Root در HTML اولیه؛ زیرشاخه‌ها هنگام کلیک Lazy-load می‌شوند.
    $category_root_parent = ($context_tax === evazar_archive_get_taxonomy_name('category') && $context_term_id) ? $context_term_id : 0;
    $category_root_terms = evazar_get_smart_category_children_terms($category_root_parent, [
        'taxonomy' => $context_tax, 'term_id' => $context_term_id
    ], $state);
    $category_tree_html = evazar_render_lazy_category_nodes($category_root_terms, $selected_cats, 0);
    ob_start();
    ?>
    <aside class="evazar-filter-panel" id="evazar-filter-panel" aria-label="فیلتر محصولات" data-filter-taxonomy="<?php echo esc_attr($context_tax); ?>" data-filter-term-id="<?php echo esc_attr($context_term_id); ?>">
        <div class="evazar-filter-head">
            <div><strong>فیلتر محصولات</strong><span class="evazar-filter-subtitle">انتخاب هوشمند بر اساس همین صفحه</span></div>
            <button type="button" class="evazar-filter-close" aria-label="بستن فیلترها">×</button>
        </div>
        <form class="evazar-filter-form" method="get" action="<?php echo $action; ?>">
            <?php if ($hidden_search !== ''): ?><input type="hidden" name="s" value="<?php echo esc_attr($hidden_search); ?>" /><?php endif; ?>
            <input type="hidden" name="post_type" value="<?php echo esc_attr($hidden_post_type); ?>" />
            <input type="hidden" name="sort" value="<?php echo esc_attr($sort); ?>" />
            <?php foreach ($order as $section): ?>
                <?php if ($section === 'category' && !empty($cats)): ?>
                    <section class="evazar-filter-section" data-filter-section="category">
                        <button type="button" class="evazar-filter-section-title" aria-expanded="true"><span>دسته‌بندی</span><span aria-hidden="true"></span></button>
                        <div class="evazar-filter-section-body">
                            <div class="evazar-filter-search-wrap">
                                <input type="search" class="evazar-filter-search evazar-filter-category-search" placeholder="جستجوی دسته‌بندی..." aria-label="جستجوی دسته‌بندی" autocomplete="off" />
                                <button type="button" class="evazar-filter-search-clear" aria-label="پاک کردن جستجوی دسته‌بندی" hidden>×</button>
                            </div>
                            <div class="evazar-filter-options evazar-filter-category-options">
                                <?php echo $category_tree_html; ?>
                            </div>
                        </div>
                    </section>
                <?php elseif ($section === 'brand' && !empty($brands) && $context_tax !== evazar_archive_get_taxonomy_name('brand')): ?>
                    <section class="evazar-filter-section" data-filter-section="brand">
                        <button type="button" class="evazar-filter-section-title" aria-expanded="true"><span>برند</span><span aria-hidden="true"></span></button>
                        <div class="evazar-filter-section-body">
                            <div class="evazar-filter-search-wrap">
                                <input type="search" class="evazar-filter-search evazar-filter-brand-search" placeholder="جستجوی برند..." aria-label="جستجوی برند" autocomplete="off" />
                                <button type="button" class="evazar-filter-search-clear" aria-label="پاک کردن جستجوی برند" hidden>×</button>
                            </div>
                            <div class="evazar-filter-options evazar-filter-brand-options">
                                <?php foreach ($brands as $term): $checked = in_array($term->slug, $selected_brands, true); ?>
                                    <?php $brand_search_text = trim($term->name . ' ' . $term->slug); ?>
                                    <label class="evazar-filter-check" data-filter-text="<?php echo esc_attr(mb_strtolower($brand_search_text, 'UTF-8')); ?>"><input type="checkbox" name="brand[]" value="<?php echo esc_attr($term->slug); ?>" <?php checked($checked); ?>><span><?php echo esc_html($term->name); ?></span></label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </section>
                <?php elseif ($section === 'stock' && !empty($smart['stock_total'])): ?>
                    <section class="evazar-filter-section" data-filter-section="stock">
                        <button type="button" class="evazar-filter-section-title" aria-expanded="true"><span>وضعیت کالا</span><span aria-hidden="true"></span></button>
                        <div class="evazar-filter-section-body">
                            <label class="evazar-filter-switch"><input type="checkbox" name="stock" value="1" <?php checked($stock); ?>><span class="evazar-filter-switch-ui"></span><span>فقط کالاهای موجود</span></label>
                        </div>
                    </section>
                <?php elseif ($section === 'price' && ($smart_min !== null || $smart_max !== null)): ?>
                    <section class="evazar-filter-section" data-filter-section="price">
                        <button type="button" class="evazar-filter-section-title" aria-expanded="true"><span>بازه قیمت</span><span aria-hidden="true"></span></button>
                        <div class="evazar-filter-section-body">
                            <div class="evazar-price-range<?php echo ($min !== null || $max !== null) ? ' is-active' : ''; ?>" data-price-min="<?php echo $smart_min !== null ? esc_attr((float)$smart_min) : '0'; ?>" data-price-max="<?php echo $smart_max !== null ? esc_attr((float)$smart_max) : '0'; ?>" data-price-step="<?php echo esc_attr((string) max(1, $smart_max !== null && $smart_min !== null ? (abs((float)$smart_max-(float)$smart_min) > 10000000 ? 10000 : (abs((float)$smart_max-(float)$smart_min) > 1000000 ? 1000 : (abs((float)$smart_max-(float)$smart_min) > 100000 ? 100 : 10))) : 1)); ?>" data-price-filter-active="<?php echo ($min !== null || $max !== null) ? '1' : '0'; ?>">
                                <div class="evazar-price-range-values" aria-hidden="true">
                                    <span class="evazar-price-range-value evazar-price-range-min-value"><?php echo $min !== null ? esc_html(evazar_to_fa_num(number_format_i18n($min, 0))) : ($smart_min !== null ? esc_html(evazar_to_fa_num(number_format_i18n($smart_min, 0))) : '۰'); ?></span>
                                    <span class="evazar-price-range-separator">تا</span>
                                    <span class="evazar-price-range-value evazar-price-range-max-value"><?php echo $max !== null ? esc_html(evazar_to_fa_num(number_format_i18n($max, 0))) : ($smart_max !== null ? esc_html(evazar_to_fa_num(number_format_i18n($smart_max, 0))) : '۰'); ?></span>
                                </div>
                                <div class="evazar-price-range-slider" role="group" aria-label="انتخاب بازه قیمت" tabindex="0">
                                    <span class="evazar-price-range-rail" aria-hidden="true"></span>
                                    <span class="evazar-price-range-fill" aria-hidden="true"></span>
                                    <button type="button" role="slider" class="evazar-price-range-handle evazar-price-range-handle-lower" aria-label="حداقل قیمت" aria-orientation="horizontal" aria-valuemin="<?php echo esc_attr((float)$smart_min); ?>" aria-valuemax="<?php echo esc_attr((float)$smart_max); ?>" aria-valuenow="<?php echo esc_attr((float)($min !== null ? $min : $smart_min)); ?>" aria-valuetext="<?php echo esc_attr(evazar_to_fa_num(number_format_i18n((float)($min !== null ? $min : $smart_min), 0)) . ' تومان'); ?>"></button>
                                    <button type="button" role="slider" class="evazar-price-range-handle evazar-price-range-handle-upper" aria-label="حداکثر قیمت" aria-orientation="horizontal" aria-valuemin="<?php echo esc_attr((float)$smart_min); ?>" aria-valuemax="<?php echo esc_attr((float)$smart_max); ?>" aria-valuenow="<?php echo esc_attr((float)($max !== null ? $max : $smart_max)); ?>" aria-valuetext="<?php echo esc_attr(evazar_to_fa_num(number_format_i18n((float)($max !== null ? $max : $smart_max), 0)) . ' تومان'); ?>"></button>
                                </div>
                            </div>
                            <div class="evazar-price-fields">
                                <label>از<input type="text" name="min_price" inputmode="numeric" autocomplete="off" value="<?php echo $min !== null ? esc_attr(evazar_to_fa_num(number_format_i18n($min, 0))) : ''; ?>" placeholder="<?php echo $smart_min !== null ? esc_attr(evazar_to_fa_num(number_format_i18n($smart_min, 0))) : 'حداقل'; ?>" /></label>
                                <label>تا<input type="text" name="max_price" inputmode="numeric" autocomplete="off" value="<?php echo $max !== null ? esc_attr(evazar_to_fa_num(number_format_i18n($max, 0))) : ''; ?>" placeholder="<?php echo $smart_max !== null ? esc_attr(evazar_to_fa_num(number_format_i18n($smart_max, 0))) : 'حداکثر'; ?>" /></label>
                            </div>
                            <div class="evazar-price-unit">تومان</div>
                        </div>
                    </section>
                <?php endif; ?>
            <?php endforeach; ?>
            <div class="evazar-filter-actions">
                <a class="evazar-filter-clear" href="<?php echo esc_url(evazar_archive_filter_base_url()); ?>">حذف همه</a>
                <span class="evazar-filter-live-status" aria-live="polite">فیلترها خودکار اعمال می‌شوند</span>
            </div>
        </form>
    </aside>
    <?php
    return ob_get_clean();
}

/** AJAX: اعمال فوری فیلترهای آرشیو و بازسازی نتایج و فیلترهای هوشمند. */

/** AJAX: جستجوی برندهای فیلتر بر اساس متن/slug و همان context فیلترها. */
add_action('wp_ajax_evazar_filter_brand_search', 'evazar_ajax_filter_brand_search');
add_action('wp_ajax_nopriv_evazar_filter_brand_search', 'evazar_ajax_filter_brand_search');
function evazar_ajax_filter_brand_search() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'evazar_archive_filters_nonce')) {
        wp_send_json_error(['message' => 'درخواست نامعتبر است.'], 403);
    }

    $query = isset($_POST['q']) ? trim(sanitize_text_field(wp_unslash($_POST['q']))) : '';
    $query_norm = evazar_normalize_search_text($query);
    if (mb_strlen($query_norm, 'UTF-8') < 2) wp_send_json_success(['brands'=>[], 'html'=>'']);

    $brand_tax = evazar_archive_get_taxonomy_name('brand');
    if (!$brand_tax) wp_send_json_success(['brands'=>[], 'html'=>'']);

    $state = evazar_archive_filter_state_from_array([
        'brand'=>$_POST['brand'] ?? [], 'category'=>$_POST['category'] ?? [],
        'stock'=>$_POST['stock'] ?? '', 'min_price'=>$_POST['min_price'] ?? '', 'max_price'=>$_POST['max_price'] ?? '',
    ]);
    $context = [
        'taxonomy'=>sanitize_key($_POST['context_taxonomy'] ?? ''),
        'term_id'=>absint($_POST['context_term_id'] ?? 0),
    ];

    $matches = [];
    foreach (evazar_get_cached_brand_index($brand_tax) as $row) {
        $name_norm = evazar_normalize_search_text((string)($row['name'] ?? ''));
        $slug_norm = evazar_normalize_search_text((string)($row['slug'] ?? ''));
        $aliases = array_values(array_filter(array_map('evazar_normalize_search_text', (array)($row['aliases'] ?? []))));
        $needles = array_merge([$name_norm, $slug_norm], $aliases);
        $score = 0;
        foreach ($needles as $needle) {
            if ($needle === '') continue;
            if ($needle === $query_norm) { $score = 1000; break; }
            if ($score < 900 && mb_strpos($needle, $query_norm, 0, 'UTF-8') === 0) $score = 900;
            elseif ($score < 700 && mb_strlen($query_norm, 'UTF-8') >= 3 && mb_strpos($needle, $query_norm, 0, 'UTF-8') !== false) $score = 700;
        }
        if ($score <= 0) continue;
        $matches[] = [
            'id'=>(int)$row['id'], 'name'=>(string)$row['name'], 'url'=>(string)$row['url'],
            'score'=>$score, 'count'=>(int)$row['count'], 'slug'=>(string)$row['slug'],
        ];
    }
    if (!$matches) wp_send_json_success(['brands'=>[], 'html'=>'']);

    // وقتی تطبیق دقیق وجود دارد، فقط همان برندها را نشان بده؛ این مانع می‌شود
    // جستجوی «anker» با برندهای صرفاً مشابه/طولانی‌تر شلوغ شود.
    $exact_matches = array_values(array_filter($matches, static fn($row) => (int)$row['score'] === 1000));
    if ($exact_matches) {
        $matches = $exact_matches;
    } else {
        $prefix_matches = array_values(array_filter($matches, static fn($row) => (int)$row['score'] === 900));
        if ($prefix_matches) $matches = $prefix_matches;
    }

    usort($matches, static function($a,$b){
        if ($a['score'] !== $b['score']) return $b['score'] <=> $a['score'];
        if ($a['count'] !== $b['count']) return $b['count'] <=> $a['count'];
        return strnatcasecmp(evazar_normalize_search_text($a['name']), evazar_normalize_search_text($b['name']));
    });
    // Context validation is only applied to the strongest matches, after ranking.
    $matches = array_slice($matches, 0, 200);
    $candidate_ids = array_values(array_map(static fn($row)=>(int)$row['id'], $matches));
    $valid_ids = evazar_archive_smart_term_ids($brand_tax, $candidate_ids, $context, $state, 'brand');
    $valid_map = array_fill_keys($valid_ids, true);
    $matches = array_values(array_filter($matches, static fn($row) => isset($valid_map[(int)$row['id']])));
    $matches = array_slice($matches, 0, 30);

    ob_start();
    foreach ($matches as $brand) {
        $term_slug = (string)$brand['slug'];
        $search_text = trim($brand['name'].' '.$term_slug);
        $checked = in_array($term_slug, $state['brand'] ?? [], true);
        echo '<label class="evazar-filter-check" data-filter-text="'.esc_attr(mb_strtolower($search_text,'UTF-8')).'">';
        echo '<input type="checkbox" name="brand[]" value="'.esc_attr($term_slug).'" '.checked($checked,true,false).'>';
        echo '<span>'.esc_html($brand['name']).'</span></label>';
    }
    wp_send_json_success(['brands'=>$matches,'html'=>ob_get_clean(),'count'=>count($matches)]);
}

/** AJAX: جستجوی زنده دسته‌بندی‌های فیلتر. */
add_action('wp_ajax_evazar_filter_category_search', 'evazar_ajax_filter_category_search');
add_action('wp_ajax_nopriv_evazar_filter_category_search', 'evazar_ajax_filter_category_search');
function evazar_ajax_filter_category_search() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'evazar_archive_filters_nonce')) {
        wp_send_json_error(['message' => 'درخواست نامعتبر است.'], 403);
    }

    $query = isset($_POST['q']) ? trim(sanitize_text_field(wp_unslash($_POST['q']))) : '';
    $query_norm = evazar_normalize_search_text($query);
    if (mb_strlen($query_norm, 'UTF-8') < 2) wp_send_json_success(['categories'=>[], 'html'=>'']);

    $cat_tax = evazar_archive_get_taxonomy_name('category');
    if (!$cat_tax) wp_send_json_success(['categories'=>[], 'html'=>'']);

    $state = evazar_archive_filter_state_from_array([
        'brand'=>$_POST['brand'] ?? [], 'category'=>$_POST['category'] ?? [],
        'stock'=>$_POST['stock'] ?? '', 'min_price'=>$_POST['min_price'] ?? '', 'max_price'=>$_POST['max_price'] ?? '',
    ]);
    $context = [
        'taxonomy'=>sanitize_key($_POST['context_taxonomy'] ?? ''),
        'term_id'=>absint($_POST['context_term_id'] ?? 0),
    ];

    $index = evazar_get_cached_category_index($cat_tax);
    $row_by_id = [];
    foreach ($index as $row) $row_by_id[(int)$row['id']] = $row;
    $query_variants = evazar_get_filter_taxonomy_query_variants($query_norm, evazar_archive_get_taxonomy_name('brand'));

    $ranked = [];
    foreach ($index as $row) {
        $name_norm = evazar_normalize_search_text((string)($row['name'] ?? ''));
        $slug_norm = evazar_normalize_search_text((string)($row['slug'] ?? ''));
        $best_score = 0;
        foreach ($query_variants as $variant) {
            if ($variant === '') continue;
            if ($name_norm === $variant || $slug_norm === $variant) $best_score = max($best_score, 1000);
            elseif (mb_strpos($name_norm, $variant, 0, 'UTF-8') === 0 || mb_strpos($slug_norm, $variant, 0, 'UTF-8') === 0) $best_score = max($best_score, 900);
            elseif (mb_strlen($variant, 'UTF-8') >= 3 && (mb_strpos($name_norm, $variant, 0, 'UTF-8') !== false || mb_strpos($slug_norm, $variant, 0, 'UTF-8') !== false)) $best_score = max($best_score, 700);
        }
        if ($best_score <= 0) continue;
        $row['_score'] = $best_score;
        $ranked[] = $row;
    }
    if (!$ranked) wp_send_json_success(['categories'=>[], 'html'=>'']);

    usort($ranked, static function($a,$b){
        $sa=(int)($a['_score']??0); $sb=(int)($b['_score']??0);
        if ($sa!==$sb) return $sb<=>$sa;
        $ca=(int)($a['count']??0); $cb=(int)($b['count']??0);
        if ($ca!==$cb) return $cb<=>$ca;
        return strnatcasecmp(evazar_normalize_search_text($a['name']??''), evazar_normalize_search_text($b['name']??''));
    });
    $ranked = array_slice($ranked, 0, 250);
    $candidate_ids = array_values(array_map(static fn($row)=>(int)$row['id'], $ranked));
    $valid_ids = evazar_archive_smart_term_ids($cat_tax, $candidate_ids, $context, $state, 'category');
    $valid_map = array_fill_keys($valid_ids, true);
    $selected = $state['category'] ?? [];

    $build_path = static function($term_id) use (&$row_by_id) {
        $parts=[]; $cursor=(int)$term_id; $guard=0;
        while ($cursor>0 && isset($row_by_id[$cursor]) && $guard<12) {
            array_unshift($parts,(string)$row_by_id[$cursor]['name']);
            $cursor=(int)($row_by_id[$cursor]['parent']??0); $guard++;
        }
        return implode(' ← ',$parts);
    };

    $matches=[];
    foreach ($ranked as $row) {
        $id=(int)$row['id'];
        if (!isset($valid_map[$id])) continue;
        $matches[]=[
            'id'=>$id,'name'=>(string)$row['name'],'slug'=>(string)$row['slug'],
            'score'=>(int)$row['_score'],'count'=>(int)$row['count'],
            'checked'=>in_array($row['slug'],$selected,true),'path'=>$build_path($id),
        ];
        if (count($matches)>=60) break;
    }

    ob_start();
    if ($matches) {
        echo '<div class="evazar-category-search-results" role="group" aria-label="نتایج جستجوی دسته‌بندی">';
        foreach ($matches as $cat) {
            $term=(object)[
                'term_id'=>(int)$cat['id'],'name'=>(string)$cat['name'],'slug'=>(string)$cat['slug'],
                'parent'=>(int)($row_by_id[(int)$cat['id']]['parent']??0),'taxonomy'=>$cat_tax,
            ];
            echo evazar_render_filter_category_search_result_item($term,$cat['path'],!empty($cat['checked']));
        }
        echo '</div>';
    } else {
        echo '<div class="evazar-filter-category-search-empty">دسته‌ای با این عبارت پیدا نشد</div>';
    }
    wp_send_json_success(['categories'=>$matches,'html'=>ob_get_clean(),'count'=>count($matches)]);
}

add_action('wp_ajax_evazar_filter_category_children', 'evazar_ajax_filter_category_children');
add_action('wp_ajax_nopriv_evazar_filter_category_children', 'evazar_ajax_filter_category_children');
function evazar_ajax_filter_category_children() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'evazar_archive_filters_nonce')) {
        wp_send_json_error(['message' => 'درخواست نامعتبر است.'], 403);
    }
    $tax = evazar_archive_get_taxonomy_name('category');
    $parent_id = absint($_POST['parent_id'] ?? 0);
    if (!$tax || !$parent_id) {
        wp_send_json_success(['html' => '', 'has_children' => false]);
    }
    $state = evazar_archive_filter_state_from_array([
        'brand'=>$_POST['brand'] ?? [], 'category'=>$_POST['category'] ?? [],
        'stock'=>$_POST['stock'] ?? '', 'min_price'=>$_POST['min_price'] ?? '', 'max_price'=>$_POST['max_price'] ?? '',
    ]);
    $context = [
        'taxonomy' => sanitize_key($_POST['context_taxonomy'] ?? ''),
        'term_id' => absint($_POST['context_term_id'] ?? 0),
    ];
    $terms = evazar_get_smart_category_children_terms($parent_id, $context, $state);
    if (!$terms) {
        wp_send_json_success(['html'=>'', 'has_children'=>false]);
    }
    $html = evazar_render_lazy_category_nodes($terms, $state['category'], (int)($_POST['depth'] ?? 1));
    wp_send_json_success(['html'=>$html, 'has_children'=>true]);
}

add_action('wp_ajax_evazar_archive_filter', 'evazar_ajax_archive_filter');
add_action('wp_ajax_nopriv_evazar_archive_filter', 'evazar_ajax_archive_filter');
function evazar_ajax_archive_filter() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'evazar_archive_filters_nonce')) wp_send_json_error(['message'=>'درخواست نامعتبر است.'], 403);

    $state = evazar_archive_filter_state_from_array([
        'brand' => $_POST['brand'] ?? [],
        'category' => $_POST['category'] ?? [],
        'stock' => $_POST['stock'] ?? '',
        'min_price' => $_POST['min_price'] ?? '',
        'max_price' => $_POST['max_price'] ?? '',
    ]);
    $sort = sanitize_text_field($_POST['sort'] ?? 'relevant');
    if (!in_array($sort, ['relevant','views','newest','bestseller','cheapest','expensive','satisfaction'], true)) $sort='relevant';
    $context_tax = sanitize_key($_POST['context_taxonomy'] ?? '');
    $context_term_id = absint($_POST['context_term_id'] ?? 0);
    $search = sanitize_text_field(wp_unslash($_POST['search'] ?? ''));
    $on_sale = !empty($_POST['on_sale']) && (string)$_POST['on_sale'] === '1';
    $paged = max(1, absint($_POST['paged'] ?? 1));
    $posted_base = isset($_POST['base_url']) ? wp_unslash($_POST['base_url']) : '';
    $posted_base_path = '';
    if ($posted_base !== '') {
        $posted_base_path = parse_url($posted_base, PHP_URL_PATH) ?: '';
    }
    if (!$posted_base_path || strpos($posted_base_path, '/') !== 0 || strpos($posted_base_path, '//') !== false) {
        $posted_base_path = parse_url($_SERVER['HTTP_REFERER'] ?? '/', PHP_URL_PATH) ?: '/';
    }
    // AJAX pagination may submit /page/N/. Keep one canonical archive base URL.
    $posted_base_path = preg_replace('#/page/\d+/?$#i', '/', $posted_base_path) ?: '/';
    $base_url = home_url($posted_base_path);


    $GLOBALS['evazar_archive_filter_state'] = $state;
    $GLOBALS['evazar_archive_filter_context'] = ['taxonomy'=>$context_tax,'term_id'=>$context_term_id];
    $GLOBALS['evazar_archive_filter_base_url'] = $base_url;
    $_GET['sort'] = $sort;
    $_GET['orderby'] = $sort;
    if ($search !== '') $_GET['s'] = $search;

    $tax_query = ['relation'=>'AND'];
    if ($context_tax && $context_term_id) {
        $tax_query[] = ['taxonomy'=>$context_tax,'field'=>'term_id','terms'=>[$context_term_id],'include_children'=>true];
    }
    if (!empty($state['brand'])) {
        $tax_query[] = ['taxonomy'=>evazar_archive_get_taxonomy_name('brand'),'field'=>'slug','terms'=>$state['brand'],'operator'=>'IN'];
    }
    if (!empty($state['category'])) {
        $tax_query[] = ['taxonomy'=>evazar_archive_get_taxonomy_name('category'),'field'=>'slug','terms'=>$state['category'],'operator'=>'IN','include_children'=>true];
    }
    if (count($tax_query) === 1) $tax_query = [];

    $meta_query = ['relation'=>'AND'];
    // موجودی فقط از شرط canonical موجودی در posts_clauses خوانده می‌شود: قیمت فعلی > 0، با override explicit_unavailable.
    // فیلتر قیمت نیز در posts_clauses اعمال می‌شود تا فرمت‌های عددی و جداکننده‌ها یکدست باشند.
    if ($on_sale) $meta_query[] = ['key'=>'_evazar_discount_percent','value'=>0,'compare'=>'>','type'=>'NUMERIC'];
    if (count($meta_query) === 1) $meta_query = [];

    $args = [
        'post_type'=>'evazar_product', 'post_status'=>'publish', 'posts_per_page'=>intval(get_option('evazar_opt_archive_posts_per_page',16)),
        'paged'=>$paged, 'no_found_rows'=>false, 'ignore_sticky_posts'=>true,
        's'=>$search, 'tax_query'=>$tax_query, 'meta_query'=>$meta_query,
        'evazar_stock_filter'=>($state['stock']==='1' ? 1 : 0),
        'evazar_min_price_filter'=>($state['min_price'] !== null ? (float)$state['min_price'] : null),
        'evazar_max_price_filter'=>($state['max_price'] !== null ? (float)$state['max_price'] : null),
    ];
    $q = new WP_Query($args);

    ob_start();
    $show_discount = get_option('evazar_opt_archive_show_discount','1');
    $show_rating = get_option('evazar_opt_archive_show_rating','1');
    ?>
    <?php
    $total = (int)$q->found_posts;
    $tabs = ['relevant'=>'مرتبط‌ترین','views'=>'پربازدیدترین','newest'=>'جدیدترین','bestseller'=>'پرفروش‌ترین','cheapest'=>'ارزان‌ترین','expensive'=>'گران‌ترین','satisfaction'=>'پیشنهاد خریداران'];
    ?>
    <div class="dk-sort-bar-container">
        <div class="dk-sort-right">
            <div class="dk-sort-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M6 12h12M9 18h6"/></svg><span>مرتب سازی:</span></div>
            <ul class="dk-sort-items-list"><?php foreach($tabs as $k=>$title): $sort_args = evazar_archive_current_url_args_from_state($state, $search, $k); $u=add_query_arg($sort_args, evazar_archive_filter_base_url()); ?><li><a href="<?php echo esc_url($u); ?>" class="dk-sort-btn <?php echo $sort===$k?'active':''; ?>"><?php echo esc_html($title); ?></a></li><?php endforeach; ?></ul>
        </div>
        <?php if ($total > 0): ?><div class="dk-sort-left-count"><span><?php echo esc_html(evazar_to_fa_num(number_format_i18n($total))); ?></span> کالا</div><?php endif; ?>
    </div>
    <?php if ($q->have_posts()): ?>
        <div class="evazar-archive-grid">
        <?php while($q->have_posts()): $q->the_post();
            $pid=get_the_ID();
            $cur_price=get_post_meta($pid,'_evazar_current_price',true);
            $old_price=get_post_meta($pid,'_evazar_old_price',true);
            $discount=get_post_meta($pid,'_evazar_discount_percent',true);
            $rating=get_post_meta($pid,'_evazar_rating',true);
            $rating_count=(int)get_post_meta($pid,'_evazar_rating_count',true);
            $img_url=get_post_meta($pid,'_evazar_main_image',true) ?: get_the_post_thumbnail_url($pid,'medium');
            if(!$img_url) $img_url='data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300"><rect fill="%23f8fafc" width="300" height="300"/><text fill="%2394a3b8" font-size="16" x="50%" y="50%" text-anchor="middle">تصویر کالا</text></svg>';
            if(function_exists('evazar_cdn_image_url') && strpos($img_url,'data:image')===false) $img_url=evazar_cdn_image_url($img_url, 360);
            $clean_disc=function_exists('evazar_get_clean_discount_badge')?evazar_get_clean_discount_badge($discount,$old_price,$cur_price):'';
        ?>
            <article class="archive-product-card">
                <div class="card-thumb-wrap">
                    <?php if($show_discount==='1' && $clean_disc): ?><span class="card-badge-discount"><?php echo esc_html($clean_disc); ?></span><?php endif; ?>
                    <a href="<?php the_permalink(); ?>"><img src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy" decoding="async" class="card-product-img"></a>
                </div>
                <div class="card-body">
                    <h2 class="card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <?php if($show_rating==='1' && $rating && $rating_count>0): ?><div class="card-rating-row"><span class="rating-star">★ <?php echo esc_html(evazar_to_fa_num($rating)); ?></span></div><?php endif; ?>
                    <div class="card-pricing">
                        <?php if($old_price && (float)$old_price>(float)$cur_price): ?><span class="card-old-price"><?php echo evazar_format_price($old_price); ?></span><?php else: ?><span class="card-old-price-placeholder">&nbsp;</span><?php endif; ?>
                        <div class="card-cur-price"><?php if($cur_price): ?><strong><?php echo evazar_format_price($cur_price); ?></strong><span class="currency">تومان</span><?php else: ?><strong>ناموجود</strong><?php endif; ?></div>
                    </div>
                </div>
            </article>
        <?php endwhile; wp_reset_postdata(); ?>
        </div>
        <div class="evazar-pagination"><?php
            // Keep clean /page/N/ URLs for AJAX navigation and browser history.
            $pagination_base = trailingslashit($base_url) . '%_%';
            echo paginate_links(['base'=>$pagination_base,'format'=>'page/%#%/','prev_text'=>'&#8594; قبلی','next_text'=>'بعدی &#8592;','type'=>'list','mid_size'=>2,'end_size'=>1,'current'=>$paged,'total'=>(int)$q->max_num_pages,'add_args'=>evazar_archive_current_url_args_from_state($state, $search, $sort)]);
        ?></div>
    <?php else: ?>
        <div class="archive-empty-box"><div class="empty-icon">🔍</div><h2>کالایی با این فیلترها یافت نشد.</h2><p>برخی فیلترها را بردارید یا بازه قیمت را گسترده‌تر کنید.</p></div>
    <?php endif; ?>
    <?php
    $results_html = ob_get_clean();
    $active_html = evazar_render_active_archive_filters();
    $filters_html = evazar_render_archive_filters();
    $smart = evazar_get_smart_archive_filter_terms(['taxonomy'=>$context_tax,'term_id'=>$context_term_id], $state);
    $active_count = count($state['brand']) + count($state['category']) + (($state['stock']==='1')?1:0) + (($state['min_price']!==null || $state['max_price']!==null)?1:0);
    $query_args = [];
    foreach (['brand','category'] as $k) if (!empty($state[$k])) $query_args[$k] = $state[$k];
    if ($state['stock']==='1') $query_args['stock']='1';
    if ($state['min_price']!==null) $query_args['min_price']=$state['min_price'];
    if ($state['max_price']!==null) $query_args['max_price']=$state['max_price'];
    if ($search!=='') $query_args['s']=$search;
    if($sort!=='relevant') $query_args['sort']=$sort;
    if ($paged > 1) {
        $pretty_base = trailingslashit($base_url) . 'page/' . absint($paged) . '/';
        $url = add_query_arg($query_args, $pretty_base);
    } else {
        $url = add_query_arg($query_args, $base_url);
    }
    wp_send_json_success(['results_html'=>$results_html,'filters_html'=>$filters_html,'active_html'=>$active_html,'url'=>$url,'found'=>$total,'active_count'=>$active_count,'smart'=>['brand_count'=>count($smart['brands']),'category_count'=>count($smart['categories'])]]);
}

add_action('pre_get_posts', 'evazar_theme_archive_query_filter');
function evazar_theme_archive_query_filter($query) {
    if (!is_admin() && $query->is_main_query()) {
        $req_uri      = $_SERVER['REQUEST_URI'] ?? '';
        $clean_path   = trim(parse_url($req_uri, PHP_URL_PATH), '/');
        $is_brand_dir = ($query->get('evazar_directory') === 'brand') || preg_match('#(?:^|/)brands?(?:/page/\d+)?/?$#i', $clean_path);
        $is_cat_dir   = ($query->get('evazar_directory') === 'category') || preg_match('#(?:^|/)categories?(?:/page/\d+)?/?$#i', $clean_path) || preg_match('#(?:^|/)product-category(?:/page/\d+)?/?$#i', $clean_path);

        if ($is_brand_dir || $is_cat_dir) {
            $query->is_home = false;
            $query->is_front_page = false;
            $query->is_archive = true;
        }

        $is_on_sale_req = isset($_GET['on_sale']) || isset($_GET['discount']) || ($query->is_search() && trim($query->get('s')) === 'تخفیف');

        if ($is_on_sale_req) {
            $query->set('post_type', 'evazar_product');
            $query->set('s', ''); // پاکسازی جستجوی متنی کلمه تخفیف
            $query->is_home = false;
            $query->is_front_page = false;
            $query->is_archive = true;
            $query->is_post_type_archive = true;
            
            $meta_query = $query->get('meta_query') ?: [];
            $meta_query[] = [
                'key'     => '_evazar_discount_percent',
                'value'   => 0,
                'compare' => '>',
                'type'    => 'NUMERIC',
            ];
            $query->set('meta_query', $meta_query);
            $query->set('meta_key', '_evazar_discount_percent');
            $query->set('orderby', 'meta_value_num');
            $query->set('order', 'DESC');
        }

        if ($query->is_tax('evazar_category') || $query->is_tax('evazar_brand') || $query->is_post_type_archive('evazar_product') || $query->is_search() || $is_on_sale_req) {
            $per_page = intval(get_option('evazar_opt_archive_posts_per_page', 16));
            if ($per_page > 0) {
                $query->set('posts_per_page', $per_page);
            }

            // فیلترهای برند، دسته، موجودی و قیمت روی صفحات لیست محصولات.
            evazar_apply_archive_product_filters($query);

            if ($query->is_search() && empty($query->get('post_type')) && !$is_on_sale_req) {
                $query->set('post_type', ['evazar_product', 'post']);
            }
        }
    }
}

// 6. توابع کمکی برای پردازش متن‌های چندخطی
function evazar_get_multiline_meta($post_id, $meta_key) {
    $meta = get_post_meta($post_id, $meta_key, true);
    if (empty($meta)) return [];
    $lines = explode("\n", $meta);
    $lines = array_map('trim', $lines);
    return array_filter($lines);
}

/**
 * پردازش هوشمند ویژگی‌های برجسته کالا با ساختار مدرن (تفکیک عنوان و مقدار + ادغام سطرهای شکسته شده)
 * حل قطعی مشکل ویژگی‌های چندخطی دیجی‌کالا مانند سیستم‌های عامل سازگار و اقلام همراه
 * 
 * @param int $post_id
 * @return array آرایه‌ای از ویژگی‌ها شامل ['label' => '...', 'value' => '...']
 */
function evazar_get_key_features($post_id) {
    $raw = get_post_meta($post_id, '_evazar_key_features', true);
    if (empty($raw)) return [];

    $raw = str_replace(["\r\n", "\r"], "\n", $raw);
    $raw_lines = explode("\n", $raw);
    
    $features = [];
    $current = null;

    foreach ($raw_lines as $line) {
        $line = trim($line);
        if ($line === '') continue;

        // پاکسازی بولت‌ها، خط تیره‌ها یا ستاره‌های ابتدای خط
        $line = preg_replace('/^[-*•\x{2022}\x{25E6}\x{2043}\x{2219}]\s*/u', '', $line);
        $line = trim($line);
        if ($line === '') continue;

        // یافتن دونقطه به عنوان تفکیک‌کننده عنوان و مقدار
        $colon_pos = mb_strpos($line, ':');
        if ($colon_pos === false) {
            $colon_pos = mb_strpos($line, '：'); // دونقطه یونیکد تمام‌عرض
        }

        // اگر سطر دارای دونقطه است و موقعیت آن در محدوده منطقی عنوان است (کمتر از ۷۰ کاراکتر)
        if ($colon_pos !== false && $colon_pos > 0 && $colon_pos < 70) {
            if ($current !== null) {
                $features[] = $current;
            }
            $label = trim(mb_substr($line, 0, $colon_pos));
            $value = trim(mb_substr($line, $colon_pos + 1));
            $current = [
                'label' => $label,
                'value' => $value
            ];
        } else {
            // سطر فاقد دونقطه بوده و در واقع ادامه مقدار سطر قبلی است (مانند سیستم‌های عامل یا اقلام همراه)
            if ($current !== null) {
                $prev_val = rtrim($current['value']);
                if (preg_match('/[\/،,-]\s*$/u', $prev_val)) {
                    $current['value'] = $prev_val . ' ' . $line;
                } else {
                    $current['value'] = $prev_val . ' / ' . $line;
                }
            } else {
                $current = [
                    'label' => '',
                    'value' => $line
                ];
            }
        }
    }

    if ($current !== null) {
        $features[] = $current;
    }

    // پاکسازی نهایی اسلش‌ها یا علائم اضافی پایانی و فاصله‌های مکرر در هر ویژگی
    foreach ($features as &$f) {
        $clean_val = preg_replace('/\s*[\/،,-]\s*$/u', '', trim($f['value']));
        $clean_val = preg_replace('/\s*\/\s*/', ' / ', $clean_val);
        $clean_val = preg_replace('/\s+/', ' ', $clean_val);
        $f['value'] = trim($clean_val);
    }
    unset($f);

    return $features;
}

// 7. تابع کمکی تبدیل آدرس تصویر به CDN کلودفلر و ساخت نسخه اندازه‌گذاری‌شده بدون ذخیره روی هاست
if (!function_exists('evazar_cdn_image_url')) {
    function evazar_cdn_image_url($url, $size = null) {
        if (empty($url) || !is_string($url)) return '';
        $cdn_host = rtrim(trim(get_option('evazar_image_cdn_domain', 'https://img.evazar.ir')), '/');
        $is_digikala_image = stripos($url, 'dkstatics-public.digikala.com') !== false;
        $is_evazar_cdn = ($cdn_host !== '' && stripos($url, $cdn_host) === 0);
        if ($is_digikala_image && $cdn_host !== '') {
            $url = str_replace(['https://dkstatics-public.digikala.com', 'http://dkstatics-public.digikala.com'], $cdn_host, $url);
            $is_evazar_cdn = true;
        }
        $size = is_numeric($size) ? absint($size) : 0;
        if ($size > 0 && $size <= 2000 && $is_evazar_cdn) {
            $parts = wp_parse_url($url);
            if (is_array($parts) && !empty($parts['host'])) {
                $query = [];
                if (!empty($parts['query'])) parse_str($parts['query'], $query);
                $query['x-oss-process'] = 'image/resize,m_lfit,h_' . $size . ',w_' . $size;
                $encoded_query = http_build_query($query, '', '&', PHP_QUERY_RFC3986);
                $url = (!empty($parts['scheme']) ? $parts['scheme'] . '://' : '') . $parts['host'] . (!empty($parts['port']) ? ':' . $parts['port'] : '') . ($parts['path'] ?? '') . ($encoded_query !== '' ? '?' . $encoded_query : '') . (!empty($parts['fragment']) ? '#' . $parts['fragment'] : '');
            }
        }
        return $url;
    }
}

// 8. تابع ترمیم خودکار سلسله‌مراتب دسته‌بندی‌ها (Fallback)
if (!function_exists('evazar_repair_term_ancestors')) {
    function evazar_repair_term_ancestors($term_id) {
        $tax = 'evazar_category';
        $term = get_term($term_id, $tax);
        if (!$term || is_wp_error($term) || intval($term->parent) > 0) {
            return;
        }

        $posts = get_posts([
            'post_type'      => 'evazar_product',
            'posts_per_page' => 1,
            'tax_query'      => [
                [
                    'taxonomy' => $tax,
                    'field'    => 'term_id',
                    'terms'    => $term_id,
                ]
            ],
            'meta_query'     => [
                [
                    'key'     => '_evazar_breadcrumbs',
                    'compare' => 'EXISTS'
                ]
            ]
        ]);

        if (empty($posts)) {
            $posts = get_posts([
                'post_type'      => 'evazar_product',
                'posts_per_page' => 1,
                'meta_query'     => [
                    [
                        'key'     => '_evazar_category',
                        'value'   => $term->name,
                        'compare' => '='
                    ]
                ]
            ]);
        }

        if (empty($posts)) return;

        $bc_meta = get_post_meta($posts[0]->ID, '_evazar_breadcrumbs', true);
        if (empty($bc_meta)) return;

        $raw_crumbs = is_string($bc_meta) ? json_decode($bc_meta, true) : $bc_meta;
        if (!is_array($raw_crumbs)) return;

        $titles = [];
        foreach ($raw_crumbs as $crumb) {
            $title = is_array($crumb) ? ($crumb['title'] ?? $crumb['name'] ?? '') : (string)$crumb;
            $title = trim($title);
            $uri = is_array($crumb) ? ($crumb['url']['uri'] ?? ($crumb['url'] ?? '')) : '';
            if (empty($title) || $title === 'دیجی‌کالا' || strpos($uri, '/product/') !== false || stripos($title, 'dkp-') === 0) {
                continue;
            }
            $titles[] = $title;
        }

        if (in_array($term->name, $titles)) {
            $parent_id = 0;
            foreach ($titles as $t_title) {
                $existing = get_term_by('name', $t_title, $tax);
                $curr_id = 0;
                if ($existing && !is_wp_error($existing)) {
                    $curr_id = intval($existing->term_id);
                    if ($parent_id > 0 && intval($existing->parent) !== $parent_id && $curr_id !== $parent_id) {
                        wp_update_term($curr_id, $tax, ['parent' => $parent_id]);
                        clean_term_cache($curr_id, $tax);
                    }
                } else {
                    $res = wp_insert_term($t_title, $tax, ['parent' => $parent_id]);
                    if (!is_wp_error($res)) {
                        $curr_id = intval($res['term_id']);
                    }
                }
                if ($curr_id > 0) {
                    $parent_id = $curr_id;
                }
                if ($t_title === $term->name) {
                    break;
                }
            }
            clean_taxonomy_cache($tax);
        }
    }
}

// =========================================================================
// ماژول جستجوی فوق‌سریع و هوشمند ایوازار (الگوبرداری از دیجی‌کالا و مبلک)
// =========================================================================

/**
 * ثبت هوشمند کلمات جستجوشده توسط کاربران واقعی
 */
function evazar_log_search_query($query_str) {
    $q = sanitize_text_field(trim($query_str));
    if (mb_strlen($q, 'UTF-8') < 2 || mb_strlen($q, 'UTF-8') > 50) return;
    
    // اگر صرفاً یک کد عددی است ثبت نشود تا تگ‌های متنی باکیفیت باقی بمانند
    $clean_digits = str_replace([' ', '-', '_', 'dkp', 'DKP'], '', $q);
    if (is_numeric($clean_digits)) return;

    $data = get_option('evazar_popular_searches_data', []);
    if (!is_array($data)) $data = [];

    $norm = mb_strtolower($q, 'UTF-8');
    $data[$norm] = ($data[$norm] ?? 0) + 1;

    // نگه‌داری حداکثر ۸۰ عبارت برتر با بالاترین فرکانس جستجو
    if (count($data) > 80) {
        arsort($data);
        $data = array_slice($data, 0, 80, true);
    }
    update_option('evazar_popular_searches_data', $data, false);
}

/**
 * دریافت هوشمند تگ‌های پرطرفدار بر اساس آمار سرچ کاربران و دسته‌ها/برندهای واقعی سایت
 */
function evazar_get_smart_popular_searches($limit = 8) {
    $results = [];

    // ۱. استخراج کلمات پرجستجوی کاربران واقعی
    $user_searches = get_option('evazar_popular_searches_data', []);
    if (!empty($user_searches) && is_array($user_searches)) {
        arsort($user_searches);
        foreach (array_keys($user_searches) as $term) {
            $term_clean = trim($term);
            if (!empty($term_clean) && !in_array($term_clean, $results, true)) {
                $results[] = $term_clean;
            }
            if (count($results) >= $limit) {
                return $results;
            }
        }
    }

    // ۲. فال‌بک داینامیک از دسته‌بندی‌های واقعی فروشگاه
    $cat_tax = taxonomy_exists('evazar_category') ? 'evazar_category' : (taxonomy_exists('product_cat') ? 'product_cat' : '');
    if (!empty($cat_tax)) {
        $cats = get_terms([
            'taxonomy'   => $cat_tax,
            'orderby'    => 'count',
            'order'      => 'DESC',
            'number'     => $limit,
            'hide_empty' => true,
        ]);
        if (!empty($cats) && !is_wp_error($cats)) {
            foreach ($cats as $c) {
                if (!in_array($c->name, $results, true)) {
                    $results[] = $c->name;
                }
                if (count($results) >= $limit) {
                    return $results;
                }
            }
        }
    }

    // ۳. فال‌بک از برندهای واقعی موجود در فروشگاه
    $brand_tax = taxonomy_exists('evazar_brand') ? 'evazar_brand' : (taxonomy_exists('product_brand') ? 'product_brand' : '');
    if (!empty($brand_tax)) {
        $brands = get_terms([
            'taxonomy'   => $brand_tax,
            'orderby'    => 'count',
            'order'      => 'DESC',
            'number'     => ($limit - count($results)),
            'hide_empty' => true,
        ]);
        if (!empty($brands) && !is_wp_error($brands)) {
            foreach ($brands as $b) {
                if (!in_array($b->name, $results, true)) {
                    $results[] = $b->name;
                }
                if (count($results) >= $limit) {
                    return $results;
                }
            }
        }
    }

    if (empty($results)) {
        $results = ['گوشی موبایل', 'لپ تاپ', 'هارد اکسترنال', 'سامسونگ', 'شیائومی', 'ساعت هوشمند'];
    }

    return array_slice($results, 0, $limit);
}

/**
 * تابع رندر ساختار کپسولی جستجو و دراپ‌داون نتایج و ترندها
 */
function evazar_render_search_bar($is_mobile = false) {
    $search_placeholder = get_option('evazar_opt_header_search_placeholder', 'جستجو در نام کالا، دسته‌بندی یا کد کالا...');
    $popular_tags = evazar_get_smart_popular_searches(8);
    $popular_tags = apply_filters('evazar_search_popular_tags', $popular_tags);
    ?>
    <div class="evazar-search-container <?php echo $is_mobile ? 'is-mobile-container' : 'is-desktop-container'; ?>" dir="rtl">
        <form class="evazar-search-form" action="<?php echo esc_url(home_url('/')); ?>" method="get" role="search" autocomplete="off">
            <div class="evazar-search-bar">
                <button type="submit" class="evazar-search-submit" aria-label="جستجو">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="11" cy="11" r="8"></circle>
                        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                    </svg>
                </button>
                <input type="text"
                       name="s"
                       class="evazar-search-input"
                       placeholder="<?php echo esc_attr($search_placeholder); ?>"
                       value="<?php echo esc_attr(get_search_query()); ?>"
                       autocomplete="off"
                       spellcheck="false" />
                <button type="button" class="evazar-search-clear" aria-label="پاک کردن متن" aria-hidden="true" tabindex="-1">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                </button>
                <input type="hidden" name="post_type" value="evazar_product" />
            </div>

            <!-- دراپ‌داون شناور نتایج -->
            <div class="evazar-search-dropdown" style="display: none;">
                <!-- هدر اختصاصی موبایل -->
                <div class="evazar-search-mobile-header">
                    <button type="button" class="evazar-search-mobile-back" aria-label="بازگشت">
                        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </button>
                    <div class="evazar-search-mobile-input-bar">
                        <input type="text" class="evazar-search-mobile-input" placeholder="<?php echo esc_attr($search_placeholder); ?>" value="<?php echo esc_attr(get_search_query()); ?>" autocomplete="off" spellcheck="false" aria-label="جستجو" />
                        <button type="button" class="evazar-search-mobile-clear" aria-label="پاک کردن متن" aria-hidden="true" tabindex="-1">
                            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                <line x1="6" y1="6" x2="18" y2="18"></line>
                            </svg>
                        </button>
                    </div>
                </div>

                <!-- نوار ابزار بالا: فقط کالاهای موجود -->
                <div class="evazar-search-top-toolbar">
                    <label class="evazar-instock-toggle" title="نمایش فقط محصولات موجود در انبار">
                        <span class="evazar-toggle-label">فقط کالاهای موجود</span>
                        <input type="checkbox" class="evazar-instock-checkbox" />
                        <span class="evazar-toggle-slider"></span>
                    </label>
                </div>

                <!-- ۱. تاریخچه جستجوهای اخیر -->
                <div class="evazar-search-section evazar-section-recent" style="display: none;">
                    <div class="evazar-section-header">
                        <div class="evazar-section-title">
                            <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg>
                            <span>جستجوهای اخیر</span>
                        </div>
                        <span role="button" class="evazar-clear-recent-all">پاک کردن</span>
                    </div>
                    <div class="evazar-search-pills evazar-recent-pills"></div>
                </div>

                <!-- ۲. جستجوهای پرطرفدار -->
                <?php if (!empty($popular_tags)): ?>
                <div class="evazar-search-section evazar-section-popular">
                    <div class="evazar-section-header">
                        <div class="evazar-section-title">
                            <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline>
                                <polyline points="17 6 23 6 23 12"></polyline>
                            </svg>
                            <span>جستجوهای پرطرفدار</span>
                        </div>
                    </div>
                    <div class="evazar-search-pills evazar-popular-pills">
                        <?php foreach ($popular_tags as $tag): ?>
                            <a href="<?php echo esc_url(home_url('/?s=' . urlencode($tag) . '&post_type=evazar_product')); ?>" class="evazar-search-pill" data-query="<?php echo esc_attr($tag); ?>">
                                <span><?php echo esc_html($tag); ?></span>
                                <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="7" y1="17" x2="17" y2="7"></line>
                                    <polyline points="7 7 17 7 17 17"></polyline>
                                </svg>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- ۳. اسپینر لودینگ -->
                <div class="evazar-search-loader" style="display: none;">
                    <div class="evazar-spinner"></div>
                    <span>در حال جستجو...</span>
                </div>

                <!-- ۴. محتوای نتایج زنده -->
                <div class="evazar-search-live-content" style="display: none;">
                    <div class="evazar-did-you-mean" style="display: none;">
                        <span>آیا منظورتان این بود:</span>
                        <a href="#" class="evazar-dym-link"></a>
                    </div>

                    <!-- بخش پیشنهادات هوشمند جستجو دیجی‌کالا (Digikala Smart Suggestions) -->
                    <div class="evazar-search-suggestions" style="display: none;">
                        <div class="evazar-suggestions-list"></div>
                    </div>

                    <div class="evazar-matched-categories" style="display: none;">
                        <div class="evazar-group-label">دسته‌بندی‌ها</div>
                        <div class="evazar-categories-list"></div>
                    </div>

                    <div class="evazar-matched-brands" style="display: none;">
                        <div class="evazar-group-label">برندها</div>
                        <div class="evazar-brands-list"></div>
                    </div>

                    <div class="evazar-search-footer">
                        <a href="#" class="evazar-view-all-link">
                            <span>مشاهده همه نتایج</span>
                            <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="15 18 9 12 15 6"></polyline>
                            </svg>
                        </a>
                    </div>
                </div>

                <!-- ۵. عدم یافتن نتیجه -->
                <div class="evazar-search-no-results" style="display: none;">
                    <p>نتیجه‌ای برای این جستجو یافت نشد.</p>
                </div>
            </div>
        </form>
    </div>
    <?php
}

/**
 * پشتیبانی کامل و قطعی جستجوی اصلی وردپرس از کد کالا و شناسه دیجی‌کالا (SKU / DKP)
 * با تزریق مستقیم و بدون شکست در کلاز WHERE کوئری اصلی وردپرس
 */
add_filter('posts_clauses', 'evazar_extend_search_to_sku_clauses', 20, 2);
function evazar_extend_search_to_sku_clauses($clauses, $wp_query) {
    if (!is_admin() && $wp_query->is_main_query() && $wp_query->is_search()) {
        global $wpdb;
        $q = trim((string)$wp_query->get('s'));
        if (!empty($q)) {
            $en_nums = ['0','1','2','3','4','5','6','7','8','9'];
            $fa_nums = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
            $clean_sku = str_replace($fa_nums, $en_nums, $q);
            $clean_sku = trim(str_replace(['dkp-', 'DKP-', 'dkp', 'DKP', ' '], '', $clean_sku));

            if (!empty($clean_sku)) {
                $sku_esc = esc_sql($wpdb->esc_like($clean_sku));
                if (evazar_archive_has_product_index()) {
                    $index_table = evazar_archive_product_index_table();
                    $sku_condition = "(EXISTS (SELECT 1 FROM {$index_table} si WHERE si.product_id = {$wpdb->posts}.ID AND (si.dkp = '%{$sku_esc}%' OR si.sku = '%{$sku_esc}%')) OR (NOT EXISTS (SELECT 1 FROM {$index_table} sx WHERE sx.product_id = {$wpdb->posts}.ID) AND EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm_sku2 WHERE pm_sku2.post_id = {$wpdb->posts}.ID AND pm_sku2.meta_key IN ('_evazar_sku', '_sku', '_evazar_dk_id', '_evazar_dk_url') AND pm_sku2.meta_value LIKE '%{$sku_esc}%')))";
                } else {
                    $sku_condition = "EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm_sku WHERE pm_sku.post_id = {$wpdb->posts}.ID AND pm_sku.meta_key IN ('_evazar_sku', '_sku', '_evazar_dk_id', '_evazar_dk_url') AND pm_sku.meta_value LIKE '%{$sku_esc}%')";
                }

                if (!empty($clauses['where'])) {
                    // اتصال دقیق شرط در کنار post_title درون پرانتز جستجوی وردپرس
                    if (preg_match("/(\b{$wpdb->posts}\.post_title\s+LIKE\s*'[^\']*'\s*\))/i", $clauses['where'])) {
                        $clauses['where'] = preg_replace(
                            "/(\b{$wpdb->posts}\.post_title\s+LIKE\s*'[^\']*'\s*\))/i",
                            "$1 OR {$sku_condition}",
                            $clauses['where'],
                            1
                        );
                    } else {
                        $clauses['where'] .= " OR ({$sku_condition}) ";
                    }
                }
            }
        }
    }
    return $clauses;
}

add_action('pre_get_posts', 'evazar_search_filter_post_types');
function evazar_search_filter_post_types($query) {
    if (!is_admin() && $query->is_main_query() && $query->is_search()) {
        $pt = $query->get('post_type');
        if (empty($pt)) {
            $query->set('post_type', ['evazar_product']);
        }

        // لاگ هوشمند کلمه جستجوشده توسط کاربر
        $s = $query->get('s');
        if (!empty($s) && function_exists('evazar_log_search_query')) {
            evazar_log_search_query($s);
        }
    }
}

/**
 * مدیریت یکپارچه مرتب‌سازی دیجی‌کالا و انتقال تضمینی کالاهای ناموجود به انتهای لیست در تمامی صفحات
 * (دسته‌بندی‌ها، برندها، نتایج جستجو، آرشیوها، تخفیف‌ها و فیلترها)
 */
// ثبت بازدید محصول خارج از رندر صفحه؛ سبک و غیرمسدودکننده.
add_action('wp_ajax_evazar_track_view', 'evazar_track_product_view');
add_action('wp_ajax_nopriv_evazar_track_view', 'evazar_track_product_view');
function evazar_track_product_view() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'evazar_view_nonce')) {
        wp_send_json_error(['message' => 'درخواست نامعتبر است.'], 403);
    }

    $post_id = isset($_POST['post_id']) ? absint($_POST['post_id']) : 0;
    if (!$post_id || get_post_type($post_id) !== 'evazar_product' || get_post_status($post_id) !== 'publish') {
        wp_send_json_error(['message' => 'کالا نامعتبر است.'], 400);
    }

    $views = (int) get_post_meta($post_id, '_evazar_views_count', true);
    update_post_meta($post_id, '_evazar_views_count', $views + 1);
    wp_send_json_success();
}

add_filter('posts_clauses', 'evazar_push_outofstock_and_sort', 30, 2);
function evazar_push_outofstock_and_sort($clauses, $wp_query) {
    if ((is_admin() && !wp_doing_ajax()) || $wp_query->is_singular()) return $clauses;
    $post_type = $wp_query->get('post_type');
    $is_product_query = empty($post_type)
        ? ($wp_query->is_search() || $wp_query->is_tax(['evazar_category','evazar_brand']) || $wp_query->is_post_type_archive('evazar_product'))
        : in_array('evazar_product', (array)$post_type, true);
    if (!$is_product_query) return $clauses;
    global $wpdb;

    if (evazar_archive_has_product_index()) {
        $idx = evazar_archive_product_index_table();
        $clauses['join'] .= " LEFT JOIN {$idx} AS evz_idx ON ({$wpdb->posts}.ID = evz_idx.product_id) ";
        // مهم: ایندکس در اولین دقایق انتشار نسخه جدید هنوز برای همه کالاهای قدیمی پر نشده است.
        // LEFT JOIN + fallback به postmeta مانع از ناپدیدشدن کامل آرشیو در این فاصله می‌شود.
        $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS evz_prc_meta ON ({$wpdb->posts}.ID = evz_prc_meta.post_id AND evz_prc_meta.meta_key = '_evazar_current_price') ";
        $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS evz_avsrc_meta ON ({$wpdb->posts}.ID = evz_avsrc_meta.post_id AND evz_avsrc_meta.meta_key = '_evazar_availability_source') ";
        $clean_index_price = "CASE WHEN evz_idx.product_id IS NULL THEN CAST(REPLACE(REPLACE(REPLACE(COALESCE(evz_prc_meta.meta_value,'0'), ',', ''), '٬', ''), '،', '') AS DECIMAL(18,2)) ELSE evz_idx.price END";
        $clean_meta_price = "CAST(REPLACE(REPLACE(REPLACE(COALESCE(evz_prc_meta.meta_value,'0'), ',', ''), '٬', ''), '،', '') AS DECIMAL(18,2))";
        $stock_value = "CASE WHEN evz_avsrc_meta.meta_value = 'explicit_unavailable' THEN 0 WHEN ({$clean_meta_price}) > 0 THEN 1 ELSE 0 END";
        $stock_case = "CASE WHEN ({$stock_value}) = 1 THEN 0 ELSE 1 END";
        $clauses['fields'] .= ", {$stock_case} AS evz_stock_priority";
        if ($wp_query->get('evazar_stock_filter')) $clauses['where'] .= " AND ({$stock_value}) = 1";

        $min = $wp_query->get('evazar_min_price_filter'); $max = $wp_query->get('evazar_max_price_filter');
        if ($min !== null && $min !== '') $clauses['where'] .= $wpdb->prepare(" AND {$clean_index_price} >= %f", (float)$min);
        if ($max !== null && $max !== '') $clauses['where'] .= $wpdb->prepare(" AND {$clean_index_price} <= %f", (float)$max);

        $sort = sanitize_text_field($_GET['sort'] ?? ($_GET['orderby'] ?? 'relevant'));
        switch ($sort) {
            case 'views':
                $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS evz_views_meta ON ({$wpdb->posts}.ID = evz_views_meta.post_id AND evz_views_meta.meta_key = '_evazar_views_count') ";
                $active_order = "COALESCE(CASE WHEN evz_idx.product_id IS NULL THEN CAST(evz_views_meta.meta_value AS SIGNED) ELSE evz_idx.views END,0) DESC, ".$wpdb->posts.'.post_date DESC'; break;
            case 'bestseller':
            case 'sales':
                $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS evz_sales_meta ON ({$wpdb->posts}.ID = evz_sales_meta.post_id AND evz_sales_meta.meta_key = '_evazar_rating_count') ";
                $active_order = "COALESCE(CASE WHEN evz_idx.product_id IS NULL THEN CAST(evz_sales_meta.meta_value AS SIGNED) ELSE evz_idx.rating_count END,0) DESC, ".$wpdb->posts.'.post_date DESC'; break;
            case 'cheapest':
            case 'price-asc':
                $active_order = $clean_index_price.' ASC, '.$wpdb->posts.'.post_date DESC'; break;
            case 'expensive':
            case 'price-desc':
                $active_order = $clean_index_price.' DESC, '.$wpdb->posts.'.post_date DESC'; break;
            case 'satisfaction':
            case 'rating':
                $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS evz_sat_meta ON ({$wpdb->posts}.ID = evz_sat_meta.post_id AND evz_sat_meta.meta_key = '_evazar_satisfaction') ";
                $active_order = "COALESCE(CASE WHEN evz_idx.product_id IS NULL THEN CAST(evz_sat_meta.meta_value AS SIGNED) ELSE evz_idx.satisfaction END,0) DESC, COALESCE(evz_idx.rating,0) DESC, ".$wpdb->posts.'.post_date DESC'; break;
            case 'newest':
            case 'date':
                $active_order = $wpdb->posts.'.post_date DESC'; break;
            case 'relevant':
            default:
                $active_order = !empty($clauses['orderby']) ? $clauses['orderby'] : $wpdb->posts.'.post_date DESC'; break;
        }
        $clauses['orderby'] = $stock_case.' ASC, '.$active_order;
        return $clauses;
    }

    // Fallback legacy path until the index is available.
    $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS evz_prc_meta ON ({$wpdb->posts}.ID = evz_prc_meta.post_id AND evz_prc_meta.meta_key = '_evazar_current_price') ";
    $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS evz_avsrc_meta ON ({$wpdb->posts}.ID = evz_avsrc_meta.post_id AND evz_avsrc_meta.meta_key = '_evazar_availability_source') ";
    $clean_price = "CAST(REPLACE(REPLACE(REPLACE(COALESCE(evz_prc_meta.meta_value,'0'), ',', ''), '٬', ''), '،', '') AS DECIMAL(18,2))";
    $stock_value = "CASE WHEN evz_avsrc_meta.meta_value = 'explicit_unavailable' THEN 0 WHEN ({$clean_price}) > 0 THEN 1 ELSE 0 END";
    $stock_case = "CASE WHEN ({$stock_value}) = 1 THEN 0 ELSE 1 END";
    $clauses['fields'] .= ", {$stock_case} AS evz_stock_priority";
    if ($wp_query->get('evazar_stock_filter')) $clauses['where'] .= " AND ({$stock_value}) = 1";
    $min = $wp_query->get('evazar_min_price_filter'); $max = $wp_query->get('evazar_max_price_filter');
    if ($min !== null && $min !== '') $clauses['where'] .= $wpdb->prepare(" AND {$clean_price} >= %f ", (float)$min);
    if ($max !== null && $max !== '') $clauses['where'] .= $wpdb->prepare(" AND {$clean_price} <= %f ", (float)$max);
    $sort = sanitize_text_field($_GET['sort'] ?? ($_GET['orderby'] ?? 'relevant'));
    switch ($sort) {
        case 'views':
            $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS evz_views_meta ON ({$wpdb->posts}.ID = evz_views_meta.post_id AND evz_views_meta.meta_key = '_evazar_views_count') ";
            $active_order = 'COALESCE(CAST(evz_views_meta.meta_value AS SIGNED),0) DESC, '.$wpdb->posts.'.post_date DESC'; break;
        case 'bestseller': case 'sales':
            $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS evz_sales_meta ON ({$wpdb->posts}.ID = evz_sales_meta.post_id AND evz_sales_meta.meta_key = '_evazar_rating_count') ";
            $active_order = 'COALESCE(CAST(evz_sales_meta.meta_value AS SIGNED),0) DESC, '.$wpdb->posts.'.post_date DESC'; break;
        case 'cheapest': case 'price-asc': $active_order = "COALESCE({$clean_price},999999999) ASC, {$wpdb->posts}.post_date DESC"; break;
        case 'expensive': case 'price-desc': $active_order = "COALESCE({$clean_price},0) DESC, {$wpdb->posts}.post_date DESC"; break;
        case 'satisfaction': case 'rating':
            $clauses['join'] .= " LEFT JOIN {$wpdb->postmeta} AS evz_sat_meta ON ({$wpdb->posts}.ID = evz_sat_meta.post_id AND evz_sat_meta.meta_key = '_evazar_satisfaction') ";
            $active_order = 'COALESCE(CAST(evz_sat_meta.meta_value AS SIGNED),0) DESC, '.$wpdb->posts.'.post_date DESC'; break;
        case 'newest': case 'date': $active_order=$wpdb->posts.'.post_date DESC'; break;
        default: $active_order=!empty($clauses['orderby'])?$clauses['orderby']:$wpdb->posts.'.post_date DESC'; break;
    }
    $clauses['orderby'] = $stock_case.' ASC, '.$active_order;
    return $clauses;
}

/**
 * پردازشگر آژاکس جستجوی زنده ایوازار با کش موقت و سرعت زیر ۲۰ میلی‌ثانیه
 */
/**
 * نرمال‌سازی یکپارچه عبارت جستجو برای فارسی/عربی/لاتین.
 * هدف: «ي/ی»، «ك/ک»، نیم‌فاصله، اعراب، فاصله‌های اضافه و حروف مشابه
 * بدون تغییر متن اصلیِ قابل نمایش، در مقایسه با هم یکسان شوند.
 */
function evazar_normalize_search_text($text) {
    $text = wp_strip_all_tags((string) $text);
    $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
    $text = str_replace(
        ['ي','ى','ئ','ك','ة','ۀ','ؤ','أ','إ','آ','ٱ','‌','ـ'],
        ['ی','ی','ی','ک','ه','ه','و','ا','ا','ا','ا',' ',''],
        $text
    );
    // حذف اعراب و علائم آوایی عربی
    $text = preg_replace('/[\x{064B}-\x{065F}\x{0670}]/u', '', $text);
    // یکسان‌سازی اعداد عربی/فارسی
    $text = str_replace(
        ['٠','١','٢','٣','٤','٥','٦','٧','٨','٩','۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'],
        ['0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9'],
        $text
    );
    $text = preg_replace('/\s+/u', ' ', $text);
    return mb_strtolower(trim($text), 'UTF-8');
}

/** نرمال‌سازی داخلیِ نام برند/دسته برای مقایسه سریع و دقیق‌تر. */
function evazar_search_term_score($term_name, $query_norm) {
    $name_norm = evazar_normalize_search_text($term_name);
    if ($name_norm === '') return 0;
    if ($name_norm === $query_norm) return 1000;
    if (mb_strpos($name_norm, $query_norm, 0, 'UTF-8') === 0) return 800;
    if (mb_strpos($name_norm, $query_norm, 0, 'UTF-8') !== false) return 600;
    if (mb_strpos($query_norm, $name_norm, 0, 'UTF-8') !== false) return 500;
    return 0;
}

/**
 * فهرست سبک برندها برای تشخیص «برند + عبارت» بدون Query سنگین در هر keystroke.
 * فقط اطلاعات taxonomy خوانده می‌شود و ۱۰ دقیقه Cache می‌شود.
 */
function evazar_get_cached_brand_index($brand_tax) {
    global $wpdb;
    $cache_key = 'evz_brand_index_v2_' . md5($brand_tax);
    $cached = get_transient($cache_key);
    if (is_array($cached)) return $cached;

    $terms = get_terms([
        'taxonomy'   => $brand_tax,
        'hide_empty' => true,
        'number'     => 5000,
        'orderby'    => 'count',
        'order'      => 'DESC',
    ]);
    $index = [];
    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $name_norm = evazar_normalize_search_text($term->name);
            if ($name_norm === '') continue;
            $index[(int)$term->term_id] = [
                'id'      => (int) $term->term_id,
                'name'    => $term->name,
                'slug'    => $term->slug,
                'url'     => get_term_link($term),
                'count'   => (int) $term->count,
                'norm'    => $name_norm,
                'aliases' => [],
            ];
        }
    }

    // بعضی برندها نام فارسی دارند ولی در داده محصولات نام انگلیسی هم ذخیره شده است
    // (مثلاً «ایکیا» + IKEA). این aliasها باعث می‌شوند جستجوی فیلتر مستقل از زبان ثبت‌شده برند باشد.
    if (!empty($index)) {
        $tax_sql = $wpdb->prepare("SELECT tt.term_id, pm.meta_value\n            FROM {$wpdb->term_taxonomy} tt\n            INNER JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id = tt.term_taxonomy_id\n            INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id AND p.post_type = 'evazar_product' AND p.post_status = 'publish'\n            INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_evazar_brand_en'\n            WHERE tt.taxonomy = %s AND pm.meta_value <> ''\n            GROUP BY tt.term_id, pm.meta_value", $brand_tax);
        $alias_rows = $wpdb->get_results($tax_sql);
        if ($alias_rows) {
            foreach ($alias_rows as $row) {
                $term_id = (int)$row->term_id;
                if (!isset($index[$term_id])) continue;
                $alias = trim((string)$row->meta_value);
                if ($alias === '') continue;
                $alias_norm = evazar_normalize_search_text($alias);
                if ($alias_norm !== '') $index[$term_id]['aliases'][$alias_norm] = true;
            }
        }
    }

    // چند معادل رایج فارسی/لاتین برای برندهایی که در داده‌های قدیمی alias انگلیسی ندارند.
    $known_aliases = [
        'asus' => ['ایسوس'], 'ikea' => ['ایکیا','ایکا'], 'samsung' => ['سامسونگ'],
        'xiaomi' => ['شیائومی','شیائومی'], 'apple' => ['اپل'], 'lenovo' => ['لنوو'],
        'dell' => ['دل'], 'hp' => ['اچ پی','اچ‌پی'], 'sony' => ['سونی'], 'lg' => ['ال جی','ال‌جی'],
        'anker' => ['انکر'], 'philips' => ['فیلیپس'], 'acer' => ['ایسر'], 'huawei' => ['هواوی','هوآوی'],
        'nokia' => ['نوکیا'], 'microsoft' => ['مایکروسافت'], 'logitech' => ['لاجیتک'],
    ];
    foreach ($index as $term_id => &$row) {
        foreach ($known_aliases as $latin => $persian_values) {
            if ($row['norm'] === $latin || in_array($latin, array_keys($row['aliases']), true)) {
                $row['aliases'][$latin] = true;
            }
            foreach ($persian_values as $pv) {
                $pn = evazar_normalize_search_text($pv);
                if ($pn !== '' && $row['norm'] === $pn) $row['aliases'][$latin] = true;
            }
        }
        $row['aliases'] = array_values(array_unique(array_keys($row['aliases'])));
    }
    unset($row);

    $index = array_values($index);
    usort($index, function($a, $b) {
        $la = mb_strlen($a['norm'], 'UTF-8');
        $lb = mb_strlen($b['norm'], 'UTF-8');
        if ($la === $lb) return $b['count'] <=> $a['count'];
        return $lb <=> $la;
    });
    set_transient($cache_key, $index, 10 * MINUTE_IN_SECONDS);
    return $index;
}


function evazar_get_filter_taxonomy_query_variants($query_norm, $brand_tax) {
    $query_norm = evazar_normalize_search_text($query_norm);
    $variants = $query_norm !== '' ? [$query_norm] : [];
    if (!$brand_tax || $query_norm === '') return array_values(array_unique($variants));

    $exact = [];
    $prefix = [];
    foreach (evazar_get_cached_brand_index($brand_tax) as $row) {
        $name_norm = (string)($row['norm'] ?? '');
        $slug_norm = evazar_normalize_search_text((string)($row['slug'] ?? ''));
        $aliases = array_values(array_filter((array)($row['aliases'] ?? [])));
        $needles = array_merge([$name_norm, $slug_norm], $aliases);
        $matched_exact = false;
        $matched_prefix = false;
        foreach ($needles as $needle) {
            $needle = evazar_normalize_search_text($needle);
            if ($needle === '') continue;
            if ($needle === $query_norm) {
                $matched_exact = true;
                break;
            }
            if (mb_strpos($needle, $query_norm, 0, 'UTF-8') === 0) {
                $matched_prefix = true;
            }
        }
        if ($matched_exact && $name_norm !== '') {
            $exact[$name_norm] = true;
        } elseif ($matched_prefix && $name_norm !== '') {
            $prefix[$name_norm] = true;
        }
    }

    // Exact brand/alias match is the preferred way to expand an English query
    // into the localized category name (e.g. IKEA -> ایکیا). Prefix fallback is
    // deliberately limited so short queries do not broaden category search.
    foreach (array_keys($exact) as $v) $variants[] = $v;
    if (count($variants) === 1) {
        foreach (array_keys($prefix) as $v) {
            $variants[] = $v;
            if (count($variants) >= 3) break;
        }
    }
    return array_values(array_unique($variants));
}

/**
 * فهرست سبک دسته‌بندی‌ها برای جستجوی زنده فیلترها.
 * داده taxonomy فقط یک‌بار Cache می‌شود و جستجو در حافظه انجام می‌شود.
 */
function evazar_get_cached_category_index($cat_tax) {
    $cache_key = 'evz_category_index_v1_' . md5($cat_tax);
    $cached = get_transient($cache_key);
    if (is_array($cached)) return $cached;

    $terms = get_terms([
        'taxonomy'   => $cat_tax,
        'hide_empty' => true,
        'number'     => 5000,
        'orderby'    => 'count',
        'order'      => 'DESC',
    ]);
    $index = [];
    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $name_norm = evazar_normalize_search_text($term->name);
            if ($name_norm === '') continue;
            $index[] = [
                'id'   => (int) $term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'url'  => get_term_link($term),
                'count'=> (int) $term->count,
                'norm' => $name_norm,
                'parent' => (int) $term->parent,
            ];
        }
    }
    set_transient($cache_key, $index, 10 * MINUTE_IN_SECONDS);
    return $index;
}

function evazar_flush_search_category_index($term_id = 0, $tt_id = 0, $taxonomy = '') {
    if ($taxonomy && !in_array($taxonomy, ['evazar_category', 'product_cat'], true)) return;
    foreach (['evazar_category', 'product_cat'] as $tax) {
        delete_transient('evz_category_index_v1_' . md5($tax));
    }
}
add_action('created_term', 'evazar_flush_search_category_index', 10, 3);
add_action('edited_term', 'evazar_flush_search_category_index', 10, 3);
add_action('delete_term', 'evazar_flush_search_category_index', 10, 3);

function evazar_flush_search_brand_index($term_id = 0, $tt_id = 0, $taxonomy = '') {
    if ($taxonomy && !in_array($taxonomy, ['evazar_brand', 'product_brand', 'pwb-brand'], true)) {
        return;
    }
    foreach (['evazar_brand', 'product_brand', 'pwb-brand'] as $tax) {
        delete_transient('evz_brand_index_v1_' . md5($tax));
        delete_transient('evz_brand_index_v2_' . md5($tax));
    }
}
add_action('created_term', 'evazar_flush_search_brand_index', 10, 3);
add_action('edited_term', 'evazar_flush_search_brand_index', 10, 3);
add_action('delete_term', 'evazar_flush_search_brand_index', 10, 3);

add_action('wp_ajax_evazar_ajax_search', 'evazar_handle_ajax_search');
add_action('wp_ajax_nopriv_evazar_ajax_search', 'evazar_handle_ajax_search');
function evazar_handle_ajax_search() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'evazar_search_nonce')) {
        wp_send_json_error(['message' => 'درخواست نامعتبر است.'], 403);
    }

    $raw_query     = isset($_POST['keyword']) ? sanitize_text_field(wp_unslash($_POST['keyword'])) : '';
    $raw_query     = trim($raw_query);
    $in_stock_only = isset($_POST['in_stock_only']) && ('1' === (string)$_POST['in_stock_only'] || 'true' === (string)$_POST['in_stock_only']);

    if (empty($raw_query) || mb_strlen($raw_query, 'UTF-8') < 2) {
        wp_send_json_success([
            'categories'     => [],
            'brands'         => [],
            'products'       => [],
            'total_products' => 0,
            'did_you_mean'   => null,
        ]);
    }

    // نرمال‌سازی واحد برای فارسی/عربی/لاتین و SKU/DKP
    $norm_query = evazar_normalize_search_text($raw_query);
    $en_query   = $norm_query;
    $sku_query  = str_replace(['.', '-', ' '], '', $en_query);

    // کش موقت ۳ دقیقه‌ای نتایج زنده (کلید جدید جهت بی‌اثر کردن کش‌های قدیمی ناموجود)
    $cache_key = 'evz_srch_v17_' . md5(mb_strtolower($en_query, 'UTF-8') . ($in_stock_only ? '_instk' : ''));
    $cached = get_transient($cache_key);
    if (false !== $cached && is_array($cached)) {
        wp_send_json_success($cached);
    }

    if (function_exists('evazar_log_search_query')) {
        evazar_log_search_query($raw_query);
    }

    // ۱. جستجوی دسته‌بندی‌های منطبق؛ Exact Match همیشه اول است.
    $categories = [];
    $primary_cat_term = null;
    $cat_objects = [];
    $cat_tax = taxonomy_exists('evazar_category') ? 'evazar_category' : (taxonomy_exists('product_cat') ? 'product_cat' : '');
    if (!empty($cat_tax)) {
        $cat_terms_pool = [];
        foreach (array_unique([$raw_query, $norm_query]) as $term_query) {
            if ($term_query === '') continue;
            $found = get_terms([
                'taxonomy'   => $cat_tax,
                'name__like' => $term_query,
                'number'     => 12,
                'hide_empty' => true,
            ]);
            if (!empty($found) && !is_wp_error($found)) {
                foreach ($found as $t) $cat_terms_pool[$t->term_id] = $t;
            }
        }
        $ranked_cats = [];
        foreach ($cat_terms_pool as $t) {
            $score = evazar_search_term_score($t->name, $norm_query);
            if ($score > 0) {
                $ranked_cats[] = ['term' => $t, 'score' => $score];
            }
        }
        usort($ranked_cats, function($a, $b) {
            if ($a['score'] === $b['score']) return $b['term']->count <=> $a['term']->count;
            return $b['score'] <=> $a['score'];
        });
        foreach (array_slice($ranked_cats, 0, 4) as $row) {
            $t = $row['term'];
            if (!$primary_cat_term) $primary_cat_term = $t;
            $cat_objects[$t->term_id] = $t;
            $categories[] = [
                'id'    => $t->term_id,
                'name'  => $t->name,
                'url'   => get_term_link($t),
                'type'  => 'category',
            ];
        }
    }

    // ۲. جستجوی برندهای منطبق؛ برند باید مستقل از پیشنهادهای هوشمند نمایش داده شود.
    $brands = [];
    $brand_tax = taxonomy_exists('evazar_brand') ? 'evazar_brand' : (taxonomy_exists('product_brand') ? 'product_brand' : (taxonomy_exists('pwb-brand') ? 'pwb-brand' : ''));
    $matched_brand_term = null;
    $exact_brand_match = false;
    if (!empty($brand_tax)) {
        $brand_terms_pool = [];
        foreach (array_unique([$raw_query, $norm_query]) as $term_query) {
            if ($term_query === '') continue;
            $found = get_terms([
                'taxonomy'   => $brand_tax,
                'name__like' => $term_query,
                'number'     => 12,
                'hide_empty' => true,
            ]);
            if (!empty($found) && !is_wp_error($found)) {
                foreach ($found as $b) $brand_terms_pool[$b->term_id] = $b;
            }
        }

        // برای «برند + عبارت» از ایندکس سبک و Cache‌شده برندها استفاده می‌کنیم.
        $brand_index = evazar_get_cached_brand_index($brand_tax);
        foreach ($brand_index as $bi) {
            $name_norm = $bi['norm'] ?? evazar_normalize_search_text($bi['name'] ?? '');
            $slug_norm = evazar_normalize_search_text($bi['slug'] ?? '');
            $is_exact_name = ($name_norm !== '' && $name_norm === $norm_query);
            $is_exact_slug = ($slug_norm !== '' && $slug_norm === $norm_query);
            $is_query_contains_name = ($name_norm !== '' && mb_strpos($norm_query, $name_norm, 0, 'UTF-8') !== false);
            $is_query_contains_slug = ($slug_norm !== '' && mb_strpos($norm_query, $slug_norm, 0, 'UTF-8') !== false);

            if ($is_exact_name || $is_exact_slug || $is_query_contains_name || $is_query_contains_slug) {
                if (!isset($brand_terms_pool[$bi['id']])) {
                    $obj = get_term($bi['id'], $brand_tax);
                    if ($obj && !is_wp_error($obj)) $brand_terms_pool[$bi['id']] = $obj;
                }
                if (!$matched_brand_term) {
                    $matched_brand_term = $brand_terms_pool[$bi['id']] ?? null;
                    $exact_brand_match = $is_exact_name || $is_exact_slug;
                }
                // نام دقیق/slug دقیق اولویت بالاتری از تطبیق صرفاً بخشی دارد.
                if ($is_exact_name || $is_exact_slug) break;
            }
        }

        $ranked_brands = [];
        foreach ($brand_terms_pool as $b) {
            $score = evazar_search_term_score($b->name, $norm_query);
            if ($score > 0 || mb_strpos($norm_query, evazar_normalize_search_text($b->name), 0, 'UTF-8') !== false) {
                $ranked_brands[] = ['term' => $b, 'score' => max($score, 450)];
            }
        }
        usort($ranked_brands, function($a, $b) {
            if ($a['score'] === $b['score']) return $b['term']->count <=> $a['term']->count;
            return $b['score'] <=> $a['score'];
        });
        foreach (array_slice($ranked_brands, 0, 4) as $row) {
            $b = $row['term'];
            if (!$matched_brand_term && evazar_normalize_search_text($b->name) === $norm_query) {
                $matched_brand_term = $b;
                $exact_brand_match = true;
            }
            $brands[] = [
                'id'    => $b->term_id,
                'name'  => $b->name,
                'url'   => get_term_link($b),
                'type'  => 'brand',
            ];
        }
    }

    // ۳. جستجوی کالاها
    $post_types = ['evazar_product'];

    $meta_query = [];
    if ($in_stock_only) {
        $meta_query[] = [
            'key'     => '_evazar_current_price',
            'value'   => 0,
            'compare' => '>',
            'type'    => 'NUMERIC',
        ];
        $meta_query[] = [
            'relation' => 'OR',
            [
                'key'     => '_evazar_availability_source',
                'compare' => 'NOT EXISTS',
            ],
            [
                'key'     => '_evazar_availability_source',
                'value'   => 'explicit_unavailable',
                'compare' => '!=',
            ],
        ];
    }

    // -------------------------------------------------------------------------
    // جستجوی چندمسیره برای برندها
    //
    // مشکل رایج: کاربر «asus» می‌نویسد ولی عنوان کالا «ایسوس» است.
    // همچنین بعضی کالاهای قدیمی taxonomy برند ندارند اما نام برند در عنوان/متن
    // محصول وجود دارد. بنابراین برای برند دقیق، taxonomy و جستجوی متنی را با هم
    // می‌گیریم و نتایج را یکتا می‌کنیم. برای عبارت ترکیبی مثل «لپ تاپ asus»
    // یک مسیر taxonomy+text و یک مسیر text-only اجرا می‌شود.
    // -------------------------------------------------------------------------
    $query_posts = [];
    $query_found_ids = [];
    $search_variants = [$norm_query];

    $brand_name_norm_for_query = '';
    $brand_slug_norm_for_query = '';
    if ($matched_brand_term && !empty($brand_tax)) {
        $brand_name_norm_for_query = evazar_normalize_search_text($matched_brand_term->name);
        $brand_slug_norm_for_query = evazar_normalize_search_text($matched_brand_term->slug);

        // «ASUS» ↔ «ایسوس»: برای برند دقیق، نام نمایشی برند را نیز جستجو کن.
        if ($exact_brand_match) {
            if ($brand_name_norm_for_query !== '' && $brand_name_norm_for_query !== $norm_query) {
                $search_variants[] = $brand_name_norm_for_query;
            }
        } else {
            // عبارت ترکیبی: مثلاً «لپ تاپ asus» → «لپ تاپ ایسوس».
            $combined_variant = $norm_query;
            if ($brand_slug_norm_for_query !== '' && mb_strpos($combined_variant, $brand_slug_norm_for_query, 0, 'UTF-8') !== false) {
                $combined_variant = trim(str_replace($brand_slug_norm_for_query, $brand_name_norm_for_query, $combined_variant));
            }
            if ($brand_name_norm_for_query !== '' && mb_strpos($combined_variant, $brand_name_norm_for_query, 0, 'UTF-8') === false) {
                // اگر تشخیص با بخشی از نام انجام شده، تلاش بعدی با نام کامل برند.
                $combined_variant = trim($combined_variant . ' ' . $brand_name_norm_for_query);
            }
            if ($combined_variant !== '' && $combined_variant !== $norm_query) {
                $search_variants[] = $combined_variant;
            }
        }
    }

    // حداکثر دو variant: عبارت اصلی + معادل مناسب برند/فارسی.
    $search_variants = array_values(array_unique(array_slice($search_variants, 0, 2)));

    $run_query = function(array $args) use (&$query_posts, &$query_found_ids) {
        $q = new WP_Query($args);
        $found = (int) $q->found_posts;
        if ($q->have_posts()) {
            foreach ($q->posts as $post_obj) {
                $pid = (int) $post_obj->ID;
                if (!isset($query_found_ids[$pid])) {
                    $query_found_ids[$pid] = true;
                    $query_posts[] = $post_obj;
                }
            }
        }
        return $found;
    };

    if ($matched_brand_term && $exact_brand_match) {
        // تمام محصولات taxonomy برند + کالاهایی که نام برند فقط در title/excerpt/content دارند.
        $run_query([
            'post_type'           => $post_types,
            'post_status'         => 'publish',
            'posts_per_page'      => 24,
            'meta_query'          => $meta_query,
            'tax_query'           => [[
                'taxonomy' => $brand_tax,
                'field'    => 'term_id',
                'terms'    => [(int) $matched_brand_term->term_id],
            ]],
            'orderby'             => 'relevance',
            'ignore_sticky_posts' => true,
        ]);

        // محصولات قدیمی که برندشان در متا ثبت شده ولی taxonomy ندارند.
        $brand_meta_values = array_values(array_unique(array_filter([
            $brand_name_norm_for_query,
            $brand_slug_norm_for_query,
            $norm_query,
        ])));
        if (!empty($brand_meta_values)) {
            $brand_meta_or = ['relation' => 'OR'];
            foreach ($brand_meta_values as $brand_value) {
                $brand_meta_or[] = [
                    'key'     => '_evazar_brand',
                    'value'   => $brand_value,
                    'compare' => 'LIKE',
                ];
                $brand_meta_or[] = [
                    'key'     => '_evazar_brand_en',
                    'value'   => $brand_value,
                    'compare' => 'LIKE',
                ];
            }
            $run_query([
                'post_type'           => $post_types,
                'post_status'         => 'publish',
                'posts_per_page'      => 24,
                'meta_query'          => array_merge(
                    ['relation' => 'AND'],
                    $meta_query,
                    [$brand_meta_or]
                ),
                'ignore_sticky_posts' => true,
            ]);
        }

        foreach ($search_variants as $variant) {
            if ($variant === '') continue;
            $run_query([
                'post_type'           => $post_types,
                'post_status'         => 'publish',
                's'                   => $variant,
                'posts_per_page'      => 24,
                'meta_query'          => $meta_query,
                'orderby'             => 'relevance',
                'ignore_sticky_posts' => true,
            ]);
        }
    } elseif ($matched_brand_term && !$exact_brand_match) {
        // عبارت ترکیبی: مسیر دقیقِ برند+متن و مسیر آزاد برای کالاهای قدیمی فاقد taxonomy برند.
        $primary_variant = $search_variants[1] ?? $search_variants[0] ?? $norm_query;
        $run_query([
            'post_type'           => $post_types,
            'post_status'         => 'publish',
            's'                   => $primary_variant,
            'posts_per_page'      => 24,
            'meta_query'          => $meta_query,
            'tax_query'           => [[
                'taxonomy' => $brand_tax,
                'field'    => 'term_id',
                'terms'    => [(int) $matched_brand_term->term_id],
            ]],
            'orderby'             => 'relevance',
            'ignore_sticky_posts' => true,
        ]);

        foreach ($search_variants as $variant) {
            if ($variant === '') continue;
            $run_query([
                'post_type'           => $post_types,
                'post_status'         => 'publish',
                's'                   => $variant,
                'posts_per_page'      => 24,
                'meta_query'          => $meta_query,
                'orderby'             => 'relevance',
                'ignore_sticky_posts' => true,
            ]);
        }
    } else {
        $run_query([
            'post_type'           => $post_types,
            'post_status'         => 'publish',
            's'                   => $norm_query,
            'posts_per_page'      => 24,
            'meta_query'          => $meta_query,
            'orderby'             => 'relevance',
            'ignore_sticky_posts' => true,
        ]);
    }

    $total_found = count($query_posts);

    // اگر با متن/برند چیزی پیدا نشد، با SKU / DKP جستجو شود.
    if ($total_found === 0 && !empty($sku_query)) {
        $sku_args = [
            'post_type'      => $post_types,
            'post_status'    => 'publish',
            'posts_per_page' => 24,
            'meta_query'     => array_merge(
                ['relation' => 'AND'],
                $meta_query,
                [[
                    'relation' => 'OR',
                    [
                        'key'     => '_evazar_sku',
                        'value'   => $sku_query,
                        'compare' => 'LIKE',
                    ],
                    [
                        'key'     => '_sku',
                        'value'   => $sku_query,
                        'compare' => 'LIKE',
                    ],
                    [
                        'key'     => '_evazar_dk_id',
                        'value'   => $sku_query,
                        'compare' => 'LIKE',
                    ],
                ]]
            ),
        ];
        $run_query($sku_args);
        $total_found = count($query_posts);
    }


    // فقط عنوان کالاها برای ساخت پیشنهادهای طبیعی مورد نیاز است.
    // قیمت، تصویر، دسته و برند هر محصول در Dropdown جستجو نمایش داده نمی‌شوند؛
    // بنابراین از خواندن متادیتای سنگین برای هر نتیجه صرف‌نظر می‌کنیم.
    $product_titles = [];
    if (!empty($query_posts)) {
        foreach ($query_posts as $post_obj) {
            $pid = is_object($post_obj) ? (int) $post_obj->ID : (int) $post_obj;
            if ($pid <= 0) continue;
            $product_titles[] = get_the_title($pid);
        }
    }

    // دسته «منطبق» فقط باید از taxonomy واقعی جستجو به دست بیاید؛
    // دسته‌های والد/محصولات پیدا شده نباید صرفاً به‌عنوان نتیجه جستجو نمایش داده شوند.
    $primary_cat_name = '';
    $primary_cat_url  = '';
    if (!empty($primary_cat_term)) {
        $primary_cat_name = $primary_cat_term->name;
        $primary_cat_url  = get_term_link($primary_cat_term);
    }

    // =========================================================================
    // پیشنهادات جستجو: فقط عبارت‌های واقعی و غیرتکراری؛ برند/دسته در بخش مستقل.
    // از عناوین واقعی محصولات Match‌شده برای پیشنهادهای سبک و طبیعی استفاده می‌کنیم.
    // =========================================================================
    $suggestions = [];
    $raw_clean = trim($raw_query);
    $suggestion_seen = [];

    $add_suggestion = static function($title) use (&$suggestions, &$suggestion_seen, $raw_clean, $norm_query) {
        $title = trim(preg_replace('/\\s+/u', ' ', (string)$title));
        if ($title === '') return;
        $key = evazar_normalize_search_text($title);
        $query_key = evazar_normalize_search_text($raw_clean);
        if ($key === '' || $key === $query_key) return;
        // از تکرارهای واضح مانند «ایسوس ایسوس» یا «ایکیا ایکیا» جلوگیری کن.
        $parts = preg_split('/\\s+/u', $key, -1, PREG_SPLIT_NO_EMPTY);
        if (count($parts) >= 2 && $parts[0] === $parts[1]) return;
        if (isset($suggestion_seen[$key])) return;
        $suggestion_seen[$key] = true;
        $suggestions[] = [
            'title'       => $title,
            'category'    => '',
            'type'        => 'query',
            'url'         => '',
            'search_term' => $title,
        ];
    };

    // ۱. عبارات کوتاه طبیعی از عنوان کالاها؛ مناسب برای جستجوی عمومی مثل «ساعت».
    $needles = array_values(array_unique(array_filter([
        $raw_clean,
        $matched_brand_term ? $matched_brand_term->name : '',
    ])));
    foreach ($product_titles as $ptitle) {
        $title = trim(preg_replace('/\\s+/u', ' ', (string)$ptitle));
        if ($title === '') continue;
        foreach ($needles as $needle) {
            $needle = trim((string)$needle);
            if ($needle === '') continue;
            $pattern = '/' . preg_quote($needle, '/') . '(?:\\s+[^\\s]+){0,2}/iu';
            if (preg_match($pattern, $title, $m)) {
                $candidate = trim($m[0]);
                $words = preg_split('/\\s+/u', $candidate, -1, PREG_SPLIT_NO_EMPTY);
                if (count($words) > 3) {
                    $candidate = implode(' ', array_slice($words, 0, 3));
                }
                $add_suggestion($candidate);
            }
            if (count($suggestions) >= 6) break 2;
        }
    }

    // ۲. عبارت‌های پرجستجو که واقعاً با query شروع می‌شوند؛ فقط اگر تکراری نباشند.
    if (count($suggestions) < 6) {
        $popular_terms = evazar_get_smart_popular_searches(12);
        $query_lc = mb_strtolower($norm_query, 'UTF-8');
        foreach ($popular_terms as $popular_term) {
            $pop_norm = evazar_normalize_search_text($popular_term);
            if ($pop_norm === '' || $pop_norm === $query_lc) continue;
            if (mb_strpos($pop_norm, $query_lc, 0, 'UTF-8') === 0 || mb_strpos($query_lc, $pop_norm, 0, 'UTF-8') === 0) {
                $add_suggestion($popular_term);
            }
            if (count($suggestions) >= 6) break;
        }
    }

    // ۳. برای query دقیق برند، هرگز نام همان برند را دوباره به خودش اضافه نکن.
    if (!empty($matched_brand_term) && $exact_brand_match) {
        $brand_norm = evazar_normalize_search_text($matched_brand_term->name);
        $suggestions = array_values(array_filter($suggestions, static function($item) use ($brand_norm) {
            $candidate = evazar_normalize_search_text($item['title'] ?? '');
            if ($candidate === $brand_norm) return false;
            $parts = preg_split('/\\s+/u', $candidate, -1, PREG_SPLIT_NO_EMPTY);
            return !(count($parts) >= 2 && $parts[0] === $brand_norm && $parts[1] === $brand_norm);
        }));
    }

    // غلط‌یاب هوشمند املایی (Did You Mean)
    $did_you_mean = null;
    $dictionary = ['میز', 'صندلی', 'تختخواب', 'کمد', 'دراور', 'قفسه', 'کتابخانه', 'لوستر', 'آباژور', 'مبلمان', 'کاناپه', 'ایکیا', 'فرش', 'پرده', 'ساعت', 'آینه'];
    foreach ($dictionary as $word) {
        $lev = levenshtein($norm_query, $word);
        if ($lev > 0 && $lev <= 2 && mb_strlen($word, 'UTF-8') >= 3) {
            $did_you_mean = $word;
            break;
        }
    }

    $result = [
        'suggestions'    => $suggestions,
        'categories'     => $categories,
        'brands'         => $brands,
        'products'       => [],
        'total_products' => '',
        'did_you_mean'   => $did_you_mean,
    ];

    set_transient($cache_key, $result, 3 * MINUTE_IN_SECONDS);
    wp_send_json_success($result);
}

// افزودن کلاس بادی جهت تشخیص فعال بودن نوار چسبان خرید موبایل
add_filter('body_class', 'evazar_theme_body_classes');
function evazar_theme_body_classes($classes) {
    if (is_singular('evazar_product') && get_option('evazar_opt_sticky_mobile_buybox', '1') === '1') {
        $classes[] = 'has-sticky-buybox';
    }
    return $classes;
}

/**
 * دریافت آدرس دقیق و زنده برگه درباره ما
 */
function evazar_get_about_page_url() {
    $page_id = get_option('evazar_opt_about_page_id', 0);
    if ($page_id) {
        $url = get_permalink($page_id);
        if ($url) return $url;
    }
    $page = get_page_by_path('about') ?: get_page_by_path('about-us');
    if ($page) {
        return get_permalink($page);
    }
    return home_url('/about/');
}

/**
 * ساخت خودکار برگه «درباره ما» در فهرست برگه‌های وردپرس (Auto Create About Page)
 */
add_action('init', 'evazar_auto_create_about_page');
function evazar_auto_create_about_page() {
    if (get_option('evazar_about_page_created', '0') === '1') {
        return;
    }

    $existing_page = get_page_by_path('about');
    if (!$existing_page) {
        $existing_page = get_page_by_path('about-us');
    }

    if (!$existing_page) {
        $page_id = wp_insert_post([
            'post_title'   => 'درباره ما',
            'post_name'    => 'about',
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => '',
        ]);

        if ($page_id && !is_wp_error($page_id)) {
            update_post_meta($page_id, '_wp_page_template', 'template-about.php');
            update_option('evazar_opt_about_page_id', $page_id);
        }
    } else {
        update_post_meta($existing_page->ID, '_wp_page_template', 'template-about.php');
        update_option('evazar_opt_about_page_id', $existing_page->ID);
    }

    update_option('evazar_about_page_created', '1');
}

/**
 * هدایت خودکار آدرس /about یا /about-us به قالب اختصاصی درباره ما
 */
add_filter('template_include', 'evazar_about_template_redirect');
function evazar_about_template_redirect($template) {
    if (is_page('about') || is_page('about-us')) {
        $about_template = locate_template('template-about.php');
        if ($about_template) {
            return $about_template;
        }
    }
    return $template;
}

/**
 * ==========================================================================
 * ۱. استراکچردیتای رسمی محصول (Schema.org / Product & Offer JSON-LD)
 * ==========================================================================
 * ایجاد و تزریق استاندارد کدهای اسکیما جهت نمایش ستاره‌های امتیاز و قیمت در نتایج گوگل
 */
add_action('wp_head', 'evazar_output_product_schema_jsonld', 25);
function evazar_output_product_schema_jsonld() {
    if (!is_singular('evazar_product')) {
        return;
    }

    if (get_option('evazar_opt_schema_enable', '1') !== '1') {
        return;
    }

    $post_id = get_the_ID();
    $title = get_the_title($post_id);
    $permalink = get_permalink($post_id);

    // تصویر شاخص
    $img = get_post_meta($post_id, '_evazar_main_image', true) ?: get_the_post_thumbnail_url($post_id, 'full');
    if (function_exists('evazar_cdn_image_url') && $img) {
        $img = evazar_cdn_image_url($img);
    }

    // توضیحات سئو
    $desc = get_post_meta($post_id, 'rank_math_description', true) 
        ?: get_post_meta($post_id, '_evazar_short_desc', true) 
        ?: wp_strip_all_tags(get_the_excerpt($post_id));
    if (empty($desc)) {
        $desc = $title;
    }

    // برند و شناسه کالا
    $brand = get_post_meta($post_id, '_evazar_brand', true) ?: get_post_meta($post_id, '_evazar_brand_en', true) ?: 'عمومی';
    $sku = get_post_meta($post_id, '_sku', true) ?: get_post_meta($post_id, '_evazar_sku', true) ?: ('DKP-' . $post_id);

    // امتیاز و رضایت خریداران (تنها در صورت وجود نظر و امتیاز واقعی در دیجی‌کالا)
    $rating = floatval(get_post_meta($post_id, '_evazar_rating', true));
    $rating_count = intval(get_post_meta($post_id, '_evazar_rating_count', true));
    $satisfaction = intval(get_post_meta($post_id, '_evazar_satisfaction', true));

    $schema_mode = get_option('evazar_opt_schema_mode', 'full');

    $schema = [
        '@context' => 'https://schema.org/',
        '@type'    => 'Product',
        'name'     => $title,
        'image'    => $img ? [$img] : [],
        'description' => esc_html($desc),
        'sku'      => (string)$sku,
        'brand'    => [
            '@type' => 'Brand',
            'name'  => $brand
        ],
    ];

    if ($rating > 0 && $rating <= 5 && $rating_count > 0) {
        $schema['aggregateRating'] = [
            '@type'       => 'AggregateRating',
            'ratingValue' => number_format($rating, 1, '.', ''),
            'bestRating'  => '5',
            'worstRating' => '1',
            'ratingCount' => (string)$rating_count,
        ];
    }

    // در حالت کامل: افزودن Offers بر پایه استاندارد ISO-4217 گوگل (واحد IRR)
    if ($schema_mode === 'full') {
        $raw_price = get_post_meta($post_id, '_evazar_current_price', true);
        $clean_price = floatval(str_replace([',', ' ', '،'], '', function_exists('evazar_to_en_num') ? evazar_to_en_num((string)$raw_price) : (string)$raw_price));
        $is_avail = get_post_meta($post_id, '_evazar_is_available', true);
        if ($is_avail === '' || $is_avail === null) $is_avail = '1';

        $seller = get_post_meta($post_id, '_evazar_seller_name', true) ?: 'دیجی‌کالا';
        $aff_link = function_exists('evazar_get_final_affiliate_link') ? evazar_get_final_affiliate_link($post_id) : $permalink; // Schema باید مقصد نهایی را نگه دارد

        // تبدیل تومان به ریال جهت استاندارد رسمی گوگل
        $price_irr = $clean_price > 0 ? ($clean_price * 10) : 0;

        if ($price_irr > 0) {
            $schema['offers'] = [
                '@type'           => 'Offer',
                'priceCurrency'   => 'IRR',
                'price'           => (string)$price_irr,
                'priceValidUntil' => date('Y-12-31', strtotime('+1 year')),
                'itemCondition'   => 'https://schema.org/NewCondition',
                'availability'    => ($is_avail === '1') ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
                'url'             => $aff_link,
                'seller'          => [
                    '@type' => 'Organization',
                    'name'  => $seller
                ]
            ];
        }
    }

    echo "\n<!-- Evazar Structured Data (Schema.org JSON-LD) -->\n";
    echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "</script>\n";
}

/**
 * ==========================================================================
 * ۲. تابع کمکی نشان گرافیکی «کاهش قیمت» (Price Drop Badge Helper)
 * ==========================================================================
 */
function evazar_get_price_drop_info($post_id, $custom_hours = null) {
    if (get_option('evazar_opt_show_price_drop_badge', '1') !== '1') {
        return false;
    }

    $drop_time = intval(get_post_meta($post_id, '_evazar_price_drop_time', true));
    if (!$drop_time) {
        return false;
    }

    $max_hours = $custom_hours ? intval($custom_hours) : intval(get_option('evazar_opt_price_drop_hours', 48));
    if ($max_hours < 1) $max_hours = 48;

    // بررسی انقضای زمانی نشان
    if ((time() - $drop_time) > ($max_hours * 3600)) {
        return false;
    }

    $diff = intval(get_post_meta($post_id, '_evazar_price_drop_diff', true));
    if ($diff <= 0) {
        return false;
    }

    $badge_text = get_option('evazar_opt_price_drop_badge_text', '📉 افت قیمت امروز');

    return [
        'diff'           => $diff,
        'diff_formatted' => function_exists('evazar_format_price') ? evazar_format_price($diff) : number_format($diff),
        'time'           => $drop_time,
        'badge_text'     => $badge_text,
    ];
}

// تضمین فعال‌بودن پیش‌فرض بخش محصولات مشابه و پاکسازی باگ مقادیر قدیمی دیتابیس
if (get_option('evazar_opt_product_show_related_fix_v2') !== 'done') {
    update_option('evazar_opt_product_show_related', '1');
    update_option('evazar_opt_product_show_related_fix_v2', 'done');
}

/**
 * افزودن کلاس مخفی‌سازی تعداد کالاها به تگ بادی بر اساس تنظیم پوسته
 */
add_filter('body_class', 'evazar_term_count_body_class');
function evazar_term_count_body_class($classes) {
    if (get_option('evazar_opt_archive_show_count', '1') !== '1') {
        $classes[] = 'hide-term-counts';
    }
    return $classes;
}
