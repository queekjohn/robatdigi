<?php
/**
 * قالب تاکسونومی‌های ایوازار (هدایت به archive.php)
 */
require_once get_template_directory() . '/archive.php';
