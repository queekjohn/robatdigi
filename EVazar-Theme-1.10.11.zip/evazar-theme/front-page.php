<?php
/**
 * صفحه اصلی پوسته ایوازار (Front Page)
 */
$req_uri    = $_SERVER['REQUEST_URI'] ?? '';
$clean_path = trim(parse_url($req_uri, PHP_URL_PATH), '/');

if (
    isset($_GET['on_sale']) || isset($_GET['discount']) ||
    get_query_var('evazar_directory') === 'brand' ||
    get_query_var('evazar_directory') === 'category' ||
    preg_match('#(^|/)brands?/?$#i', $clean_path) ||
    preg_match('#(^|/)categories?/?$#i', $clean_path) ||
    preg_match('#(^|/)product-category/?$#i', $clean_path)
) {
    include get_template_directory() . '/archive.php';
    return;
}

get_header();

$hero_title           = get_option('evazar_opt_home_hero_title', 'راهنمای هوشمند انتخاب و خرید کالا');
$hero_subtitle        = get_option('evazar_opt_home_hero_subtitle', 'بررسی تخصصی، تحلیل قیمت‌های واقعی و دسترسی مستقیم به بهترین تخفیف‌های دیجی‌کالا');
$show_cats            = get_option('evazar_opt_home_show_categories', '1');
$show_brands          = get_option('evazar_opt_home_show_brands', '1');
$show_item_count      = get_option('evazar_opt_archive_show_count', '1');

// تنظیمات بخش شگفت‌انگیز
$show_deals           = get_option('evazar_opt_home_show_deals', '1');
$deals_title          = get_option('evazar_opt_home_deals_title', 'پیشنهاد شگفت‌انگیز');
$deals_count          = intval(get_option('evazar_opt_home_deals_count', 12));
$deals_min_discount   = intval(get_option('evazar_opt_home_deals_min_discount', 5));
$deals_hide_outofstock= get_option('evazar_opt_home_deals_hide_outofstock', '1');
$deals_link           = get_option('evazar_opt_home_deals_link', '/?on_sale=1');
if (empty($deals_link)) {
    $deals_link = home_url('/?on_sale=1');
} elseif (strpos($deals_link, 'http') !== 0) {
    $deals_link = home_url($deals_link);
}

// تنظیمات بخش چنددسته‌ای
$show_cat_showcase        = get_option('evazar_opt_home_show_cat_showcase', '1');
$cat_showcase_title       = get_option('evazar_opt_home_cat_showcase_title', 'منتخب کالاهای دسته‌بندی‌های برتر');
$cat_showcase_type        = get_option('evazar_opt_home_cat_showcase_type', 'tabs');
$cat_showcase_cats        = get_option('evazar_opt_home_cat_showcase_cats', []);
$cat_showcase_count       = intval(get_option('evazar_opt_home_cat_showcase_count', 8));
$cat_showcase_hide_oos    = get_option('evazar_opt_home_cat_showcase_hide_outofstock', '1');
$cat_showcase_orderby     = get_option('evazar_opt_home_cat_showcase_orderby', 'date');
$cat_showcase_inc_latest  = get_option('evazar_opt_home_cat_showcase_include_latest', '1');

// تنظیمات بخش مستقل جدیدترین کالاها
$show_latest              = get_option('evazar_opt_home_show_latest', '1');
$latest_title             = get_option('evazar_opt_home_latest_title', 'جدیدترین کالاها');
$latest_count             = intval(get_option('evazar_opt_home_latest_count', 12));
$latest_cat               = intval(get_option('evazar_opt_home_latest_cat', 0));
$latest_hide_oos          = get_option('evazar_opt_home_latest_hide_oos', '1');

// ترتیب چیدمان المان‌های صفحه اصلی
$sections_order           = get_option('evazar_opt_home_sections_order', ['hero', 'deals', 'categories', 'brands', 'cat_showcase', 'latest_products']);
if (!is_array($sections_order) || empty($sections_order)) {
    $sections_order = ['hero', 'deals', 'categories', 'brands', 'cat_showcase', 'latest_products'];
}
$master_sec_keys = ['hero', 'deals', 'categories', 'brands', 'cat_showcase', 'latest_products'];
foreach ($master_sec_keys as $mk) {
    if (!in_array($mk, $sections_order)) {
        $sections_order[] = $mk;
    }
}
?>

<div class="evazar-front-page">

<?php 
foreach ($sections_order as $sec_key):
    switch ($sec_key):
        
        // ۱. بنر هیرو و موتور جستجو
        case 'hero':
?>
    <!-- HERO SECTION -->
    <section class="home-hero-section">
        <div class="evazar-container">
            <div class="hero-inner-card">
                <span class="hero-tag">✨ بررسی تخصصی و معرفی بی‌طرفانه کالاها</span>
                <h1 class="hero-main-heading"><?php echo esc_html($hero_title); ?></h1>
                <div class="hero-main-sub"><?php echo evazar_render_readmore(esc_html($hero_subtitle), 'home', 180); ?></div>

                <div class="hero-search-wrapper">
                    <form method="get" action="<?php echo home_url('/'); ?>" class="hero-search-form">
                        <input type="text" name="s" placeholder="جستجوی کالا، نامک، هارد، ماگ یا برند دلخواه..." required>
                        <button type="submit" class="btn-hero-search">
                            <span>جستجو</span>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="18" height="18"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php 
            break;

        // ۲. بخش محصولات تخفیف شگفت‌انگیز
        case 'deals':
            if ($show_deals === '1'): 
                $deals_meta = [
                    'relation' => 'AND',
                    [
                        'key'     => '_evazar_discount_percent',
                        'value'   => max(1, $deals_min_discount),
                        'compare' => '>=',
                        'type'    => 'NUMERIC'
                    ],
                ];
                if ($deals_hide_outofstock === '1') {
                    $deals_meta[] = [
                        'key'     => '_evazar_is_available',
                        'value'   => '1',
                        'compare' => '=',
                    ];
                }
                $deals_query = new WP_Query([
                    'post_type'      => 'evazar_product',
                    'posts_per_page' => max(4, $deals_count),
                    'post_status'    => 'publish',
                    'meta_query'     => $deals_meta,
                    'meta_key'       => '_evazar_discount_percent',
                    'orderby'        => 'meta_value_num',
                    'order'          => 'DESC',
                ]);

                if ($deals_query->have_posts()):
?>
    <!-- INCREDIBLE DEALS SHOWCASE (بخش محصولات تخفیف شگفت‌انگیز اتوماتیک بدون تایمر) -->
    <section class="home-deals-section">
        <div class="evazar-container">
            <div class="deals-showcase-box">
                <!-- کارت لید معرفی شگفت‌انگیز (ثابت در دسکتاپ هنگام اسکرول) -->
                <div class="deal-lead-card">
                    <div class="deal-lead-top">
                        <div class="deal-lead-icon-box">
                            <svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                        </div>
                        <h2 class="deal-lead-title"><?php echo esc_html($deals_title); ?></h2>
                        <div class="deal-lead-auto-badge">
                            <svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor"><path d="M13 2.05v3.03c3.39.49 6 3.39 6 6.92 0 .9-.18 1.75-.48 2.54l2.6 1.53c.56-1.24.88-2.62.88-4.07 0-5.18-3.95-9.45-9-9.95zM12 19c-3.87 0-7-3.13-7-7 0-3.53 2.61-6.43 6-6.92V2.05c-5.05.5-9 4.76-9 9.95 0 5.52 4.47 10 9.99 10 3.31 0 6.24-1.61 8.01-4.09l-2.49-1.46C16.14 17.83 14.23 19 12 19z"/></svg>
                            <span>بروزرسانی خودکار</span>
                        </div>
                        <p class="deal-lead-desc">تخفیف‌های ویژه بر اساس قیمت روز</p>
                    </div>

                    <a href="<?php echo esc_url($deals_link); ?>" class="deal-lead-btn">
                        <span>مشاهده همه تخفیف‌ها</span>
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </a>
                </div>

                <!-- ریل اسکرول محصولات تخفیف‌دار -->
                <div class="deals-slider-wrapper">
                    <button type="button" class="deals-nav-btn deals-nav-prev" aria-label="قبلی" title="قبلی" style="display: none;">
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </button>

                    <div class="deals-slider-rail" id="homeDealsRail">
                        <?php while ($deals_query->have_posts()): $deals_query->the_post(); 
                            $d_id = get_the_ID();
                            $d_cur = get_post_meta($d_id, '_evazar_current_price', true);
                            $d_old = get_post_meta($d_id, '_evazar_old_price', true);
                            $d_disc = get_post_meta($d_id, '_evazar_discount_percent', true);
                            $d_brand = get_post_meta($d_id, '_evazar_brand', true);
                            $d_img = get_post_meta($d_id, '_evazar_main_image', true);
                            if (!$d_img) $d_img = get_the_post_thumbnail_url($d_id, 'medium');
                            if (function_exists('evazar_cdn_image_url') && strpos($d_img, 'data:image') === false) {
                                $d_img = evazar_cdn_image_url($d_img, 360);
                            }
                            $d_profit = (floatval($d_old) > floatval($d_cur)) ? (floatval($d_old) - floatval($d_cur)) : 0;
                        ?>
                        <a href="<?php the_permalink(); ?>" class="deal-product-card">
                            <div class="deal-card-top-wrap">
                                <div class="deal-card-thumb">
                                    <?php if ($d_disc && intval($d_disc) > 0): ?>
                                        <span class="deal-disc-pill">-<?php echo esc_html(evazar_to_fa_num($d_disc)); ?>٪</span>
                                    <?php endif; ?>
                                    <?php 
                                    if (get_option('evazar_opt_show_price_drop_badge', '1') === '1' && function_exists('evazar_get_price_drop_info')):
                                        $d_drop = evazar_get_price_drop_info($d_id, 48);
                                        if ($d_drop):
                                    ?>
                                        <span class="deal-drop-tag">🔻 افت قیمت</span>
                                    <?php endif; endif; ?>
                                    <?php if ($d_img): ?>
                                        <img src="<?php echo esc_url($d_img); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy" decoding="async" class="deal-thumb-img">
                                    <?php endif; ?>
                                </div>
                                <?php if (!empty($d_brand)): ?>
                                    <span class="deal-card-brand"><?php echo esc_html($d_brand); ?></span>
                                <?php endif; ?>
                                <h3 class="deal-card-title"><?php the_title(); ?></h3>
                            </div>
                            <div class="deal-card-pricing">
                                <?php if ($d_old && floatval($d_old) > floatval($d_cur)): ?>
                                <div class="deal-old-row">
                                    <span>قیمت قبل:</span>
                                    <span class="deal-old-price"><?php echo evazar_format_price($d_old); ?></span>
                                </div>
                                <?php endif; ?>
                                <div class="deal-cur-row">
                                    <span class="deal-cur-price"><?php echo evazar_format_price($d_cur); ?></span>
                                    <span class="deal-currency">تومان</span>
                                </div>
                                <?php if ($d_profit > 0): ?>
                                <div class="deal-profit-badge">
                                    سود شما: <?php echo evazar_format_price($d_profit); ?> تومان
                                </div>
                                <?php endif; ?>
                            </div>
                        </a>
                        <?php endwhile; wp_reset_postdata(); ?>

                        <!-- کارت پایانی مشاهده همه -->
                        <a href="<?php echo esc_url($deals_link); ?>" class="deal-card-more">
                            <div class="deal-more-icon-circle">
                                <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                            </div>
                            <span class="deal-more-text">مشاهده همه تخفیف‌ها ←</span>
                        </a>
                    </div>

                    <button type="button" class="deals-nav-btn deals-nav-next" aria-label="بعدی" title="بعدی" style="display: none;">
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
                    </button>
                </div>
            </div>
        </div>
    </section>
<?php 
                endif; 
            endif;
            break;

        // ۳. دسته‌بندی‌های برگزیده
        case 'categories':
            if ($show_cats === '1'): 
                $home_cats_title = get_option('evazar_opt_home_cats_title', 'دسته‌بندی‌های برگزیده') ?: 'دسته‌بندی‌های برگزیده';
                $home_cats_mode  = get_option('evazar_opt_home_cats_mode', 'auto');
                $home_cats_count = intval(get_option('evazar_opt_home_cats_count', 8));
                $home_cats_selected = get_option('evazar_opt_home_cats_selected', []);

                if ($home_cats_mode === 'custom' && !empty($home_cats_selected) && is_array($home_cats_selected)) {
                    $home_categories = get_terms([
                        'taxonomy'   => 'evazar_category',
                        'include'    => $home_cats_selected,
                        'orderby'    => 'include',
                        'hide_empty' => false,
                    ]);
                } else {
                    $home_categories = get_terms([
                        'taxonomy'   => 'evazar_category',
                        'number'     => max(3, $home_cats_count),
                        'hide_empty' => false,
                        'parent'     => 0,
                        'orderby'    => 'count',
                        'order'      => 'DESC',
                    ]);
                }
                if (!empty($home_categories) && !is_wp_error($home_categories)):
?>
    <!-- QUICK CATEGORIES BAR (دسته‌بندی‌های برگزیده) -->
    <section class="home-categories-section">
        <div class="evazar-container">
            <div class="section-header-row">
                <h2 class="section-title">
                    <svg class="section-icon" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M4 4h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 10h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4zM4 16h4v4H4zm6 0h4v4h-4zm6 0h4v4h-4z"/></svg>
                    <span><?php echo esc_html($home_cats_title); ?></span>
                </h2>
                <a href="<?php echo home_url('/product-category/'); ?>" class="view-all-link">مشاهده همه دسته‌ها ←</a>
            </div>
            <div class="home-cat-grid modern-cat-grid">
                <?php foreach ($home_categories as $cat): 
                    $c_icon = function_exists('evazar_get_category_icon') ? evazar_get_category_icon($cat->name) : '📁';
                ?>
                    <a href="<?php echo esc_url(get_term_link($cat)); ?>" class="cat-card modern-cat-card">
                        <div class="cat-icon-bubble">
                            <?php echo $c_icon; ?>
                        </div>
                        <span class="cat-name"><?php echo esc_html($cat->name); ?></span>
                        <?php if ($show_item_count === '1' && $cat->count > 0): ?>
                            <span class="cat-count-badge"><?php echo evazar_to_fa_num(number_format_i18n($cat->count)); ?> کالا</span>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
<?php 
                endif; 
            endif;
            break;

        // ۴. برندهای برتر و معتبر
        case 'brands':
            if ($show_brands === '1'): 
                $home_brands_title = get_option('evazar_opt_home_brands_title', 'برندهای برتر و معتبر') ?: 'برندهای برتر و معتبر';
                $home_brands_mode  = get_option('evazar_opt_home_brands_mode', 'auto');
                $home_brands_count = intval(get_option('evazar_opt_home_brands_count', 12));
                $home_brands_selected = get_option('evazar_opt_home_brands_selected', []);

                if ($home_brands_mode === 'custom' && !empty($home_brands_selected) && is_array($home_brands_selected)) {
                    $home_brands = get_terms([
                        'taxonomy'   => 'evazar_brand',
                        'include'    => $home_brands_selected,
                        'orderby'    => 'include',
                        'hide_empty' => false,
                    ]);
                } else {
                    $home_brands = get_terms([
                        'taxonomy'   => 'evazar_brand',
                        'number'     => max(4, $home_brands_count),
                        'hide_empty' => false,
                        'orderby'    => 'count',
                        'order'      => 'DESC',
                    ]);
                }
                if (!empty($home_brands) && !is_wp_error($home_brands)):
?>
    <!-- POPULAR BRANDS BAR (برندهای برتر و معتبر - هماهنگ با استایل دسته‌بندی‌ها) -->
    <section class="home-brands-section">
        <div class="evazar-container">
            <div class="section-header-row">
                <h2 class="section-title">
                    <svg class="section-icon" viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58.55 0 1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z"/></svg>
                    <span><?php echo esc_html($home_brands_title); ?></span>
                </h2>
                <a href="<?php echo home_url('/brand/'); ?>" class="view-all-link">مشاهده همه برندها ←</a>
            </div>
            
            <div class="home-brands-scroll-wrap">
                <button type="button" class="brands-scroll-btn brands-nav-prev" aria-label="برندهای قبلی" title="قبلی" style="display: none;">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                </button>
                <div class="home-brands-rail">
                    <?php foreach ($home_brands as $brand): 
                        $b_logo = get_term_meta($brand->term_id, '_evazar_brand_logo', true);
                        if (function_exists('evazar_cdn_image_url') && $b_logo && strpos($b_logo, 'data:image') === false) {
                            $b_logo = evazar_cdn_image_url($b_logo, 200);
                        }
                    ?>
                        <a href="<?php echo esc_url(get_term_link($brand)); ?>" class="brand-card modern-brand-card modern-cat-card">
                            <div class="cat-icon-bubble brand-icon-bubble">
                                <?php if ($b_logo): ?>
                                    <img src="<?php echo esc_url($b_logo); ?>" alt="<?php echo esc_attr($brand->name); ?>" loading="lazy" decoding="async" class="brand-avatar-img">
                                <?php else: ?>
                                    <span class="brand-avatar-initial"><?php echo esc_html(mb_substr($brand->name, 0, 1, 'UTF-8')); ?></span>
                                <?php endif; ?>
                            </div>
                            <span class="cat-name brand-name"><?php echo esc_html($brand->name); ?></span>
                            <?php if ($show_item_count === '1' && $brand->count > 0): ?>
                                <span class="cat-count-badge brand-count-badge"><?php echo evazar_to_fa_num(number_format_i18n($brand->count)); ?> کالا</span>
                            <?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="brands-scroll-btn brands-nav-next" aria-label="سایر برندها" title="بعدی" style="display: none;">
                    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
                </button>
            </div>
        </div>
    </section>
<?php 
                endif; 
            endif;
            break;

        // ۵. ویترین کالاهای چنددسته‌ای (تب‌دار یا قفسه‌ای)
        case 'cat_showcase':
            if ($show_cat_showcase === '1'): 
                if (!empty($cat_showcase_cats) && is_array($cat_showcase_cats)) {
                    $showcase_categories = get_terms([
                        'taxonomy'   => 'evazar_category',
                        'include'    => $cat_showcase_cats,
                        'orderby'    => 'include',
                        'hide_empty' => false,
                    ]);
                } else {
                    $showcase_categories = get_terms([
                        'taxonomy'   => 'evazar_category',
                        'parent'     => 0,
                        'hide_empty' => true,
                        'orderby'    => 'count',
                        'order'      => 'DESC',
                        'number'     => 4,
                    ]);
                }

                if (!empty($showcase_categories) && !is_wp_error($showcase_categories)):
                    $cat_order_args = ['orderby' => 'date', 'order' => 'DESC'];
                    if ($cat_showcase_orderby === 'rating') {
                        $cat_order_args = [
                            'meta_key' => '_evazar_rating',
                            'orderby'  => 'meta_value_num',
                            'order'    => 'DESC',
                        ];
                    } elseif ($cat_showcase_orderby === 'discount') {
                        $cat_order_args = [
                            'meta_key' => '_evazar_discount_percent',
                            'orderby'  => 'meta_value_num',
                            'order'    => 'DESC',
                        ];
                    }
                    $first_cat = $showcase_categories[0];
                    $first_cat_url = ($cat_showcase_inc_latest === '1') ? home_url('/?post_type=evazar_product') : get_term_link($first_cat);
                    $first_cat_label = ($cat_showcase_inc_latest === '1') ? 'کالاهای جدید' : $first_cat->name;
?>
    <?php if ($cat_showcase_type === 'tabs'): ?>
    <!-- حالت ۱: شوکیس تب‌دار هوشمند -->
    <section class="home-cat-tabs-section">
        <div class="evazar-container">
            <div class="cat-tabs-section">
                <!-- هدر بدون فاصله اضافی در بالا (رفع باگ فاصله غیراستاندارد) -->
                <div class="section-header-row" style="margin: 0 0 16px 0;">
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <svg class="section-icon" viewBox="0 0 24 24" width="22" height="22" fill="#0284c7"><path d="M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z"/></svg>
                        <h2 class="section-title" style="margin: 0;"><?php echo esc_html($cat_showcase_title); ?></h2>
                    </div>
                    <a href="<?php echo esc_url($first_cat_url); ?>" class="section-view-all-link view-all-link">
                        مشاهده همه <?php echo esc_html($first_cat_label); ?> ←
                    </a>
                </div>

                <!-- نوار تب‌های دسته‌بندی‌ها همراه با تب جدیدترین‌ها -->
                <div class="cat-tabs-nav-bar">
                    <?php if ($cat_showcase_inc_latest === '1'): ?>
                    <button type="button" class="cat-tab-btn is-active" data-tab="cat-tab-latest" data-url="<?php echo esc_url(home_url('/?post_type=evazar_product')); ?>">
                        <span>⚡</span>
                        <span class="cat-tab-name">جدیدترین‌ها</span>
                    </button>
                    <?php endif; ?>

                    <?php foreach ($showcase_categories as $idx => $sc_cat): 
                        $is_tab_active = ($cat_showcase_inc_latest !== '1' && $idx === 0);
                        $sc_url = get_term_link($sc_cat);
                        $sc_icon = function_exists('evazar_get_category_icon') ? evazar_get_category_icon($sc_cat->name) : '📁';
                    ?>
                    <button type="button" class="cat-tab-btn <?php echo $is_tab_active ? 'is-active' : ''; ?>" data-tab="cat-tab-<?php echo esc_attr($sc_cat->term_id); ?>" data-url="<?php echo esc_url($sc_url); ?>">
                        <span><?php echo $sc_icon; ?></span>
                        <span class="cat-tab-name"><?php echo esc_html($sc_cat->name); ?></span>
                        <?php if ($show_item_count === '1' && $sc_cat->count > 0): ?>
                            <span class="cat-tab-badge"><?php echo evazar_to_fa_num($sc_cat->count); ?></span>
                        <?php endif; ?>
                    </button>
                    <?php endforeach; ?>
                </div>

                <!-- پنل‌های محصولات هر تب -->
                <div class="cat-tabs-panels-wrap">
                    <?php if ($cat_showcase_inc_latest === '1'): 
                        $latest_tab_args = [
                            'post_type'      => 'evazar_product',
                            'posts_per_page' => max(4, $cat_showcase_count),
                            'post_status'    => 'publish',
                            'orderby'        => 'date',
                            'order'          => 'DESC',
                        ];
                        if ($cat_showcase_hide_oos === '1') {
                            $latest_tab_args['meta_query'] = [
                                [
                                    'key'     => '_evazar_is_available',
                                    'value'   => '1',
                                    'compare' => '=',
                                ]
                            ];
                        }
                        $latest_tab_query = new WP_Query($latest_tab_args);
                    ?>
                    <div class="cat-tab-panel is-active" id="cat-tab-latest">
                        <?php if ($latest_tab_query->have_posts()): ?>
                            <div class="cat-tab-slider-wrap">
                                <button type="button" class="deals-nav-btn cat-tab-nav-prev" aria-label="قبلی" title="قبلی" style="display: none;">
                                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                                </button>

                                <div class="cat-tab-slider-rail">
                                    <?php while ($latest_tab_query->have_posts()): $latest_tab_query->the_post(); 
                                        $p_id = get_the_ID();
                                        $p_cur = get_post_meta($p_id, '_evazar_current_price', true);
                                        $p_old = get_post_meta($p_id, '_evazar_old_price', true);
                                        $p_disc = get_post_meta($p_id, '_evazar_discount_percent', true);
                                        $p_brand = get_post_meta($p_id, '_evazar_brand', true);
                                        $p_img = get_post_meta($p_id, '_evazar_main_image', true);
                                        if (!$p_img) $p_img = get_the_post_thumbnail_url($p_id, 'medium');
                                        if (function_exists('evazar_cdn_image_url') && strpos($p_img, 'data:image') === false) {
                                            $p_img = evazar_cdn_image_url($p_img, 360);
                                        }
                                        $p_affiliate = function_exists('evazar_get_affiliate_redirect_url') ? evazar_get_affiliate_redirect_url($p_id) : (function_exists('evazar_get_final_affiliate_link') ? evazar_get_final_affiliate_link($p_id) : get_permalink($p_id));
                                    ?>
                                    <article class="cat-tab-product-card">
                                        <div class="card-thumb-wrap">
                                            <?php 
                                            $clean_disc = function_exists('evazar_get_clean_discount_badge') 
                                                ? evazar_get_clean_discount_badge($p_disc, $p_old, $p_cur) 
                                                : '';
                                            if (!empty($clean_disc)): 
                                            ?>
                                                <span class="card-badge-discount"><?php echo esc_html($clean_disc); ?></span>
                                            <?php endif; ?>
                                            <a href="<?php the_permalink(); ?>">
                                                <img src="<?php echo esc_url($p_img); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy" decoding="async" class="card-product-img">
                                            </a>
                                        </div>
                                        <div class="card-body">
                                            <?php if ($p_brand): ?>
                                                <span class="card-brand"><?php echo esc_html($p_brand); ?></span>
                                            <?php endif; ?>
                                            <h3 class="card-title">
                                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                            </h3>
                                            <div class="card-pricing">
                                                <?php if ($p_old && floatval($p_old) > floatval($p_cur)): ?>
                                                    <span class="card-old-price"><?php echo evazar_format_price($p_old); ?></span>
                                                <?php else: ?>
                                                    <span class="card-old-price-placeholder">&nbsp;</span>
                                                <?php endif; ?>
                                                <div class="card-cur-price">
                                                    <strong><?php echo evazar_format_price($p_cur); ?></strong>
                                                    <span class="currency">تومان</span>
                                                </div>
                                            </div>
                                        </div>
                                    </article>
                                    <?php endwhile; wp_reset_postdata(); ?>

                                    <!-- کارت پایانی مشاهده همه -->
                                    <a href="<?php echo esc_url(home_url('/?post_type=evazar_product')); ?>" class="cat-tab-more-card">
                                        <div class="cat-more-icon-circle">
                                            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                                        </div>
                                        <span class="cat-more-text">مشاهده همه کالاهای جدید ←</span>
                                    </a>
                                </div>

                                <button type="button" class="deals-nav-btn cat-tab-nav-next" aria-label="بعدی" title="بعدی" style="display: none;">
                                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
                                </button>
                            </div>
                        <?php else: ?>
                            <p style="text-align: center; color: #94a3b8; padding: 24px;">کالایی یافت نشد.</p>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <?php foreach ($showcase_categories as $idx => $sc_cat): 
                        $is_panel_active = ($cat_showcase_inc_latest !== '1' && $idx === 0);
                        $sc_query_args = array_merge([
                            'post_type'      => 'evazar_product',
                            'posts_per_page' => max(4, $cat_showcase_count),
                            'post_status'    => 'publish',
                            'tax_query'      => [
                                [
                                    'taxonomy'         => 'evazar_category',
                                    'field'            => 'term_id',
                                    'terms'            => $sc_cat->term_id,
                                    'include_children' => true,
                                ]
                            ]
                        ], $cat_order_args);

                        if ($cat_showcase_hide_oos === '1') {
                            $sc_query_args['meta_query'] = [
                                [
                                    'key'     => '_evazar_is_available',
                                    'value'   => '1',
                                    'compare' => '=',
                                ]
                            ];
                        }

                        $sc_prod_query = new WP_Query($sc_query_args);
                    ?>
                    <div class="cat-tab-panel <?php echo $is_panel_active ? 'is-active' : ''; ?>" id="cat-tab-<?php echo esc_attr($sc_cat->term_id); ?>">
                        <?php if ($sc_prod_query->have_posts()): ?>
                            <div class="cat-tab-slider-wrap">
                                <button type="button" class="deals-nav-btn cat-tab-nav-prev" aria-label="قبلی" title="قبلی" style="display: none;">
                                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                                </button>

                                <div class="cat-tab-slider-rail">
                                    <?php while ($sc_prod_query->have_posts()): $sc_prod_query->the_post(); 
                                        $p_id = get_the_ID();
                                        $p_cur = get_post_meta($p_id, '_evazar_current_price', true);
                                        $p_old = get_post_meta($p_id, '_evazar_old_price', true);
                                        $p_disc = get_post_meta($p_id, '_evazar_discount_percent', true);
                                        $p_brand = get_post_meta($p_id, '_evazar_brand', true);
                                        $p_img = get_post_meta($p_id, '_evazar_main_image', true);
                                        if (!$p_img) $p_img = get_the_post_thumbnail_url($p_id, 'medium');
                                        if (function_exists('evazar_cdn_image_url') && strpos($p_img, 'data:image') === false) {
                                            $p_img = evazar_cdn_image_url($p_img, 360);
                                        }
                                        $p_affiliate = function_exists('evazar_get_affiliate_redirect_url') ? evazar_get_affiliate_redirect_url($p_id) : (function_exists('evazar_get_final_affiliate_link') ? evazar_get_final_affiliate_link($p_id) : get_permalink($p_id));
                                    ?>
                                    <article class="cat-tab-product-card">
                                        <div class="card-thumb-wrap">
                                            <?php 
                                            $clean_disc = function_exists('evazar_get_clean_discount_badge') 
                                                ? evazar_get_clean_discount_badge($p_disc, $p_old, $p_cur) 
                                                : '';
                                            if (!empty($clean_disc)): 
                                            ?>
                                                <span class="card-badge-discount"><?php echo esc_html($clean_disc); ?></span>
                                            <?php endif; ?>
                                            <a href="<?php the_permalink(); ?>">
                                                <img src="<?php echo esc_url($p_img); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy" decoding="async" class="card-product-img">
                                            </a>
                                        </div>
                                        <div class="card-body">
                                            <?php if ($p_brand): ?>
                                                <span class="card-brand"><?php echo esc_html($p_brand); ?></span>
                                            <?php endif; ?>
                                            <h3 class="card-title">
                                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                            </h3>
                                            <div class="card-pricing">
                                                <?php if ($p_old && floatval($p_old) > floatval($p_cur)): ?>
                                                    <span class="card-old-price"><?php echo evazar_format_price($p_old); ?></span>
                                                <?php else: ?>
                                                    <span class="card-old-price-placeholder">&nbsp;</span>
                                                <?php endif; ?>
                                                <div class="card-cur-price">
                                                    <strong><?php echo evazar_format_price($p_cur); ?></strong>
                                                    <span class="currency">تومان</span>
                                                </div>
                                            </div>
                                        </div>
                                    </article>
                                    <?php endwhile; wp_reset_postdata(); ?>

                                    <!-- کارت پایانی مشاهده همه -->
                                    <a href="<?php echo esc_url(get_term_link($sc_cat)); ?>" class="cat-tab-more-card">
                                        <div class="cat-more-icon-circle">
                                            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                                        </div>
                                        <span class="cat-more-text">مشاهده همه کالاهای <?php echo esc_html($sc_cat->name); ?> ←</span>
                                    </a>
                                </div>

                                <button type="button" class="deals-nav-btn cat-tab-nav-next" aria-label="بعدی" title="بعدی" style="display: none;">
                                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
                                </button>
                            </div>
                        <?php else: ?>
                            <p style="text-align: center; color: #94a3b8; padding: 24px;">کالایی در این دسته‌بندی یافت نشد.</p>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

    <?php else: ?>
    <!-- حالت ۲: قفسه‌های مستقل موضوعی (Shelves) -->
    <?php 
    if ($cat_showcase_inc_latest === '1'): 
        $latest_shelf_args = [
            'post_type'      => 'evazar_product',
            'posts_per_page' => max(4, $cat_showcase_count),
            'post_status'    => 'publish',
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];
        if ($cat_showcase_hide_oos === '1') {
            $latest_shelf_args['meta_query'] = [
                [
                    'key'     => '_evazar_is_available',
                    'value'   => '1',
                    'compare' => '=',
                ]
            ];
        }
        $latest_shelf_query = new WP_Query($latest_shelf_args);
        if ($latest_shelf_query->have_posts()):
    ?>
    <section class="home-category-shelf-section">
        <div class="evazar-container">
            <div class="shelf-card-box">
                <div class="section-header-row" style="margin: 0 0 16px 0;">
                    <h2 class="section-title">
                        <svg class="section-icon" viewBox="0 0 24 24" width="20" height="20" fill="#0284c7"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                        <span>جدیدترین کالاها</span>
                    </h2>
                    <a href="<?php echo home_url('/?post_type=evazar_product'); ?>" class="view-all-link">مشاهده همه کالاهای جدید ←</a>
                </div>

            <div class="shelf-slider-wrap">
                <button type="button" class="deals-nav-btn shelf-nav-prev" aria-label="قبلی" title="قبلی" style="display: none;">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                </button>

                <div class="shelf-slider-rail">
                    <?php while ($latest_shelf_query->have_posts()): $latest_shelf_query->the_post(); 
                        $p_id = get_the_ID();
                        $p_cur = get_post_meta($p_id, '_evazar_current_price', true);
                        $p_old = get_post_meta($p_id, '_evazar_old_price', true);
                        $p_disc = get_post_meta($p_id, '_evazar_discount_percent', true);
                        $p_img = get_post_meta($p_id, '_evazar_main_image', true);
                        if (!$p_img) $p_img = get_the_post_thumbnail_url($p_id, 'medium');
                        if (function_exists('evazar_cdn_image_url') && strpos($p_img, 'data:image') === false) {
                            $p_img = evazar_cdn_image_url($p_img, 360);
                        }
                        $p_affiliate = function_exists('evazar_get_affiliate_redirect_url') ? evazar_get_affiliate_redirect_url($p_id) : (function_exists('evazar_get_final_affiliate_link') ? evazar_get_final_affiliate_link($p_id) : get_permalink($p_id));
                    ?>
                        <article class="archive-product-card">
                            <div class="card-thumb-wrap">
                                <?php 
                                $clean_disc = function_exists('evazar_get_clean_discount_badge') 
                                    ? evazar_get_clean_discount_badge($p_disc, $p_old, $p_cur) 
                                    : '';
                                if (!empty($clean_disc)): 
                                ?>
                                    <span class="card-badge-discount"><?php echo esc_html($clean_disc); ?></span>
                                <?php endif; ?>
                                <a href="<?php the_permalink(); ?>">
                                    <img src="<?php echo esc_url($p_img); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy" decoding="async" class="card-product-img">
                                </a>
                            </div>
                            <div class="card-body">
                                <h3 class="card-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h3>
                                <div class="card-pricing">
                                    <?php if ($p_old && floatval($p_old) > floatval($p_cur)): ?>
                                        <span class="card-old-price"><?php echo evazar_format_price($p_old); ?></span>
                                    <?php else: ?>
                                        <span class="card-old-price-placeholder">&nbsp;</span>
                                    <?php endif; ?>
                                    <div class="card-cur-price">
                                        <strong><?php echo evazar_format_price($p_cur); ?></strong>
                                        <span class="currency">تومان</span>
                                    </div>
                                </div>
                            </div>
                        </article>
                    <?php endwhile; wp_reset_postdata(); ?>
                </div>

                <button type="button" class="deals-nav-btn shelf-nav-next" aria-label="بعدی" title="بعدی" style="display: none;">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
                </button>
            </div>
            </div>
        </div>
    </section>
    <?php endif; endif; ?>

    <?php foreach ($showcase_categories as $sc_cat): 
        $sc_query_args = array_merge([
            'post_type'      => 'evazar_product',
            'posts_per_page' => max(4, $cat_showcase_count),
            'post_status'    => 'publish',
            'tax_query'      => [
                [
                    'taxonomy'         => 'evazar_category',
                    'field'            => 'term_id',
                    'terms'            => $sc_cat->term_id,
                    'include_children' => true,
                ]
            ]
        ], $cat_order_args);

        if ($cat_showcase_hide_oos === '1') {
            $sc_query_args['meta_query'] = [
                [
                    'key'     => '_evazar_is_available',
                    'value'   => '1',
                    'compare' => '=',
                ]
            ];
        }

        $sc_prod_query = new WP_Query($sc_query_args);
        if ($sc_prod_query->have_posts()):
            $sc_url = get_term_link($sc_cat);
    ?>
    <section class="home-category-shelf-section">
        <div class="evazar-container">
            <div class="shelf-card-box">
                <div class="section-header-row" style="margin: 0 0 16px 0;">
                    <h2 class="section-title">
                        <svg class="section-icon" viewBox="0 0 24 24" width="20" height="20" fill="#0284c7"><path d="M4 6h16v2H4zm0 5h16v2H4zm0 5h16v2H4z"/></svg>
                        <span><?php echo esc_html($sc_cat->name); ?></span>
                    </h2>
                    <a href="<?php echo esc_url($sc_url); ?>" class="view-all-link">مشاهده همه کالاهای این دسته ←</a>
                </div>

            <div class="shelf-slider-wrap">
                <button type="button" class="deals-nav-btn shelf-nav-prev" aria-label="قبلی" title="قبلی" style="display: none;">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                </button>

                <div class="shelf-slider-rail">
                    <?php while ($sc_prod_query->have_posts()): $sc_prod_query->the_post(); 
                        $p_id = get_the_ID();
                        $p_cur = get_post_meta($p_id, '_evazar_current_price', true);
                        $p_old = get_post_meta($p_id, '_evazar_old_price', true);
                        $p_disc = get_post_meta($p_id, '_evazar_discount_percent', true);
                        $p_img = get_post_meta($p_id, '_evazar_main_image', true);
                        if (!$p_img) $p_img = get_the_post_thumbnail_url($p_id, 'medium');
                        if (function_exists('evazar_cdn_image_url') && strpos($p_img, 'data:image') === false) {
                            $p_img = evazar_cdn_image_url($p_img, 360);
                        }
                        $p_affiliate = function_exists('evazar_get_affiliate_redirect_url') ? evazar_get_affiliate_redirect_url($p_id) : (function_exists('evazar_get_final_affiliate_link') ? evazar_get_final_affiliate_link($p_id) : get_permalink($p_id));
                    ?>
                        <article class="archive-product-card">
                            <div class="card-thumb-wrap">
                                <?php 
                                $clean_disc = function_exists('evazar_get_clean_discount_badge') 
                                    ? evazar_get_clean_discount_badge($p_disc, $p_old, $p_cur) 
                                    : '';
                                if (!empty($clean_disc)): 
                                ?>
                                    <span class="card-badge-discount"><?php echo esc_html($clean_disc); ?></span>
                                <?php endif; ?>
                                <a href="<?php the_permalink(); ?>">
                                    <img src="<?php echo esc_url($p_img); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy" decoding="async" class="card-product-img">
                                </a>
                            </div>
                            <div class="card-body">
                                <h3 class="card-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h3>
                                <div class="card-pricing">
                                    <?php if ($p_old && floatval($p_old) > floatval($p_cur)): ?>
                                        <span class="card-old-price"><?php echo evazar_format_price($p_old); ?></span>
                                    <?php else: ?>
                                        <span class="card-old-price-placeholder">&nbsp;</span>
                                    <?php endif; ?>
                                    <div class="card-cur-price">
                                        <strong><?php echo evazar_format_price($p_cur); ?></strong>
                                        <span class="currency">تومان</span>
                                    </div>
                                </div>
                            </div>
                        </article>
                    <?php endwhile; wp_reset_postdata(); ?>
                </div>

                <button type="button" class="deals-nav-btn shelf-nav-next" aria-label="بعدی" title="بعدی" style="display: none;">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
                </button>
            </div>
            </div>
        </div>
    </section>
    <?php endif; endforeach; ?>
    <?php endif; ?>
<?php 
                endif; 
            endif;
            break;

        // ۶. بخش مستقل جدیدترین کالاها (یا دسته انتخابی)
        case 'latest_products':
            if ($show_latest === '1'): 
                $lat_query_args = [
                    'post_type'      => 'evazar_product',
                    'posts_per_page' => max(4, $latest_count),
                    'post_status'    => 'publish',
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                ];

                if (!empty($latest_cat) && $latest_cat > 0) {
                    $lat_query_args['tax_query'] = [
                        [
                            'taxonomy'         => 'evazar_category',
                            'field'            => 'term_id',
                            'terms'            => $latest_cat,
                            'include_children' => true,
                        ]
                    ];
                    $latest_shelf_view_url = get_term_link($latest_cat, 'evazar_category');
                } else {
                    $latest_shelf_view_url = home_url('/?post_type=evazar_product');
                }

                if ($latest_hide_oos === '1') {
                    $lat_query_args['meta_query'] = [
                        [
                            'key'     => '_evazar_is_available',
                            'value'   => '1',
                            'compare' => '=',
                        ]
                    ];
                }

                $lat_query = new WP_Query($lat_query_args);
                if ($lat_query->have_posts()):
?>
    <!-- LATEST PRODUCTS SECTION (بخش جدیدترین کالاها) -->
    <section class="home-latest-products-section">
        <div class="evazar-container">
            <div class="shelf-card-box home-latest-products-box">
                <div class="section-header-row" style="margin: 0 0 16px 0;">
                    <h2 class="section-title">
                        <svg class="section-icon" viewBox="0 0 24 24" width="22" height="22" fill="#10b981"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                        <span><?php echo esc_html($latest_title); ?></span>
                    </h2>
                    <a href="<?php echo esc_url($latest_shelf_view_url); ?>" class="view-all-link">مشاهده همه کالاهای جدید ←</a>
                </div>

            <div class="shelf-slider-wrap">
                <button type="button" class="deals-nav-btn shelf-nav-prev" aria-label="قبلی" title="قبلی" style="display: none;">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                </button>

                <div class="shelf-slider-rail">
                    <?php while ($lat_query->have_posts()): $lat_query->the_post(); 
                        $p_id = get_the_ID();
                        $p_cur = get_post_meta($p_id, '_evazar_current_price', true);
                        $p_old = get_post_meta($p_id, '_evazar_old_price', true);
                        $p_disc = get_post_meta($p_id, '_evazar_discount_percent', true);
                        $p_img = get_post_meta($p_id, '_evazar_main_image', true);
                        if (!$p_img) $p_img = get_the_post_thumbnail_url($p_id, 'medium');
                        if (function_exists('evazar_cdn_image_url') && strpos($p_img, 'data:image') === false) {
                            $p_img = evazar_cdn_image_url($p_img, 360);
                        }
                        $p_affiliate = function_exists('evazar_get_affiliate_redirect_url') ? evazar_get_affiliate_redirect_url($p_id) : (function_exists('evazar_get_final_affiliate_link') ? evazar_get_final_affiliate_link($p_id) : get_permalink($p_id));
                    ?>
                        <article class="archive-product-card">
                            <div class="card-thumb-wrap">
                                <?php 
                                $clean_disc = function_exists('evazar_get_clean_discount_badge') 
                                    ? evazar_get_clean_discount_badge($p_disc, $p_old, $p_cur) 
                                    : '';
                                if (!empty($clean_disc)): 
                                ?>
                                    <span class="card-badge-discount"><?php echo esc_html($clean_disc); ?></span>
                                <?php endif; ?>
                                <a href="<?php the_permalink(); ?>">
                                    <img src="<?php echo esc_url($p_img); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy" decoding="async" class="card-product-img">
                                </a>
                            </div>
                            <div class="card-body">
                                <h3 class="card-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h3>
                                <div class="card-pricing">
                                    <?php if ($p_old && floatval($p_old) > floatval($p_cur)): ?>
                                        <span class="card-old-price"><?php echo evazar_format_price($p_old); ?></span>
                                    <?php else: ?>
                                        <span class="card-old-price-placeholder">&nbsp;</span>
                                    <?php endif; ?>
                                    <div class="card-cur-price">
                                        <strong><?php echo evazar_format_price($p_cur); ?></strong>
                                        <span class="currency">تومان</span>
                                    </div>
                                </div>
                            </div>
                        </article>
                    <?php endwhile; wp_reset_postdata(); ?>
                </div>

                <button type="button" class="deals-nav-btn shelf-nav-next" aria-label="بعدی" title="بعدی" style="display: none;">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
                </button>
            </div>
            </div>
        </div>
    </section>
<?php 
                endif; 
            endif;
            break;

    endswitch;
endforeach;
?>

</div>

<?php get_footer(); ?>
