# EVazar Theme 1.10.9

- Reduced excessive white space visible inside many source product images on archive cards by applying a CSS-only `scale(1.08)` to `.archive-product-card .card-product-img`.
- Archive hover scale adjusted to `1.12` so hover no longer visually shrinks the image relative to the base scale.
- No image files are stored or regenerated; the existing `img.evazar.ir`, 360×360 CDN URL strategy, Cloudflare cache, and lazy/eager loading behavior remain unchanged.
- No changes to EVazar Core or Cloudflare Worker.
