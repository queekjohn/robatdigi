# EVazar Theme 1.10.10

- Restored archive product-card image markup to the stable 1.10.6 behavior: lazy loading without `fetchpriority`, intrinsic width/height attributes, or eager promotion.
- Removed the 1.10.9 CSS scale workaround because it did not correct the source-image framing.
- Kept the 1.10.7 accessibility/heading improvements and other unrelated performance work intact.
