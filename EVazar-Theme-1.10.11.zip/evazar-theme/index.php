<?php
/**
 * قالب پیش‌فرض صفحه اصلی و عمومی ایوازار
 */
require_once get_template_directory() . '/archive.php';
