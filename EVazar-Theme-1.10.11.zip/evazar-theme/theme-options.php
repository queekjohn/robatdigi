<?php
/**
 * پنل تنظیمات پیشرفته و بومی پوسته ایوازار (Evazar Theme Options)
 * بدون هیچ وابستگی خارجی، بسیار سریع، سبک و سازگار ۱۰۰٪ با وردپرس
 */

if (!defined('ABSPATH')) exit;

// افزودن منو به بخش نمایش پیشخوان وردپرس
add_action('admin_menu', 'evazar_theme_register_options_menu');
function evazar_theme_register_options_menu() {
    add_theme_page(
        'تنظیمات قالب ایوازار',
        'تنظیمات قالب ایوازار',
        'manage_options',
        'evazar-theme-options',
        'evazar_theme_render_options_page'
    );
}

// بارگذاری اسکریپت‌های انتخاب رسانه و کالرپیکر در صفحه تنظیمات
add_action('admin_enqueue_scripts', 'evazar_theme_options_admin_assets');
function evazar_theme_options_admin_assets($hook) {
    if (strpos($hook, 'evazar-theme-options') !== false) {
        wp_enqueue_media();
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
    }
}

// رندر صفحه تنظیمات
function evazar_theme_render_options_page() {
    // پردازش ذخیره فرم
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['evazar_save_theme_options'])) {
        check_admin_referer('evazar_theme_options_nonce');

        $options = [
            // ۱. هویت بصری و رنگ‌بندی
            'evazar_opt_logo_type'               => sanitize_text_field($_POST['evazar_opt_logo_type'] ?? 'text'),
            'evazar_opt_logo_image'              => esc_url_raw($_POST['evazar_opt_logo_image'] ?? ''),
            'evazar_opt_logo_text'               => sanitize_text_field($_POST['evazar_opt_logo_text'] ?? 'ایــــوازار'),
            'evazar_opt_logo_letter'             => sanitize_text_field($_POST['evazar_opt_logo_letter'] ?? 'E'),
            'evazar_opt_logo_tagline'            => sanitize_text_field($_POST['evazar_opt_logo_tagline'] ?? 'راهنمای هوشمند انتخاب و خرید کالا'),
            'evazar_opt_favicon'                 => esc_url_raw($_POST['evazar_opt_favicon'] ?? ''),
            'evazar_opt_font'                    => sanitize_text_field($_POST['evazar_opt_font'] ?? 'vazirmatn'),
            'evazar_opt_primary_color'           => sanitize_hex_color($_POST['evazar_opt_primary_color'] ?? '#ef394e'),
            'evazar_opt_secondary_color'         => sanitize_hex_color($_POST['evazar_opt_secondary_color'] ?? '#0284c7'),
            // صفحه انتقال افیلیت (کنترل کامل از پنل قالب)
            'evazar_affiliate_redirect_countdown_enabled' => isset($_POST['evazar_affiliate_redirect_countdown_enabled']) ? '1' : '0',
            'evazar_affiliate_redirect_delay'             => max(1, min(5, intval($_POST['evazar_affiliate_redirect_delay'] ?? 2))),
            'evazar_affiliate_redirect_title'             => sanitize_text_field($_POST['evazar_affiliate_redirect_title'] ?? 'در حال انتقال به دیجی‌کالا'),
            'evazar_affiliate_redirect_description'       => sanitize_text_field($_POST['evazar_affiliate_redirect_description'] ?? 'لینک خرید شما آماده است؛ تا چند لحظه دیگر به سایت فروشنده منتقل می‌شوید.'),
            'evazar_affiliate_redirect_button'            => sanitize_text_field($_POST['evazar_affiliate_redirect_button'] ?? 'انتقال فوری'),

            // ۲. تنظیمات هدر و ناوبری
            'evazar_opt_show_top_notice'         => isset($_POST['evazar_opt_show_top_notice']) ? '1' : '0',
            'evazar_opt_top_notice'              => sanitize_text_field($_POST['evazar_opt_top_notice'] ?? ''),
            'evazar_opt_top_notice_bg'           => sanitize_hex_color($_POST['evazar_opt_top_notice_bg'] ?? '#0f172a'),
            'evazar_opt_top_notice_color'        => sanitize_hex_color($_POST['evazar_opt_top_notice_color'] ?? '#ffffff'),
            'evazar_opt_header_sticky'           => isset($_POST['evazar_opt_header_sticky']) ? '1' : '0',
            'evazar_opt_header_show_search'      => isset($_POST['evazar_opt_header_show_search']) ? '1' : '0',
            'evazar_opt_header_search_placeholder'=> sanitize_text_field($_POST['evazar_opt_header_search_placeholder'] ?? 'جستجوی کالا، برند یا دسته‌بندی...'),
            'evazar_opt_show_partner_badge'      => isset($_POST['evazar_opt_show_partner_badge']) ? '1' : '0',
            'evazar_opt_partner_badge_text'      => sanitize_text_field($_POST['evazar_opt_partner_badge_text'] ?? 'پارتنر رسمی دیجی‌کالا'),
            'evazar_opt_header_show_quick_links' => isset($_POST['evazar_opt_header_show_quick_links']) ? '1' : '0',

            // ۳. برگه تکی محصول
            'evazar_opt_product_zoom'            => isset($_POST['evazar_opt_product_zoom']) ? '1' : '0',
            'evazar_opt_product_lightbox'        => isset($_POST['evazar_opt_product_lightbox']) ? '1' : '0',
            'evazar_opt_product_show_discount'   => isset($_POST['evazar_opt_product_show_discount']) ? '1' : '0',
            'evazar_opt_product_show_ratings'    => isset($_POST['evazar_opt_product_show_ratings']) ? '1' : '0',
            'evazar_opt_product_show_sku'        => isset($_POST['evazar_opt_product_show_sku']) ? '1' : '0',
            'evazar_opt_product_show_features'   => isset($_POST['evazar_opt_product_show_features']) ? '1' : '0',
            'evazar_opt_single_features_limit'   => max(1, intval($_POST['evazar_opt_single_features_limit'] ?? 5)),
            'evazar_opt_product_show_ai'         => isset($_POST['evazar_opt_product_show_ai']) ? '1' : '0',
            'evazar_opt_product_seller_name'     => sanitize_text_field($_POST['evazar_opt_product_seller_name'] ?? 'دیجی‌کالا'),
            'evazar_opt_product_show_seller'     => isset($_POST['evazar_opt_product_show_seller']) ? '1' : '0',
            'evazar_opt_buybox_guarantee_header' => sanitize_text_field($_POST['evazar_opt_buybox_guarantee_header'] ?? 'قیمت و موجودی به‌روز از دیجی‌کالا'),
            'evazar_opt_buybox_feature_1'        => sanitize_text_field($_POST['evazar_opt_buybox_feature_1'] ?? 'قیمت و وضعیت موجودی به‌صورت آنلاین بررسی می‌شود'),
            'evazar_opt_buybox_feature_2'        => sanitize_text_field($_POST['evazar_opt_buybox_feature_2'] ?? 'برای خرید به سایت فروشنده منتقل می‌شوید'),
            'evazar_opt_buybox_feature_3'        => sanitize_text_field($_POST['evazar_opt_buybox_feature_3'] ?? 'پرداخت، ارسال و مرجوعی توسط فروشنده انجام می‌شود'),
            'evazar_opt_product_trust_badge_1' => sanitize_text_field($_POST['evazar_opt_product_trust_badge_1'] ?? 'اطلاعات قیمت و موجودی به‌روز'),
            'evazar_opt_product_trust_badge_2' => sanitize_text_field($_POST['evazar_opt_product_trust_badge_2'] ?? 'خرید در سایت فروشنده'),
            'evazar_opt_product_trust_badge_3' => sanitize_text_field($_POST['evazar_opt_product_trust_badge_3'] ?? 'ارسال و مرجوعی طبق شرایط فروشنده'),
            'evazar_opt_buybox_price_label'      => sanitize_text_field($_POST['evazar_opt_buybox_price_label'] ?? 'قیمت رسمی در دیجی‌کالا:'),
            'evazar_opt_product_btn_title'       => sanitize_text_field($_POST['evazar_opt_product_btn_title'] ?? 'مشاهده قیمت و خرید در دیجی‌کالا'),
            'evazar_opt_product_btn_subtitle'    => sanitize_text_field($_POST['evazar_opt_product_btn_subtitle'] ?? 'برای مشاهده و خرید به سایت دیجی‌کالا منتقل می‌شوید'),
            'evazar_opt_product_guarantee_text'  => sanitize_text_field($_POST['evazar_opt_product_guarantee_text'] ?? 'ایوازار فروشنده کالا نیست؛ برای خرید به سایت فروشنده منتقل می‌شوید و پرداخت و ارسال در همان سایت انجام می‌شود.'),
            'evazar_opt_product_show_related'    => isset($_POST['evazar_opt_product_show_related']) ? '1' : '0',
            'evazar_opt_product_related_count'   => max(1, min(50, intval($_POST['evazar_opt_product_related_count'] ?? 4))),
            'evazar_opt_related_hide_outofstock' => isset($_POST['evazar_opt_related_hide_outofstock']) ? '1' : '0',
            'evazar_opt_schema_enable'           => isset($_POST['evazar_opt_schema_enable']) ? '1' : '0',
            'evazar_opt_schema_mode'             => sanitize_text_field($_POST['evazar_opt_schema_mode'] ?? 'full'),
            'evazar_opt_show_price_drop_badge'   => isset($_POST['evazar_opt_show_price_drop_badge']) ? '1' : '0',
            'evazar_opt_price_drop_badge_text'   => sanitize_text_field($_POST['evazar_opt_price_drop_badge_text'] ?? '📉 افت قیمت امروز'),
            'evazar_opt_price_drop_hours'        => intval($_POST['evazar_opt_price_drop_hours'] ?? 48),

            // ۴. صفحه برندها و دسته‌بندی‌ها (آرشیو)
            'evazar_opt_archive_posts_per_page'  => intval($_POST['evazar_opt_archive_posts_per_page'] ?? 16),
            'evazar_opt_archive_desktop_cols'    => sanitize_text_field($_POST['evazar_opt_archive_desktop_cols'] ?? '4'),
            'evazar_opt_filter_sections_order' => sanitize_text_field($_POST['evazar_opt_filter_sections_order'] ?? 'category,brand,stock,price'),
            'evazar_opt_archive_mobile_cols'     => sanitize_text_field($_POST['evazar_opt_archive_mobile_cols'] ?? '2'),
            'evazar_opt_archive_show_hero'       => isset($_POST['evazar_opt_archive_show_hero']) ? '1' : '0',
            'evazar_opt_archive_show_count'      => isset($_POST['evazar_opt_archive_show_count']) ? '1' : '0',
            'evazar_opt_archive_show_desc'       => isset($_POST['evazar_opt_archive_show_desc']) ? '1' : '0',
            'evazar_opt_archive_show_discount'   => isset($_POST['evazar_opt_archive_show_discount']) ? '1' : '0',
            'evazar_opt_archive_show_rating'     => isset($_POST['evazar_opt_archive_show_rating']) ? '1' : '0',
            'evazar_opt_archive_show_buy_btn'    => isset($_POST['evazar_opt_archive_show_buy_btn']) ? '1' : '0',
            'evazar_opt_special_offers_title'    => sanitize_text_field($_POST['evazar_opt_special_offers_title'] ?? 'تخفیف‌های ویژه و شگفت‌انگیز'),
            'evazar_opt_special_offers_desc'     => wp_kses_post($_POST['evazar_opt_special_offers_desc'] ?? ''),
            'evazar_opt_brands_page_title'            => sanitize_text_field($_POST['evazar_opt_brands_page_title'] ?? 'برندهای کالا'),
            'evazar_opt_brands_page_desc'             => wp_kses_post($_POST['evazar_opt_brands_page_desc'] ?? ''),
            'evazar_opt_brand_meta_title_template'    => sanitize_text_field($_POST['evazar_opt_brand_meta_title_template'] ?? 'خرید و قیمت روز انواع محصولات {brand} | {site_name}'),
            'evazar_opt_brand_meta_desc_template'     => sanitize_textarea_field($_POST['evazar_opt_brand_meta_desc_template'] ?? 'مشاهده لیست قیمت روز و مشخصات فنی انواع {brand} در {site_name} و بررسی گزینه‌های خرید از فروشندگان معتبر.'),
            'evazar_opt_categories_page_title'        => sanitize_text_field($_POST['evazar_opt_categories_page_title'] ?? 'دسته‌بندی‌های کالا'),
            'evazar_opt_categories_page_desc'         => wp_kses_post($_POST['evazar_opt_categories_page_desc'] ?? ''),
            'evazar_opt_category_meta_title_template' => sanitize_text_field($_POST['evazar_opt_category_meta_title_template'] ?? 'خرید و قیمت روز انواع {category} | {site_name}'),
            'evazar_opt_category_meta_desc_template'  => sanitize_textarea_field($_POST['evazar_opt_category_meta_desc_template'] ?? 'مشاهده لیست قیمت روز و مشخصات فنی انواع {category} در {site_name} و بررسی گزینه‌های خرید از فروشندگان معتبر.'),

            // ۵. صفحه اصلی
            'evazar_opt_home_hero_title'         => sanitize_text_field($_POST['evazar_opt_home_hero_title'] ?? ''),
            'evazar_opt_home_hero_subtitle'      => sanitize_textarea_field($_POST['evazar_opt_home_hero_subtitle'] ?? ''),
            'evazar_opt_home_product_count'      => intval($_POST['evazar_opt_home_product_count'] ?? 16),
            'evazar_opt_home_hide_outofstock'    => isset($_POST['evazar_opt_home_hide_outofstock']) ? '1' : '0',
            'evazar_opt_home_sections_order'     => isset($_POST['evazar_opt_home_sections_order']) && is_array($_POST['evazar_opt_home_sections_order']) ? array_map('sanitize_key', $_POST['evazar_opt_home_sections_order']) : ['hero', 'deals', 'categories', 'brands', 'cat_showcase', 'latest_products'],
            'evazar_opt_home_show_latest'        => isset($_POST['evazar_opt_home_show_latest']) ? '1' : '0',
            'evazar_opt_home_latest_title'       => sanitize_text_field($_POST['evazar_opt_home_latest_title'] ?? 'جدیدترین کالاها'),
            'evazar_opt_home_latest_count'       => intval($_POST['evazar_opt_home_latest_count'] ?? 12),
            'evazar_opt_home_latest_cat'         => intval($_POST['evazar_opt_home_latest_cat'] ?? 0),
            'evazar_opt_home_latest_hide_oos'    => isset($_POST['evazar_opt_home_latest_hide_oos']) ? '1' : '0',
            'evazar_opt_home_cat_showcase_include_latest' => isset($_POST['evazar_opt_home_cat_showcase_include_latest']) ? '1' : '0',
            'evazar_opt_home_show_categories'    => isset($_POST['evazar_opt_home_show_categories']) ? '1' : '0',
            'evazar_opt_home_cats_title'         => sanitize_text_field($_POST['evazar_opt_home_cats_title'] ?? 'دسته‌بندی‌های برگزیده'),
            'evazar_opt_home_cats_mode'          => sanitize_text_field($_POST['evazar_opt_home_cats_mode'] ?? 'auto'),
            'evazar_opt_home_cats_count'         => intval($_POST['evazar_opt_home_cats_count'] ?? 8),
            'evazar_opt_home_cats_selected'      => isset($_POST['evazar_opt_home_cats_selected']) && is_array($_POST['evazar_opt_home_cats_selected']) ? array_map('intval', $_POST['evazar_opt_home_cats_selected']) : [],
            
            // ۵-الف: بخش محصولات تخفیف شگفت‌انگیز (Deals Showcase)
            'evazar_opt_home_show_deals'            => isset($_POST['evazar_opt_home_show_deals']) ? '1' : '0',
            'evazar_opt_home_deals_title'           => sanitize_text_field($_POST['evazar_opt_home_deals_title'] ?? 'پیشنهاد شگفت‌انگیز'),
            'evazar_opt_home_deals_count'           => intval($_POST['evazar_opt_home_deals_count'] ?? 12),
            'evazar_opt_home_deals_min_discount'    => intval($_POST['evazar_opt_home_deals_min_discount'] ?? 5),
            'evazar_opt_home_deals_hide_outofstock' => isset($_POST['evazar_opt_home_deals_hide_outofstock']) ? '1' : '0',
            'evazar_opt_home_deals_link'            => sanitize_text_field($_POST['evazar_opt_home_deals_link'] ?? '/?on_sale=1'),
            
            // ۵-ب: بخش لیست محصولات دسته‌بندی‌های مختلف (Multi-Category Showcase)
            'evazar_opt_home_show_cat_showcase'     => isset($_POST['evazar_opt_home_show_cat_showcase']) ? '1' : '0',
            'evazar_opt_home_cat_showcase_title'    => sanitize_text_field($_POST['evazar_opt_home_cat_showcase_title'] ?? 'منتخب کالاهای دسته‌بندی‌های برتر'),
            'evazar_opt_home_cat_showcase_type'     => sanitize_text_field($_POST['evazar_opt_home_cat_showcase_type'] ?? 'tabs'),
            'evazar_opt_home_cat_showcase_cats'     => isset($_POST['evazar_opt_home_cat_showcase_cats']) && is_array($_POST['evazar_opt_home_cat_showcase_cats']) ? array_map('intval', $_POST['evazar_opt_home_cat_showcase_cats']) : [],
            'evazar_opt_home_cat_showcase_count'    => intval($_POST['evazar_opt_home_cat_showcase_count'] ?? 8),
            'evazar_opt_home_cat_showcase_hide_outofstock' => isset($_POST['evazar_opt_home_cat_showcase_hide_outofstock']) ? '1' : '0',
            'evazar_opt_home_cat_showcase_orderby'  => sanitize_text_field($_POST['evazar_opt_home_cat_showcase_orderby'] ?? 'date'),

            'evazar_opt_home_show_brands'        => isset($_POST['evazar_opt_home_show_brands']) ? '1' : '0',
            'evazar_opt_home_brands_title'       => sanitize_text_field($_POST['evazar_opt_home_brands_title'] ?? 'برندهای برتر و معتبر'),
            'evazar_opt_home_brands_mode'        => sanitize_text_field($_POST['evazar_opt_home_brands_mode'] ?? 'auto'),
            'evazar_opt_home_brands_count'       => intval($_POST['evazar_opt_home_brands_count'] ?? 12),
            'evazar_opt_home_brands_selected'    => isset($_POST['evazar_opt_home_brands_selected']) && is_array($_POST['evazar_opt_home_brands_selected']) ? array_map('intval', $_POST['evazar_opt_home_brands_selected']) : [],
            'evazar_opt_home_show_trust_bar'     => isset($_POST['evazar_opt_home_show_trust_bar']) ? '1' : '0',

            // ۶. مدیریت فوتر و نوار مزایا (Trust Bar)
            'evazar_opt_footer_show_trust_bar'   => isset($_POST['evazar_opt_footer_show_trust_bar']) ? '1' : '0',
            'evazar_opt_trust_bar_mobile'        => isset($_POST['evazar_opt_trust_bar_mobile']) ? '1' : '0',
            'evazar_opt_trust_bar_style'         => sanitize_text_field($_POST['evazar_opt_trust_bar_style'] ?? 'line'),
            'evazar_opt_trust_item_1_title'      => sanitize_text_field($_POST['evazar_opt_trust_item_1_title'] ?? 'قیمت و موجودی به‌روز'),
            'evazar_opt_trust_item_1_sub'        => sanitize_text_field($_POST['evazar_opt_trust_item_1_sub'] ?? 'به‌روزرسانی خودکار از داده‌های دیجی‌کالا'),
            'evazar_opt_trust_item_1_icon'       => sanitize_text_field($_POST['evazar_opt_trust_item_1_icon'] ?? 'shield'),
            'evazar_opt_trust_item_1_link'       => esc_url_raw($_POST['evazar_opt_trust_item_1_link'] ?? ''),
            'evazar_opt_trust_item_2_title'      => sanitize_text_field($_POST['evazar_opt_trust_item_2_title'] ?? 'بهترین قیمت روز'),
            'evazar_opt_trust_item_2_sub'        => sanitize_text_field($_POST['evazar_opt_trust_item_2_sub'] ?? 'بروزرسانی لحظه‌ای تخفیف‌ها'),
            'evazar_opt_trust_item_2_icon'       => sanitize_text_field($_POST['evazar_opt_trust_item_2_icon'] ?? 'zap'),
            'evazar_opt_trust_item_2_link'       => esc_url_raw($_POST['evazar_opt_trust_item_2_link'] ?? ''),
            'evazar_opt_trust_item_3_title'      => sanitize_text_field($_POST['evazar_opt_trust_item_3_title'] ?? 'بررسی با هوش مصنوعی'),
            'evazar_opt_trust_item_3_sub'        => sanitize_text_field($_POST['evazar_opt_trust_item_3_sub'] ?? 'تحلیل شفاف نقاط قوت و ضعف'),
            'evazar_opt_trust_item_3_icon'       => sanitize_text_field($_POST['evazar_opt_trust_item_3_icon'] ?? 'ai'),
            'evazar_opt_trust_item_3_link'       => esc_url_raw($_POST['evazar_opt_trust_item_3_link'] ?? ''),
            'evazar_opt_trust_item_4_title'      => sanitize_text_field($_POST['evazar_opt_trust_item_4_title'] ?? 'خرید در سایت فروشنده'),
            'evazar_opt_trust_item_4_sub'        => sanitize_text_field($_POST['evazar_opt_trust_item_4_sub'] ?? 'پرداخت، ارسال و مرجوعی در سایت فروشنده انجام می‌شود'),
            'evazar_opt_trust_item_4_icon'       => sanitize_text_field($_POST['evazar_opt_trust_item_4_icon'] ?? 'lock'),
            'evazar_opt_trust_item_4_link'       => esc_url_raw($_POST['evazar_opt_trust_item_4_link'] ?? ''),
            'evazar_opt_footer_about_title'      => sanitize_text_field($_POST['evazar_opt_footer_about_title'] ?? 'درباره ایوازار'),
            'evazar_opt_footer_about_text'       => sanitize_textarea_field($_POST['evazar_opt_footer_about_text'] ?? ''),
            'evazar_opt_footer_trust_title'      => sanitize_text_field($_POST['evazar_opt_footer_trust_title'] ?? 'ایوازار فروشنده کالا نیست'),
            'evazar_opt_footer_trust_text'       => sanitize_textarea_field($_POST['evazar_opt_footer_trust_text'] ?? ''),
            'evazar_opt_footer_phone'            => sanitize_text_field($_POST['evazar_opt_footer_phone'] ?? ''),
            'evazar_opt_footer_email'            => sanitize_email($_POST['evazar_opt_footer_email'] ?? ''),
            'evazar_opt_footer_address'          => sanitize_text_field($_POST['evazar_opt_footer_address'] ?? ''),
            'evazar_opt_footer_show_cats'        => isset($_POST['evazar_opt_footer_show_cats']) ? '1' : '0',
            'evazar_opt_footer_cats_count'       => intval($_POST['evazar_opt_footer_cats_count'] ?? 6),
            'evazar_opt_footer_show_brands'      => isset($_POST['evazar_opt_footer_show_brands']) ? '1' : '0',
            'evazar_opt_footer_brands_count'     => intval($_POST['evazar_opt_footer_brands_count'] ?? 6),
            'evazar_opt_footer_copyright'        => sanitize_text_field($_POST['evazar_opt_footer_copyright'] ?? ''),
            'evazar_opt_footer_back_to_top'      => isset($_POST['evazar_opt_footer_back_to_top']) ? '1' : '0',

            // ۷. بهینه‌سازی موبایل
            'evazar_opt_sticky_mobile_buybox'    => isset($_POST['evazar_opt_sticky_mobile_buybox']) ? '1' : '0',
            'evazar_opt_mobile_search_visible'   => isset($_POST['evazar_opt_mobile_search_visible']) ? '1' : '0',
            'evazar_opt_mobile_header_compact'   => isset($_POST['evazar_opt_mobile_header_compact']) ? '1' : '0',

            // ۸. سیستم مشاهده بیشتر و محوشدگی متون (Read More System)
            'evazar_opt_enable_readmore'          => isset($_POST['evazar_opt_enable_readmore']) ? '1' : '0',
            'evazar_opt_readmore_desktop_height' => intval($_POST['evazar_opt_readmore_desktop_height'] ?? 280),
            'evazar_opt_readmore_mobile_height'  => intval($_POST['evazar_opt_readmore_mobile_height'] ?? 200),
            'evazar_opt_readmore_char_threshold' => intval($_POST['evazar_opt_readmore_char_threshold'] ?? 220),
            'evazar_opt_readmore_product'        => isset($_POST['evazar_opt_readmore_product']) ? '1' : '0',
            'evazar_opt_readmore_archive'        => isset($_POST['evazar_opt_readmore_archive']) ? '1' : '0',
            'evazar_opt_readmore_home'           => isset($_POST['evazar_opt_readmore_home']) ? '1' : '0',
            'evazar_opt_readmore_footer'         => isset($_POST['evazar_opt_readmore_footer']) ? '1' : '0',

            // ۹. امکانات هوشمند، CDN و کدها
            'evazar_opt_image_cdn_domain'        => esc_url_raw(trim($_POST['evazar_opt_image_cdn_domain'] ?? 'https://img.evazar.ir')),
            'evazar_opt_custom_css'              => wp_strip_all_tags($_POST['evazar_opt_custom_css'] ?? ''),
            'evazar_opt_header_scripts'          => $_POST['evazar_opt_header_scripts'] ?? '',
            'evazar_opt_footer_scripts'          => $_POST['evazar_opt_footer_scripts'] ?? '',
            // ۱۰. برگه درباره ما (About Us)
            'evazar_opt_about_hero_badge'        => sanitize_text_field($_POST['evazar_opt_about_hero_badge'] ?? 'سامانه تخصصی همکاری در فروش و هدایت هوشمند خرید'),
            'evazar_opt_about_hero_title'        => sanitize_text_field($_POST['evazar_opt_about_hero_title'] ?? 'انتخابی دقیق‌تر، خریدی مطمئن‌تر و بدون واسطه از دیجی‌کالا'),
            'evazar_opt_about_hero_desc'         => sanitize_textarea_field($_POST['evazar_opt_about_hero_desc'] ?? ''),
            'evazar_opt_about_stat1_num'         => sanitize_text_field($_POST['evazar_opt_about_stat1_num'] ?? '+۵۰,۰۰۰'),
            'evazar_opt_about_stat1_txt'         => sanitize_text_field($_POST['evazar_opt_about_stat1_txt'] ?? 'کالای پایش‌شده و ارزیابی‌شده'),
            'evazar_opt_about_stat2_num'         => sanitize_text_field($_POST['evazar_opt_about_stat2_num'] ?? '۰ تومان'),
            'evazar_opt_about_stat2_txt'         => sanitize_text_field($_POST['evazar_opt_about_stat2_txt'] ?? 'کارمزد یا هزینه اضافه برای خریدار'),
            'evazar_opt_about_stat3_num'         => sanitize_text_field($_POST['evazar_opt_about_stat3_num'] ?? '۲۴/۷'),
            'evazar_opt_about_stat3_txt'         => sanitize_text_field($_POST['evazar_opt_about_stat3_txt'] ?? 'رصد لحظه‌ای تخفیف‌های واقعی'),
            'evazar_opt_about_stat4_num'         => sanitize_text_field($_POST['evazar_opt_about_stat4_num'] ?? '۱۰۰٪'),
            'evazar_opt_about_stat4_txt'         => sanitize_text_field($_POST['evazar_opt_about_stat4_txt'] ?? 'پرداخت مستقیم در درگاه شاپرک دیجی‌کالا'),
            'evazar_opt_about_disclosure_title'  => sanitize_text_field($_POST['evazar_opt_about_disclosure_title'] ?? 'بیانیه شفافیت در همکاری در فروش (Affiliate Disclosure)'),
            'evazar_opt_about_disclosure_text'   => sanitize_textarea_field($_POST['evazar_opt_about_disclosure_text'] ?? ''),
            'evazar_opt_about_faq_enable'        => isset($_POST['evazar_opt_about_faq_enable']) ? '1' : '0',
            'evazar_opt_about_faq_title'         => sanitize_text_field($_POST['evazar_opt_about_faq_title'] ?? 'پرسش‌های متداول درباره ایوازار و نحوه خرید'),
            'evazar_opt_about_faq_items'         => sanitize_textarea_field($_POST['evazar_opt_about_faq_items'] ?? ''),
            'evazar_opt_about_cta_title'         => sanitize_text_field($_POST['evazar_opt_about_cta_title'] ?? 'خریدی هوشمندانه‌تر را از همین امروز تجربه کنید'),
            'evazar_opt_about_cta_desc'          => sanitize_textarea_field($_POST['evazar_opt_about_cta_desc'] ?? ''),
            'evazar_opt_about_cta_btn'           => sanitize_text_field($_POST['evazar_opt_about_cta_btn'] ?? 'ورود به کاتالوگ کالاهای منتخب'),
            'evazar_opt_about_cta_link'          => esc_url_raw($_POST['evazar_opt_about_cta_link'] ?? ''),

            // ۱۱. برگه خطای ۴۰۴
            'evazar_opt_404_tab_title'           => sanitize_text_field($_POST['evazar_opt_404_tab_title'] ?? 'صفحه مورد نظر یافت نشد (خطای ۴۰۴)'),
            'evazar_opt_404_title'               => sanitize_text_field($_POST['evazar_opt_404_title'] ?? 'صفحه‌ای که دنبالش بودید پیدا نشد!'),
            'evazar_opt_404_subtitle'            => sanitize_text_field($_POST['evazar_opt_404_subtitle'] ?? 'ممکن است آدرس را اشتباه تایپ کرده باشید یا این کالا دیگر در فروشگاه موجود نباشد.'),
        ];

        foreach ($options as $key => $val) {
            update_option($key, $val);
        }

        // همگام‌سازی تنظیم CDN با افزونه evazar-core در صورت وجود
        if (!empty($options['evazar_opt_image_cdn_domain'])) {
            update_option('evazar_image_cdn_domain', $options['evazar_opt_image_cdn_domain']);
        }

        echo '<div class="notice notice-success is-dismissible" style="margin-top: 15px;"><p><strong>تنظیمات قالب ایوازار با موفقیت ذخیره شد.</strong></p></div>';
    }

    // تشخیص تب فعال فعلی جهت ثبات ۱۰۰٪ در همان بخش پس از ذخیره‌سازی
    $active_tab = isset($_POST['evazar_active_tab']) ? sanitize_text_field($_POST['evazar_active_tab']) : '#tab-branding';
    if (empty($active_tab) || strpos($active_tab, '#') !== 0) {
        $active_tab = '#tab-branding';
    }

    // خواندن مقادیر فعلی
    $logo_type               = get_option('evazar_opt_logo_type', 'text');
    $logo_image              = get_option('evazar_opt_logo_image', '');
    $logo_text               = get_option('evazar_opt_logo_text', 'ایــــوازار');
    $logo_letter             = get_option('evazar_opt_logo_letter', 'E');
    $logo_tagline            = get_option('evazar_opt_logo_tagline', 'راهنمای هوشمند انتخاب و خرید کالا');
    $favicon                 = get_option('evazar_opt_favicon', '');
    $font                    = get_option('evazar_opt_font', 'vazirmatn');
    $primary_color           = get_option('evazar_opt_primary_color', '#ef394e');
    $secondary_color         = get_option('evazar_opt_secondary_color', '#0284c7');
    $affiliate_redirect_countdown_enabled = get_option('evazar_affiliate_redirect_countdown_enabled', '1');
    $affiliate_redirect_delay   = max(1, min(5, intval(get_option('evazar_affiliate_redirect_delay', 2))));
    $affiliate_redirect_title   = get_option('evazar_affiliate_redirect_title', 'در حال انتقال به دیجی‌کالا');
    $affiliate_redirect_description = get_option('evazar_affiliate_redirect_description', 'لینک خرید شما آماده است؛ تا چند لحظه دیگر به سایت فروشنده منتقل می‌شوید.');
    $affiliate_redirect_button  = get_option('evazar_affiliate_redirect_button', 'انتقال فوری');

    $show_top_notice         = get_option('evazar_opt_show_top_notice', '1');
    $top_notice              = get_option('evazar_opt_top_notice', '✨ ایوازار (evazar.ir) | سیستم هوشمند معرفی و بررسی تخصصی کالاهای دیجی‌کالا');
    $top_notice_bg           = get_option('evazar_opt_top_notice_bg', '#0f172a');
    $top_notice_color        = get_option('evazar_opt_top_notice_color', '#ffffff');
    $header_sticky           = get_option('evazar_opt_header_sticky', '1');
    $header_show_search      = get_option('evazar_opt_header_show_search', '1');
    $header_search_placeholder= get_option('evazar_opt_header_search_placeholder', 'جستجوی کالا، برند یا دسته‌بندی...');
    $show_partner_badge      = get_option('evazar_opt_show_partner_badge', '1');
    $partner_badge_text      = get_option('evazar_opt_partner_badge_text', 'پارتنر رسمی دیجی‌کالا');
    $header_quick_links      = get_option('evazar_opt_header_show_quick_links', '1');

    $product_zoom            = get_option('evazar_opt_product_zoom', '1');
    $product_lightbox        = get_option('evazar_opt_product_lightbox', '1');
    $product_show_discount   = get_option('evazar_opt_product_show_discount', '1');
    $product_show_ratings    = get_option('evazar_opt_product_show_ratings', '1');
    $product_show_sku        = get_option('evazar_opt_product_show_sku', '1');
    $product_show_features   = get_option('evazar_opt_product_show_features', '1');
    $single_features_limit   = intval(get_option('evazar_opt_single_features_limit', 5));
    $product_show_ai         = get_option('evazar_opt_product_show_ai', '1');
    $product_seller_name     = get_option('evazar_opt_product_seller_name', 'دیجی‌کالا');
    $product_show_seller     = get_option('evazar_opt_product_show_seller', '1');
    $buybox_guarantee_header = get_option('evazar_opt_buybox_guarantee_header', 'قیمت و موجودی به‌روز از دیجی‌کالا');
    $buybox_feature_1        = get_option('evazar_opt_buybox_feature_1', 'قیمت و وضعیت موجودی به‌صورت آنلاین بررسی می‌شود');
    $buybox_feature_2        = get_option('evazar_opt_buybox_feature_2', 'برای خرید به سایت فروشنده منتقل می‌شوید');
    $buybox_feature_3        = get_option('evazar_opt_buybox_feature_3', 'پرداخت، ارسال و مرجوعی توسط فروشنده انجام می‌شود');
    $product_trust_badge_1   = get_option('evazar_opt_product_trust_badge_1', 'اطلاعات قیمت و موجودی به‌روز');
    $product_trust_badge_2   = get_option('evazar_opt_product_trust_badge_2', 'خرید در سایت فروشنده');
    $product_trust_badge_3   = get_option('evazar_opt_product_trust_badge_3', 'ارسال و مرجوعی طبق شرایط فروشنده');
    $buybox_price_label      = get_option('evazar_opt_buybox_price_label', 'قیمت رسمی در دیجی‌کالا:');
    $product_btn_title       = get_option('evazar_opt_product_btn_title', 'مشاهده قیمت و خرید در دیجی‌کالا');
    $product_btn_subtitle    = get_option('evazar_opt_product_btn_subtitle', 'برای ادامه خرید به سایت دیجی‌کالا منتقل می‌شوید');
    $product_guarantee_text  = get_option('evazar_opt_product_guarantee_text', 'ایوازار فروشنده کالا نیست؛ برای خرید به سایت فروشنده منتقل می‌شوید و پرداخت و ارسال در همان سایت انجام می‌شود.');
    $product_show_related    = get_option('evazar_opt_product_show_related', '1');
    $product_related_count   = get_option('evazar_opt_product_related_count', 4);
    $related_hide_outofstock = get_option('evazar_opt_related_hide_outofstock', '1');
    $schema_enable           = get_option('evazar_opt_schema_enable', '1');
    $schema_mode             = get_option('evazar_opt_schema_mode', 'full');
    $show_price_drop_badge   = get_option('evazar_opt_show_price_drop_badge', '1');
    $price_drop_badge_text   = get_option('evazar_opt_price_drop_badge_text', '📉 افت قیمت امروز');
    $price_drop_hours        = intval(get_option('evazar_opt_price_drop_hours', 48));

    $archive_posts_per_page  = get_option('evazar_opt_archive_posts_per_page', 16);
    $archive_desktop_cols    = get_option('evazar_opt_archive_desktop_cols', '4');
    $filter_sections_order   = get_option('evazar_opt_filter_sections_order', 'category,brand,stock,price');
    $archive_mobile_cols     = get_option('evazar_opt_archive_mobile_cols', '2');
    $archive_show_hero       = get_option('evazar_opt_archive_show_hero', '1');
    $archive_show_count      = get_option('evazar_opt_archive_show_count', '1');
    $archive_show_desc       = get_option('evazar_opt_archive_show_desc', '1');
    $archive_show_discount   = get_option('evazar_opt_archive_show_discount', '1');
    $archive_show_rating     = get_option('evazar_opt_archive_show_rating', '1');
    $archive_show_buy_btn    = get_option('evazar_opt_archive_show_buy_btn', '1');
    $special_offers_title    = get_option('evazar_opt_special_offers_title', 'تخفیف‌های ویژه و شگفت‌انگیز');
    $special_offers_desc     = get_option('evazar_opt_special_offers_desc', 'مجموعه جدیدترین کالاهای دارای تخفیف ویژه و کاهش قیمت واقعی در دیجی‌کالا. بررسی مشخصات و خرید آنلاین با بیشترین درصد سود خریدار.');
    $brands_page_title       = get_option('evazar_opt_brands_page_title', 'برندهای کالا');
    $brands_page_desc        = get_option('evazar_opt_brands_page_desc', '');
    $brand_meta_title_tpl    = get_option('evazar_opt_brand_meta_title_template', 'خرید و قیمت روز انواع محصولات {brand} | {site_name}');
    $brand_meta_desc_tpl     = get_option('evazar_opt_brand_meta_desc_template', 'مشاهده لیست قیمت روز و مشخصات فنی انواع {brand} در {site_name} و بررسی گزینه‌های خرید از فروشندگان معتبر.');
    $categories_page_title   = get_option('evazar_opt_categories_page_title', 'دسته‌بندی‌های کالا');
    $categories_page_desc    = get_option('evazar_opt_categories_page_desc', '');
    $category_meta_title_tpl = get_option('evazar_opt_category_meta_title_template', 'خرید و قیمت روز انواع {category} | {site_name}');
    $category_meta_desc_tpl  = get_option('evazar_opt_category_meta_desc_template', 'مشاهده لیست قیمت روز و مشخصات فنی انواع {category} در {site_name} و بررسی گزینه‌های خرید از فروشندگان معتبر.');

    $home_hero_title         = get_option('evazar_opt_home_hero_title', 'راهنمای هوشمند انتخاب و خرید کالا');
    $home_hero_subtitle      = get_option('evazar_opt_home_hero_subtitle', 'بررسی تخصصی، تحلیل قیمت‌های واقعی و دسترسی مستقیم به بهترین تخفیف‌های دیجی‌کالا');
    $home_product_count      = get_option('evazar_opt_home_product_count', 16);
    $home_hide_outofstock    = get_option('evazar_opt_home_hide_outofstock', '1');
    $home_sections_order     = get_option('evazar_opt_home_sections_order', ['hero', 'deals', 'categories', 'brands', 'cat_showcase', 'latest_products']);
    if (!is_array($home_sections_order) || empty($home_sections_order)) {
        $home_sections_order = ['hero', 'deals', 'categories', 'brands', 'cat_showcase', 'latest_products'];
    }
    $master_sec_keys = ['hero', 'deals', 'categories', 'brands', 'cat_showcase', 'latest_products'];
    foreach ($master_sec_keys as $mk) {
        if (!in_array($mk, $home_sections_order)) {
            $home_sections_order[] = $mk;
        }
    }
    $home_show_latest        = get_option('evazar_opt_home_show_latest', '1');
    $home_latest_title       = get_option('evazar_opt_home_latest_title', 'جدیدترین کالاها');
    $home_latest_count       = get_option('evazar_opt_home_latest_count', 12);
    $home_latest_cat         = get_option('evazar_opt_home_latest_cat', 0);
    $home_latest_hide_oos    = get_option('evazar_opt_home_latest_hide_oos', '1');
    $home_cat_showcase_include_latest = get_option('evazar_opt_home_cat_showcase_include_latest', '1');
    $home_show_cats          = get_option('evazar_opt_home_show_categories', '1');
    $home_cats_title         = get_option('evazar_opt_home_cats_title', 'دسته‌بندی‌های برگزیده');
    $home_cats_mode          = get_option('evazar_opt_home_cats_mode', 'auto');
    $home_cats_count         = get_option('evazar_opt_home_cats_count', 8);
    $home_cats_selected      = get_option('evazar_opt_home_cats_selected', []);

    // تنظیمات بخش شگفت‌انگیز
    $home_show_deals            = get_option('evazar_opt_home_show_deals', '1');
    $home_deals_title           = get_option('evazar_opt_home_deals_title', 'پیشنهاد شگفت‌انگیز');
    $home_deals_count           = get_option('evazar_opt_home_deals_count', 12);
    $home_deals_min_discount    = get_option('evazar_opt_home_deals_min_discount', 5);
    $home_deals_hide_outofstock = get_option('evazar_opt_home_deals_hide_outofstock', '1');
    $home_deals_link            = get_option('evazar_opt_home_deals_link', '/?on_sale=1');

    // تنظیمات بخش محصولات چنددسته‌ای
    $home_show_cat_showcase     = get_option('evazar_opt_home_show_cat_showcase', '1');
    $home_cat_showcase_title    = get_option('evazar_opt_home_cat_showcase_title', 'منتخب کالاهای دسته‌بندی‌های برتر');
    $home_cat_showcase_type     = get_option('evazar_opt_home_cat_showcase_type', 'tabs');
    $home_cat_showcase_cats     = get_option('evazar_opt_home_cat_showcase_cats', []);
    $home_cat_showcase_count    = get_option('evazar_opt_home_cat_showcase_count', 8);
    $home_cat_showcase_hide_outofstock = get_option('evazar_opt_home_cat_showcase_hide_outofstock', '1');
    $home_cat_showcase_orderby  = get_option('evazar_opt_home_cat_showcase_orderby', 'date');

    $home_show_brands        = get_option('evazar_opt_home_show_brands', '1');
    $home_brands_title       = get_option('evazar_opt_home_brands_title', 'برندهای برتر و معتبر');
    $home_brands_mode        = get_option('evazar_opt_home_brands_mode', 'auto');
    $home_brands_count       = get_option('evazar_opt_home_brands_count', 12);
    $home_brands_selected    = get_option('evazar_opt_home_brands_selected', []);
    $home_show_trust         = get_option('evazar_opt_home_show_trust_bar', '1');

    $footer_show_trust_bar   = get_option('evazar_opt_footer_show_trust_bar', '1');
    $trust_bar_mobile        = get_option('evazar_opt_trust_bar_mobile', '1');
    $trust_bar_style         = get_option('evazar_opt_trust_bar_style', 'line');
    $trust_item_1_title      = get_option('evazar_opt_trust_item_1_title', 'قیمت و موجودی به‌روز');
    $trust_item_1_sub        = get_option('evazar_opt_trust_item_1_sub', 'به‌روزرسانی خودکار از داده‌های دیجی‌کالا');
    $trust_item_1_icon       = get_option('evazar_opt_trust_item_1_icon', 'shield');
    $trust_item_1_link       = get_option('evazar_opt_trust_item_1_link', '');
    $trust_item_2_title      = get_option('evazar_opt_trust_item_2_title', 'بهترین قیمت روز');
    $trust_item_2_sub        = get_option('evazar_opt_trust_item_2_sub', 'بروزرسانی لحظه‌ای تخفیف‌ها');
    $trust_item_2_icon       = get_option('evazar_opt_trust_item_2_icon', 'zap');
    $trust_item_2_link       = get_option('evazar_opt_trust_item_2_link', '');
    $trust_item_3_title      = get_option('evazar_opt_trust_item_3_title', 'بررسی با هوش مصنوعی');
    $trust_item_3_sub        = get_option('evazar_opt_trust_item_3_sub', 'تحلیل شفاف نقاط قوت و ضعف');
    $trust_item_3_icon       = get_option('evazar_opt_trust_item_3_icon', 'ai');
    $trust_item_3_link       = get_option('evazar_opt_trust_item_3_link', '');
    $trust_item_4_title      = get_option('evazar_opt_trust_item_4_title', 'خرید در سایت فروشنده');
    $trust_item_4_sub        = get_option('evazar_opt_trust_item_4_sub', 'پرداخت، ارسال و مرجوعی در سایت فروشنده انجام می‌شود');
    $trust_item_4_icon       = get_option('evazar_opt_trust_item_4_icon', 'lock');
    $trust_item_4_link       = get_option('evazar_opt_trust_item_4_link', '');
    $footer_about_title      = get_option('evazar_opt_footer_about_title', 'درباره ایوازار');
    $footer_about_text       = get_option('evazar_opt_footer_about_text', 'ایوازار، سامانه هوشمند کشف، بررسی تخصصی و مقایسه قیمت کالاهای دیجی‌کالا است. هدف ما ارائه تحلیل‌های بی‌طرفانه، راهنمایی خرید با هوش مصنوعی و اتصال امن کاربران به درگاه رسمی دیجی‌کالا است.');
    $footer_trust_title      = get_option('evazar_opt_footer_trust_title', 'ایوازار فروشنده کالا نیست');
    $footer_trust_text       = get_option('evazar_opt_footer_trust_text', 'ایوازار قیمت و اطلاعات کالا را نمایش می‌دهد و برای خرید شما را به سایت فروشنده منتقل می‌کند. پرداخت، ارسال، گارانتی و مرجوعی توسط فروشنده انجام می‌شود.');
    $footer_phone            = get_option('evazar_opt_footer_phone', '۰۲۱-۹۱۰۰۰۰۰۰');
    $footer_email            = get_option('evazar_opt_footer_email', 'info@evazar.ir');
    $footer_address          = get_option('evazar_opt_footer_address', 'تهران، دفتر ارتباطات ایوازار');
    $footer_show_cats        = get_option('evazar_opt_footer_show_cats', '1');
    $footer_cats_count       = get_option('evazar_opt_footer_cats_count', 6);
    $footer_show_brands      = get_option('evazar_opt_footer_show_brands', '1');
    $footer_brands_count     = get_option('evazar_opt_footer_brands_count', 6);
    $footer_copyright        = get_option('evazar_opt_footer_copyright', 'تمامی حقوق مادی و معنوی برای ایوازار محفوظ است © ۱۴۰۵');
    $footer_back_to_top      = get_option('evazar_opt_footer_back_to_top', '1');

    $sticky_buybox           = get_option('evazar_opt_sticky_mobile_buybox', '1');
    $mobile_search_visible   = get_option('evazar_opt_mobile_search_visible', '1');
    $mobile_header_compact   = get_option('evazar_opt_mobile_header_compact', '1');

    $enable_readmore         = get_option('evazar_opt_enable_readmore', '1');
    $readmore_desktop_height = get_option('evazar_opt_readmore_desktop_height', 280);
    $readmore_mobile_height  = get_option('evazar_opt_readmore_mobile_height', 200);
    $readmore_char_threshold = get_option('evazar_opt_readmore_char_threshold', 220);
    $readmore_product        = get_option('evazar_opt_readmore_product', '1');
    $readmore_archive        = get_option('evazar_opt_readmore_archive', '1');
    $readmore_home           = get_option('evazar_opt_readmore_home', '1');
    $readmore_footer         = get_option('evazar_opt_readmore_footer', '1');

    $image_cdn_domain        = get_option('evazar_opt_image_cdn_domain', 'https://img.evazar.ir');
    $custom_css              = get_option('evazar_opt_custom_css', '');
    $header_scripts          = get_option('evazar_opt_header_scripts', '');
    $footer_scripts          = get_option('evazar_opt_footer_scripts', '');

    $about_hero_badge        = get_option('evazar_opt_about_hero_badge', 'سامانه تخصصی همکاری در فروش و هدایت هوشمند خرید');
    $about_hero_title        = get_option('evazar_opt_about_hero_title', 'انتخابی دقیق‌تر، خریدی مطمئن‌تر و بدون واسطه از دیجی‌کالا');
    $about_hero_desc         = get_option('evazar_opt_about_hero_desc', 'ایوازار یک پل هوشمند و مرجع مستقل برای بررسی، مقایسه و کشف باارزش‌ترین کالاهای بازار آنلاین است. ما به شما کمک می‌کنیم در میان میلیون‌ها کالای موجود، باکیفیت‌ترین محصولات را با بهترین قیمت و مستقیم از طریق بستر امن دیجی‌کالا خریداری کنید.');
    $about_stat1_num         = get_option('evazar_opt_about_stat1_num', '+۵۰,۰۰۰');
    $about_stat1_txt         = get_option('evazar_opt_about_stat1_txt', 'کالای پایش‌شده و ارزیابی‌شده');
    $about_stat2_num         = get_option('evazar_opt_about_stat2_num', '۰ تومان');
    $about_stat2_txt         = get_option('evazar_opt_about_stat2_txt', 'کارمزد یا هزینه اضافه برای خریدار');
    $about_stat3_num         = get_option('evazar_opt_about_stat3_num', '۲۴/۷');
    $about_stat3_txt         = get_option('evazar_opt_about_stat3_txt', 'رصد لحظه‌ای تخفیف‌های واقعی');
    $about_stat4_num         = get_option('evazar_opt_about_stat4_num', '۱۰۰٪');
    $about_stat4_txt         = get_option('evazar_opt_about_stat4_txt', 'پرداخت مستقیم در درگاه شاپرک دیجی‌کالا');
    $about_disclosure_title  = get_option('evazar_opt_about_disclosure_title', 'بیانیه شفافیت در همکاری در فروش (Affiliate Disclosure)');
    $about_disclosure_text   = get_option('evazar_opt_about_disclosure_text', "ایوازار چگونه درآمد کسب می‌کند؟\nما به عنوان پارتنر تاییدشده سیستم همکاری در فروش رسمی (افیلیو دیجی‌کالا)، در ازای معرفی خریداران و در صورت انجام خرید نهایی، پورسانت اندکی از فروشگاه مرجع دریافت می‌کنیم. این فرآیند هیچ هزینه، کارمزد یا افزایش قیمتی برای شما ندارد و شما دقیقا با همان قیمت، تخفیف‌ها و گارانتی‌های رسمی خرید می‌کنید. این مدل به ما امکان می‌دهد تمام ابزارها و نقد و بررسی‌ها را به صورت ۱۰۰٪ رایگان و بدون تبلیغات آزاردهنده در اختیارتان بگذاریم.");
    $about_faq_enable        = get_option('evazar_opt_about_faq_enable', '1');
    $about_faq_title         = get_option('evazar_opt_about_faq_title', 'پرسش‌های متداول درباره ایوازار و نحوه خرید');
    $about_faq_items         = get_option('evazar_opt_about_faq_items', "آیا خرید از ایوازار هزینه یا کارمزد اضافی دارد؟ | خیر، به هیچ وجه. شما دقیقا با همان قیمت مصوب دیجی‌کالا و بدون حتی یک ریال هزینه اضافه خرید می‌کنید.\nآیا کالاها گارانتی و مهلت بازگشت دارند؟ | بله، تمامی سفارش‌ها مستقیماً با ضمانت ۷ روزه بازگشت وجه، تضمین اصالت فیزیکی و فاکتور رسمی دیجی‌کالا ارائه می‌شوند.\nپرداخت وجه در چه درگاهی انجام می‌شود؟ | پرداخت تماماً در درگاه امن شاپرک تحت نظارت بانک مرکزی و متعلق به دیجی‌کالا صورت می‌پذیرد.\nارسال سفارش‌ها چگونه انجام می‌شود؟ | تحویل کالا با بسته‌بندی پلمپ و اصالت کالا توسط ناوگان اکسپرس و پست دیجی‌کالا به سراسر کشور انجام می‌شود.");
    $about_cta_title         = get_option('evazar_opt_about_cta_title', 'خریدی هوشمندانه‌تر را از همین امروز تجربه کنید');
    $about_cta_desc          = get_option('evazar_opt_about_cta_desc', 'هزاران کالای بررسی‌شده با تخفیف‌های واقعی و ضمانت رسمی دیجی‌کالا در انتظار انتخاب شماست.');
    $about_cta_btn           = get_option('evazar_opt_about_cta_btn', 'ورود به کاتالوگ کالاهای منتخب');
    $about_cta_link          = get_option('evazar_opt_about_cta_link', home_url('/'));
    $opt_404_tab_title       = get_option('evazar_opt_404_tab_title', 'صفحه مورد نظر یافت نشد (خطای ۴۰۴)');
    $opt_404_title           = get_option('evazar_opt_404_title', 'صفحه‌ای که دنبالش بودید پیدا نشد!');
    $opt_404_subtitle        = get_option('evazar_opt_404_subtitle', 'ممکن است آدرس را اشتباه تایپ کرده باشید یا این کالا دیگر در فروشگاه موجود نباشد.');
    ?>

    <div class="wrap" style="direction: rtl; max-width: 1200px; margin: 20px auto 40px; font-family: inherit;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; background: #ffffff; padding: 18px 24px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
            <div>
                <h1 style="font-size: 22px; font-weight: 900; color: #0f172a; margin: 0 0 4px 0;">⚙️ تنظیمات قالب ایوازار</h1>
                <span style="color: #64748b; font-size: 13px;">مدیریت کامل و مستقل تمامی المان‌های پوسته، صفحات کالا، آرشیو، هدر و فوتر</span>
            </div>
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="background: #eff6ff; color: #2563eb; font-size: 12px; font-weight: bold; padding: 6px 14px; border-radius: 20px; border: 1px solid #bfdbfe;">⚡ بهینه برای موبایل</span>
                <?php 
                $active_theme_obj = wp_get_theme();
                $ui_theme_version = ($active_theme_obj && $active_theme_obj->exists()) ? $active_theme_obj->get('Version') : '1.4.47';
                ?>
                <span style="background: #ef394e; color: #fff; font-size: 12px; font-weight: bold; padding: 6px 14px; border-radius: 20px;">نسخه <?php echo esc_html($ui_theme_version); ?></span>
            </div>
        </div>

        <form method="post" action="">
            <?php wp_nonce_field('evazar_theme_options_nonce'); ?>
            <input type="hidden" name="evazar_active_tab" id="evazar_active_tab" value="<?php echo esc_attr($active_tab); ?>">

            <div style="display: flex; gap: 24px; flex-wrap: wrap;">
                
                <!-- تب‌های ناوبری کناری -->
                <div style="width: 250px; flex-shrink: 0;">
                    <ul class="evazar-tabs-nav" style="list-style: none; margin: 0; padding: 0; background: #fff; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.06); border: 1px solid #e2e8f0; overflow: hidden;">
                        <li><a href="#tab-branding" class="tab-link <?php echo ($active_tab === '#tab-branding') ? 'active' : ''; ?>">🎨 هویت بصری و رنگ‌بندی</a></li>
                        <li><a href="#tab-header" class="tab-link <?php echo ($active_tab === '#tab-header') ? 'active' : ''; ?>">📌 تنظیمات هدر و ناوبری</a></li>
                        <li><a href="#tab-product" class="tab-link <?php echo ($active_tab === '#tab-product') ? 'active' : ''; ?>">🛍️ برگه تکی محصول</a></li>
                        <li><a href="#tab-affiliate" class="tab-link <?php echo ($active_tab === '#tab-affiliate') ? 'active' : ''; ?>">🔗 انتقال به فروشنده</a></li>
                        <li><a href="#tab-archive" class="tab-link <?php echo ($active_tab === '#tab-archive') ? 'active' : ''; ?>">🏷️ برندها و دسته‌بندی‌ها</a></li>
                        <li><a href="#tab-home" class="tab-link <?php echo ($active_tab === '#tab-home') ? 'active' : ''; ?>">🏠 محتوای صفحه اصلی</a></li>
                        <li><a href="#tab-about" class="tab-link <?php echo ($active_tab === '#tab-about') ? 'active' : ''; ?>">ℹ️ برگه درباره ما</a></li>
                        <li><a href="#tab-404" class="tab-link <?php echo ($active_tab === '#tab-404') ? 'active' : ''; ?>">🚫 برگه خطای ۴۰۴</a></li>
                        <li><a href="#tab-footer" class="tab-link <?php echo ($active_tab === '#tab-footer') ? 'active' : ''; ?>">📑 مدیریت فوتر</a></li>
                        <li><a href="#tab-mobile" class="tab-link <?php echo ($active_tab === '#tab-mobile') ? 'active' : ''; ?>">📱 بهینه‌سازی موبایل</a></li>
                        <li><a href="#tab-readmore" class="tab-link <?php echo ($active_tab === '#tab-readmore') ? 'active' : ''; ?>">📖 سیستم مشاهده بیشتر</a></li>
                        <li><a href="#tab-smart" class="tab-link <?php echo ($active_tab === '#tab-smart') ? 'active' : ''; ?>">⚡ CDN و کدهای سفارشی</a></li>
                    </ul>
                </div>

                <!-- پنل‌های محتوای تب‌ها -->
                <div style="flex: 1; min-width: 340px; background: #fff; padding: 28px 34px; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.06); border: 1px solid #e2e8f0;">
                    
                    <!-- تب ۱: هویت بصری و رنگ‌بندی -->
                    <div id="tab-branding" class="tab-content <?php echo ($active_tab === '#tab-branding') ? 'active' : ''; ?>" style="<?php echo ($active_tab === '#tab-branding') ? '' : 'display: none;'; ?>">
                        <h2 class="tab-title">🎨 هویت بصری، لوگو و تایپوگرافی سایت</h2>
                        
                        <table class="form-table">
                            <tr>
                                <th>نوع نمایش لوگو</th>
                                <td>
                                    <label style="margin-left: 20px;"><input type="radio" name="evazar_opt_logo_type" value="text" <?php checked($logo_type, 'text'); ?>> لوگوی متنی مدرن (سبک، سریع و برداری)</label>
                                    <label><input type="radio" name="evazar_opt_logo_type" value="image" <?php checked($logo_type, 'image'); ?>> تصویر لوگوی اختصاصی</label>
                                </td>
                            </tr>
                            <tr class="row-logo-image" style="<?php echo ($logo_type === 'image') ? '' : 'display:none;'; ?>">
                                <th>تصویر لوگو</th>
                                <td>
                                    <input type="text" id="evazar_logo_img" name="evazar_opt_logo_image" value="<?php echo esc_attr($logo_image); ?>" style="width: 70%;" placeholder="https://...">
                                    <button type="button" class="button btn-upload-media" data-target="#evazar_logo_img">انتخاب از رسانه</button>
                                    <div id="logo-preview" style="margin-top: 10px;"><?php if ($logo_image) echo '<img src="' . esc_url($logo_image) . '" style="max-height: 46px;">'; ?></div>
                                </td>
                            </tr>
                            <tr class="row-logo-text" style="<?php echo ($logo_type === 'text') ? '' : 'display:none;'; ?>">
                                <th>عنوان متنی برند</th>
                                <td>
                                    <input type="text" name="evazar_opt_logo_text" value="<?php echo esc_attr($logo_text); ?>" class="regular-text">
                                    <p class="description">نام برند شما (مثلاً: ایــــوازار)</p>
                                </td>
                            </tr>
                            <tr class="row-logo-text" style="<?php echo ($logo_type === 'text') ? '' : 'display:none;'; ?>">
                                <th>تک‌حرف آیکون لوگو</th>
                                <td>
                                    <input type="text" name="evazar_opt_logo_letter" value="<?php echo esc_attr($logo_letter); ?>" style="width: 60px; text-align: center; font-weight: bold; font-size: 16px;">
                                    <p class="description">حرف داخل باکس قرمز لوگو (پیش‌فرض: E)</p>
                                </td>
                            </tr>
                            <tr>
                                <th>شعار زیر لوگو (Tagline)</th>
                                <td>
                                    <input type="text" name="evazar_opt_logo_tagline" value="<?php echo esc_attr($logo_tagline); ?>" class="large-text">
                                </td>
                            </tr>
                            <tr>
                                <th>تصویر فاوآیکون (Favicon)</th>
                                <td>
                                    <input type="text" id="evazar_favicon_img" name="evazar_opt_favicon" value="<?php echo esc_attr($favicon); ?>" style="width: 70%;">
                                    <button type="button" class="button btn-upload-media" data-target="#evazar_favicon_img">انتخاب فاوآیکون</button>
                                </td>
                            </tr>
                            <tr>
                                <th>فونت فارسی سایت</th>
                                <td>
                                    <select name="evazar_opt_font" style="min-width: 260px; padding: 6px;">
                                        <option value="vazirmatn" <?php selected($font, 'vazirmatn'); ?>>وزیرمتن متغیر (Vazirmatn VF) - محلی، کش‌شده و فوق‌سریع</option>
                                        <option value="yekanbakh" <?php selected($font, 'yekanbakh'); ?>>یکان‌بخ (Yekan Bakh) - وب‌فونت مدرن و محبوب فروشگاهی</option>
                                        <option value="system" <?php selected($font, 'system'); ?>>فونت سیستمی (System Fonts) - بدون دانلود</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th>رنگ اصلی برند (Primary)</th>
                                <td>
                                    <input type="text" name="evazar_opt_primary_color" value="<?php echo esc_attr($primary_color); ?>" class="color-picker-field" data-default-color="#ef394e">
                                    <p class="description">رنگ دکمه‌ها، قیمت‌ها و هویت سازگار با دیجی‌کالا (پیش‌فرض: #ef394e)</p>
                                </td>
                            </tr>
                            <tr>
                                <th>رنگ ثانویه (Secondary)</th>
                                <td>
                                    <input type="text" name="evazar_opt_secondary_color" value="<?php echo esc_attr($secondary_color); ?>" class="color-picker-field" data-default-color="#0284c7">
                                    <p class="description">رنگ لینک‌های مکمل و برندها (پیش‌فرض: #0284c7)</p>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- تب ۲: هدر و ناوبری -->
                    <div id="tab-header" class="tab-content <?php echo ($active_tab === '#tab-header') ? 'active' : ''; ?>" style="<?php echo ($active_tab === '#tab-header') ? '' : 'display: none;'; ?>">
                        <h2 class="tab-title">📌 تنظیمات هدر، نوار اعلان و جستجو</h2>
                        
                        <table class="form-table">
                            <tr>
                                <th>نوار اعلان بالای سایت (Top Bar)</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_show_top_notice" value="1" <?php checked($show_top_notice, '1'); ?>> نمایش نوار اعلان بالای سایت</label>
                                    <br><br>
                                    <input type="text" name="evazar_opt_top_notice" value="<?php echo esc_attr($top_notice); ?>" class="large-text">
                                </td>
                            </tr>
                            <tr>
                                <th>رنگ‌های نوار اعلان</th>
                                <td>
                                    رنگ پس‌زمینه: <input type="text" name="evazar_opt_top_notice_bg" value="<?php echo esc_attr($top_notice_bg); ?>" class="color-picker-field" data-default-color="#0f172a">
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    رنگ متن: <input type="text" name="evazar_opt_top_notice_color" value="<?php echo esc_attr($top_notice_color); ?>" class="color-picker-field" data-default-color="#ffffff">
                                </td>
                            </tr>
                            <tr>
                                <th>هدر چسبان (Sticky Header)</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_header_sticky" value="1" <?php checked($header_sticky, '1'); ?>> چسبان بودن نوار هدر هنگام اسکرول صفحه به پایین</label>
                                </td>
                            </tr>
                            <tr>
                                <th>جستجوی هوشمند در هدر</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_header_show_search" value="1" <?php checked($header_show_search, '1'); ?>> نمایش کادر جستجوی کالاها در هدر</label>
                                    <br><br>
                                    متن راهنمای جستجو:
                                    <input type="text" name="evazar_opt_header_search_placeholder" value="<?php echo esc_attr($header_search_placeholder); ?>" class="regular-text">
                                </td>
                            </tr>
                            <tr>
                                <th>نشان رسمی پارتنر دیجی‌کالا</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_show_partner_badge" value="1" <?php checked($show_partner_badge, '1'); ?>> نمایش نشان اعتماد «پارتنر رسمی دیجی‌کالا» در هدر</label>
                                    <br><br>
                                    متن نشان: <input type="text" name="evazar_opt_partner_badge_text" value="<?php echo esc_attr($partner_badge_text); ?>" class="regular-text">
                                </td>
                            </tr>
                            <tr>
                                <th>لینک‌های دسترسی سریع هدر</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_header_show_quick_links" value="1" <?php checked($header_quick_links, '1'); ?>> نمایش نوار ناوبری دسترسی سریع به کالاها، برندها و تخفیف‌ها</label>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- تب ۳: برگه تکی محصول -->
                    <div id="tab-product" class="tab-content <?php echo ($active_tab === '#tab-product') ? 'active' : ''; ?>" style="<?php echo ($active_tab === '#tab-product') ? '' : 'display: none;'; ?>">
                        <h2 class="tab-title">🛍️ تنظیمات تخصصی صفحه تکی کالا (Single Product)</h2>
                        
                        <table class="form-table">
                            <tr>
                                <th>امکانات گالری تصاویر</th>
                                <td>
                                    <label style="display: block; margin-bottom: 8px;"><input type="checkbox" name="evazar_opt_product_zoom" value="1" <?php checked($product_zoom, '1'); ?>> فعال بودن بزرگ‌نمایی شناور دسکتاپ (Hover Zoom)</label>
                                    <label style="display: block;"><input type="checkbox" name="evazar_opt_product_lightbox" value="1" <?php checked($product_lightbox, '1'); ?>> فعال بودن لایت‌باکس تمام‌صفحه و تعاملی (Fullscreen Lightbox Modal)</label>
                                </td>
                            </tr>
                            <tr>
                                <th>عناصر اطلاعاتی کالا</th>
                                <td>
                                    <label style="margin-left: 20px;"><input type="checkbox" name="evazar_opt_product_show_discount" value="1" <?php checked($product_show_discount, '1'); ?>> نشان درصد تخفیف آتشین</label>
                                    <label style="margin-left: 20px;"><input type="checkbox" name="evazar_opt_product_show_ratings" value="1" <?php checked($product_show_ratings, '1'); ?>> چیپ امتیاز و درصد رضایت</label>
                                    <label><input type="checkbox" name="evazar_opt_product_show_sku" value="1" <?php checked($product_show_sku, '1'); ?>> نمایش کد کالا (SKU)</label>
                                </td>
                            </tr>
                            <tr>
                                <th>باکس ویژگی‌ها و هوش مصنوعی</th>
                                <td>
                                    <label style="display: block; margin-bottom: 8px;"><input type="checkbox" name="evazar_opt_product_show_features" value="1" <?php checked($product_show_features, '1'); ?>> نمایش باکس ویژگی‌های برجسته کالا</label>
                                    <div style="margin: 8px 0 14px 0; padding: 10px 14px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 6px; display: inline-flex; align-items: center; gap: 10px;">
                                        <label for="evazar_opt_single_features_limit" style="font-weight: 600; color: #334155; font-size: 13px;">تعداد ویژگی‌های اولیه نمایان (قبل از دکمه مشاهده بیشتر):</label>
                                        <input type="number" id="evazar_opt_single_features_limit" name="evazar_opt_single_features_limit" value="<?php echo esc_attr($single_features_limit); ?>" min="1" max="50" style="width: 70px; text-align: center; border-radius: 4px; border: 1px solid #cbd5e1; height: 32px;">
                                        <span class="description" style="color: #64748b; font-size: 12px;">(پیش‌فرض: ۵ عدد - مابقی ویژگی‌ها جمع شده و با کلیک روی دکمه مشاهده بیشتر باز می‌شوند)</span>
                                    </div>
                                    <label style="display: block;"><input type="checkbox" name="evazar_opt_product_show_ai" value="1" <?php checked($product_show_ai, '1'); ?>> نمایش ستون‌های نقاط قوت و ضعف هوش مصنوعی (AI Verdict)</label>
                                </td>
                            </tr>
                            <tr>
                                <th>جعبه خرید (طرح ۴: گارانتی‌محور)</th>
                                <td>
                                    <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 12px; margin-bottom: 12px;">
                                        <strong>🛡️ المان‌های اعتمادسازی و گارانتی:</strong>
                                        <div style="margin-top: 8px;">
                                            عنوان نوار بالای گارانتی:
                                            <input type="text" name="evazar_opt_buybox_guarantee_header" value="<?php echo esc_attr($buybox_guarantee_header); ?>" class="large-text">
                                        </div>
                                        <div style="margin-top: 8px;">
                                            ویژگی گارانتی ۱ (تیک‌سبز):
                                            <input type="text" name="evazar_opt_buybox_feature_1" value="<?php echo esc_attr($buybox_feature_1); ?>" class="large-text">
                                        </div>
                                        <div style="margin-top: 8px;">
                                            ویژگی گارانتی ۲ (تیک‌سبز):
                                            <input type="text" name="evazar_opt_buybox_feature_2" value="<?php echo esc_attr($buybox_feature_2); ?>" class="large-text">
                                        </div>
                                        <div style="margin-top: 8px;">
                                            ویژگی گارانتی ۳ (تیک‌سبز):
                                            <input type="text" name="evazar_opt_buybox_feature_3" value="<?php echo esc_attr($buybox_feature_3); ?>" class="large-text">
                                        </div>
                                        <div style="margin-top: 8px;">
                                            برچسب عنوان قیمت:
                                            <input type="text" name="evazar_opt_buybox_price_label" value="<?php echo esc_attr($buybox_price_label); ?>" class="regular-text">
                                        </div>
                                        <hr style="margin: 16px 0; border: 0; border-top: 1px solid #dbeafe;">
                                        <strong style="display:block; margin-bottom:8px;">متن ۳ باکس اطلاعاتی زیر مشخصات کالا:</strong>
                                        <div style="margin-top: 8px;">
                                            باکس اول (اطلاعات قیمت و موجودی):
                                            <input type="text" name="evazar_opt_product_trust_badge_1" value="<?php echo esc_attr($product_trust_badge_1); ?>" class="large-text">
                                        </div>
                                        <div style="margin-top: 8px;">
                                            باکس دوم (خرید در سایت فروشنده):
                                            <input type="text" name="evazar_opt_product_trust_badge_2" value="<?php echo esc_attr($product_trust_badge_2); ?>" class="large-text">
                                        </div>
                                        <div style="margin-top: 8px;">
                                            باکس سوم (ارسال و مرجوعی):
                                            <input type="text" name="evazar_opt_product_trust_badge_3" value="<?php echo esc_attr($product_trust_badge_3); ?>" class="large-text">
                                        </div>
                                    </div>
                                    <label><input type="checkbox" name="evazar_opt_product_show_seller" value="1" <?php checked($product_show_seller, '1'); ?>> نمایش باکس نام فروشنده رسمی و تضمین اصالت</label>
                                    <br><br>
                                    نام فروشنده: <input type="text" name="evazar_opt_product_seller_name" value="<?php echo esc_attr($product_seller_name); ?>" class="regular-text">
                                </td>
                            </tr>
                            <tr>
                                <th>دکمه اصلی خرید (Affiliate CTA)</th>
                                <td>
                                    عنوان دکمه خرید: <input type="text" name="evazar_opt_product_btn_title" value="<?php echo esc_attr($product_btn_title); ?>" class="large-text">
                                    <br><br>
                                    زیرعنوان دکمه خرید: <input type="text" name="evazar_opt_product_btn_subtitle" value="<?php echo esc_attr($product_btn_subtitle); ?>" class="large-text">
                                    <br><br>
                                    پیام تضمین خرید امن زیر دکمه:
                                    <textarea name="evazar_opt_product_guarantee_text" rows="2" class="large-text"><?php echo esc_textarea($product_guarantee_text); ?></textarea>
                                </td>
                            </tr>
                            <tr>
                                <th>کالاهای مشابه و مرتبط</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_product_show_related" value="1" <?php checked($product_show_related, '1'); ?>> نمایش بخش کالاهای مشابه در انتهای صفحه کالا</label>
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    تعداد نمایش: 
                                    <input type="number" name="evazar_opt_product_related_count" value="<?php echo esc_attr($product_related_count); ?>" min="1" max="50" step="1" style="width: 75px; text-align: center; font-weight: bold; border-radius: 6px; padding: 4px 6px;">
                                    <span style="color: #64748b; font-size: 0.85rem;">کالا (دلخواه از ۱ تا ۵۰، مانند ۴، ۵، ۶، ۸، ۱۰، ۱۲ یا هر عدد دیگر)</span>
                                    <br><br>
                                    <label style="display: inline-flex; align-items: center; gap: 6px; background: #fff1f2; border: 1px solid #fecdd3; padding: 6px 12px; border-radius: 6px; color: #9f1239; font-weight: 600;">
                                        <input type="checkbox" name="evazar_opt_related_hide_outofstock" value="1" <?php checked($related_hide_outofstock, '1'); ?>>
                                        عدم نمایش کالاهای ناموجود در بخش کالاهای مشابه (فقط کالاهای دارای موجودی و قیمت معتبر نمایش داده شوند)
                                    </label>
                                </td>
                            </tr>
                            <tr>
                                <th>استراکچردیتا و سئوی گوگل (Schema.org / JSON-LD)</th>
                                <td>
                                    <label style="display: block; margin-bottom: 10px; font-weight: bold;">
                                        <input type="checkbox" name="evazar_opt_schema_enable" value="1" <?php checked($schema_enable, '1'); ?>>
                                        فعال‌سازی کدهای رسمی Schema.org در برگه تکی محصول (تزریق خودکار در هدر)
                                    </label>
                                    
                                    <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px; margin-top: 8px;">
                                        <div style="font-weight: 600; margin-bottom: 8px; color: #1e293b;">نوع خروجی استراکچردیتا برای گوگل (Rich Snippets):</div>
                                        <label style="display: block; margin-bottom: 8px;">
                                            <input type="radio" name="evazar_opt_schema_mode" value="full" <?php checked($schema_mode, 'full'); ?>>
                                            <strong>حالت استاندارد کامل (پیشنهادی):</strong> شامل نام، تصویر، برند، امتیاز رضایت خریداران، قیمت ریالی روز دیجی‌کالا و وضعیت موجودی انبار (بالاترین شانس نمایش در باکس‌های ویژه خرید و مقایسه قیمت گوگل).
                                        </label>
                                        <label style="display: block;">
                                            <input type="radio" name="evazar_opt_schema_mode" value="stars_only" <?php checked($schema_mode, 'stars_only'); ?>>
                                            <strong>حالت فقط ستاره‌ها (Minimal Rating):</strong> فقط نام کالا، تصویر و ستاره‌های امتیاز (AggregateRating) بدون درج قیمت و موجودی.
                                        </label>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>نشان گرافیکی «کاهش قیمت» (Price Drop Badge)</th>
                                <td>
                                    <label style="display: block; margin-bottom: 10px; font-weight: bold;">
                                        <input type="checkbox" name="evazar_opt_show_price_drop_badge" value="1" <?php checked($show_price_drop_badge, '1'); ?>>
                                        نمایش خودکار برچسب «کاهش قیمت» در کارت‌های کالا و برگه محصول هنگام ارزان شدن کالا در استعلام زنده
                                    </label>
                                    
                                    <div style="display: flex; gap: 20px; align-items: center; flex-wrap: wrap; margin-top: 8px;">
                                        <div>
                                            متن نشان بر روی کارت:
                                            <input type="text" name="evazar_opt_price_drop_badge_text" value="<?php echo esc_attr($price_drop_badge_text); ?>" class="regular-text">
                                        </div>
                                        <div>
                                            مدت اعتبار نشان پس از کاهش قیمت:
                                            <input type="number" name="evazar_opt_price_drop_hours" value="<?php echo esc_attr($price_drop_hours); ?>" style="width: 80px;" min="1" max="168"> ساعت
                                        </div>
                                    </div>
                                    <p class="description" style="margin-top: 8px;">سیستم به محض اینکه در استعلام زنده دیجی‌کالا متوجه شود قیمت کالا ارزان‌تر از قیمت قبلی دیتابیس شده است، این نشان روانشناختی را فعال می‌کند.</p>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- تب انتقال افیلیت -->
                    <div id="tab-affiliate" class="tab-content <?php echo ($active_tab === '#tab-affiliate') ? 'active' : ''; ?>" style="<?php echo ($active_tab === '#tab-affiliate') ? '' : 'display: none;'; ?>">
                        <h2 class="tab-title">🔗 صفحه انتقال به سایت فروشنده</h2>
                        <p style="margin:0 0 18px;color:#64748b;line-height:1.9;">این صفحه فقط هنگام کلیک کاربر روی لینک خرید نمایش داده می‌شود. هیچ خریدی در ایوازار انجام نمی‌شود و کاربر برای خرید به سایت فروشنده منتقل خواهد شد.</p>
                        <table class="form-table">
                            <tr>
                                <th>شمارش معکوس</th>
                                <td>
                                    <label style="display:block;font-weight:600;margin-bottom:8px;">
                                        <input type="checkbox" name="evazar_affiliate_redirect_countdown_enabled" value="1" <?php checked($affiliate_redirect_countdown_enabled, '1'); ?>>
                                        فعال‌سازی شمارش معکوس قبل از انتقال
                                    </label>
                                    <p class="description">وقتی خاموش باشد، صفحه انتقال و شمارنده نمایش داده نمی‌شود و کلیک کاربر مستقیماً به لینک فروشنده هدایت می‌شود.</p>
                                </td>
                            </tr>
                            <tr>
                                <th>مدت شمارش</th>
                                <td>
                                    <input type="number" name="evazar_affiliate_redirect_delay" value="<?php echo esc_attr($affiliate_redirect_delay); ?>" min="1" max="5" step="1" style="width:80px;text-align:center;font-weight:700;">
                                    <span class="description" style="margin-right:8px;">ثانیه — پیشنهاد: ۲ ثانیه</span>
                                </td>
                            </tr>
                            <tr>
                                <th>عنوان صفحه</th>
                                <td><input type="text" name="evazar_affiliate_redirect_title" value="<?php echo esc_attr($affiliate_redirect_title); ?>" class="large-text"></td>
                            </tr>
                            <tr>
                                <th>متن توضیح</th>
                                <td><textarea name="evazar_affiliate_redirect_description" rows="2" class="large-text"><?php echo esc_textarea($affiliate_redirect_description); ?></textarea></td>
                            </tr>
                            <tr>
                                <th>متن دکمه انتقال فوری</th>
                                <td><input type="text" name="evazar_affiliate_redirect_button" value="<?php echo esc_attr($affiliate_redirect_button); ?>" class="regular-text"></td>
                            </tr>
                        </table>
                        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:14px 16px;line-height:2;color:#475569;">
                            <strong>فونت صفحه انتقال:</strong> از همان «فونت فارسی سایت» در تب هویت بصری استفاده می‌شود؛ بنابراین در صورت انتخاب وزیرمتن، یکان‌بخ یا فونت سیستمی، صفحه انتقال هم خودکار با همان فونت نمایش داده می‌شود.
                        </div>
                    </div>

                    <!-- تب ۴: صفحه برندها و دسته‌بندی‌ها -->
                    <div id="tab-archive" class="tab-content <?php echo ($active_tab === '#tab-archive') ? 'active' : ''; ?>" style="<?php echo ($active_tab === '#tab-archive') ? '' : 'display: none;'; ?>">
                        <h2 class="tab-title">🏷️ تنظیمات آرشیو دسته‌بندی‌ها و برندها</h2>
                        <div class="evazar-filter-order-admin" style="margin:18px 0 26px;padding:18px;border:1px solid #e2e8f0;background:#f8fafc;border-radius:14px;max-width:760px;">
                            <strong style="display:block;font-size:14px;margin-bottom:7px;color:#0f172a;">ترتیب نمایش فیلترها</strong>
                            <p style="margin:0 0 14px;color:#64748b;font-size:12px;">بخش‌ها را با کشیدن و رها کردن جابه‌جا کنید. این ترتیب در دسکتاپ و موبایل اعمال می‌شود.</p>
                            <?php
                            $filter_order = array_values(array_intersect(explode(',', (string)$filter_sections_order), ['category','brand','stock','price']));
                            foreach (['category','brand','stock','price'] as $fallback) if (!in_array($fallback, $filter_order, true)) $filter_order[]=$fallback;
                            $labels = ['category'=>'دسته‌بندی','brand'=>'برند','stock'=>'وضعیت کالا','price'=>'بازه قیمت'];
                            ?>
                            <input type="hidden" id="evazar_filter_sections_order" name="evazar_opt_filter_sections_order" value="<?php echo esc_attr(implode(',', $filter_order)); ?>">
                            <div id="evazar-filter-sortable" style="display:grid;gap:8px;max-width:520px;">
                            <?php foreach ($filter_order as $key): ?>
                                <div class="evazar-filter-sort-item" draggable="true" data-key="<?php echo esc_attr($key); ?>" style="display:flex;align-items:center;gap:10px;padding:11px 13px;background:#fff;border:1px solid #e2e8f0;border-radius:10px;cursor:grab;">
                                    <span style="font-size:18px;color:#94a3b8;">☷</span><strong style="font-size:13px;color:#334155;"><?php echo esc_html($labels[$key]); ?></strong>
                                </div>
                            <?php endforeach; ?>
                            </div>
                        </div>
                        
                        <table class="form-table">
                            <tr>
                                <th>تعداد کالاها در هر صفحه (Pagination)</th>
                                <td>
                                    <input type="number" name="evazar_opt_archive_posts_per_page" value="<?php echo esc_attr($archive_posts_per_page); ?>" min="4" max="48" style="width: 80px;"> کالا
                                    <p class="description">تعداد کالاهایی که قبل از صفحه‌بندی نمایش داده می‌شوند (پیش‌فرض: ۱۶)</p>
                                </td>
                            </tr>
                            <tr>
                                <th>تعداد ستون‌های نمایش کالاها</th>
                                <td>
                                    در رایانه و لپ‌تاپ (دسکتاپ):
                                    <select name="evazar_opt_archive_desktop_cols" style="margin-left: 20px;">
                                        <option value="5" <?php selected($archive_desktop_cols, '5'); ?>>⭐ ۵ ستونه (پیشنهاد طلایی سیستم در عرض ۱۵۲۰px)</option>
                                        <option value="4" <?php selected($archive_desktop_cols, '4'); ?>>۴ ستونه (کلاسیک و جادار)</option>
                                        <option value="3" <?php selected($archive_desktop_cols, '3'); ?>>۳ ستونه (بزرگ‌تر و واضح‌تر)</option>
                                        <option value="6" <?php selected($archive_desktop_cols, '6'); ?>>۶ ستونه (تراکم بالا - کالاهای جانبی)</option>
                                        <option value="auto" <?php selected($archive_desktop_cols, 'auto'); ?>>⚡ هوشمند تطبیقی (Auto-Fit بر اساس رزولوشن)</option>
                                    </select>
                                    در گوشی موبایل:
                                    <select name="evazar_opt_archive_mobile_cols">
                                        <option value="2" <?php selected($archive_mobile_cols, '2'); ?>>۲ ستونه (بهترین تجربه کاربری موبایل)</option>
                                        <option value="1" <?php selected($archive_mobile_cols, '1'); ?>>۱ ستونه (کارت تمام‌عرض)</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th>بنر بالای آرشیو (Hero Banner)</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_archive_show_hero" value="1" <?php checked($archive_show_hero, '1'); ?>> نمایش باکس عنوان و معرفی بالای صفحه آرشیو</label>
                                </td>
                            </tr>
                            <tr>
                                <th>شمارنده و تعداد کالاها</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_archive_show_count" value="1" <?php checked($archive_show_count, '1'); ?>> نمایش تعداد کالاها در هدر آرشیو، دسته‌بندی‌ها، زیردسته‌ها، برندها و صفحه راهنمای برندها</label>
                                    <p class="description">با غیرفعال‌سازی این گزینه، برچسب‌های تعداد کالاها در سراسر بخش‌های دسته‌بندی، زیردسته‌ها، منوی آبشاری، صفحه اصلی و لیست برندها مخفی می‌شوند.</p>
                                </td>
                            </tr>
                            <tr>
                                <th>توضیحات غنی سئو (SEO Description)</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_archive_show_desc" value="1" <?php checked($archive_show_desc, '1'); ?>> نمایش متن توضیحات دسته‌بندی و برند در بالای صفحه آرشیو (بهبود رتبه سئو)</label>
                                </td>
                            </tr>
                            <tr>
                                <th>عناصر روی کارت‌های کالا در آرشیو</th>
                                <td>
                                    <label style="margin-left: 20px;"><input type="checkbox" name="evazar_opt_archive_show_discount" value="1" <?php checked($archive_show_discount, '1'); ?>> نشان درصد تخفیف</label>
                                    <label style="margin-left: 20px;"><input type="checkbox" name="evazar_opt_archive_show_rating" value="1" <?php checked($archive_show_rating, '1'); ?>> امتیاز ستاره‌ای</label>
                                    <label><input type="checkbox" name="evazar_opt_archive_show_buy_btn" value="1" <?php checked($archive_show_buy_btn, '1'); ?>> دکمه خرید مستقیم</label>
                                </td>
                            </tr>
                            <tr>
                                <th>عنوان برگه تخفیف‌های ویژه</th>
                                <td>
                                    <input type="text" name="evazar_opt_special_offers_title" value="<?php echo esc_attr($special_offers_title); ?>" class="regular-text" style="width: 100%; max-width: 500px;">
                                    <p class="description">عنوان اصلی نمایش داده شده در بالای لندینگ کالاهای تخفیف‌دار</p>
                                </td>
                            </tr>
                            <tr>
                                <th>متن معرفی و سئوی لندینگ تخفیف‌ها</th>
                                <td>
                                    <textarea name="evazar_opt_special_offers_desc" rows="3" style="width: 100%; max-width: 700px;"><?php echo esc_textarea($special_offers_desc); ?></textarea>
                                    <p class="description">متنی که در انتهای برگه تخفیف‌های ویژه درون کادر راهنمای سئو نمایش می‌یابد (امکان خالی گذاشتن برای عدم نمایش وجود دارد).</p>
                                </td>
                            </tr>
                            <tr>
                                <th>عنوان برگه جامع برندها (/brand/)</th>
                                <td>
                                    <input type="text" name="evazar_opt_brands_page_title" value="<?php echo esc_attr($brands_page_title); ?>" class="regular-text" style="width: 100%; max-width: 500px;">
                                    <p class="description">عنوان نمایش داده شده در بالای صفحه دایرکتوری همه برندها (پیش‌فرض: برندهای کالا)</p>
                                </td>
                            </tr>
                            <tr>
                                <th>متن معرفی و سئوی برگه برندها</th>
                                <td>
                                    <textarea name="evazar_opt_brands_page_desc" rows="3" style="width: 100%; max-width: 700px;"><?php echo esc_textarea($brands_page_desc); ?></textarea>
                                    <p class="description">متن توضیحی و راهنمای سئو برای صفحه دایرکتوری برندها (اختیاری - در انتهای صفحه کادر راهنما ایجاد می‌کند).</p>
                                </td>
                            </tr>
                            <tr>
                                <th>عنوان برگه جامع دسته‌بندی‌ها (/product-category/)</th>
                                <td>
                                    <input type="text" name="evazar_opt_categories_page_title" value="<?php echo esc_attr($categories_page_title); ?>" class="regular-text" style="width: 100%; max-width: 500px;">
                                    <p class="description">عنوان نمایش داده شده در بالای صفحه ساختار دسته‌بندی‌ها (پیش‌فرض: دسته‌بندی‌های کالا)</p>
                                </td>
                            </tr>
                            <tr>
                                <th>متن معرفی و سئوی برگه دسته‌بندی‌ها</th>
                                <td>
                                    <textarea name="evazar_opt_categories_page_desc" rows="3" style="width: 100%; max-width: 700px;"><?php echo esc_textarea($categories_page_desc); ?></textarea>
                                    <p class="description">متن توضیحی و راهنمای سئو برای صفحه ساختار دسته‌بندی‌ها (اختیاری).</p>
                                </td>
                            </tr>
                            <tr>
                                <th>الگوی عنوان متای سئو صفحات برندها (Meta Title)</th>
                                <td>
                                    <input type="text" name="evazar_opt_brand_meta_title_template" value="<?php echo esc_attr($brand_meta_title_tpl); ?>" class="regular-text" style="width: 100%; max-width: 500px;">
                                    <p class="description">فرمول عنوان متای سئو در تب مرورگر و گوگل برای تک‌تک برندها (مانند تسکو، وسترن دیجیتال و...).<br>متغیرهای در دسترس: <code>{brand}</code> (نام برند) و <code>{site_name}</code> (نام سایت).<br>پیش‌فرض: <code>خرید و قیمت روز انواع محصولات {brand} | {site_name}</code></p>
                                </td>
                            </tr>
                            <tr>
                                <th>الگوی پیش‌فرض توضیحات متای برندها (Meta Description)</th>
                                <td>
                                    <textarea name="evazar_opt_brand_meta_desc_template" rows="2" style="width: 100%; max-width: 500px;"><?php echo esc_textarea($brand_meta_desc_tpl); ?></textarea>
                                    <p class="description">الگوی پیش‌فرض توضیحات متای گوگل برای برندهایی که فیلد اختصاصی آن‌ها خالی مانده است. متغیرها: <code>{brand}</code> و <code>{site_name}</code>.</p>
                                </td>
                            </tr>
                            <tr>
                                <th>الگوی عنوان متای سئو صفحات دسته‌بندی‌ها (Meta Title)</th>
                                <td>
                                    <input type="text" name="evazar_opt_category_meta_title_template" value="<?php echo esc_attr($category_meta_title_tpl); ?>" class="regular-text" style="width: 100%; max-width: 500px;">
                                    <p class="description">فرمول عنوان متای سئو در تب مرورگر و گوگل برای صفحات هر دسته‌بندی.<br>متغیرهای در دسترس: <code>{category}</code> (نام دسته) و <code>{site_name}</code> (نام سایت).<br>پیش‌فرض: <code>خرید و قیمت روز انواع {category} | {site_name}</code></p>
                                </td>
                            </tr>
                            <tr>
                                <th>الگوی پیش‌فرض توضیحات متای دسته‌بندی‌ها (Meta Description)</th>
                                <td>
                                    <textarea name="evazar_opt_category_meta_desc_template" rows="2" style="width: 100%; max-width: 500px;"><?php echo esc_textarea($category_meta_desc_tpl); ?></textarea>
                                    <p class="description">الگوی پیش‌فرض توضیحات متای گوگل برای دسته‌هایی که فیلد اختصاصی آن‌ها خالی مانده است. متغیرها: <code>{category}</code> و <code>{site_name}</code>.</p>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- تب ۵: محتوای صفحه اصلی -->
                    <div id="tab-home" class="tab-content <?php echo ($active_tab === '#tab-home') ? 'active' : ''; ?>" style="<?php echo ($active_tab === '#tab-home') ? '' : 'display: none;'; ?>">
                        <h2 class="tab-title">🏠 تنظیمات بخش‌های صفحه اصلی (Home Page)</h2>
                        
                        <table class="form-table">
                            <tr>
                                <th>عنوان بزرگ بنر هیرو</th>
                                <td>
                                    <input type="text" name="evazar_opt_home_hero_title" value="<?php echo esc_attr($home_hero_title); ?>" class="large-text">
                                </td>
                            </tr>
                            <tr>
                                <th>زیرعنوان و توضیحات هیرو</th>
                                <td>
                                    <textarea name="evazar_opt_home_hero_subtitle" rows="3" class="large-text"><?php echo esc_textarea($home_hero_subtitle); ?></textarea>
                                </td>
                            </tr>
                            <tr>
                                <th>تعداد کالاهای صفحه اصلی</th>
                                <td>
                                    <input type="number" name="evazar_opt_home_product_count" value="<?php echo esc_attr($home_product_count); ?>" min="4" max="48" style="width: 80px;"> کالا
                                    <label style="margin-right: 18px;"><input type="checkbox" name="evazar_opt_home_hide_outofstock" value="1" <?php checked($home_hide_outofstock, '1'); ?>> عدم نمایش محصولات ناموجود در لیست کلی</label>
                                </td>
                            </tr>
                            <tr style="border-top: 2px solid #0284c7; background: #f8fafc;">
                                <th style="color: #0369a1; padding: 18px 12px;">
                                    🔄 مدیریت ترتیب چیدمان و فعال‌سازی المان‌های صفحه اصلی<br>
                                    <small style="font-weight: normal; color: #64748b;">(با دکمه‌های بالا/پایین ترتیب قرارگیری هر بخش را مشخص کنید)</small>
                                </th>
                                <td style="padding: 18px 12px;">
                                    <div id="evz-sections-sorter" style="max-width: 650px; background: #ffffff; border: 1px solid #cbd5e1; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
                                        <?php 
                                        $sections_meta_info = [
                                            'hero' => [
                                                'title' => '🚀 بنر هیرو و موتور جستجوی کالا',
                                                'desc'  => 'کادر اصلی بالای صفحه همراه با عنوان معرفی و باکس جستجو',
                                                'toggle_name' => '', // Always active or controlled by title
                                            ],
                                            'deals' => [
                                                'title' => '🔥 بخش محصولات تخفیف شگفت‌انگیز (اسلایدر ریل اتوماتیک)',
                                                'desc'  => 'کارت لید شگفت‌انگیز با اسلایدر افقی تخفیف‌ها',
                                                'toggle_name' => 'evazar_opt_home_show_deals',
                                                'is_active' => ($home_show_deals === '1'),
                                            ],
                                            'categories' => [
                                                'title' => '📁 دسته‌بندی‌های برگزیده (کارت‌های آیکونی مدرن)',
                                                'desc'  => 'گرید آیکون‌های گرد دسته‌بندی‌های اصلی کالا',
                                                'toggle_name' => 'evazar_opt_home_show_categories',
                                                'is_active' => ($home_show_cats === '1'),
                                            ],
                                            'brands' => [
                                                'title' => '🏷️ برندهای برتر و معتبر (اسلایدر لوگوها)',
                                                'desc'  => 'نوار اسکرول برندهای معتبر کالا',
                                                'toggle_name' => 'evazar_opt_home_show_brands',
                                                'is_active' => ($home_show_brands === '1'),
                                            ],
                                            'cat_showcase' => [
                                                'title' => '🗂️ ویترین کالاهای چنددسته‌ای (تب‌دار یا قفسه‌های موضوعی)',
                                                'desc'  => 'لیست محصولات تفکیک‌شده بر اساس دسته‌بندی با قابلیت تب یا قفسه',
                                                'toggle_name' => 'evazar_opt_home_show_cat_showcase',
                                                'is_active' => ($home_show_cat_showcase === '1'),
                                            ],
                                            'latest_products' => [
                                                'title' => '✨ بخش مستقل جدیدترین کالاها (اسلایدر محصولات)',
                                                'desc'  => 'ردیف مجزا برای نمایش جدیدترین کالاها یا یک دسته دلخواه',
                                                'toggle_name' => 'evazar_opt_home_show_latest',
                                                'is_active' => ($home_show_latest === '1'),
                                            ],
                                        ];

                                        foreach ($home_sections_order as $sec_idx => $s_key):
                                            if (!isset($sections_meta_info[$s_key])) continue;
                                            $s_info = $sections_meta_info[$s_key];
                                        ?>
                                        <div class="evz-sort-row" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; border-bottom: 1px solid #f1f5f9; background: <?php echo ($sec_idx % 2 === 0) ? '#ffffff' : '#fcfcfd'; ?>;">
                                            <input type="hidden" name="evazar_opt_home_sections_order[]" value="<?php echo esc_attr($s_key); ?>">
                                            <div style="display: flex; align-items: center; gap: 12px;">
                                                <div style="display: flex; flex-direction: column; gap: 2px;">
                                                    <button type="button" class="button button-small evz-btn-up" title="انتقال به بالا" style="padding: 0 6px; height: 22px; line-height: 20px;">▲</button>
                                                    <button type="button" class="button button-small evz-btn-down" title="انتقال به پایین" style="padding: 0 6px; height: 22px; line-height: 20px;">▼</button>
                                                </div>
                                                <div>
                                                    <strong style="font-size: 13px; color: #1e293b;"><?php echo esc_html($s_info['title']); ?></strong>
                                                    <div style="font-size: 11px; color: #64748b; margin-top: 2px;"><?php echo esc_html($s_info['desc']); ?></div>
                                                </div>
                                            </div>
                                            <div>
                                                <?php if (!empty($s_info['toggle_name'])): ?>
                                                    <label style="font-size: 12px; font-weight: 600; cursor: pointer; color: #0f172a;">
                                                        <input type="checkbox" name="<?php echo esc_attr($s_info['toggle_name']); ?>" value="1" <?php checked($s_info['is_active']); ?>> فعال
                                                    </label>
                                                <?php else: ?>
                                                    <span style="font-size: 11px; color: #10b981; font-weight: 700; background: #ecfdf5; padding: 2px 8px; border-radius: 4px;">همیشه فعال</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <p class="description" style="margin-top: 8px;">نکته: با زدن دکمه‌های ▲ و ▼ ترتیب چیدمان المان‌های صفحه اصلی جابه‌جا شده و پس از «ذخیره تغییرات» بلافاصله در فرانت‌اِند اعمال می‌گردد.</p>
                                    <script>
                                    document.addEventListener('DOMContentLoaded', function() {
                                        var sorter = document.getElementById('evz-sections-sorter');
                                        if (!sorter) return;
                                        sorter.addEventListener('click', function(e) {
                                            var row = e.target.closest('.evz-sort-row');
                                            if (!row) return;
                                            if (e.target.classList.contains('evz-btn-up')) {
                                                e.preventDefault();
                                                var prev = row.previousElementSibling;
                                                if (prev && prev.classList.contains('evz-sort-row')) {
                                                    sorter.insertBefore(row, prev);
                                                }
                                            } else if (e.target.classList.contains('evz-btn-down')) {
                                                e.preventDefault();
                                                var next = row.nextElementSibling;
                                                if (next && next.classList.contains('evz-sort-row')) {
                                                    sorter.insertBefore(next, row);
                                                }
                                            }
                                        });
                                    });
                                    </script>
                                </td>
                            </tr>
                            
                            <!-- تنظیمات اختصاصی دسته‌بندی‌های برگزیده -->
                            <tr style="border-top: 1px solid #e2e8f0;">
                                <th style="color: #ef394e;">📁 مدیریت دسته‌بندی‌های برگزیده</th>
                                <td>
                                    <p><strong>عنوان بخش:</strong></p>
                                    <input type="text" name="evazar_opt_home_cats_title" value="<?php echo esc_attr($home_cats_title); ?>" class="regular-text" style="width: 100%; max-width: 400px; margin-bottom: 12px;">
                                    
                                    <p><strong>نحوه انتخاب دسته‌بندی‌ها:</strong></p>
                                    <label style="margin-left: 20px;"><input type="radio" name="evazar_opt_home_cats_mode" value="auto" <?php checked($home_cats_mode, 'auto'); ?>> خودکار (دسته‌های سطح اول دارای بیشترین تعداد کالا)</label>
                                    <label><input type="radio" name="evazar_opt_home_cats_mode" value="custom" <?php checked($home_cats_mode, 'custom'); ?>> انتخاب دستی دسته‌ها</label>
                                    
                                    <div style="margin-top: 12px;">
                                        <label>تعداد دسته‌ها در حالت خودکار: 
                                            <input type="number" name="evazar_opt_home_cats_count" value="<?php echo esc_attr($home_cats_count); ?>" min="3" max="24" style="width: 70px;">
                                        </label>
                                    </div>
                                    
                                    <p style="margin-top: 14px; margin-bottom: 6px;"><strong>دسته‌بندی‌های انتخابی (در صورت فعال بودن حالت انتخاب دستی):</strong></p>
                                    <div style="max-height: 180px; overflow-y: auto; background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px 14px; max-width: 600px;">
                                        <?php 
                                        $all_parent_cats = get_terms([
                                            'taxonomy'   => 'evazar_category',
                                            'parent'     => 0,
                                            'hide_empty' => false,
                                            'orderby'    => 'count',
                                            'order'      => 'DESC',
                                        ]);
                                        if (!empty($all_parent_cats) && !is_wp_error($all_parent_cats)):
                                            $sel_cat_ids = is_array($home_cats_selected) ? $home_cats_selected : [];
                                            foreach ($all_parent_cats as $p_cat):
                                                $is_chk = in_array($p_cat->term_id, $sel_cat_ids);
                                        ?>
                                            <label style="display: block; margin-bottom: 6px; font-size: 13px;">
                                                <input type="checkbox" name="evazar_opt_home_cats_selected[]" value="<?php echo esc_attr($p_cat->term_id); ?>" <?php checked($is_chk); ?>>
                                                <?php echo esc_html($p_cat->name); ?> 
                                                <span style="color: #64748b; font-size: 11px;">(<?php echo evazar_to_fa_num($p_cat->count); ?> کالا)</span>
                                            </label>
                                        <?php endforeach; else: ?>
                                            <p style="color: #94a3b8; font-size: 12px; margin: 0;">دسته‌بندی‌ای یافت نشد.</p>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>

                            <!-- تنظیمات اختصاصی برندهای برتر و معتبر -->
                            <tr style="border-top: 1px solid #e2e8f0;">
                                <th style="color: #0284c7;">🏷️ مدیریت برندهای برتر صفحه اصلی</th>
                                <td>
                                    <p><strong>عنوان بخش:</strong></p>
                                    <input type="text" name="evazar_opt_home_brands_title" value="<?php echo esc_attr($home_brands_title); ?>" class="regular-text" style="width: 100%; max-width: 400px; margin-bottom: 12px;">
                                    
                                    <p><strong>نحوه انتخاب برندها:</strong></p>
                                    <label style="margin-left: 20px;"><input type="radio" name="evazar_opt_home_brands_mode" value="auto" <?php checked($home_brands_mode, 'auto'); ?>> خودکار (برندهای دارای بیشترین تعداد کالا)</label>
                                    <label><input type="radio" name="evazar_opt_home_brands_mode" value="custom" <?php checked($home_brands_mode, 'custom'); ?>> انتخاب دستی برندها</label>
                                    
                                    <div style="margin-top: 12px;">
                                        <label>تعداد برندها در حالت خودکار: 
                                            <input type="number" name="evazar_opt_home_brands_count" value="<?php echo esc_attr($home_brands_count); ?>" min="4" max="30" style="width: 70px;">
                                        </label>
                                    </div>
                                    
                                    <p style="margin-top: 14px; margin-bottom: 6px;"><strong>برندهای انتخابی (در صورت فعال بودن حالت انتخاب دستی):</strong></p>
                                    <div style="max-height: 180px; overflow-y: auto; background: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px 14px; max-width: 600px;">
                                        <?php 
                                        $all_top_brands = get_terms([
                                            'taxonomy'   => 'evazar_brand',
                                            'hide_empty' => false,
                                            'orderby'    => 'count',
                                            'order'      => 'DESC',
                                            'number'     => 60,
                                        ]);
                                        if (!empty($all_top_brands) && !is_wp_error($all_top_brands)):
                                            $sel_brand_ids = is_array($home_brands_selected) ? $home_brands_selected : [];
                                            foreach ($all_top_brands as $p_brand):
                                                $is_b_chk = in_array($p_brand->term_id, $sel_brand_ids);
                                        ?>
                                            <label style="display: block; margin-bottom: 6px; font-size: 13px;">
                                                <input type="checkbox" name="evazar_opt_home_brands_selected[]" value="<?php echo esc_attr($p_brand->term_id); ?>" <?php checked($is_b_chk); ?>>
                                                <?php echo esc_html($p_brand->name); ?> 
                                                <span style="color: #64748b; font-size: 11px;">(<?php echo evazar_to_fa_num($p_brand->count); ?> کالا)</span>
                                            </label>
                                        <?php endforeach; else: ?>
                                            <p style="color: #94a3b8; font-size: 12px; margin: 0;">برندی یافت نشد.</p>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>

                            <!-- تنظیمات اختصاصی بخش محصولات تخفیف‌دار و شگفت‌انگیز -->
                            <tr style="border-top: 2px solid #ef394e; background: #fff5f5;">
                                <th style="color: #d32f2f; padding-top: 18px;">
                                    🔥 بخش شگفت‌انگیز و تخفیف‌ها<br>
                                    <small style="font-weight: normal; color: #64748b;">(اسلایدر خودکار بدون تایمر)</small>
                                </th>
                                <td style="padding-top: 18px;">
                                    <p><strong>عنوان باکس شگفت‌انگیز:</strong></p>
                                    <input type="text" name="evazar_opt_home_deals_title" value="<?php echo esc_attr($home_deals_title); ?>" class="regular-text" style="width: 100%; max-width: 400px; margin-bottom: 12px;">
                                    
                                    <div style="display: flex; gap: 24px; flex-wrap: wrap; margin-bottom: 12px;">
                                        <label>تعداد کالا در اسلایدر شگفت‌انگیز: 
                                            <input type="number" name="evazar_opt_home_deals_count" value="<?php echo esc_attr($home_deals_count); ?>" min="4" max="30" style="width: 70px;">
                                        </label>
                                        <label>حداقل درصد تخفیف برای نمایش: 
                                            <input type="number" name="evazar_opt_home_deals_min_discount" value="<?php echo esc_attr($home_deals_min_discount); ?>" min="0" max="90" style="width: 70px;"> ٪
                                        </label>
                                    </div>

                                    <p style="margin-bottom: 8px;"><strong>لینک دکمه «مشاهده همه تخفیف‌ها»:</strong></p>
                                    <input type="text" name="evazar_opt_home_deals_link" value="<?php echo esc_attr($home_deals_link); ?>" class="regular-text" style="width: 100%; max-width: 400px; margin-bottom: 12px;" placeholder="/?on_sale=1">
                                    <p class="description" style="margin-top: -6px; margin-bottom: 12px;">پیش‌فرض: <code>/?on_sale=1</code> (هدایت مستقیم به صفحه تمام کالاهای تخفیف‌دار).</p>

                                    <label style="display: block; font-weight: 600; color: #b91c1c;">
                                        <input type="checkbox" name="evazar_opt_home_deals_hide_outofstock" value="1" <?php checked($home_deals_hide_outofstock, '1'); ?>>
                                        عدم نمایش کالاهای ناموجود در بخش شگفت‌انگیز (فقط کالاهای موجود نمایش داده شوند)
                                    </label>
                                </td>
                            </tr>

                            <!-- تنظیمات اختصاصی بخش لیست محصولات دسته‌بندی‌ها -->
                            <tr style="border-top: 2px solid #0284c7; background: #f0f9ff;">
                                <th style="color: #0369a1; padding-top: 18px;">
                                    🗂️ لیست محصولات دسته‌بندی‌ها<br>
                                    <small style="font-weight: normal; color: #64748b;">(تب‌دار یا قفسه‌های مجزا)</small>
                                </th>
                                <td style="padding-top: 18px;">
                                    <p><strong>عنوان اصلی این بخش:</strong></p>
                                    <input type="text" name="evazar_opt_home_cat_showcase_title" value="<?php echo esc_attr($home_cat_showcase_title); ?>" class="regular-text" style="width: 100%; max-width: 400px; margin-bottom: 12px;">

                                    <p><strong>نوع چیدمان در صفحه اصلی:</strong></p>
                                    <label style="margin-left: 20px;">
                                        <input type="radio" name="evazar_opt_home_cat_showcase_type" value="tabs" <?php checked($home_cat_showcase_type, 'tabs'); ?>>
                                        <strong>شوکیس تب‌دار هوشمند (Tabs):</strong> همه دسته‌ها در یک کادر جمع‌وجور با تب‌های تعاملی بدون رفرش صفحه (صرفه‌جویی در فضای صفحه)
                                    </label><br>
                                    <label style="display: inline-block; margin-top: 6px; margin-bottom: 12px;">
                                        <input type="radio" name="evazar_opt_home_cat_showcase_type" value="shelves" <?php checked($home_cat_showcase_type, 'shelves'); ?>>
                                        <strong>قفسه‌های تفکیک‌شده (Shelves):</strong> هر دسته به صورت یک ردیف اسلایدر مستقل با هدر مجزا در صفحه اصلی
                                    </label>

                                    <div style="display: flex; gap: 24px; flex-wrap: wrap; margin-bottom: 12px; margin-top: 8px;">
                                        <label>تعداد کالا در هر دسته: 
                                            <input type="number" name="evazar_opt_home_cat_showcase_count" value="<?php echo esc_attr($home_cat_showcase_count); ?>" min="4" max="24" style="width: 70px;">
                                        </label>
                                        <label>مرتب‌سازی محصولات هر دسته: 
                                            <select name="evazar_opt_home_cat_showcase_orderby" style="margin-right: 6px;">
                                                <option value="date" <?php selected($home_cat_showcase_orderby, 'date'); ?>>جدیدترین محصولات</option>
                                                <option value="rating" <?php selected($home_cat_showcase_orderby, 'rating'); ?>>پرفروش‌ترین و بیشترین امتیاز</option>
                                                <option value="discount" <?php selected($home_cat_showcase_orderby, 'discount'); ?>>بیشترین درصد تخفیف</option>
                                            </select>
                                        </label>
                                    </div>

                                    <div style="margin-top: 14px; padding-top: 10px; border-top: 1px dashed #cbd5e1;">
                                        <label style="font-weight: 700; color: #0284c7;">
                                            <input type="checkbox" name="evazar_opt_home_cat_showcase_include_latest" value="1" <?php checked($home_cat_showcase_include_latest, '1'); ?>>
                                            ⚡ افزودن تب «جدیدترین کالاها» در ابتدای تب‌های این بخش (نمایش محصولات جدید همه دسته‌ها در تب اول)
                                        </label>
                                    </div>
                                </td>
                            </tr>

                            <!-- تنظیمات اختصاصی بخش جدیدترین کالاها -->
                            <tr style="border-top: 2px solid #10b981; background: #f0fdf4;">
                                <th style="color: #047857; padding-top: 18px;">
                                    ✨ بخش مستقل جدیدترین کالاها<br>
                                    <small style="font-weight: normal; color: #64748b;">(اسلایدر مستقل محصولات)</small>
                                </th>
                                <td style="padding-top: 18px;">
                                    <p><strong>عنوان این بخش در صفحه اصلی:</strong></p>
                                    <input type="text" name="evazar_opt_home_latest_title" value="<?php echo esc_attr($home_latest_title); ?>" class="regular-text" style="width: 100%; max-width: 400px; margin-bottom: 12px;">

                                    <div style="display: flex; gap: 24px; flex-wrap: wrap; margin-bottom: 12px;">
                                        <label>تعداد کالا در این بخش: 
                                            <input type="number" name="evazar_opt_home_latest_count" value="<?php echo esc_attr($home_latest_count); ?>" min="4" max="30" style="width: 70px;">
                                        </label>
                                        <label>فیلتر بر اساس دسته خاص: 
                                            <select name="evazar_opt_home_latest_cat" style="margin-right: 6px;">
                                                <option value="0" <?php selected($home_latest_cat, 0); ?>>همه دسته‌بندی‌ها (جدیدترین کل سایت)</option>
                                                <?php 
                                                if (!empty($all_parent_cats) && !is_wp_error($all_parent_cats)) {
                                                    foreach ($all_parent_cats as $p_cat) {
                                                        echo '<option value="' . esc_attr($p_cat->term_id) . '" ' . selected($home_latest_cat, $p_cat->term_id, false) . '>' . esc_html($p_cat->name) . '</option>';
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </label>
                                    </div>

                                    <label style="display: block; font-weight: 600; color: #047857;">
                                        <input type="checkbox" name="evazar_opt_home_latest_hide_oos" value="1" <?php checked($home_latest_hide_oos, '1'); ?>>
                                        عدم نمایش کالاهای ناموجود در بخش جدیدترین‌ها
                                    </label>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- تب درباره ما -->
                    <div id="tab-about" class="tab-content <?php echo ($active_tab === '#tab-about') ? 'active' : ''; ?>" style="<?php echo ($active_tab === '#tab-about') ? '' : 'display: none;'; ?>">
                        <h2 class="tab-title">ℹ️ مدیریت کامل محتوای برگه درباره ما (مدل ۱: پلتفرم شفاف همکاری در فروش)</h2>
                        
                        <?php
                        $about_url = function_exists('evazar_get_about_page_url') ? evazar_get_about_page_url() : home_url('/about/');
                        ?>
                        <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 16px 20px; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 14px;">
                            <div>
                                <strong style="color: #166534; font-size: 14px; display: flex; align-items: center; gap: 6px;">
                                    <span>🔗 پیوند فعال و زنده برگه درباره ما در سایت:</span>
                                </strong>
                                <div style="direction: ltr; text-align: right; margin-top: 5px;">
                                    <a href="<?php echo esc_url($about_url); ?>" target="_blank" style="color: #15803d; font-weight: 700; font-size: 14px; text-decoration: underline;"><?php echo esc_html($about_url); ?></a>
                                </div>
                                <span style="color: #64748b; font-size: 12px; margin-top: 4px; display: block;">این برگه به صورت خودکار با قالب اختصاصی ساخته شده و در مسیر پیشخوان > برگه‌ها نیز در دسترس شماست.</span>
                            </div>
                            <a href="<?php echo esc_url($about_url); ?>" target="_blank" class="button button-primary" style="background: #16a34a; border-color: #15803d; font-weight: bold; padding: 6px 16px;">مشاهده زنده برگه درباره ما ↗</a>
                        </div>
                        
                        <table class="form-table">
                            <tr>
                                <th>بخش هیرو (Hero Banner)</th>
                                <td>
                                    نشان بالای عنوان:
                                    <input type="text" name="evazar_opt_about_hero_badge" value="<?php echo esc_attr($about_hero_badge); ?>" class="large-text">
                                    <br><br>
                                    عنوان اصلی صفحه درباره ما:
                                    <input type="text" name="evazar_opt_about_hero_title" value="<?php echo esc_attr($about_hero_title); ?>" class="large-text">
                                    <br><br>
                                    توضیحات و رسالت ایوازار:
                                    <textarea name="evazar_opt_about_hero_desc" rows="3" class="large-text"><?php echo esc_textarea($about_hero_desc); ?></textarea>
                                </td>
                            </tr>
                            <tr>
                                <th>کارت‌های ۴گانه آمار کلیدی</th>
                                <td>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; max-width: 700px;">
                                        <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; border-radius: 8px;">
                                            <strong>آمار ۱:</strong><br>
                                            عدد: <input type="text" name="evazar_opt_about_stat1_num" value="<?php echo esc_attr($about_stat1_num); ?>" style="width: 100px;">
                                            عنوان: <input type="text" name="evazar_opt_about_stat1_txt" value="<?php echo esc_attr($about_stat1_txt); ?>" style="width: 180px;">
                                        </div>
                                        <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; border-radius: 8px;">
                                            <strong>آمار ۲:</strong><br>
                                            عدد: <input type="text" name="evazar_opt_about_stat2_num" value="<?php echo esc_attr($about_stat2_num); ?>" style="width: 100px;">
                                            عنوان: <input type="text" name="evazar_opt_about_stat2_txt" value="<?php echo esc_attr($about_stat2_txt); ?>" style="width: 180px;">
                                        </div>
                                        <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; border-radius: 8px;">
                                            <strong>آمار ۳:</strong><br>
                                            عدد: <input type="text" name="evazar_opt_about_stat3_num" value="<?php echo esc_attr($about_stat3_num); ?>" style="width: 100px;">
                                            عنوان: <input type="text" name="evazar_opt_about_stat3_txt" value="<?php echo esc_attr($about_stat3_txt); ?>" style="width: 180px;">
                                        </div>
                                        <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 10px; border-radius: 8px;">
                                            <strong>آمار ۴:</strong><br>
                                            عدد: <input type="text" name="evazar_opt_about_stat4_num" value="<?php echo esc_attr($about_stat4_num); ?>" style="width: 100px;">
                                            عنوان: <input type="text" name="evazar_opt_about_stat4_txt" value="<?php echo esc_attr($about_stat4_txt); ?>" style="width: 180px;">
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>بیانیه شفافیت در افیلیت (Affiliate Disclosure)</th>
                                <td>
                                    عنوان بیانیه:
                                    <input type="text" name="evazar_opt_about_disclosure_title" value="<?php echo esc_attr($about_disclosure_title); ?>" class="large-text">
                                    <br><br>
                                    متن بیانیه شفافیت مالی:
                                    <textarea name="evazar_opt_about_disclosure_text" rows="5" class="large-text"><?php echo esc_textarea($about_disclosure_text); ?></textarea>
                                </td>
                            </tr>
                            <tr>
                                <th>بخش سوالات متداول (FAQ Accordion)</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_about_faq_enable" value="1" <?php checked($about_faq_enable, '1'); ?>> نمایش بخش سوالات متداول در برگه درباره ما</label>
                                    <br><br>
                                    عنوان بخش:
                                    <input type="text" name="evazar_opt_about_faq_title" value="<?php echo esc_attr($about_faq_title); ?>" class="large-text">
                                    <br><br>
                                    لیست سوالات و پاسخ‌ها (هر سطر یک مورد، سوال و پاسخ را با علامت <code>|</code> جدا کنید):
                                    <textarea name="evazar_opt_about_faq_items" rows="7" class="large-text" style="font-family: monospace; font-size: 13px;"><?php echo esc_textarea($about_faq_items); ?></textarea>
                                    <p class="description">مثال: <code>آیا خرید هزینه اضافی دارد؟ | خیر، شما دقیقا با همان قیمت دیجی‌کالا خرید می‌کنید.</code></p>
                                </td>
                            </tr>
                            <tr>
                                <th>بنر پایانی دعوت به اقدام (CTA)</th>
                                <td>
                                    عنوان بنر:
                                    <input type="text" name="evazar_opt_about_cta_title" value="<?php echo esc_attr($about_cta_title); ?>" class="large-text">
                                    <br><br>
                                    توضیحات:
                                    <textarea name="evazar_opt_about_cta_desc" rows="2" class="large-text"><?php echo esc_textarea($about_cta_desc); ?></textarea>
                                    <br><br>
                                    متن دکمه:
                                    <input type="text" name="evazar_opt_about_cta_btn" value="<?php echo esc_attr($about_cta_btn); ?>" class="regular-text">
                                    &nbsp;&nbsp;
                                    لینک دکمه:
                                    <input type="text" name="evazar_opt_about_cta_link" value="<?php echo esc_attr($about_cta_link); ?>" class="regular-text" placeholder="https://...">
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- تب خطای ۴۰۴ -->
                    <div id="tab-404" class="tab-content <?php echo ($active_tab === '#tab-404') ? 'active' : ''; ?>" style="<?php echo ($active_tab === '#tab-404') ? '' : 'display: none;'; ?>">
                        <h2 class="tab-title">🚫 تنظیمات برگه خطای ۴۰۴ (مدل ۱: مینیمال مدرن با سرچ هوشمند)</h2>
                        
                        <table class="form-table">
                            <tr>
                                <th>پیام صفحه ۴۰۴</th>
                                <td>
                                    <strong>عنوان تب مرورگر و سئو (Browser Tab Title):</strong>
                                    <input type="text" name="evazar_opt_404_tab_title" value="<?php echo esc_attr($opt_404_tab_title); ?>" class="large-text">
                                    <p class="description" style="margin-bottom: 18px;">این عنوان در تب مرورگر و نتایج جستجوی گوگل جایگزین عنوان انگلیسی «Page Not Found» می‌شود.</p>

                                    <strong>عنوان اصلی داخل صفحه (H1):</strong>
                                    <input type="text" name="evazar_opt_404_title" value="<?php echo esc_attr($opt_404_title); ?>" class="large-text">
                                    <br><br>
                                    <strong>توضیحات و راهنمایی کاربر:</strong>
                                    <textarea name="evazar_opt_404_subtitle" rows="3" class="large-text"><?php echo esc_textarea($opt_404_subtitle); ?></textarea>
                                    <p class="description">این برگه به صورت خودکار به ماژول لایو سرچ هوشمند و کپسول‌های دسترسی سریع به کاتالوگ مجهز است.</p>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- تب ۶: مدیریت فوتر -->
                    <div id="tab-footer" class="tab-content <?php echo ($active_tab === '#tab-footer') ? 'active' : ''; ?>" style="<?php echo ($active_tab === '#tab-footer') ? '' : 'display: none;'; ?>">
                        <h2 class="tab-title">📑 مدیریت بخش‌های فوتر، اطلاعات تماس و اعتمادسازی</h2>
                        
                        <table class="form-table">
                            <tr>
                                <th>نوار مزایای خرید و اعتمادسازی (Trust Bar)</th>
                                <td>
                                    <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; margin-bottom: 16px;">
                                        <div style="display: flex; gap: 24px; flex-wrap: wrap; align-items: center; margin-bottom: 18px; padding-bottom: 14px; border-bottom: 1px solid #e2e8f0;">
                                            <label style="font-weight: 700; color: #0f172a;">
                                                <input type="checkbox" name="evazar_opt_footer_show_trust_bar" value="1" <?php checked($footer_show_trust_bar, '1'); ?>>
                                                نمایش سراسری نوار مزایای ۴گانه بالای فوتر
                                            </label>
                                            
                                            <label style="font-weight: 700; color: #0f172a; background: #fff; padding: 4px 12px; border-radius: 8px; border: 1px solid #cbd5e1;">
                                                <input type="checkbox" name="evazar_opt_trust_bar_mobile" value="1" <?php checked($trust_bar_mobile, '1'); ?>>
                                                📱 نمایش در نسخه موبایل و تبلت (در صورت خاموش بودن، در موبایل مخفی می‌شود)
                                            </label>

                                            <div style="display: flex; align-items: center; gap: 8px;">
                                                <span style="font-weight: 700; font-size: 13px;">سبک طراحی:</span>
                                                <select name="evazar_opt_trust_bar_style" style="border-radius: 8px; font-weight: 600;">
                                                    <option value="line" <?php selected($trust_bar_style, 'line'); ?>>💎 مدل ۱: مدرن خطی دو رنگ (Digikala Line Pro)</option>
                                                    <option value="gradient" <?php selected($trust_bar_style, 'gradient'); ?>>🚀 مدل ۲: آیکون‌های سه‌بعدی نرم (Soft 3D Glow)</option>
                                                    <option value="glass" <?php selected($trust_bar_style, 'glass'); ?>>✨ مدل ۳: کارت‌های مینیمال با حاشیه شناور (Minimal Border)</option>
                                                </select>
                                            </div>
                                        </div>

                                        <p class="description" style="margin-bottom: 16px;">تنظیمات و متون هر یک از ۴ بلوک اعتماد. در صورتی که فیلد لینک را پر کنید، کارت به صورت دکمه تعاملی و قابل کلیک نمایش داده می‌شود:</p>

                                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 14px;">
                                            <!-- بلوک ۱ -->
                                            <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 14px;">
                                                <div style="font-weight: 800; font-size: 13px; color: #0f172a; margin-bottom: 8px; display: flex; justify-content: space-between;">
                                                    <span>بلوک ۱</span>
                                                    <select name="evazar_opt_trust_item_1_icon" style="font-size: 12px;">
                                                        <option value="shield" <?php selected($trust_item_1_icon, 'shield'); ?>>🛡️ سپر / اصالت</option>
                                                        <option value="zap" <?php selected($trust_item_1_icon, 'zap'); ?>>⚡ آذرخش / قیمت</option>
                                                        <option value="ai" <?php selected($trust_item_1_icon, 'ai'); ?>>🤖 هوش مصنوعی</option>
                                                        <option value="lock" <?php selected($trust_item_1_icon, 'lock'); ?>>🔒 قفل / پرداخت</option>
                                                        <option value="truck" <?php selected($trust_item_1_icon, 'truck'); ?>>🚚 ارسال سریع</option>
                                                        <option value="return" <?php selected($trust_item_1_icon, 'return'); ?>>🔄 بازگشت کالا</option>
                                                        <option value="support" <?php selected($trust_item_1_icon, 'support'); ?>>🎧 پشتیبانی</option>
                                                        <option value="star" <?php selected($trust_item_1_icon, 'star'); ?>>⭐ کیفیت برتر</option>
                                                    </select>
                                                </div>
                                                <input type="text" name="evazar_opt_trust_item_1_title" value="<?php echo esc_attr($trust_item_1_title); ?>" placeholder="عنوان بلوک" style="width: 100%; margin-bottom: 6px; font-weight: 700;">
                                                <input type="text" name="evazar_opt_trust_item_1_sub" value="<?php echo esc_attr($trust_item_1_sub); ?>" placeholder="توضیح کوتاه" style="width: 100%; margin-bottom: 6px; font-size: 12px;">
                                                <input type="text" name="evazar_opt_trust_item_1_link" value="<?php echo esc_attr($trust_item_1_link); ?>" placeholder="لینک (https://...)" style="width: 100%; font-size: 11px; direction: ltr;">
                                            </div>

                                            <!-- بلوک ۲ -->
                                            <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 14px;">
                                                <div style="font-weight: 800; font-size: 13px; color: #0f172a; margin-bottom: 8px; display: flex; justify-content: space-between;">
                                                    <span>بلوک ۲</span>
                                                    <select name="evazar_opt_trust_item_2_icon" style="font-size: 12px;">
                                                        <option value="shield" <?php selected($trust_item_2_icon, 'shield'); ?>>🛡️ سپر / اصالت</option>
                                                        <option value="zap" <?php selected($trust_item_2_icon, 'zap'); ?>>⚡ آذرخش / قیمت</option>
                                                        <option value="ai" <?php selected($trust_item_2_icon, 'ai'); ?>>🤖 هوش مصنوعی</option>
                                                        <option value="lock" <?php selected($trust_item_2_icon, 'lock'); ?>>🔒 قفل / پرداخت</option>
                                                        <option value="truck" <?php selected($trust_item_2_icon, 'truck'); ?>>🚚 ارسال سریع</option>
                                                        <option value="return" <?php selected($trust_item_2_icon, 'return'); ?>>🔄 بازگشت کالا</option>
                                                        <option value="support" <?php selected($trust_item_2_icon, 'support'); ?>>🎧 پشتیبانی</option>
                                                        <option value="star" <?php selected($trust_item_2_icon, 'star'); ?>>⭐ کیفیت برتر</option>
                                                    </select>
                                                </div>
                                                <input type="text" name="evazar_opt_trust_item_2_title" value="<?php echo esc_attr($trust_item_2_title); ?>" placeholder="عنوان بلوک" style="width: 100%; margin-bottom: 6px; font-weight: 700;">
                                                <input type="text" name="evazar_opt_trust_item_2_sub" value="<?php echo esc_attr($trust_item_2_sub); ?>" placeholder="توضیح کوتاه" style="width: 100%; margin-bottom: 6px; font-size: 12px;">
                                                <input type="text" name="evazar_opt_trust_item_2_link" value="<?php echo esc_attr($trust_item_2_link); ?>" placeholder="لینک (https://...)" style="width: 100%; font-size: 11px; direction: ltr;">
                                            </div>

                                            <!-- بلوک ۳ -->
                                            <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 14px;">
                                                <div style="font-weight: 800; font-size: 13px; color: #0f172a; margin-bottom: 8px; display: flex; justify-content: space-between;">
                                                    <span>بلوک ۳</span>
                                                    <select name="evazar_opt_trust_item_3_icon" style="font-size: 12px;">
                                                        <option value="shield" <?php selected($trust_item_3_icon, 'shield'); ?>>🛡️ سپر / اصالت</option>
                                                        <option value="zap" <?php selected($trust_item_3_icon, 'zap'); ?>>⚡ آذرخش / قیمت</option>
                                                        <option value="ai" <?php selected($trust_item_3_icon, 'ai'); ?>>🤖 هوش مصنوعی</option>
                                                        <option value="lock" <?php selected($trust_item_3_icon, 'lock'); ?>>🔒 قفل / پرداخت</option>
                                                        <option value="truck" <?php selected($trust_item_3_icon, 'truck'); ?>>🚚 ارسال سریع</option>
                                                        <option value="return" <?php selected($trust_item_3_icon, 'return'); ?>>🔄 بازگشت کالا</option>
                                                        <option value="support" <?php selected($trust_item_3_icon, 'support'); ?>>🎧 پشتیبانی</option>
                                                        <option value="star" <?php selected($trust_item_3_icon, 'star'); ?>>⭐ کیفیت برتر</option>
                                                    </select>
                                                </div>
                                                <input type="text" name="evazar_opt_trust_item_3_title" value="<?php echo esc_attr($trust_item_3_title); ?>" placeholder="عنوان بلوک" style="width: 100%; margin-bottom: 6px; font-weight: 700;">
                                                <input type="text" name="evazar_opt_trust_item_3_sub" value="<?php echo esc_attr($trust_item_3_sub); ?>" placeholder="توضیح کوتاه" style="width: 100%; margin-bottom: 6px; font-size: 12px;">
                                                <input type="text" name="evazar_opt_trust_item_3_link" value="<?php echo esc_attr($trust_item_3_link); ?>" placeholder="لینک (https://...)" style="width: 100%; font-size: 11px; direction: ltr;">
                                            </div>

                                            <!-- بلوک ۴ -->
                                            <div style="background: #fff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 14px;">
                                                <div style="font-weight: 800; font-size: 13px; color: #0f172a; margin-bottom: 8px; display: flex; justify-content: space-between;">
                                                    <span>بلوک ۴</span>
                                                    <select name="evazar_opt_trust_item_4_icon" style="font-size: 12px;">
                                                        <option value="shield" <?php selected($trust_item_4_icon, 'shield'); ?>>🛡️ سپر / اصالت</option>
                                                        <option value="zap" <?php selected($trust_item_4_icon, 'zap'); ?>>⚡ آذرخش / قیمت</option>
                                                        <option value="ai" <?php selected($trust_item_4_icon, 'ai'); ?>>🤖 هوش مصنوعی</option>
                                                        <option value="lock" <?php selected($trust_item_4_icon, 'lock'); ?>>🔒 قفل / پرداخت</option>
                                                        <option value="truck" <?php selected($trust_item_4_icon, 'truck'); ?>>🚚 ارسال سریع</option>
                                                        <option value="return" <?php selected($trust_item_4_icon, 'return'); ?>>🔄 بازگشت کالا</option>
                                                        <option value="support" <?php selected($trust_item_4_icon, 'support'); ?>>🎧 پشتیبانی</option>
                                                        <option value="star" <?php selected($trust_item_4_icon, 'star'); ?>>⭐ کیفیت برتر</option>
                                                    </select>
                                                </div>
                                                <input type="text" name="evazar_opt_trust_item_4_title" value="<?php echo esc_attr($trust_item_4_title); ?>" placeholder="عنوان بلوک" style="width: 100%; margin-bottom: 6px; font-weight: 700;">
                                                <input type="text" name="evazar_opt_trust_item_4_sub" value="<?php echo esc_attr($trust_item_4_sub); ?>" placeholder="توضیح کوتاه" style="width: 100%; margin-bottom: 6px; font-size: 12px;">
                                                <input type="text" name="evazar_opt_trust_item_4_link" value="<?php echo esc_attr($trust_item_4_link); ?>" placeholder="لینک (https://...)" style="width: 100%; font-size: 11px; direction: ltr;">
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>ستون ۱: درباره ما</th>
                                <td>
                                    عنوان: <input type="text" name="evazar_opt_footer_about_title" value="<?php echo esc_attr($footer_about_title); ?>" class="regular-text"><br><br>
                                    متن توضیحات:
                                    <textarea name="evazar_opt_footer_about_text" rows="4" class="large-text"><?php echo esc_textarea($footer_about_text); ?></textarea>
                                </td>
                            </tr>
                            <tr>
                                <th>ستون ۲: دسته‌بندی‌ها در فوتر</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_footer_show_cats" value="1" <?php checked($footer_show_cats, '1'); ?>> نمایش لیست دسته‌بندی‌های کالا در فوتر</label>
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    تعداد لینک‌ها: <input type="number" name="evazar_opt_footer_cats_count" value="<?php echo esc_attr($footer_cats_count); ?>" min="3" max="15" style="width: 70px;">
                                </td>
                            </tr>
                            <tr>
                                <th>ستون ۳: برندها در فوتر</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_footer_show_brands" value="1" <?php checked($footer_show_brands, '1'); ?>> نمایش لیست برندهای محبوب در فوتر</label>
                                    &nbsp;&nbsp;&nbsp;&nbsp;
                                    تعداد لینک‌ها: <input type="number" name="evazar_opt_footer_brands_count" value="<?php echo esc_attr($footer_brands_count); ?>" min="3" max="15" style="width: 70px;">
                                </td>
                            </tr>
                            <tr>
                                <th>ستون ۴: خرید امن و شفافیت</th>
                                <td>
                                    عنوان: <input type="text" name="evazar_opt_footer_trust_title" value="<?php echo esc_attr($footer_trust_title); ?>" class="regular-text"><br><br>
                                    متن:
                                    <textarea name="evazar_opt_footer_trust_text" rows="3" class="large-text"><?php echo esc_textarea($footer_trust_text); ?></textarea>
                                </td>
                            </tr>
                            <tr>
                                <th>اطلاعات تماس و آدرس</th>
                                <td>
                                    شماره پشتیبانی: <input type="text" name="evazar_opt_footer_phone" value="<?php echo esc_attr($footer_phone); ?>" class="regular-text" style="direction: ltr;"><br><br>
                                    ایمیل پشتیبانی: <input type="email" name="evazar_opt_footer_email" value="<?php echo esc_attr($footer_email); ?>" class="regular-text" style="direction: ltr;"><br><br>
                                    آدرس / ساعات کاری: <input type="text" name="evazar_opt_footer_address" value="<?php echo esc_attr($footer_address); ?>" class="large-text">
                                </td>
                            </tr>
                            <tr>
                                <th>کپی‌رایت و دکمه بالا</th>
                                <td>
                                    متن کپی‌رایت: <input type="text" name="evazar_opt_footer_copyright" value="<?php echo esc_attr($footer_copyright); ?>" class="large-text"><br><br>
                                    <label><input type="checkbox" name="evazar_opt_footer_back_to_top" value="1" <?php checked($footer_back_to_top, '1'); ?>> نمایش دکمه «بازگشت به بالا ↑»</label>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- تب ۷: بهینه‌سازی موبایل -->
                    <div id="tab-mobile" class="tab-content <?php echo ($active_tab === '#tab-mobile') ? 'active' : ''; ?>" style="<?php echo ($active_tab === '#tab-mobile') ? '' : 'display: none;'; ?>">
                        <h2 class="tab-title">📱 تنظیمات اختصاصی تجربه کاربری موبایل (Mobile UX)</h2>
                        
                        <table class="form-table">
                            <tr>
                                <th>نوار چسبان خرید کالا در موبایل</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_sticky_mobile_buybox" value="1" <?php checked($sticky_buybox, '1'); ?>> فعال بودن نوار چسبان قیمت و دکمه خرید در پایین نمایشگر موبایل (افزایش چشمگیر نرخ کلیک و فروش)</label>
                                </td>
                            </tr>
                            <tr>
                                <th>جستجوی موبایل</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_mobile_search_visible" value="1" <?php checked($mobile_search_visible, '1'); ?>> نمایش نوار جستجوی کالاها در صفحات گوشی موبایل</label>
                                </td>
                            </tr>
                            <tr>
                                <th>حالت فوق‌فشرده هدر در موبایل</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_mobile_header_compact" value="1" <?php checked($mobile_header_compact, '1'); ?>> کاهش ارتفاع هدر برای باز شدن حداکثر فضای دید محتوای کالا در گوشی</label>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- تب ۸: سیستم مشاهده بیشتر و محوشدگی متن (Read More) -->
                    <div id="tab-readmore" class="tab-content <?php echo ($active_tab === '#tab-readmore') ? 'active' : ''; ?>" style="<?php echo ($active_tab === '#tab-readmore') ? '' : 'display: none;'; ?>">
                        <h2 class="tab-title">📖 سیستم مشاهده بیشتر و محوشدگی متون (Read More & Text Truncation)</h2>
                        <p style="color: #64748b; font-size: 13.5px; margin-bottom: 20px;">مشابه قالب مبلک، متون طولانی با گرادیان محوشدگی شیشه‌ای و دکمه بازشونده «مشاهده بیشتر / بستن» نمایش داده می‌شوند تا نظم و زیبایی بصری صفحات حفظ شود.</p>
                        
                        <table class="form-table">
                            <tr>
                                <th>فعال‌سازی سراسری سیستم مشاهده بیشتر</th>
                                <td>
                                    <label><input type="checkbox" name="evazar_opt_enable_readmore" value="1" <?php checked($enable_readmore, '1'); ?>> فعال کردن قابلیت خلاصه متون و دکمه تعاملی مشاهده بیشتر در سایت</label>
                                    <p class="description">در صورت خاموش بودن، متون با طول کامل و بدون دکمه مشاهده بیشتر نمایش داده می‌شوند.</p>
                                </td>
                            </tr>
                            <tr>
                                <th>حداکثر ارتفاع در دسکتاپ</th>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap;">
                                        <input type="range" id="range_readmore_desktop_height" min="50" max="800" step="10" value="<?php echo esc_attr($readmore_desktop_height); ?>" oninput="document.getElementById('evazar_opt_readmore_desktop_height').value = this.value" style="width: 200px; accent-color: #ef394e;">
                                        <input type="number" id="evazar_opt_readmore_desktop_height" name="evazar_opt_readmore_desktop_height" value="<?php echo esc_attr($readmore_desktop_height); ?>" min="50" max="800" step="10" oninput="document.getElementById('range_readmore_desktop_height').value = this.value" class="small-text" style="font-weight: 800; text-align: center;"> <span style="font-weight: 700; color: #64748b;">px</span>
                                    </div>
                                    <p class="description">ارتفاعی که بعد از آن متن در مانیتورها و دسکتاپ محو و دکمه مشاهده بیشتر ظاهر می‌شود (پیش‌فرض: 280 پیکسل).</p>
                                </td>
                            </tr>
                            <tr>
                                <th>حداکثر ارتفاع در موبایل و تبلت</th>
                                <td>
                                    <div style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap;">
                                        <input type="range" id="range_readmore_mobile_height" min="50" max="800" step="10" value="<?php echo esc_attr($readmore_mobile_height); ?>" oninput="document.getElementById('evazar_opt_readmore_mobile_height').value = this.value" style="width: 200px; accent-color: #ef394e;">
                                        <input type="number" id="evazar_opt_readmore_mobile_height" name="evazar_opt_readmore_mobile_height" value="<?php echo esc_attr($readmore_mobile_height); ?>" min="50" max="800" step="10" oninput="document.getElementById('range_readmore_mobile_height').value = this.value" class="small-text" style="font-weight: 800; text-align: center;"> <span style="font-weight: 700; color: #64748b;">px</span>
                                    </div>
                                    <p class="description">ارتفاعی که بعد از آن متن در گوشی‌های موبایل محو و کوتاه می‌شود (پیش‌فرض: 200 پیکسل).</p>
                                </td>
                            </tr>
                            <tr>
                                <th>آستانه حداقل کاراکتر</th>
                                <td>
                                    <input type="number" name="evazar_opt_readmore_char_threshold" value="<?php echo esc_attr($readmore_char_threshold); ?>" min="50" max="1000" step="10" class="small-text" style="font-weight: 800; text-align: center;"> <span style="font-weight: 700; color: #64748b;">کاراکتر</span>
                                    <p class="description">تنها در صورتی که طول متن از این تعداد حرف بیشتر باشد، دکمه مشاهده بیشتر ظاهر می‌شود (پیش‌فرض: 220 کاراکتر).</p>
                                </td>
                            </tr>
                            <tr>
                                <th>بخش‌های تحت پوشش</th>
                                <td>
                                    <fieldset style="display: flex; flex-direction: column; gap: 10px;">
                                        <label><input type="checkbox" name="evazar_opt_readmore_product" value="1" <?php checked($readmore_product, '1'); ?>> صفحه تکی محصول (توضیحات کوتاه و نقد و بررسی بلند)</label>
                                        <label><input type="checkbox" name="evazar_opt_readmore_archive" value="1" <?php checked($readmore_archive, '1'); ?>> توضیحات برندها، دسته‌بندی‌ها و آرشیوهای کالا</label>
                                        <label><input type="checkbox" name="evazar_opt_readmore_home" value="1" <?php checked($readmore_home, '1'); ?>> توضیحات و متن معرفی در صفحه اصلی</label>
                                        <label><input type="checkbox" name="evazar_opt_readmore_footer" value="1" <?php checked($readmore_footer, '1'); ?>> متن معرفی و درباره ما در فوتر سایت</label>
                                    </fieldset>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- تب ۹: امکانات هوشمند، CDN و کدها -->
                    <div id="tab-smart" class="tab-content <?php echo ($active_tab === '#tab-smart') ? 'active' : ''; ?>" style="<?php echo ($active_tab === '#tab-smart') ? '' : 'display: none;'; ?>">
                        <h2 class="tab-title">⚡ دامنه کش کلودفلر (CDN) و کدهای اختصاصی</h2>
                        
                        <table class="form-table">
                            <tr>
                                <th>دامنه کش و توزیع تصاویر (Cloudflare Image CDN)</th>
                                <td>
                                    <input type="text" name="evazar_opt_image_cdn_domain" value="<?php echo esc_attr($image_cdn_domain); ?>" class="regular-text" style="direction: ltr;">
                                    <p class="description">آدرس ساب‌دامنه متصل به ورکر کلودفلر (پیش‌فرض: https://img.evazar.ir). کلیه تصاویر محصولات سایت بدون اشغال فضای هاست از این مسیر پرسرعت لود می‌شوند.</p>
                                </td>
                            </tr>
                            <tr>
                                <th>کدهای استایل سفارشی (Custom CSS)</th>
                                <td>
                                    <textarea name="evazar_opt_custom_css" rows="6" class="large-text code" style="direction: ltr;" placeholder=".my-custom-class { color: #ef394e; }"><?php echo esc_textarea($custom_css); ?></textarea>
                                </td>
                            </tr>
                            <tr>
                                <th>کدهای تگ Head (گوگل آنالیتیکس / اینماد / متاتگ‌ها)</th>
                                <td>
                                    <textarea name="evazar_opt_header_scripts" rows="5" class="large-text code" style="direction: ltr;" placeholder="<!-- Google tag (gtag.js) -->"><?php echo esc_textarea($header_scripts); ?></textarea>
                                </td>
                            </tr>
                            <tr>
                                <th>کدهای انتهای صفحه (قبل از &lt;/body&gt;)</th>
                                <td>
                                    <textarea name="evazar_opt_footer_scripts" rows="4" class="large-text code" style="direction: ltr;" placeholder="<!-- Chat widget / Scripts -->"><?php echo esc_textarea($footer_scripts); ?></textarea>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <!-- دکمه ذخیره تنظیمات -->
                    <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #f1f5f9; display: flex; align-items: center; justify-content: space-between;">
                        <button type="submit" name="evazar_save_theme_options" class="button button-primary button-large" style="padding: 8px 34px; font-size: 15px; font-weight: 800; border-radius: 8px; background: #ef394e; border-color: #dc2626;">ذخیره کلیه تنظیمات پوسته</button>
                        <span style="color: #64748b; font-size: 13px;">تغییرات بلافاصله روی تمام بخش‌های سایت اعمال می‌شوند.</span>
                    </div>

                </div>
            </div>
        </form>
    </div>

    <style>
        .tab-title { font-size: 17px; margin-top: 0; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; color: #0f172a; font-weight: 800; }
        .evazar-tabs-nav li { margin: 0; border-bottom: 1px solid #f1f5f9; }
        .evazar-tabs-nav li:last-child { border-bottom: none; }
        .evazar-tabs-nav .tab-link {
            display: block;
            padding: 14px 18px;
            color: #475569;
            text-decoration: none;
            font-weight: 600;
            font-size: 13.5px;
            transition: all 0.2s;
            border-right: 4px solid transparent;
        }
        .evazar-tabs-nav .tab-link:hover {
            background: #f8fafc;
            color: #0f172a;
        }
        .evazar-tabs-nav .tab-link.active {
            background: #fff1f2;
            color: #ef394e;
            border-right-color: #ef394e;
            font-weight: 700;
        }
    </style>

    <script>
        jQuery(document).ready(function($) {
            // سوییچ تب‌ها و حفظ تب فعال
            function switchTab(target, updateHash) {
                if (!target || !$(target).length) return;
                $('.evazar-tabs-nav .tab-link').removeClass('active');
                $('.evazar-tabs-nav .tab-link[href="' + target + '"]').addClass('active');
                $('.tab-content').hide().removeClass('active');
                $(target).show().addClass('active');
                $('#evazar_active_tab').val(target);
                if (updateHash) {
                    try {
                        history.replaceState(null, null, target);
                        localStorage.setItem('evazar_active_tab', target);
                    } catch(e) {}
                }
            }

            var hash = window.location.hash;
            var serverTab = $('#evazar_active_tab').val();
            var targetTab = '';

            // اولویت با تب ارسال شده از سرور پس از ذخیره‌سازی، سپس هش آدرس، سپس لوکال استوریج
            if (serverTab && $(serverTab).length) {
                targetTab = serverTab;
            } else if (hash && $(hash).length) {
                targetTab = hash;
            } else {
                try {
                    var localTab = localStorage.getItem('evazar_active_tab');
                    if (localTab && $(localTab).length) {
                        targetTab = localTab;
                    }
                } catch(e) {}
            }

            if (targetTab && $(targetTab).length) {
                switchTab(targetTab, true);
            }

            // رویداد کلیک تب‌ها
            $('.evazar-tabs-nav .tab-link').on('click', function(e) {
                e.preventDefault();
                var target = $(this).attr('href');
                switchTab(target, true);
            });

            // سوییچ نوع لوگو
            $('input[name="evazar_opt_logo_type"]').on('change', function() {
                if ($(this).val() === 'image') {
                    $('.row-logo-image').show();
                    $('.row-logo-text').hide();
                } else {
                    $('.row-logo-image').hide();
                    $('.row-logo-text').show();
                }
            });

            // کالرپیکر وردپرس
            $('.color-picker-field').wpColorPicker();

            // آپلودر رسانه وردپرس
            $('.btn-upload-media').on('click', function(e) {
                e.preventDefault();
                var targetInput = $($(this).data('target'));
                var customUploader = wp.media({
                    title: 'انتخاب یا آپلود تصویر',
                    button: { text: 'استفاده از این تصویر' },
                    multiple: false
                }).on('select', function() {
                    var attachment = customUploader.state().get('selection').first().toJSON();
                    targetInput.val(attachment.url);
                    if (targetInput.attr('id') === 'evazar_logo_img') {
                        $('#logo-preview').html('<img src="' + attachment.url + '" style="max-height: 46px;">');
                    }
                }).open();
            });
        });
    
        (function($){
            var list = document.getElementById('evazar-filter-sortable');
            var hidden = document.getElementById('evazar_filter_sections_order');
            if (!list || !hidden) return;
            var dragged = null;
            list.addEventListener('dragstart', function(e){ dragged=e.target.closest('.evazar-filter-sort-item'); if(dragged){ e.dataTransfer.effectAllowed='move'; e.dataTransfer.setData('text/plain', dragged.getAttribute('data-key')); dragged.style.opacity='.55'; }});
            list.addEventListener('dragend', function(){ if(dragged) dragged.style.opacity='1'; dragged=null; updateOrder(); });
            list.addEventListener('dragover', function(e){ e.preventDefault(); var item=e.target.closest('.evazar-filter-sort-item'); if(!dragged || !item || item===dragged) return; var rect=item.getBoundingClientRect(); var before=(e.clientY-rect.top)<rect.height/2; list.insertBefore(dragged, before?item:item.nextSibling); });
            function updateOrder(){ hidden.value=Array.prototype.map.call(list.querySelectorAll('.evazar-filter-sort-item'),function(el){return el.getAttribute('data-key');}).join(','); }
            updateOrder();
        })(jQuery);
</script>
    <?php
}
