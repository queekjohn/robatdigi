# EVazar Theme 1.9.6
- Archive filters and sorting use EVazar Product Index when available.
- Price and stock filtering no longer depend primarily on wp_postmeta scans.
- SKU/DKP search uses the indexed product table when available.
- Legacy fallbacks remain until index backfill is complete.
