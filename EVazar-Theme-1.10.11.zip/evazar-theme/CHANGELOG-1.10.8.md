# EVazar Theme 1.10.8

- Reverted the aggressive archive image prioritization introduced in 1.10.7 after real-world testing showed QUIC_NETWORK_IDLE_TIMEOUT errors on the first two product images.
- Only the first archive product image is now `loading="eager"`; all subsequent product-card images remain lazy.
- Removed archive `fetchpriority="high"` from product-card images to reduce connection/priority pressure.
- Kept 360×360 intrinsic dimensions and the existing CDN URL strategy unchanged.
