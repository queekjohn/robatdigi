# EVazar Theme 1.9.8

- Fix sort-link URLs generated during AJAX rendering so they stay on the real archive URL instead of `/wp-admin/admin-ajax.php`.
- Preserve existing brand/category/stock/price/search parameters when changing sort.
- Add a defensive JS canonicalization for legacy sort links that still point to `admin-ajax.php`.
- Keep out-of-stock products at the end of every supported sort order.
- Bump the theme version and asset cache-buster to 1.9.8.
