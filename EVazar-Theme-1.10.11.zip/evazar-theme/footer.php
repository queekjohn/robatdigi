<?php
/**
 * فوتر مدرن و جامع پوسته ایوازار
 */

$show_trust_bar     = get_option('evazar_opt_footer_show_trust_bar', '1');
$trust_bar_mobile   = get_option('evazar_opt_trust_bar_mobile', '1');
$trust_bar_style    = get_option('evazar_opt_trust_bar_style', 'line');

$trust_items = [
    1 => [
        'title' => get_option('evazar_opt_trust_item_1_title', 'قیمت و موجودی به‌روز'),
        'sub'   => get_option('evazar_opt_trust_item_1_sub', 'به‌روزرسانی خودکار از داده‌های دیجی‌کالا'),
        'icon'  => get_option('evazar_opt_trust_item_1_icon', 'shield'),
        'link'  => get_option('evazar_opt_trust_item_1_link', ''),
    ],
    2 => [
        'title' => get_option('evazar_opt_trust_item_2_title', 'بهترین قیمت روز'),
        'sub'   => get_option('evazar_opt_trust_item_2_sub', 'بروزرسانی لحظه‌ای تخفیف‌ها'),
        'icon'  => get_option('evazar_opt_trust_item_2_icon', 'zap'),
        'link'  => get_option('evazar_opt_trust_item_2_link', ''),
    ],
    3 => [
        'title' => get_option('evazar_opt_trust_item_3_title', 'بررسی با هوش مصنوعی'),
        'sub'   => get_option('evazar_opt_trust_item_3_sub', 'تحلیل شفاف نقاط قوت و ضعف'),
        'icon'  => get_option('evazar_opt_trust_item_3_icon', 'ai'),
        'link'  => get_option('evazar_opt_trust_item_3_link', ''),
    ],
    4 => [
        'title' => get_option('evazar_opt_trust_item_4_title', 'خرید در سایت فروشنده'),
        'sub'   => get_option('evazar_opt_trust_item_4_sub', 'پرداخت و ارسال در سایت فروشنده انجام می‌شود'),
        'icon'  => get_option('evazar_opt_trust_item_4_icon', 'lock'),
        'link'  => get_option('evazar_opt_trust_item_4_link', ''),
    ],
];

$footer_about_title = get_option('evazar_opt_footer_about_title', 'درباره ایوازار');
$footer_about_text  = get_option('evazar_opt_footer_about_text', 'ایوازار، سامانه هوشمند کشف، بررسی تخصصی و مقایسه قیمت کالاهای دیجی‌کالا است. هدف ما ارائه تحلیل‌های بی‌طرفانه، راهنمایی خرید با هوش مصنوعی و اتصال امن کاربران به درگاه رسمی دیجی‌کالا است.');
$footer_trust_title = get_option('evazar_opt_footer_trust_title', 'ایوازار فروشنده کالا نیست');
$footer_trust_text  = get_option('evazar_opt_footer_trust_text', 'ایوازار قیمت و اطلاعات کالا را نمایش می‌دهد و برای خرید شما را به سایت فروشنده منتقل می‌کند. پرداخت، ارسال، گارانتی و مرجوعی توسط فروشنده انجام می‌شود.');
$footer_phone       = get_option('evazar_opt_footer_phone', '۰۲۱-۹۱۰۰۰۰۰۰');
$footer_email       = get_option('evazar_opt_footer_email', 'info@evazar.ir');
$footer_address     = get_option('evazar_opt_footer_address', '');
$footer_show_cats   = get_option('evazar_opt_footer_show_cats', '1');
$footer_cats_count  = intval(get_option('evazar_opt_footer_cats_count', 6));
$footer_show_brands = get_option('evazar_opt_footer_show_brands', '1');
$footer_brands_count= intval(get_option('evazar_opt_footer_brands_count', 6));
$footer_copyright   = get_option('evazar_opt_footer_copyright', 'تمامی حقوق مادی و معنوی برای ایوازار محفوظ است © ۱۴۰۵');
$footer_back_to_top = get_option('evazar_opt_footer_back_to_top', '1');
?>

<!-- TRUST BAR -->
<?php if ($show_trust_bar === '1'): ?>
<div class="evazar-trust-bar-section trust-style-<?php echo esc_attr($trust_bar_style); ?><?php echo ($trust_bar_mobile !== '1') ? ' trust-hide-mobile' : ''; ?>">
    <div class="evazar-container">
        <div class="evazar-trust-grid">
            <?php foreach ($trust_items as $i_idx => $t_item): 
                $t_title = $t_item['title'];
                $t_sub   = $t_item['sub'];
                $t_icon  = $t_item['icon'];
                $t_link  = trim($t_item['link']);
                $has_link = !empty($t_link);
                $tag = $has_link ? 'a' : 'div';
                $tag_attrs = $has_link ? ' href="' . esc_url($t_link) . '" class="trust-item trust-item-link item-' . $i_idx . '"' : ' class="trust-item item-' . $i_idx . '"';
            ?>
            <<?php echo $tag . $tag_attrs; ?>>
                <div class="trust-icon-box">
                    <?php echo evazar_get_trust_icon_svg($t_icon); ?>
                </div>
                <div class="trust-text">
                    <strong>
                        <span><?php echo esc_html($t_title); ?></span>
                        <?php if ($has_link): ?>
                            <svg class="trust-link-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                        <?php endif; ?>
                    </strong>
                    <?php if (!empty($t_sub)): ?>
                        <span><?php echo esc_html($t_sub); ?></span>
                    <?php endif; ?>
                </div>
            </<?php echo $tag; ?>>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- MAIN FOOTER -->
<footer class="evazar-site-footer">
    <div class="evazar-container">
        <div class="footer-main-grid">
            
            <!-- ستون ۱: درباره و معرفی برند -->
            <div class="footer-col col-about">
                <a href="<?php echo home_url(); ?>" class="footer-brand">
                    <span class="footer-logo-box"><?php echo esc_html(get_option('evazar_opt_logo_letter', 'E')); ?></span>
                    <span class="footer-logo-title"><?php echo esc_html(get_option('evazar_opt_logo_text', 'ایــــوازار')); ?></span>
                </a>
                <h3 class="footer-widget-title"><?php echo esc_html($footer_about_title); ?></h3>
                <div class="footer-desc">
                    <?php echo evazar_render_readmore(nl2br(esc_html($footer_about_text)), 'footer', 180); ?>
                </div>
                
                <div class="footer-contacts">
                    <?php if ($footer_phone): 
                        $clean_tel_href = preg_replace('/[^0-9]/', '', evazar_to_en_num($footer_phone));
                        $display_phone  = function_exists('evazar_format_phone_display') ? evazar_format_phone_display($footer_phone) : evazar_to_fa_num($footer_phone);
                    ?>
                        <div class="contact-row contact-phone-row">
                            <span class="contact-lbl">پشتیبانی:</span>
                            <a href="tel:<?php echo esc_attr($clean_tel_href); ?>" class="contact-val contact-phone" dir="ltr"><bdi><?php echo esc_html($display_phone); ?></bdi></a>
                        </div>
                    <?php endif; ?>
                    <?php if ($footer_email): ?>
                        <div class="contact-row contact-email-row">
                            <span class="contact-lbl">ایمیل:</span>
                            <a href="mailto:<?php echo esc_attr($footer_email); ?>" class="contact-val contact-email" dir="ltr"><bdi><?php echo esc_html($footer_email); ?></bdi></a>
                        </div>
                    <?php endif; ?>
                    <?php if ($footer_address): ?>
                        <div class="contact-row contact-address-row">
                            <span class="contact-lbl">نشانی:</span>
                            <span class="contact-val" style="color: #cbd5e1;"><?php echo esc_html(evazar_to_fa_num($footer_address)); ?></span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- ستون ۲: دسته‌بندی‌های برگزیده -->
            <?php if ($footer_show_cats === '1'): ?>
            <div class="footer-col col-links">
                <h3 class="footer-widget-title">دسته‌بندی‌های کالا</h3>
                <ul class="footer-nav-list">
                    <?php 
                    $footer_cats = get_terms([
                        'taxonomy'   => 'evazar_category',
                        'number'     => max(1, $footer_cats_count),
                        'hide_empty' => false,
                        'parent'     => 0
                    ]);
                    if (!empty($footer_cats) && !is_wp_error($footer_cats)):
                        foreach ($footer_cats as $cat): ?>
                            <li><a href="<?php echo esc_url(get_term_link($cat)); ?>"><?php echo esc_html($cat->name); ?></a></li>
                        <?php endforeach;
                    else: ?>
                        <li><a href="<?php echo home_url('/product-category/'); ?>">همه دسته‌بندی‌ها</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <?php endif; ?>

            <!-- ستون ۳: برندهای محبوب -->
            <?php if ($footer_show_brands === '1'): ?>
            <div class="footer-col col-links">
                <h3 class="footer-widget-title">برندهای محبوب</h3>
                <ul class="footer-nav-list">
                    <?php 
                    $footer_brands = get_terms([
                        'taxonomy'   => 'evazar_brand',
                        'number'     => max(1, $footer_brands_count),
                        'hide_empty' => false
                    ]);
                    if (!empty($footer_brands) && !is_wp_error($footer_brands)):
                        foreach ($footer_brands as $brand): ?>
                            <li><a href="<?php echo esc_url(get_term_link($brand)); ?>"><?php echo esc_html($brand->name); ?></a></li>
                        <?php endforeach;
                    else: ?>
                        <li><a href="<?php echo home_url('/brand/western-digital'); ?>">وسترن دیجیتال</a></li>
                        <li><a href="<?php echo home_url('/brand/samsung'); ?>">سامسونگ</a></li>
                        <li><a href="<?php echo home_url('/brand/xiaomi'); ?>">شیائومی</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <?php endif; ?>

            <!-- ستون ۴: خرید امن و نماد اعتماد -->
            <div class="footer-col col-trust">
                <h3 class="footer-widget-title"><?php echo esc_html($footer_trust_title); ?></h3>
                <div class="footer-trust-box">
                    <p><?php echo nl2br(esc_html($footer_trust_text)); ?></p>
                </div>
            </div>

        </div>

        <!-- COPYRIGHT BAR -->
        <div class="footer-bottom-bar">
            <p class="copyright-text"><?php echo esc_html(evazar_to_fa_num($footer_copyright)); ?></p>
            <?php if ($footer_back_to_top === '1'): ?>
            <button type="button" class="btn-scroll-top" onclick="window.scrollTo({top:0, behavior:'smooth'});">
                بازگشت به بالا ↑
            </button>
            <?php endif; ?>
        </div>
    </div>
</footer>

<?php 
// نوار چسبان خرید موبایل در صفحه تک محصول (طراحی اختصاصی مطابق دیجی‌کالا و ریپانسیو کامل)
if (is_singular('evazar_product') && get_option('evazar_opt_sticky_mobile_buybox', '1') === '1'): 
    $m_post_id   = get_the_ID();
    $m_price     = get_post_meta($m_post_id, '_evazar_current_price', true);
$m_available_meta = get_post_meta($m_post_id, '_evazar_is_available', true);
$m_available = ($m_available_meta === '') ? ((float)$m_price > 0) : in_array((string)$m_available_meta, ['1', 'yes', 'true'], true);
    $m_old_price = get_post_meta($m_post_id, '_evazar_old_price', true);
    $m_discount  = get_post_meta($m_post_id, '_evazar_discount_percent', true);
    $m_link      = function_exists('evazar_get_affiliate_redirect_url') ? evazar_get_affiliate_redirect_url($m_post_id) : (function_exists('evazar_get_final_affiliate_link') ? evazar_get_final_affiliate_link($m_post_id) : '#');
    $m_btn_text  = get_option('evazar_opt_product_btn_title', 'مشاهده قیمت و خرید از دیجی‌کالا');
    
    // استخراج تمیز عدد درصد تخفیف به صورت ارقام فارسی بدون کاراکترهای اضافه (دقیقاً مشابه دیجی‌کالا مانند ۱۲٪ یا ۲۲٪)
    $clean_disc_badge = function_exists('evazar_get_clean_discount_badge') 
        ? evazar_get_clean_discount_badge($m_discount, $m_old_price, $m_price) 
        : '';
    $m_old_num = floatval(str_replace([',', ' ', '،'], '', function_exists('evazar_to_en_num') ? evazar_to_en_num((string)$m_old_price) : (string)$m_old_price));
    $m_cur_num = floatval(str_replace([',', ' ', '،'], '', function_exists('evazar_to_en_num') ? evazar_to_en_num((string)$m_price) : (string)$m_price));
    $m_has_discount = ($m_available && $m_old_num > 0 && $m_cur_num > 0 && $m_old_num > $m_cur_num);
?>
<div class="mobile-sticky-buybox" id="mobile-sticky-bar">
    <div class="mobile-sticky-inner">
        <!-- سمت راست در RTL: باکس قیمت دیجی‌کالا -->
        <div class="mobile-price-box">
            <?php if ($m_has_discount): ?>
                <div class="mobile-sticky-top-row">
                    <?php if ($clean_disc_badge): ?>
                        <span class="mobile-sticky-discount-badge"><?php echo esc_html($clean_disc_badge); ?></span>
                    <?php endif; ?>
                    <del class="mobile-sticky-old-price"><?php echo evazar_format_price($m_old_price); ?></del>
                </div>
            <?php endif; ?>

            <div class="mobile-sticky-main-price">
                <span class="price-num" style="<?php echo ($m_available && $m_cur_num > 0) ? '' : 'display: none;'; ?>"><?php echo evazar_format_price($m_price); ?></span>
                <span class="price-unit" style="<?php echo ($m_cur_num > 0) ? '' : 'display: none;'; ?>">تومان</span>
                <span class="price-out" style="<?php echo ($m_available && $m_cur_num > 0) ? 'display: none;' : 'display: inline;'; ?>">ناموجود</span>
            </div>
        </div>

        <!-- سمت چپ در RTL: دکمه هدایت به دیجی‌کالا -->
        <a href="<?php echo esc_url($m_link); ?>" rel="nofollow sponsored" class="btn-mobile-buy">
            <span><?php echo esc_html($m_btn_text ?: 'مشاهده قیمت و خرید'); ?></span>
        </a>
    </div>
</div>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
