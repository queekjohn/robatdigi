<?php
/**
 * قالب جامع آرشیو کالاها، برندها و دسته‌بندی‌های ایوازار
 */
get_header(); 

global $wp_query;

$req_uri    = $_SERVER['REQUEST_URI'] ?? '';
$clean_path = trim(parse_url($req_uri, PHP_URL_PATH), '/');

$is_brand_dir = (get_query_var('evazar_directory') === 'brand') || preg_match('#(^|/)brands?/?$#i', $clean_path);
$is_cat_dir   = (get_query_var('evazar_directory') === 'category') || preg_match('#(^|/)categories?/?$#i', $clean_path) || preg_match('#(^|/)product-category/?$#i', $clean_path);

$archive_title = 'کالاهای ایوازار';
$breadcrumbs   = [];
$total_count   = $wp_query->found_posts ?? 0;
$term_desc     = '';
$child_terms   = [];
$view_mode     = 'products'; // 'products', 'brand_directory', 'cat_directory'
$show_item_count = get_option('evazar_opt_archive_show_count', '1');

$is_on_sale = isset($_GET['on_sale']) || isset($_GET['discount']) || (is_search() && trim(get_search_query()) === 'تخفیف');

if ($is_on_sale) {
    $view_mode      = 'products';
    $opt_sale_title = get_option('evazar_opt_special_offers_title', 'تخفیف‌های ویژه و شگفت‌انگیز');
    $opt_sale_desc  = get_option('evazar_opt_special_offers_desc', 'مجموعه جدیدترین کالاهای دارای تخفیف ویژه و کاهش قیمت واقعی در دیجی‌کالا. بررسی مشخصات و خرید آنلاین با بیشترین درصد سود خریدار.');
    $archive_title  = !empty($opt_sale_title) ? $opt_sale_title : 'تخفیف‌های ویژه و شگفت‌انگیز';
    $breadcrumbs[]  = ['title' => 'تخفیف‌های ویژه', 'url' => home_url('/?post_type=evazar_product&on_sale=1')];
    $term_desc      = $opt_sale_desc;
} elseif (is_search()) {
    $search_query  = get_search_query();
    $view_mode     = 'products';
    $archive_title = !empty($search_query) ? ('نتایج جستجو برای: «' . $search_query . '»') : 'نتایج جستجوی کالاها';
    $breadcrumbs[] = ['title' => 'نتایج جستجو', 'url' => home_url('/?s=' . urlencode($search_query) . '&post_type=evazar_product')];
    if (!empty($search_query)) {
        $breadcrumbs[] = ['title' => $search_query, 'url' => '#'];
    }
} elseif ($is_cat_dir) {
    $view_mode     = 'cat_directory';
    $archive_title = get_option('evazar_opt_categories_page_title', 'دسته‌بندی‌های کالا') ?: 'دسته‌بندی‌های کالا';
    $term_desc     = get_option('evazar_opt_categories_page_desc', '');
    $breadcrumbs[] = ['title' => 'دسته‌بندی‌ها', 'url' => home_url('/product-category/')];
} elseif ($is_brand_dir) {
    $view_mode     = 'brand_directory';
    $archive_title = get_option('evazar_opt_brands_page_title', 'برندهای کالا') ?: 'برندهای کالا';
    $term_desc     = get_option('evazar_opt_brands_page_desc', '');
    $breadcrumbs[] = ['title' => 'برندها', 'url' => home_url('/brand/')];
} elseif (is_tax('evazar_brand')) {
    $term = get_queried_object();
    if ($term && isset($term->term_id)) {
        $archive_title = $term->name;
        $breadcrumbs[] = ['title' => 'برندها', 'url' => home_url('/brand/')];
        $breadcrumbs[] = ['title' => $term->name, 'url' => get_term_link($term)];
        $term_desc     = term_description($term->term_id, 'evazar_brand');
    } else {
        $view_mode     = 'brand_directory';
        $archive_title = get_option('evazar_opt_brands_page_title', 'برندهای کالا') ?: 'برندهای کالا';
        $term_desc     = get_option('evazar_opt_brands_page_desc', '');
        $breadcrumbs[] = ['title' => 'برندها', 'url' => home_url('/brand/')];
    }
} elseif (is_tax('evazar_category')) {
    $term = get_queried_object();
    if ($term && isset($term->term_id)) {
        $archive_title = $term->name;

        // ۱. استخراج دسته‌های والد ثبت‌شده در وردپرس
        $ancestor_ids = array_reverse(get_ancestors($term->term_id, 'evazar_category'));

        // ۲. در صورت خالی بودن والدها، ترمیم خودکار سلسله‌مراتب از متادیتای محصولات
        if (empty($ancestor_ids) && function_exists('evazar_repair_term_ancestors')) {
            evazar_repair_term_ancestors($term->term_id);
            $ancestor_ids = array_reverse(get_ancestors($term->term_id, 'evazar_category'));
        }

        if (!empty($ancestor_ids)) {
            foreach ($ancestor_ids as $anc_id) {
                $anc = get_term($anc_id, 'evazar_category');
                if ($anc && !is_wp_error($anc)) {
                    $breadcrumbs[] = [
                        'title' => $anc->name,
                        'url'   => get_term_link($anc)
                    ];
                }
            }
        }

        // دسته جاری به عنوان آیتم نهایی
        $breadcrumbs[] = ['title' => $term->name, 'url' => get_term_link($term)];
        $term_desc     = term_description($term->term_id, 'evazar_category');

        // زیردسته‌ها
        $child_terms = get_terms([
            'taxonomy'   => 'evazar_category',
            'parent'     => $term->term_id,
            'hide_empty' => false,
        ]);
    } else {
        $view_mode     = 'cat_directory';
        $archive_title = 'دسته‌بندی‌های کالا';
        $breadcrumbs[] = ['title' => 'دسته‌بندی‌ها', 'url' => home_url('/product-category/')];
    }
} elseif (is_post_type_archive('evazar_product')) {
    $archive_title = 'همه کالاهای ایوازار';
    $breadcrumbs[] = ['title' => 'کالاها', 'url' => get_post_type_archive_link('evazar_product')];
} else {
    if ($total_count === 0 && !have_posts()) {
        $view_mode     = 'cat_directory';
        $archive_title = 'دسته‌بندی‌های کالا';
        $breadcrumbs[] = ['title' => 'دسته‌بندی‌ها', 'url' => home_url('/product-category/')];
    }
}

// خواندن تنظیمات اختصاصی آرشیو پوسته
$show_desc     = get_option('evazar_opt_archive_show_desc', '1');
$show_discount = get_option('evazar_opt_archive_show_discount', '1');
$show_rating   = get_option('evazar_opt_archive_show_rating', '1');
$show_buy_btn  = get_option('evazar_opt_archive_show_buy_btn', '1');
?>

<main id="primary" class="site-main evazar-archive-main">
<div class="evazar-container evazar-archive-page" data-filter-taxonomy="<?php echo esc_attr($evz_filter_context_tax ?? ((is_tax("evazar_brand")||is_tax("evazar_category")) ? get_queried_object()->taxonomy : "")); ?>" data-filter-term-id="<?php echo esc_attr($evz_filter_context_term_id ?? ((is_tax("evazar_brand")||is_tax("evazar_category")) ? get_queried_object()->term_id : 0)); ?>" data-filter-search="<?php echo esc_attr(is_search() ? get_search_query() : ""); ?>" data-filter-sale="<?php echo esc_attr($is_on_sale ? "1" : "0"); ?>">
    
    <!-- BREADCRUMBS -->
    <nav class="evazar-top-breadcrumbs" aria-label="موقعیت فعلی در سایت" style="margin-top: 24px;">
        <ol itemscope itemtype="https://schema.org/BreadcrumbList">
            <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                <a itemprop="item" href="<?php echo esc_url(home_url('/')); ?>"><span itemprop="name">ایوازار</span></a>
                <meta itemprop="position" content="1" />
            </li>
            <?php 
            $pos = 2;
            $total_b = count($breadcrumbs);
            foreach ($breadcrumbs as $idx => $bc): 
                $is_active = ($idx === $total_b - 1);
            ?>
                <li class="breadcrumb-sep">/</li>
                <?php if ($is_active): ?>
                    <li class="current-item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                        <span itemprop="name"><?php echo esc_html($bc['title']); ?></span>
                        <meta itemprop="position" content="<?php echo $pos++; ?>" />
                    </li>
                <?php else: ?>
                    <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                        <a itemprop="item" href="<?php echo esc_url($bc['url']); ?>"><span itemprop="name"><?php echo esc_html($bc['title']); ?></span></a>
                        <meta itemprop="position" content="<?php echo $pos++; ?>" />
                    </li>
                <?php endif; ?>
            <?php endforeach; ?>
        </ol>
    </nav>

    <?php if ($view_mode !== 'brand_directory'): ?>
    <!-- CLEAN PAGE HEADER -->
    <div class="archive-clean-header">
        <div class="archive-header-content">
            <h1 class="archive-main-title"><?php echo esc_html($archive_title); ?></h1>
        </div>
        <?php if ($view_mode === 'products' && $total_count > 0 && $show_item_count === '1'): ?>
            <span class="archive-clean-count"><?php echo evazar_to_fa_num(number_format_i18n($total_count)); ?> کالا</span>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if (!empty($child_terms) && !is_wp_error($child_terms)): ?>
    <!-- SUBCATEGORIES CHIPS (نوار کپسولی دسته‌بندی‌های فرعی دیجی‌کالا پلاس با پشتیبانی کامل از درگ و لمس) -->
    <div class="archive-subcats-bar dk-capsules-bar">
        <div class="subcats-label dk-pill-tag">
            <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M10 18h4v-2h-4v2zM3 6v2h18V6H3zm3 7h12v-2H6v2z"/></svg>
            <span>زیردسته‌ها:</span>
        </div>
        <div class="subcats-scroll-wrapper">
            <button type="button" class="subcats-scroll-btn subcats-btn-prev" aria-label="مشاهده قبلی" title="زیردسته‌های قبلی" style="display: none;">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
            </button>
            <div class="subcats-chips-wrapper" id="subcatsChipsWrapper">
                <?php foreach ($child_terms as $c_term): 
                    $c_url = get_term_link($c_term);
                ?>
                <a href="<?php echo esc_url($c_url); ?>" class="subcat-chip dk-cat-pill">
                    <span class="pill-dot"></span>
                    <span class="subcat-chip-name"><?php echo esc_html($c_term->name); ?></span>
                    <?php if ($c_term->count > 0 && $show_item_count === '1'): ?>
                        <span class="subcat-chip-count pill-badge"><?php echo evazar_to_fa_num(number_format_i18n($c_term->count)); ?></span>
                    <?php endif; ?>
                </a>
                <?php endforeach; ?>
            </div>
            <button type="button" class="subcats-scroll-btn subcats-btn-next" aria-label="مشاهده بعدی" title="سایر زیردسته‌ها" style="display: none;">
                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
            </button>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($view_mode === 'cat_directory'): ?>
        <!-- DIGIKALA CASCADE MEGA PORTAL (پرتال آبشاری دو ستونه دیجی‌کالا) -->
        <div class="archive-categories-hub">
            <?php
            $parent_cats = get_terms([
                'taxonomy'   => 'evazar_category',
                'parent'     => 0,
                'hide_empty' => false,
            ]);
            if (!empty($parent_cats) && !is_wp_error($parent_cats)): ?>
                <div class="dk-cascade-wrapper">
                    <!-- ستون راست: دسته‌های والد دیجی‌کالا -->
                    <aside class="dk-sidebar">
                        <?php foreach ($parent_cats as $idx => $p_cat): 
                            $p_icon = function_exists('evazar_get_category_icon') ? evazar_get_category_icon($p_cat->name) : '📁';
                            $is_first = ($idx === 0);
                        ?>
                        <div class="dk-side-item <?php echo $is_first ? 'active' : ''; ?>" data-cat-id="<?php echo esc_attr($p_cat->term_id); ?>">
                            <div class="icon-title">
                                <span class="dk-cat-icon"><?php echo $p_icon; ?></span>
                                <span class="dk-cat-name"><?php echo esc_html($p_cat->name); ?></span>
                            </div>
                            <div class="dk-side-meta">
                                <?php if ($p_cat->count > 0 && $show_item_count === '1'): ?>
                                    <span class="dk-cat-count"><?php echo evazar_to_fa_num(number_format_i18n($p_cat->count)); ?></span>
                                <?php endif; ?>
                                <span class="arrow">‹</span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </aside>

                    <!-- ستون چپ: پنل زیردسته‌ها -->
                    <div class="dk-main-panels">
                        <?php foreach ($parent_cats as $idx => $p_cat): 
                            $p_icon = function_exists('evazar_get_category_icon') ? evazar_get_category_icon($p_cat->name) : '📁';
                            $p_link = get_term_link($p_cat);
                            $is_first = ($idx === 0);

                            // واکشی زیردسته‌های سطح ۲
                            $sub_cats = get_terms([
                                'taxonomy'   => 'evazar_category',
                                'parent'     => $p_cat->term_id,
                                'hide_empty' => false,
                            ]);

                            $has_any_lvl3 = false;
                            $lvl3_by_parent = [];
                            if (!empty($sub_cats) && !is_wp_error($sub_cats)) {
                                foreach ($sub_cats as $sc) {
                                    $lvl3 = get_terms([
                                        'taxonomy'   => 'evazar_category',
                                        'parent'     => $sc->term_id,
                                        'hide_empty' => false,
                                    ]);
                                    if (!empty($lvl3) && !is_wp_error($lvl3)) {
                                        $has_any_lvl3 = true;
                                        $lvl3_by_parent[$sc->term_id] = $lvl3;
                                    }
                                }
                            }
                        ?>
                        <div class="dk-main-panel <?php echo $is_first ? 'active' : ''; ?>" id="dk-panel-<?php echo esc_attr($p_cat->term_id); ?>" data-cat-id="<?php echo esc_attr($p_cat->term_id); ?>" style="<?php echo $is_first ? '' : 'display: none;'; ?>">
                            <div class="dk-panel-header">
                                <div class="title-group">
                                    <span class="dk-header-icon"><?php echo $p_icon; ?></span>
                                    <h2 class="dk-cat-heading">همه زیردسته‌های <?php echo esc_html($p_cat->name); ?></h2>
                                </div>
                                <a href="<?php echo esc_url($p_link); ?>" class="btn-view-all">مشاهده همه کالاهای این دسته ←</a>
                            </div>

                            <?php if (!empty($sub_cats) && !is_wp_error($sub_cats)): ?>
                                <?php if ($has_any_lvl3): ?>
                                    <!-- نمایش ستونی زیردسته‌های سطح ۲ به همراه فرزندان سطح ۳ -->
                                    <div class="dk-columns-grid">
                                        <?php foreach ($sub_cats as $sc): 
                                             $sc_link = get_term_link($sc);
                                            $lvl3_items = $lvl3_by_parent[$sc->term_id] ?? [];
                                        ?>
                                        <div class="dk-sub-column">
                                            <h3>
                                                <a href="<?php echo esc_url($sc_link); ?>"><?php echo esc_html($sc->name); ?></a>
                                                <?php if ($sc->count > 0 && $show_item_count === '1'): ?>
                                                    <span class="sub-qty">(<?php echo evazar_to_fa_num(number_format_i18n($sc->count)); ?>)</span>
                                                <?php endif; ?>
                                            </h3>
                                            <?php if (!empty($lvl3_items)): ?>
                                            <ul class="dk-sub-links">
                                                <?php foreach ($lvl3_items as $l3): ?>
                                                <li>
                                                    <a href="<?php echo esc_url(get_term_link($l3)); ?>">
                                                        <span><?php echo esc_html($l3->name); ?></span>
                                                        <?php if ($l3->count > 0 && $show_item_count === '1'): ?>
                                                            <span class="sub-count"><?php echo evazar_to_fa_num(number_format_i18n($l3->count)); ?></span>
                                                        <?php endif; ?>
                                                    </a>
                                                </li>
                                                <?php endforeach; ?>
                                            </ul>
                                            <?php endif; ?>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <!-- نمایش مستقیم زیردسته‌های سطح ۲ در ۳ ستون مرتب و کارتی -->
                                    <div class="dk-columns-grid dk-direct-grid">
                                        <?php 
                                        $col_count = 3;
                                        $chunks = array_chunk($sub_cats, max(1, ceil(count($sub_cats) / $col_count)));
                                        foreach ($chunks as $chunk):
                                        ?>
                                        <div class="dk-sub-column">
                                            <ul class="dk-sub-links direct-sub-list">
                                                <?php foreach ($chunk as $sc): 
                                                    $sc_link = get_term_link($sc);
                                                ?>
                                                <li>
                                                    <a href="<?php echo esc_url($sc_link); ?>" class="dk-direct-sub-item">
                                                        <span class="bullet-dot">›</span>
                                                        <span class="sub-name"><?php echo esc_html($sc->name); ?></span>
                                                        <?php if ($sc->count > 0 && $show_item_count === '1'): ?>
                                                            <span class="sub-count"><?php echo evazar_to_fa_num(number_format_i18n($sc->count)); ?> کالا</span>
                                                        <?php endif; ?>
                                                    </a>
                                                </li>
                                                <?php endforeach; ?>
                                            </ul>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="dk-empty-sub">
                                    <div class="dk-empty-icon"><?php echo $p_icon; ?></div>
                                    <p>کالاهای این دسته‌بندی به طور مستقیم فهرست شده‌اند.</p>
                                    <a href="<?php echo esc_url($p_link); ?>" class="btn-view-all-pill">مشاهده کالاهای <?php echo esc_html($p_cat->name); ?> ←</a>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="archive-empty-box">
                    <div class="empty-icon">📁</div>
                    <h2>دسته‌بندی فعالی ثبت نشده است!</h2>
                    <a href="<?php echo home_url('/'); ?>" class="btn-back-home">بازگشت به صفحه اصلی</a>
                </div>
            <?php endif; ?>
        </div>

    <?php elseif ($view_mode === 'brand_directory'): ?>
        <!-- MODEL 1: DIGIKALA-STYLE A-Z STICKY DIRECTORY & FEATURED BRANDS HUB -->
        <div class="archive-brands-hub brands-model-1">
            <?php
            $brands_list = get_terms([
                'taxonomy'   => 'evazar_brand',
                'hide_empty' => false,
                'orderby'    => 'name',
                'order'      => 'ASC',
            ]);

            if (!empty($brands_list) && !is_wp_error($brands_list)):
                $total_brands = count($brands_list);

                // استخراج محبوب‌ترین برندها بر اساس بیشترین تعداد کالا
                $sorted_by_count = $brands_list;
                usort($sorted_by_count, function($a, $b) {
                    return ($b->count ?? 0) <=> ($a->count ?? 0);
                });
                $featured_brands = array_slice($sorted_by_count, 0, min(8, count($sorted_by_count)));

                // گروه‌بندی الفبایی برندها (فارسی و لاتین)
                $grouped_fa = [];
                $grouped_en = [];

                foreach ($brands_list as $b) {
                    $b_name = trim($b->name);
                    $first_char = mb_substr($b_name, 0, 1, 'UTF-8');

                    if (preg_match('/^[a-zA-Z]/', $first_char)) {
                        $letter = strtoupper($first_char);
                        $grouped_en[$letter][] = $b;
                    } else {
                        if (in_array($first_char, ['آ', 'ا', 'أ', 'إ'], true)) {
                            $letter = 'الف';
                        } else {
                            $letter = $first_char;
                        }
                        $grouped_fa[$letter][] = $b;
                    }
                }

                // مرتب‌سازی طبق ترتیب استاندارد الفبای فارسی
                $fa_alphabet_order = ['الف', 'ب', 'پ', 'ت', 'ث', 'ج', 'چ', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'ژ', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ک', 'گ', 'ل', 'م', 'ن', 'و', 'ه', 'ی'];
                $sorted_fa = [];
                foreach ($fa_alphabet_order as $fa_l) {
                    if (isset($grouped_fa[$fa_l])) {
                        $sorted_fa[$fa_l] = $grouped_fa[$fa_l];
                    }
                }
                foreach ($grouped_fa as $k => $v) {
                    if (!isset($sorted_fa[$k])) {
                        $sorted_fa[$k] = $v;
                    }
                }
                ksort($grouped_en);

                $opt_brand_page_title = get_option('evazar_opt_brands_page_title', 'برندهای معتبر و برگزیده') ?: 'برندهای معتبر و برگزیده';
                $opt_brand_page_desc  = get_option('evazar_opt_brands_page_desc', 'بررسی قیمت روز، مقایسه مشخصات فنی و مشاهده گزینه‌های خرید از فروشندگان معتبر.') ?: 'بررسی قیمت روز، مقایسه مشخصات فنی و مشاهده گزینه‌های خرید از فروشندگان معتبر.';
            ?>

                <!-- 1. HERO SEARCH BANNER -->
                <div class="brands-hero-banner">
                    <span class="brands-hero-tag">🏷️ بیش از <?php echo esc_html(evazar_to_fa_num($total_brands)); ?> برند معتبر و رسمی</span>
                    <h1 class="brands-hero-heading"><?php echo esc_html($opt_brand_page_title); ?></h1>
                    <p class="brands-hero-sub"><?php echo esc_html($opt_brand_page_desc); ?></p>
                    
                    <div class="brands-search-wrapper">
                        <span class="brands-search-icon">
                            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                        </span>
                        <input type="text" id="evazar-brand-search-input" placeholder="جستجوی سریع نام برند (تسکو، وسترن دیجیتال، سونی، سامسونگ...)" autocomplete="off">
                    </div>
                </div>

                <!-- 2. STICKY ALPHABET JUMP BAR -->
                <nav class="brands-sticky-alphabet" id="brands-sticky-nav" aria-label="پرش سریع الفبایی برندها">
                    <button type="button" class="brands-alpha-btn active" data-target="all">همه</button>
                    <?php foreach ($sorted_fa as $l_char => $b_arr): ?>
                        <a href="#brand-group-<?php echo esc_attr(urlencode($l_char)); ?>" class="brands-alpha-btn" data-target="<?php echo esc_attr(urlencode($l_char)); ?>"><?php echo esc_html($l_char); ?></a>
                    <?php endforeach; ?>

                    <?php if (!empty($grouped_en)): ?>
                        <span class="brands-alpha-divider">|</span>
                        <?php foreach ($grouped_en as $en_char => $b_arr): ?>
                            <a href="#brand-group-<?php echo esc_attr($en_char); ?>" class="brands-alpha-btn" data-target="<?php echo esc_attr($en_char); ?>"><?php echo esc_html($en_char); ?></a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </nav>

                <!-- 3. FEATURED / TRENDING BRANDS -->
                <?php if (!empty($featured_brands)): ?>
                <div class="brands-featured-section" id="brands-featured-wrapper">
                    <div class="brands-section-title">
                        <h2>
                            <span class="fire-icon">🔥</span>
                            <span>محبوب‌ترین برندهای این هفته</span>
                        </h2>
                        <span class="meta-sub">بیشترین کالا و بازدید کاربران</span>
                    </div>

                    <div class="brands-featured-grid">
                        <?php foreach ($featured_brands as $f_item): 
                            $f_link = get_term_link($f_item);
                            $f_first = mb_substr($f_item->name, 0, 1, 'UTF-8');
                            $f_en = ucwords(str_replace(['-', '_'], ' ', $f_item->slug));
                        ?>
                        <a href="<?php echo esc_url($f_link); ?>" class="brands-featured-card" data-brand-name="<?php echo esc_attr(mb_strtolower($f_item->name . ' ' . $f_en)); ?>">
                            <div class="brand-avatar-circle">
                                <span><?php echo esc_html($f_first); ?></span>
                            </div>
                            <span class="brand-title-fa"><?php echo esc_html($f_item->name); ?></span>
                            <?php if (!empty($f_en) && $f_en !== $f_item->name): ?>
                                <span class="brand-title-en"><?php echo esc_html($f_en); ?></span>
                            <?php endif; ?>
                            <?php if ($show_item_count === '1'): ?>
                                <span class="brand-badge-count"><?php echo esc_html(evazar_to_fa_num(number_format_i18n($f_item->count))); ?> کالا</span>
                            <?php endif; ?>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- 4. ALPHABETICAL BRAND GROUPS -->
                <div class="brands-groups-container" id="brands-groups-container">
                    <?php foreach ($sorted_fa as $l_char => $b_list): ?>
                    <div class="brand-alpha-block" id="brand-group-<?php echo esc_attr(urlencode($l_char)); ?>" data-letter="<?php echo esc_attr(urlencode($l_char)); ?>">
                        <div class="brand-block-header">
                            <span class="letter-badge"><?php echo esc_html($l_char); ?></span>
                            <h2 class="block-title">برندهای شروع شونده با حرف «<?php echo esc_html($l_char); ?>»</h2>
                            <span class="block-count"><?php echo esc_html(evazar_to_fa_num(count($b_list))); ?> برند</span>
                        </div>
                        <div class="brand-cards-grid">
                            <?php foreach ($b_list as $b_item): 
                                $b_link = get_term_link($b_item);
                                $b_first = mb_substr($b_item->name, 0, 1, 'UTF-8');
                                $b_en = ucwords(str_replace(['-', '_'], ' ', $b_item->slug));
                            ?>
                            <a href="<?php echo esc_url($b_link); ?>" class="brand-row-card" data-brand-name="<?php echo esc_attr(mb_strtolower($b_item->name . ' ' . $b_en)); ?>">
                                <div class="brand-card-info">
                                    <span class="card-name-fa"><?php echo esc_html($b_item->name); ?></span>
                                    <?php if (!empty($b_en) && $b_en !== $b_item->name): ?>
                                        <span class="card-name-en"><?php echo esc_html($b_en); ?></span>
                                    <?php endif; ?>
                                </div>
                                <?php if ($show_item_count === '1'): ?>
                                    <span class="card-count-pill"><?php echo esc_html(evazar_to_fa_num(number_format_i18n($b_item->count))); ?> کالا</span>
                                <?php endif; ?>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>

                    <?php foreach ($grouped_en as $en_char => $b_list): ?>
                    <div class="brand-alpha-block" id="brand-group-<?php echo esc_attr($en_char); ?>" data-letter="<?php echo esc_attr($en_char); ?>">
                        <div class="brand-block-header">
                            <span class="letter-badge"><?php echo esc_html($en_char); ?></span>
                            <h2 class="block-title">برندهای لاتین با حرف «<?php echo esc_html($en_char); ?>»</h2>
                            <span class="block-count"><?php echo esc_html(evazar_to_fa_num(count($b_list))); ?> برند</span>
                        </div>
                        <div class="brand-cards-grid">
                            <?php foreach ($b_list as $b_item): 
                                $b_link = get_term_link($b_item);
                                $b_en = ucwords(str_replace(['-', '_'], ' ', $b_item->slug));
                            ?>
                            <a href="<?php echo esc_url($b_link); ?>" class="brand-row-card" data-brand-name="<?php echo esc_attr(mb_strtolower($b_item->name . ' ' . $b_en)); ?>">
                                <div class="brand-card-info">
                                    <span class="card-name-fa"><?php echo esc_html($b_item->name); ?></span>
                                    <?php if (!empty($b_en) && $b_en !== $b_item->name): ?>
                                        <span class="card-name-en"><?php echo esc_html($b_en); ?></span>
                                    <?php endif; ?>
                                </div>
                                <?php if ($show_item_count === '1'): ?>
                                    <span class="card-count-pill"><?php echo esc_html(evazar_to_fa_num(number_format_i18n($b_item->count))); ?> کالا</span>
                                <?php endif; ?>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>

                    <!-- پیام عدم یافتن برند در جستجو -->
                    <div id="brands-no-match" class="brands-no-match" style="display: none;">
                        <span class="no-match-icon">🔍</span>
                        <h2>هیچ برندی با این نام یافت نشد!</h2>
                        <p>لطفاً نام برند را به شکل دیگری تایپ کنید یا از حروف الفبا استفاده نمایید.</p>
                    </div>
                </div>

                <!-- INSTANT SEARCH & SCROLL SCRIPT -->
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const searchInput = document.getElementById('evazar-brand-search-input');
                    const cards = document.querySelectorAll('.brand-row-card, .brands-featured-card');
                    const blocks = document.querySelectorAll('.brand-alpha-block');
                    const featuredWrapper = document.getElementById('brands-featured-wrapper');
                    const noMatch = document.getElementById('brands-no-match');
                    const alphaBtns = document.querySelectorAll('.brands-alpha-btn');

                    if (searchInput) {
                        searchInput.addEventListener('input', function() {
                            const val = this.value.trim().toLowerCase();
                            let totalVisible = 0;

                            if (val === '') {
                                cards.forEach(c => c.style.display = '');
                                blocks.forEach(b => b.style.display = '');
                                if (featuredWrapper) featuredWrapper.style.display = '';
                                if (noMatch) noMatch.style.display = 'none';
                                return;
                            }

                            if (featuredWrapper) featuredWrapper.style.display = 'none';

                            blocks.forEach(block => {
                                let blockHasVisible = false;
                                const blockCards = block.querySelectorAll('.brand-row-card');
                                blockCards.forEach(c => {
                                    const bName = c.getAttribute('data-brand-name') || '';
                                    if (bName.includes(val)) {
                                        c.style.display = '';
                                        blockHasVisible = true;
                                        totalVisible++;
                                    } else {
                                        c.style.display = 'none';
                                    }
                                });
                                block.style.display = blockHasVisible ? '' : 'none';
                            });

                            if (noMatch) {
                                noMatch.style.display = (totalVisible === 0) ? 'block' : 'none';
                            }
                        });
                    }

                    // Smooth Scrolling for Jump Bar
                    alphaBtns.forEach(btn => {
                        btn.addEventListener('click', function(e) {
                            const target = this.getAttribute('data-target');
                            alphaBtns.forEach(b => b.classList.remove('active'));
                            this.classList.add('active');

                            if (target === 'all') {
                                window.scrollTo({ top: 0, behavior: 'smooth' });
                                return;
                            }

                            const el = document.getElementById('brand-group-' + target);
                            if (el) {
                                e.preventDefault();
                                const offset = 80;
                                const topPos = el.getBoundingClientRect().top + window.pageYOffset - offset;
                                window.scrollTo({ top: topPos, behavior: 'smooth' });
                            }
                        });
                    });
                });
                </script>

            <?php else: ?>
                <div class="archive-empty-box">
                    <div class="empty-icon">🏷️</div>
                    <h2>برندی در سایت ثبت نشده است!</h2>
                    <a href="<?php echo home_url('/'); ?>" class="btn-back-home">بازگشت به صفحه اصلی</a>
                </div>
            <?php endif; ?>
        </div>

    <?php else: ?>
        <!-- PRODUCTS GRID + FILTERS -->
        <div class="evazar-filter-mobile-toolbar">
            <button type="button" class="evazar-mobile-filter-trigger" aria-controls="evazar-filter-panel" aria-expanded="false">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 5h16M7 12h10M10 19h4"/></svg>
                <span>فیلترها</span>
            </button>
        </div>
        <?php
        $evz_filter_context_tax = ''; $evz_filter_context_term_id = 0;
        if (is_tax('evazar_brand') || is_tax('evazar_category')) { $evz_obj = get_queried_object(); $evz_filter_context_tax = $evz_obj && isset($evz_obj->taxonomy) ? $evz_obj->taxonomy : ''; $evz_filter_context_term_id = $evz_obj && isset($evz_obj->term_id) ? (int)$evz_obj->term_id : 0; }
        $GLOBALS['evazar_archive_filter_context'] = ['taxonomy'=>$evz_filter_context_tax,'term_id'=>$evz_filter_context_term_id];
        ?>
        <?php echo evazar_render_active_archive_filters(); ?>
        <div class="evazar-results-layout">
            <?php echo evazar_render_archive_filters(); ?>
            <div class="evazar-results-content">
        <?php if (have_posts()): ?>
            <?php
            // نوار مرتب‌سازی استاندارد دیجی‌کالا
            $current_sort = sanitize_text_field($_GET['sort'] ?? ($_GET['orderby'] ?? 'relevant'));
            $base_sort_url = home_url(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
            $sort_preserve_args = is_array($_GET) ? $_GET : [];
            unset($sort_preserve_args['paged'], $sort_preserve_args['page'], $sort_preserve_args['sort']);
            if (!empty($sort_preserve_args)) $base_sort_url = add_query_arg($sort_preserve_args, $base_sort_url);
            $sort_tabs = [
                'relevant'     => 'مرتبط‌ترین',
                'views'        => 'پربازدیدترین',
                'newest'       => 'جدیدترین',
                'bestseller'   => 'پرفروش‌ترین',
                'cheapest'     => 'ارزان‌ترین',
                'expensive'    => 'گران‌ترین',
                'satisfaction' => 'پیشنهاد خریداران',
            ];
            ?>
            <div class="dk-sort-bar-container">
                <div class="dk-sort-right">
                    <div class="dk-sort-label">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M6 12h12M9 18h6"/></svg>
                        <span>مرتب سازی:</span>
                    </div>
                    <ul class="dk-sort-items-list">
                        <?php foreach ($sort_tabs as $s_key => $s_title): 
                            $is_active = ($current_sort === $s_key || (empty($current_sort) && $s_key === 'relevant'));
                            $s_url = add_query_arg('sort', $s_key, $base_sort_url);
                        ?>
                        <li>
                            <a href="<?php echo esc_url($s_url); ?>" class="dk-sort-btn <?php echo $is_active ? 'active' : ''; ?>">
                                <?php echo esc_html($s_title); ?>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php 
                $sort_total = intval($wp_query->found_posts ?? ($total_count ?? ($wp_query->post_count ?? 0)));
                if ($sort_total > 0): 
                ?>
                <div class="dk-sort-left-count">
                    <span><?php echo evazar_to_fa_num(number_format_i18n($sort_total)); ?></span> کالا
                </div>
                <?php endif; ?>
            </div>

            <div class="evazar-archive-grid">
                <?php while (have_posts()): the_post(); 
                    $pid = get_the_ID();
                    $cur_price = get_post_meta($pid, '_evazar_current_price', true);
                    $old_price = get_post_meta($pid, '_evazar_old_price', true);
                    $discount = get_post_meta($pid, '_evazar_discount_percent', true);
                    $rating = get_post_meta($pid, '_evazar_rating', true);
                    $rating_count = intval(get_post_meta($pid, '_evazar_rating_count', true));
                    $brand = get_post_meta($pid, '_evazar_brand', true);
                    $img_url = get_post_meta($pid, '_evazar_main_image', true);
                    if (!$img_url) {
                        $img_url = get_the_post_thumbnail_url($pid, 'medium');
                    }
                    if (!$img_url) {
                        $img_url = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300" viewBox="0 0 300 300"><rect fill="%23f8fafc" width="300" height="300"/><text fill="%2394a3b8" font-family="sans-serif" font-size="16" dy="6" font-weight="bold" x="50%" y="50%" text-anchor="middle">تصویر کالا</text></svg>';
                    }
                    if (function_exists('evazar_cdn_image_url') && strpos($img_url, 'data:image') === false) {
                        $img_url = evazar_cdn_image_url($img_url, 360);
                    }
                    $affiliate_url = function_exists('evazar_get_affiliate_redirect_url') ? evazar_get_affiliate_redirect_url($pid) : (function_exists('evazar_get_final_affiliate_link') ? evazar_get_final_affiliate_link($pid) : get_permalink($pid));
                ?>
                    <article class="archive-product-card">
                        <div class="card-thumb-wrap">
                            <?php 
                            $clean_disc = function_exists('evazar_get_clean_discount_badge') 
                                ? evazar_get_clean_discount_badge($discount, $old_price, $cur_price) 
                                : '';
                            if ($show_discount === '1' && !empty($clean_disc)): 
                            ?>
                                <span class="card-badge-discount"><?php echo esc_html($clean_disc); ?></span>
                            <?php endif; ?>
                            <?php 
                            if (get_option('evazar_opt_show_price_drop_badge', '1') === '1' && function_exists('evazar_get_price_drop_info')):
                                $drop_hours = intval(get_option('evazar_opt_price_drop_hours', 48));
                                $drop_info = evazar_get_price_drop_info($pid, $drop_hours);
                                if ($drop_info):
                                    $drop_text = get_option('evazar_opt_price_drop_badge_text', 'کاهش قیمت');
                            ?>
                                <span class="card-badge-price-drop" title="کاهش قیمت در ۲ روز اخیر">
                                    <svg viewBox="0 0 24 24"><path d="M12 5v14M19 12l-7 7-7-7"/></svg>
                                    <span><?php echo esc_html($drop_text); ?></span>
                                </span>
                            <?php 
                                endif;
                            endif; 
                            ?>
                            <a href="<?php the_permalink(); ?>">
                                <img src="<?php echo esc_url($img_url); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy" decoding="async" class="card-product-img">
                            </a>
                        </div>
                        
                        <div class="card-body">
                            <h2 class="card-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>

                            <?php if ($show_rating === '1' && $rating && floatval($rating) > 0 && $rating_count > 0): ?>
                            <div class="card-rating-row">
                                <span class="rating-star">★ <?php echo esc_html(evazar_to_fa_num($rating)); ?></span>
                            </div>
                            <?php endif; ?>

                            <div class="card-pricing">
                                <?php if ($old_price && floatval($old_price) > floatval($cur_price)): ?>
                                    <span class="card-old-price"><?php echo evazar_format_price($old_price); ?></span>
                                <?php else: ?>
                                    <span class="card-old-price-placeholder">&nbsp;</span>
                                <?php endif; ?>
                                <div class="card-cur-price">
                                    <?php if ($cur_price): ?>
                                        <strong><?php echo evazar_format_price($cur_price); ?></strong>
                                        <span class="currency">تومان</span>
                                    <?php else: ?>
                                        <strong>ناموجود</strong>
                                    <?php endif; ?>
                                </div>
                            </div>

                        </div>
                    </article>
                <?php endwhile; ?>
            </div>

            <!-- PAGINATION -->
            <div class="evazar-pagination">
                <?php
                echo paginate_links([
                    'prev_text' => '&#8594; قبلی',
                    'next_text' => 'بعدی &#8592;',
                    'type'      => 'list',
                    'mid_size'  => (function_exists('wp_is_mobile') && wp_is_mobile()) ? 1 : 2,
                    'end_size'  => 1,
                    'add_args'  => evazar_archive_filter_args(),
                ]);
                ?>
            </div>

        <?php else: ?>
            <?php if (!empty($child_terms)): ?>
                <div class="archive-subcats-prominent">
                    <h2>دسته‌بندی‌های این بخش</h2>
                    <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 16px;">برای مشاهده کالاها، یکی از شاخه‌های زیر را انتخاب نمایید:</p>
                    <div class="subcats-prominent-grid">
                        <?php foreach ($child_terms as $c_term): ?>
                            <a href="<?php echo esc_url(get_term_link($c_term)); ?>" class="subcat-prominent-card">
                                <span class="folder-icon">📂</span>
                                <span class="name"><?php echo esc_html($c_term->name); ?></span>
                                <?php if ($show_item_count === '1'): ?>
                                    <span class="count"><?php echo evazar_to_fa_num(number_format_i18n($c_term->count)); ?> کالا</span>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php elseif (!empty($is_on_sale)): ?>
                <div class="archive-empty-box">
                    <div class="empty-icon">🏷️</div>
                    <h2>در حال حاضر کالایی با تخفیف ویژه یافت نشد!</h2>
                    <p>به زودی جدیدترین کالاهای تخفیف‌دار و شگفت‌انگیز به این بخش افزوده خواهند شد.</p>
                    <a href="<?php echo get_post_type_archive_link('evazar_product') ?: home_url('/product/'); ?>" class="btn-back-home">مشاهده همه کالاهای فروشگاه</a>
                </div>
            <?php elseif (is_search()): ?>
                <div class="archive-empty-box">
                    <div class="empty-icon">🔍</div>
                    <h2>کالایی مطابق با عبارت «<?php echo esc_html(get_search_query()); ?>» یافت نشد!</h2>
                    <p>پیشنهاد می‌کنیم املای کلمات را بررسی کنید یا با عبارت‌های عمومی‌تر جستجو نمایید.</p>
                    <a href="<?php echo home_url('/'); ?>" class="btn-back-home">بازگشت به صفحه اصلی</a>
                </div>
            <?php else: ?>
                <div class="archive-empty-box">
                    <div class="empty-icon">📦</div>
                    <h2>هنوز کالایی در این بخش ثبت نشده است!</h2>
                    <p>می‌توانید از طریق ربات هوشمند، محصولات این گروه را به صف واردات اضافه نمایید.</p>
                    <a href="<?php echo home_url('/'); ?>" class="btn-back-home">بازگشت به صفحه اصلی</a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
            </div><!-- /.evazar-results-content -->
        </div><!-- /.evazar-results-layout -->
    <?php endif; ?>

    <!-- SEO / TERM DESCRIPTION BOX (توضیحات برند و دسته‌بندی فقط در صفحه اول با سیستم مشاهده بیشتر) -->
    <?php 
    $current_paged = max(1, intval(get_query_var('paged', 1)), intval(get_query_var('page', 1)));
    if ($show_desc === '1' && !empty($term_desc) && !is_paged() && $current_paged <= 1): 
    ?>
    <div class="archive-seo-box archive-seo-box-bottom">
        <div class="archive-seo-inner">
            <?php echo evazar_render_readmore(wp_kses_post($term_desc), 'archive'); ?>
        </div>
    </div>
    <?php endif; ?>

</div>
</main>

<?php get_footer(); ?>
