<?php
/**
 * Template Name: صفحه تکی کالا ایوازار
 */
get_header(); 

// دریافت دیتاهای کالا از افزونه evazar-core
$post_id = get_the_ID();
$dk_url = get_post_meta($post_id, '_evazar_dk_url', true);
$en_title = get_post_meta($post_id, '_evazar_en_title', true);
$old_price = get_post_meta($post_id, '_evazar_old_price', true);
$current_price = get_post_meta($post_id, '_evazar_current_price', true);
// وضعیت ذخیره‌شده موجودی؛ اگر هنوز متا ساخته نشده باشد، برای سازگاری با محصولات قدیمی از وجود قیمت استفاده می‌کنیم.
$stored_available_meta = get_post_meta($post_id, '_evazar_is_available', true);
$product_available = ($stored_available_meta === '') ? ((float)$current_price > 0) : in_array((string)$stored_available_meta, ['1', 'yes', 'true'], true);
$discount_percent = get_post_meta($post_id, '_evazar_discount_percent', true);
$rating = get_post_meta($post_id, '_evazar_rating', true);
$rating_count = get_post_meta($post_id, '_evazar_rating_count', true);
$satisfaction = get_post_meta($post_id, '_evazar_satisfaction', true);
$sku = get_post_meta($post_id, '_sku', true) ?: get_post_meta($post_id, '_evazar_sku', true);
if (empty($sku) && !empty($dk_url) && preg_match('/dkp-(\d+)/i', $dk_url, $m_dkp)) {
    $sku = $m_dkp[1];
}
$brand = get_post_meta($post_id, '_evazar_brand', true);
$brand_en = get_post_meta($post_id, '_evazar_brand_en', true);

// ثبت بازدید در سمت کلاینت انجام می‌شود تا رندر صفحه باعث Write دیتابیس نشود.

// اطلاعات تکمیلی فروشنده از متادیتا (استعلام بلادرنگ به صورت ایجکس غیرمسدودکننده در کلاینت انجام می‌شود)
if (empty($seller_name)) {
    $seller_name = get_post_meta($post_id, '_evazar_seller_name', true) ?: 'دیجی‌کالا';
}
if (empty($seller_rate_text)) {
    $seller_rate_text = get_post_meta($post_id, '_evazar_seller_rate_text', true);
// متادیتای قدیمی ممکن است خودش شامل «فروشنده: نام» باشد؛ این متن دیگر نباید تکرار شود.
if ($seller_rate_text && preg_match('/^\s*فروشنده\s*[:：]/u', $seller_rate_text)) {
    $seller_rate_text = '';
}
}

// خواندن تنظیمات اختصاصی برگه تکی محصول
$opt_zoom             = get_option('evazar_opt_product_zoom', '1');
$opt_lightbox         = get_option('evazar_opt_product_lightbox', '1');
$opt_show_discount    = get_option('evazar_opt_product_show_discount', '1');
$opt_show_ratings     = get_option('evazar_opt_product_show_ratings', '1');
$opt_show_sku         = get_option('evazar_opt_product_show_sku', '1');
$opt_show_features    = get_option('evazar_opt_product_show_features', '1');
$opt_show_ai          = get_option('evazar_opt_product_show_ai', '1');
$opt_seller_name      = get_option('evazar_opt_product_seller_name', 'دیجی‌کالا');
$opt_show_seller      = get_option('evazar_opt_product_show_seller', '1');
$opt_buybox_guarantee_header = get_option('evazar_opt_buybox_guarantee_header', 'قیمت و موجودی به‌روز از دیجی‌کالا');
$opt_buybox_feature_1        = get_option('evazar_opt_buybox_feature_1', 'قیمت و وضعیت موجودی به‌صورت آنلاین بررسی می‌شود');
$opt_buybox_feature_2        = get_option('evazar_opt_buybox_feature_2', 'برای خرید به سایت فروشنده منتقل می‌شوید');
$opt_buybox_feature_3        = get_option('evazar_opt_buybox_feature_3', 'پرداخت، ارسال و مرجوعی توسط فروشنده انجام می‌شود');
$opt_product_trust_badge_1 = get_option('evazar_opt_product_trust_badge_1', 'اطلاعات قیمت و موجودی به‌روز');
$opt_product_trust_badge_2 = get_option('evazar_opt_product_trust_badge_2', 'خرید در سایت فروشنده');
$opt_product_trust_badge_3 = get_option('evazar_opt_product_trust_badge_3', 'ارسال و مرجوعی طبق شرایط فروشنده');
$opt_buybox_price_label      = get_option('evazar_opt_buybox_price_label', 'قیمت رسمی در دیجی‌کالا:');
$opt_btn_title        = get_option('evazar_opt_product_btn_title', 'مشاهده قیمت و خرید در دیجی‌کالا');
$opt_btn_subtitle     = get_option('evazar_opt_product_btn_subtitle', 'برای ادامه خرید به سایت دیجی‌کالا منتقل می‌شوید');
$opt_guarantee_text   = get_option('evazar_opt_product_guarantee_text', 'ایوازار فروشنده کالا نیست؛ برای خرید، شما به سایت دیجی‌کالا منتقل می‌شوید و پرداخت و ارسال در همان سایت انجام می‌شود.');
$opt_show_related     = get_option('evazar_opt_product_show_related', '1');
$opt_related_count    = intval(get_option('evazar_opt_product_related_count', 4));

// استخراج دسته‌بندی‌ها و ساخت سلسله‌مراتب دقیق بردکرامب (Zero Fail Breadcrumb)
$breadcrumbs = [];

// ۱. ابتدا بررسی ترم‌های اختصاص‌یافته به کالا در تاکسونومی evazar_category
$product_terms = get_the_terms($post_id, 'evazar_category');

// در فرانت‌اند هیچ Sync/Repair دیتابیسی انجام نمی‌شود؛ فقط داده‌های موجود خوانده می‌شوند.

// ساخت زنجیره کامل والد تا فرزند نهایی
if (!empty($product_terms) && !is_wp_error($product_terms)) {
    // پیدا کردن عمیق‌ترین دسته‌بندی (برگ نهایی)
    $deepest_term = null;
    $max_depth = -1;

    foreach ($product_terms as $t) {
        $ancestors = get_ancestors($t->term_id, 'evazar_category');
        $depth = count($ancestors);
        if ($depth > $max_depth) {
            $max_depth = $depth;
            $deepest_term = $t;
        }
    }

    if ($deepest_term) {
        $ancestor_ids = array_reverse(get_ancestors($deepest_term->term_id, 'evazar_category'));
        foreach ($ancestor_ids as $anc_id) {
            $anc = get_term($anc_id, 'evazar_category');
            if ($anc && !is_wp_error($anc)) {
                $breadcrumbs[] = [
                    'title' => $anc->name,
                    'url'   => get_term_link($anc)
                ];
            }
        }
        $breadcrumbs[] = [
            'title' => $deepest_term->name,
            'url'   => get_term_link($deepest_term)
        ];
    }
}

// اگر دسته‌ای در ترم‌ها پیدا نشد، از اطلاعات ذخیره‌شده در متادیتا استفاده کن
if (empty($breadcrumbs)) {
    $bc_meta = get_post_meta($post_id, '_evazar_breadcrumbs', true);
    if (!empty($bc_meta)) {
        $decoded = is_array($bc_meta) ? $bc_meta : json_decode($bc_meta, true);
        if (is_array($decoded) && !empty($decoded)) {
            foreach ($decoded as $item) {
                $item_title = is_array($item) ? ($item['title'] ?? '') : (string)$item;
                $item_url   = is_array($item) ? ($item['url'] ?? '') : '';
                $item_title = trim($item_title);

                if (empty($item_title) || $item_title === 'دیجی‌کالا' || stripos($item_title, 'dkp-') === 0) {
                    continue;
                }
                if ($brand && mb_strtolower($item_title) === mb_strtolower($brand)) {
                    continue;
                }
                if (strpos($item_url, '/product/') !== false || $item_title === get_the_title($post_id)) {
                    continue;
                }

                if (empty($item_url) || strpos($item_url, 'digikala.com') !== false) {
                    $term_obj = get_term_by('name', $item_title, 'evazar_category');
                    if ($term_obj && !is_wp_error($term_obj)) {
                        $item_url = get_term_link($term_obj);
                    } else {
                        $item_url = home_url('/product-category/' . sanitize_title($item_title));
                    }
                }

                $breadcrumbs[] = [
                    'title' => $item_title,
                    'url'   => $item_url
                ];
            }
        }
    }
}

// اگر هنوز خالی است، دسته پیش‌فرض متادیتا
if (empty($breadcrumbs)) {
    $cat_name = get_post_meta($post_id, '_evazar_category', true);
    if (!empty($cat_name) && $cat_name !== 'عمومی' && $cat_name !== 'دسته‌بندی نشده') {
        $term_obj = get_term_by('name', $cat_name, 'evazar_category');
        $cat_url = ($term_obj && !is_wp_error($term_obj)) ? get_term_link($term_obj) : home_url('/product-category/' . sanitize_title($cat_name));
        $breadcrumbs[] = [
            'title' => $cat_name,
            'url'   => $cat_url
        ];
    }
}

// تضمین وجود زیردسته لندینگ برند + دسته در انتهای بردکرامب
if (!empty($breadcrumbs) && !empty($brand) && !in_array($brand, ['متفرقه', 'دیجی‌کالا', 'دیجیکالا', 'عمومی'])) {
    $last_bc = end($breadcrumbs);
    if (!empty($last_bc['title']) && mb_stripos($last_bc['title'], $brand) === false) {
        $subcat_title = $last_bc['title'] . ' ' . $brand;
        $term_sub = get_term_by('name', $subcat_title, 'evazar_category');
        $sub_link = ($term_sub && !is_wp_error($term_sub)) ? get_term_link($term_sub) : home_url('/product-category/' . sanitize_title($subcat_title));
        $breadcrumbs[] = [
            'title' => $subcat_title,
            'url'   => $sub_link
        ];
    }
}

$key_features = evazar_get_key_features($post_id);
$pros = evazar_get_multiline_meta($post_id, '_evazar_pros');
$cons = evazar_get_multiline_meta($post_id, '_evazar_cons');

// دریافت لینک دیپ‌لینک اختصاصی
// لینک داخلی انتقال: ثبت کلیک + صفحه انتقال ۲ ثانیه‌ای + سپس لینک افیلیت
$affiliate_link = function_exists('evazar_get_affiliate_redirect_url') ? evazar_get_affiliate_redirect_url($post_id) : (function_exists('evazar_get_final_affiliate_link') ? evazar_get_final_affiliate_link($post_id) : $dk_url);

// تصویر شاخص بر پایه معماری Zero Host Storage (مستقیماً از CDN یا کش کلودفلر)
$thumbnail_url = get_post_meta($post_id, '_evazar_main_image', true);
if (!$thumbnail_url) {
    $thumbnail_url = get_the_post_thumbnail_url($post_id, 'large');
}
if (!$thumbnail_url) {
    $thumbnail_url = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect fill="%23f8fafc" width="600" height="600"/><text fill="%2394a3b8" font-family="sans-serif" font-size="20" dy="8" font-weight="bold" x="50%" y="50%" text-anchor="middle">تصویر کالا</text></svg>';
}
if (function_exists('evazar_cdn_image_url') && strpos($thumbnail_url, 'data:image') === false) {
    $thumbnail_url = evazar_cdn_image_url($thumbnail_url, 800);
}

// گالری تصاویر (پشتیبانی هوشمند از آرایه JSON و تفکیک امن متنی با حفظ پارامترهای ابعاد عکس دیجی‌کالا)
$gallery_raw = get_post_meta($post_id, '_evazar_gallery', true);
$gallery_images = [];

if (!empty($gallery_raw)) {
    if (is_array($gallery_raw)) {
        $raw_list = $gallery_raw;
    } else {
        $decoded = json_decode($gallery_raw, true);
        if (is_array($decoded)) {
            $raw_list = $decoded;
        } else {
            $raw_list = preg_split('/,(?=https?:\/\/)/i', $gallery_raw);
        }
    }

    if (!empty($raw_list) && is_array($raw_list)) {
        foreach ($raw_list as $img_item) {
            $img_item = trim((string)$img_item);
            if (empty($img_item) || !filter_var($img_item, FILTER_VALIDATE_URL)) {
                continue;
            }
            if (function_exists('evazar_cdn_image_url')) {
                $img_item = evazar_cdn_image_url($img_item);
            }
            if (!in_array($img_item, $gallery_images)) {
                $gallery_images[] = $img_item;
            }
        }
    }
}

// قرار دادن تصویر اصلی در ابتدای گالری
if (!empty($thumbnail_url) && strpos($thumbnail_url, 'data:image') === false) {
    if (!in_array($thumbnail_url, $gallery_images)) {
        array_unshift($gallery_images, $thumbnail_url);
    }
}
?>

<!-- PRODUCT CONTENT -->
<div class="evazar-container">
    
    <!-- TOP BREADCRUMBS -->
    <nav class="evazar-top-breadcrumbs" aria-label="موقعیت فعلی در سایت">
        <ol itemscope itemtype="https://schema.org/BreadcrumbList">
            <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                <a itemprop="item" href="<?php echo esc_url(home_url('/')); ?>"><span itemprop="name">ایوازار</span></a>
                <meta itemprop="position" content="1" />
            </li>
            <?php 
            $pos = 2;
            $clean_breadcrumbs = [];
            $prod_title = get_the_title($post_id);
            if (!empty($breadcrumbs)) {
                foreach ($breadcrumbs as $bc) {
                    $bc_title = is_array($bc) ? ($bc['title'] ?? '') : (string)$bc;
                    $bc_url   = is_array($bc) ? ($bc['url'] ?? '') : '';
                    $bc_title = trim($bc_title);
                    if (empty($bc_title) || $bc_title === 'دیجی‌کالا' || stripos($bc_title, 'dkp-') === 0) continue;
                    if ($bc_title === $prod_title || strpos($bc_url, '/product/') !== false) continue;
                    if (empty($bc_url)) {
                        $term_obj = get_term_by('name', $bc_title, 'evazar_category');
                        $bc_url = ($term_obj && !is_wp_error($term_obj)) ? get_term_link($term_obj) : home_url('/product-category/' . sanitize_title($bc_title));
                    }
                    $clean_breadcrumbs[] = [
                        'title' => $bc_title,
                        'url'   => $bc_url
                    ];
                }
            }

            $total_bc = count($clean_breadcrumbs);
            if ($total_bc > 0) {
                foreach ($clean_breadcrumbs as $idx => $bc) {
                    $is_last = ($idx === $total_bc - 1);
                    echo '<li class="breadcrumb-sep">/</li>';
                    if ($is_last) {
                        echo '<li class="current-item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
                        echo '<a itemprop="item" href="' . esc_url($bc['url']) . '"><span itemprop="name">' . esc_html($bc['title']) . '</span></a>';
                        echo '<meta itemprop="position" content="' . $pos++ . '" />';
                        echo '</li>';
                    } else {
                        echo '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
                        echo '<a itemprop="item" href="' . esc_url($bc['url']) . '"><span itemprop="name">' . esc_html($bc['title']) . '</span></a>';
                        echo '<meta itemprop="position" content="' . $pos++ . '" />';
                        echo '</li>';
                    }
                }
            } elseif (!empty($brand)) {
                $brand_url = home_url('/brand/' . sanitize_title($brand_en ? $brand_en : $brand));
                echo '<li class="breadcrumb-sep">/</li>';
                echo '<li class="current-item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
                echo '<a itemprop="item" href="' . esc_url($brand_url) . '"><span itemprop="name">' . esc_html($brand) . '</span></a>';
                echo '<meta itemprop="position" content="' . $pos++ . '" />';
                echo '</li>';
            }
            ?>
        </ol>
    </nav>

    <!-- 3-COL PRODUCT TOP -->
    <div class="product-grid-top">
        
        <!-- 1. GALLERY -->
        <div class="gallery-col">
            <div class="gallery-main-wrap" id="evazar-gallery-main">
                <?php 
                $g_clean_badge = function_exists('evazar_get_clean_discount_badge') 
                    ? evazar_get_clean_discount_badge($discount_percent, $old_price, $current_price) 
                    : '';
                if (!empty($g_clean_badge) && $opt_show_discount === '1'): 
                ?>
                    <div class="badge-onsale">
                        <span class="badge-text"><?php echo esc_html($g_clean_badge . ' تخفیف'); ?></span>
                        <span class="badge-fire-icon">🔥</span>
                    </div>
                <?php endif; ?>

                <div class="gallery-img-container" id="evazar-zoom-container" title="مشاهده بزرگ‌تر و تمام‌صفحه">
                    <img src="<?php echo esc_url($thumbnail_url); ?>" id="evazar-main-img" class="gallery-main-img" alt="<?php echo esc_attr(get_the_title()); ?>" data-index="0" width="800" height="800" loading="eager" fetchpriority="high" decoding="async" onerror="this.onerror=null;this.style.visibility='hidden';">
                </div>
            </div>

            <?php if (!empty($gallery_images) && count($gallery_images) > 1): ?>
                <div class="gallery-thumbs-wrapper">
                    <button type="button" class="gallery-thumb-arrow thumb-arrow-prev" id="thumb-arrow-prev" aria-label="قبلی">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </button>
                    <div class="gallery-thumbs-track" id="evazar-gallery-thumbs">
                        <?php foreach ($gallery_images as $idx => $g_img): ?>
                            <div class="gallery-thumb-item <?php echo $idx === 0 ? 'active' : ''; ?>" data-src="<?php echo esc_url($g_img); ?>" data-index="<?php echo $idx; ?>">
                                <img src="<?php echo esc_url(function_exists('evazar_cdn_image_url') ? evazar_cdn_image_url($g_img, 160) : $g_img); ?>" data-src="<?php echo esc_url($g_img); ?>" alt="تصویر شماره <?php echo $idx + 1; ?>" width="160" height="160" loading="lazy" decoding="async" onerror="this.onerror=null;this.style.visibility='hidden';">
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button type="button" class="gallery-thumb-arrow thumb-arrow-next" id="thumb-arrow-next" aria-label="بعدی">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
                    </button>
                </div>
            <?php endif; ?>
        </div>

        <!-- 2. CENTER INFO -->
        <div class="info-col">

            <?php if ($brand): ?>
            <div class="evazar-floating-brand">
                <a href="<?php echo esc_url(home_url('/brand/' . sanitize_title($brand_en ? $brand_en : $brand))); ?>"><?php echo esc_html($brand); ?></a>
                <?php if (!empty($breadcrumbs)): 
                    $last_cat = end($breadcrumbs);
                    if (!empty($last_cat['title'])): 
                        $brand_cat_name = (mb_stripos($last_cat['title'], $brand) === false && !in_array($brand, ['متفرقه', 'دیجی‌کالا', 'دیجیکالا', 'عمومی'])) ? ($last_cat['title'] . ' ' . $brand) : $last_cat['title'];
                        $sub_term = get_term_by('name', $brand_cat_name, 'evazar_category');
                        $sub_url = ($sub_term && !is_wp_error($sub_term)) ? get_term_link($sub_term) : $last_cat['url'];
                    ?>
                        <span class="sep">/</span>
                        <a href="<?php echo esc_url($sub_url); ?>"><?php echo esc_html($brand_cat_name); ?></a>
                <?php endif; endif; ?>
            </div>
            <?php endif; ?>

            <h1 class="product-title"><?php the_title(); ?></h1>
            <?php if ($en_title): ?>
                <div class="product-subtitle"><?php echo esc_html($en_title); ?></div>
            <?php endif; ?>

            <div class="meta-ratings">
                <?php if ($opt_show_sku === '1' && $sku): ?>
                    <div class="sku-chip">کد کالا: <?php echo esc_html($sku); ?></div>
                <?php endif; ?>
                <?php if ($opt_show_ratings === '1'): ?>
                    <?php if ($rating && floatval($rating) > 0 && !empty($rating_count) && intval($rating_count) > 0): ?>
                        <div class="rating-chip" dir="rtl">
                            <span class="rating-star">★</span>
                            <span class="rating-val"><?php echo esc_html(evazar_to_fa_num($rating)); ?></span>
                            <span class="rating-count">(امتیاز <?php echo esc_html(evazar_to_fa_num($rating_count)); ?> خریدار)</span>
                        </div>
                    <?php endif; ?>
                    <?php if ($satisfaction && intval($satisfaction) > 0 && !empty($rating_count) && intval($rating_count) > 0): ?>
                        <div class="satisfaction-chip"><?php echo esc_html(evazar_to_fa_num($satisfaction)); ?>٪ رضایت خریداران</div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>


            <?php if ($opt_show_features === '1' && !empty($key_features)): 
                $feat_count = count($key_features);
                $feat_limit = intval(get_option('evazar_opt_single_features_limit', 5));
                if ($feat_limit < 1) { $feat_limit = 5; }
                $has_feat_more = ($feat_count > $feat_limit);
            ?>
                <div class="features-box <?php echo $has_feat_more ? 'has-features-collapse' : ''; ?>" id="evazar-features-box">
                    <h4>ویژگی‌های برجسته کالا:</h4>
                    <ul class="features-list">
                        <?php foreach($key_features as $f_idx => $feat): 
                            $is_extra = ($has_feat_more && $f_idx >= $feat_limit);
                        ?>
                            <li class="<?php echo $is_extra ? 'feature-item-extra' : ''; ?>">
                                <?php if (!empty($feat['label'])): ?>
                                    <span class="feat-label"><?php echo esc_html($feat['label']); ?>:</span>
                                <?php endif; ?>
                                <span class="feat-val"><bdi><?php echo esc_html(evazar_to_fa_num($feat['value'])); ?></bdi></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if ($has_feat_more): ?>
                    <button type="button" class="features-toggle-btn" aria-expanded="false">
                        <span class="feat-btn-text">+ مشاهده بیشتر (<?php echo esc_html(evazar_to_fa_num($feat_count - $feat_limit)); ?> ویژگی دیگر)</span>
                        <svg class="feat-btn-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </button>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- MOBLAK 3 TRUST BADGES (انتقال استراتژیک به انتهای مشخصات کالا در ستون وسط) -->
            <div class="info-trust-row">
                <?php if (!empty($opt_product_trust_badge_1)): ?>
                <div class="trust-badge-item">
                    <svg class="trust-icon" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>
                    <span><?php echo esc_html($opt_product_trust_badge_1); ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($opt_product_trust_badge_2)): ?>
                <div class="trust-badge-item">
                    <svg class="trust-icon" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M20 8h-3V4H1v13h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4zM6 18.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm13.5-9l1.96 2.5H17V9.5h2.5zm-1 9c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5 1.5 1.5 1.5z"/></svg>
                    <span><?php echo esc_html($opt_product_trust_badge_2); ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($opt_product_trust_badge_3)): ?>
                <div class="trust-badge-item">
                    <svg class="trust-icon" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12.5 8c-2.65 0-5.05.99-6.9 2.6L2 7v9h9l-3.62-3.62c1.39-1.16 3.16-1.88 5.12-1.88 3.54 0 6.55 2.31 7.6 5.5l2.37-.78C21.08 11.03 17.15 8 12.5 8z"/></svg>
                    <span><?php echo esc_html($opt_product_trust_badge_3); ?></span>
                </div>
                <?php endif; ?>
            </div>

        </div> <!-- /.info-col (ستون ۲: عنوان، امتیاز، توضیحات و مشخصات کالا) -->

        <!-- 3. BUYBOX COLUMN (ستون ۳: باکس خرید، قیمت، فروشنده و اعتمادسازی) -->
        <div class="buybox-col">
            <div class="product-integrated-buybox buybox-plan-4">
                <?php if (!empty($opt_buybox_guarantee_header)): ?>
                <div class="buybox-guarantee-topbar">
                    <?php echo esc_html($opt_buybox_guarantee_header); ?>
                </div>
                <?php endif; ?>

                <?php 
                if (get_option('evazar_opt_show_price_drop_badge', '1') === '1' && function_exists('evazar_get_price_drop_info')):
                    $drop_hours = intval(get_option('evazar_opt_price_drop_hours', 48));
                    $drop_info = evazar_get_price_drop_info($post_id, $drop_hours);
                    if ($drop_info):
                        $drop_text = get_option('evazar_opt_price_drop_badge_text', 'کاهش قیمت');
                        $drop_diff_formatted = evazar_format_price($drop_info['diff']);
                ?>
                    <div class="price-drop-hero-banner">
                        <div class="price-drop-hero-content">
                            <div class="price-drop-hero-icon-box">
                                <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"></polyline><polyline points="17 6 23 6 23 12"></polyline></svg>
                            </div>
                            <div class="price-drop-hero-text">
                                <strong><?php echo esc_html($drop_text); ?> ویژه:</strong> این کالا در <?php echo esc_html(evazar_to_fa_num($drop_hours)); ?> ساعت اخیر ارزان‌تر شده است!
                            </div>
                        </div>
                        <div class="price-drop-hero-amount">
                            <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"></line><polyline points="19 12 12 19 5 12"></polyline></svg>
                            <span><?php echo esc_html($drop_diff_formatted); ?></span> تومان افت قیمت
                        </div>
                    </div>
                <?php 
                    endif;
                endif;
                ?>

                <div class="buybox-top-row">
                    <?php if ($opt_show_seller === '1'): ?>
                    <div class="seller-badge-row">
                        <div class="seller-brand">
                            <div class="seller-logo">DK</div>
                            <div class="seller-details-wrap">
                                <div class="seller-name-row">
                                    <div class="seller-name" id="evazar-seller-name">فروشنده: <?php echo esc_html($seller_name); ?></div>
                                </div>
                                <div class="seller-sub-meta">
                                    <span class="seller-rate" id="evazar-seller-rate"><?php echo esc_html($seller_rate_text); ?></span>
                                    <span class="verified-badge">
                                        <svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="flex-shrink: 0;"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                                        <span>اطلاعات به‌روز از دیجی‌کالا</span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php 
                    $clean_old_num = floatval(str_replace([',', ' ', '،'], '', function_exists('evazar_to_en_num') ? evazar_to_en_num((string)$old_price) : (string)$old_price));
                    $clean_cur_num = floatval(str_replace([',', ' ', '،'], '', function_exists('evazar_to_en_num') ? evazar_to_en_num((string)$current_price) : (string)$current_price));
                    $has_real_discount = ($product_available && $clean_old_num > 0 && $clean_cur_num > 0 && $clean_old_num > $clean_cur_num);
                    $b_clean_badge = function_exists('evazar_get_clean_discount_badge') 
                        ? evazar_get_clean_discount_badge($discount_percent, $old_price, $current_price) 
                        : '';
                    ?>
                    <div class="price-container">
                        <div class="price-head" style="<?php echo ($has_real_discount && !empty($b_clean_badge)) ? '' : 'display: none;'; ?>">
                            <span><?php echo esc_html($opt_buybox_price_label ?: 'قیمت رسمی در دیجی‌کالا:'); ?></span>
                            <div class="price-discount-wrap">
                                <?php if ($has_real_discount && !empty($b_clean_badge) && $opt_show_discount === '1'): ?>
                                    <div class="discount-pill" id="evazar-discount-pill"><?php echo esc_html($b_clean_badge); ?></div>
                                <?php else: ?>
                                    <div class="discount-pill" id="evazar-discount-pill" style="display: none;"></div>
                                <?php endif; ?>
                                <?php if ($has_real_discount): ?>
                                    <div class="old-price-line" id="evazar-old-price-line"><?php echo evazar_format_price($old_price); ?> تومان</div>
                                <?php else: ?>
                                    <div class="old-price-line" id="evazar-old-price-line" style="display: none;"></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="main-price-row">
                            <span class="price-static-label"><?php echo esc_html($opt_buybox_price_label ?: 'قیمت:'); ?></span>
                            <div class="main-price-figure">
                                <div class="main-price-val" id="evazar-main-price-val"><?php echo ($product_available && $current_price) ? evazar_format_price($current_price) : 'ناموجود'; ?></div>
                                <div class="main-price-unit" id="evazar-main-price-unit" style="<?php echo ($product_available && $current_price) ? '' : 'display: none;'; ?>">تومان</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 3 CHECKLIST GUARANTEE ITEMS (چک‌لیست اعتمادسازی با تیک سبز) -->
                <?php if (!empty($opt_buybox_feature_1) || !empty($opt_buybox_feature_2) || !empty($opt_buybox_feature_3)): ?>
                <ul class="buybox-checklist">
                    <?php if (!empty($opt_buybox_feature_1)): ?>
                        <li><span class="chk-icon">✓</span> <span><?php echo esc_html($opt_buybox_feature_1); ?></span></li>
                    <?php endif; ?>
                    <?php if (!empty($opt_buybox_feature_2)): ?>
                        <li><span class="chk-icon">✓</span> <span><?php echo esc_html($opt_buybox_feature_2); ?></span></li>
                    <?php endif; ?>
                    <?php if (!empty($opt_buybox_feature_3)): ?>
                        <li><span class="chk-icon">✓</span> <span><?php echo esc_html($opt_buybox_feature_3); ?></span></li>
                    <?php endif; ?>
                </ul>
                <?php endif; ?>

                <!-- AFFILIATE CTA BUTTON -->
                <div class="buybox-action-wrap">
                    <a href="<?php echo esc_url($affiliate_link); ?>" rel="nofollow sponsored" class="btn-affiliate-cta">
                        <span><?php echo esc_html($opt_btn_title ?: 'اتصال مستقیم به دیجی‌کالا'); ?></span>
                        <?php if ($opt_btn_subtitle): ?>
                            <span class="btn-sub"><?php echo esc_html($opt_btn_subtitle); ?></span>
                        <?php endif; ?>
                    </a>

                    <?php if ($opt_guarantee_text): ?>
                    <div class="affiliate-guarantee-note">
                        <?php echo esc_html($opt_guarantee_text); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- MOBLAK 3 TRUST BADGES FOR MOBILE (نمایش زیر کادر قیمت و فروشنده در موبایل) -->
            <div class="info-trust-row buybox-mobile-trust-badges">
                <?php if (!empty($opt_product_trust_badge_1)): ?>
                <div class="trust-badge-item">
                    <svg class="trust-icon" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>
                    <span><?php echo esc_html($opt_product_trust_badge_1); ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($opt_product_trust_badge_2)): ?>
                <div class="trust-badge-item">
                    <svg class="trust-icon" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M20 8h-3V4H1v13h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4zM6 18.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5 1.5 1.5 1.5zm13.5-9l1.96 2.5H17V9.5h2.5zm-1 9c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5 1.5 1.5 1.5z"/></svg>
                    <span><?php echo esc_html($opt_product_trust_badge_2); ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($opt_product_trust_badge_3)): ?>
                <div class="trust-badge-item">
                    <svg class="trust-icon" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12.5 8c-2.65 0-5.05.99-6.9 2.6L2 7v9h9l-3.62-3.62c1.39-1.16 3.16-1.88 5.12-1.88 3.54 0 6.55 2.31 7.6 5.5l2.37-.78C21.08 11.03 17.15 8 12.5 8z"/></svg>
                    <span><?php echo esc_html($opt_product_trust_badge_3); ?></span>
                </div>
                <?php endif; ?>
            </div>

        </div> <!-- /.buybox-col (ستون ۳: بای‌باکس مستقل) -->

    </div> <!-- /.product-grid-top (چیدمان ۳ ستونه اختصاصی) -->

    <!-- 2-COL PRODUCT BOTTOM -->
    <div class="product-grid-bottom">
        <div class="main-content-card">
            <div class="content-tabs">
                <div class="tab-item active">نقد و بررسی تخصصی</div>
            </div>
            <div class="tab-pane active review-article">
                <?php 
                $article_body = get_the_content();
                echo evazar_render_readmore(apply_filters('the_content', $article_body), 'product');
                ?>

                <?php if ($opt_show_ai === '1' && !empty($pros)): ?>
                <div class="product-pros-cons-accent">
                    <div class="accent-box accent-pros">
                        <h4 class="accent-head">
                            <span class="accent-badge-icon">✓</span>
                            <span>ویژگی‌ها و نقاط قوت کلیدی کالا</span>
                        </h4>
                        <ul class="accent-list">
                            <?php foreach($pros as $pro): ?>
                                <li><?php echo esc_html(evazar_to_fa_num($pro)); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- SIDEBAR -->
        <div class="sidebar-col">
            <div class="sidebar-card">
                <h3 style="color:#0f172a; font-size:0.9rem;">چرا خرید از طریق ایوازار؟</h3>
                <p style="font-size:0.8rem; color:var(--text-main); line-height:1.6;">
                    ایوازار اطلاعات و قیمت کالاها را از منابع فروشنده جمع‌آوری و تحلیل می‌کند. برای خرید، شما مستقیماً به سایت فروشنده منتقل می‌شوید و پرداخت و ارسال همان‌جا انجام می‌شود.
                </p>
            </div>
        </div>
    </div>

    <?php 
    // نمایش بخش کالاهای مشابه و پیشنهادی (Bulletproof Related Products Query)
    $show_related_flag = ($opt_show_related !== '0');
    if ($show_related_flag): 
        $related_count = max(1, intval($opt_related_count));
        $opt_related_hide_outofstock = get_option('evazar_opt_related_hide_outofstock', '1');
        
        $base_args = [
            'post_type'           => 'evazar_product',
            'posts_per_page'      => $related_count,
            'post__not_in'        => [$post_id],
            'post_status'         => 'publish',
            'suppress_filters'    => true,
            'ignore_sticky_posts' => true,
            'no_found_rows'       => true,
        ];

        // در صورت فعال بودن تنظیم، کالاهای ناموجود یا بدون قیمت از محصولات مشابه حذف می‌شوند
        if ($opt_related_hide_outofstock === '1') {
            $base_args['meta_query'] = [
                'relation' => 'AND',
                [
                    'key'     => '_evazar_is_available',
                    'value'   => '1',
                    'compare' => '='
                ],
                [
                    'key'     => '_evazar_current_price',
                    'value'   => 0,
                    'compare' => '>',
                    'type'    => 'NUMERIC'
                ]
            ];
        }
        
        $related_query = null;

        // اولویت ۱: تطابق با دسته‌بندی‌های کالا
        if (!empty($product_terms) && !is_wp_error($product_terms)) {
            $cat_ids = wp_list_pluck($product_terms, 'term_id');
            $args_cat = array_merge($base_args, [
                'tax_query' => [
                    [
                        'taxonomy'         => 'evazar_category',
                        'field'            => 'term_id',
                        'terms'            => $cat_ids,
                        'include_children' => true,
                        'operator'         => 'IN',
                    ]
                ]
            ]);
            $related_query = new WP_Query($args_cat);
        }

        // اولویت ۲: اگر با دسته یافت نشد و برند مشخص است
        if ((!$related_query || !$related_query->have_posts()) && !empty($brand)) {
            $brand_term = get_term_by('name', $brand, 'evazar_brand') ?: get_term_by('slug', sanitize_title($brand), 'evazar_brand');
            if ($brand_term && !is_wp_error($brand_term)) {
                $args_brand = array_merge($base_args, [
                    'tax_query' => [
                        [
                            'taxonomy' => 'evazar_brand',
                            'field'    => 'term_id',
                            'terms'    => [$brand_term->term_id],
                        ]
                    ]
                ]);
            } else {
                $args_brand = array_merge($base_args, [
                    'tax_query' => [
                        [
                            'taxonomy' => 'evazar_brand',
                            'field'    => 'name',
                            'terms'    => $brand,
                        ]
                    ]
                ]);
            }
            $related_query = new WP_Query($args_brand);
        }

        // اولویت ۳: فال‌بک نهایی هوشمند (جدیدترین کالاهای منتشرشده فروشگاه)
        if (!$related_query || !$related_query->have_posts()) {
            $args_fallback = array_merge($base_args, [
                'orderby' => 'date',
                'order'   => 'DESC',
            ]);
            $related_query = new WP_Query($args_fallback);
        }

        if ($related_query && $related_query->have_posts()):
    ?>
    <section class="single-related-section">
        <div class="section-header-row">
            <h3 class="related-section-title">🔍 کالاهای مرتبط و پیشنهادی</h3>
            <?php if (!empty($breadcrumbs)): 
                $last_bc = end($breadcrumbs);
                $cat_link = is_array($last_bc) ? ($last_bc['url'] ?? '#') : '#';
            ?>
                <a href="<?php echo esc_url($cat_link); ?>" class="view-all-link">مشاهده همه کالاهای این دسته ←</a>
            <?php endif; ?>
        </div>
        <div class="evazar-archive-grid related-products-grid">
            <?php while ($related_query->have_posts()): $related_query->the_post(); 
                $r_id = get_the_ID();
                $r_price = get_post_meta($r_id, '_evazar_current_price', true);
                $r_old_price = get_post_meta($r_id, '_evazar_old_price', true);
                $r_discount = get_post_meta($r_id, '_evazar_discount_percent', true);
                $r_rating = get_post_meta($r_id, '_evazar_rating', true);
                $r_rating_count = intval(get_post_meta($r_id, '_evazar_rating_count', true));
                $r_brand = get_post_meta($r_id, '_evazar_brand', true);
                $r_img = get_post_meta($r_id, '_evazar_main_image', true) ?: get_the_post_thumbnail_url($r_id, 'medium');
                if (function_exists('evazar_cdn_image_url') && $r_img) {
                    $r_img = evazar_cdn_image_url($r_img, 360);
                }
            ?>
            <article class="archive-product-card">
                <div class="card-thumb-wrap">
                    <?php 
                    $r_clean_badge = function_exists('evazar_get_clean_discount_badge') 
                        ? evazar_get_clean_discount_badge($r_discount, $r_old_price, $r_price) 
                        : '';
                    if (!empty($r_clean_badge)): 
                    ?>
                        <span class="card-badge-discount"><?php echo esc_html($r_clean_badge); ?></span>
                    <?php endif; ?>
                    <?php 
                    if (get_option('evazar_opt_show_price_drop_badge', '1') === '1' && function_exists('evazar_get_price_drop_info')):
                        $drop_hours = intval(get_option('evazar_opt_price_drop_hours', 48));
                        $drop_info = evazar_get_price_drop_info($r_id, $drop_hours);
                        if ($drop_info):
                            $drop_text = get_option('evazar_opt_price_drop_badge_text', 'کاهش قیمت');
                    ?>
                        <span class="card-badge-price-drop" title="کاهش قیمت در ۲ روز اخیر">
                            <svg viewBox="0 0 24 24"><path d="M12 5v14M19 12l-7 7-7-7"/></svg>
                            <span><?php echo esc_html($drop_text); ?></span>
                        </span>
                    <?php 
                        endif;
                    endif;
                    ?>
                    <a href="<?php the_permalink(); ?>">
                        <img src="<?php echo esc_url($r_img); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy" decoding="async" class="card-product-img">
                    </a>
                </div>
                <div class="card-body">
                    <h4 class="card-title">
                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h4>
                    <?php if ($r_rating && floatval($r_rating) > 0 && $r_rating_count > 0): ?>
                    <div class="card-rating-row">
                        <span class="rating-star">★ <?php echo esc_html(evazar_to_fa_num($r_rating)); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="card-pricing">
                        <?php if ($r_old_price && floatval($r_old_price) > floatval($r_price)): ?>
                            <span class="card-old-price"><?php echo evazar_format_price($r_old_price); ?></span>
                        <?php else: ?>
                            <span class="card-old-price-placeholder">&nbsp;</span>
                        <?php endif; ?>
                        <div class="card-cur-price">
                            <?php if ($r_price): ?>
                                <strong><?php echo evazar_format_price($r_price); ?></strong>
                                <span class="currency">تومان</span>
                            <?php else: ?>
                                <strong>ناموجود</strong>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </article>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    </section>
    <?php endif; endif; ?>

</div>

<!-- EVAZAR CLEAN LIGHTBOX MODAL -->
<div id="evazar-lightbox" class="evazar-lightbox-modal" role="dialog" aria-modal="true" aria-label="گالری تصاویر کالا">
    <div class="lightbox-backdrop" id="lightbox-backdrop"></div>
    <div class="lightbox-dialog">
        <!-- Top Toolbar -->
        <div class="lightbox-toolbar">
            <div class="lightbox-info">
                <span class="lightbox-counter" id="lightbox-counter">۱ از <?php echo max(1, count($gallery_images)); ?></span>
            </div>
            <div class="lightbox-tools">
                <button type="button" class="lightbox-tool-btn lightbox-close-btn" id="lightbox-close-btn" title="بستن (Esc)">
                    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                </button>
            </div>
        </div>

        <!-- Center Image Stage with Arrows -->
        <div class="lightbox-viewport" id="lightbox-viewport">
            <button type="button" class="lightbox-nav prev" id="lightbox-nav-prev" aria-label="تصویر قبلی">
                <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
            </button>

            <div class="lightbox-image-stage" id="lightbox-image-stage">
                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==" data-src="<?php echo esc_url($thumbnail_url); ?>" id="lightbox-img" class="lightbox-img" alt="<?php echo esc_attr(get_the_title()); ?>" decoding="async">
            </div>

            <button type="button" class="lightbox-nav next" id="lightbox-nav-next" aria-label="تصویر بعدی">
                <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
            </button>
        </div>

        <!-- Bottom Thumbnails Bar -->
        <?php if (!empty($gallery_images) && count($gallery_images) > 1): ?>
            <div class="lightbox-thumbs-bar">
                <div class="lightbox-thumbs-list" id="lightbox-thumbs-list">
                    <?php foreach ($gallery_images as $idx => $g_img): ?>
                        <div class="lightbox-thumb <?php echo $idx === 0 ? 'active' : ''; ?>" data-src="<?php echo esc_url($g_img); ?>" data-index="<?php echo $idx; ?>">
                            <img src="<?php echo esc_url(function_exists('evazar_cdn_image_url') ? evazar_cdn_image_url($g_img, 120) : $g_img); ?>" data-src="<?php echo esc_url($g_img); ?>" alt="تصویر <?php echo $idx + 1; ?>" width="120" height="120" loading="lazy" decoding="async">
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const galleryImages = <?php echo json_encode(array_values($gallery_images), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
    let currentIndex = 0;

    // عناصر گالری
    const mainImg = document.getElementById('evazar-main-img');
    const zoomContainer = document.getElementById('evazar-zoom-container');
    const btnZoomTrigger = document.getElementById('btn-zoom-trigger');
    const thumbItems = document.querySelectorAll('.gallery-thumb-item');
    const thumbsTrack = document.getElementById('evazar-gallery-thumbs');
    const arrowPrev = document.getElementById('thumb-arrow-prev');
    const arrowNext = document.getElementById('thumb-arrow-next');

    // عناصر لایت‌باکس
    const lightbox = document.getElementById('evazar-lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxBackdrop = document.getElementById('lightbox-backdrop');
    const lightboxClose = document.getElementById('lightbox-close-btn');
    const lightboxPrev = document.getElementById('lightbox-nav-prev');
    const lightboxNext = document.getElementById('lightbox-nav-next');
    const lightboxCounter = document.getElementById('lightbox-counter');
    const lightboxThumbs = document.querySelectorAll('.lightbox-thumb');

    // 1. بزرگ‌نمایی شناور فقط در دسکتاپ با ماوس (رفع قطعی باگ زوم گیر افتاده در موبایل)
    <?php if ($opt_zoom === '1'): ?>
    const canHoverZoom = window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    if (canHoverZoom && zoomContainer && mainImg) {
        zoomContainer.addEventListener('mousemove', function(e) {
            const rect = zoomContainer.getBoundingClientRect();
            const x = ((e.clientX - rect.left) / rect.width) * 100;
            const y = ((e.clientY - rect.top) / rect.height) * 100;
            mainImg.style.transformOrigin = x + '% ' + y + '%';
            mainImg.style.transform = 'scale(2.2)';
            zoomContainer.classList.add('is-zoomed');
        });

        zoomContainer.addEventListener('mouseleave', function() {
            mainImg.style.transformOrigin = 'center center';
            mainImg.style.transform = 'scale(1)';
            zoomContainer.classList.remove('is-zoomed');
        });
    }
    <?php endif; ?>

    // تصاویر بندانگشتی گالری فقط وقتی وارد محدوده قابل‌مشاهده شوند دانلود می‌شوند.
    function hydrateImage(img) {
        if (!img || img.getAttribute('data-loaded') === '1') return;
        const src = img.getAttribute('data-src');
        if (!src) return;
        img.setAttribute('data-loaded', '1');
        img.src = src;
    }

    if (thumbsTrack && thumbItems.length) {
        const thumbImages = thumbsTrack.querySelectorAll('img[data-src]');
        if ('IntersectionObserver' in window) {
            const thumbObserver = new IntersectionObserver(function(entries, observer) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        hydrateImage(entry.target);
                        observer.unobserve(entry.target);
                    }
                });
            }, { root: thumbsTrack, rootMargin: '160px 160px' });
            thumbImages.forEach(function(img) { thumbObserver.observe(img); });
        } else {
            thumbImages.forEach(hydrateImage);
        }
    }

    function hydrateLightboxAssets() {
        if (lightboxImg) hydrateImage(lightboxImg);
        lightboxThumbs.forEach(function(item) {
            const img = item.querySelector('img[data-src]');
            if (img) hydrateImage(img);
        });
    }

    // 2. تغییر تصویر اصلی با کلیک روی بندانگشتی‌ها و تراز دقیق گوشه‌ای عکس اول
    function setActiveImage(index, isInitial) {
        if (!galleryImages || galleryImages.length === 0) return;
        if (index < 0) index = galleryImages.length - 1;
        if (index >= galleryImages.length) index = 0;
        currentIndex = index;

        const src = galleryImages[currentIndex];
        if (mainImg) {
            mainImg.style.opacity = '0.4';
            mainImg.src = src;
            mainImg.setAttribute('data-index', currentIndex);
            setTimeout(function() {
                mainImg.style.opacity = '1';
            }, 60);
        }

        // بروزرسانی شمارنده موبایل
        const mobileCounter = document.getElementById('evazar-mobile-gallery-counter');
        if (mobileCounter) {
            const faNums = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
            const curFa = String(currentIndex + 1).replace(/[0-9]/g, w => faNums[+w]);
            const totFa = String(galleryImages.length).replace(/[0-9]/g, w => faNums[+w]);
            mobileCounter.textContent = curFa + ' از ' + totFa;
        }

        // بروزرسانی داتس‌های پیجینیشن موبایل
        const dots = document.querySelectorAll('#evazar-gallery-dots .gallery-dot');
        dots.forEach(function(d, dIdx) {
            if (dIdx === currentIndex) {
                d.classList.add('active');
            } else {
                d.classList.remove('active');
            }
        });

        thumbItems.forEach(function(item) {
            const itemIdx = parseInt(item.getAttribute('data-index'), 10);
            if (itemIdx === currentIndex) {
                item.classList.add('active');
                if (thumbsTrack) {
                    if (isInitial || currentIndex === 0) {
                        thumbsTrack.scrollLeft = 0;
                    } else {
                        const trackRect = thumbsTrack.getBoundingClientRect();
                        const itemRect = item.getBoundingClientRect();
                        if (itemRect.left < trackRect.left) {
                            thumbsTrack.scrollBy({ left: itemRect.left - trackRect.left - 12, behavior: 'smooth' });
                        } else if (itemRect.right > trackRect.right) {
                            thumbsTrack.scrollBy({ left: itemRect.right - trackRect.right + 12, behavior: 'smooth' });
                        }
                    }
                }
            } else {
                item.classList.remove('active');
            }
        });
    }

    // تعامل داتس‌های موبایل با کلیک
    document.querySelectorAll('#evazar-gallery-dots .gallery-dot').forEach(function(dot) {
        dot.addEventListener('click', function(e) {
            e.stopPropagation();
            const dIdx = parseInt(this.getAttribute('data-index'), 10);
            setActiveImage(dIdx, false);
        });
    });

    // پشتیبانی کامل از سوایپ افقی لمسی (Touch Swipe) در موبایل بدون تداخل با کلیک
    let isSwiping = false;
    let swipeCooldown = false;
    if (zoomContainer) {
        let touchStartX = 0;
        let touchStartY = 0;
        let touchEndX = 0;
        let touchEndY = 0;

        zoomContainer.addEventListener('touchstart', function(e) {
            if (e.touches && e.touches.length > 0) {
                touchStartX = e.touches[0].clientX;
                touchStartY = e.touches[0].clientY;
                isSwiping = false;
            }
        }, { passive: true });

        zoomContainer.addEventListener('touchmove', function(e) {
            if (e.touches && e.touches.length > 0) {
                const diffX = Math.abs(e.touches[0].clientX - touchStartX);
                const diffY = Math.abs(e.touches[0].clientY - touchStartY);
                if (diffX > 10 && diffX > diffY) {
                    isSwiping = true;
                }
            }
        }, { passive: true });

        zoomContainer.addEventListener('touchend', function(e) {
            if (e.changedTouches && e.changedTouches.length > 0) {
                touchEndX = e.changedTouches[0].clientX;
                touchEndY = e.changedTouches[0].clientY;
                const diffX = touchStartX - touchEndX;
                const diffY = Math.abs(touchStartY - touchEndY);
                if (Math.abs(diffX) > 35 && Math.abs(diffX) > diffY) {
                    isSwiping = true;
                    swipeCooldown = true;
                    if (diffX < 0) {
                        // سوایپ به راست: تصویر بعدی در چیدمان راست‌به‌چپ (RTL)
                        setActiveImage(currentIndex + 1, false);
                    } else {
                        // سوایپ به چپ: تصویر قبلی در چیدمان راست‌به‌چپ (RTL)
                        setActiveImage(currentIndex - 1, false);
                    }
                    setTimeout(function() {
                        swipeCooldown = false;
                        isSwiping = false;
                    }, 350);
                }
            }
        }, { passive: true });
    }

    thumbItems.forEach(function(item) {
        item.addEventListener('click', function() {
            const idx = parseInt(this.getAttribute('data-index'), 10);
            setActiveImage(idx, false);
        });
    });

    // 3. اسکرول افقی نوار بندانگشتی‌ها با کلیدهای قبلی و بعدی
    if (thumbsTrack) {
        thumbsTrack.scrollLeft = 0;

        if (arrowPrev) {
            arrowPrev.addEventListener('click', function(e) {
                e.preventDefault();
                thumbsTrack.scrollBy({ left: 160, behavior: 'smooth' });
            });
        }
        if (arrowNext) {
            arrowNext.addEventListener('click', function(e) {
                e.preventDefault();
                thumbsTrack.scrollBy({ left: -160, behavior: 'smooth' });
            });
        }
    }

    // 4. موتور اختصاصی و سریع لایت‌باکس با دکمه ذره‌بین به‌علاوه یا کلیک تصویر
    function openLightbox(index) {
        if (!lightbox) return;
        if (typeof index === 'number') {
            currentIndex = index;
        }
        hydrateLightboxAssets();
        updateLightboxView();
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';
        const lightboxTrack = document.getElementById('lightbox-thumbs-list');
        if (lightboxTrack && currentIndex === 0) {
            lightboxTrack.scrollLeft = 0;
        }
    }

    function closeLightbox() {
        if (!lightbox) return;
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
    }

    function updateLightboxView() {
        if (!galleryImages || galleryImages.length === 0 || !lightboxImg) return;
        if (currentIndex < 0) currentIndex = galleryImages.length - 1;
        if (currentIndex >= galleryImages.length) currentIndex = 0;

        if (lightboxImg) {
            lightboxImg.style.opacity = '0.4';
            const selectedSrc = galleryImages[currentIndex];
            if (lightboxImg.getAttribute('src') !== selectedSrc) {
                lightboxImg.src = selectedSrc;
                lightboxImg.setAttribute('data-loaded', '1');
            }
            setTimeout(function() {
                if (lightboxImg) lightboxImg.style.opacity = '1';
            }, 60);
        }

        if (lightboxCounter) {
            const faNums = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
            const curFa = String(currentIndex + 1).replace(/\d/g, d => faNums[d]);
            const totalFa = String(galleryImages.length).replace(/\d/g, d => faNums[d]);
            lightboxCounter.textContent = curFa + ' از ' + totalFa;
        }

        const lightboxTrack = document.getElementById('lightbox-thumbs-list');
        lightboxThumbs.forEach(function(lt) {
            const idx = parseInt(lt.getAttribute('data-index'), 10);
            if (idx === currentIndex) {
                lt.classList.add('active');
                if (lightboxTrack) {
                    if (currentIndex === 0) {
                        lightboxTrack.scrollLeft = 0;
                    } else {
                        const trackRect = lightboxTrack.getBoundingClientRect();
                        const itemRect = lt.getBoundingClientRect();
                        if (itemRect.left < trackRect.left) {
                            lightboxTrack.scrollBy({ left: itemRect.left - trackRect.left - 12, behavior: 'smooth' });
                        } else if (itemRect.right > trackRect.right) {
                            lightboxTrack.scrollBy({ left: itemRect.right - trackRect.right + 12, behavior: 'smooth' });
                        }
                    }
                }
            } else {
                lt.classList.remove('active');
            }
        });
    }

    // باز شدن لایت‌باکس با کلیک دکمه ذره‌بین به‌علاوه
    if (btnZoomTrigger) {
        btnZoomTrigger.addEventListener('click', function(e) {
            e.stopPropagation();
            openLightbox(currentIndex);
        });
    }

    // باز شدن لایت‌باکس با کلیک مستقیم روی تصویر اصلی کالا (با محافظت در برابر سوایپ لمسی)
    if (zoomContainer) {
        zoomContainer.addEventListener('click', function(e) {
            if (isSwiping || swipeCooldown) {
                e.preventDefault();
                e.stopPropagation();
                return;
            }
            openLightbox(currentIndex);
        });
    }

    if (lightboxClose) lightboxClose.addEventListener('click', closeLightbox);
    if (lightboxBackdrop) lightboxBackdrop.addEventListener('click', closeLightbox);

    if (lightboxPrev) {
        lightboxPrev.addEventListener('click', function(e) {
            e.stopPropagation();
            currentIndex = (currentIndex - 1 + galleryImages.length) % galleryImages.length;
            updateLightboxView();
            setActiveImage(currentIndex, false);
        });
    }

    if (lightboxNext) {
        lightboxNext.addEventListener('click', function(e) {
            e.stopPropagation();
            currentIndex = (currentIndex + 1) % galleryImages.length;
            updateLightboxView();
            setActiveImage(currentIndex, false);
        });
    }

    // 5. فرامین لمسی بهینه و اختصاصی لایت‌باکس در موبایل (سازگار ۱۰۰٪ با جهت راست‌به‌چپ RTL)
    const lightboxViewport = document.getElementById('lightbox-viewport');
    if (lightboxViewport) {
        let lbTouchStartX = 0;
        let lbTouchStartY = 0;
        let lbTouchEndX = 0;
        let lbTouchEndY = 0;

        lightboxViewport.addEventListener('touchstart', function(e) {
            if (e.touches && e.touches.length === 1) {
                lbTouchStartX = e.touches[0].clientX;
                lbTouchStartY = e.touches[0].clientY;
            }
        }, { passive: true });

        lightboxViewport.addEventListener('touchend', function(e) {
            if (e.changedTouches && e.changedTouches.length > 0) {
                lbTouchEndX = e.changedTouches[0].clientX;
                lbTouchEndY = e.changedTouches[0].clientY;
                const diffX = lbTouchStartX - lbTouchEndX;
                const diffY = Math.abs(lbTouchStartY - lbTouchEndY);

                // آستانه سوایپ افقی بهینه و جلوگیری از تداخل با ژست‌های عمودی
                if (Math.abs(diffX) > 35 && Math.abs(diffX) > diffY) {
                    if (diffX < 0) {
                        // سوایپ به راست: تصویر بعدی در چیدمان راست‌به‌چپ (RTL)
                        currentIndex = (currentIndex + 1) % galleryImages.length;
                    } else {
                        // سوایپ به چپ: تصویر قبلی در چیدمان راست‌به‌چپ (RTL)
                        currentIndex = (currentIndex - 1 + galleryImages.length) % galleryImages.length;
                    }
                    updateLightboxView();
                    setActiveImage(currentIndex, false);
                }
            }
        }, { passive: true });
    }

    lightboxThumbs.forEach(function(lt) {
        lt.addEventListener('click', function(e) {
            e.stopPropagation();
            const idx = parseInt(this.getAttribute('data-index'), 10);
            currentIndex = idx;
            updateLightboxView();
            setActiveImage(currentIndex, false);
        });
    });

    document.addEventListener('keydown', function(e) {
        if (!lightbox || !lightbox.classList.contains('active')) return;
        if (e.key === 'Escape') {
            closeLightbox();
        } else if (e.key === 'ArrowRight') {
            currentIndex = (currentIndex - 1 + galleryImages.length) % galleryImages.length;
            updateLightboxView();
            setActiveImage(currentIndex, false);
        } else if (e.key === 'ArrowLeft') {
            currentIndex = (currentIndex + 1) % galleryImages.length;
            updateLightboxView();
            setActiveImage(currentIndex, false);
        }
    });

    // مقداردهی اولیه تصویر اول در گوشه گالری
    if (thumbItems.length > 0) {
        setActiveImage(0, true);
    }
});

// ثبت بازدید غیرمسدودکننده؛ رندر PHP دیگر DB Write ندارد.
(function() {
    const viewPostId = <?php echo intval($post_id); ?>;
    if (!viewPostId) return;
    try {
        const key = 'evazar_viewed_' + viewPostId;
        if (sessionStorage.getItem(key) === '1') return;
        sessionStorage.setItem(key, '1');
        const data = new URLSearchParams({
            action: 'evazar_track_view',
            post_id: String(viewPostId),
            nonce: <?php echo json_encode(wp_create_nonce('evazar_view_nonce')); ?>
        });
        if (navigator.sendBeacon) {
            navigator.sendBeacon(<?php echo json_encode(admin_url('admin-ajax.php')); ?>, data);
        } else {
            fetch(<?php echo json_encode(admin_url('admin-ajax.php')); ?>, {
                method: 'POST',
                body: data,
                keepalive: true,
                credentials: 'same-origin'
            }).catch(function(){});
        }
    } catch (_) {}
})();

// استعلام زنده و همگام‌سازی بلادرنگ قیمت و موجودی دیجی‌کالا (Live Price & Buybox Sync)
// نوار Sticky موبایل داخل footer.php ساخته می‌شود؛ بنابراین اجرای Live بعد از DOMContentLoaded انجام می‌شود
// تا عناصر Desktop و Mobile هر دو در زمان اعمال پاسخ وجود داشته باشند.
(function() {
    function evazarInitLiveInquiry() {
    const postId = <?php echo intval($post_id); ?>;
    const sku = <?php echo json_encode($sku); ?>;
    if (!postId || !sku) return;

    const ajaxUrl = <?php echo json_encode(admin_url('admin-ajax.php')); ?>;
    const liveNonce = <?php echo json_encode(wp_create_nonce('evazar_live_product_nonce')); ?>;

    fetch(ajaxUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: new URLSearchParams({
            action: 'evazar_live_product_inquiry',
            post_id: postId,
            sku: sku,
            nonce: liveNonce
        })
    })
    .then(res => res.json())
    .then(data => {
        if (!data || !data.success || !data.data) return;
        const d = data.data;

        // ۱. به‌روزرسانی قیمت دسکتاپ
        const mainPriceVal = document.getElementById('evazar-main-price-val');
        const mainPriceUnit = document.getElementById('evazar-main-price-unit');
        const oldPriceLine = document.getElementById('evazar-old-price-line');
        const discPill = document.getElementById('evazar-discount-pill');

        if (mainPriceVal) {
            if (d.is_available && d.price_formatted) {
                mainPriceVal.textContent = d.price_formatted;
                if (mainPriceUnit) mainPriceUnit.style.display = 'block';
            } else {
                mainPriceVal.textContent = 'ناموجود';
                if (mainPriceUnit) mainPriceUnit.style.display = 'none';
            }
        }

        const hasRealDiscount = d.is_available && d.old_price && (Number(d.old_price) > Number(d.price));

        const pHead = document.querySelector('.price-head');
        if (oldPriceLine) {
            if (hasRealDiscount && d.old_price_formatted) {
                oldPriceLine.textContent = d.old_price_formatted + ' تومان';
                oldPriceLine.style.display = 'block';
                if (pHead) pHead.style.display = 'flex';
            } else {
                oldPriceLine.style.display = 'none';
                if (pHead) pHead.style.display = 'none';
            }
        }

        if (discPill) {
            if (hasRealDiscount && d.discount_percent) {
                discPill.textContent = d.discount_percent;
                discPill.style.display = 'inline-block';
            } else {
                discPill.style.display = 'none';
            }
        }

        // ۲. به‌روزرسانی استیکر تخفیف در گالری
        const galleryDiscBadge = document.querySelector('.badge-onsale');
        if (galleryDiscBadge) {
            if (hasRealDiscount && d.discount_percent) {
                galleryDiscBadge.style.display = 'flex';
                const badgeText = galleryDiscBadge.querySelector('.badge-text');
                if (badgeText) badgeText.textContent = d.discount_percent + ' تخفیف';
            } else {
                galleryDiscBadge.style.display = 'none';
            }
        }

        // ۳. به‌روزرسانی نام فروشنده و وضعیت ارسال
        const sellerNameEl = document.getElementById('evazar-seller-name');
        const sellerRateEl = document.getElementById('evazar-seller-rate');
        if (sellerNameEl && d.seller) {
            sellerNameEl.textContent = 'فروشنده: ' + d.seller;
        }
        if (sellerRateEl) {
            if (d.seller_rating !== null && d.seller_rating !== undefined && Number(d.seller_rating) > 0) {
                const ratingNumber = Math.round(Number(d.seller_rating) * 10) / 10;
                const ratingValue = ratingNumber.toLocaleString('fa-IR', Number.isInteger(ratingNumber) ? { maximumFractionDigits: 0 } : { minimumFractionDigits: 1, maximumFractionDigits: 1 });
                sellerRateEl.textContent = 'امتیاز فروشنده: ' + ratingValue + ' از ۵';
                sellerRateEl.style.display = '';
            } else if (d.seller_rate_text && !/^\s*فروشنده\s*[:：]/u.test(String(d.seller_rate_text))) {
                sellerRateEl.textContent = d.seller_rate_text;
                sellerRateEl.style.display = '';
            } else {
                sellerRateEl.textContent = '';
                sellerRateEl.style.display = 'none';
            }
        }

        // ۴. به‌روزرسانی نوار چسبان خرید موبایل (Mobile Sticky Buybox)
        const mPriceContainer = document.querySelector('.mobile-sticky-main-price');
        let mPriceNum = document.querySelector('.mobile-sticky-main-price .price-num');
        let mPriceOut = document.querySelector('.mobile-sticky-main-price .price-out');
        let mPriceUnit = document.querySelector('.mobile-sticky-main-price .price-unit');
        const mOldPrice = document.querySelector('.mobile-sticky-old-price');
        const mDiscBadge = document.querySelector('.mobile-sticky-discount-badge');

        if (mPriceContainer) {
            if (d.is_available && d.price_formatted) {
                if (!mPriceNum) {
                    mPriceNum = document.createElement('span');
                    mPriceNum.className = 'price-num';
                    mPriceContainer.appendChild(mPriceNum);
                }
                if (!mPriceUnit) {
                    mPriceUnit = document.createElement('span');
                    mPriceUnit.className = 'price-unit';
                    mPriceUnit.textContent = 'تومان';
                    mPriceContainer.appendChild(mPriceUnit);
                }
                mPriceNum.textContent = d.price_formatted;
                mPriceNum.style.display = 'inline';
                mPriceUnit.style.display = 'inline';
                if (mPriceOut) mPriceOut.style.display = 'none';
            } else {
                if (!mPriceOut) {
                    mPriceOut = document.createElement('span');
                    mPriceOut.className = 'price-out';
                    mPriceContainer.appendChild(mPriceOut);
                }
                mPriceOut.textContent = 'ناموجود';
                mPriceOut.style.display = 'inline';
                if (mPriceNum) mPriceNum.style.display = 'none';
                if (mPriceUnit) mPriceUnit.style.display = 'none';
            }
        }

        if (mOldPrice) {
            if (hasRealDiscount && d.old_price_formatted) {
                mOldPrice.textContent = d.old_price_formatted;
                mOldPrice.style.display = 'inline';
            } else {
                mOldPrice.style.display = 'none';
            }
        }

        // ۵. به‌روزرسانی بلادرنگ امتیاز ستاره‌ای و تعداد خریداران در صفحه محصول
        const toFa = n => String(n).replace(/\d/g, digit => '۰۱۲۳۴۵۶۷۸۹'[digit]);
        if (d.rating && Number(d.rating) > 0 && d.rating_count && Number(d.rating_count) > 0) {
            let rChip = document.querySelector('.rating-chip');
            if (rChip) {
                rChip.style.display = 'inline-flex';
                const rVal = rChip.querySelector('.rating-val');
                if (rVal) rVal.textContent = toFa(d.rating);
                let rCount = rChip.querySelector('.rating-count');
                if (!rCount) {
                    rCount = document.createElement('span');
                    rCount.className = 'rating-count';
                    rChip.appendChild(rCount);
                }
                rCount.textContent = '(امتیاز ' + toFa(d.rating_count) + ' خریدار)';
            }
        } else {
            const rChip = document.querySelector('.rating-chip');
            if (rChip) rChip.style.display = 'none';
        }

        if (d.satisfaction && Number(d.satisfaction) > 0 && d.rating_count && Number(d.rating_count) > 0) {
            let satEl = document.querySelector('.satisfaction-chip');
            if (satEl) {
                satEl.style.display = 'inline-flex';
                satEl.textContent = toFa(d.satisfaction) + '٪ رضایت خریداران';
            }
        } else {
            const satEl = document.querySelector('.satisfaction-chip');
            if (satEl) satEl.style.display = 'none';
        }

        if (mDiscBadge) {
            if (hasRealDiscount && d.discount_percent) {
                mDiscBadge.textContent = d.discount_percent;
                mDiscBadge.style.display = 'inline-block';
            } else {
                mDiscBadge.style.display = 'none';
            }
        }
    })
    .catch(err => {
        // در صورت خطای شبکه، مقادیر ذخیره‌شده اولیه بدون مشکل حفظ می‌شوند
    });
    }

    function evazarScheduleLiveInquiry() {
        const run = function() {
            if ('requestIdleCallback' in window) {
                window.requestIdleCallback(evazarInitLiveInquiry, { timeout: 1800 });
            } else {
                window.setTimeout(evazarInitLiveInquiry, 1200);
            }
        };
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', run, { once: true });
        } else {
            run();
        }
    }

    evazarScheduleLiveInquiry();
})();
</script>

<?php get_footer(); ?>
