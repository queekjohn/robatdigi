# EVazar Theme 1.9.7
- Fixes product blackout immediately after Product Index deployment.
- Product archive/sort/filter now uses LEFT JOIN with legacy postmeta fallback for products not yet indexed.
- SKU/DKP search falls back to postmeta when an index row does not yet exist.
