<?php
/**
 * قالب اختصاصی نمایش نتایج جستجوی کالاهای ایوازار
 * Template Name: Evazar Search Results
 *
 * @package Evazar
 * @version 1.4.27
 */

require_once get_template_directory() . '/archive.php';
