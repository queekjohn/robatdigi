# EVazar Theme 1.10.7

- Archive first two product-card images are loaded eagerly; only those two receive `fetchpriority="high"` because the measured archive LCP was the second product image.
- Remaining archive product images continue using lazy loading.
- Added intrinsic 360x360 dimensions to archive card images.
- Added a `<main id="primary">` landmark around archive content.
- Corrected archive heading hierarchy so direct sections use H2 and nested category headings use H3.
- Improved contrast for active sort controls, archive prices, discount/price-drop badges, and footer copyright text.
