# EVazar Theme 1.10.5

- Fixed Lighthouse Agent Accessibility audit for the price range slider by assigning the correct `slider` ARIA role to both handles.
- Added horizontal slider semantics while preserving existing keyboard and pointer interactions.
- Reworked filter section collapse chevrons so open and closed states are visually distinct.
- Updated filter arrow markup to decorative, accessible controls.
- Synchronized `readme.txt` theme version with `style.css` (1.10.5).
