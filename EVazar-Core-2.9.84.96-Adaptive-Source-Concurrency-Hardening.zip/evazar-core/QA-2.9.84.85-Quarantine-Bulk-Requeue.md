# QA — EVazar Core 2.9.84.85

## Change
Added a bulk action to the review-quarantine view that returns all currently quarantined queue rows to the existing pending import queue. Existing single-row actions remain unchanged.

## Targeted regression scenarios
- Bulk requeue handles every quarantined row, including different quarantine error codes, while ignoring pending, processing, excluded, completed, and failed rows.
- Queue IDs, DKPs, and related product IDs remain unchanged; no post is deleted or updated.
- Retry count, queue error code, claim token/time, and `next_attempt_at` are reset for the fresh retry generation.
- A repeat click when no quarantined rows remain is an idempotent no-op.
- Database failure returns an error, not success.
- UI appears only on the `quarantined` filter and explicitly says it affects every quarantined row, not only the 50 visible rows.
- AJAX nonce verification and `manage_options` gate remain required.
- Worker stays at 1.13.27 and its source bytes are unchanged.

## Boundaries
These are local automated tests using a fake database and source checks; the action has not been executed on the live EVazar database. Run a live smoke test from WordPress Admin after backup, on the `قرنطینهٔ بررسی` filter.
