# QA — Core 2.9.84.39 Brand Metadata Sync

- Added selector-level metadata synchronization only after exact taxonomy term IDs are validated and persisted.
- Added read-back verification for both display metadata values.
- Single-term replacement writes the selected term name and term-level English name.
- Explicit clearing removes stale product brand metadata.
- Multi-term behavior avoids arbitrary primary selection; it retains a uniquely identifiable existing primary or clears ambiguous scalar metadata.
- Idempotent assignments also reconcile metadata.
- Regression test coverage added for all of the above.
- Cache files and implementation were not modified.
