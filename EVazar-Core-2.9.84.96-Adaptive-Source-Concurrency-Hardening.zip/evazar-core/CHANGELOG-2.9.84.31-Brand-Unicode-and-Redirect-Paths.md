# EVazar Core 2.9.84.31 — Unicode Brand URLs and Digikala Redirect Routes

- Accept explicit Persian/Unicode brand source URL slugs after safe percent-decoding.
- Treat `/brand/{slug}/` and `/brand-landing/{slug}/` as alternate public routes for the same source brand identity, preserving `/brand/{slug}/` as the normalized identity path.
- Source-page proxy accepts Unicode path segments and reports the final redirect path. It fails closed if a brand URL redirects to a different or unrecognized brand slug.
- Legacy brand metadata repair tries up to ten attached product samples when earlier product API payloads are incomplete. It still requires authoritative ID/code/brand URL and two agreeing independent samples when the public slug differs from the source slug.
- Existing public WordPress taxonomy slugs are not rewritten by metadata-only repair.
- No cache purge, cache policy, product index, import queue capacity, or Gemini behavior changes.
