# EVazar Core 2.9.84.73 — Gemini parallel endpoint 4 MiB limit

- Raises the internal parallel endpoint request-body limit from 2 MiB (2,097,152 bytes) to 4 MiB (4,194,304 bytes).
- Keeps the operational HTTP 413 diagnostic limit synchronized with the endpoint's actual limit.
- Does not change batch size, queue/retry/cooldown behavior, worker selection, duplicate protection, or cache behavior. No Worker changes.
- Hosting, proxy, PHP/web-server limits may still impose a lower cap; this change only raises the WordPress endpoint's own limit.
