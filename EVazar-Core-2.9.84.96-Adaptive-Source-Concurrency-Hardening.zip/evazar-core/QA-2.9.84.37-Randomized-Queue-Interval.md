# QA — EVazar Core 2.9.84.37

## Scope
Randomized timing for automatic product-import queue runs, configurable minimum/maximum, one cross-request queue-run lock, and safe migration from prior recurring cron schedules.

## Local regression results
- Random interval / lock / cron regression: **16 passed, 0 failed**.
- Existing-product taxonomy identity sync: **11 passed, 0 failed**.
- Brand source regression: **120 passed, 0 failed**.
- Brand source registration: **19 passed, 0 failed**.
- Brand metadata repair: **26 passed, 0 failed**.
- Category metadata repair: **16 passed, 0 failed**.
- Brand selector: **24 passed, 0 failed**.
- Gemini cooldown/recovery: **32 assertions passed**.
- PHP syntax validation: **20 PHP files passed `php -l`**.
- JavaScript syntax validation: `node --check` passed for all 5 JavaScript files.
- Protected-file comparison against Core 2.9.84.36 confirmed `cache-purge.php`, `product-index.php`, `importer.php`, `brand-source-registration.php`, and `worker/digikala-worker.js` are byte-identical.
- Embedded Worker and standalone Worker 1.13.23 are byte-identical (SHA-256 `1a627ffc7011f3ada8419366d7493b8bc4df57204bdbb9feb6b107ab1256ecfb`).

## Key invariants
- Defaults: minimum 5 minutes, maximum 10 minutes; both inclusive.
- The delay is picked when the current queue request finishes and is measured from that completion timestamp.
- The recurring WP-Cron event is only a safety-net tick, using the minimum bound. Actual automatic runs are gated by `evazar_queue_next_auto_run_at`.
- Automatic follow-ups and due retries cannot bypass the randomized not-before timestamp; item-level `next_attempt_at` and Gemini/Worker cooldowns can delay execution further.
- A persistent atomic option lock permits only one queue run across independent PHP requests. It is released in shutdown handling, and abandoned locks are reclaimed conditionally after 15 minutes.
- Changing the min/max values reschedules the queue and changes cron schedule version to 3. Existing version 2 schedules are migrated on the next admin initialization.
- Manual runs remain on-demand. The existing explicit Resume button keeps its 5-second wake-up; subsequent completed runs return to randomized timing.

## Scope protection
No changes to cache purge, product index, the standalone/embedded Worker, import product parsing, brand registration, stock/price sync, or Gemini API request implementation.

## Not tested
No production WordPress site, real WP-Cron runner, live Cloudflare Worker, or live Digikala/Gemini endpoint was accessed. Local tests use stubs for WordPress scheduling and options; actual cron timing still depends on traffic or a configured system cron.
