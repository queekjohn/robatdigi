# Safe upgrade — EVazar Core 2.9.84.74

1. Back up the current `evazar-core/` plugin folder and the WordPress database.
2. Replace the existing `evazar-core/` plugin folder with the folder in this ZIP; keep the folder name unchanged.
3. No database schema migration is required. A small non-autoloaded WordPress option stores adaptive batch state.
4. Do not redeploy Cloudflare Workers for this release; the Worker source is unchanged.
5. The configured Gemini batch size remains the administrator's maximum. The Core may temporarily use a smaller effective batch after confirmed upstream 5xx errors and recovers after consecutive successful batch requests.
6. Check the operations log for `تنظیم تطبیقی ظرفیت Gemini` to inspect reductions and recovery. Internal endpoint errors and uncertain outcomes are not treated as confirmed upstream 5xx.
7. Local syntax, regression, and functional tests are run for this release. Live hosting, live Gemini requests, and production queue behavior are not tested here.
