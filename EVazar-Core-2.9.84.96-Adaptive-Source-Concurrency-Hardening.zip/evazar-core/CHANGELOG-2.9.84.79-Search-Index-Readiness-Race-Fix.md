# EVazar Core 2.9.84.79 — Search Index Readiness Race Fix

- Closes a narrow concurrency race during transition from `building` to `ready`.
- Readiness is now provisionally activated only after a complete check, followed by a second completeness probe.
- Canonical product-index sync failures persist their error marker before writing the fail-closed `building` state, so concurrent completion cannot silently overwrite a failure.
- No schema, Worker, importer, cache-purge, or live filter behavior changes.
