# Safe upgrade — EVazar Core 2.9.84.77

1. Back up the existing `evazar-core/` folder and the WordPress database.
2. Install Core 2.9.84.77 before installing Theme 1.13.29. Keep the plugin folder name `evazar-core/` unchanged.
3. This release adds two tables using the site's actual WordPress table prefix: `evazar_product_search_index` (normalized product-title document) and `evazar_product_search_terms` (indexed title tokens). It does not alter or drop the existing facet/product-index tables.
4. Search-index creation and backfill run in the existing `evazar_product_index_backfill` event, in batches of up to 250 products per run. With roughly 20,000 products, expect several hours depending on WP-Cron execution and whether any older index rows need repair.
5. While the search index is `building`, live search keeps using the legacy `WP_Query` path. The indexed fast path is enabled only after every published product has a current search document and current Core product-index row, with no recorded sync errors. This is designed to avoid silently omitting unindexed products.
6. Product saves continue syncing the title index automatically. A failed sync keeps the index in `building` and uses retry metadata; the legacy path remains available during recovery.
7. No Cloudflare Worker redeployment is required. `worker/digikala-worker.js` and `cache-purge.php` are byte-identical to the Core 2.9.84.76 baseline. Existing archive filters/category SQL and page-cache purge behavior were not changed.
8. Local syntax, regression and ZIP-integrity tests passed. No live production database benchmark or actual MySQL query-plan test was available in this environment.

## Optional progress check

Use the real WordPress table prefix in place of `wp_`:

```sql
SELECT option_name, option_value
FROM wp_options
WHERE option_name IN (
  'evazar_product_search_index_state',
  'evazar_product_search_index_db_version',
  'evazar_product_search_index_backfill_last_run'
);

SELECT COUNT(*) AS indexed_products FROM wp_evazar_product_search_index;
```

Do not manually set the state to `ready`; the Core backfill marks it ready only after its completeness check succeeds.
