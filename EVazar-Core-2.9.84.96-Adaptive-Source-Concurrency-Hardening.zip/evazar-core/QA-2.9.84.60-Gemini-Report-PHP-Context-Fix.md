# QA — EVazar Core 2.9.84.60

## Fixed

The compact Gemini report had `<?php endif; ?>` immediately before its event-variable preparation block. That closed PHP execution, so lines such as `if (!is_array($event)) continue;` were emitted as literal HTML for every event. The loop now stays in PHP after closing the conditional.

## Verification

- PHP syntax lint for all plugin PHP files and PHP tests.
- All existing Core regression tests, including queue/quarantine and responsive report tests.
- Tokenizer regression asserts the event loop statement is not inside a `T_INLINE_HTML` token.
- JavaScript syntax checks for bundled regression tests and Worker source.

No queue, Worker, Gemini request, or cache logic was changed.
