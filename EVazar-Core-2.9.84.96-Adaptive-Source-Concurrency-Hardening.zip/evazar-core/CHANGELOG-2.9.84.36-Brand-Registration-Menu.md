# EVazar Core 2.9.84.36 — Brand Registration Menu Placement

- Move “ثبت برند از لینک دیجی‌کالا” from the generic WordPress Tools menu into the EVazar custom product admin menu, alongside Core's existing affiliate/Gemini pages.
- Update preview redirects and the cancel/restart link to return to the plugin admin page (`admin.php?page=evazar-brand-source-register`) rather than `tools.php`.
- No changes to Worker code, brand identity logic, product assignment, import queues, taxonomy SEO behavior, redirect maps, product index, pricing/stock, or cache implementation.
