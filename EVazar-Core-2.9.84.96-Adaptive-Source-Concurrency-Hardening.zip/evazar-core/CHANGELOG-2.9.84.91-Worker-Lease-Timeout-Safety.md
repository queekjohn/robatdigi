# EVazar Core 2.9.84.91 — Worker Lease Timeout Safety

## Scope

This is a focused safety correction to the shared primary Digikala Worker lease introduced in 2.9.84.90. It does not change the Cloudflare Worker, Gemini prompts/models, product persistence, taxonomy identity rules, theme, or cache behavior.

## Changes

- Serial primary-Worker dispatch now releases its shared lease only after receiving a valid HTTP response with a positive status code. A transport-level `WP_Error`, timeout, thrown exception, or malformed/no-status result leaves the lease in place because the remote Worker may still be processing the request.
- Parallel product-source dispatch no longer releases every lease in an unconditional `finally` block. Each lease is released independently only when its corresponding response contains a positive HTTP status code.
- If the parallel transport throws or an individual response is missing/unreadable, the uncertain Worker lease remains held; fallback dispatch can use other free Workers but cannot immediately reuse the uncertain endpoint.
- Increased the minimum stale lease window from 90 to 180 seconds, with an additional timeout-derived margin, to cover the Worker-side upstream redirect chain and delayed completion after the PHP client times out.
- Added regression coverage for serial timeout retention, subsequent dispatch exclusion, conservative stale expiry, parallel transport exceptions, successful/error HTTP responses, and partial/missing parallel results.

## Preserved behavior

- Real HTTP responses (including HTTP error statuses) release the matching lease because the endpoint has conclusively returned.
- Lease release remains token-specific; an older request cannot delete a newer owner's lease.
- Product and taxonomy queues continue sharing the same primary Worker leases. Gemini locks and all existing product/taxonomy behavior remain unchanged.
- Embedded and standalone Cloudflare Worker remain version 1.13.27 and are not modified by this release.

## Operational behavior

An uncertain lease may temporarily reduce available Worker capacity for up to the stale window. This is intentional: temporarily deferring work is safer than overlapping requests against a Worker that may still be processing. The normal queue retry mechanism will resume work after capacity returns.
