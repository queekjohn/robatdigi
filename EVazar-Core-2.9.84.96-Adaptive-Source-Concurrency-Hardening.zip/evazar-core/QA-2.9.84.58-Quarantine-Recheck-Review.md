# QA — EVazar Core 2.9.84.58

- Full local PHP regression suite rerun from the package source.
- Full local JavaScript regression suite rerun from the package source.
- PHP/JS syntax checks and ZIP integrity checks passed.
- Added regression assertion that all eight early queue return payloads count quarantined items as processed.
- Added regressions for resetting retry generation on scheduled quarantine retry and preserving a populated related product ID during legacy migration.
- Tests use local stubs/mocked data; no production WordPress DB, live Digikala request, or Cloudflare Worker was changed or exercised.
