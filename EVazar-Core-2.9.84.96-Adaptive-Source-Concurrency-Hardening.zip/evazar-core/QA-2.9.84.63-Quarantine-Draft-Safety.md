# QA — EVazar Core 2.9.84.63

- Added regression cases that allow Draft only for known legacy post-save failures and block the action for preflight failures or unknown reason text.
- Verified both server-side handler guard and UI button guard.
- Existing source preflight still runs before Gemini/checkpoint/product post writes.
- The product remains inspectable via related-product link but the preflight attempt is not described as having saved it.
- Worker and cache code are unchanged.
