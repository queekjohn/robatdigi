# Safe upgrade — EVazar Core 2.9.84.84

1. Back up the current Core plugin and database.
2. Publish the companion Worker 1.13.27 JavaScript to the active Cloudflare Worker. Preserve the existing routes, domains, secrets, API keys, and bindings; no configuration values need to change.
3. Confirm the Worker responds with version `1.13.27` and that a request using `source_page=/search/category-men-sport-shoes-/` is no longer rejected as `Invalid source page path`.
4. Replace Core with `EVazar-Core-2.9.84.84-Category-Source-Trailing-Hyphen-Fix.zip`.
5. Retry only `dkp-22055693` with single-product import. Confirm the source-category preflight error is gone, the product result is correct, and no new category has an empty/guessed source URL.
6. If that passes, test the other three previously quarantined products individually before resuming broader imports.

This release does not change cache settings or cache-purge logic, Gemini prompts/model/settings, queue scheduling, price/stock handling, or product-save behavior. Core installation does not deploy the Cloudflare Worker automatically.
