# QA — EVazar Core 2.9.84.59

Scope: admin presentation only for Gemini operation reports.

- Responsive compact event cards replace the wide 12-column operations table.
- Full technical diagnostics remain available in an expandable detail region.
- Long URLs, DKP lists, and diagnostic strings use word wrapping to avoid horizontal scrolling.
- Worker status table has fixed layout and wrapping.
- Settings-page recent logs are constrained to the container and hide horizontal overflow.
- Queue, import, Worker routing, Gemini request generation, and cache code were not intentionally changed.
- Regression test: `tests/gemini-report-responsive-ui-regression.php`.
