# Safe upgrade — EVazar Core 2.9.84.28

1. Take a fresh database backup and keep the current Core ZIP for rollback.
2. Install Core 2.9.84.28. No database schema migration is required.
3. Keep the product-import queue paused until existing ambiguous/manual brands occupying source slugs have verified source metadata or are reported as blocked.
4. Test one confirmed collision first: a stored brand with source ID `18` owns `lg`; a different incoming source ID should use a separate slug `lg-1` (or the next free numeric suffix), with the original `lg` term untouched.
5. Confirm that the new term stores the source URL/slug separately from `_evazar_dk_public_slug_override=1`, and the product attaches to the source-ID-matched term.
6. Test an exact source slug occupied by a term with no source identity metadata: import must fail closed and must not create `lg-1` based on a guess. Run the admin-only “ترمیم متادیتای برندها” first, review its live-source result, then retry.
7. Resume the queue only after the targeted checks pass.

No cache/Worker deployment is required by this patch. Worker code and the embedded Worker remain unchanged.
8. A pending source-ID marker is internal recovery metadata. The normal successful path removes it after all source fields verify. If a write fails, the queue retries and resolves that pending ID to the same term.
