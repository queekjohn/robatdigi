# EVazar Core 2.9.84.21 — Persist and Verify Brand 301 Before Slug Change

## Fix
- Persist the old-slug → term ID redirect mapping before changing the public brand slug.
- Read the mapping back and verify ownership; abort slug migration if persistence is not confirmed.
- If `wp_update_term()` fails, restore the prior redirect map and return failure.
- Re-read the term after the update and verify that the canonical slug is stored; fail closed if it is not.

## Scope
- No cache behavior changes.
- No Worker, queue, import-batching, or product-assignment changes.
- No existing terms are changed by installing/upgrading this release alone; this protects future import-time migrations.
