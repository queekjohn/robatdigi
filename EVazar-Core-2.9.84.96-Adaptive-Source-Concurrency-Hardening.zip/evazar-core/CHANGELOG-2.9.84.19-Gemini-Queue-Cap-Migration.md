# EVazar Core 2.9.84.19 — Gemini Queue Cap Migration

## Fix
- Corrects the legacy state where `evazar_queue_max_products_per_run` remained at exactly 15 even though per-Worker Gemini request batches had been raised to 30.
- A new one-time migration promotes exactly that saved outer queue cap from 15 to 150 and synchronizes the legacy companion option, enabling Worker-scaled capacity (e.g. four eligible Workers × 30 products = 120) subject to runtime/parallel-transport guards.
- Other saved manual caps are preserved. The migration is one-shot; a site owner can intentionally lower the cap after upgrade.
- No Worker code, product batch-size settings, SEO taxonomy batch limit, queue cooldown/retry policy, theme, or cache logic is changed.

## Why this is required
The effective Gemini queue limit is `min(manual outer cap, configured per-request size × eligible Worker count, 150)`. A stored cap of 15 therefore makes the result 15, regardless of four Workers and a batch size of 30.
