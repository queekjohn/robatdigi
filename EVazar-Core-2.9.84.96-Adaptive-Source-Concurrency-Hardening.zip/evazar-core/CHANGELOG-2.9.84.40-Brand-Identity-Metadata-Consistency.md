# EVazar Core 2.9.84.40 — Brand Identity / Metadata Consistency

- The verified `evazar_brand` term is now the source of product brand display/search metadata after a successful assignment.
- Importer no longer writes raw source brand labels before the taxonomy assignment is verified, avoiding mixed states after failed writes.
- Existing-product queue repair no longer overwrites canonical product metadata with raw source labels after a successful identity sync.
- Read-back verification fails the import/repair path if product brand display metadata cannot be persisted.
- No cache-purge implementation, LiteSpeed handling, Product Index logic, or Worker code was modified.
