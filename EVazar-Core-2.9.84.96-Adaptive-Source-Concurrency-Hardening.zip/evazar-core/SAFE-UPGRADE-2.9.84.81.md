# Safe upgrade — Core 2.9.84.81 + Theme 1.13.30

1. Install Core 2.9.84.81 first; Theme 1.13.30 remains compatible and requires no rebuild for this Core-only correction.
2. Open Products → تنظیمات جستجو and review the live index status.
3. If the stored status was `ready` while live counts were incomplete, the screen will move it to `building`; scheduled backfill can then repair it.
4. Repair respects each product's retry-not-before timestamp and does not truncate index tables.
5. No Worker redeployment, importer change, cache purge, or archive-filter change is required.
