<?php
/**
 * Admin-only manual brand registration from an explicit Digikala brand URL.
 * All upstream calls are server-side through the configured primary Cloudflare Worker.
 * Creates only a new taxonomy term + verified source metadata; never assigns products,
 * changes existing terms, writes redirects, or calls Digikala directly. It does not call cache
 * purge APIs directly; standard WordPress hooks fire normally when a taxonomy term is created.
 */
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', 'evazar_bsr_register_menu');
add_action('admin_post_evazar_bsr_preview', 'evazar_bsr_handle_preview');
add_action('admin_post_evazar_bsr_create', 'evazar_bsr_handle_create');

function evazar_bsr_register_menu() {
    // Keep brand registration beside the other EVazar Core tools under the custom product menu.
    add_submenu_page(
        'edit.php?post_type=evazar_product',
        'ثبت برند از لینک دیجی‌کالا',
        'ثبت برند از لینک دیجی‌کالا',
        'manage_options',
        'evazar-brand-source-register',
        'evazar_bsr_render_page'
    );
}

function evazar_bsr_admin_page_url($args = array()) {
    $args = is_array($args) ? $args : array();
    $args = array_merge(array('page' => 'evazar-brand-source-register'), $args);
    return add_query_arg($args, admin_url('admin.php'));
}

function evazar_bsr_state_key($token) {
    return 'evazar_bsr_' . get_current_user_id() . '_' . substr(hash('sha256', (string)$token), 0, 24);
}

function evazar_bsr_redirect_state($kind, $data) {
    $token = wp_generate_password(40, false, false);
    set_transient(evazar_bsr_state_key($token), array_merge(array('kind'=>$kind, 'created_at'=>time()), is_array($data) ? $data : array()), 15 * MINUTE_IN_SECONDS);
    wp_safe_redirect(evazar_bsr_admin_page_url(array('notice' => $token)));
    exit;
}

function evazar_bsr_get_state($token) {
    $token = is_string($token) ? trim($token) : '';
    if ($token === '' || !preg_match('/^[A-Za-z0-9]{24,64}$/', $token)) return false;
    $state = get_transient(evazar_bsr_state_key($token));
    return is_array($state) ? $state : false;
}

function evazar_bsr_normalize_source_path($value) {
    if (!function_exists('evazar_normalize_digikala_brand_source_path')) return '';
    return evazar_normalize_digikala_brand_source_path((string)$value);
}

function evazar_bsr_slug_from_path($path) {
    $path = evazar_bsr_normalize_source_path((string)$path);
    if ($path === '' || !preg_match('#^/brand/([\p{L}\p{M}\p{N}]+(?:[._-][\p{L}\p{M}\p{N}]+)*)/$#iu', $path, $m)) return '';
    $slug = (string)$m[1];
    if (class_exists('Normalizer')) {
        $normalized = Normalizer::normalize($slug, Normalizer::FORM_C);
        if (is_string($normalized)) $slug = $normalized;
    }
    return function_exists('mb_strtolower') ? mb_strtolower($slug, 'UTF-8') : strtolower($slug);
}

function evazar_bsr_fetch_identity_via_worker($input_url) {
    $source_path = evazar_bsr_normalize_source_path((string)$input_url);
    $expected_slug = evazar_bsr_slug_from_path($source_path);
    if ($source_path === '' || $expected_slug === '') return new WP_Error('evazar_bsr_invalid_url', 'لینک باید مستقیماً به صفحهٔ یک برند در دیجی‌کالا اشاره کند.');

    // Do not silently use img.evazar.ir or any other legacy fallback as the main Worker.
    $configured_pool = trim((string)get_option('evazar_cf_worker_urls', ''));
    $configured_single = trim((string)get_option('evazar_cf_worker_url', ''));
    // Do not rely on raw option non-emptiness: evazar_get_primary_worker_urls() has a legacy
    // image-host fallback when configured entries sanitize to nothing. This tool must fail closed.
    $valid_pool = function_exists('evazar_sanitize_primary_worker_urls')
        ? trim((string)evazar_sanitize_primary_worker_urls($configured_pool)) : '';
    $valid_single = function_exists('evazar_sanitize_primary_worker_urls')
        ? trim((string)evazar_sanitize_primary_worker_urls($configured_single)) : '';
    if ($valid_pool === '' && $valid_single === '') {
        return new WP_Error('evazar_bsr_worker_unconfigured', 'هیچ آدرس معتبر Worker اصلی دیجی‌کالا در تنظیمات Core تعیین نشده است؛ درخواست ارسال نشد.');
    }
    if (trim((string)get_option('evazar_cf_worker_token', '')) === '') {
        return new WP_Error('evazar_bsr_worker_token_missing', 'توکن داخلی Worker در تنظیمات Core خالی است؛ درخواست ارسال نشد.');
    }
    if (!function_exists('evazar_primary_worker_request') || !function_exists('evazar_worker_auth_headers')) {
        return new WP_Error('evazar_bsr_worker_helper_missing', 'توابع ارتباط امن Core با Worker در دسترس نیستند.');
    }

    $headers = array_merge(array(
        'Accept' => 'application/json',
        'Content-Type' => 'application/json; charset=utf-8',
        'Cache-Control' => 'no-store',
        'Pragma' => 'no-cache',
    ), evazar_worker_auth_headers());
    $response = evazar_primary_worker_request('brand-source/inspect', array(), array(
        'timeout' => 25,
        'redirection' => 0,
        'reject_unsafe_urls' => true,
        'headers' => $headers,
        'body' => wp_json_encode(array('source_url'=>$source_path)),
    ), 'POST', 'brand_register');
    if (is_wp_error($response)) {
        return new WP_Error('evazar_bsr_worker_request_failed', 'درخواست سرور به Worker ناموفق بود: ' . $response->get_error_message());
    }
    $status = (int)wp_remote_retrieve_response_code($response);
    $body = (string)wp_remote_retrieve_body($response);
    $json = json_decode($body, true);
    if ($status !== 200 || !is_array($json) || empty($json['success']) || !is_array($json['identity'] ?? null)) {
        $detail = is_array($json) ? sanitize_text_field((string)($json['message'] ?? $json['error'] ?? '')) : '';
        $detail = $detail !== '' ? $detail : 'پاسخ هویت معتبر از Worker دریافت نشد.';
        return new WP_Error('evazar_bsr_worker_source_failed', 'Worker اطلاعات برند را تأیید نکرد (HTTP ' . $status . '): ' . $detail, array('http_status'=>$status));
    }

    $raw = $json['identity'];
    $identity_path = evazar_bsr_normalize_source_path((string)($raw['source_url'] ?? ''));
    $identity_slug = evazar_bsr_slug_from_path($identity_path);
    $id = trim((string)($raw['brand_id'] ?? ''));
    $code = sanitize_text_field((string)($raw['brand_code'] ?? ''));
    $fa = sanitize_text_field((string)($raw['brand_fa'] ?? ''));
    $en = sanitize_text_field((string)($raw['brand_en'] ?? ''));
    if ($identity_path !== $source_path || $identity_slug === '' || $identity_slug !== $expected_slug
        || !ctype_digit($id) || (int)$id <= 0 || $code === '' || $fa === '') {
        return new WP_Error('evazar_bsr_worker_identity_mismatch', 'اطلاعات هویت برگشتی با لینک واردشده سازگار نیست؛ ثبت متوقف شد.');
    }
    if (empty($raw['url_confirmed']) && empty($raw['code_confirmed'])) {
        return new WP_Error('evazar_bsr_worker_identity_unconfirmed', 'Worker تطبیق URL یا کد منبع با نامک واردشده را تأیید نکرد.');
    }

    return array(
        'brand_id' => $id,
        'brand_code' => $code,
        'brand_fa' => $fa,
        'brand_en' => $en,
        'source_url' => $identity_path,
        'source_slug' => $identity_slug,
        'api_source_url' => evazar_bsr_normalize_source_path((string)($raw['api_source_url'] ?? '')),
        'url_confirmed' => !empty($raw['url_confirmed']),
        'code_confirmed' => !empty($raw['code_confirmed']),
        'worker_version' => sanitize_text_field((string)($json['version'] ?? '')),
        'source_api' => sanitize_key((string)($json['source_api'] ?? '')),
        'public_slug' => sanitize_title($identity_slug),
    );
}

function evazar_bsr_check_conflicts($identity) {
    if (!taxonomy_exists('evazar_brand')) return new WP_Error('evazar_bsr_taxonomy_missing', 'تاکسونومی برند ایوازار در این درخواست در دسترس نیست.');
    $id = (string)($identity['brand_id'] ?? '');
    $source_url = (string)($identity['source_url'] ?? '');
    $source_slug = (string)($identity['source_slug'] ?? '');
    $public_slug = (string)($identity['public_slug'] ?? '');
    if ($id === '' || $source_url === '' || $source_slug === '' || $public_slug === '') return new WP_Error('evazar_bsr_identity_incomplete', 'هویت منبع یا نامک عمومی برند ناقص است.');

    $terms = get_terms(array('taxonomy'=>'evazar_brand', 'hide_empty'=>false, 'number'=>0));
    if (is_wp_error($terms)) return new WP_Error('evazar_bsr_terms_unreadable', 'فهرست برندهای ایوازار برای بررسی تعارض قابل خواندن نیست.');
    foreach ((array)$terms as $term) {
        if (!is_object($term) || empty($term->term_id)) continue;
        $term_id = (int)$term->term_id;
        $saved_id = trim((string)get_term_meta($term_id, '_evazar_dk_brand_id', true));
        if ($saved_id === '') $saved_id = trim((string)get_term_meta($term_id, '_evazar_dk_brand_source_id_pending', true));
        $saved_path = evazar_bsr_normalize_source_path((string)get_term_meta($term_id, '_evazar_dk_url', true));
        if ($saved_id !== '' && ctype_digit($saved_id) && $saved_id === $id) {
            return new WP_Error('evazar_bsr_source_id_exists', 'شناسهٔ دیجی‌کالا ' . $id . ' از قبل در ترم ' . $term_id . ' ثبت/رزرو شده است؛ ترم تکراری ساخته نشد.');
        }
        if ($saved_path !== '' && $saved_path === $source_url) {
            return new WP_Error('evazar_bsr_source_url_exists', 'این URL منبع از قبل به ترم ' . $term_id . ' تعلق دارد؛ ترم تکراری ساخته نشد.');
        }
    }

    $slug_owner = get_term_by('slug', $public_slug, 'evazar_brand');
    if ($slug_owner && !is_wp_error($slug_owner)) {
        return new WP_Error('evazar_bsr_public_slug_exists', 'نامک عمومی «' . $public_slug . '» از قبل متعلق به ترم ' . (int)$slug_owner->term_id . ' است. ابزار برای جلوگیری از ادغام/تغییر ناخواسته، نامک موجود را تصاحب نمی‌کند.');
    }
    $redirect_map = function_exists('evazar_brand_slug_redirect_map') ? evazar_brand_slug_redirect_map() : get_option('evazar_brand_slug_redirects', array());
    if (is_array($redirect_map) && isset($redirect_map[$public_slug]) && absint($redirect_map[$public_slug]) > 0) {
        return new WP_Error('evazar_bsr_redirect_slug_reserved', 'نامک «' . $public_slug . '» در نگاشت ریدایرکت موجود رزرو شده است؛ ابزار ریدایرکت‌ها را تغییر نمی‌دهد.');
    }
    return true;
}

function evazar_bsr_handle_preview() {
    if (!current_user_can('manage_options')) wp_die('دسترسی مدیر لازم است.', '', array('response' => 403));
    check_admin_referer('evazar_bsr_preview', 'evazar_bsr_nonce');
    $url = isset($_POST['source_url']) ? trim((string)wp_unslash($_POST['source_url'])) : '';
    $identity = evazar_bsr_fetch_identity_via_worker($url);
    if (is_wp_error($identity)) evazar_bsr_redirect_state('error', array('message'=>$identity->get_error_message()));
    $conflict = evazar_bsr_check_conflicts($identity);
    if (is_wp_error($conflict)) evazar_bsr_redirect_state('error', array('message'=>$conflict->get_error_message()));
    evazar_bsr_redirect_state('preview', array('identity'=>$identity, 'input_url'=>$url));
}

function evazar_bsr_handle_create() {
    if (!current_user_can('manage_options')) wp_die('دسترسی مدیر لازم است.', '', array('response' => 403));
    $token = isset($_POST['preview_token']) ? sanitize_text_field(wp_unslash($_POST['preview_token'])) : '';
    check_admin_referer('evazar_bsr_create_' . $token, 'evazar_bsr_nonce');
    $state = evazar_bsr_get_state($token);
    if (!$state || ($state['kind'] ?? '') !== 'preview' || !is_array($state['identity'] ?? null)) {
        evazar_bsr_redirect_state('error', array('message'=>'پیش‌نمایش منقضی یا نامعتبر است؛ دوباره لینک برند را بررسی کن.'));
    }
    $before = $state['identity'];
    $fresh = evazar_bsr_fetch_identity_via_worker((string)($state['input_url'] ?? ''));
    if (is_wp_error($fresh)) {
        delete_transient(evazar_bsr_state_key($token));
        evazar_bsr_redirect_state('error', array('message'=>'تأیید دوباره از Worker ناموفق بود؛ برند ساخته نشد. ' . $fresh->get_error_message()));
    }
    // Revalidate not only the identity tuple but also the evidence used to confirm it.
    // For example, if the API supplied an explicit matching URL during preview but drops it
    // before confirmation, do not silently downgrade to code-only confirmation.
    foreach (array('brand_id','brand_code','brand_fa','brand_en','source_url','source_slug','public_slug','api_source_url','url_confirmed','code_confirmed','source_api') as $field) {
        if ((string)($before[$field] ?? '') !== (string)($fresh[$field] ?? '')) {
            delete_transient(evazar_bsr_state_key($token));
            evazar_bsr_redirect_state('error', array('message'=>'اطلاعات منبع از زمان پیش‌نمایش تغییر کرده است؛ برای جلوگیری از ثبت هویت نادرست، عملیات متوقف شد. دوباره پیش‌نمایش بگیر.'));
        }
    }
    $conflict = evazar_bsr_check_conflicts($fresh);
    if (is_wp_error($conflict)) {
        delete_transient(evazar_bsr_state_key($token));
        evazar_bsr_redirect_state('error', array('message'=>$conflict->get_error_message()));
    }
    $inserted = wp_insert_term((string)$fresh['brand_fa'], 'evazar_brand', array('slug'=>(string)$fresh['public_slug']));
    if (is_wp_error($inserted) || !is_array($inserted) || empty($inserted['term_id'])) {
        $message = is_wp_error($inserted) ? $inserted->get_error_message() : 'WordPress شناسهٔ ترم جدید را برنگرداند.';
        delete_transient(evazar_bsr_state_key($token));
        evazar_bsr_redirect_state('error', array('message'=>'ساخت برند انجام نشد: ' . $message));
    }
    $term_id = absint($inserted['term_id']);
    $now = gmdate('c');
    $meta = array(
        '_evazar_brand_en' => sanitize_text_field((string)$fresh['brand_en']),
        '_evazar_dk_brand_id' => (string)$fresh['brand_id'],
        '_evazar_dk_brand_code' => sanitize_text_field((string)$fresh['brand_code']),
        '_evazar_dk_slug' => sanitize_text_field((string)$fresh['source_slug']),
        '_evazar_dk_url' => (string)$fresh['source_url'],
        '_evazar_dk_source_map_version' => '2.9.84.33-live-brand-registration',
        '_evazar_dk_source_path_updated' => $now,
        '_evazar_dk_public_slug_override' => '0',
        '_evazar_dk_public_slug_override_reason' => '',
        '_evazar_dk_source_verified' => '0',
    );
    $write_ok = true;
    foreach ($meta as $key=>$value) {
        update_term_meta($term_id, $key, $value);
        if ((string)get_term_meta($term_id, $key, true) !== (string)$value) { $write_ok = false; break; }
    }
    if ($write_ok) {
        update_term_meta($term_id, '_evazar_dk_source_verified', '1');
        $write_ok = (string)get_term_meta($term_id, '_evazar_dk_source_verified', true) === '1';
    }
    $created_term = get_term($term_id, 'evazar_brand');
    if (!$created_term || is_wp_error($created_term) || (string)$created_term->name !== (string)$fresh['brand_fa']
        || sanitize_title((string)$created_term->slug) !== (string)$fresh['public_slug']) $write_ok = false;

    if (!$write_ok) {
        // This is a term created by this request; with failed metadata verification, remove only this new term.
        wp_delete_term($term_id, 'evazar_brand');
        delete_transient(evazar_bsr_state_key($token));
        evazar_bsr_redirect_state('error', array('message'=>'ذخیره/بازخوانی کامل متادیتای برند تأیید نشد؛ ترم تازه ایجادشده حذف شد و برند ثبت‌نشده باقی نماند.'));
    }

    // Match normal importer behavior: newly created brand terms are added to the independent SEO queue.
    // This runs only after the new term and all source metadata have passed read-back verification.
    if (function_exists('evazar_taxonomy_seo_enqueue_new_term')) {
        evazar_taxonomy_seo_enqueue_new_term($term_id, 'evazar_brand', 0);
    }

    delete_transient(evazar_bsr_state_key($token));
    evazar_bsr_redirect_state('success', array(
        'term_id'=>$term_id,
        'name'=>(string)$fresh['brand_fa'],
        'slug'=>(string)$created_term->slug,
        'source_url'=>(string)$fresh['source_url'],
        'message'=>'برند و متادیتای منبع ثبت و از دیتابیس بازخوانی شد. هیچ محصولی به آن متصل نشده است.',
    ));
}

function evazar_bsr_render_page() {
    if (!current_user_can('manage_options')) return;
    $token = isset($_GET['notice']) ? sanitize_text_field(wp_unslash($_GET['notice'])) : '';
    $state = $token !== '' ? evazar_bsr_get_state($token) : false;
    echo '<div class="wrap"><h1>ثبت برند از لینک دیجی‌کالا</h1>';
    echo '<p>لینک دقیق صفحهٔ برند را وارد کن. درخواست از سرور وردپرس به Worker اصلی تنظیم‌شده ارسال می‌شود؛ مرورگر مستقیماً به دیجی‌کالا یا Worker درخواست نمی‌زند. ابزار فقط برند و متادیتای منبع را ثبت می‌کند و محصولات یا ریدایرکت‌ها را تغییر نمی‌دهد. خودش پاک‌سازی کش را صدا نمی‌زند؛ هوک‌های معمول وردپرس هنگام ایجاد ترم طبق تنظیمات فعلی سایت اجرا می‌شوند.</p>';

    if ($state && ($state['kind'] ?? '') === 'error') {
        echo '<div class="notice notice-error"><p>' . esc_html((string)($state['message'] ?? 'عملیات ناموفق بود.')) . '</p></div>';
        delete_transient(evazar_bsr_state_key($token));
    } elseif ($state && ($state['kind'] ?? '') === 'success') {
        $edit_url = admin_url('term.php?taxonomy=evazar_brand&tag_ID=' . absint($state['term_id'] ?? 0) . '&post_type=evazar_product');
        echo '<div class="notice notice-success"><p>' . esc_html((string)($state['message'] ?? 'ثبت شد.')) . '</p><p>ترم: ' . absint($state['term_id'] ?? 0) . ' — ' . esc_html((string)($state['name'] ?? '')) . ' — <code>' . esc_html((string)($state['slug'] ?? '')) . '</code></p><p>منبع: <code>' . esc_html((string)($state['source_url'] ?? '')) . '</code></p><p><a href="' . esc_url($edit_url) . '">ویرایش برند در وردپرس</a></p></div>';
        delete_transient(evazar_bsr_state_key($token));
    } elseif ($state && ($state['kind'] ?? '') === 'preview' && is_array($state['identity'] ?? null)) {
        $i = $state['identity'];
        echo '<h2>پیش‌نمایش هویت دریافت‌شده</h2><table class="widefat striped" style="max-width:900px"><tbody>';
        $rows = array(
            'نام فارسی منبع' => (string)($i['brand_fa'] ?? ''),
            'نام انگلیسی منبع' => (string)($i['brand_en'] ?? ''),
            'شناسهٔ برند دیجی‌کالا' => (string)($i['brand_id'] ?? ''),
            'کد برند دیجی‌کالا' => (string)($i['brand_code'] ?? ''),
            'URL منبع' => (string)($i['source_url'] ?? ''),
            'نامک منبع' => (string)($i['source_slug'] ?? ''),
            'نامک عمومی پیشنهادی ایوازار' => (string)($i['public_slug'] ?? ''),
            'نسخهٔ Worker' => (string)($i['worker_version'] ?? ''),
            'تأیید تطبیق' => (!empty($i['url_confirmed']) ? 'URL API' : '') . (!empty($i['url_confirmed']) && !empty($i['code_confirmed']) ? ' + ' : '') . (!empty($i['code_confirmed']) ? 'کد برند' : ''),
        );
        foreach ($rows as $label=>$value) echo '<tr><th style="width:260px">' . esc_html($label) . '</th><td>' . ($value === '' ? '—' : '<code>' . esc_html($value) . '</code>') . '</td></tr>';
        echo '</tbody></table>';
        echo '<p>پس از تأیید، ابزار یک ترم جدید می‌سازد و متادیتا را ذخیره و بازخوانی می‌کند. هیچ محصولی به این برند متصل نمی‌شود.</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="evazar_bsr_create"><input type="hidden" name="preview_token" value="' . esc_attr($token) . '">';
        wp_nonce_field('evazar_bsr_create_' . $token, 'evazar_bsr_nonce');
        submit_button('تأیید و ثبت برند', 'primary', 'submit', false);
        echo ' <a class="button" href="' . esc_url(evazar_bsr_admin_page_url()) . '">لغو و شروع دوباره</a></form>';
    }

    echo '<hr><h2>بررسی لینک جدید</h2><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="max-width:900px">';
    echo '<input type="hidden" name="action" value="evazar_bsr_preview">';
    wp_nonce_field('evazar_bsr_preview', 'evazar_bsr_nonce');
    echo '<label for="evazar-bsr-source-url"><strong>لینک صفحهٔ برند دیجی‌کالا</strong></label><br>';
    echo '<input id="evazar-bsr-source-url" name="source_url" type="url" required inputmode="url" placeholder="https://www.digikala.com/brand/carrera-brand/" style="width:100%;max-width:760px;direction:ltr;margin-top:8px" autocomplete="off">';
    echo '<p class="description">فقط لینک صفحهٔ برند پذیرفته می‌شود؛ لینک محصول یا دامنهٔ دیگر پذیرفته نیست. نام‌ها و شناسه از پاسخ API منبع گرفته می‌شوند، نه از تبدیل نام انگلیسی به نامک.</p>';
    submit_button('دریافت اطلاعات و پیش‌نمایش', 'secondary', 'submit', false);
    echo '</form></div>';
}
