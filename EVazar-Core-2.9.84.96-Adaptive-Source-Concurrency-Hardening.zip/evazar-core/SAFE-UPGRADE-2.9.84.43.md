# Safe Upgrade — EVazar Core 2.9.84.43

This is a targeted Core-only fix for the stale 30-DKP cap left after Gemini batch sizes were raised to 50.

- Upgrade the existing `evazar-core` plugin using the supplied ZIP.
- Keep existing settings and queue data; no database migration is required.
- This Core fix does not change the Worker source. However, batches above 30 require every active Gemini Worker endpoint to already run Worker 1.13.24 or later; Worker 1.13.23 still rejects batches above 30.
- This release does not modify LiteSpeed/cache code or queue interval settings.
- After updating, confirm the admin reports Core `2.9.84.43`; then run one normal 40-product import batch and inspect Gemini operation logs before relying on full throughput.
