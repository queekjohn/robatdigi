# Safe Upgrade — EVazar Core 2.9.84.35 / Worker 1.13.23

1. Ensure Worker 1.13.23 is deployed to every active primary Worker URL and `EVAZAR_INTERNAL_TOKEN` matches the Core internal token.
2. Upgrade EVazar Core to 2.9.84.35.
3. Open Tools → ثبت برند از لینک دیجی‌کالا, preview a known source brand URL, verify the live identity and confirm only when expected.

The registration tool refuses to dispatch if neither the primary Worker pool nor the explicit legacy primary Worker URL contains a syntactically valid HTTPS URL. It does not use the image-host fallback. Before creating, it fetches identity again and requires the identity fields and confirmation evidence to match preview.

No product assignment or existing term edits are performed. Redirect maps are untouched. `cache-purge.php` and `product-index.php` remain byte-for-byte unchanged from 2.9.84.32, though the existing WordPress `created_evazar_brand` hook can issue the normal exact-term archive purge upon brand creation. No live WordPress database or Cloudflare deployment was tested by this QA.
