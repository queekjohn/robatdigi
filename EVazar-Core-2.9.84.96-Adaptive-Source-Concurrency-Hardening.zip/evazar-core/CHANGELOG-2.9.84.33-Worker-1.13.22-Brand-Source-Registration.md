# EVazar Core 2.9.84.33 / Worker 1.13.22

- Added Tools → ثبت برند از لینک دیجی‌کالا in Core.
- Brand URL inspection is performed server-side through the configured primary Worker only; no direct Core-to-Digikala fallback exists in this tool.
- Added authenticated Worker endpoint `POST /brand-source/inspect`, using Digikala's fixed brand search API route and validating explicit brand identity.
- Registration requires a separate admin confirmation after preview and re-fetches live identity before insert.
- Writes source ID, code, URL, source slug, English name, verified state and provenance; verifies metadata readback.
- Stops on existing source ID/URL, existing public slug, or reserved redirect slug.
- Never assigns products, edits existing brand terms, modifies redirects, or performs cache operations.
- Local regression, PHP/JS syntax and ZIP integrity checks run at packaging time; no live Worker or WordPress was accessed.
