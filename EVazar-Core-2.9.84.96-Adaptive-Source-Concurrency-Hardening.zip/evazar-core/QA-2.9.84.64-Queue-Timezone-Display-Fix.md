# QA — EVazar Core 2.9.84.64

## Scope
Correct local rendering of Unix timestamps in queue retry/cooldown messages and queue statistics. Scheduling timestamps and comparisons remain unchanged.

## Targeted checks
- `tests/queue-local-time-display-regression.php`: source-path checks that all affected queue-manager call sites use the local formatter and no raw `date_i18n()` timestamp conversion remains.
- `tests/QA-2.9.84.13-Gemini-Cooldown-Local-Test.php`: behavior of the actual shared formatter under mocked WordPress timezone `Europe/Berlin`, including full date-time, time-only display, and zero timestamp.
- `tests/product-source-parallel-fetch-regression.php`: isolated queue-manager load also succeeds when importer is not loaded first, validating the fallback formatter.
- PHP syntax validation for all plugin PHP files.
- Full existing PHP and JavaScript regression suites.
