# Deep Review QA — EVazar Core 2.9.84.35 / Worker 1.13.23
Date: 2026-10-25

## Review performed
Compared the full Core 2.9.84.34 package to 2.9.84.32, compared Worker 1.13.23 to 1.13.22, inspected registration and identity code, re-ran all bundled PHP/JavaScript regression scripts, linted all PHP files, ran Node syntax checks, checked ZIP integrity, and compared embedded/standalone Worker hashes.

## Additional issues found and fixed in Core 2.9.84.35
1. **Invalid Worker URL fallback guard:** the first registration implementation tested only whether the raw Worker options were non-empty. If a non-empty pool contained no valid HTTPS URLs and the explicit legacy Worker URL was empty, the shared dispatch helper could fall back to the configured image-host URL. Registration now validates the configured pool/legacy values with the Core URL sanitizer and refuses to dispatch unless one valid configured Worker URL exists. No change was made to the shared dispatcher, so product import behavior is unchanged.
2. **Confirmation evidence consistency:** the create step previously compared core identity fields but did not compare the evidence type used to confirm identity. It now compares `api_source_url`, `url_confirmed`, `code_confirmed`, and `source_api` with the server-side preview snapshot; a dropped/changed API URL or weaker confirmation evidence blocks creation and requires a new preview.

## Full request path and safety review
- Tools page is admin-only (`manage_options`); preview/create posts use WordPress nonces.
- Preview state is user-scoped and transient-backed with a random 40-character token and 15-minute expiry.
- Core accepts only normalized Digikala brand routes (`/brand/{slug}/` and supported `/brand-landing/{slug}/` alias). Foreign hosts, credentials, ports, query/fragment, traversal and encoded path separators are rejected.
- Browser submits to WordPress `admin-post.php`. Server-to-Worker calls use the configured primary Worker dispatcher and `X-Evazar-Internal-Token`; there is no direct Core-to-Digikala fallback. Core now also fails closed when configured Worker options contain no valid HTTPS URL.
- Worker endpoint `/brand-source/inspect` independently checks the internal token and POST method, rejects oversized JSON bodies, calls only the fixed `api.digikala.com` host and the brand-search path derived from the validated slug, and returns only explicit `data.brand` identity fields.
- It never guesses a source slug from `brand_en`, Persian title or the public WordPress slug. If API URL is present but conflicts with the entered source URL, registration is rejected even when code matches. If URL is missing, source code must match the requested source slug.
- Confirmation re-fetches source identity; source identifiers, names, URL/slug, public slug, API URL and confirmation evidence must match preview.
- Conflict guards stop duplicate source IDs, duplicate source URLs, public slug collisions and redirect-reserved slugs. No existing term, redirect mapping or product-brand assignment is edited.
- Creation writes source fields, reads them back, marks `_evazar_dk_source_verified=1` last, validates the created term, and deletes only the newly created term if metadata verification fails.
- A newly created brand is added to the existing taxonomy SEO queue after the metadata write-back succeeds.

## Tests re-run in this review
- Brand registration regression: **15 passed, 0 failed** (includes invalid but non-empty Worker pool must fail closed and preview confirmation evidence is checked).
- Core brand/source regression: **120 passed, 0 failed**.
- Brand metadata repair regression: **26 passed, 0 failed**.
- Category metadata repair regression: **16 passed, 0 failed**.
- Queue taxonomy identity sync regression: **11 passed, 0 failed**.
- Brand selector regression: **24 passed, 0 failed**.
- Gemini cooldown/recovery regression: **32 assertions passed**.
- Worker source regression: **41 passed, 0 failed**.
- Authenticated Worker brand-audit regression: **6 passed, 0 failed**.
- PHP syntax: all PHP files in package passed `php -l`.
- JavaScript: Worker and all bundled `.js` regression files passed `node --check`.
- Both ZIPs passed `unzip -t`.
- Embedded Worker SHA-256 equals standalone Worker SHA-256: `1a627ffc7011f3ada8419366d7493b8bc4df57204bdbb9feb6b107ab1256ecfb`.
- `cache-purge.php` remains byte-for-byte identical to Core 2.9.84.32 (SHA-256 `8cea2666c9a31a2122c74f855ced41586db2fc0cb57491ddddc7da9ae2148e2e`). `product-index.php` remains byte-for-byte identical (SHA-256 `73794a104b6289b5abc279c6943a5707e15880ffd8b6a02d35c38bfdbb6a0cff`).

## Scope of changes against Core 2.9.84.34
Production code changed in 2.9.84.35:
- `evazar-core.php`: version header only.
- `brand-source-registration.php`: strict configured-Worker URL guard and preview evidence consistency check.
- `tests/brand-source-registration-regression.php`: regression tests for both protections.
- Documentation/QA files were added.
- Embedded Worker remains 1.13.23; no Worker source change was needed for these Core-only fixes.

Earlier 2.9.84.34 changes retained from Core 2.9.84.32 include the registration tool, trusted metadata provenance recognition, queue identity allowlist updates and embedded Worker 1.13.23.

## Cache clarification
No new cache code was added. `cache-purge.php` is unchanged. WordPress's existing `created_evazar_brand` hook still runs on successful term creation and may issue the normal exact-term archive purge; this is pre-existing behavior, not new cache logic.

## Limitations
All regression tests use local stubs and/or mocked upstream responses. A live Digikala API request, production WordPress database operation and Cloudflare deployment were not performed in this review. Deploy Worker 1.13.23 to every configured primary Worker before using the Core tool in production; preview a known URL first.
