<?php
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', 'evazar_search_settings_add_admin_menu');
function evazar_search_settings_add_admin_menu() {
    add_submenu_page(
        'edit.php?post_type=evazar_product',
        'تنظیمات جستجوی ایوازار',
        'تنظیمات جستجو',
        'manage_options',
        'evazar-search-settings',
        'evazar_search_settings_admin_page'
    );
}

add_action('admin_init', 'evazar_search_settings_register');
function evazar_search_settings_register() {
    register_setting('evazar_search_settings_group', 'evazar_search_indexed_enabled', ['sanitize_callback' => 'evazar_search_sanitize_checkbox']);
    register_setting('evazar_search_settings_group', 'evazar_search_min_chars', ['sanitize_callback' => 'evazar_search_sanitize_min_chars']);
    register_setting('evazar_search_settings_group', 'evazar_search_debounce_ms', ['sanitize_callback' => 'evazar_search_sanitize_debounce']);
    register_setting('evazar_search_settings_group', 'evazar_search_live_product_limit', ['sanitize_callback' => 'evazar_search_sanitize_live_product_limit']);
    register_setting('evazar_search_settings_group', 'evazar_search_index_batch_size', ['sanitize_callback' => 'evazar_search_sanitize_batch_size']);
}

function evazar_search_sanitize_checkbox($value) {
    if (!is_scalar($value)) return '0';
    return in_array((string) $value, ['1', 'true', 'yes', 'on'], true) ? '1' : '0';
}
function evazar_search_sanitize_min_chars($value) {
    if (!is_scalar($value)) return 2;
    $value = absint($value);
    return in_array($value, [2, 3, 4], true) ? $value : 2;
}
function evazar_search_sanitize_debounce($value) {
    if (!is_scalar($value)) return 250;
    $value = absint($value);
    return in_array($value, [150, 250, 350, 500, 750], true) ? $value : 250;
}
function evazar_search_sanitize_live_product_limit($value) {
    if (!is_scalar($value)) return 5;
    $value = absint($value);
    return in_array($value, [3, 5, 8], true) ? $value : 5;
}
function evazar_search_sanitize_batch_size($value) {
    if (!is_scalar($value)) return 250;
    $value = absint($value);
    return in_array($value, [100, 250, 500], true) ? $value : 250;
}

function evazar_search_settings_table_exists($table) {
    global $wpdb;
    $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));
    if ($wpdb->last_error !== '') return null;
    return $found === $table;
}

function evazar_search_settings_get_index_status() {
    global $wpdb;
    $posts = $wpdb->posts;
    $documents = function_exists('evazar_product_search_index_documents_table') ? evazar_product_search_index_documents_table() : '';
    $terms = function_exists('evazar_product_search_index_terms_table') ? evazar_product_search_index_terms_table() : '';
    $product_index = function_exists('evazar_product_index_table') ? evazar_product_index_table() : '';
    $state = (string) get_option('evazar_product_search_index_state', 'not_initialized');
    $data = [
        'state' => $state,
        'tables_ready' => false,
        'db_error' => false,
        'total' => 0,
        'indexed' => 0,
        'missing' => 0,
        'errors' => 0,
        'terms' => 0,
        'percent' => 0,
        'last_run' => get_option('evazar_product_search_index_backfill_last_run', []),
        'next_run' => function_exists('wp_next_scheduled') ? wp_next_scheduled('evazar_product_index_backfill') : false,
        'documents_updated' => '',
    ];
    if (!$documents || !$terms || !$product_index) {
        $data['state'] = 'missing_tables';
        return $data;
    }
    $documents_exists = evazar_search_settings_table_exists($documents);
    $terms_exists = evazar_search_settings_table_exists($terms);
    $product_index_exists = evazar_search_settings_table_exists($product_index);
    if ($documents_exists === null || $terms_exists === null || $product_index_exists === null) {
        $data['db_error'] = true;
        return $data;
    }
    if (!$documents_exists || !$terms_exists || !$product_index_exists) {
        $data['state'] = 'missing_tables';
        return $data;
    }
    $data['tables_ready'] = true;
    $total = $wpdb->get_var("SELECT COUNT(*) FROM {$posts} WHERE post_type='evazar_product' AND post_status='publish'");
    if ($wpdb->last_error !== '') { $data['db_error'] = true; return $data; }
    $data['total'] = max(0, (int) $total);

    $indexed = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*)
         FROM {$posts} p
         INNER JOIN {$documents} d ON d.product_id=p.ID AND d.index_version=%s
         INNER JOIN {$product_index} i ON i.product_id=p.ID AND i.index_version=%s
         WHERE p.post_type='evazar_product' AND p.post_status='publish'
           AND NOT EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm WHERE pm.post_id=p.ID AND pm.meta_key='_evazar_product_search_index_sync_error')
           AND NOT EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm2 WHERE pm2.post_id=p.ID AND pm2.meta_key='_evazar_product_index_sync_error')",
        defined('EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION') ? EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION : '1.0.0',
        defined('EVAZAR_PRODUCT_INDEX_DB_VERSION') ? EVAZAR_PRODUCT_INDEX_DB_VERSION : '1.3.0'
    ));
    if ($wpdb->last_error !== '') { $data['db_error'] = true; return $data; }
    $data['indexed'] = max(0, (int) $indexed);
    $data['missing'] = max(0, $data['total'] - $data['indexed']);
    $errors = $wpdb->get_var(
        "SELECT COUNT(DISTINCT pm.post_id)
         FROM {$wpdb->postmeta} pm
         INNER JOIN {$posts} p ON p.ID=pm.post_id AND p.post_type='evazar_product' AND p.post_status='publish'
         WHERE pm.meta_key IN ('_evazar_product_search_index_sync_error','_evazar_product_index_sync_error')"
    );
    if ($wpdb->last_error !== '') { $data['db_error'] = true; return $data; }
    $data['errors'] = max(0, (int) $errors);
    $term_count = $wpdb->get_var("SELECT COUNT(*) FROM {$terms}");
    if ($wpdb->last_error !== '') { $data['db_error'] = true; return $data; }
    $data['terms'] = max(0, (int) $term_count);
    $updated = $wpdb->get_var("SELECT MAX(updated_at) FROM {$documents}");
    if ($wpdb->last_error === '' && is_string($updated)) $data['documents_updated'] = $updated;
    $data['percent'] = $data['total'] > 0 ? min(100, (int) floor(($data['indexed'] / $data['total']) * 100)) : 100;

    // Fail closed if live counts contradict a stored `ready` flag. Without this state
    // transition, the frontend could keep using a partial index while cron skips backfill
    // because its guard sees `ready`. The regular scheduled hook will resume repair.
    $data['state_mismatch'] = ($state === 'ready' && $data['indexed'] < $data['total']);
    if ($data['state_mismatch']) {
        update_option('evazar_product_search_index_state', 'building', false);
        $data['state'] = 'building';
        if (function_exists('evazar_product_index_schedule_backfill')) {
            evazar_product_index_schedule_backfill();
        }
    }
    return $data;
}

add_action('admin_post_evazar_search_index_run_batch', 'evazar_search_settings_run_index_batch');
function evazar_search_settings_run_index_batch() {
    if (!current_user_can('manage_options')) wp_die('اجازه دسترسی ندارید.');
    check_admin_referer('evazar_search_index_run_batch');
    if (!function_exists('evazar_product_search_index_ensure_tables') || !function_exists('evazar_product_search_index_backfill_batch')) {
        wp_safe_redirect(add_query_arg('search_index_action', 'unavailable', admin_url('edit.php?post_type=evazar_product&page=evazar-search-settings')));
        exit;
    }
    // Repair the canonical product index schema only if a required base table is missing.
    // Schema ensure calls add/fix structures; they do not truncate product/index data.
    if (function_exists('evazar_product_index_table') && function_exists('evazar_product_index_ensure_tables')) {
        $base_missing = evazar_search_settings_table_exists(evazar_product_index_table()) === false;
        if (function_exists('evazar_product_category_index_table')) {
            $base_missing = $base_missing || evazar_search_settings_table_exists(evazar_product_category_index_table()) === false;
        }
        if ($base_missing) evazar_product_index_ensure_tables();
    }
    evazar_product_search_index_ensure_tables();
    update_option('evazar_product_search_index_state', 'building', false);
    $settings = function_exists('evazar_product_search_runtime_settings') ? evazar_product_search_runtime_settings() : ['index_batch_size' => 250];
    $batch_size = max(100, min(500, (int) ($settings['index_batch_size'] ?? 250)));
    $synced = evazar_product_search_index_backfill_batch($batch_size);
    $remaining = function_exists('evazar_product_search_index_find_remaining_published_product') ? evazar_product_search_index_find_remaining_published_product() : false;
    $result = ($remaining === null) ? 'ready' : (($remaining === false) ? 'error' : 'building');
    $url = add_query_arg([
        'search_index_action' => $result,
        'search_index_synced' => max(0, (int) $synced),
    ], admin_url('edit.php?post_type=evazar_product&page=evazar-search-settings'));
    wp_safe_redirect($url);
    exit;
}

function evazar_search_settings_admin_page() {
    if (!current_user_can('manage_options')) wp_die(esc_html__('اجازه دسترسی به این صفحه را ندارید.'));
    $settings = function_exists('evazar_product_search_runtime_settings') ? evazar_product_search_runtime_settings() : [
        'indexed_enabled' => true, 'min_chars' => 2, 'debounce_ms' => 250, 'live_product_limit' => 5, 'index_batch_size' => 250,
    ];
    $status = evazar_search_settings_get_index_status();
    $action = isset($_GET['search_index_action']) ? sanitize_key(wp_unslash($_GET['search_index_action'])) : '';
    $synced = isset($_GET['search_index_synced']) ? absint($_GET['search_index_synced']) : 0;
    ?>
    <div class="wrap" style="direction:rtl;max-width:1100px;">
      <h1>تنظیمات جستجوی ایوازار</h1>
      <p>وضعیت ایندکس جستجوی زنده و تنظیمات عملکرد در این صفحه مدیریت می‌شود. این صفحه تغییری در کش صفحات، فیلترهای آرشیو یا Worker کلادفلر ایجاد نمی‌کند.</p>
      <?php if (isset($_GET['settings-updated']) && (string)wp_unslash($_GET['settings-updated']) === 'true') : ?><div class="notice notice-success is-dismissible"><p>تنظیمات جستجو ذخیره شد.</p></div><?php endif; ?>
      <?php if ($action === 'ready') : ?><div class="notice notice-success"><p>بررسی این مرحله کامل شد؛ ایندکس آماده است. تعداد رکوردهای پردازش‌شده در این نوبت: <?php echo esc_html((string)$synced); ?>.</p></div>
      <?php elseif ($action === 'building') : ?><div class="notice notice-info"><p>یک نوبت ترمیم اجرا شد؛ ایندکس هنوز کامل نیست و پردازش زمان‌بندی‌شده ادامه می‌دهد. تعداد رکوردهای پردازش‌شده: <?php echo esc_html((string)$synced); ?>.</p></div>
      <?php elseif ($action === 'error') : ?><div class="notice notice-error"><p>پرس‌وجوی بررسی وضعیت با خطای دیتابیس روبه‌رو شد؛ وضعیت ایندکس آماده اعلام نشده است.</p></div>
      <?php elseif ($action === 'unavailable') : ?><div class="notice notice-error"><p>توابع لازم برای ساخت ایندکس در دسترس نیستند؛ نسخهٔ فعال هسته را بررسی کنید.</p></div><?php endif; ?>

      <div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px;margin:16px 0;">
        <h2 style="margin-top:0;">وضعیت ایندکس جستجو</h2>
        <?php if (!empty($status['db_error'])) : ?>
          <p style="color:#b32d2e;"><strong>خطا:</strong> خواندن آمار از دیتابیس انجام نشد؛ درصد پیشرفت قابل اتکا نیست.</p>
        <?php elseif (!$status['tables_ready']) : ?>
          <p><strong>وضعیت:</strong> جدول‌های ایندکس هنوز ایجاد نشده‌اند یا در دسترس نیستند.</p>
        <?php else : ?>
          <p><strong>وضعیت فعلی:</strong>
            <?php
              if (!empty($status['state_mismatch'])) echo '<span style="color:#b32d2e;font-weight:700;">نیازمند بررسی (پرچم آماده با شمارش واقعی تطبیق ندارد)</span>';
              elseif ($status['state'] === 'ready') echo '<span style="color:#008a20;font-weight:700;">آماده</span>';
              elseif ($status['state'] === 'building') echo '<span style="color:#996800;font-weight:700;">در حال ساخت/ترمیم</span>';
              else echo '<span style="color:#646970;font-weight:700;">' . esc_html($status['state']) . '</span>';
            ?>
          </p>
          <p><strong>محصولات منتشرشده:</strong> <?php echo esc_html(number_format_i18n($status['total'])); ?> &nbsp; | &nbsp;
             <strong>دارای هر دو ایندکس معتبر:</strong> <?php echo esc_html(number_format_i18n($status['indexed'])); ?> &nbsp; | &nbsp;
             <strong>باقی‌مانده/نیازمند بررسی:</strong> <?php echo esc_html(number_format_i18n($status['missing'])); ?></p>
          <div style="height:16px;background:#f0f0f1;border-radius:8px;overflow:hidden;max-width:760px;">
            <div style="height:16px;width:<?php echo esc_attr((string)$status['percent']); ?>%;background:<?php echo ($status['percent'] === 100 && $status['state'] === 'ready' && empty($status['state_mismatch'])) ? '#00a32a' : '#2271b1'; ?>;"></div>
          </div>
          <p><strong>پیشرفت تقریبی بر پایهٔ رکوردهای کامل:</strong> <?php echo esc_html((string)$status['percent']); ?>٪</p>
          <p><strong>خطاهای همگام‌سازی ثبت‌شده:</strong> <?php echo esc_html(number_format_i18n($status['errors'])); ?> &nbsp; | &nbsp;
             <strong>تعداد توکن‌های جستجو:</strong> <?php echo esc_html(number_format_i18n($status['terms'])); ?></p>
          <?php if ($status['documents_updated'] !== '') : ?><p><strong>آخرین به‌روزرسانی رکورد ایندکس:</strong> <?php echo esc_html($status['documents_updated']); ?> (زمان دیتابیس)</p><?php endif; ?>
        <?php endif; ?>
        <p><strong>وضعیت ذخیره‌شده:</strong> <?php echo esc_html($status['state']); ?>.</p>
        <p><strong>آخرین اجرای پس‌زمینه:</strong>
          <?php if (is_array($status['last_run']) && !empty($status['last_run']['time'])) : ?>
            <?php echo esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), (int)$status['last_run']['time'])); ?>؛ پردازش‌شده: <?php echo esc_html((string)absint($status['last_run']['synced'] ?? 0)); ?>
          <?php else : ?>هنوز سابقه‌ای ثبت نشده است.<?php endif; ?>
        </p>
        <p><strong>اجرای زمان‌بندی‌شدهٔ بعدی:</strong>
          <?php echo $status['next_run'] ? esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), (int)$status['next_run'])) : 'زمان‌بندی ثبت نشده است؛ با بازدید بعدی وردپرس بررسی شود.'; ?>
        </p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-top:14px;">
          <input type="hidden" name="action" value="evazar_search_index_run_batch">
          <?php wp_nonce_field('evazar_search_index_run_batch'); ?>
          <?php submit_button('بررسی و ترمیم ایندکس (یک نوبت)', 'secondary', 'submit', false); ?>
          <p class="description">این دکمه فقط یک نوبت محدود را اجرا می‌کند و ردیف‌های موجود را پاک نمی‌کند؛ ادامهٔ کار با زمان‌بندی پس‌زمینه است.</p>
        </form>
      </div>

      <form action="options.php" method="post" style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:16px;margin:16px 0;">
        <?php settings_fields('evazar_search_settings_group'); ?>
        <h2 style="margin-top:0;">تنظیمات عملکرد جستجو</h2>
        <table class="form-table" role="presentation"><tbody>
          <tr><th scope="row">استفاده از ایندکس اختصاصی جستجو</th><td>
            <input type="hidden" name="evazar_search_indexed_enabled" value="0">
            <label><input type="checkbox" name="evazar_search_indexed_enabled" value="1" <?php checked($settings['indexed_enabled']); ?>> فعال‌سازی جستجوی سریع مبتنی بر ایندکس آماده</label>
            <p class="description">اگر خاموش باشد، جستجوی زنده به مسیر قدیمی WP_Query برمی‌گردد؛ ایندکس همچنان همگام می‌شود و پاک نمی‌شود.</p>
          </td></tr>
          <tr><th scope="row"><label for="evazar_search_min_chars">حداقل طول عبارت</label></th><td>
            <select id="evazar_search_min_chars" name="evazar_search_min_chars">
              <?php foreach ([2,3,4] as $n) : ?><option value="<?php echo esc_attr((string)$n); ?>" <?php selected((int)$settings['min_chars'], $n); ?>><?php echo esc_html((string)$n); ?> کاراکتر</option><?php endforeach; ?>
            </select><p class="description">روی تایپ زنده و اعتبارسنجی سرور اعمال می‌شود.</p>
          </td></tr>
          <tr><th scope="row"><label for="evazar_search_debounce_ms">تأخیر قبل از درخواست</label></th><td>
            <select id="evazar_search_debounce_ms" name="evazar_search_debounce_ms">
              <?php foreach ([150,250,350,500,750] as $n) : ?><option value="<?php echo esc_attr((string)$n); ?>" <?php selected((int)$settings['debounce_ms'], $n); ?>><?php echo esc_html((string)$n); ?> میلی‌ثانیه</option><?php endforeach; ?>
            </select><p class="description">عدد کمتر پاسخ‌گوتر است اما درخواست‌های بیشتری ایجاد می‌کند؛ مقدار پیشنهادی ۲۵۰ است.</p>
          </td></tr>
          <tr><th scope="row"><label for="evazar_search_live_product_limit">تعداد کارت کالای پیشنهادی</label></th><td>
            <select id="evazar_search_live_product_limit" name="evazar_search_live_product_limit">
              <?php foreach ([3,5,8] as $n) : ?><option value="<?php echo esc_attr((string)$n); ?>" <?php selected((int)$settings['live_product_limit'], $n); ?>><?php echo esc_html((string)$n); ?> کالا</option><?php endforeach; ?>
            </select><p class="description">تعداد کارت‌های محصولی که در فهرست جستجوی زنده نمایش داده می‌شوند؛ روی نتایج صفحهٔ کامل جستجو اثر ندارد.</p>
          </td></tr>
          <tr><th scope="row"><label for="evazar_search_index_batch_size">تعداد کالا در هر نوبت ساخت ایندکس جستجو</label></th><td>
            <select id="evazar_search_index_batch_size" name="evazar_search_index_batch_size">
              <?php foreach ([100,250,500] as $n) : ?><option value="<?php echo esc_attr((string)$n); ?>" <?php selected((int)$settings['index_batch_size'], $n); ?>><?php echo esc_html((string)$n); ?> کالا</option><?php endforeach; ?>
            </select><p class="description">۵۰۰ سریع‌تر ولی سنگین‌تر است؛ برای شروع ۲۵۰ پیشنهاد می‌شود. ایندکس اصلی فیلترها همچنان با دستهٔ ثابت ۲۵۰تایی اجرا می‌شود.</p>
          </td></tr>
        </tbody></table>
        <?php submit_button('ذخیره تنظیمات جستجو'); ?>
      </form>
      <p class="description">نسخهٔ ایندکس عنوان: <?php echo esc_html(defined('EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION') ? EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION : 'نامشخص'); ?>؛ این ابزار عملیات حذف یا بازسازی مخرب جدول‌ها انجام نمی‌دهد.</p>
    </div>
    <?php
}
