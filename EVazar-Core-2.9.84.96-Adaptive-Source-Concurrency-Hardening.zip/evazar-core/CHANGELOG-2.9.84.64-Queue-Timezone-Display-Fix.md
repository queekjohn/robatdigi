# EVazar Core 2.9.84.64 — Queue Timezone Display Fix

- Replaced raw Unix-timestamp calls to `date_i18n()` in `queue-manager.php` with `evazar_queue_local_datetime()`.
- The queue formatter delegates to the shared `evazar_gemini_local_datetime()` when available and has a safe WordPress-timezone fallback for isolated/module-only loads.
- Corrected local display for source-pool cooldowns, attempted-item retry, source circuit-breaker deferral, Gemini cooldown/rate-limit messages, queue pause notices, and queue-stat refresh time.
- The stored SQL timestamps, retry deadlines, scheduler timestamps, and queue eligibility comparisons are unchanged; only human-facing formatting changes.
- No Worker, Gemini request, queue processing, product import, or cache behavior changed.
