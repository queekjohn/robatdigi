# QA — EVazar Core 2.9.84.36

## Change
Brand registration menu placement only: `add_management_page()` -> `add_submenu_page('edit.php?post_type=evazar_product', ...)`; preview and cancel URLs use the plugin admin page.

## Validation
- Regression tests assert submenu parent is `edit.php?post_type=evazar_product`.
- Regression tests assert no Tools menu registration or `tools.php` navigation remains in the brand registration implementation.
- Regression tests assert plugin-page URL helper is used.
- All PHP files checked with `php -l`.
- Existing brand-registration, source-identity, metadata-repair, queue-identity and Worker tests rerun.

## Scope guarantee
No Worker edits. No changes to `cache-purge.php`, `product-index.php`, `importer.php`, or `queue-manager.php` in this version. Functional registration logic is otherwise unchanged.
