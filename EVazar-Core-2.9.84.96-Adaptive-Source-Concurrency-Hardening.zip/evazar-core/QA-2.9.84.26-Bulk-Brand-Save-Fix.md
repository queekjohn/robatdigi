# QA — EVazar Core 2.9.84.26 Bulk Brand Save Fix

## Reason for patch
A live user test showed the 2.9.84.25 bulk editor could display/select a brand but fail to apply it after submit. The previous regression suite invoked the `save_post` callback directly and did not exercise WordPress' actual bulk completion event.

## Fix
- Added a `bulk_edit_posts` completion handler that reads the original shared bulk payload and assigns selected brand term IDs to every successfully updated `evazar_product`.
- Kept the `save_post` path as compatibility fallback; assignments are idempotent so no duplicate taxonomy write occurs if both paths execute.
- Added write-result/postcondition checks and failure logs.
- Empty brand selection still makes no change; bad nonce or invalid IDs are rejected.

## Tests
- Brand selector regression suite: 24 assertions passed, 0 failed, including the newly tested completion hook, exact ID replacement, no-op on empty input, nonce rejection, and fallback behavior.
- PHP syntax checks: all 12 PHP files in the plugin passed `php -l`.
- JavaScript syntax checks passed for `brand-selector-admin.js`, `brand-selector-editor.js`, and the bundled Worker.
- Brand-source regressions: 89 passed, 0 failed.
- Worker/source JavaScript regressions: 23 passed, 0 failed.
- Gemini cooldown/recovery: 32 assertions passed.
- ZIP integrity: `unzip -t`.
- Diff scope verifies cache, import, queue, product-index, brand redirect and Worker files are byte-identical to 2.9.84.25.

## Limits
- Tests run locally with WordPress function stubs. The live site has not been accessed from this environment; user must test after installing the package.
