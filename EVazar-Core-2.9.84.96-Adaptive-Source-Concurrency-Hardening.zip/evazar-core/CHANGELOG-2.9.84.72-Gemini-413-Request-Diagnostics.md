# EVazar Core 2.9.84.72 — Gemini parallel HTTP 413 diagnostics

- Adds exact serialized request-body byte count to internal parallel HTTP 413 errors.
- Captures a short sanitized response excerpt; it does not log the request body, prompt, checkpoint contents, tokens, or API keys.
- Distinguishes the WordPress internal endpoint's `evazar_parallel_payload_invalid` response from a generic upstream/web-server HTTP 413 when the response body allows it.
- Adds request size, known 2 MiB WordPress endpoint limit, endpoint error code, and sanitized response excerpt to the existing `queue_batch_deferred` operational event.
- Does not change batch size, request payload, queue retry/cooldown logic, worker selection, or duplicate-request protection. No Worker changes.
