# QA — EVazar Core 2.9.84.93 Taxonomy API SEO Description Fallback

## Source shape reproduced

The supplied Digikala discovery API response contains matching `data.category.code` and `data.brand.code`, a non-empty `data.brand.description`, and a non-empty `data.seo.description`, while `data.seo.content` and `data.category_brand.description` are empty.

## Expected behavior

- Accept only a JSON response with exact category and brand codes matching the requested source path.
- Prefer full editorial fields when present.
- Otherwise compose readable page SEO description and matching category/brand descriptions.
- Strip markup, decode entities, retain paragraph boundaries, de-duplicate nested content, and cap text at 18,000 characters.
- Return the taxonomy source as ready after the single API request; do not fetch the public `/search/` HTML page when usable API descriptions exist.
- Reject mismatched or missing category/brand identity.

## Regression coverage

Focused tests cover the supplied response shape, HTML/entity normalization, paragraph preservation, exact-field precedence, duplicate and nested descriptions, category-only fallback, output-size bound, full fetch path, no HTML fallback after API success, and category/brand identity mismatch/missing-code rejection.
