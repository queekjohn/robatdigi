# QA — EVazar Core 2.9.84.52

## Regression checks
- Queue rows whose DKP is blank or has no digit are quarantined as `failed/INVALID_DKP`; no row is deleted and `retries` is not incremented.
- Rows with a numeric DKP or product URL containing a numeric DKP remain eligible.
- Atomic claim and exact eligible count both require a DKP with digits.
- `failed/INVALID_DKP` rows cannot be picked up by legacy automatic retry.
- Runtime `invalid` errors become terminal queue failures rather than retrying indefinitely.
- Claim diagnostic and final summary expose how many invalid DKP rows were quarantined.
- Existing parallel source-fetch and Gemini batch regressions remain green.
