# QA — EVazar Core 2.9.84.56

## Scope

Diagnostic-only change for the existing five-Worker parallel Digikala source fetch path. The Gemini Worker pool and batch-size logic are unchanged.

## Coverage

- All five primary Workers eligible: reports 5/5 eligibility, selected host list, and full wave.
- Two Workers cooling down: reports 3/5 eligibility and names each cooldown Worker, reason, HTTP status, and remaining seconds.
- Daily budget exhausted on two Workers: reports budget exclusions separately from cooldown.
- Reservation rejection despite an eligible snapshot: records a zero-request selection-race wave rather than falsely labeling it cooldown.
- One-product queue tail: labels it as queue-tail-limited, not an availability failure.
- Worker HTTP 502/503 failures: captures pre-wave eligibility and post-wave cooldown state in the same consolidated summary.
- Per-wave traces remain grouped into the existing `batch_dispatch_wave` log; no per-wave log flooding.

All tests are local/stubbed and do not claim live verification against Cloudflare or Digikala.

## Validation completed

- `product-source-parallel-fetch-regression.php`: 76 assertions passed.
- All 14 PHP test suites passed; all 3 JavaScript test suites passed.
- 26 PHP files passed `php -l`; 6 JavaScript files passed `node --check`.
- The ZIP was extracted and the focused source-wave suite rerun successfully.
- The embedded Worker source SHA-256 matches Core 2.9.84.55 exactly; no Worker source was modified.
