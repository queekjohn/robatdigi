# Safe upgrade — EVazar Core 2.9.84.92

1. Back up the database and the currently installed EVazar Core plugin.
2. Replace **EVazar Core only** with this release.
3. Keep all five deployed Cloudflare Workers on the existing version **1.13.27**; no Worker deployment or secret change is required.
4. Keep current queue, Gemini, Worker URL, and WP-Cron settings unchanged.
5. Do not manually clear `evz_primary_worker_inflight_*` lease options or Worker cooldown transients.
6. After upgrade, inspect taxonomy source retry events. Source-side failures should report `worker_upstream_source_http_*` (or a specific upstream error) and include the Worker version, Digikala host/status, source path, and fetch duration where available. A bare 502 without source provenance should still be treated as a Worker/edge failure.

## Scope

This is a Core-only classification and diagnostics correction. The prior 2.9.84.91 shared-lease timeout safety remains intact. The update does not change product content generation, Gemini, taxonomy identity rules, Theme, or cache logic.

## Validation boundary

Automated local regression tests and syntax checks are run for this package. This build is not a live production test against evazar.ir, cPanel, Cloudflare, or Digikala.
