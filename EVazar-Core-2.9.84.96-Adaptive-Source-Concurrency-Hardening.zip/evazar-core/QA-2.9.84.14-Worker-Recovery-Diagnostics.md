# QA — Core 2.9.84.14 / Worker 1.13.13.3

- Based on Worker 1.13.13.2; only changes are version header and Durable Object uncertain-outcome error classification/diagnostics.
- Brand source-path extractor and output preserved.
- Existing Gemini retry headers/markers preserved.
- Product cache and batch/taxonomy contracts preserved byte-for-byte at their relevant sections.
- Local tests: run PHP cooldown and brand source regressions, Node worker regression and syntax checks, PHP syntax, ZIP integrity.
- Live Cloudflare deployment and Durable Object binding/migration not verified.
