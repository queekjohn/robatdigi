# QA — EVazar Core 2.9.84.21

## Fix
- The previous implementation changed a brand public slug before persisting and confirming its old-slug 301 map entry. It ignored whether `update_option()` actually stored the redirect map.
- New behavior saves and reads back the redirect map first; a failed pre-write prevents slug mutation.
- Failed term updates trigger best-effort restoration of the prior map. The function then reloads the term and confirms the canonical slug. If WordPress reports success but the slug did not change, the function fails closed and removes the prewritten mapping where safe.
- Existing collision checks are retained. No cache or Worker behavior changed.

## Test results
- Core brand/queue regression: 77 passed, 0 failed, including redirect-map write failure, WordPress term-update failure/rollback, and a no-op update postcondition test.
- Gemini cooldown/recovery regression: 32 assertions passed.
- Worker regression: 23 passed, 0 failed.
- PHP syntax: all 9 PHP files passed `php -l`.
- JavaScript syntax: `node --check` passed for the Worker and Worker regression test.
- ZIP integrity: `unzip -t` passed.

## Limits / deployment
- These are local tests with WordPress function stubs, not a live site/database run.
- Back up the database and keep the product import queue paused before deploying. This release does not migrate any existing term or create a redirect until ordinary import attempts a brand slug move.
