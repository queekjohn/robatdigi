# QA — EVazar Core 2.9.84.86

## Review changes
- Bulk quarantine retry is staged transactionally while holding the existing shared capacity lock.
- The action verifies that both the active queue and capacity-intake table have exactly one non-prefix, single-column UNIQUE index named `dkp_unique` on column `dkp`. Missing, composite, wrong-column, prefix, or unverifiable indexes fail closed.
- Eligible canonical numeric DKPs are staged as explicit `qretry` work. Existing rewrite intent is preserved or upgraded to `qrewrite`.
- Capacity promotion activates explicit quarantine retries only when an active slot is free. Generic intake modes still cannot bypass quarantine/exclusion.
- Existing queue IDs, DKPs, related-product IDs, and historical error messages are preserved; retry claim/error status fields are reset only when an item is promoted.
- Non-numeric and leading-zero DKPs stay in quarantine for manual review.
- Quarantine counts/filter exclude entries already staged for retry; the durable capacity-waiting count continues to include them.
- Existing AJAX nonce and `manage_options` authorization checks remain in force.

## Validation on the final packaged ZIP after extraction
- PHP regression scripts: **26/26 passed**.
- JavaScript/MJS regression scripts: **4/4 passed**.
- PHP syntax: **39/39 files passed**.
- JavaScript syntax (`node --check`): **7/7 files passed**.
- Quarantine bulk-requeue regression: **22/22 targeted assertions passed**, including duplicate/idempotent runs, missing/wrong/composite indexes, simulated database failure, invalid/leading-zero DKPs, history preservation, and capacity limit behavior.
- Simulated-capacity check: with effective capacity 4 and 2 already-active rows, exactly 2 quarantine rows become pending and excess items remain in the intake waiting table.
- ZIP integrity: passed; root directory is `evazar-core/`; plugin header is version `2.9.84.86`.

## Protected-file comparison against Core 2.9.84.84
These files are byte-identical to the baseline:
- `cache-purge.php`: `8cea2666c9a31a2122c74f855ced41586db2fc0cb57491ddddc7da9ae2148e2e`
- `importer.php`: `c96a288a44df87b18e6d26c266ff52b772a9bcb501fa03099d41da345bba4ba3`
- `worker/digikala-worker.js`: `0fc82e8cdd7886739c4560ae81d2f4fb1affaf6f8a6adf39386cf1e668909074`

The runtime changes are limited to `evazar-core.php` version metadata and `queue-manager.php`. Existing regression scripts had version pins updated, and a targeted regression test plus release notes were added.

## Limits
These are local tests with a fake database and simulated networking where relevant. The final package was not installed on the production EVazar WordPress site; no live database or production queue was modified.
