# QA — Core 2.9.84.89 Queue Claim Recovery

- [x] Active lock with a recent owner-specific heartbeat cannot be stolen solely because its original start timestamp is old.
- [x] An abandoned lock becomes reclaimable only after the matching heartbeat lease expires.
- [x] Claim recovery happens before Worker/quota/configuration early-return paths.
- [x] Stale row updates compare ID, status, claim token, and exact original `claimed_at` value.
- [x] Recovered rows are returned to `pending`, have their claim cleared, record `STALE_CLAIM`, increment retry count, and get a bounded retry delay.
- [x] Any remaining `processing` row blocks a fresh queue Claim.
- [x] Exact scenario tested: 200 stale processing rows are recovered, and the next 200-item Claim leaves exactly 200 processing rows rather than 400.
- [x] Mixed scenario tested: 200 old + 200 recent processing rows recovers only the old generation; the recent generation remains untouched and blocks a third Claim.
- [x] Next safe cycle can recover the remaining abandoned generation; no row remains permanently processing in the harness.
- [x] All existing PHP tests and syntax checks pass.

Production-only verification still required: inspect the next real `queue_stale_claim_recovery`, `queue_prior_claims_blocked`, `batch_dispatch_wave`, and `queue_batch_run_summary` events after installation. This bundle was tested locally; it was not deployed to the live site.
