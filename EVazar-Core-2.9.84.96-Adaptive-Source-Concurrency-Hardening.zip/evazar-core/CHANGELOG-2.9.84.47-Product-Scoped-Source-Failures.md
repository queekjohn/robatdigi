# EVazar Core 2.9.84.47 — Product-Scoped Source Failures

- Transient Digikala source failures (upstream 5xx such as 502/503, fetch failures, invalid JSON, and missing product payloads) now defer only the affected queue item without incrementing its retry counter.
- Remaining products continue through the same queue run after a single transient source failure.
- A circuit breaker activates only after three consecutive transient source failures. It defers only products not yet visited in the current claimed run; previously prepared product checkpoints continue to the Gemini batch.
- Upstream rate limiting (`source_rate_limited`) and explicit upstream 401/403 access rejection remain run-wide safeguards; other ambiguous request rejections are item-scoped with a not-before delay and no retry-counter increment.
- Product-specific 404s, Gemini handling, Worker transport errors, cache behavior, and Worker source-fetch strategy are unchanged.
