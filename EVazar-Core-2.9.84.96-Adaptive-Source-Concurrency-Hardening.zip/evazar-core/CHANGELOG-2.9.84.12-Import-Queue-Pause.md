# EVazar Core 2.9.84.12 — Import Queue Pause / Resume

## Changes
- Added a persistent administrator-controlled pause state for the product import queue.
- Added a dashboard control that switches between **Pause queue** and **Resume queue**, with a visible state label.
- While paused, both scheduled queue processing and the manual “Run queue now” action refuse to claim new products.
- Cancels outstanding single follow-up events at pause time and prevents new follow-ups from being scheduled while paused. The recurring Cron remains installed as a safety net.
- Resume schedules a prompt follow-up and preserves the normal recurring Cron.
- If a running request notices a pause before processing an item or sending a later batch/wave, still-claimed and unsent rows return to `pending` without incrementing retries or overwriting retry metadata.
- New incoming queue entries continue to be stored while paused; they are retained for later processing and are not deleted.

## Scope and limits
- The pause controls the product import queue worker; it does not disable the standalone single-product manual import flow or the separate taxonomy SEO queue.
- An HTTP request/wave already sent to a Worker cannot be cancelled reliably from another request and may finish. Further unsent batches/waves are not dispatched after the pause is observed.
- No cache, image CDN, cache purge, Worker source, importer product-write path, or database schema was changed.
