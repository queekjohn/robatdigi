# EVazar Core 2.9.84.57 — Category Source-Path Quarantine

- Classify only explicit missing source-category path errors (`PRODUCT_CATEGORY_SOURCE_MISSING`, `PRODUCT_CATEGORY_SOURCE_PATH_MISSING`) as review quarantine; ordinary category/database synchronization failures remain retryable.
- Persist the partially saved product ID and a structured quarantine reason so administrators can inspect the product before retrying.
- Add queue status tabs for review quarantine and administrative exclusion, with manual requeue, exclude-from-import, and restore-excluded actions.
- Add optional automatic recheck intervals of 1, 3, 7, or 14 days; default is disabled.
- Migrate legacy pending/failed records only when the exact known missing-source-path messages are present. No queue rows or product posts are deleted.
- Reserve quarantined and excluded DKPs from the Harvester existing-DKP endpoint to prevent recurring rediscovery. Failed rows remain eligible for the existing retry workflow.
- Keep cache and Cloudflare Worker source unchanged.


## Recheck review follow-up — 2.9.84.58

- Automatic rechecks reset the normal retry counter so an old pre-quarantine retry history cannot prematurely exhaust retries after a configured delayed recheck.
- Legacy migration no longer overwrites an existing `related_product_id` with zero while moving old queue rows into quarantine.
- Queue return summaries now count quarantined rows as resolved items on every early-return path, matching the final-run summary.
