# Safe Upgrade — EVazar Core 2.9.84.89

1. Back up the active EVazar Core plugin folder and database before replacing the plugin.
2. Install the Core ZIP only; no Cloudflare Worker or Theme update is required for these queue safeguards.
3. Keep the existing automatic queue schedule and Gemini batch settings. The release does not change configured batch sizes or Worker counts.
4. After upgrading, inspect the queue event log for `queue_stale_claim_recovery` and `queue_prior_claims_blocked`. If a previous claim remains recent, a run may intentionally skip one batch rather than stacking more `processing` rows; it will retry after the conservative recovery age is reached.
5. Verify the `queue_batch_run_summary` for the next run reports normal completion or an explicit interruption status. Investigate repeated interruptions before increasing the batch limit.

Rollback: restore the backed-up Core plugin files. The release does not migrate or delete queue rows; it only changes stale rows through guarded status updates when the next queue run performs recovery.
