# Safe upgrade — EVazar Core 2.9.84.48

1. Back up the currently installed EVazar Core plugin.
2. Install `EVazar-Core-2.9.84.48-Queue-Start-Cadence-Diagnostics.zip`.
3. No Worker redeploy is needed; keep Worker `1.13.25` as-is.
4. The randomized interval is now anchored to the prior run's start. Overlap is still prevented by the run lock; if a run lasts past its target, the next one waits until the current lock is released.
5. The Queue dashboard records the last start, start delay against the planned timestamp, and run duration. After a few runs, use those values to tell Cron delay apart from slow processing.
6. Configure cPanel Cron to call `https://evazar.ir/wp-cron.php?doing_wp_cron` every minute. Keep WP-Cron enabled until that scheduled execution is confirmed. Only then consider adding `define('DISABLE_WP_CRON', true);` to `wp-config.php`.
7. Source fetching is still sequential in this release. Do not expect this version by itself to increase the number of simultaneous Digikala requests.
8. No cache code is changed.

Local tests do not replace live verification on the hosting account.
