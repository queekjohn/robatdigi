<?php
if (!defined('ABSPATH')) exit;

/** Format a queue datetime in the WordPress site timezone, matching current_time('mysql'). */
if (!function_exists('evazar_queue_mysql_timestamp')) {
    function evazar_queue_mysql_timestamp($timestamp = null) {
        $timestamp = ($timestamp === null) ? time() : (int) $timestamp;
        if (function_exists('wp_date')) {
            $timezone = function_exists('wp_timezone') ? wp_timezone() : null;
            return wp_date('Y-m-d H:i:s', $timestamp, $timezone);
        }
        // Compatibility path for WordPress versions before wp_date(): honor a named
        // site timezone (including DST), then fall back to the configured UTC offset.
        $timezone_name = function_exists('get_option') ? trim((string) get_option('timezone_string', '')) : '';
        if ($timezone_name !== '') {
            try {
                return (new DateTimeImmutable('@' . $timestamp))->setTimezone(new DateTimeZone($timezone_name))->format('Y-m-d H:i:s');
            } catch (Exception $e) {
                // Invalid legacy timezone value: use the configured offset below.
            }
        }
        $offset = function_exists('get_option') ? (float) get_option('gmt_offset', 0) : 0.0;
        return gmdate('Y-m-d H:i:s', $timestamp + (int) round($offset * 3600));
    }
}

/** Format a queue retry time relative to now in the WordPress site timezone. */
if (!function_exists('evazar_queue_mysql_after')) {
    function evazar_queue_mysql_after($seconds) {
        return evazar_queue_mysql_timestamp(time() + max(0, (int) $seconds));
    }
}

/**
 * Format a Unix timestamp for a human-facing queue message using the WordPress site timezone.
 * Unlike date_i18n(), wp_date()/the shared Gemini formatter accept a real Unix timestamp without
 * requiring a pre-applied GMT offset. A fallback keeps queue-manager safe in isolated test/runtime loads.
 */
if (!function_exists('evazar_queue_local_datetime')) {
    function evazar_queue_local_datetime($timestamp, $format = 'Y-m-d H:i:s') {
        $timestamp = (int) $timestamp;
        $format = (string) $format;
        if ($timestamp <= 0) return '';

        if (function_exists('evazar_gemini_local_datetime')) {
            $formatted = evazar_gemini_local_datetime($timestamp, $format);
            if (is_string($formatted) && $formatted !== '') return $formatted;
        }

        if (function_exists('wp_date')) {
            $timezone = function_exists('wp_timezone') ? wp_timezone() : null;
            return wp_date($format, $timestamp, $timezone);
        }

        $timezone_name = function_exists('wp_timezone_string')
            ? trim((string) wp_timezone_string())
            : (function_exists('get_option') ? trim((string) get_option('timezone_string', '')) : '');
        if ($timezone_name !== '') {
            try {
                return (new DateTimeImmutable('@' . $timestamp))->setTimezone(new DateTimeZone($timezone_name))->format($format);
            } catch (Exception $e) {
                // An invalid legacy timezone falls through to the configured GMT offset.
            }
        }

        $offset = function_exists('get_option') ? (float) get_option('gmt_offset', 0) : 0.0;
        return gmdate($format, $timestamp + (int) round($offset * 3600));
    }
}

/**
 * Classify a Worker-reported upstream source failure separately from a product or Worker failure.
 * Rate limits and explicit source access rejections pause the current claimed run. Transient source
 * failures such as an upstream 5xx or malformed product response are isolated to the affected product;
 * a short consecutive-failure circuit breaker protects the source if several products fail in a row.
 * Returned delay is a not-before time; the normal queue scheduler still applies.
 */
if (!function_exists('evazar_queue_upstream_source_failure_policy')) {
    function evazar_queue_upstream_source_failure_policy($error) {
        if (!function_exists('is_wp_error') || !is_wp_error($error)) return [];
        $error_code = (string) $error->get_error_code();
        $data = $error->get_error_data($error_code);
        if (!is_array($data)) return [];

        $scope = sanitize_key((string) ($data['error_scope'] ?? ''));
        $source_code = sanitize_key((string) ($data['source_error_code'] ?? ''));
        $diag_code = sanitize_key((string) ($data['code'] ?? ''));
        $attempted = absint($data['attempted'] ?? 0);
        $busy_skipped = absint($data['busy_skipped'] ?? 0);
        $known_source_codes = ['source_rate_limited', 'source_server_error', 'source_fetch_failed', 'source_request_rejected', 'source_invalid_json', 'source_product_payload_missing'];

        // Cross-queue Worker leases are capacity contention, not product/source failure.
        // When no HTTP request was sent and all candidates were busy (or a mixed busy/cooldown
        // pool left no candidate), release the whole product claim without incrementing retries.
        $pool_contention = $attempted === 0 && (
            $diag_code === 'worker_pool_busy'
            || ($diag_code === 'worker_pool_unavailable' && $busy_skipped > 0)
            || ($diag_code === 'worker_reservation_rejected' && $busy_skipped > 0)
        );
        if ($pool_contention) {
            $delay = max(15, min(900, absint($data['retry_after_seconds'] ?? 60) ?: 60));
            $queue_code = ($diag_code === 'worker_pool_busy') ? 'PRIMARY_WORKERS_BUSY' : 'PRIMARY_WORKERS_TEMPORARILY_UNAVAILABLE';
            return [
                'action' => 'defer_run',
                'delay_seconds' => $delay,
                'queue_error_code' => $queue_code,
                'source_error_code' => $diag_code,
                'reason' => 'Workerهای اصلی موقتاً توسط اجرای دیگری استفاده می‌شوند؛ هیچ درخواست محصولی ارسال نشد.',
            ];
        }

        $is_source_failure = $scope === 'source'
            || in_array($source_code, $known_source_codes, true)
            || strpos($diag_code, 'worker_upstream_') === 0
            || $diag_code === 'worker_source_unavailable';
        if (!$is_source_failure) return [];

        if ($source_code === 'source_rate_limited') {
            $delay = max(60, min(900, absint($data['retry_after_seconds'] ?? 30)));
            $queue_code = 'DIGIKALA_SOURCE_RATE_LIMITED';
            $reason = 'محدودیت درخواست از سمت دیجی‌کالا';
            $action = 'defer_run';
        } elseif ($source_code === 'source_request_rejected') {
            $upstream_status_v2 = absint($data['upstream_status_v2'] ?? 0);
            $upstream_status_v1 = absint($data['upstream_status_v1'] ?? 0);
            $explicit_access_denial = in_array(401, [$upstream_status_v2, $upstream_status_v1], true)
                || in_array(403, [$upstream_status_v2, $upstream_status_v1], true);
            if ($explicit_access_denial) {
                $delay = 300;
                $queue_code = 'DIGIKALA_SOURCE_REJECTED';
                $reason = 'رد شدن دسترسی به منبع دیجی‌کالا';
                $action = 'defer_run';
            } else {
                // Other rejected responses can be specific to one product/request; do not
                // defer unrelated products unless a clear 401/403 or 429 is reported.
                $delay = 60;
                $queue_code = 'DIGIKALA_SOURCE_UNAVAILABLE';
                $reason = 'پاسخ نامعتبر منبع برای همین محصول';
                $action = 'defer_item';
            }
        } else {
            // A transient 5xx/timeout/bad payload belongs to the current product request,
            // not to every item in the claimed queue. A circuit breaker handles repeated failures.
            $delay = 60;
            $queue_code = 'DIGIKALA_SOURCE_UNAVAILABLE';
            $reason = 'اختلال موقت در دریافت اطلاعات همین محصول از دیجی‌کالا';
            $action = 'defer_item';
        }

        return [
            'action' => $action,
            'delay_seconds' => $delay,
            'queue_error_code' => $queue_code,
            'source_error_code' => $source_code,
            'reason' => $reason,
        ];
    }
}

/** True only for category sync failures that explicitly report missing source category paths. */
if (!function_exists('evazar_queue_category_source_quarantine_reason')) {
    function evazar_queue_category_source_quarantine_reason($error) {
        if (!function_exists('is_wp_error') || !is_wp_error($error)) return '';
        $outer_code = strtoupper((string) $error->get_error_code());
        if ($outer_code !== 'PRODUCT_CATEGORY_SYNC_FAILED') return '';
        $data = $error->get_error_data($outer_code);
        if (!is_array($data)) return '';
        $inner_code = strtoupper(sanitize_key((string) ($data['category_error_code'] ?? '')));
        $reason = sanitize_key((string) ($data['quarantine_reason'] ?? ''));
        if ($reason === 'source_category_path_missing' || in_array($inner_code, ['PRODUCT_CATEGORY_SOURCE_MISSING', 'PRODUCT_CATEGORY_SOURCE_PATH_MISSING'], true)) {
            return 'SOURCE_CATEGORY_PATH_MISSING';
        }
        return '';
    }
}

/**
 * Distinguish legacy post-save category failures from the new preflight guard.
 * A preflight failure may be linked to an already-existing valid product with the same DKP;
 * it must never offer/allow drafting that existing product just because this attempt was blocked.
 */
if (!function_exists('evazar_queue_quarantine_row_has_saved_partial_product')) {
    function evazar_queue_quarantine_row_has_saved_partial_product($row) {
        $error_log = is_object($row) ? (string) ($row->error_log ?? '') : (is_array($row) ? (string) ($row['error_log'] ?? '') : '');
        if ($error_log === '') return false;
        if (strpos($error_log, 'پیش از ارسال به Gemini و پیش از هرگونه ذخیره‌سازی') !== false
            || strpos($error_log, 'validation_stage=source_preflight') !== false
            || strpos($error_log, 'validation_stage: source_preflight') !== false) {
            return false;
        }
        // Only the known legacy failure proves this attempt saved product data before category sync failed.
        return strpos($error_log, 'اطلاعات کالا ذخیره شد، اما همگام‌سازی/تأیید دسته‌بندی ناموفق بود') !== false;
    }
}

/** Draft an existing product only when an administrator explicitly requests it from a confirmed post-save quarantine row. Never delete data. */
if (!function_exists('evazar_queue_draft_quarantined_product')) {
    function evazar_queue_draft_quarantined_product($post_id) {
        $post_id = absint($post_id);
        if ($post_id < 1 || !function_exists('get_post')) return new WP_Error('QUARANTINE_PRODUCT_NOT_FOUND', 'محصول ذخیره‌شده پیدا نشد.');
        $post = get_post($post_id);
        if (!$post || (string) ($post->post_type ?? '') !== 'evazar_product') {
            return new WP_Error('QUARANTINE_PRODUCT_TYPE_INVALID', 'رکورد مرتبط، محصول ایوازار نیست؛ هیچ تغییری انجام نشد.');
        }
        if (in_array((string) ($post->post_status ?? ''), ['trash', 'auto-draft'], true)) {
            return new WP_Error('QUARANTINE_PRODUCT_STATUS_INVALID', 'محصول در زباله‌دان یا پیش‌نویس خودکار است؛ هیچ تغییری انجام نشد.');
        }
        if ((string) ($post->post_status ?? '') === 'draft') {
            return ['success' => true, 'changed' => false, 'message' => 'محصول از قبل پیش‌نویس است؛ داده‌ای تغییر نکرد.'];
        }
        $updated = wp_update_post(['ID' => $post_id, 'post_status' => 'draft'], true);
        if (function_exists('is_wp_error') && is_wp_error($updated)) {
            return new WP_Error('QUARANTINE_PRODUCT_DRAFT_FAILED', 'انتقال محصول به پیش‌نویس ناموفق بود: ' . $updated->get_error_message());
        }
        if (absint($updated) !== $post_id) {
            return new WP_Error('QUARANTINE_PRODUCT_DRAFT_FAILED', 'وردپرس تغییر وضعیت محصول به پیش‌نویس را تأیید نکرد.');
        }
        if (function_exists('update_post_meta')) {
            update_post_meta($post_id, '_evazar_quarantine_draft_reason', 'SOURCE_CATEGORY_PATH_MISSING');
            update_post_meta($post_id, '_evazar_quarantine_draft_at', current_time('mysql'));
        }
        return ['success' => true, 'changed' => true, 'message' => 'محصول به پیش‌نویس منتقل شد؛ هیچ داده‌ای حذف نشد و برای نمایش عمومی منتشر نیست.'];
    }
}

/** Optional automatic retry interval for category-path quarantine; disabled by default. */
if (!function_exists('evazar_queue_category_quarantine_auto_retry_days')) {
    function evazar_queue_category_quarantine_auto_retry_days() {
        $days = absint(get_option('evazar_queue_category_quarantine_auto_retry_days', 0));
        return in_array($days, [1, 3, 7, 14], true) ? $days : 0;
    }
}

/** Move due, explicitly opt-in quarantined rows back to pending. Other quarantine reasons are never auto-retried. */
if (!function_exists('evazar_queue_promote_due_category_quarantine')) {
    function evazar_queue_promote_due_category_quarantine() {
        global $wpdb;
        $days = evazar_queue_category_quarantine_auto_retry_days();
        if ($days < 1) return 0;
        $table_name = $wpdb->prefix . 'evazar_import_queue';
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name)));
        if ($exists !== $table_name) return 0;
        $now_mysql = current_time('mysql');
        $note = ' | بازگردانی خودکار قرنطینه طبق تنظیم مدیر؛ بررسی مجدد مسیر دسته‌بندی مبدأ.';
        // A scheduled quarantine recheck begins a fresh retry generation; otherwise an old
        // retry count from before quarantine could prematurely exhaust the ordinary retry policy.
        $updated = $wpdb->query($wpdb->prepare(
            "UPDATE `$table_name` SET status='pending', retries=0, error_code='', error_log=CONCAT(COALESCE(error_log,''), %s), claim_token='', claimed_at=NULL, next_attempt_at=NULL WHERE status='quarantined' AND error_code='SOURCE_CATEGORY_PATH_MISSING' AND next_attempt_at IS NOT NULL AND next_attempt_at <= %s",
            $note, $now_mysql
        ));
        if ($updated !== false && (int) $updated > 0) delete_transient('evazar_queue_dashboard_stats_v2');
        return $updated === false ? 0 : max(0, (int) $updated);
    }
}

/** One-time conservative migration of existing retry loops with the exact known missing-source-path messages. */
if (!function_exists('evazar_queue_migrate_legacy_category_path_quarantine')) {
    function evazar_queue_migrate_legacy_category_path_quarantine() {
        global $wpdb;
        $migration_option = 'evazar_queue_category_path_quarantine_migration_v1';
        if (get_option($migration_option, '') === 'done') return 0;
        $table_name = $wpdb->prefix . 'evazar_import_queue';
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name)));
        if ($exists !== $table_name) return 0;
        $days = evazar_queue_category_quarantine_auto_retry_days();
        $next_due_sql = $days > 0
            ? "DATE_ADD(COALESCE(last_error_at, updated_at, NOW()), INTERVAL " . (int) $days . " DAY)"
            : 'NULL';
        $sql = "UPDATE `$table_name`
                SET status='quarantined', error_code='SOURCE_CATEGORY_PATH_MISSING',
                    claim_token='', claimed_at=NULL, next_attempt_at=$next_due_sql,
                    error_log=CONCAT(COALESCE(error_log,''), ' | EVazar Core 2.9.84.57: migrated exact missing source category-path error to review quarantine.')
                WHERE status IN ('pending','failed')
                  AND (error_log LIKE '%اطلاعات مسیر مبدأ دسته‌بندی از دیجی‌کالا دریافت نشد%'
                       OR error_log LIKE '%URL معتبر مبدأ برای دسته‌بندی%')";
        $result = $wpdb->query($sql);
        if ($result === false) return 0;
        // Recover the partially saved local product ID for migrated rows when its SKU/DKP meta exists.
        $legacy_rows = $wpdb->get_results("SELECT id, dkp FROM `$table_name` WHERE status='quarantined' AND error_code='SOURCE_CATEGORY_PATH_MISSING' AND related_product_id=0 ORDER BY id DESC LIMIT 250");
        foreach ((array) $legacy_rows as $legacy_row) {
            $legacy_dkp = trim((string) ($legacy_row->dkp ?? ''));
            if ($legacy_dkp === '') continue;
            $post_id = absint($wpdb->get_var($wpdb->prepare(
                "SELECT post_id FROM `{$wpdb->postmeta}` WHERE meta_key IN ('_evazar_sku','_sku','_evazar_dk_id') AND meta_value=%s ORDER BY CASE meta_key WHEN '_evazar_sku' THEN 0 WHEN '_sku' THEN 1 ELSE 2 END LIMIT 1",
                $legacy_dkp
            )));
            if ($post_id > 0) $wpdb->update($table_name, ['related_product_id' => $post_id], ['id' => (int) $legacy_row->id, 'status' => 'quarantined']);
        }
        update_option($migration_option, 'done', false);
        if ((int) $result > 0) delete_transient('evazar_queue_dashboard_stats_v2');
        return max(0, (int) $result);
    }
}

// ==========================================
// 1. ایجاد جدول صف (Queue Database Table)
// ==========================================
function evazar_queue_create_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        url varchar(2048) NOT NULL,
        dkp varchar(50) NOT NULL,
        related_product_id bigint(20) unsigned NOT NULL DEFAULT 0,
        status varchar(20) DEFAULT 'pending' NOT NULL,
        retries int(11) DEFAULT 0 NOT NULL,
        error_code varchar(50) DEFAULT '' NOT NULL,
        error_log text DEFAULT '' NOT NULL,
        last_error_at datetime DEFAULT NULL,
        claim_token varchar(64) DEFAULT '' NOT NULL,
        claimed_at datetime DEFAULT NULL,
        next_attempt_at datetime DEFAULT NULL,
        created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY  (id),
        KEY status (status),
        KEY dkp (dkp),
        KEY error_code (error_code),
        KEY claim_token (claim_token),
        KEY status_id (status, id),
        KEY status_next_attempt (status, next_attempt_at, id),
        UNIQUE KEY dkp_unique (dkp)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

function evazar_queue_import_history_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'evazar_import_history';
}

function evazar_queue_import_history_cutoff() {
    // History timestamps are stored in UTC so the 24-hour window is independent
    // of the WordPress site's timezone and daylight-saving changes.
    return gmdate('Y-m-d H:i:s', time() - DAY_IN_SECONDS);
}

function evazar_queue_ensure_import_history_table() {
    global $wpdb;

    $table_name = evazar_queue_import_history_table_name();
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        dkp varchar(50) NOT NULL,
        product_id bigint(20) unsigned NOT NULL DEFAULT 0,
        source_url varchar(2048) NOT NULL,
        imported_at datetime NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY dkp_unique (dkp),
        KEY imported_at (imported_at),
        KEY product_id (product_id)
    ) $charset_collate;";

    $history_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name)));
    if ($history_exists !== $table_name) {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    $history_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name)));
    if ($history_exists !== $table_name) {
        return false;
    }

    // One-time best-effort migration: recover the last 24 hours from queue rows
    // that are still completed. Older/requeued rows have no reliable completion
    // timestamp in legacy versions, so they are intentionally not guessed.
    // updated_at is generated by MySQL; normalize it to UTC before storing.
    if (get_option('evazar_queue_import_history_backfill_v1') !== '1') {
        $queue_table = $wpdb->prefix . 'evazar_import_queue';
        $queue_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($queue_table)));
        if ($queue_exists === $queue_table) {
            $backfill_sql = $wpdb->prepare(
                "INSERT IGNORE INTO `$table_name` (dkp, product_id, source_url, imported_at)
                 SELECT q.dkp, COALESCE(MAX(p.ID), 0), q.url,
                        TIMESTAMPADD(SECOND, -TIMESTAMPDIFF(SECOND, UTC_TIMESTAMP(), NOW()), q.updated_at)
                 FROM `$queue_table` q
                 LEFT JOIN {$wpdb->postmeta} pm
                   ON pm.meta_key IN ('_evazar_sku', '_sku') AND pm.meta_value = q.dkp
                 LEFT JOIN {$wpdb->posts} p
                   ON p.ID = pm.post_id
                  AND p.post_type = 'evazar_product'
                  AND p.post_status NOT IN ('trash', 'auto-draft')
                 WHERE q.status = 'completed'
                   AND q.dkp != ''
                   AND q.updated_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
                 GROUP BY q.dkp, q.url, q.updated_at"
            );
            $backfill_result = $wpdb->query($backfill_sql);
            if ($backfill_result !== false) {
                update_option('evazar_queue_import_history_backfill_v1', '1', false);
            }
        }
    }

    return true;
}

/**
 * Register a successful import regardless of whether it came from the queue worker
 * or the one-product manual importer. The queue dashboard's "completed" number
 * is queue-row based, so manual imports are mirrored into the queue as completed.
 *
 * $imported_at_utc is optional and is used only for one-time recovery from the
 * existing import log, where timestamps are stored in the WordPress timezone.
 */
function evazar_queue_record_successful_import($dkp_or_url, $product_id, $source_url = '', $imported_at_utc = '') {
    global $wpdb;

    $product_id = absint($product_id);
    if (!$product_id) {
        return ['history_saved' => false, 'queue_saved' => false];
    }

    $dkp = trim((string) get_post_meta($product_id, '_evazar_sku', true));
    if ($dkp === '') {
        $dkp = preg_replace('/[^0-9]/', '', (string) $dkp_or_url);
    }
    $dkp = preg_replace('/[^0-9]/', '', (string) $dkp);
    if ($dkp === '') {
        error_log('[EVazar Core] Cannot record import history: missing DKP for product ID ' . $product_id);
        return ['history_saved' => false, 'queue_saved' => false];
    }

    $meta_url = (string) get_post_meta($product_id, '_evazar_dk_url', true);
    if ($meta_url && preg_match('~^https?://(?:www\.)?digikala\.com/~i', $meta_url)) {
        $source_url = $meta_url;
    } elseif (!$source_url || !preg_match('~^https?://(?:www\.)?digikala\.com/~i', (string) $source_url)) {
        $source_url = 'https://www.digikala.com/product/dkp-' . rawurlencode($dkp) . '/';
    }
    $source_url = esc_url_raw($source_url);
    if (!$source_url) {
        $source_url = 'https://www.digikala.com/product/dkp-' . rawurlencode($dkp) . '/';
    }

    $imported_at = $imported_at_utc;
    if (!is_string($imported_at) || !preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $imported_at)) {
        $imported_at = current_time('mysql', true); // UTC
    }

    // Save the history independently of current queue state.
    $history_table = evazar_queue_import_history_table_name();
    $history_result = $wpdb->replace(
        $history_table,
        [
            'dkp'         => $dkp,
            'product_id'  => $product_id,
            'source_url'  => $source_url,
            'imported_at' => $imported_at,
        ],
        ['%s', '%d', '%s', '%s']
    );
    $history_saved = ($history_result !== false);
    if (!$history_saved) {
        error_log('[EVazar Core] Failed to save manual/import history for DKP ' . $dkp . ': ' . $wpdb->last_error);
    }

    // Mirror a successful manual import into the queue status model. If this DKP
    // already exists as pending/failed/processing, mark that row completed instead
    // of creating a duplicate or letting the queue re-import it.
    $queue_table = $wpdb->prefix . 'evazar_import_queue';
    $existing_id = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM `$queue_table` WHERE dkp = %s LIMIT 1",
        $dkp
    ));
    $queue_data = [
        'url'             => $source_url,
        'status'          => 'completed',
        'retries'         => 0,
        'error_code'      => '',
        'error_log'       => '',
        'last_error_at'   => null,
        'claim_token'     => '',
        'claimed_at'      => null,
        'next_attempt_at' => null,
    ];
    $queue_formats = ['%s', '%s', '%d', '%s', '%s', null, '%s', null, null];

    if ($existing_id) {
        $queue_result = $wpdb->update(
            $queue_table,
            $queue_data,
            ['id' => absint($existing_id)],
            $queue_formats,
            ['%d']
        );
        // 0 means the row was already in exactly this state, not a DB error.
        $queue_saved = ($queue_result !== false);
    } else {
        $queue_data['dkp'] = $dkp;
        $queue_formats = ['%s', '%s', '%d', '%s', '%s', null, '%s', null, null, '%s'];
        // Keep column order independent from format order by passing explicit data
        // keys (WordPress maps format entries by key).
        $queue_data = [
            'url'             => $source_url,
            'dkp'             => $dkp,
            'status'          => 'completed',
            'retries'         => 0,
            'error_code'      => '',
            'error_log'       => '',
            'last_error_at'   => null,
            'claim_token'     => '',
            'claimed_at'      => null,
            'next_attempt_at' => null,
        ];
        $queue_formats = ['%s', '%s', '%s', '%d', '%s', '%s', null, '%s', null, null];
        $queue_result = $wpdb->insert($queue_table, $queue_data, $queue_formats);
        $queue_saved = ($queue_result !== false);

        // Handle a simultaneous enqueue that won the UNIQUE DKP race.
        if (!$queue_saved) {
            $raced_id = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM `$queue_table` WHERE dkp = %s LIMIT 1",
                $dkp
            ));
            if ($raced_id) {
                $queue_result = $wpdb->update(
                    $queue_table,
                    [
                        'url' => $source_url, 'status' => 'completed', 'retries' => 0,
                        'error_code' => '', 'error_log' => '', 'last_error_at' => null,
                        'claim_token' => '', 'claimed_at' => null, 'next_attempt_at' => null,
                    ],
                    ['id' => absint($raced_id)],
                    ['%s', '%s', '%d', '%s', '%s', null, '%s', null, null],
                    ['%d']
                );
                $queue_saved = ($queue_result !== false);
            }
        }
    }

    if (!$queue_saved) {
        error_log('[EVazar Core] Failed to sync successful import to queue for DKP ' . $dkp . ': ' . $wpdb->last_error);
    }

    // Dashboard statistics intentionally retain their 30-second cache during import
    // bursts to avoid re-running aggregate queue counts for every successful product.
    return ['history_saved' => $history_saved, 'queue_saved' => $queue_saved];
}

/**
 * One-time compatibility recovery: successful imports from the previous 24 hours
 * may already exist in the lightweight log but were not written to the new history
 * table by older plugin versions. Recover those entries once, preserving timestamps.
 */
function evazar_queue_backfill_recent_imports_from_logs() {
    if (get_option('evazar_queue_manual_import_log_backfill_v1') === '1') {
        return;
    }
    if (!function_exists('evazar_import_get_last_logs') || !function_exists('evazar_queue_record_successful_import')) {
        return;
    }

    $logs = evazar_import_get_last_logs(50);
    $now = time();
    $cutoff = $now - DAY_IN_SECONDS;
    $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone(function_exists('wp_timezone_string') && wp_timezone_string() ? wp_timezone_string() : 'UTC');

    // Logs are newest-first. Process oldest-first so the UNIQUE DKP history row
    // ends up with the latest successful timestamp if a product appears more than once.
    foreach (array_reverse((array) $logs) as $log) {
        if (!is_array($log) || ($log['type'] ?? '') !== 'success') {
            continue;
        }
        $product_id = absint($log['extra']['post_id'] ?? 0);
        $dkp = preg_replace('/[^0-9]/', '', (string) ($log['dkp'] ?? ''));
        $raw_time = (string) ($log['time'] ?? '');
        if (!$product_id || $dkp === '' || $raw_time === '') {
            continue;
        }

        $local_dt = DateTimeImmutable::createFromFormat('!Y/m/d H:i:s', $raw_time, $tz);
        if (!$local_dt) {
            continue;
        }
        $timestamp = $local_dt->getTimestamp();
        // Ignore old and implausibly future-dated log entries.
        if ($timestamp < $cutoff || $timestamp > ($now + 300)) {
            continue;
        }

        $imported_at_utc = gmdate('Y-m-d H:i:s', $timestamp);
        evazar_queue_record_successful_import($dkp, $product_id, '', $imported_at_utc);
    }

    update_option('evazar_queue_manual_import_log_backfill_v1', '1', false);
}

function evazar_queue_queue_has_unique_dkp_index() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    $index = $wpdb->get_row($wpdb->prepare("SHOW INDEX FROM `$table_name` WHERE Key_name = %s", 'dkp_unique'));
    return ($index && isset($index->Non_unique) && intval($index->Non_unique) === 0);
}

function evazar_queue_capacity_intake_has_unique_dkp_index() {
    global $wpdb;
    $table_name = evazar_queue_capacity_intake_table_name();
    $index = $wpdb->get_row($wpdb->prepare("SHOW INDEX FROM `$table_name` WHERE Key_name = %s", 'dkp_unique'));
    return ($index && isset($index->Non_unique) && intval($index->Non_unique) === 0);
}

/** Verify a real one-column unique index on DKP; a merely named or composite index is not enough. */
function evazar_queue_table_has_verified_dkp_unique_index($table_name) {
    global $wpdb;
    $table_name = (string) $table_name;
    if ($table_name === '' || !preg_match('/^[A-Za-z0-9_]+$/', $table_name)) return false;
    $indexes = $wpdb->get_results($wpdb->prepare("SHOW INDEX FROM `$table_name` WHERE Key_name = %s", 'dkp_unique'));
    if (!is_array($indexes) || count($indexes) !== 1) return false;
    $index = $indexes[0];
    return isset($index->Non_unique, $index->Column_name, $index->Seq_in_index)
        && (int) $index->Non_unique === 0
        && (string) $index->Column_name === 'dkp'
        && (int) $index->Seq_in_index === 1
        && (!isset($index->Sub_part) || $index->Sub_part === null || $index->Sub_part === '');
}

function evazar_queue_cleanup_duplicate_dkps($limit = 100) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';

    $limit = max(1, min(100, intval($limit)));
    $duplicates = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT dkp\n             FROM `$table_name`\n             WHERE dkp != ''\n             GROUP BY dkp\n             HAVING COUNT(*) > 1\n             ORDER BY MIN(id) ASC\n             LIMIT %d",
            $limit
        )
    );

    if (empty($duplicates)) {
        return 0;
    }

    $deleted = 0;
    foreach ($duplicates as $dup) {
        $dkp = (string) $dup->dkp;
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, status, created_at\n                 FROM `$table_name`\n                 WHERE dkp = %s\n                 ORDER BY\n                    CASE status\n                        WHEN 'completed' THEN 1\n                        WHEN 'processing' THEN 2\n                        WHEN 'pending' THEN 3\n                        WHEN 'failed' THEN 4\n                        ELSE 5\n                    END ASC,\n                    id ASC",
                $dkp
            )
        );

        if (count($rows) < 2) {
            continue;
        }

        // فقط یک رکورد را نگه می‌داریم؛ اولویت با processing، سپس pending، completed و failed است تا پردازش زنده قطع نشود.
        $keep_id = intval($rows[0]->id);
        $delete_ids = [];
        foreach (array_slice($rows, 1) as $row) {
            $delete_ids[] = intval($row->id);
        }

        if (!empty($delete_ids)) {
            $placeholders = implode(',', array_fill(0, count($delete_ids), '%d'));
            $query = "DELETE FROM `$table_name` WHERE id IN ($placeholders) AND id != %d";
            $args = array_merge($delete_ids, [$keep_id]);
            $res = $wpdb->query(call_user_func_array([$wpdb, 'prepare'], array_merge([$query], $args)));
            if ($res !== false) {
                $deleted += intval($res);
            }
        }
    }

    return $deleted;
}

function evazar_queue_ensure_unique_dkp_index() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';

    if (evazar_queue_queue_has_unique_dkp_index()) {
        return true;
    }

    // رکوردهای ناقص بدون DKP قابل پردازش نیستند و Unique Index نباید چند مقدار خالی داشته باشد.
    $wpdb->query("DELETE FROM `$table_name` WHERE dkp = ''");

    // قبل از ساخت Unique Index، هر DKP تکراری را به یک رکورد معتبر ادغام می‌کنیم.
    evazar_queue_cleanup_duplicate_dkps(100);

    $remaining_duplicate = $wpdb->get_var(
        "SELECT dkp FROM `$table_name` WHERE dkp != '' GROUP BY dkp HAVING COUNT(*) > 1 LIMIT 1"
    );
    if (!empty($remaining_duplicate)) {
        return false;
    }

    $altered = $wpdb->query("ALTER TABLE `$table_name` ADD UNIQUE KEY `dkp_unique` (`dkp`)");
    if ($altered === false) {
        // اگر Index قبلاً در فاصله بین دو درخواست اضافه شده باشد، نتیجه نهایی همچنان موفق است.
        return evazar_queue_queue_has_unique_dkp_index();
    }

    return true;
}

function evazar_queue_ensure_table() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        evazar_queue_create_table();
    } else {
        // افزودن خودکار ستون‌های جدید خطایابی ساختاریافته در صورت عدم وجود
        $cols = $wpdb->get_col("DESC `$table_name`", 0);
        if (is_array($cols)) {
            if (!in_array('related_product_id', $cols)) {
                $wpdb->query("ALTER TABLE `$table_name` ADD COLUMN `related_product_id` bigint(20) unsigned NOT NULL DEFAULT 0 AFTER `dkp`");
            }
            if (!in_array('error_code', $cols)) {
                $wpdb->query("ALTER TABLE `$table_name` ADD COLUMN `error_code` varchar(50) DEFAULT '' NOT NULL AFTER `retries`");
            }
            if (!in_array('last_error_at', $cols)) {
                $wpdb->query("ALTER TABLE `$table_name` ADD COLUMN `last_error_at` datetime DEFAULT NULL AFTER `error_log`");
            }
            if (!in_array('claim_token', $cols)) {
                $wpdb->query("ALTER TABLE `$table_name` ADD COLUMN `claim_token` varchar(64) DEFAULT '' NOT NULL AFTER `last_error_at`");
            }
            if (!in_array('claimed_at', $cols)) {
                $wpdb->query("ALTER TABLE `$table_name` ADD COLUMN `claimed_at` datetime DEFAULT NULL AFTER `claim_token`");
            }
            if (!in_array('next_attempt_at', $cols)) {
                $wpdb->query("ALTER TABLE `$table_name` ADD COLUMN `next_attempt_at` datetime DEFAULT NULL AFTER `claimed_at`");
            }
        }
    }

    // آخرین لایه حفاظتی: هر DKP در سطح دیتابیس هم یکتا باشد.
    evazar_queue_ensure_unique_dkp_index();
    evazar_queue_ensure_import_history_table();
    evazar_queue_ensure_capacity_intake_table();
    // Keep legacy missing-source-category rows from cycling forever in the normal queue.
    evazar_queue_migrate_legacy_category_path_quarantine();
}

/** Durable holding queue for incoming products that exceed the currently processable queue capacity. */
function evazar_queue_capacity_intake_table_name() {
    global $wpdb;
    return $wpdb->prefix . 'evazar_import_intake';
}

function evazar_queue_ensure_capacity_intake_table() {
    global $wpdb;
    $table_name = evazar_queue_capacity_intake_table_name();
    $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name)));
    if ($exists === $table_name) {
        // Add the intake mode to existing installs without deleting or rewriting staged rows.
        $mode_column = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$table_name` LIKE %s", 'mode'));
        if ($mode_column !== 'mode') {
            $altered = $wpdb->query("ALTER TABLE `$table_name` ADD COLUMN `mode` varchar(20) NOT NULL DEFAULT 'import' AFTER `url`");
            // Two concurrent first requests can both observe the missing column. If the
            // other request wins the ALTER race, verify the resulting schema instead of
            // incorrectly disabling queue ingestion for this request.
            if ($altered === false) {
                $mode_column = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$table_name` LIKE %s", 'mode'));
                if ($mode_column !== 'mode') return false;
            }
        }
        $mode_column = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$table_name` LIKE %s", 'mode'));
        return $mode_column === 'mode';
    }

    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS `$table_name` (
        id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
        dkp varchar(50) NOT NULL,
        url varchar(2048) NOT NULL DEFAULT '',
        mode varchar(20) NOT NULL DEFAULT 'import',
        created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY dkp_unique (dkp),
        KEY created_at (created_at),
        KEY mode_id (mode, id)
    ) $charset_collate;";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
    $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name)));
    if ($exists !== $table_name) return false;
    $mode_column = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$table_name` LIKE %s", 'mode'));
    if ($mode_column !== 'mode') {
        $altered = $wpdb->query("ALTER TABLE `$table_name` ADD COLUMN `mode` varchar(20) NOT NULL DEFAULT 'import' AFTER `url`");
        if ($altered === false) {
            $mode_column = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$table_name` LIKE %s", 'mode'));
            if ($mode_column !== 'mode') return false;
        }
        $mode_column = $wpdb->get_var($wpdb->prepare("SHOW COLUMNS FROM `$table_name` LIKE %s", 'mode'));
    }
    return $mode_column === 'mode';
}

/** Shared MySQL advisory lock serializes admission/promotion without holding a PHP-only race-prone flag. */
function evazar_queue_capacity_lock_name() {
    global $wpdb;
    return 'evz_qcap_' . substr(md5((string) $wpdb->prefix), 0, 32);
}

function evazar_queue_capacity_lock_acquire($timeout_seconds = 3) {
    global $wpdb;
    $name = evazar_queue_capacity_lock_name();
    $timeout_seconds = max(0, min(10, absint($timeout_seconds)));
    $result = $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $name, $timeout_seconds));
    return (string) $result === '1';
}

function evazar_queue_capacity_lock_release() {
    global $wpdb;
    $name = evazar_queue_capacity_lock_name();
    $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $name));
}

/**
 * Effective per-run queue ceiling. In Gemini batch mode, capacity scales with
 * configured per-Worker products/request × distinct configured Gemini Workers,
 * up to five Workers (250 products maximum). The currently eligible Worker
 * count and transport/runtime guards narrow this ceiling immediately before
 * dispatch. Non-Gemini queue processing retains its legacy 75-item ceiling.
 */
function evazar_queue_effective_run_limit($configured_limit = null) {
    $base_limit = ($configured_limit === null)
        ? (int) get_option('evazar_queue_max_products_per_run', 250)
        : (int) $configured_limit;
    $batch_mode = function_exists('evazar_queue_product_batch_enabled') && evazar_queue_product_batch_enabled();
    $hard_limit = $batch_mode ? 250 : 75;
    $base_limit = max(1, min($hard_limit, $base_limit));
    if (!$batch_mode) return $base_limit;
    $per_request = function_exists('evazar_queue_product_batch_size') ? evazar_queue_product_batch_size() : 50;
    $worker_count = 0;
    if (function_exists('evazar_get_gemini_worker_urls')) {
        $urls = array_unique(array_filter(array_map(static function($url) {
            return rtrim(trim((string) $url), '/');
        }, (array) evazar_get_gemini_worker_urls())));
        $worker_count = count($urls);
    }
    $automatic_slots = max(1, min(5, $worker_count));
    return min($base_limit, $per_request * $automatic_slots, 250);
}

/** Capacity for ACTIVE queue rows, based on the same queue limit and currently eligible Gemini Workers as dispatch. */
function evazar_queue_current_processing_capacity() {
    $queue_limit = evazar_queue_effective_run_limit();
    $ai_enabled = get_option('evazar_ai_enabled', '') === 'yes';
    $engine_mode = (string) get_option('evazar_ai_engine_mode', '');

    // Auto queue processing is intentionally paused when AI is enabled in an unsupported engine mode.
    if ($ai_enabled && $engine_mode !== 'gemini_only') return 0;

    if ($ai_enabled && $engine_mode === 'gemini_only') {
        if (!function_exists('evazar_queue_product_batch_enabled') || !evazar_queue_product_batch_enabled()) return 0;
        $ai_batch_size = function_exists('evazar_queue_product_batch_size') ? evazar_queue_product_batch_size() : 50;
        $queue_limit = max(5, min(250, $queue_limit));
        $eligible_workers = function_exists('evazar_queue_parallel_healthy_worker_count')
            ? evazar_queue_parallel_healthy_worker_count()
            : 0;
        if ($eligible_workers < 1) return 0;
        $parallel_enabled = function_exists('evazar_queue_product_batch_parallel_enabled')
            ? evazar_queue_product_batch_parallel_enabled()
            : false;
        $parallelism = function_exists('evazar_queue_product_batch_parallelism')
            ? evazar_queue_product_batch_parallelism()
            : 1;
        if (function_exists('evazar_queue_adaptive_claim_capacity')) {
            $capacity = evazar_queue_adaptive_claim_capacity($queue_limit, $eligible_workers, $ai_batch_size, $parallel_enabled, $parallelism);
        } else {
            $slots = $parallel_enabled ? min($eligible_workers, max(1, (int) $parallelism)) : $eligible_workers;
            $capacity = min($queue_limit, $slots * max(2, min(50, (int) $ai_batch_size)));
        }
        // The cron path deliberately sends only one batch when parallel transport is unavailable.
        // Keep admission capacity aligned so it cannot fill the active queue beyond that run's safe ceiling.
        if (!$parallel_enabled || !function_exists('evazar_queue_parallel_transport_available') || !evazar_queue_parallel_transport_available()) {
            $capacity = min($capacity, $ai_batch_size);
        }
        return min(250, max(0, (int) $capacity));
    }

    // With AI disabled, imports keep using the normal configured queue batch limit.
    return $queue_limit;
}

function evazar_queue_active_item_count() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    return (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table_name` WHERE status IN ('pending','processing')");
}

/**
 * Move unprocessable legacy pending rows out of the automatic queue without deleting them.
 * Importer normalization keeps only digits, so a DKP containing no digits can never reach a Worker.
 * Such rows must not consume run capacity or be retried forever.
 */
function evazar_queue_quarantine_invalid_pending_dkps($limit = 1000) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    $limit = max(1, min(5000, absint($limit)));
    $message = 'شناسه DKP خالی یا فاقد رقم است و قابل ارسال به Worker نیست؛ ردیف بدون حذف داده به وضعیت خطای INVALID_DKP منتقل شد و به‌صورت خودکار Retry نمی‌شود.';
    $sql = $wpdb->prepare(
        "UPDATE `$table_name`
         SET status='failed', error_code='INVALID_DKP', error_log=%s, last_error_at=%s,
             claim_token='', claimed_at=NULL, next_attempt_at=NULL
         WHERE status='pending' AND (TRIM(COALESCE(dkp,''))='' OR dkp NOT REGEXP '[0-9]')
         ORDER BY id ASC LIMIT %d",
        $message,
        current_time('mysql'),
        $limit
    );
    $updated = $wpdb->query($sql);
    if ($updated === false) {
        error_log('[EVazar Queue] Failed to quarantine pending rows with invalid DKP: ' . (string) $wpdb->last_error);
        return -1;
    }
    $updated = max(0, (int) $updated);
    if ($updated > 0) {
        if (function_exists('delete_transient')) delete_transient('evazar_queue_dashboard_stats_v2');
        if (function_exists('evazar_gemini_log_event')) {
            evazar_gemini_log_event(
                'queue_invalid_dkp_quarantined',
                $updated . ' ردیف صف با DKP نامعتبر قبل از Claim به وضعیت خطا منتقل شد؛ داده‌ای حذف نشد و شمارنده Retry افزایش نیافت.',
                '', 0, 0,
                ['purpose' => 'product_import_batch', 'queue_invalid_dkp_quarantined' => $updated]
            );
        }
    }
    return $updated;
}

/** Requeue identifiable legacy failures gradually; new failures are already stored as pending. */
function evazar_queue_requeue_legacy_failed_items($limit = 100) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    $limit = max(1, min(100, absint($limit)));
    $now_mysql = current_time('mysql');
    $retry_mysql = evazar_queue_mysql_after(60);
    $message = 'خطای قدیمی به‌صورت خودکار برای تلاش مجدد به صف بازگشت.';
    $sql = $wpdb->prepare(
        "UPDATE `$table_name`
         SET status='pending',
             retries=COALESCE(retries,0)+1,
             error_code='AUTO_RETRY_LEGACY_FAILURE',
             error_log=%s,
             last_error_at=%s,
             claim_token='',
             claimed_at=NULL,
             next_attempt_at=%s,
             url=IF(url IS NULL OR url='', CONCAT('https://www.digikala.com/product/dkp-', dkp, '/'), url)
         WHERE status='failed' AND dkp<>'' AND dkp REGEXP '[0-9]' AND COALESCE(error_code,'') <> 'INVALID_DKP'
         ORDER BY id ASC LIMIT %d",
        $message,
        $now_mysql,
        $retry_mysql,
        $limit
    );
    $updated = $wpdb->query($sql);
    if ($updated === false) {
        error_log('[EVazar Queue] Automatic retry migration for legacy failed rows failed: ' . $wpdb->last_error);
        return 0;
    }
    if ($updated > 0) delete_transient('evazar_queue_dashboard_stats_v2');
    return (int) $updated;
}

/**
 * Insert/upsert a bounded batch into the durable capacity queue.
 * Modes are ordered by intent: import < retry < rewrite. Explicit admin actions
 * upgrade an existing import placeholder instead of silently keeping the weaker mode.
 * Call only while the shared capacity lock is held.
 */
function evazar_queue_bulk_store_capacity_waiting_locked($items, $chunk_size = 100) {
    global $wpdb;
    $table_name = evazar_queue_capacity_intake_table_name();
    if (!evazar_queue_ensure_capacity_intake_table()) {
        return ['success' => false, 'affected' => 0, 'error' => 'capacity_intake_schema_unavailable'];
    }

    $normalized = [];
    $priority = ['import' => 0, 'retry' => 1, 'rewrite' => 2];
    foreach ((array) $items as $item) {
        $dkp = preg_replace('/[^0-9]/', '', (string) ($item['dkp'] ?? ''));
        if ($dkp === '') continue;
        $url = esc_url_raw((string) ($item['url'] ?? ''));
        $mode = (string) ($item['mode'] ?? 'import');
        if (!isset($priority[$mode])) $mode = 'import';
        if (!isset($normalized[$dkp]) || $priority[$mode] > $priority[$normalized[$dkp]['mode']]) {
            $normalized[$dkp] = ['dkp' => $dkp, 'url' => $url, 'mode' => $mode];
        }
    }

    $affected_total = 0;
    $chunk_size = max(1, min(100, absint($chunk_size)));
    foreach (array_chunk(array_values($normalized), $chunk_size) as $chunk) {
        $values = [];
        $args = [];
        foreach ($chunk as $item) {
            $values[] = '(%s, %s, %s)';
            $args[] = $item['dkp'];
            $args[] = $item['url'];
            $args[] = $item['mode'];
        }
        $sql = "INSERT INTO `$table_name` (dkp, url, mode) VALUES " . implode(', ', $values) . "
            ON DUPLICATE KEY UPDATE
              url = CASE WHEN VALUES(mode) IN ('retry','rewrite','qretry','qrewrite') THEN VALUES(url) ELSE url END,
              mode = CASE
                WHEN mode = 'qrewrite' THEN 'qrewrite'
                WHEN mode = 'qretry' AND VALUES(mode) = 'rewrite' THEN 'qrewrite'
                WHEN mode IN ('qretry','qrewrite') THEN mode
                WHEN VALUES(mode) = 'rewrite' THEN 'rewrite'
                WHEN mode = 'rewrite' THEN mode
                WHEN VALUES(mode) = 'retry' THEN 'retry'
                ELSE mode
              END";
        $prepared = $wpdb->prepare($sql, $args);
        $result = $wpdb->query($prepared);
        if ($result === false) {
            return ['success' => false, 'affected' => $affected_total, 'error' => 'capacity_intake_bulk_insert_failed'];
        }
        $affected_total += (int) $result;
    }

    return ['success' => true, 'affected' => $affected_total, 'error' => ''];
}

/** Store an over-capacity item durably. It is not marked as actively queued until a slot opens. */
function evazar_queue_store_capacity_waiting($dkp, $url, $mode = 'import') {
    global $wpdb;
    $table_name = evazar_queue_capacity_intake_table_name();
    $dkp = preg_replace('/[^0-9]/', '', (string) $dkp);
    if ($dkp === '' || !evazar_queue_ensure_capacity_intake_table()) return false;
    $mode = in_array((string) $mode, ['import', 'retry', 'rewrite'], true) ? (string) $mode : 'import';
    $url = esc_url_raw((string) $url);
    $result = $wpdb->query($wpdb->prepare(
        "INSERT INTO `$table_name` (dkp, url, mode) VALUES (%s, %s, %s)
         ON DUPLICATE KEY UPDATE
           url = CASE WHEN VALUES(mode) IN ('retry','rewrite','qretry','qrewrite') THEN VALUES(url) ELSE url END,
           mode = CASE
             WHEN mode = 'qrewrite' THEN 'qrewrite'
             WHEN mode = 'qretry' AND VALUES(mode) = 'rewrite' THEN 'qrewrite'
             WHEN mode IN ('qretry','qrewrite') THEN mode
             WHEN VALUES(mode) = 'rewrite' THEN 'rewrite'
             WHEN mode = 'rewrite' THEN mode
             WHEN VALUES(mode) = 'retry' THEN 'retry'
             ELSE mode
           END",
        $dkp,
        $url,
        $mode
    ));
    if ($result === false) return false;
    if ((int) $result > 0) return 'inserted';
    if ($wpdb->get_var($wpdb->prepare("SELECT id FROM `$table_name` WHERE dkp = %s LIMIT 1", $dkp))) return 'exists';
    return false;
}

/** Must be called while evazar_queue_capacity_lock_acquire() is held. */
function evazar_queue_promote_capacity_waiting_locked() {
    global $wpdb;
    $queue_table = $wpdb->prefix . 'evazar_import_queue';
    $intake_table = evazar_queue_capacity_intake_table_name();
    $capacity = evazar_queue_current_processing_capacity();
    if ($capacity < 1) {
        return ['promoted' => 0, 'cleaned' => 0, 'waiting' => (int) $wpdb->get_var("SELECT COUNT(*) FROM `$intake_table`")];
    }

    $active = evazar_queue_active_item_count();
    $slots = max(0, $capacity - $active);
    if ($slots < 1) {
        return ['promoted' => 0, 'cleaned' => 0, 'waiting' => (int) $wpdb->get_var("SELECT COUNT(*) FROM `$intake_table`")];
    }
    // Scan a bounded FIFO window larger than the number of open slots. The intake
    // table can temporarily contain stale duplicates after lock-contention fallback;
    // cleaning those must not waste a newly available slot until the next regular Cron.
    $scan_limit = min(200, max($slots, $slots + 100));
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT id, dkp, url, mode FROM `$intake_table` ORDER BY id ASC LIMIT %d",
        $scan_limit
    ));
    if (empty($rows)) return ['promoted' => 0, 'cleaned' => 0, 'waiting' => 0];

    $dkps = [];
    foreach ($rows as $row) $dkps[] = (string) $row->dkp;
    $placeholders = implode(',', array_fill(0, count($dkps), '%s'));
    $product_skus = $wpdb->get_col(call_user_func_array([$wpdb, 'prepare'], array_merge([
        "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key IN ('_sku','_evazar_sku','_evazar_dk_id') AND meta_value IN ($placeholders)"
    ], $dkps)));
    $existing_products = [];
    foreach ((array) $product_skus as $sku) {
        $normalized = preg_replace('/[^0-9]/', '', (string) $sku);
        if ($normalized !== '') $existing_products[$normalized] = true;
    }
    $queue_rows = $wpdb->get_results(call_user_func_array([$wpdb, 'prepare'], array_merge([
        "SELECT id, dkp, url, status, related_product_id, error_log FROM `$queue_table` WHERE dkp IN ($placeholders)"
    ], $dkps)));
    $queue_map = [];
    foreach ((array) $queue_rows as $queue_row) {
        $queue_dkp = preg_replace('/[^0-9]/', '', (string) $queue_row->dkp);
        if ($queue_dkp === '') continue;
        if (!isset($queue_map[$queue_dkp])) {
            $queue_map[$queue_dkp] = $queue_row;
        } elseif (in_array((string) $queue_row->status, ['pending', 'processing'], true)) {
            // Prefer an already-active queue row if legacy formatted IDs normalize to the same DKP.
            $queue_map[$queue_dkp] = $queue_row;
        }
    }

    $promoted = 0;
    $cleaned = 0;
    foreach ($rows as $row) {
        // Re-read active count before each promotion so a concurrent completion/requeue cannot overfill the cap.
        if (evazar_queue_active_item_count() >= $capacity) break;
        $dkp = preg_replace('/[^0-9]/', '', (string) $row->dkp);
        $mode = in_array((string) ($row->mode ?? 'import'), ['import', 'retry', 'rewrite', 'qretry', 'qrewrite'], true) ? (string) ($row->mode ?? 'import') : 'import';
        $delete_staged = false;
        $existing_row = $queue_map[$dkp] ?? null;

        // First honor an existing queue row. Explicit retry/rewrite work is allowed to
        // reprocess an already-imported product; ordinary fresh imports are not.
        if ($existing_row) {
            $existing_status = (string) $existing_row->status;
            if (in_array($existing_status, ['pending', 'processing'], true)) {
                // Another request already placed this DKP in the active queue.
                $delete_staged = true;
            } elseif ($existing_status === 'quarantined' && in_array($mode, ['qretry', 'qrewrite'], true)) {
                // Only the explicit bulk-quarantine action can release a quarantined row, and only when capacity is free.
                $source_url = trim((string) $row->url) !== '' ? (string) $row->url : (string) $existing_row->url;
                $old_log = (string) ($existing_row->error_log ?? '');
                $note = ' | بازگردانی گروهی قرنطینه از صف انتظار ظرفیت در ' . current_time('mysql') . '.';
                if (strlen($old_log) <= 63000) $old_log .= $note;
                $updated = $wpdb->update($queue_table, [
                    'url' => $source_url,
                    'status' => 'pending',
                    'retries' => 0,
                    'error_code' => '',
                    'error_log' => $old_log,
                    'last_error_at' => current_time('mysql'),
                    'claim_token' => '',
                    'claimed_at' => null,
                    'next_attempt_at' => null,
                ], ['id' => (int) $existing_row->id, 'status' => 'quarantined']);
                if ($updated === 1) {
                    $delete_staged = true;
                    $promoted++;
                } else {
                    $fresh_status = $wpdb->get_var($wpdb->prepare("SELECT status FROM `$queue_table` WHERE id = %d", (int) $existing_row->id));
                    if (in_array((string) $fresh_status, ['pending', 'processing'], true)) $delete_staged = true;
                    else break; // Preserve the intake row if a real database/race issue prevents requeue.
                }
            } elseif (in_array($existing_status, ['quarantined', 'excluded'], true)) {
                // Ordinary intake/retry requests cannot bypass a quarantine/exclusion decision.
                $delete_staged = true;
            } elseif (in_array($existing_status, ['failed', 'completed'], true)) {
                if (isset($existing_products[$dkp]) && $mode === 'import') {
                    $delete_staged = true;
                } else {
                    $source_url = trim((string) $row->url) !== '' ? (string) $row->url : (string) $existing_row->url;
                    $updated = $wpdb->update($queue_table, [
                        'url' => $source_url,
                        'status' => 'pending',
                        'retries' => 0,
                        'error_code' => '',
                        'error_log' => '',
                        'last_error_at' => null,
                        'claim_token' => '',
                        'claimed_at' => null,
                        'next_attempt_at' => null,
                    ], ['id' => (int) $existing_row->id, 'status' => $existing_status]);
                    if ($updated === 1) {
                        $delete_staged = true;
                        $promoted++;
                    } else {
                        $fresh_status = $wpdb->get_var($wpdb->prepare("SELECT status FROM `$queue_table` WHERE id = %d", (int) $existing_row->id));
                        if (in_array((string) $fresh_status, ['pending', 'processing'], true)) $delete_staged = true;
                        else break; // Database/race issue: leave this and later rows safely staged.
                    }
                }
            } else {
                break;
            }
        } elseif (isset($existing_products[$dkp]) && $mode === 'import') {
            // A regular Harvester import must not re-add a product already in WordPress.
            $delete_staged = true;
        } else {
            // Retry/rewrite modes deliberately bypass the existing-product check.
            $url = (string) $row->url;
            $inserted = $wpdb->insert($queue_table, [
                'url' => $url,
                'dkp' => $dkp,
                'status' => 'pending',
                'retries' => 0,
                'next_attempt_at' => null,
            ], ['%s', '%s', '%s', '%d', '%s']);
            if ($inserted !== false) {
                $delete_staged = true;
                $promoted++;
            } else {
                $fresh_status = $wpdb->get_var($wpdb->prepare("SELECT status FROM `$queue_table` WHERE dkp = %s LIMIT 1", $dkp));
                if (in_array((string) $fresh_status, ['pending', 'processing'], true)) $delete_staged = true;
                else break; // Preserve the staged row if insertion failed for a real database reason.
            }
        }

        if ($delete_staged) {
            $deleted = $wpdb->delete($intake_table, ['id' => (int) $row->id], ['%d']);
            if ($deleted !== false && $deleted > 0) $cleaned++;
        }
    }

    return [
        'promoted' => $promoted,
        'cleaned' => $cleaned,
        'waiting' => (int) $wpdb->get_var("SELECT COUNT(*) FROM `$intake_table`")
    ];
}

/** Fill available processing slots with oldest waiting intake rows; safe no-op if another admission owns the lock. */
function evazar_queue_promote_capacity_waiting() {
    global $wpdb;
    if (!evazar_queue_ensure_capacity_intake_table()) return ['promoted' => 0, 'cleaned' => 0, 'waiting' => 0, 'lock_busy' => true];
    if (!evazar_queue_capacity_lock_acquire(2)) {
        return ['promoted' => 0, 'cleaned' => 0, 'waiting' => (int) $wpdb->get_var('SELECT COUNT(*) FROM `' . evazar_queue_capacity_intake_table_name() . '`'), 'lock_busy' => true];
    }
    try {
        $result = evazar_queue_promote_capacity_waiting_locked();
    } finally {
        evazar_queue_capacity_lock_release();
    }
    if (!empty($result['promoted']) || !empty($result['cleaned'])) {
        delete_transient('evazar_queue_dashboard_stats_v2');
    }
    if (!empty($result['promoted']) && function_exists('evazar_gemini_log_event')) {
        evazar_gemini_log_event(
            'queue_capacity_promoted',
            'ظرفیت آزاد شد و ' . (int) $result['promoted'] . ' محصول از صف انتظار ظرفیت به صف فعال منتقل شد؛ ' . (int) ($result['waiting'] ?? 0) . ' محصول همچنان منتظر ظرفیت است.',
            '', 0, 0,
            ['purpose' => 'adaptive_queue_admission', 'batch_size' => (int) $result['promoted']]
        );
    }
    return $result;
}
add_action('admin_init', 'evazar_queue_ensure_table');

// ==========================================
// 2. تنظیم زمان‌بندی Cron Job
// ==========================================
add_filter('cron_schedules', 'evazar_cron_add_schedule');
function evazar_cron_add_schedule($schedules) {
    // WP-Cron's recurring event is only a safety-net tick. Actual automatic
    // processing is gated by the separately randomized single-event timestamp.
    $interval_minutes = evazar_queue_interval_min_minutes();
    $schedules['evazar_queue_custom_schedule'] = array(
        'interval' => $interval_minutes * 60,
        'display'  => sprintf('بررسی صف هر %d دقیقه (ایوازار)', $interval_minutes)
    );
    return $schedules;
}

function evazar_queue_interval_min_minutes() {
    return max(1, min(60, (int) get_option('evazar_queue_interval_min_minutes', 5)));
}

function evazar_queue_interval_max_minutes() {
    return max(evazar_queue_interval_min_minutes(), min(60, max(1, (int) get_option('evazar_queue_interval_max_minutes', 10))));
}

/** Compatibility helper for code paths that need the lower bound (e.g. internal batch-partner deferral). */
function evazar_queue_interval_minutes() {
    return evazar_queue_interval_min_minutes();
}

/**
 * Legacy whole-minute selector kept for compatibility with older integrations.
 * New automatic scheduling must use evazar_queue_random_interval_seconds().
 */
function evazar_queue_random_interval_minutes() {
    $min = evazar_queue_interval_min_minutes();
    $max = evazar_queue_interval_max_minutes();
    if ($max <= $min) return $min;
    if (function_exists('wp_rand')) return (int) wp_rand($min, $max);
    try {
        return (int) random_int($min, $max);
    } catch (Throwable $e) {
        return (int) mt_rand($min, $max);
    }
}

/**
 * Choose an inclusive random interval with one-second granularity.
 * The configured minute bounds remain exact endpoints: e.g. 5..8 minutes means
 * any whole-second value from 300 through 480 seconds, inclusive.
 */
function evazar_queue_random_interval_seconds() {
    $min = evazar_queue_interval_min_minutes() * MINUTE_IN_SECONDS;
    $max = evazar_queue_interval_max_minutes() * MINUTE_IN_SECONDS;
    if ($max <= $min) return $min;
    if (function_exists('wp_rand')) {
        return max($min, min($max, (int) wp_rand($min, $max)));
    }
    try {
        return max($min, min($max, (int) random_int($min, $max)));
    } catch (Throwable $e) {
        return max($min, min($max, (int) mt_rand($min, $max)));
    }
}

/** Format seconds as a concise Persian duration for logs and admin diagnostics. */
function evazar_queue_format_interval_duration($seconds) {
    $seconds = max(0, (int) $seconds);
    $minutes = intdiv($seconds, MINUTE_IN_SECONDS);
    $remainder = $seconds % MINUTE_IN_SECONDS;
    $parts = [];
    if ($minutes > 0) $parts[] = $minutes . ' دقیقه';
    if ($remainder > 0 || empty($parts)) $parts[] = $remainder . ' ثانیه';
    return implode(' و ', $parts);
}

/** A manager-controlled pause for queue processing; incoming items are still retained. */
function evazar_queue_is_manually_paused() {
    return get_option('evazar_import_queue_manual_paused', 'no') === 'yes';
}

/** Return still-claimed rows to pending without consuming retries or altering retry metadata. */
function evazar_queue_release_manual_pause_claims($claim_token) {
    global $wpdb;
    $claim_token = sanitize_text_field((string) $claim_token);
    if ($claim_token === '') return 0;
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    $sql = $wpdb->prepare(
        "UPDATE `$table_name` SET status='pending', claim_token='', claimed_at=NULL WHERE status='processing' AND claim_token=%s",
        $claim_token
    );
    $released = $wpdb->query($sql);
    return ($released === false) ? 0 : (int) $released;
}

function evazar_queue_next_auto_run_at() {
    return max(0, (int) get_option('evazar_queue_next_auto_run_at', 0));
}

function evazar_queue_processing_lock_option_name() {
    return 'evazar_queue_processing_run_lock';
}

/** Stable opaque owner token embedded in the legacy-compatible lock value. */
function evazar_queue_run_lock_token_from_value($lock_value) {
    $parts = explode('|', (string) $lock_value, 2);
    return isset($parts[1]) ? (string) $parts[1] : '';
}

/** One heartbeat option per owner prevents an expired owner from overwriting a successor's heartbeat. */
function evazar_queue_run_lock_heartbeat_option_name($lock_value = '') {
    $token = evazar_queue_run_lock_token_from_value($lock_value);
    if ($token === '') return 'evazar_queue_processing_run_lock_heartbeat';
    return 'evazar_queue_processing_run_lock_heartbeat_' . substr(hash('sha256', $token), 0, 16);
}

/**
 * A lock can expire only after a long period without a heartbeat. A 15-minute minimum
 * lease gives external requests margin; hosts with a larger PHP execution limit get a longer lease.
 */
function evazar_queue_run_lock_stale_after_seconds() {
    $max_execution = function_exists('ini_get') ? (int) ini_get('max_execution_time') : 0;
    if ($max_execution <= 0) return 15 * MINUTE_IN_SECONDS;
    return max(15 * MINUTE_IN_SECONDS, ($max_execution * 2) + 120);
}

/** Refresh the owning request's heartbeat; a stale/foreign request cannot refresh another lock. */
function evazar_queue_heartbeat_run_lock($lock_value = '') {
    if ($lock_value === '' && isset($GLOBALS['evazar_queue_active_run_lock'])) {
        $lock_value = (string) $GLOBALS['evazar_queue_active_run_lock'];
    }
    if (!is_string($lock_value) || $lock_value === '') return false;
    $option_name = evazar_queue_processing_lock_option_name();
    if (get_option($option_name, '') !== $lock_value) return false;
    $heartbeat_name = evazar_queue_run_lock_heartbeat_option_name($lock_value);
    update_option($heartbeat_name, time(), false);
    return true;
}

/** Remove only this owner's heartbeat; never remove a successor's heartbeat. */
function evazar_queue_delete_run_lock_heartbeat($lock_value) {
    $token = evazar_queue_run_lock_token_from_value($lock_value);
    if ($token === '') return false;
    $heartbeat_name = evazar_queue_run_lock_heartbeat_option_name($lock_value);
    return delete_option($heartbeat_name);
}

/**
 * Acquire a cross-request queue-run lock. The value stays compatible with older versions,
 * while a separate heartbeat means a genuinely active run does not expire merely because
 * its original start time is older than 15 minutes.
 */
function evazar_queue_acquire_run_lock() {
    global $wpdb;
    $option_name = evazar_queue_processing_lock_option_name();
    $existing = get_option($option_name, '');
    if ($existing !== '') {
        $parts = explode('|', (string) $existing, 2);
        $started_at = isset($parts[0]) ? (int) $parts[0] : 0;
        $heartbeat_name = evazar_queue_run_lock_heartbeat_option_name((string) $existing);
        $heartbeat_at = (int) get_option($heartbeat_name, 0);
        // Legacy locks have no heartbeat, so their original timestamp remains the fallback.
        $last_activity_at = max($started_at, $heartbeat_at);
        $stale_after = evazar_queue_run_lock_stale_after_seconds();
        if ($last_activity_at > 0 && (time() - $last_activity_at) > $stale_after && isset($wpdb->options) && method_exists($wpdb, 'prepare') && method_exists($wpdb, 'query')) {
            $deleted = $wpdb->query($wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
                $option_name,
                (string) $existing
            ));
            if ($deleted !== false && function_exists('wp_cache_delete')) {
                // Invalidate even on zero affected rows: another request may already
                // have changed/deleted the stale lock while this request held a cached copy.
                wp_cache_delete($option_name, 'options');
                wp_cache_delete('alloptions', 'options');
                wp_cache_delete('notoptions', 'options');
            }
            // This heartbeat is uniquely tied to the stale owner token, so it is safe
            // to clean even if another request won the race and already deleted the lock.
            if ($deleted !== false) evazar_queue_delete_run_lock_heartbeat((string) $existing);
            $existing = get_option($option_name, '');
        }
        if ($existing !== '') return '';
    }

    if (function_exists('wp_generate_password')) {
        $token = wp_generate_password(48, false, false);
    } else {
        try { $token = bin2hex(random_bytes(24)); }
        catch (Throwable $e) { $token = str_replace('.', '', uniqid('', true)); }
    }
    $lock_value = time() . '|' . (string) $token;
    if (!add_option($option_name, $lock_value, '', 'no')) return '';
    $GLOBALS['evazar_queue_active_run_lock'] = $lock_value;
    evazar_queue_heartbeat_run_lock($lock_value);
    return $lock_value;
}

/** Release only the lock acquired by this request; never delete a successor's lock. */
function evazar_queue_release_run_lock($lock_value = '') {
    if (!is_string($lock_value) || $lock_value === '') return;
    global $wpdb;
    $option_name = evazar_queue_processing_lock_option_name();
    $deleted = false;
    if (isset($wpdb->options) && method_exists($wpdb, 'prepare') && method_exists($wpdb, 'query')) {
        $deleted = $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
            $option_name,
            $lock_value
        ));
        if ($deleted !== false && function_exists('wp_cache_delete')) {
            wp_cache_delete($option_name, 'options');
            wp_cache_delete('alloptions', 'options');
            wp_cache_delete('notoptions', 'options');
        }
        // Per-owner heartbeat names are token-scoped; remove only this request's entry
        // whether or not the matching lock row was already removed by a competing cleanup.
        if ($deleted !== false) evazar_queue_delete_run_lock_heartbeat($lock_value);
        if ($deleted !== false) {
            if (($GLOBALS['evazar_queue_active_run_lock'] ?? '') === $lock_value) unset($GLOBALS['evazar_queue_active_run_lock']);
            return;
        }
    }
    if (get_option($option_name, '') === $lock_value && delete_option($option_name)) {
        evazar_queue_delete_run_lock_heartbeat($lock_value);
    }
    if (($GLOBALS['evazar_queue_active_run_lock'] ?? '') === $lock_value) unset($GLOBALS['evazar_queue_active_run_lock']);
}

/** Recovery cutoff must exceed one normal request timeout, while remaining bounded. */
function evazar_queue_stale_claim_age_seconds() {
    $max_execution = function_exists('ini_get') ? (int) ini_get('max_execution_time') : 0;
    if ($max_execution <= 0) return 15 * MINUTE_IN_SECONDS;
    return max(10 * MINUTE_IN_SECONDS, ($max_execution * 2) + 60);
}

/**
 * Recover only claims older than the safe lease age. The queue-run lock must already belong
 * to the current request, so no other healthy queue runner can own these old claims.
 * Compare-and-set on id + token + timestamp prevents touching a row that changed after SELECT.
 */
function evazar_queue_recover_stale_processing_claims($table_name = '', $limit = 1000) {
    global $wpdb;
    if ($table_name === '') $table_name = $wpdb->prefix . 'evazar_import_queue';
    $table_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name)));
    if ($table_exists !== $table_name) return ['recovered' => 0, 'age_seconds' => evazar_queue_stale_claim_age_seconds(), 'candidates' => 0, 'stale_before' => ''];
    $limit = max(1, min(2000, (int) $limit));
    $age_seconds = evazar_queue_stale_claim_age_seconds();
    $stale_before = evazar_queue_mysql_timestamp(time() - $age_seconds);
    $stale_items = $wpdb->get_results($wpdb->prepare(
        "SELECT id, retries, claim_token, claimed_at FROM `$table_name` WHERE status='processing' AND claimed_at IS NOT NULL AND claimed_at < %s ORDER BY claimed_at ASC LIMIT %d",
        $stale_before,
        $limit
    ));
    $recovered = 0;
    foreach ((array) $stale_items as $stale_item) {
        $next_retries = ((int) $stale_item->retries) + 1;
        $backoff_minutes = min(10, max(1, (int) pow(2, min(4, max(0, $next_retries - 1)))));
        $updated = $wpdb->query($wpdb->prepare(
            "UPDATE `$table_name` SET status='pending', retries=%d, error_code='STALE_CLAIM', error_log=%s, last_error_at=%s, claim_token='', claimed_at=NULL, next_attempt_at=%s WHERE id=%d AND status='processing' AND claim_token=%s AND claimed_at=%s AND claimed_at < %s",
            $next_retries,
            'اجرای قبلی پیش از تعیین نتیجه متوقف شد؛ Claim قدیمی با مکث ایمنی به صف انتظار برگشت.',
            current_time('mysql'),
            evazar_queue_mysql_after($backoff_minutes * MINUTE_IN_SECONDS),
            (int) $stale_item->id,
            (string) $stale_item->claim_token,
            (string) $stale_item->claimed_at,
            $stale_before
        ));
        if ($updated !== false && (int) $updated > 0) $recovered += (int) $updated;
    }
    if ($recovered > 0) {
        if (function_exists('delete_transient')) delete_transient('evazar_queue_dashboard_stats_v2');
        if (function_exists('evazar_gemini_log_event')) {
            evazar_gemini_log_event(
                'queue_stale_claim_recovery',
                'بازیابی امن صف: ' . $recovered . ' Claim قدیمی‌تر از ' . $age_seconds . ' ثانیه به انتظار با مکث افزایشی برگشت؛ اجرای فعال یا Claim تازه تغییر نکرد.',
                '', 0, 0,
                ['purpose' => 'product_import_batch', 'queue_stale_recovered' => $recovered, 'queue_stale_age_seconds' => $age_seconds, 'queue_stale_candidates' => is_countable($stale_items) ? count($stale_items) : 0]
            );
        }
    }
    return ['recovered' => $recovered, 'age_seconds' => $age_seconds, 'candidates' => is_countable($stale_items) ? count($stale_items) : 0, 'stale_before' => $stale_before];
}

/** Never append a fresh batch while any previous Claim remains in processing. */
function evazar_queue_guard_previous_processing_claims($table_name = '', $recovered_count = 0) {
    global $wpdb;
    if ($table_name === '') $table_name = $wpdb->prefix . 'evazar_import_queue';
    $processing_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table_name` WHERE status='processing'");
    if ($processing_count < 1) return ['blocked' => false, 'processing_count' => 0];
    $oldest_claimed_at = (string) $wpdb->get_var("SELECT MIN(claimed_at) FROM `$table_name` WHERE status='processing' AND claimed_at IS NOT NULL");
    $age_seconds = evazar_queue_stale_claim_age_seconds();
    $message = 'Claim محافظ صف فعال شد: ' . $processing_count . ' محصول هنوز در وضعیت «در حال پردازش» باقی مانده است؛ این نوبت هیچ محصول جدیدی Claim نکرد تا از جمع‌شدن دسته‌ها و تکرار واردات جلوگیری شود.';
    if ($oldest_claimed_at !== '') $message .= ' قدیمی‌ترین claimed_at=' . $oldest_claimed_at . '.';
    if ((int) $recovered_count > 0) $message .= ' در همین اجرا ' . (int) $recovered_count . ' Claim قدیمی بازیابی شد.';
    if (function_exists('evazar_gemini_log_event')) {
        evazar_gemini_log_event(
            'queue_prior_claims_blocked',
            $message,
            '', 0, 0,
            ['purpose' => 'product_import_batch', 'queue_processing_before_new_claim' => $processing_count, 'queue_oldest_processing_claimed_at' => $oldest_claimed_at, 'queue_stale_age_seconds' => $age_seconds, 'queue_stale_recovered_this_run' => max(0, (int) $recovered_count)]
        );
    }
    return ['blocked' => true, 'processing_count' => $processing_count, 'oldest_claimed_at' => $oldest_claimed_at, 'message' => $message];
}

/**
 * Start-to-start cadence: choose and persist the next not-before timestamp at run start.
 * A long run never overlaps its successor; the shutdown scheduler launches it shortly
 * after the current run finishes if the target timestamp already passed.
 */
function evazar_queue_begin_run_interval($lock_value = '', $is_manual = false) {
    if ($lock_value === '' || get_option(evazar_queue_processing_lock_option_name(), '') !== $lock_value) return [];

    $started_at = time();
    $previous_due = evazar_queue_next_auto_run_at();
    $scheduled_for = (!$is_manual && $previous_due > 0) ? $previous_due : 0;
    $start_lag = $scheduled_for > 0 ? max(0, $started_at - $scheduled_for) : 0;
    $interval_seconds = evazar_queue_random_interval_seconds();
    $minutes = intdiv($interval_seconds, MINUTE_IN_SECONDS);
    $seconds_remainder = $interval_seconds % MINUTE_IN_SECONDS;
    $interval_display = evazar_queue_format_interval_duration($interval_seconds);
    $next_run_at = $started_at + $interval_seconds;
    $run_id = substr(hash('sha256', (string) $lock_value), 0, 12);

    $diagnostics = [
        'run_id' => $run_id,
        'trigger' => $is_manual ? 'manual' : 'automatic',
        'scheduled_for' => $scheduled_for,
        'started_at' => $started_at,
        'start_lag_seconds' => $start_lag,
        // Keep interval_minutes for legacy consumers; interval_seconds is authoritative.
        'interval_minutes' => $minutes,
        'interval_seconds_remainder' => $seconds_remainder,
        'interval_seconds' => $interval_seconds,
        'interval_display' => $interval_display,
        'next_run_at' => $next_run_at,
        'finished_at' => 0,
        'duration_seconds' => 0,
        'status' => 'running',
    ];

    update_option('evazar_queue_next_auto_run_at', $next_run_at, false);
    update_option('evazar_queue_last_random_interval_minutes', $minutes, false); // legacy compatibility
    update_option('evazar_queue_last_random_interval_seconds', $interval_seconds, false);
    update_option('evazar_queue_last_run_started_at', $started_at, false);
    update_option('evazar_queue_last_run_start_lag_seconds', $start_lag, false);
    update_option('evazar_queue_last_run_diagnostics', $diagnostics, false);
    evazar_queue_heartbeat_run_lock($lock_value);

    if (function_exists('evazar_gemini_log_event')) {
        $message = 'اجرای صف آغاز شد؛ فاصله بعدی ' . $interval_display . ' (جمعاً ' . $interval_seconds . ' ثانیه) با دقت یک ثانیه از زمان شروع محاسبه شد.';
        if ($start_lag > 0) $message .= ' تأخیر شروع نسبت به موعد ثبت‌شده: ' . $start_lag . ' ثانیه.';
        evazar_gemini_log_event('queue_run_started', $message, '', 0, 0, [
            'purpose' => 'queue_scheduler',
        ]);
    }

    return $diagnostics;
}

/** Record end time and observed run duration without moving the start-to-start due timestamp. */
function evazar_queue_finalize_auto_interval($lock_value = '') {
    if ($lock_value === '' || get_option(evazar_queue_processing_lock_option_name(), '') !== $lock_value) return;
    $finished_at = time();
    $diagnostics = get_option('evazar_queue_last_run_diagnostics', []);
    if (!is_array($diagnostics)) $diagnostics = [];

    $run_id = substr(hash('sha256', (string) $lock_value), 0, 12);
    if (!empty($diagnostics['run_id']) && !hash_equals((string) $diagnostics['run_id'], $run_id)) return;

    $started_at = absint($diagnostics['started_at'] ?? get_option('evazar_queue_last_run_started_at', 0));
    $duration = $started_at > 0 ? max(0, $finished_at - $started_at) : 0;
    $diagnostics['finished_at'] = $finished_at;
    $diagnostics['duration_seconds'] = $duration;
    $diagnostics['status'] = 'finished';
    update_option('evazar_queue_last_run_diagnostics', $diagnostics, false);
    update_option('evazar_queue_last_run_finished_at', $finished_at, false);
    update_option('evazar_queue_last_run_duration_seconds', $duration, false);

    if (function_exists('evazar_gemini_log_event')) {
        evazar_gemini_log_event(
            'queue_run_finished',
            'اجرای صف پایان یافت؛ مدت اجرا ' . $duration . ' ثانیه، تأخیر شروع ' . absint($diagnostics['start_lag_seconds'] ?? 0) . ' ثانیه.',
            '', 0, 0,
            ['purpose' => 'queue_scheduler']
        );
    }
}

function evazar_queue_clear_followup_cron() {
    $timestamp = wp_next_scheduled('evazar_process_import_queue_followup');
    while ($timestamp) {
        wp_unschedule_event($timestamp, 'evazar_process_import_queue_followup');
        $timestamp = wp_next_scheduled('evazar_process_import_queue_followup');
    }
}

/** Persist the pause state and control only the product-import queue's follow-up scheduling. */
function evazar_queue_set_manual_paused($paused) {
    $paused = (bool) $paused;
    update_option('evazar_import_queue_manual_paused', $paused ? 'yes' : 'no', false);

    if ($paused) {
        evazar_queue_clear_followup_cron();
        return true;
    }

    // A deliberate resume starts soon; the regular recurring Cron remains the safety net.
    if (function_exists('evazar_queue_ensure_cron')) {
        evazar_queue_ensure_cron();
    }
    $resume_at = time() + 5;
    update_option('evazar_queue_next_auto_run_at', $resume_at, false);
    evazar_queue_schedule_followup_at($resume_at);
    return true;
}

/** Keep no more than one follow-up at the requested not-before timestamp. */
function evazar_queue_schedule_followup_at($run_at) {
    if (!function_exists('wp_schedule_single_event')) {
        return false;
    }
    $run_at = max(time() + 5, (int) $run_at);
    $existing = wp_next_scheduled('evazar_process_import_queue_followup');
    if ($existing && abs((int) $existing - $run_at) <= 5) {
        return true;
    }
    evazar_queue_clear_followup_cron();
    return (bool) wp_schedule_single_event($run_at, 'evazar_process_import_queue_followup');
}

function evazar_queue_schedule_cron() {
    if (!wp_next_scheduled('evazar_process_import_queue')) {
        $existing_next = evazar_queue_next_auto_run_at();
        if ($existing_next > time()) {
            $first_run = $existing_next;
        } else {
            $interval_seconds = evazar_queue_random_interval_seconds();
            $first_run = time() + $interval_seconds;
            update_option('evazar_queue_next_auto_run_at', $first_run, false);
            update_option('evazar_queue_last_random_interval_minutes', intdiv($interval_seconds, MINUTE_IN_SECONDS), false); // legacy compatibility
            update_option('evazar_queue_last_random_interval_seconds', $interval_seconds, false);
        }
        wp_schedule_event($first_run, 'evazar_queue_custom_schedule', 'evazar_process_import_queue');
    }
}

function evazar_queue_clear_cron() {
    $timestamp = wp_next_scheduled('evazar_process_import_queue');
    while ($timestamp) {
        wp_unschedule_event($timestamp, 'evazar_process_import_queue');
        $timestamp = wp_next_scheduled('evazar_process_import_queue');
    }
}

function evazar_queue_reschedule_cron() {
    evazar_queue_clear_cron();
    evazar_queue_clear_followup_cron();
    $interval_seconds = evazar_queue_random_interval_seconds();
    $next_run = time() + $interval_seconds;
    update_option('evazar_queue_next_auto_run_at', $next_run, false);
    update_option('evazar_queue_last_random_interval_minutes', intdiv($interval_seconds, MINUTE_IN_SECONDS), false); // legacy compatibility
    update_option('evazar_queue_last_random_interval_seconds', $interval_seconds, false);
    wp_schedule_event($next_run, 'evazar_queue_custom_schedule', 'evazar_process_import_queue');
    if (wp_next_scheduled('evazar_process_import_queue')) {
        update_option('evazar_queue_cron_schedule_version', 4, false);
    }
}

function evazar_queue_ensure_cron() {
    // Rebuild legacy schedules once to activate second-granularity randomized intervals.
    if ((int) get_option('evazar_queue_cron_schedule_version', 0) < 4) {
        evazar_queue_reschedule_cron();
        return;
    }
    if (!wp_next_scheduled('evazar_process_import_queue')) {
        evazar_queue_schedule_cron();
    }
}
add_action('admin_init', 'evazar_queue_ensure_cron');

/**
 * Schedule one follow-up when eligible work remains, respecting the randomized
 * completion-to-start timestamp. The recurring queue cron is a safety net only.
 */
function evazar_queue_maybe_schedule_followup() {
    global $wpdb;

    if (evazar_queue_is_manually_paused()) {
        evazar_queue_clear_followup_cron();
        return;
    }

    // The queue intentionally does not claim automatic product rows outside Gemini-only
    // batch mode. Do not schedule follow-ups for a queue that this policy pauses.
    if (get_option('evazar_ai_enabled', '') === 'yes' && (string) get_option('evazar_ai_engine_mode', '') !== 'gemini_only') {
        return;
    }

    if (!function_exists('wp_schedule_single_event')) {
        return;
    }

    $table_name = $wpdb->prefix . 'evazar_import_queue';
    $table_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name)));
    if ($table_exists !== $table_name) {
        return;
    }

    // Do not create a rapid retry loop while Gemini is paused by quota, rate limit,
    // worker concurrency, or another global pause condition.
    if (!function_exists('evazar_should_pause_queue_for_gemini_quota')) {
        $importer = plugin_dir_path(__FILE__) . 'importer.php';
        if (is_file($importer)) require_once $importer;
    }
    if (function_exists('evazar_should_pause_queue_for_gemini_quota') && evazar_should_pause_queue_for_gemini_quota()) {
        return;
    }

    // An administrator may opt in to periodic retries for source-category quarantine.
    // Promote only those exact rows whose configured retry time has elapsed.
    evazar_queue_promote_due_category_quarantine();

    // Refill freed slots from the durable intake queue before scheduling the next run.
    if (function_exists('evazar_queue_promote_capacity_waiting')) {
        evazar_queue_promote_capacity_waiting();
    }

    $now_mysql = current_time('mysql');
    $ready = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM `$table_name` WHERE status='pending' AND (next_attempt_at IS NULL OR next_attempt_at <= %s)",
        $now_mysql
    ));

    if ($ready > 0) {
        // Wake promptly for eligible rows; the shared randomized not-before timestamp
        // below still controls when the next actual batch may start.
        $run_at = time() + 15;
    } else {
        // If pending rows are deliberately deferred, wake the queue near their earliest
        // due time instead of making them wait for the recurring Cron event.
        $quarantine_retry_days = evazar_queue_category_quarantine_auto_retry_days();
        if ($quarantine_retry_days > 0) {
            $next_due = $wpdb->get_var($wpdb->prepare(
                "SELECT MIN(next_attempt_at) FROM `$table_name` WHERE ((status='pending' AND next_attempt_at IS NOT NULL AND next_attempt_at > %s) OR (status='quarantined' AND error_code='SOURCE_CATEGORY_PATH_MISSING' AND next_attempt_at IS NOT NULL AND next_attempt_at > %s))",
                $now_mysql, $now_mysql
            ));
        } else {
            $next_due = $wpdb->get_var($wpdb->prepare(
                "SELECT MIN(next_attempt_at) FROM `$table_name` WHERE status='pending' AND next_attempt_at IS NOT NULL AND next_attempt_at > %s",
                $now_mysql
            ));
        }
        if (empty($next_due)) {
            $intake_table = evazar_queue_capacity_intake_table_name();
            $waiting_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$intake_table`");
            $capacity = function_exists('evazar_queue_current_processing_capacity') ? evazar_queue_current_processing_capacity() : 0;
            $active_count = evazar_queue_active_item_count();
            if ($waiting_count > 0 && $capacity > $active_count) {
                // Capacity exists but the bounded FIFO scan may have cleaned stale duplicates.
                // Recheck in a separate request so valid staged rows remain eligible; the shared
                // interval gate below prevents an early automatic batch.
                $run_at = time() + 15;
            } else {
                return;
            }
        } else {
            // MySQL DATETIME values are in the WordPress site timezone. Parse both
            // with that timezone explicitly; PHP's default timezone may be different.
            try {
                $site_tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
                $now_dt = new DateTimeImmutable($now_mysql, $site_tz);
                $due_dt = new DateTimeImmutable((string) $next_due, $site_tz);
                $delay = $due_dt->getTimestamp() - $now_dt->getTimestamp();
            } catch (Exception $e) {
                return;
            }
            $run_at = time() + max(15, $delay);
        }
    }

    // Every automatic batch, including a retry continuation, respects the randomized
    // completion-to-start interval. Item-level next_attempt_at and Gemini quota gates
    // still delay work further when required; no automatic retry bypasses this cadence.
    $not_before = evazar_queue_next_auto_run_at();
    if ($not_before > 0) {
        $run_at = max((int) $run_at, $not_before);
    }
    evazar_queue_schedule_followup_at($run_at);
}

add_action('evazar_process_import_queue_followup', 'evazar_cron_worker_logic');

// ==========================================
// 3. اندپوینت REST API (ثبت در صف از سمت هاروستر)
// ==========================================
add_action('rest_api_init', function () {
    register_rest_route('evazar/v1', '/queue-ingest', array(
        'methods' => 'POST',
        'callback' => 'evazar_rest_queue_ingest',
        'permission_callback' => 'evazar_queue_rest_permission',
    ));

    register_rest_route('evazar/v1', '/existing-dkps', array(
        'methods' => 'GET',
        'callback' => 'evazar_rest_existing_dkps',
        'permission_callback' => 'evazar_queue_rest_permission',
    ));

    // Signed internal endpoint: one product-AI sub-batch per parallel request.
    register_rest_route('evazar/v1', '/internal-product-ai-batch', array(
        'methods' => 'POST',
        'callback' => 'evazar_queue_internal_product_ai_batch',
        'permission_callback' => 'evazar_queue_parallel_batch_permission',
    ));
});


function evazar_queue_rest_permission(WP_REST_Request $request) {
    $token = trim((string) get_option('evazar_cf_worker_token', ''));
    if ($token === '') {
        return new WP_Error('evazar_queue_auth_not_configured', 'توکن داخلی Worker در تنظیمات ایوازار تعریف نشده است.', ['status' => 503]);
    }
    $received = trim((string) $request->get_header('x-evazar-internal-token'));
    if ($received === '' || !hash_equals($token, $received)) {
        return new WP_Error('evazar_queue_forbidden', 'دسترسی غیرمجاز.', ['status' => 403]);
    }
    return true;
}


/** Derive a private signing secret for authenticated loopback fan-out; never expose it in settings or logs. */
function evazar_queue_parallel_batch_signing_secret() {
    $internal_token = trim((string) get_option('evazar_cf_worker_token', ''));
    $wp_auth_salt = function_exists('wp_salt') ? (string) wp_salt('auth') : '';
    if ($internal_token === '' || $wp_auth_salt === '') return '';
    return hash_hmac('sha256', 'evazar-parallel-product-batch-v1|' . $internal_token, $wp_auth_salt);
}

/** Validate HMAC-signed internal parallel requests and reject replayed nonces atomically. */
function evazar_queue_parallel_batch_permission(WP_REST_Request $request) {
    global $wpdb;
    $raw_body = (string) $request->get_body();
    if ($raw_body === '' || strlen($raw_body) > 4194304) {
        return new WP_Error('evazar_parallel_payload_invalid', 'بدنه درخواست داخلی خالی یا بیش از حد بزرگ است.', ['status' => 413]);
    }
    $timestamp = trim((string) $request->get_header('x-evazar-parallel-timestamp'));
    $nonce = strtolower(trim((string) $request->get_header('x-evazar-parallel-nonce')));
    $signature = strtolower(trim((string) $request->get_header('x-evazar-parallel-signature')));
    if (!ctype_digit($timestamp) || abs(time() - (int) $timestamp) > 180 || !preg_match('/^[a-f0-9]{32}$/', $nonce) || !preg_match('/^[a-f0-9]{64}$/', $signature)) {
        return new WP_Error('evazar_parallel_signature_invalid', 'امضای درخواست داخلی معتبر یا تازه نیست.', ['status' => 403]);
    }
    $secret = evazar_queue_parallel_batch_signing_secret();
    if ($secret === '') {
        return new WP_Error('evazar_parallel_auth_not_configured', 'توکن داخلی و کلید امضای WordPress برای پردازش موازی تنظیم نشده‌اند.', ['status' => 503]);
    }
    $expected = hash_hmac('sha256', $timestamp . "\n" . $nonce . "\n" . $raw_body, $secret);
    if (!hash_equals($expected, $signature)) {
        return new WP_Error('evazar_parallel_signature_invalid', 'امضای درخواست داخلی صحیح نیست.', ['status' => 403]);
    }

    // The nonce options are non-autoloaded and deleted after five minutes to keep storage bounded.
    $nonce_prefix = 'evz_parallel_nonce_';
    $wpdb->query($wpdb->prepare(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND CAST(option_value AS UNSIGNED) < %d",
        $wpdb->esc_like($nonce_prefix) . '%', time() - 300
    ));
    if (!add_option($nonce_prefix . $nonce, (string) ((int) $timestamp), '', 'no')) {
        return new WP_Error('evazar_parallel_replay_rejected', 'درخواست داخلی تکراری تشخیص داده شد و اجرا نشد.', ['status' => 409]);
    }
    return true;
}

/** Process one signed sub-batch in a separate WordPress request; queue rows are finalized only by the parent. */
function evazar_queue_internal_product_ai_batch(WP_REST_Request $request) {
    // A parallel child request may have been queued just before the admin pause.
    // Check again here so it cannot start a fresh Gemini call after the pause is visible.
    if (evazar_queue_is_manually_paused()) {
        return new WP_REST_Response(['success' => false, 'error' => [
            'code' => 'evazar_queue_manually_paused',
            'message' => 'صف واردات به درخواست مدیر متوقف است؛ این دسته پیش از ارسال به Gemini متوقف شد.'
        ]], 200);
    }

    $payload = json_decode((string) $request->get_body(), true);
    $entry_count = (is_array($payload) && is_array($payload['entries'] ?? null)) ? count($payload['entries']) : 0;
    $single_wire = ($entry_count === 1 && is_array($payload['entries'][0] ?? null)) ? $payload['entries'][0] : [];
    $single_item = is_array($single_wire['item'] ?? null) ? $single_wire['item'] : [];
    $single_error_code = strtoupper(sanitize_key((string) ($single_item['error_code'] ?? '')));
    $single_next_attempt = trim((string) ($single_item['next_attempt_at'] ?? ''));
    $single_due = ($single_next_attempt === '' || $single_next_attempt <= current_time('mysql'));
    $singleton_retry_allowed = ($entry_count === 1 && $single_error_code === 'WAITING_FOR_BATCH_PARTNER' && $single_due);
    if (!is_array($payload) || empty($payload['entries']) || !is_array($payload['entries']) || $entry_count < 1 || $entry_count > 50 || ($entry_count === 1 && !$singleton_retry_allowed)) {
        return new WP_REST_Response(['success' => false, 'error' => ['code' => 'EVZ_PARALLEL_PAYLOAD_INVALID', 'message' => 'دسته داخلی باید ۲ تا ۵۰ محصول داشته باشد؛ فقط محصولی که قبلاً برای شریک دسته‌ای مکث کرده و اکنون موعدش رسیده، می‌تواند به‌عنوان تلاش مجدد تکی پردازش شود.']], 400);
    }
    if (!function_exists('evazar_generate_product_batch_ai_responses')) {
        require_once plugin_dir_path(__FILE__) . 'importer.php';
    }
    if (!function_exists('evazar_generate_product_batch_ai_responses')) {
        return new WP_REST_Response(['success' => false, 'error' => ['code' => 'EVZ_PARALLEL_HANDLER_MISSING', 'message' => 'تابع پردازش دسته‌ای بارگذاری نشد.']], 503);
    }

    $configured_workers = function_exists('evazar_get_gemini_worker_urls') ? evazar_get_gemini_worker_urls() : [];
    $assigned_worker = isset($payload['assigned_worker_url']) ? rtrim(esc_url_raw((string) $payload['assigned_worker_url']), '/') : '';
    $normalized_workers = array_map(function($url) { return rtrim((string) $url, '/'); }, (array) $configured_workers);
    if ($assigned_worker === '' || !in_array($assigned_worker, $normalized_workers, true)) {
        return new WP_REST_Response(['success' => false, 'error' => ['code' => 'EVZ_PARALLEL_WORKER_INVALID', 'message' => 'Worker اختصاص‌یافته در فهرست معتبر Gemini نیست.']], 400);
    }

    $entries = [];
    $seen_dkps = [];
    foreach ($payload['entries'] as $wire_entry) {
        if (!is_array($wire_entry) || !is_array($wire_entry['item'] ?? null) || !is_array($wire_entry['checkpoint'] ?? null)) {
            return new WP_REST_Response(['success' => false, 'error' => ['code' => 'EVZ_PARALLEL_ENTRY_INVALID', 'message' => 'یکی از ورودی‌های دسته داخلی معتبر نیست.']], 400);
        }
        $item_id = absint($wire_entry['item']['id'] ?? 0);
        $dkp = preg_replace('/[^0-9]/', '', (string) ($wire_entry['checkpoint']['dkp'] ?? $wire_entry['item']['dkp'] ?? ''));
        $checkpoint = $wire_entry['checkpoint'];
        $context = is_array($checkpoint['context'] ?? null) ? $checkpoint['context'] : null;
        if ($item_id < 1 || $dkp === '' || isset($seen_dkps[$dkp]) || !is_array($context) || empty($context['system_prompt']) || empty($context['user_msg'])) {
            return new WP_REST_Response(['success' => false, 'error' => ['code' => 'EVZ_PARALLEL_ENTRY_INVALID', 'message' => 'شناسه DKP تکراری است یا زمینه بازنویسی ناقص است.']], 400);
        }
        $seen_dkps[$dkp] = true;
        $checkpoint['__evazar_ai_batch_checkpoint'] = true;
        $checkpoint['dkp'] = $dkp;
        $checkpoint['context'] = $context;
        $checkpoint['expected_matching_ids'] = is_array($checkpoint['expected_matching_ids'] ?? null) ? $checkpoint['expected_matching_ids'] : [];
        $entries[] = [
            'item' => (object) [
                'id' => $item_id,
                'dkp' => $dkp,
                'url' => esc_url_raw((string) ($wire_entry['item']['url'] ?? '')),
                // Must survive the internal request or every retry hashes as generation 0.
                'retries' => max(0, absint($wire_entry['item']['retries'] ?? 0)),
                'error_code' => strtoupper(sanitize_key((string) ($wire_entry['item']['error_code'] ?? ''))),
                'next_attempt_at' => sanitize_text_field((string) ($wire_entry['item']['next_attempt_at'] ?? '')),
            ],
            'checkpoint' => $checkpoint,
        ];
    }
    if (empty($entries)) {
        return new WP_REST_Response(['success' => false, 'error' => ['code' => 'EVZ_PARALLEL_EMPTY', 'message' => 'هیچ محصول معتبری در دسته داخلی وجود ندارد.']], 400);
    }

    $timeout = min(180, max(60, (int) get_option('evazar_ai_timeout', 60) + 30));
    if (function_exists('set_time_limit')) @set_time_limit($timeout + 15);
    $responses = evazar_generate_product_batch_ai_responses($entries, $assigned_worker);
    if (is_wp_error($responses)) {
        $code = $responses->get_error_code() ?: 'AI_BATCH_FAILED';
        $data = $responses->get_error_data($code);
        $safe_data = [];
        if (is_array($data)) {
            foreach (['resume_at', 'request_id', 'retry_after', 'http_code'] as $key) {
                if (isset($data[$key]) && is_scalar($data[$key])) $safe_data[$key] = $data[$key];
            }
        }
        return new WP_REST_Response(['success' => false, 'error' => [
            'code' => $code,
            'message' => $responses->get_error_message(),
            'data' => $safe_data,
        ]], 200);
    }

    $wire_responses = [];
    foreach ((array) $responses as $dkp => $value) {
        $dkp = preg_replace('/[^0-9]/', '', (string) $dkp);
        if ($dkp === '') continue;
        if (is_wp_error($value)) {
            $code = $value->get_error_code() ?: 'AI_BATCH_ITEM_FAILED';
            $data = $value->get_error_data($code);
            $safe_data = [];
            if (is_array($data)) {
                foreach (['resume_at', 'request_id', 'retry_after', 'http_code'] as $key) {
                    if (isset($data[$key]) && is_scalar($data[$key])) $safe_data[$key] = $data[$key];
                }
            }
            $wire_responses[$dkp] = ['__evazar_error' => true, 'code' => $code, 'message' => $value->get_error_message(), 'data' => $safe_data];
        } else {
            $wire_responses[$dkp] = $value;
        }
    }
    return new WP_REST_Response(['success' => true, 'responses' => $wire_responses], 200);
}

function evazar_rest_existing_dkps() {
    global $wpdb;

    evazar_queue_ensure_table();
    $table_name = $wpdb->prefix . 'evazar_import_queue';

    $skus = $wpdb->get_col(
        "SELECT DISTINCT meta_value\n         FROM {$wpdb->postmeta}\n         WHERE meta_key IN ('_sku', '_evazar_sku', '_evazar_dk_id')\n           AND meta_value != ''"
    );

    $existing_dkps = [];
    foreach ($skus ?: [] as $sku) {
        $dkp = preg_replace('/[^0-9]/', '', (string) $sku);
        if ($dkp !== '') {
            $existing_dkps[] = $dkp;
        }
    }
    $existing_dkps = array_values(array_unique($existing_dkps));

    $pending_dkps = $wpdb->get_col("SELECT dkp FROM `$table_name` WHERE dkp != '' AND status = 'pending'");
    $processing_dkps = $wpdb->get_col("SELECT dkp FROM `$table_name` WHERE dkp != '' AND status = 'processing'");
    $completed_dkps = $wpdb->get_col("SELECT dkp FROM `$table_name` WHERE dkp != '' AND status = 'completed'");
    $failed_dkps = $wpdb->get_col("SELECT dkp FROM `$table_name` WHERE dkp != '' AND status = 'failed'");
    // Quarantined and explicitly excluded DKPs are durable queue decisions. Keep them
    // reserved from the Harvester so it does not silently re-ingest them every cycle.
    $quarantined_dkps = $wpdb->get_col("SELECT dkp FROM `$table_name` WHERE dkp != '' AND status = 'quarantined'");
    $excluded_dkps = $wpdb->get_col("SELECT dkp FROM `$table_name` WHERE dkp != '' AND status = 'excluded'");
    $intake_table = evazar_queue_capacity_intake_table_name();
    $capacity_waiting_dkps = $wpdb->get_col("SELECT dkp FROM `$intake_table` WHERE dkp != ''");

    $pending_dkps = array_values(array_unique(array_map('strval', $pending_dkps ?: [])));
    $processing_dkps = array_values(array_unique(array_map('strval', $processing_dkps ?: [])));
    $completed_dkps = array_values(array_unique(array_map('strval', $completed_dkps ?: [])));
    $failed_dkps = array_values(array_unique(array_map('strval', $failed_dkps ?: [])));
    $quarantined_dkps = array_values(array_unique(array_map('strval', $quarantined_dkps ?: [])));
    $excluded_dkps = array_values(array_unique(array_map('strval', $excluded_dkps ?: [])));
    $capacity_waiting_dkps = array_values(array_unique(array_map('strval', $capacity_waiting_dkps ?: [])));

    // For the legacy Harvester endpoint, both quarantine and administrative exclusion
    // reserve a DKP. Only failed rows remain eligible for Harvester-driven retry.
    $reserved_dkps = array_values(array_unique(array_merge(
        $existing_dkps,
        $pending_dkps,
        $processing_dkps,
        $completed_dkps,
        $quarantined_dkps,
        $excluded_dkps,
        $capacity_waiting_dkps
    )));

    // Quarantine and excluded items are held, not actively queued.
    $queued_active = array_values(array_unique(array_merge($pending_dkps, $processing_dkps, $capacity_waiting_dkps)));

    return new WP_REST_Response(array(
        'success' => true,

        // نسخه قدیمی API؛ هاروستر 1.6.0 همچنان از همین فیلد استفاده می‌کند.
        'dkps' => $reserved_dkps,

        // داده تفکیک‌شده برای مانیتورینگ و نسخه‌های جدید هاروستر.
        'existing_dkps' => $existing_dkps,
        'queued_dkps' => $queued_active,
        'pending_dkps' => $pending_dkps,
        'processing_dkps' => $processing_dkps,
        'completed_dkps' => $completed_dkps,
        'failed_dkps' => $failed_dkps,
        'quarantined_dkps' => $quarantined_dkps,
        'excluded_dkps' => $excluded_dkps,
        'capacity_waiting_dkps' => $capacity_waiting_dkps,

        'counts' => array(
            'existing' => count($existing_dkps),
            'queued' => count($queued_active),
            'pending' => count($pending_dkps),
            'processing' => count($processing_dkps),
            'completed' => count($completed_dkps),
            'failed' => count($failed_dkps),
            'quarantined' => count($quarantined_dkps),
            'excluded' => count($excluded_dkps),
            'capacity_waiting' => count($capacity_waiting_dkps),
            'reserved' => count($reserved_dkps),
        ),
    ), 200);
}

function evazar_rest_queue_ingest(WP_REST_Request $request) {
    global $wpdb;
    evazar_queue_ensure_table();
    if (!evazar_queue_ensure_capacity_intake_table()) {
        return new WP_REST_Response(['success' => false, 'message' => 'جدول نگهداری موقت محصولات صف قابل آماده‌سازی نیست؛ هیچ آیتمی پذیرفته نشد.'], 503);
    }
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    $intake_table = evazar_queue_capacity_intake_table_name();

    $params = $request->get_json_params();
    if (empty($params) || empty($params['items']) || !is_array($params['items'])) {
        return new WP_REST_Response(['success' => false, 'message' => 'دیتا نامعتبر است. ساختار باید دارای items باشد.'], 400);
    }

    $items = array_slice($params['items'], 0, 100);
    $normalized_items = [];
    foreach ($items as $item) {
        $dkp = isset($item['dkp']) ? preg_replace('/[^0-9]/', '', (string) $item['dkp']) : '';
        $url = isset($item['url']) ? esc_url_raw($item['url']) : '';
        if ($dkp === '' || strlen($dkp) > 20) continue;
        if ($url !== '' && !preg_match('~^https?://([^/]+\.)?digikala\.com(/|$)~i', $url)) $url = '';
        // Numeric DKP key de-duplicates items inside the same Harvester request.
        $normalized_items[$dkp] = ['dkp' => $dkp, 'url' => $url];
    }

    if (empty($normalized_items)) {
        return new WP_REST_Response([
            'success' => true, 'inserted' => 0, 'skipped' => 0, 'requeued' => 0,
            'capacity_deferred' => 0, 'errors' => 0,
            'message' => 'هیچ DKP معتبر و جدیدی در درخواست وجود نداشت.'
        ], 200);
    }

    $inserted = 0;
    $skipped = 0;
    $requeued = 0;
    $capacity_deferred = 0;
    $errors = 0;
    $lock_acquired = evazar_queue_capacity_lock_acquire(3);

    // If another ingest/promotion currently owns the admission lock, stage the whole
    // payload durably rather than returning success while dropping products or overfilling the active queue.
    if (!$lock_acquired) {
        foreach ($normalized_items as $item) {
            $stored = evazar_queue_store_capacity_waiting($item['dkp'], $item['url']);
            if ($stored === 'inserted') $capacity_deferred++;
            elseif ($stored === 'exists') $skipped++;
            else $errors++;
        }
        $waiting_now = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$intake_table`");
        delete_transient('evazar_queue_dashboard_stats_v2');
        return new WP_REST_Response([
            'success' => ($errors === 0),
            'inserted' => 0,
            'skipped' => $skipped,
            'requeued' => 0,
            'capacity_deferred' => $capacity_deferred,
            'errors' => $errors,
            'active_capacity' => evazar_queue_current_processing_capacity(),
            'active_queue' => evazar_queue_active_item_count(),
            'capacity_waiting' => $waiting_now,
            'message' => $errors > 0
                ? 'قفل تخصیص صف در دسترس نبود و بخشی از موارد در صف نگهداری امن ثبت نشدند؛ ارسال مجدد لازم است.'
                : 'درخواست هم‌زمان دیگری در حال تخصیص صف بود؛ آیتم‌های دریافت‌شده بدون حذف در صف انتظار ظرفیت نگهداری شدند.'
        ], $errors > 0 ? 500 : 200);
    }

    try {
        // Older held items always receive newly free capacity before fresh arrivals.
        evazar_queue_promote_capacity_waiting_locked();

        $dkps = array_values(array_keys($normalized_items));
        $placeholders = implode(',', array_fill(0, count($dkps), '%s'));

        $product_rows = $wpdb->get_col(call_user_func_array([$wpdb, 'prepare'], array_merge([
            "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key IN ('_sku', '_evazar_sku', '_evazar_dk_id') AND meta_value IN ($placeholders)"
        ], $dkps)));
        $existing_map = [];
        foreach ((array) $product_rows as $sku) {
            $normalized = preg_replace('/[^0-9]/', '', (string) $sku);
            if ($normalized !== '') $existing_map[$normalized] = true;
        }

        $queue_rows = $wpdb->get_results(call_user_func_array([$wpdb, 'prepare'], array_merge([
            "SELECT id, dkp, url, status FROM `$table_name` WHERE dkp IN ($placeholders) ORDER BY id ASC"
        ], $dkps)));
        $queue_map = [];
        foreach ((array) $queue_rows as $row) $queue_map[(string) $row->dkp] = $row;

        $intake_rows = $wpdb->get_results(call_user_func_array([$wpdb, 'prepare'], array_merge([
            "SELECT id, dkp, mode FROM `$intake_table` WHERE dkp IN ($placeholders)"
        ], $dkps)));
        $intake_map = [];
        $intake_mode_map = [];
        foreach ((array) $intake_rows as $row) {
            $normalized_intake_dkp = preg_replace('/[^0-9]/', '', (string) $row->dkp);
            if ($normalized_intake_dkp === '') continue;
            $intake_map[$normalized_intake_dkp] = (int) $row->id;
            $intake_mode_map[$normalized_intake_dkp] = in_array((string) ($row->mode ?? 'import'), ['import', 'retry', 'rewrite'], true)
                ? (string) ($row->mode ?? 'import')
                : 'import';
        }

        $capacity_limit = evazar_queue_current_processing_capacity();
        $active_before = evazar_queue_active_item_count();
        $available_slots = max(0, $capacity_limit - $active_before);

        foreach ($normalized_items as $dkp => $item) {
            if (isset($existing_map[$dkp])) {
                // A normal import duplicate can be discarded from intake, but an explicit
                // retry/rewrite intent must survive even when the product already exists.
                // Admin actions intentionally reprocess imported products after capacity opens.
                if (isset($intake_map[$dkp]) && !in_array(($intake_mode_map[$dkp] ?? 'import'), ['retry', 'rewrite'], true)) {
                    $wpdb->delete($intake_table, ['id' => $intake_map[$dkp]], ['%d']);
                }
                $skipped++;
                continue;
            }

            if (isset($queue_map[$dkp])) {
                $row = $queue_map[$dkp];
                $status = (string) $row->status;
                if (in_array($status, ['pending', 'processing'], true)) {
                    if (isset($intake_map[$dkp])) $wpdb->delete($intake_table, ['id' => $intake_map[$dkp]], ['%d']);
                    $skipped++;
                    continue;
                }
                if (isset($intake_map[$dkp])) {
                    // Already accepted into the durable holding queue; do not repeatedly requeue it.
                    $skipped++;
                    continue;
                }
                if (in_array($status, ['failed', 'completed'], true)) {
                    if ($available_slots > 0) {
                        $source_url = trim((string) $item['url']) !== '' ? $item['url'] : (string) $row->url;
                        $updated = $wpdb->update($table_name, [
                            'url' => $source_url,
                            'status' => 'pending', 'retries' => 0, 'error_code' => '', 'error_log' => '',
                            'last_error_at' => null, 'claim_token' => '', 'claimed_at' => null, 'next_attempt_at' => null
                        ], ['id' => (int) $row->id, 'status' => $status]);
                        if ($updated === 1) {
                            $requeued++;
                            $available_slots--;
                        } else {
                            $fresh = $wpdb->get_row($wpdb->prepare("SELECT status FROM `$table_name` WHERE id = %d", (int) $row->id));
                            if ($fresh && in_array((string) $fresh->status, ['pending', 'processing'], true)) $skipped++;
                            else {
                                $stored = evazar_queue_store_capacity_waiting($dkp, $source_url, 'retry');
                                if ($stored === 'inserted') $capacity_deferred++;
                                elseif ($stored === 'exists') $skipped++;
                                else $errors++;
                            }
                        }
                    } else {
                        $stored = evazar_queue_store_capacity_waiting($dkp, $item['url'], 'retry');
                        if ($stored === 'inserted') $capacity_deferred++;
                        elseif ($stored === 'exists') $skipped++;
                        else $errors++;
                    }
                    continue;
                }
                $skipped++;
                continue;
            }

            if (isset($intake_map[$dkp])) {
                $skipped++;
                continue;
            }

            if ($available_slots > 0) {
                $res = $wpdb->insert($table_name, [
                    'url' => $item['url'], 'dkp' => $item['dkp'], 'status' => 'pending', 'retries' => 0,
                    'next_attempt_at' => null
                ], ['%s', '%s', '%s', '%d', '%s']);
                if ($res !== false) {
                    $inserted++;
                    $available_slots--;
                } else {
                    $exists_after = $wpdb->get_var($wpdb->prepare("SELECT id FROM `$table_name` WHERE dkp = %s LIMIT 1", $dkp));
                    if ($exists_after) $skipped++;
                    else $errors++;
                }
            } else {
                $stored = evazar_queue_store_capacity_waiting($dkp, $item['url']);
                if ($stored === 'inserted') $capacity_deferred++;
                elseif ($stored === 'exists') $skipped++;
                else $errors++;
            }
        }
    } finally {
        evazar_queue_capacity_lock_release();
    }

    $active_after = evazar_queue_active_item_count();
    $waiting_now = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$intake_table`");
    delete_transient('evazar_queue_dashboard_stats_v2');
    if ($capacity_deferred > 0 && function_exists('evazar_gemini_log_event')) {
        evazar_gemini_log_event(
            'queue_capacity_deferred',
            $capacity_deferred . ' محصول به‌علت پر بودن ظرفیت فعال، در صف نگهداری امن قرار گرفتند؛ ظرفیت فعال=' . $capacity_limit . '، آیتم فعال=' . $active_before . '، آیتم فعال پس از دریافت=' . $active_after . '.',
            '', 0, 0,
            ['purpose' => 'adaptive_queue_admission', 'batch_size' => $capacity_deferred]
        );
    }

    return new WP_REST_Response([
        'success' => ($errors === 0),
        'inserted' => $inserted,
        'skipped' => $skipped,
        'requeued' => $requeued,
        'capacity_deferred' => $capacity_deferred,
        'errors' => $errors,
        'active_capacity' => $capacity_limit,
        'active_before' => $active_before,
        'active_queue' => $active_after,
        'capacity_waiting' => $waiting_now,
        'message' => $errors > 0
            ? 'برخی آیتم‌ها به علت خطای دیتابیس ثبت نشدند؛ موارد پذیرفته‌شده یا در صف فعال یا در صف انتظار ظرفیت محفوظ‌اند.'
            : ($capacity_deferred > 0
                ? 'ظرفیت صف فعال تکمیل است؛ آیتم‌های اضافه بدون حذف در صف انتظار ظرفیت ذخیره شدند و با آزادشدن ظرفیت منتقل می‌شوند.'
                : 'درخواست با موفقیت پردازش شد.')
    ], $errors > 0 ? 500 : 200);
}

/** Whether queue-time product AI batching is explicitly enabled and supported. */
function evazar_queue_product_batch_enabled() {
    // Gemini-only automatic product work is always collected and sent in batches.
    // The legacy option is intentionally not consulted: disabling it must never reopen
    // the old one-product automatic Gemini path.
    return get_option('evazar_ai_enabled', '') === 'yes'
        && get_option('evazar_ai_engine_mode', '') === 'gemini_only'
        && function_exists('evazar_generate_product_batch_ai_responses');
}

/** Partition normal work into batches; only a previously deferred, due tail item may run alone. */
function evazar_queue_partition_product_batches($entries, $max_size) {
    $entries = array_values((array) $entries);
    $max_size = max(2, min(50, absint($max_size)));
    if (count($entries) < 2) {
        $entry = $entries[0] ?? null;
        $item = is_array($entry) ? ($entry['item'] ?? null) : null;
        $waiting_at = is_object($item) ? trim((string) ($item->next_attempt_at ?? '')) : '';
        $due_now = ($waiting_at === '' || $waiting_at <= current_time('mysql'));
        if (is_object($item) && (string) ($item->error_code ?? '') === 'WAITING_FOR_BATCH_PARTNER' && $due_now) {
            return ['chunks' => [$entries], 'unpaired' => []];
        }
        return ['chunks' => [], 'unpaired' => $entries];
    }

    $chunks = array_chunk($entries, $max_size);
    $unpaired = [];
    $last_index = count($chunks) - 1;
    if ($last_index >= 1 && count($chunks[$last_index]) === 1) {
        $previous_index = $last_index - 1;
        // Rebalance e.g. 10+1 into 9+2, provided the previous batch remains >=2.
        if (count($chunks[$previous_index]) > 2) {
            $carry = array_pop($chunks[$previous_index]);
            $last = array_pop($chunks[$last_index]);
            $chunks[$last_index] = [$carry, $last];
        } else {
            $unpaired = [array_pop($chunks[$last_index])];
            if (empty($chunks[$last_index])) array_pop($chunks);
        }
    }

    $chunks = array_values(array_filter($chunks, function($chunk) { return count($chunk) >= 2; }));
    return ['chunks' => $chunks, 'unpaired' => $unpaired];
}

/** Return singleton queue items to pending without an AI call, until they can join another batch. */
function evazar_queue_defer_batch_partner_entries($entries, $claim_token) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    $interval = evazar_queue_interval_minutes();
    $resume_at = time() + max(60, min(900, $interval * 60));
    $resume_mysql = evazar_queue_mysql_timestamp($resume_at);
    $deferred = 0;
    $dkps = [];

    foreach ((array) $entries as $entry) {
        $item = $entry['item'] ?? null;
        if (!$item || empty($item->id)) continue;
        $dkp = preg_replace('/[^0-9]/', '', (string) ($item->dkp ?? ($entry['checkpoint']['dkp'] ?? '')));
        if ($dkp !== '') $dkps[] = $dkp;
        $updated = $wpdb->update($table_name, [
            'status' => 'pending',
            'error_code' => 'WAITING_FOR_BATCH_PARTNER',
            'error_log' => 'محصول برای تشکیل دسته مکث کرد؛ اگر شریک آماده نشود، پس از پایان مکث به‌عنوان تلاش مجدد کنترل‌شده پردازش می‌شود.',
            'last_error_at' => current_time('mysql'),
            'claim_token' => '',
            'claimed_at' => null,
            'next_attempt_at' => $resume_mysql,
        ], ['id' => (int) $item->id, 'claim_token' => (string) $claim_token]);
        if ($updated !== false && $updated > 0) $deferred++;
    }

    if ($deferred && function_exists('evazar_gemini_log_event')) {
        evazar_gemini_log_event(
            'batch_waiting_for_partner',
            'محصول(ها) ابتدا برای همراه‌شدن با دسته به صف برگشتند؛ اگر شریک نرسد، پس از مکث یک تلاش مجدد تکیِ محدود و کنترل‌شده انجام می‌شود.',
            '', 0, $resume_at,
            ['purpose' => 'product_import_batch', 'batch_size' => count($dkps), 'dkps' => array_values(array_unique($dkps))]
        );
    }
    return ['deferred' => $deferred, 'resume_at' => $resume_at];
}

/** Read the administrator-selected maximum batch size (the adaptive controller never changes it). */
function evazar_queue_product_batch_configured_size() {
    $size = absint(get_option('evazar_ai_product_batch_size', 50));
    if ($size < 2) $size = 50;
    return max(2, min(50, $size));
}

/**
 * Return the persisted adaptive state, or safe defaults when no state exists / the admin changed
 * the configured batch cap. A manual cap change resets batch adaptation but preserves the
 * independently learned concurrency limit.
 */
function evazar_queue_product_batch_adaptive_state() {
    $configured_size = evazar_queue_product_batch_configured_size();
    $stored = get_option('evazar_ai_product_batch_adaptive_state', []);
    $stored = is_array($stored) ? $stored : [];
    $same_configuration = isset($stored['configured_batch_size'])
        && (int) $stored['configured_batch_size'] === $configured_size;

    if (!$same_configuration) {
        return [
            'version' => 1,
            'configured_batch_size' => $configured_size,
            'batch_size' => $configured_size,
            'concurrency' => max(1, min(5, absint($stored['concurrency'] ?? 5))),
            'success_streak' => 0,
            'failure_streak' => 0,
            'last_failure_kind' => '',
            'updated_at' => 0,
        ];
    }

    return [
        'version' => 1,
        'configured_batch_size' => $configured_size,
        'batch_size' => max(2, min($configured_size, absint($stored['batch_size'] ?? $configured_size))),
        'concurrency' => max(1, min(5, absint($stored['concurrency'] ?? 5))),
        'success_streak' => max(0, min(9, absint($stored['success_streak'] ?? 0))),
        'failure_streak' => max(0, min(20, absint($stored['failure_streak'] ?? 0))),
        'last_failure_kind' => in_array(($stored['last_failure_kind'] ?? ''), ['upstream_5xx', 'rate_limit'], true)
            ? (string) $stored['last_failure_kind'] : '',
        'updated_at' => max(0, absint($stored['updated_at'] ?? 0)),
    ];
}

/** Use a short option-backed lock so concurrent queue runs cannot overwrite adaptive state updates. */
function evazar_queue_product_batch_adaptive_lock_acquire() {
    $key = 'evazar_ai_product_batch_adaptive_lock';
    $now = time();
    $GLOBALS['evazar_queue_product_batch_adaptive_lock_token'] = '';
    try {
        $token = $now . ':' . bin2hex(random_bytes(8));
    } catch (Throwable $e) {
        $token = $now . ':' . str_replace('.', '', uniqid('', true));
    }

    if (add_option($key, $token, '', false)) {
        $GLOBALS['evazar_queue_product_batch_adaptive_lock_token'] = $token;
        return true;
    }

    // Older builds stored only the acquisition timestamp, so accept both formats while expiring stale locks.
    $held_value = get_option($key, '');
    $held_parts = explode(':', (string) $held_value, 2);
    $held_at = absint($held_parts[0] ?? 0);
    if ($held_at > 0 && ($now - $held_at) > 20
        && evazar_queue_product_batch_adaptive_delete_stale_lock($key, $held_value)) {
        if (add_option($key, $token, '', false)) {
            $GLOBALS['evazar_queue_product_batch_adaptive_lock_token'] = $token;
            return true;
        }
    }

    // Queue runs are normally serialized already; briefly retry contention rather than lose an event.
    if (function_exists('usleep')) {
        for ($attempt = 0; $attempt < 3; $attempt++) {
            usleep(20000);
            if (add_option($key, $token, '', false)) {
                $GLOBALS['evazar_queue_product_batch_adaptive_lock_token'] = $token;
                return true;
            }
        }
    }
    return false;
}

/** Delete a stale lock only if the database still contains the exact value that was observed. */
function evazar_queue_product_batch_adaptive_delete_stale_lock($key, $observed_value) {
    global $wpdb;
    $key = (string) $key;
    $observed_value = (string) $observed_value;

    // In WordPress, use one conditional SQL DELETE as a compare-and-swap. A separate
    // get_option()+delete_option() pair can delete a fresh lock installed by another process.
    if (isset($wpdb) && is_object($wpdb) && !empty($wpdb->options)
        && method_exists($wpdb, 'prepare') && method_exists($wpdb, 'query')) {
        $sql = $wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
            $key,
            $observed_value
        );
        $deleted = $wpdb->query($sql);
        if ($deleted === false || (int) $deleted < 1) return false;
        if (function_exists('wp_cache_delete')) {
            wp_cache_delete($key, 'options');
            wp_cache_delete('alloptions', 'options');
            wp_cache_delete('notoptions', 'options');
        }
        return true;
    }

    // Lightweight test harnesses may not provide $wpdb. Keep their fallback value-checked;
    // production WordPress always takes the atomic conditional-delete branch above.
    if ((string) get_option($key, '') !== $observed_value) return false;
    return (bool) delete_option($key);
}

function evazar_queue_product_batch_adaptive_lock_release() {
    $key = 'evazar_ai_product_batch_adaptive_lock';
    $token = (string) ($GLOBALS['evazar_queue_product_batch_adaptive_lock_token'] ?? '');
    // A slow/stale owner must never delete a replacement lock acquired by another request.
    if ($token !== '' && hash_equals($token, (string) get_option($key, ''))) {
        delete_option($key);
    }
    $GLOBALS['evazar_queue_product_batch_adaptive_lock_token'] = '';
}

function evazar_queue_product_batch_adaptive_save($state) {
    if (!is_array($state)) return false;
    $state['updated_at'] = time();
    return update_option('evazar_ai_product_batch_adaptive_state', $state, false);
}

/** Log only actual capacity changes or a meaningful rate-limit pressure observation. */
function evazar_queue_product_batch_adaptive_log($message, $state, $previous_batch, $previous_concurrency, $reason, $failure_count = 0, $wave_size = 0, $http_code = 0) {
    if (!function_exists('evazar_gemini_log_event')) return;
    $context = [
        'purpose' => 'product_import_batch',
        'adaptive_reason' => sanitize_key((string) $reason),
        'configured_batch_size' => (int) ($state['configured_batch_size'] ?? 50),
        'previous_batch_size' => (int) $previous_batch,
        'effective_batch_size' => (int) ($state['batch_size'] ?? 50),
        'previous_concurrency' => (int) $previous_concurrency,
        'effective_concurrency' => (int) ($state['concurrency'] ?? 5),
        'success_streak' => (int) ($state['success_streak'] ?? 0),
        'failure_streak' => (int) ($state['failure_streak'] ?? 0),
        'failure_count' => max(0, (int) $failure_count),
        'wave_requests' => max(0, (int) $wave_size),
        'batch_size' => max(2, min(50, (int) ($state['batch_size'] ?? 50))),
    ];
    evazar_gemini_log_event('adaptive_batch_adjusted', (string) $message, '', (int) $http_code, 0, $context);
}

/**
 * Classify only explicit Gemini transient upstream errors. A generic HTTP 503, internal endpoint
 * failure, authentication problem, invalid model output, or uncertain result must not shrink batches.
 */
function evazar_queue_product_batch_adaptive_http_code($error) {
    if (!function_exists('is_wp_error') || !is_wp_error($error)) return 0;
    $data = method_exists($error, 'get_error_data') ? $error->get_error_data() : null;
    if (is_array($data)) {
        foreach (['http_code', 'status_code', 'status'] as $key) {
            $candidate = absint($data[$key] ?? 0);
            if (($candidate >= 500 && $candidate <= 599) || $candidate === 429) return $candidate;
        }
    }
    $message = (string) $error->get_error_message();
    if (preg_match('/\bHTTP\s*([45][0-9]{2})\b/i', $message, $match)) {
        $candidate = (int) $match[1];
        if (($candidate >= 500 && $candidate <= 599) || $candidate === 429) return $candidate;
    }
    return 0;
}

function evazar_queue_product_batch_adaptive_error_kind($error) {
    if (!function_exists('is_wp_error') || !is_wp_error($error)) return '';
    $code = (string) $error->get_error_code();
    $message = (string) $error->get_error_message();
    // Require an explicit HTTP marker in the diagnostic text as well as the specific
    // Gemini error code; an arbitrary internal status/data field alone is insufficient.
    if (!preg_match('/\bHTTP\s*([45][0-9]{2})\b/i', $message, $match)) return '';
    $message_http_code = (int) $match[1];
    $http_code = evazar_queue_product_batch_adaptive_http_code($error);
    if ($code === 'gemini_temporary_unavailable' && $message_http_code >= 500 && $message_http_code <= 599
        && $http_code >= 500 && $http_code <= 599 && $message_http_code === $http_code) {
        return 'upstream_5xx';
    }
    if ($code === 'gemini_rate_limited' && $message_http_code === 429 && $http_code === 429) {
        return 'rate_limit';
    }
    return '';
}

/** Record a retryable Gemini failure; batch reduction is global, while concurrency falls only for repeated/concurrent failures. */
function evazar_queue_product_batch_adaptive_record_failure($kind, $failure_count = 1, $wave_size = 1, $http_code = 0) {
    if (!in_array($kind, ['upstream_5xx', 'rate_limit'], true)) return false;
    if (!evazar_queue_product_batch_adaptive_lock_acquire()) return false;

    try {
        $state = evazar_queue_product_batch_adaptive_state();
        $configured = (int) $state['configured_batch_size'];
        $previous_batch = (int) $state['batch_size'];
        $previous_concurrency = (int) $state['concurrency'];
        $failure_count = max(1, (int) $failure_count);
        $wave_size = max(1, (int) $wave_size);
        $http_code = (int) $http_code;
        if ($kind === 'upstream_5xx' && ($http_code < 500 || $http_code > 599)) $http_code = 0;
        if ($kind === 'rate_limit' && $http_code !== 429) $http_code = 429;
        $repeated_same_kind = (int) $state['failure_streak'] > 0 && $state['last_failure_kind'] === $kind;

        $state['success_streak'] = 0;
        $state['failure_streak'] = min(20, (int) $state['failure_streak'] + $failure_count);
        $state['last_failure_kind'] = $kind;

        if ($kind === 'upstream_5xx') {
            // Use the requested 50→40→30→20→10→5 ladder; honour smaller admin caps safely.
            $floor = $configured >= 5 ? 5 : 2;
            $state['batch_size'] = max($floor, min($configured, $previous_batch) - 10);
        }

        // A single isolated Worker error must not throttle healthy peers. Reduce concurrency only
        // when at least two requests in this wave fail, or transient failures repeat consecutively.
        if (($failure_count >= 2 && $wave_size >= 2) || $repeated_same_kind) {
            $state['concurrency'] = max(1, min(5, $previous_concurrency) - 1);
        }

        evazar_queue_product_batch_adaptive_save($state);
        $changed = ((int) $state['batch_size'] !== $previous_batch)
            || ((int) $state['concurrency'] !== $previous_concurrency);
        $reason_label = ($kind === 'upstream_5xx') ? 'Gemini upstream 5xx' : 'Gemini rate limit 429';
        $message = $kind === 'upstream_5xx'
            ? 'خطای موقت 5xx تأییدشده از Gemini شناسایی شد؛ اندازه دسته برای اجراهای بعدی کاهش یافت.'
            : 'محدودیت نرخ 429 تأیید شد؛ اندازه دسته ثابت ماند تا تعداد درخواست‌ها بی‌دلیل افزایش نیابد.';
        if ((int) $state['concurrency'] < $previous_concurrency) {
            $message .= ' به‌دلیل خطاهای هم‌زمان/متوالی، هم‌زمانی Gemini نیز کاهش یافت.';
        }
        if (!$changed && $kind === 'upstream_5xx') $message = 'خطای موقت 5xx تأییدشده از Gemini ثبت شد، اما اندازه دسته از حداقل ایمن پایین‌تر نرفت.';
        evazar_queue_product_batch_adaptive_log(
            $message, $state, $previous_batch, $previous_concurrency, $reason_label,
            $failure_count, $wave_size, $http_code
        );
        return true;
    } finally {
        evazar_queue_product_batch_adaptive_lock_release();
    }
}

/** Accumulate clean request successes and recover by ten products/one slot per three consecutive successes. */
function evazar_queue_product_batch_adaptive_record_successes($successful_requests = 1) {
    $successful_requests = max(0, min(100, (int) $successful_requests));
    if ($successful_requests < 1 || !evazar_queue_product_batch_adaptive_lock_acquire()) return false;

    try {
        $state = evazar_queue_product_batch_adaptive_state();
        $previous_batch = (int) $state['batch_size'];
        $previous_concurrency = (int) $state['concurrency'];
        $state['failure_streak'] = 0;
        $state['last_failure_kind'] = '';
        $state['success_streak'] = (int) $state['success_streak'] + $successful_requests;
        $recovery_steps = intdiv((int) $state['success_streak'], 3);
        $state['success_streak'] = (int) $state['success_streak'] % 3;

        if ($recovery_steps > 0) {
            $state['batch_size'] = min((int) $state['configured_batch_size'], (int) $state['batch_size'] + (10 * $recovery_steps));
            $state['concurrency'] = min(5, (int) $state['concurrency'] + $recovery_steps);
        }
        evazar_queue_product_batch_adaptive_save($state);

        if ((int) $state['batch_size'] !== $previous_batch || (int) $state['concurrency'] !== $previous_concurrency) {
            evazar_queue_product_batch_adaptive_log(
                'پس از هر سه درخواست دسته‌ای موفق پیاپی، اندازه دسته ۱۰ محصول و هم‌زمانی یک واحد افزایش یافت (تا سقف تنظیم‌شده).',
                $state, $previous_batch, $previous_concurrency, 'success_recovery', $successful_requests, $successful_requests, 0
            );
        }
        return true;
    } finally {
        evazar_queue_product_batch_adaptive_lock_release();
    }
}

/** A non-adaptive error breaks consecutiveness but never changes capacity. */
function evazar_queue_product_batch_adaptive_reset_success_streak() {
    if (!evazar_queue_product_batch_adaptive_lock_acquire()) return false;
    try {
        $state = evazar_queue_product_batch_adaptive_state();
        if ((int) $state['success_streak'] === 0 && (int) $state['failure_streak'] === 0 && $state['last_failure_kind'] === '') return true;
        $state['success_streak'] = 0;
        $state['failure_streak'] = 0;
        $state['last_failure_kind'] = '';
        evazar_queue_product_batch_adaptive_save($state);
        return true;
    } finally {
        evazar_queue_product_batch_adaptive_lock_release();
    }
}

/** Return true only when every requested product has a corresponding non-error response. */
function evazar_queue_product_batch_adaptive_response_is_successful($chunk, $responses) {
    if (!is_array($responses) || !is_array($chunk) || count($chunk) < 1) return false;
    foreach ($chunk as $entry) {
        $item = $entry['item'] ?? null;
        $checkpoint = is_array($entry['checkpoint'] ?? null) ? $entry['checkpoint'] : [];
        $dkp = preg_replace('/[^0-9]/', '', (string) ($checkpoint['dkp'] ?? ($item->dkp ?? '')));
        if ($dkp === '' || !array_key_exists($dkp, $responses)) return false;
        if (function_exists('is_wp_error') && is_wp_error($responses[$dkp])) return false;
        if (!is_string($responses[$dkp]) || trim($responses[$dkp]) === '') return false;
    }
    return true;
}

/** Observe a completed parallel wave once, avoiding multiple adaptive steps for simultaneous failures. */
function evazar_queue_product_batch_adaptive_observe_wave($chunks, $responses) {
    $chunks = array_values((array) $chunks);
    if (function_exists('is_wp_error') && is_wp_error($responses)) {
        $kind = evazar_queue_product_batch_adaptive_error_kind($responses);
        if ($kind !== '') evazar_queue_product_batch_adaptive_record_failure($kind, 1, count($chunks), evazar_queue_product_batch_adaptive_http_code($responses));
        else evazar_queue_product_batch_adaptive_reset_success_streak();
        return;
    }
    if (!is_array($responses)) {
        evazar_queue_product_batch_adaptive_reset_success_streak();
        return;
    }

    $upstream_failures = 0;
    $rate_limit_failures = 0;
    $observed_http_code = 0;
    $other_failure = false;
    $successes = 0;

    foreach ($chunks as $index => $chunk) {
        $chunk_response = $responses[$index] ?? null;
        if (function_exists('is_wp_error') && is_wp_error($chunk_response)) {
            $kind = evazar_queue_product_batch_adaptive_error_kind($chunk_response);
            if ($kind === 'upstream_5xx') {
                $upstream_failures++;
                if ($observed_http_code === 0) $observed_http_code = evazar_queue_product_batch_adaptive_http_code($chunk_response);
            } elseif ($kind === 'rate_limit') {
                $rate_limit_failures++;
                if ($observed_http_code === 0) $observed_http_code = evazar_queue_product_batch_adaptive_http_code($chunk_response);
            } else $other_failure = true;
            continue;
        }
        if (!is_array($chunk_response)) {
            $other_failure = true;
            continue;
        }

        $kind_in_chunk = '';
        $chunk_http_code = 0;
        $chunk_has_other_error = false;
        foreach ($chunk as $entry) {
            $item = $entry['item'] ?? null;
            $checkpoint = is_array($entry['checkpoint'] ?? null) ? $entry['checkpoint'] : [];
            $dkp = preg_replace('/[^0-9]/', '', (string) ($checkpoint['dkp'] ?? ($item->dkp ?? '')));
            if ($dkp === '' || !array_key_exists($dkp, $chunk_response)) {
                $chunk_has_other_error = true;
                continue;
            }
            $item_response = $chunk_response[$dkp];
            if (function_exists('is_wp_error') && is_wp_error($item_response)) {
                $kind = evazar_queue_product_batch_adaptive_error_kind($item_response);
                if ($kind !== '') {
                    $kind_in_chunk = $kind;
                    if ($chunk_http_code === 0) $chunk_http_code = evazar_queue_product_batch_adaptive_http_code($item_response);
                } else $chunk_has_other_error = true;
            } elseif (!is_string($item_response) || trim($item_response) === '') {
                $chunk_has_other_error = true;
            }
        }
        if ($kind_in_chunk === 'upstream_5xx') {
            $upstream_failures++;
            if ($observed_http_code === 0) $observed_http_code = $chunk_http_code;
        } elseif ($kind_in_chunk === 'rate_limit') {
            $rate_limit_failures++;
            if ($observed_http_code === 0) $observed_http_code = $chunk_http_code;
        } elseif ($chunk_has_other_error) $other_failure = true;
        else $successes++;
    }

    $transient_failures = $upstream_failures + $rate_limit_failures;
    if ($transient_failures > 0) {
        evazar_queue_product_batch_adaptive_record_failure(
            $upstream_failures > 0 ? 'upstream_5xx' : 'rate_limit',
            $transient_failures, count($chunks), $observed_http_code
        );
        return;
    }
    if ($other_failure) {
        evazar_queue_product_batch_adaptive_reset_success_streak();
        return;
    }
    if ($successes > 0) evazar_queue_product_batch_adaptive_record_successes($successes);
}

function evazar_queue_product_batch_size() {
    $configured_size = evazar_queue_product_batch_configured_size();
    $state = evazar_queue_product_batch_adaptive_state();
    return max(2, min($configured_size, (int) ($state['batch_size'] ?? $configured_size)));
}

/** Rebuild only the unsent tail when the adaptive batch cap changes during the current queue run. */
function evazar_queue_product_batch_adaptive_repartition_chunks($chunks, $processed_chunk_count, $force = false) {
    $chunks = array_values((array) $chunks);
    $processed_chunk_count = max(0, min(count($chunks), (int) $processed_chunk_count));
    $effective_size = evazar_queue_product_batch_size();
    $prefix = array_slice($chunks, 0, $processed_chunk_count);
    $tail = array_slice($chunks, $processed_chunk_count);
    $needs_repartition = (bool) $force;

    if (!$needs_repartition) {
        foreach ($tail as $chunk) {
            if (count((array) $chunk) > $effective_size) {
                $needs_repartition = true;
                break;
            }
        }
    }

    if (!$needs_repartition || empty($tail)) {
        return [
            'chunks' => $chunks,
            'unpaired' => [],
            'repartitioned' => false,
            'effective_batch_size' => $effective_size,
        ];
    }

    $remaining_entries = [];
    foreach ($tail as $chunk) $remaining_entries = array_merge($remaining_entries, (array) $chunk);
    $partition = evazar_queue_partition_product_batches($remaining_entries, $effective_size);

    return [
        'chunks' => array_merge($prefix, (array) ($partition['chunks'] ?? [])),
        'unpaired' => (array) ($partition['unpaired'] ?? []),
        'repartitioned' => true,
        'effective_batch_size' => $effective_size,
    ];
}

/**
 * Automatically distribute Gemini-only product batches across configured Workers.
 * True concurrency is used when the WordPress cURL-multi transport is available;
 * otherwise the caller still assigns each successive chunk to a different eligible
 * Worker sequentially. The legacy checkbox is intentionally no longer a kill switch:
 * eligible-Worker-aware allocation is the default behavior requested for the queue.
 */
function evazar_queue_product_batch_parallel_enabled() {
    if (!evazar_queue_product_batch_enabled() || get_option('evazar_ai_engine_mode', '') !== 'gemini_only') {
        return false;
    }
    if (!function_exists('evazar_get_gemini_worker_urls')) return false;
    $urls = array_values(array_unique(array_filter(array_map(function($url) {
        return rtrim(trim((string) $url), '/');
    }, (array) evazar_get_gemini_worker_urls()))));
    return count($urls) >= 2;
}

function evazar_queue_product_batch_parallelism() {
    // Up to five configured Workers are allowed, but a persistent adaptive cap can
    // temporarily lower concurrency after repeated/concurrent upstream failures.
    if (!function_exists('evazar_get_gemini_worker_urls')) return 1;
    $urls = array_unique(array_filter(array_map(static function($url) {
        return rtrim(trim((string) $url), '/');
    }, (array) evazar_get_gemini_worker_urls())));
    $configured = max(1, min(5, count($urls)));
    $state = function_exists('evazar_queue_product_batch_adaptive_state') ? evazar_queue_product_batch_adaptive_state() : [];
    $adaptive = max(1, min(5, absint($state['concurrency'] ?? 5)));
    return max(1, min($configured, $adaptive));
}

function evazar_queue_parallel_transport_available() {
    // True parallel fan-out requires the cURL multi transport. The fsockopen
    // transport can only serialize requests and must not be advertised as parallel.
    return class_exists('\\WpOrg\\Requests\\Requests')
        && method_exists('\\WpOrg\\Requests\\Requests', 'request_multiple')
        && class_exists('\\WpOrg\\Requests\\Transport\\Curl')
        && function_exists('curl_init')
        && function_exists('curl_multi_init');
}

/** Persistent adaptive controller for Digikala product-source concurrency. */
function evazar_queue_product_source_adaptive_state() {
    $urls = function_exists('evazar_get_primary_worker_urls')
        ? array_values(array_unique(array_filter(array_map(static function ($url) { return rtrim(trim((string) $url), '/'); }, (array) evazar_get_primary_worker_urls()))))
        : [];
    $configured = max(1, min(5, count($urls)));
    $stored = get_option('evazar_source_fetch_adaptive_state', []);
    $state = is_array($stored) && (int) ($stored['version'] ?? 0) === 1 ? $stored : [];
    if (empty($state)) {
        $state = ['version'=>1, 'concurrency'=>min(2, $configured), 'success_streak'=>0,
            'configured_workers'=>$configured, 'last_outcome'=>'initialized', 'last_reason'=>'safe_start', 'updated_at'=>time()];
        update_option('evazar_source_fetch_adaptive_state', $state, false);
    } else {
        $previous_configured = absint($state['configured_workers'] ?? $configured);
        $state['concurrency'] = max(1, min(5, absint($state['concurrency'] ?? 2)));
        $state['success_streak'] = max(0, min(2, absint($state['success_streak'] ?? 0)));
        $state['configured_workers'] = $configured;
        if ($previous_configured !== $configured) {
            // If the controller was initialized before the Worker pool was configured,
            // move it to the normal safe start of two once at least two Workers exist.
            if ($previous_configured < 2 && $configured >= 2 && ($state['last_outcome'] ?? '') === 'initialized') {
                $state['concurrency'] = 2;
            }
            $state['success_streak'] = 0;
            update_option('evazar_source_fetch_adaptive_state', $state, false);
        }
    }
    return $state;
}

/** Observe one completed source wave; only confirmed Digikala-origin overloads affect capacity. */
function evazar_queue_product_source_adaptive_observe_wave($successes, $source_failures, $attempted, $reason = '') {
    $successes = max(0, absint($successes));
    $source_failures = max(0, absint($source_failures));
    $attempted = max(0, absint($attempted));
    $state = evazar_queue_product_source_adaptive_state();
    if ($attempted < 1) return $state;
    $before = absint($state['concurrency'] ?? 2);
    $changed = false;
    if ($source_failures > 0) {
        $state['concurrency'] = max(1, $before - 1);
        $state['success_streak'] = 0;
        $state['last_outcome'] = 'source_failure';
        $state['last_reason'] = sanitize_key((string) $reason) ?: 'digikala_upstream_error';
        $changed = $state['concurrency'] !== $before;
    } elseif ($successes === $attempted) {
        $state['success_streak'] = min(3, absint($state['success_streak'] ?? 0) + 1);
        $state['last_outcome'] = 'success';
        if ($state['success_streak'] >= 3) {
            $state['concurrency'] = min(5, $before + 1);
            $state['success_streak'] = 0;
            $changed = $state['concurrency'] !== $before;
            $state['last_reason'] = $changed ? 'three_successful_waves_upgrade' : 'maximum_capacity_stable';
        } else {
            $state['last_reason'] = 'three_clean_waves_required';
        }
    } else {
        // Product 404s, malformed payloads and Worker/runtime errors are neutral signals.
        return $state;
    }
    $state['updated_at'] = time();
    $state['last_change'] = $changed ? $state['concurrency'] : ($state['last_change'] ?? $before);
    update_option('evazar_source_fetch_adaptive_state', $state, false);
    return $state;
}

/** Starts at two and ramps to five after three clean source waves at each step. */
function evazar_queue_product_source_fetch_concurrency() {
    $urls = function_exists('evazar_get_primary_worker_urls')
        ? array_values(array_unique(array_filter(array_map(static function ($url) { return rtrim(trim((string) $url), '/'); }, (array) evazar_get_primary_worker_urls()))))
        : [];
    $configured = max(1, min(5, count($urls)));
    $state = evazar_queue_product_source_adaptive_state();
    return max(1, min($configured, 5, absint($state['concurrency'] ?? 2)));
}

/** Snapshot the primary source Worker pool without reserving a request slot. */
function evazar_queue_product_source_worker_pool_state($purpose = 'import_source') {
    $urls = function_exists('evazar_get_primary_worker_urls')
        ? array_values(array_unique(array_filter(array_map(static function ($url) { return rtrim(trim((string) $url), '/'); }, (array) evazar_get_primary_worker_urls()))))
        : [];
    $purpose = sanitize_key((string) $purpose) ?: 'import_source';
    $state = [
        'configured_count' => count($urls), 'eligible_count' => 0, 'eligible_urls' => [],
        'eligible_workers' => [], 'cooldown_count' => 0, 'budget_count' => 0, 'busy_count' => 0,
        'cooldown_workers' => [], 'budget_workers' => [], 'busy_workers' => [], 'workers' => [],
        'retry_after_seconds' => 60, 'code' => '', 'reason' => '',
    ];
    if (empty($urls)) {
        $state['code'] = 'worker_unconfigured';
        $state['reason'] = 'هیچ Worker اصلی برای دریافت محصولات تنظیم نشده است.';
        return $state;
    }

    $budget = function_exists('evazar_primary_worker_daily_budget') ? evazar_primary_worker_daily_budget() : 85000;
    $nearest_cooldown = 0;
    foreach ($urls as $url) {
        $host = function_exists('evazar_primary_worker_host_label')
            ? evazar_primary_worker_host_label($url)
            : strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        $cooldown = function_exists('evazar_primary_worker_cooldown_info')
            ? evazar_primary_worker_cooldown_info($url, $purpose) : [];
        if (!empty($cooldown)) {
            $state['cooldown_count']++;
            $wait = max(1, absint($cooldown['remaining_seconds'] ?? 30));
            if ($nearest_cooldown === 0 || $wait < $nearest_cooldown) $nearest_cooldown = $wait;
            $cooldown_worker = [
                'worker_host' => $host,
                'remaining_seconds' => $wait,
                'reason' => sanitize_key((string) ($cooldown['reason'] ?? 'temporary_worker_error')),
                'http_code' => absint($cooldown['http_code'] ?? 0),
            ];
            $state['cooldown_workers'][] = $cooldown_worker;
            $state['workers'][] = array_merge($cooldown_worker, ['status' => 'cooldown']);
            continue;
        }
        $lock_info = function_exists('evazar_primary_worker_request_lock_info')
            ? evazar_primary_worker_request_lock_info($url, 25)
            : ['busy' => false, 'remaining_seconds' => 0];
        if (!empty($lock_info['busy'])) {
            $state['busy_count']++;
            $wait = max(1, absint($lock_info['remaining_seconds'] ?? 15));
            if ($nearest_cooldown === 0 || $wait < $nearest_cooldown) $nearest_cooldown = $wait;
            $busy_worker = ['worker_host' => $host, 'status' => 'busy', 'remaining_seconds' => $wait];
            $state['busy_workers'][] = $busy_worker;
            $state['workers'][] = $busy_worker;
            continue;
        }
        $usage = function_exists('evazar_primary_worker_usage_status')
            ? evazar_primary_worker_usage_status($url, $budget)
            : ['known' => false, 'usage' => 0, 'core' => 0];
        $over_budget = (!empty($usage['known']) && absint($usage['usage'] ?? 0) >= $budget)
            || (empty($usage['known']) && absint($usage['core'] ?? 0) >= $budget);
        if ($over_budget) {
            $state['budget_count']++;
            $budget_worker = [
                'worker_host' => $host,
                'status' => 'daily_budget',
                'usage' => absint($usage['usage'] ?? 0),
                'core_usage' => absint($usage['core'] ?? 0),
                'usage_known' => !empty($usage['known']),
                'daily_budget' => absint($budget),
            ];
            $state['budget_workers'][] = $budget_worker;
            $state['workers'][] = $budget_worker;
            continue;
        }
        $state['eligible_urls'][] = $url;
        $state['eligible_workers'][] = $host;
        $state['workers'][] = [
            'worker_host' => $host,
            'status' => 'eligible',
            'usage' => absint($usage['usage'] ?? 0),
            'core_usage' => absint($usage['core'] ?? 0),
            'usage_known' => !empty($usage['known']),
            'daily_budget' => absint($budget),
        ];
    }
    $state['eligible_count'] = count($state['eligible_urls']);
    if ($state['eligible_count'] > 0) {
        $state['code'] = 'worker_pool_ready';
        $state['reason'] = 'Workerهای لازم برای دریافت محصول در دسترس هستند.';
        $state['retry_after_seconds'] = 0;
        return $state;
    }

    if ($state['busy_count'] === count($urls) && $state['cooldown_count'] === 0 && $state['budget_count'] === 0) {
        $state['code'] = 'worker_pool_busy';
        $state['reason'] = sprintf('هیچ درخواستی ارسال نشد؛ هر %d Worker اصلی در اجرای دیگری مشغول است.', count($urls));
        $state['retry_after_seconds'] = max(5, $nearest_cooldown ?: 15);
    } elseif ($state['cooldown_count'] === count($urls) && $state['budget_count'] === 0 && $state['busy_count'] === 0) {
        $state['code'] = 'all_workers_in_cooldown';
        $state['reason'] = sprintf('هیچ درخواستی ارسال نشد؛ هر %d Worker اصلی در مکث موقت است.', count($urls));
        $state['retry_after_seconds'] = max(8, $nearest_cooldown ?: 30);
    } elseif ($state['budget_count'] === count($urls) && $state['cooldown_count'] === 0 && $state['busy_count'] === 0) {
        $state['code'] = 'all_workers_daily_budget_exhausted';
        $state['reason'] = 'هیچ درخواست جدیدی ارسال نشد؛ سقف روزانه همه Workerهای اصلی تکمیل شده است.';
        $state['retry_after_seconds'] = function_exists('evazar_primary_worker_seconds_to_utc_day_reset')
            ? evazar_primary_worker_seconds_to_utc_day_reset() : DAY_IN_SECONDS;
    } else {
        $state['code'] = 'worker_pool_unavailable';
        $state['reason'] = sprintf('هیچ Worker اصلی قابل‌استفاده نیست؛ تنظیم‌شده=%d، مکث=%d، مشغول=%d، سقف‌روزانه=%d.', count($urls), $state['cooldown_count'], $state['busy_count'], $state['budget_count']);
        $state['retry_after_seconds'] = $nearest_cooldown ?: (function_exists('evazar_primary_worker_seconds_to_utc_day_reset') && $state['budget_count'] ? evazar_primary_worker_seconds_to_utc_day_reset() : 60);
    }
    return $state;
}

/** Whether a cached source-fetch entry represents a real HTTP attempt that should still be consumed. */
function evazar_queue_source_item_has_attempted_request($entry) {
    if (!is_array($entry) || empty($entry['request_sent'])) return false;
    return in_array((string) ($entry['mode'] ?? ''), ['response', 'fallback', 'worker_failure_deferred'], true);
}

/** After the source circuit opens, only defer items that were not already requested in the current wave. */
function evazar_queue_source_circuit_should_defer_tail($batch_collect_enabled, $circuit_open, $dkp, $prefetch_entry) {
    if (!$batch_collect_enabled || !$circuit_open || trim((string) $dkp) === '') return false;
    return !evazar_queue_source_item_has_attempted_request($prefetch_entry);
}

/** Release only the unvisited tail of this claim when no source Worker can accept a request. */
function evazar_queue_defer_claimed_source_tail($items, $start_index, $claim_token, $pool_state = []) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    $tail_ids = [];
    $tail_dkps = [];
    foreach (array_slice(array_values((array) $items), max(0, (int) $start_index)) as $item) {
        $id = absint($item->id ?? 0);
        if ($id < 1) continue;
        $tail_ids[] = $id;
        $dkp = preg_replace('/[^0-9]/', '', (string) ($item->dkp ?? ''));
        if ($dkp !== '') $tail_dkps[] = $dkp;
    }
    $tail_ids = array_values(array_unique($tail_ids));
    if (empty($tail_ids) || trim((string) $claim_token) === '') return ['deferred' => 0, 'resume_at' => 0, 'error' => 'no_claimed_tail'];

    $pool_code = sanitize_key((string) ($pool_state['code'] ?? 'worker_pool_unavailable'));
    $queue_code = $pool_code === 'source_circuit_open' ? 'DIGIKALA_SOURCE_CIRCUIT_OPEN'
        : ($pool_code === 'all_workers_in_cooldown' ? 'PRIMARY_WORKERS_IN_COOLDOWN'
            : ($pool_code === 'worker_pool_busy' ? 'PRIMARY_WORKERS_BUSY'
                : ($pool_code === 'all_workers_daily_budget_exhausted' ? 'PRIMARY_WORKERS_DAILY_BUDGET' : 'PRIMARY_WORKERS_UNAVAILABLE')));
    $delay = max(15, absint($pool_state['retry_after_seconds'] ?? 60));
    $delay = min(DAY_IN_SECONDS + 60, $delay);
    $resume_at = time() + $delay;
    $resume_mysql = evazar_queue_mysql_timestamp($resume_at);
    $resume_label = evazar_queue_local_datetime($resume_at) ?: $resume_mysql;
    $reason = sanitize_text_field((string) ($pool_state['reason'] ?? 'هیچ Worker اصلی برای دریافت محصول در دسترس نیست.'));
    $message = $reason . '؛ ' . count($tail_ids) . ' محصولِ ارسال‌نشده بدون افزایش Retry به صف انتظار برگشتند. زمان تلاش بعدی زودتر از ' . $resume_label . ' نخواهد بود.';

    $placeholders = implode(',', array_fill(0, count($tail_ids), '%d'));
    $sql = "UPDATE {$table_name} SET status=%s, error_code=%s, error_log=%s, last_error_at=%s, claim_token='', claimed_at=NULL, next_attempt_at=%s WHERE claim_token=%s AND status='processing' AND id IN ({$placeholders})";
    $args = array_merge([$sql, 'pending', $queue_code, $message, current_time('mysql'), $resume_mysql, (string) $claim_token], $tail_ids);
    $prepared = call_user_func_array([$wpdb, 'prepare'], $args);
    $updated = $wpdb->query($prepared);
    if ($updated === false) {
        // A failed bulk UPDATE must not leave the claimed tail stuck in processing.
        $updated = 0;
        foreach ($tail_ids as $id) {
            $one = $wpdb->update($table_name, [
                'status' => 'pending', 'error_code' => $queue_code, 'error_log' => $message,
                'last_error_at' => current_time('mysql'), 'claim_token' => '', 'claimed_at' => null,
                'next_attempt_at' => $resume_mysql,
            ], ['id' => $id, 'claim_token' => (string) $claim_token, 'status' => 'processing']);
            if ($one !== false && (int) $one > 0) $updated++;
        }
        if ($updated < count($tail_ids)) error_log('[EVazar Core] Failed to release every source-pool-deferred queue row; claim_token=' . substr((string) $claim_token, 0, 8));
    }
    $updated = max(0, (int) $updated);
    if (function_exists('delete_transient')) delete_transient('evazar_queue_dashboard_stats_v2');
    if ($updated > 0 && function_exists('evazar_gemini_log_event')) {
        evazar_gemini_log_event('queue_source_pool_deferred', $message, '', 0, $resume_at, [
            'purpose' => 'product_import_batch', 'queue_error_code' => $queue_code,
            'queue_deferred_count' => $updated, 'queue_tail_count' => count($tail_ids),
            'configured_workers' => absint($pool_state['configured_count'] ?? 0),
            'eligible_workers' => absint($pool_state['eligible_count'] ?? 0),
            'cooldown_workers' => absint($pool_state['cooldown_count'] ?? 0),
            'budget_blocked_workers' => absint($pool_state['budget_count'] ?? 0),
            'retry_after_seconds' => $delay, 'sample_dkps' => array_slice(array_values(array_unique($tail_dkps)), 0, 5),
        ]);
    }
    return ['deferred' => $updated, 'resume_at' => $resume_at, 'queue_error_code' => $queue_code, 'message' => $message];
}

/** Defer a product whose request really failed as Workers entered cooldown; keep its exact error diagnostic. */
function evazar_queue_defer_attempted_source_item($item, $claim_token, $diagnostic, $pool_state = []) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    $diagnostic = is_array($diagnostic) ? $diagnostic : [];
    $error_code = 'evazar_worker_product_unavailable';
    $detail = sanitize_textarea_field((string) ($diagnostic['detail'] ?? 'درخواست دریافت محصول از Worker ناموفق بود.'));
    if (function_exists('evazar_queue_log_pre_gemini_failure')) {
        evazar_queue_log_pre_gemini_failure($item, new WP_Error($error_code, $detail, $diagnostic));
    }
    $delay = max(15, absint($pool_state['retry_after_seconds'] ?? 60));
    $delay = min(DAY_IN_SECONDS + 60, $delay);
    $resume_at = time() + $delay;
    $resume_mysql = evazar_queue_mysql_timestamp($resume_at);
    $resume_label = evazar_queue_local_datetime($resume_at) ?: $resume_mysql;
    $message = $detail . '؛ پس از این خطا همه Workerهای اصلی در مکث شدند. این محصول بدون افزایش Retry به صف انتظار برگشت و زودتر از ' . $resume_label . ' دوباره امتحان نمی‌شود.';
    $updated = $wpdb->update($table_name, [
        'status' => 'pending', 'error_code' => 'PRIMARY_WORKER_TEMPORARY_FAILURE', 'error_log' => $message,
        'last_error_at' => current_time('mysql'), 'claim_token' => '', 'claimed_at' => null,
        'next_attempt_at' => $resume_mysql,
    ], ['id' => absint($item->id ?? 0), 'claim_token' => (string) $claim_token, 'status' => 'processing']);
    if ($updated === false) error_log('[EVazar Core] Failed to defer attempted product after source Worker pool entered cooldown; queue row=' . absint($item->id ?? 0));
    return ['deferred' => ($updated !== false && (int) $updated > 0) ? 1 : 0, 'resume_at' => $resume_at, 'message' => $message];
}

/** Select and reserve one eligible primary Worker URL, preferring URLs not yet used in this wave. */
function evazar_queue_release_product_source_worker_locks($meta) {
    foreach ((array) $meta as $entry) {
        $url = rtrim(trim((string) ($entry['worker_url'] ?? '')), '/');
        $token = (string) ($entry['worker_lock_token'] ?? '');
        if ($url !== '' && $token !== '' && function_exists('evazar_primary_worker_release_request_lock')) {
            evazar_primary_worker_release_request_lock($url, $token);
        }
    }
}

function evazar_queue_product_source_select_worker($used_urls = []) {
    if (!function_exists('evazar_get_primary_worker_urls')
        || !function_exists('evazar_primary_worker_usage_status')
        || !function_exists('evazar_primary_worker_try_reserve')
        || !function_exists('evazar_primary_worker_acquire_request_lock')
        || !function_exists('evazar_primary_worker_release_request_lock')) return '';

    $urls = array_values(array_unique(array_filter(array_map(static function ($url) {
        return rtrim(trim((string) $url), '/');
    }, (array) evazar_get_primary_worker_urls()))));
    if (empty($urls)) return '';

    $budget = function_exists('evazar_primary_worker_daily_budget') ? evazar_primary_worker_daily_budget() : 85000;
    $purpose = 'import_source';
    $count = count($urls);
    $cursor = max(0, (int) get_option('evazar_cf_worker_cursor', 0)) % $count;
    $candidates = [];
    $all_have_fresh_analytics = true;

    for ($offset = 0; $offset < $count; $offset++) {
        $index = ($cursor + $offset) % $count;
        $url = $urls[$index];
        if (function_exists('evazar_primary_worker_cooldown_info')
            && !empty(evazar_primary_worker_cooldown_info($url, $purpose))) continue;
        if (function_exists('evazar_primary_worker_request_lock_info')
            && !empty(evazar_primary_worker_request_lock_info($url, 25)['busy'])) continue;
        $status = evazar_primary_worker_usage_status($url, $budget);
        if (($status['known'] && (int) $status['usage'] >= $budget)
            || (!$status['known'] && (int) $status['core'] >= $budget)) continue;
        if (empty($status['known'])) $all_have_fresh_analytics = false;
        $candidates[] = ['index' => $index, 'url' => $url, 'status' => $status, 'cursor_order' => $offset];
    }
    if (empty($candidates)) return '';

    usort($candidates, static function ($a, $b) use ($all_have_fresh_analytics) {
        $left = $all_have_fresh_analytics ? (int) $a['status']['usage'] : (int) $a['status']['core'];
        $right = $all_have_fresh_analytics ? (int) $b['status']['usage'] : (int) $b['status']['core'];
        return $left === $right ? ($a['cursor_order'] <=> $b['cursor_order']) : ($left <=> $right);
    });

    $used = array_fill_keys(array_map(static function ($url) { return rtrim((string) $url, '/'); }, (array) $used_urls), true);
    // A single parallel wave must never schedule two simultaneous requests to the same Worker.
    // If fewer distinct Workers are eligible, leave remaining items for a later wave/serial fallback.
    $candidates = array_values(array_filter($candidates, static function ($candidate) use ($used) {
        return !isset($used[$candidate['url']]);
    }));
    if (empty($candidates)) return '';

    foreach ($candidates as $candidate) {
        $url = $candidate['url'];
        $lock_token = evazar_primary_worker_acquire_request_lock($url, 25);
        if (!$lock_token) continue;
        if (!evazar_primary_worker_try_reserve($url, $budget)) {
            evazar_primary_worker_release_request_lock($url, $lock_token);
            continue;
        }
        if (!isset($GLOBALS['evazar_queue_primary_worker_lock_tokens']) || !is_array($GLOBALS['evazar_queue_primary_worker_lock_tokens'])) {
            $GLOBALS['evazar_queue_primary_worker_lock_tokens'] = [];
        }
        $GLOBALS['evazar_queue_primary_worker_lock_tokens'][$url] = $lock_token;
        update_option('evazar_cf_worker_cursor', (((int) $candidate['index']) + 1) % $count, false);
        return $url;
    }
    return '';
}

/** Normalize scalar/array values returned by Requests response headers. */
function evazar_queue_product_source_header_value($value, $header_name = '') {
    if (function_exists('evazar_normalize_http_header_value')) {
        return evazar_normalize_http_header_value($value, $header_name);
    }
    $values = [];
    $collect = static function ($part) use (&$collect, &$values) {
        if (is_array($part)) {
            foreach ($part as $nested) $collect($nested);
        } elseif (is_object($part)) {
            if (method_exists($part, 'getAll')) $collect($part->getAll());
            elseif (method_exists($part, '__toString')) $collect((string) $part);
        } elseif (is_scalar($part) && !is_bool($part)) {
            $text = trim((string) $part);
            if ($text !== '') $values[] = preg_replace('/[\r\n\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $text);
        }
    };
    $collect($value);
    $values = array_values(array_unique(array_filter($values, static function ($part) { return $part !== ''; })));
    if (count($values) === 1) return $values[0];
    if (empty($values)) return '';
    $name = strtolower(trim((string) $header_name));
    if (in_array($name, ['x-evazar-error-scope', 'x-evazar-worker-version', 'x-evazar-source-content-status', 'x-evazar-taxonomy-source-api'], true)) return '';
    return implode(', ', $values);
}

/** Read one normalized header from the WordPress response shape. */
function evazar_queue_product_source_response_header($response, $header_name) {
    return evazar_queue_product_source_header_value(wp_remote_retrieve_header($response, $header_name), $header_name);
}

/**
 * Product source failures are terminal for the selected Worker request, not a Worker outage.
 * Prefer the explicit scope header; narrowly infer scope from the Worker's documented source_* JSON
 * contract when the header is missing or malformed (e.g. array-valued Requests headers).
 */
function evazar_queue_product_source_response_error_scope($response, $http_status = 0) {
    $scope = strtolower(trim(evazar_queue_product_source_response_header($response, 'x-evazar-error-scope')));
    if (in_array($scope, ['product', 'source', 'worker'], true)) return $scope;
    $http_status = absint($http_status ?: wp_remote_retrieve_response_code($response));
    if ($http_status < 400) return '';
    $payload = json_decode((string) wp_remote_retrieve_body($response), true);
    if (!is_array($payload) || !array_key_exists('success', $payload) || $payload['success'] !== false) return '';
    $error = sanitize_key((string) ($payload['error'] ?? ''));
    if (strpos($error, 'source_') !== 0) return '';
    $worker_version = evazar_queue_product_source_response_header($response, 'x-evazar-worker-version');
    if ($worker_version === '') $worker_version = sanitize_text_field((string) ($payload['worker_version'] ?? ''));
    $has_upstream = absint($payload['upstream_status_v2'] ?? 0) > 0
        || absint($payload['upstream_status_v1'] ?? 0) > 0
        || trim((string) ($payload['upstream_error_v2'] ?? '')) !== ''
        || trim((string) ($payload['upstream_error_v1'] ?? '')) !== '';
    return ($worker_version !== '' && $has_upstream) ? 'source' : '';
}

/** Convert a Requests response into the response-array shape consumed by WordPress HTTP helpers. */
function evazar_queue_product_source_wp_response($response) {
    if (!is_object($response) || !isset($response->status_code)) return null;
    $headers = [];
    if (isset($response->headers)) {
        if (is_object($response->headers) && method_exists($response->headers, 'getAll')) {
            $headers = $response->headers->getAll();
        } elseif (is_array($response->headers)) {
            $headers = $response->headers;
        } else {
            $headers = (array) $response->headers;
        }
    }
    $normalized_headers = [];
    foreach ((array) $headers as $key => $value) {
        $normalized_key = strtolower((string) $key);
        $normalized_headers[$normalized_key] = evazar_queue_product_source_header_value($value, $normalized_key);
    }
    return [
        'headers' => $normalized_headers,
        'body' => isset($response->body) ? (string) $response->body : '',
        'response' => [
            'code' => (int) $response->status_code,
            'message' => isset($response->status_message) ? (string) $response->status_message : '',
        ],
        'cookies' => [],
        'filename' => null,
    ];
}

/** Create the same item-scoped diagnostic contract used by the serial primary Worker dispatcher. */
function evazar_queue_product_source_response_diagnostic($response, $worker_url, $elapsed_ms = 0) {
    $code = (int) wp_remote_retrieve_response_code($response);
    $body = (string) wp_remote_retrieve_body($response);
    $payload = json_decode($body, true);
    $has_product_payload = is_array($payload)
        && !empty($payload['success'])
        && is_array($payload['product'] ?? null)
        && !empty($payload['product']);
    $scope = evazar_queue_product_source_response_error_scope($response, $code);
    $source_code = is_array($payload) ? sanitize_key((string) ($payload['error'] ?? '')) : '';
    $message = is_array($payload) ? sanitize_text_field((string) ($payload['message'] ?? '')) : '';
    $worker_version = sanitize_text_field(evazar_queue_product_source_response_header($response, 'x-evazar-worker-version') ?: (is_array($payload) ? (string) ($payload['worker_version'] ?? '') : ''));
    $retry_header = evazar_queue_product_source_response_header($response, 'retry-after');
    if ($retry_header === '' || $retry_header === null) $retry_header = evazar_queue_product_source_response_header($response, 'x-evazar-retry-after');
    $retry_after = 0;
    if (is_numeric($retry_header)) $retry_after = max(0, min(3600, (int) $retry_header));
    elseif (is_string($retry_header) && trim($retry_header) !== '') {
        $retry_time = strtotime($retry_header);
        if ($retry_time !== false) $retry_after = max(0, min(3600, $retry_time - time()));
    }

    $diag = [
        'code' => 'worker_http_' . max(0, $code),
        'detail' => $message !== '' ? $message : ('Worker پاسخ HTTP ' . $code . ' برگرداند.'),
        'configured' => count(function_exists('evazar_get_primary_worker_urls') ? evazar_get_primary_worker_urls() : []),
        'cooldown_skipped' => 0, 'budget_skipped' => 0, 'reservation_rejected' => 0,
        'attempted' => 1,
        'attempts' => [[
            'worker_host' => function_exists('evazar_primary_worker_host_label') ? evazar_primary_worker_host_label($worker_url) : (string) wp_parse_url($worker_url, PHP_URL_HOST),
            'http_code' => $code, 'duration_ms' => max(0, (int) $elapsed_ms),
            'outcome' => ($code >= 200 && $code < 300) ? 'http_success' : 'http_error',
            'error_code' => '', 'error_scope' => in_array($scope, ['product', 'source', 'worker'], true) ? $scope : '',
        ]],
        'http_code' => $code,
        'worker_host' => function_exists('evazar_primary_worker_host_label') ? evazar_primary_worker_host_label($worker_url) : (string) wp_parse_url($worker_url, PHP_URL_HOST),
        'elapsed_ms' => max(0, (int) $elapsed_ms),
        'cooldown_wait_seconds' => 0, 'retry_after_seconds' => $retry_after, 'cooldown_workers' => [],
        'error_scope' => in_array($scope, ['product', 'source', 'worker'], true) ? $scope : '',
        'source_error_code' => $source_code,
        'upstream_status_v2' => is_array($payload) ? absint($payload['upstream_status_v2'] ?? 0) : 0,
        'upstream_status_v1' => is_array($payload) ? absint($payload['upstream_status_v1'] ?? 0) : 0,
        'upstream_error_v2' => is_array($payload) ? sanitize_text_field((string) ($payload['upstream_error_v2'] ?? '')) : '',
        'upstream_error_v1' => is_array($payload) ? sanitize_text_field((string) ($payload['upstream_error_v1'] ?? '')) : '',
        'worker_version' => $worker_version,
        'purpose' => 'import_source',
    ];

    if ($scope === 'source') {
        $diag['code'] = $source_code !== '' ? 'worker_upstream_' . $source_code : 'worker_source_unavailable';
        $diag['detail'] = $message !== '' ? $message : 'Worker پاسخ داد، اما منبع دیجی‌کالا داده قابل‌استفاده‌ای برنگرداند.';
        if ($source_code !== '') $diag['detail'] .= ' [source_error=' . $source_code . ']';
        if ($diag['upstream_status_v2'] || $diag['upstream_status_v1']) {
            $diag['detail'] .= ' [upstream v2=' . ($diag['upstream_status_v2'] ?: 'no-response') . ', v1=' . ($diag['upstream_status_v1'] ?: 'not-attempted/no-response') . ']';
        }
    } elseif ($code === 404 && $scope === 'product') {
        $diag['code'] = 'product_not_found';
        $diag['detail'] = $message !== '' ? $message : 'Worker محصول را با وضعیت 404 پیدا نکرد.';
    } elseif ($code === 200 && json_last_error() !== JSON_ERROR_NONE) {
        $diag['code'] = 'worker_invalid_json';
        $diag['detail'] = 'Worker پاسخ HTTP 200 داد، اما بدنه JSON معتبر نبود.';
    } elseif ($code === 200 && $has_product_payload) {
        $diag['code'] = 'worker_http_success';
        $diag['detail'] = 'Worker اطلاعات محصول را با موفقیت برگرداند.';
    } elseif ($code === 200) {
        $diag['code'] = 'worker_missing_product_payload';
        $diag['detail'] = $message !== '' ? $message : 'پاسخ Worker فاقد فیلد product معتبر بود.';
    }
    if ($worker_version !== '') $diag['detail'] .= ' [Worker=' . $worker_version . ']';
    return $diag;
}

/** Reset per-run source-prefetch metrics; source and Gemini Worker pools are tracked separately. */
function evazar_queue_source_parallel_stats_reset() {
    $primary_urls = function_exists('evazar_get_primary_worker_urls')
        ? array_values(array_unique(array_filter(array_map(static function ($url) { return rtrim(trim((string) $url), '/'); }, (array) evazar_get_primary_worker_urls()))))
        : [];
    $pool_state = function_exists('evazar_queue_product_source_worker_pool_state')
        ? evazar_queue_product_source_worker_pool_state('import_source') : [];
    $parallel_transport = function_exists('evazar_queue_parallel_transport_available') && evazar_queue_parallel_transport_available();
    $configured_count = count($primary_urls);
    $eligible_at_start = isset($pool_state['eligible_count']) ? max(0, (int) $pool_state['eligible_count']) : 0;
    $GLOBALS['evazar_queue_source_parallel_stats'] = [
        'waves' => 0,
        'requests' => 0,
        'responses' => 0,
        'fallback_requests' => 0,
        'transport_errors' => 0,
        'total_wave_elapsed_ms' => 0,
        'started_at' => 0.0,
        'worker_hosts' => [],
        'worker_request_counts' => [],
        'wave_size_counts' => [],
        'wave_eligible_counts' => [],
        'wave_reason_counts' => [],
        'wave_diagnostics' => [],
        'worker_wave_state_counts' => [],
        'configured_source_workers' => $configured_count,
        'eligible_source_workers_at_start' => $eligible_at_start,
        'source_concurrency_at_start' => $parallel_transport ? min(evazar_queue_product_source_fetch_concurrency(), $configured_count, $eligible_at_start) : min(1, $eligible_at_start),
        'adaptive_state_at_start' => function_exists('evazar_queue_product_source_adaptive_state') ? evazar_queue_product_source_adaptive_state() : [],
        'summary_attached' => false,
    ];
}

/** Accumulate source-prefetch metrics across waves for one consolidated Gemini log entry. */
function evazar_queue_source_parallel_stats_record($request_count, $response_count, $fallback_count, $transport_errors, $elapsed_ms, $worker_hosts = [], $started_at = 0, $wave_context = []) {
    if (!isset($GLOBALS['evazar_queue_source_parallel_stats']) || !is_array($GLOBALS['evazar_queue_source_parallel_stats'])) {
        evazar_queue_source_parallel_stats_reset();
    }
    $stats =& $GLOBALS['evazar_queue_source_parallel_stats'];
    $request_count = max(0, (int) $request_count);
    $elapsed_ms = max(0, (int) $elapsed_ms);
    $started_at = is_numeric($started_at) && (float) $started_at > 0 ? (float) $started_at : microtime(true) - ($elapsed_ms / 1000);
    if (empty($stats['started_at'])) $stats['started_at'] = $started_at;
    $stats['waves']++;
    $stats['requests'] += $request_count;
    $stats['responses'] += max(0, (int) $response_count);
    $stats['fallback_requests'] += max(0, (int) $fallback_count);
    $stats['transport_errors'] += max(0, (int) $transport_errors);
    $stats['total_wave_elapsed_ms'] += $elapsed_ms;
    $wave_context = is_array($wave_context) ? $wave_context : [];
    $wave_index = (int) $stats['waves'];
    $hosts_this_wave = array_values(array_unique(array_filter(array_map(static function ($host) {
        return sanitize_text_field((string) $host);
    }, (array) $worker_hosts))));
    $stats['worker_hosts'] = array_values(array_unique(array_merge((array) ($stats['worker_hosts'] ?? []), $hosts_this_wave)));
    if ($request_count > 0) {
        $wave_key = (string) $request_count;
        $stats['wave_size_counts'][$wave_key] = (int) ($stats['wave_size_counts'][$wave_key] ?? 0) + 1;
    } else {
        $stats['wave_size_counts']['0'] = (int) ($stats['wave_size_counts']['0'] ?? 0) + 1;
    }
    // Each source Worker is assigned at most one product in a wave; count its actual requests
    // across all waves to verify whether a 120-product run was distributed 24/worker (5 available).
    foreach ($hosts_this_wave as $host) {
        $stats['worker_request_counts'][$host] = (int) ($stats['worker_request_counts'][$host] ?? 0) + 1;
    }

    $pool = is_array($wave_context['pool_state'] ?? null) ? $wave_context['pool_state'] : [];
    $configured = max(0, (int) ($pool['configured_count'] ?? $stats['configured_source_workers'] ?? 0));
    $eligible = max(0, (int) ($pool['eligible_count'] ?? 0));
    $cooldown = max(0, (int) ($pool['cooldown_count'] ?? 0));
    $budget = max(0, (int) ($pool['budget_count'] ?? 0));
    $wave_items = max(0, (int) ($wave_context['wave_items'] ?? 0));
    $selected = max(0, (int) $request_count);
    $eligibility_key = (string) $eligible;
    $stats['wave_eligible_counts'][$eligibility_key] = (int) ($stats['wave_eligible_counts'][$eligibility_key] ?? 0) + 1;

    $reason = sanitize_key((string) ($wave_context['reason'] ?? ''));
    if ($reason === '') {
        $max_pool_concurrency = min(5, $configured);
        if ($configured < 1) {
            $reason = 'no_workers_configured';
        } elseif ($eligible < 1) {
            $reason = !empty($pool['code']) ? sanitize_key((string) $pool['code']) : 'no_worker_eligible';
        } elseif ($eligible < $max_pool_concurrency) {
            $reason = ($cooldown > 0 && $budget > 0) ? 'cooldown_and_daily_budget' : ($cooldown > 0 ? 'worker_cooldown' : ($budget > 0 ? 'worker_daily_budget' : 'pool_eligibility_changed'));
        } elseif ($wave_items > 0 && $wave_items < $max_pool_concurrency) {
            $reason = 'queue_tail_smaller_than_worker_pool';
        } elseif ($selected < min($wave_items, $eligible, $max_pool_concurrency)) {
            $reason = 'worker_reservation_or_selection_race';
        } else {
            $reason = 'full_available_capacity';
        }
    }
    $stats['wave_reason_counts'][$reason] = (int) ($stats['wave_reason_counts'][$reason] ?? 0) + 1;

    $selected_lookup = array_fill_keys($hosts_this_wave, true);
    foreach ((array) ($pool['workers'] ?? []) as $worker_state) {
        if (!is_array($worker_state)) continue;
        $host = sanitize_text_field((string) ($worker_state['worker_host'] ?? ''));
        if ($host === '') continue;
        $status = sanitize_key((string) ($worker_state['status'] ?? 'unknown'));
        if (!isset($stats['worker_wave_state_counts'][$host])) {
            $stats['worker_wave_state_counts'][$host] = [
                'eligible_waves' => 0, 'cooldown_waves' => 0, 'daily_budget_waves' => 0,
                'selected_requests' => 0, 'not_selected_while_eligible' => 0,
                'last_status' => $status, 'last_reason' => '', 'last_http_code' => 0,
                'last_remaining_seconds' => 0,
            ];
        }
        $worker_stats =& $stats['worker_wave_state_counts'][$host];
        if ($status === 'eligible') $worker_stats['eligible_waves']++;
        elseif ($status === 'cooldown') $worker_stats['cooldown_waves']++;
        elseif ($status === 'daily_budget') $worker_stats['daily_budget_waves']++;
        if (isset($selected_lookup[$host])) $worker_stats['selected_requests']++;
        elseif ($status === 'eligible' && $selected >= min($wave_items, $eligible)) $worker_stats['not_selected_while_eligible']++;
        $worker_stats['last_status'] = $status;
        $worker_stats['last_reason'] = sanitize_key((string) ($worker_state['reason'] ?? ''));
        $worker_stats['last_http_code'] = absint($worker_state['http_code'] ?? 0);
        $worker_stats['last_remaining_seconds'] = absint($worker_state['remaining_seconds'] ?? 0);
        unset($worker_stats);
    }

    $state_parts = [];
    foreach ((array) ($pool['workers'] ?? []) as $worker_state) {
        if (!is_array($worker_state)) continue;
        $host = sanitize_text_field((string) ($worker_state['worker_host'] ?? ''));
        $status = sanitize_key((string) ($worker_state['status'] ?? 'unknown'));
        if ($host === '') continue;
        if ($status === 'cooldown') {
            $state_parts[] = $host . ':مکث ' . absint($worker_state['remaining_seconds'] ?? 0) . 'ث/' . (sanitize_key((string) ($worker_state['reason'] ?? 'temporary_worker_error')) ?: 'temporary_worker_error') . (absint($worker_state['http_code'] ?? 0) ? '/HTTP' . absint($worker_state['http_code']) : '');
        } elseif ($status === 'daily_budget') {
            $state_parts[] = $host . ':سقف‌روزانه';
        } elseif ($status === 'eligible' && !isset($selected_lookup[$host]) && $selected < min($wave_items, $eligible)) {
            $state_parts[] = $host . ':آماده‌بود/انتخاب‌نشد';
        }
    }
    $selected_label = !empty($hosts_this_wave) ? implode(',', $hosts_this_wave) : 'هیچ‌کدام';
    $detail = '#' . $wave_index . ': ورودی=' . $wave_items . '، واجدشرایط=' . $eligible . '/' . $configured
        . '، انتخاب=' . $selected . '، علت=' . $reason
        . (isset($wave_context['adaptive_concurrency_after']) ? '، کنترل تطبیقی=' . absint($wave_context['adaptive_concurrency_before'] ?? 2) . '→' . absint($wave_context['adaptive_concurrency_after']) . '، نتیجه=' . sanitize_key((string) ($wave_context['adaptive_outcome'] ?? '')) . '، موفقیت‌متوالی=' . absint($wave_context['adaptive_success_streak'] ?? 0) . '/3' : '')
        . (!empty($state_parts) ? '، کنارگذاشته/وضعیت=' . implode('|', $state_parts) : '')
        . '، Workerهای انتخابی=' . $selected_label;
    $pool_after = is_array($wave_context['pool_state_after'] ?? null) ? $wave_context['pool_state_after'] : [];
    if (!empty($pool_after)) {
        $after_configured = max(0, (int) ($pool_after['configured_count'] ?? $configured));
        $after_eligible = max(0, (int) ($pool_after['eligible_count'] ?? 0));
        $after_cooldown = max(0, (int) ($pool_after['cooldown_count'] ?? 0));
        $after_budget = max(0, (int) ($pool_after['budget_count'] ?? 0));
        $after_parts = [];
        foreach ((array) ($pool_after['workers'] ?? []) as $worker_after) {
            if (!is_array($worker_after)) continue;
            $after_host = sanitize_text_field((string) ($worker_after['worker_host'] ?? ''));
            $after_status = sanitize_key((string) ($worker_after['status'] ?? 'unknown'));
            if ($after_host === '') continue;
            if ($after_status === 'cooldown') {
                $after_parts[] = $after_host . ':مکث ' . absint($worker_after['remaining_seconds'] ?? 0) . 'ث/' . (sanitize_key((string) ($worker_after['reason'] ?? 'temporary_worker_error')) ?: 'temporary_worker_error') . (absint($worker_after['http_code'] ?? 0) ? '/HTTP' . absint($worker_after['http_code']) : '');
            } elseif ($after_status === 'daily_budget') {
                $after_parts[] = $after_host . ':سقف‌روزانه';
            }
        }
        $detail .= '، پس‌ازموج: واجدشرایط=' . $after_eligible . '/' . $after_configured
            . '، مکث=' . $after_cooldown . '، سقف‌روزانه=' . $after_budget
            . (!empty($after_parts) ? ' [' . implode('|', $after_parts) . ']' : '');
    }
    $stats['wave_diagnostics'][] = $detail;
}

/** Return the consolidated source-fetch summary once, for attaching to the final Worker-allocation log. */
function evazar_queue_source_parallel_stats_take_summary() {
    if (!isset($GLOBALS['evazar_queue_source_parallel_stats']) || !is_array($GLOBALS['evazar_queue_source_parallel_stats'])) return '';
    $stats =& $GLOBALS['evazar_queue_source_parallel_stats'];
    if (empty($stats['waves']) || !empty($stats['summary_attached'])) return '';
    $elapsed_ms = !empty($stats['started_at'])
        ? max(0, (int) round((microtime(true) - (float) $stats['started_at']) * 1000))
        : max(0, (int) ($stats['total_wave_elapsed_ms'] ?? 0));
    $seconds = number_format($elapsed_ms / 1000, 1, '.', '');
    $wave_size_counts = (array) ($stats['wave_size_counts'] ?? []);
    krsort($wave_size_counts, SORT_NUMERIC);
    $wave_size_parts = [];
    foreach ($wave_size_counts as $size => $count) {
        $wave_size_parts[] = (int) $count . ' موج ' . (int) $size . 'تایی';
    }
    $worker_counts = (array) ($stats['worker_request_counts'] ?? []);
    arsort($worker_counts, SORT_NUMERIC);
    $worker_parts = [];
    foreach ($worker_counts as $host => $count) {
        $worker_parts[] = sanitize_text_field((string) $host) . '=' . (int) $count;
    }
    $eligible_wave_counts = (array) ($stats['wave_eligible_counts'] ?? []);
    krsort($eligible_wave_counts, SORT_NUMERIC);
    $eligible_wave_parts = [];
    foreach ($eligible_wave_counts as $eligible => $count) {
        $eligible_wave_parts[] = (int) $count . ' موج با ' . (int) $eligible . '/' . (int) ($stats['configured_source_workers'] ?? 0) . ' Worker واجدشرایط';
    }
    $wave_reason_counts = (array) ($stats['wave_reason_counts'] ?? []);
    arsort($wave_reason_counts, SORT_NUMERIC);
    $reason_parts = [];
    foreach ($wave_reason_counts as $reason => $count) {
        $reason_parts[] = sanitize_key((string) $reason) . '=' . (int) $count;
    }
    $worker_state_parts = [];
    foreach ((array) ($stats['worker_wave_state_counts'] ?? []) as $host => $worker_state_counts) {
        if (!is_array($worker_state_counts)) continue;
        $worker_state_parts[] = sanitize_text_field((string) $host)
            . '[آماده=' . (int) ($worker_state_counts['eligible_waves'] ?? 0)
            . '، مکث=' . (int) ($worker_state_counts['cooldown_waves'] ?? 0)
            . '، سقف‌روزانه=' . (int) ($worker_state_counts['daily_budget_waves'] ?? 0)
            . '، انتخاب=' . (int) ($worker_counts[$host] ?? 0)
            . ($worker_state_counts['last_status'] !== '' ? '، وضعیت‌آخر=' . sanitize_key((string) $worker_state_counts['last_status']) : '')
            . (!empty($worker_state_counts['last_reason']) ? '/' . sanitize_key((string) $worker_state_counts['last_reason']) : '')
            . (!empty($worker_state_counts['last_http_code']) ? '/HTTP' . absint($worker_state_counts['last_http_code']) : '')
            . ']';
    }
    $wave_diagnostics = array_slice((array) ($stats['wave_diagnostics'] ?? []), 0, 60);
    $message = '؛ دریافت موازی دیجی‌کالا: Workerهای اصلی تنظیم‌شده=' . (int) ($stats['configured_source_workers'] ?? 0)
        . '؛ واجدشرایط ابتدای اجرا=' . (int) ($stats['eligible_source_workers_at_start'] ?? 0)
        . '؛ هم‌زمانی مؤثر ابتدای اجرا=' . (int) ($stats['source_concurrency_at_start'] ?? 0)
        . '؛ کنترل تطبیقی فعلی=' . (int) evazar_queue_product_source_fetch_concurrency() . '/۵'
        . ' (پیشرفت ارتقا=' . absint(evazar_queue_product_source_adaptive_state()['success_streak'] ?? 0) . '/۳ موج موفق متوالی)'
        . '؛ ' . (int) $stats['requests'] . ' درخواست در ' . (int) $stats['waves'] . ' موج (سقف تطبیقی حداکثر ۵ محصول در هر موج، هر Worker حداکثر یک محصول)'
        . (!empty($wave_size_parts) ? '؛ اندازه موج‌ها: ' . implode('، ', $wave_size_parts) : '')
        . (!empty($eligible_wave_parts) ? '؛ وضعیت واجدشرایط موج‌ها: ' . implode('، ', $eligible_wave_parts) : '')
        . (!empty($reason_parts) ? '؛ علت ظرفیت موج‌ها: ' . implode('، ', $reason_parts) : '')
        . (!empty($worker_parts) ? '؛ توزیع درخواست بین Workerهای اصلی: ' . implode('، ', $worker_parts) : '')
        . (!empty($worker_state_parts) ? '؛ وضعیت تجمعی هر Worker (آماده/مکث/سقف‌روزانه/انتخاب/آخرین وضعیت): ' . implode('، ', $worker_state_parts) : '')
        . (!empty($wave_diagnostics) ? '؛ ریزموج‌ها: ' . implode(' || ', $wave_diagnostics) : '')
        . '؛ پاسخ HTTP از Worker=' . (int) $stats['responses']
        . '؛ انتقال به مسیر جایگزین=' . (int) $stats['fallback_requests']
        . '؛ خطای انتقال=' . (int) $stats['transport_errors']
        . '؛ زمان کل آماده‌سازی=' . $seconds . ' ثانیه.';
    $stats['summary_attached'] = true;
    $stats['total_phase_elapsed_ms'] = $elapsed_ms;
    $stats['worker_request_counts_summary'] = implode('، ', $worker_parts);
    $stats['wave_size_counts_summary'] = implode('، ', $wave_size_parts);
    $stats['wave_eligibility_counts_summary'] = implode('، ', $eligible_wave_parts);
    $stats['wave_reason_counts_summary'] = implode('، ', $reason_parts);
    $stats['worker_availability_summary'] = implode('، ', $worker_state_parts);
    $stats['wave_diagnostics_summary'] = implode(' || ', $wave_diagnostics);
    return $message;
}

/**
 * Prefetch one bounded wave of product data through the configured Cloudflare Workers.
 * Only source responses that should be returned directly are cached for the importer. Worker-level
 * failures that normally trigger failover are marked for the existing serial dispatcher instead.
 * Per-wave details are aggregated and attached to the eventual batch-dispatch log to avoid flooding
 * the Gemini operation report with one log row for every product-source wave.
 */
function evazar_queue_prefetch_product_sources_parallel($items, $max_concurrency = 5) {
    $adaptive_cap = function_exists('evazar_queue_product_source_fetch_concurrency')
        ? evazar_queue_product_source_fetch_concurrency() : 1;
    $max_concurrency = max(1, min(5, absint($max_concurrency), max(1, absint($adaptive_cap))));
    $items = array_slice(array_values((array) $items), 0, $max_concurrency);
    if (empty($items)) return 0;
    $wave_pool_snapshot = function_exists('evazar_queue_product_source_worker_pool_state')
        ? evazar_queue_product_source_worker_pool_state('import_source') : [];
    $wave_started_at = microtime(true);
    $wave_context = [
        'pool_state' => $wave_pool_snapshot,
        'wave_items' => count($items),
        'requested_concurrency' => $max_concurrency,
        'reason' => '',
    ];
    if (!isset($GLOBALS['evazar_queue_prefetched_product_source']) || !is_array($GLOBALS['evazar_queue_prefetched_product_source'])) {
        $GLOBALS['evazar_queue_prefetched_product_source'] = [];
    }

    $work = [];
    $seen_dkps = [];
    foreach ($items as $item) {
        $dkp = preg_replace('/[^0-9]/', '', (string) ($item->dkp ?? ''));
        if ($dkp === '' || isset($seen_dkps[$dkp])) continue;
        $seen_dkps[$dkp] = true;
        $GLOBALS['evazar_queue_prefetched_product_source'][$dkp] = ['mode' => 'fallback', 'request_sent' => false, 'item_id' => absint($item->id ?? 0)];
        $work[] = ['dkp' => $dkp, 'item_id' => absint($item->id ?? 0)];
    }
    if (empty($work)) {
        $wave_context['wave_items'] = count($items);
        $wave_context['reason'] = 'no_valid_unique_dkp';
        evazar_queue_source_parallel_stats_record(0, 0, 0, 0, 0, [], $wave_started_at, $wave_context);
        return 0;
    }
    if (!evazar_queue_parallel_transport_available()) {
        $wave_context['wave_items'] = count($work);
        $wave_context['reason'] = 'parallel_transport_unavailable';
        evazar_queue_source_parallel_stats_record(0, 0, count($work), count($work), 0, [], $wave_started_at, $wave_context);
        return 0;
    }
    $wave_context['wave_items'] = count($work);

    $requests = [];
    $meta = [];
    $used_urls = [];
    $headers = array_merge(['Accept' => 'application/json'], function_exists('evazar_worker_auth_headers') ? evazar_worker_auth_headers() : []);
    foreach ($work as $entry) {
        $worker_url = evazar_queue_product_source_select_worker($used_urls);
        if ($worker_url === '') {
            // Once the selector cannot reserve any further distinct Worker, retrying it for
            // every remaining item only repeats the same checks and can inflate the apparent
            // number of selection attempts. Leave the rest unassigned for the next normal
            // queue iteration; wave diagnostics will show the snapshot and shortfall.
            break;
        }
        $used_urls[] = $worker_url;
        $index = count($requests);
        $url = add_query_arg(['dkp' => $entry['dkp']], trailingslashit($worker_url));
        $requests[$index] = [
            'url' => $url,
            'headers' => $headers,
            'type' => \WpOrg\Requests\Requests::GET,
            'options' => [
                'timeout' => 25,
                'connect_timeout' => 8,
                'verify' => true,
                'verifyname' => true,
                'follow_redirects' => false,
                'redirects' => 0,
                'data_format' => 'body',
            ],
        ];
        $lock_tokens = $GLOBALS['evazar_queue_primary_worker_lock_tokens'] ?? [];
        $meta[$index] = [
            'dkp' => $entry['dkp'], 'item_id' => $entry['item_id'], 'worker_url' => $worker_url,
            'worker_lock_token' => (string) ($lock_tokens[$worker_url] ?? ''),
        ];
        if (isset($GLOBALS['evazar_queue_primary_worker_lock_tokens'][$worker_url])) unset($GLOBALS['evazar_queue_primary_worker_lock_tokens'][$worker_url]);
        $GLOBALS['evazar_queue_prefetched_product_source'][$entry['dkp']] = [
            'mode' => 'fallback', 'request_sent' => true, 'item_id' => $entry['item_id'], 'worker_url' => $worker_url,
        ];
    }
    if (empty($requests)) {
        $pool_state = evazar_queue_product_source_worker_pool_state('import_source');
        $wave_context['pool_state_after'] = $pool_state;
        $wave_context['pool_state'] = $wave_pool_snapshot;
        $wave_context['reason'] = empty($pool_state['eligible_count'])
            ? sanitize_key((string) ($pool_state['code'] ?? 'no_worker_eligible'))
            : 'worker_reservation_or_selection_race';
        if (!empty($work)) {
            // No network request can be sent: cache a no-dispatch signal so the queue releases the
            // unvisited claim tail once, instead of invoking the serial dispatcher for every row.
            if (empty($pool_state['eligible_count'])) {
                $unavailable = [
                    'code' => sanitize_key((string) ($pool_state['code'] ?? 'worker_pool_unavailable')),
                    'detail' => sanitize_text_field((string) ($pool_state['reason'] ?? 'هیچ Worker قابل‌استفاده نیست؛ درخواستی ارسال نشد.')),
                    'configured' => absint($pool_state['configured_count'] ?? 0), 'attempted' => 0,
                    'http_code' => 0, 'worker_host' => '', 'worker_version' => '', 'error_scope' => 'worker',
                    'retry_after_seconds' => max(15, absint($pool_state['retry_after_seconds'] ?? 60)),
                    'cooldown_wait_seconds' => max(15, absint($pool_state['retry_after_seconds'] ?? 60)),
                    'cooldown_skipped' => absint($pool_state['cooldown_count'] ?? 0),
                    'budget_skipped' => absint($pool_state['budget_count'] ?? 0), 'purpose' => 'import_source',
                ];
                foreach ($work as $entry) {
                    $GLOBALS['evazar_queue_prefetched_product_source'][$entry['dkp']] = [
                        'mode' => 'pool_unavailable', 'request_sent' => false, 'item_id' => $entry['item_id'], 'diagnostic' => $unavailable, 'pool_state' => $pool_state,
                    ];
                }
            } else {
                // A request slot reservation can be rejected by a concurrent run even when a fresh
                // snapshot looked available. Never turn that race into one failed product per item.
                $unavailable = ['code' => 'worker_reservation_rejected', 'detail' => 'رزرو ظرفیت Worker رد شد؛ هیچ درخواست شبکه‌ای ارسال نشد.',
                    'configured' => absint($pool_state['configured_count'] ?? 0), 'attempted' => 0, 'http_code' => 0,
                    'worker_host' => '', 'worker_version' => '', 'error_scope' => 'worker', 'retry_after_seconds' => 60,
                    'cooldown_wait_seconds' => 60, 'cooldown_skipped' => absint($pool_state['cooldown_count'] ?? 0),
                    'budget_skipped' => absint($pool_state['budget_count'] ?? 0), 'purpose' => 'import_source'];
                $reservation_state = $pool_state;
                $reservation_state['eligible_count'] = 0;
                $reservation_state['code'] = 'worker_reservation_rejected';
                $reservation_state['reason'] = 'رزرو ظرفیت Worker رد شد؛ هیچ درخواست شبکه‌ای ارسال نشد.';
                $reservation_state['retry_after_seconds'] = 60;
                foreach ($work as $entry) {
                    $GLOBALS['evazar_queue_prefetched_product_source'][$entry['dkp']] = [
                        'mode' => 'pool_unavailable', 'request_sent' => false, 'item_id' => $entry['item_id'], 'diagnostic' => $unavailable, 'pool_state' => $reservation_state,
                    ];
                }
            }
        }
        evazar_queue_source_parallel_stats_record(0, 0, 0, 0, (int) round((microtime(true) - $wave_started_at) * 1000), [], $wave_started_at, $wave_context);
        return 0;
    }

    $started = microtime(true);
    try {
        $responses = \WpOrg\Requests\Requests::request_multiple($requests, [
            'timeout' => 25,
            'connect_timeout' => 8,
            'verify' => true,
            'verifyname' => true,
            'follow_redirects' => false,
            'redirects' => 0,
            'data_format' => 'body',
            'useragent' => 'EVazar-Core-Product-Source-Prefetch/2.9.84.56',
        ]);
    } catch (Throwable $e) {
        // The multi transport outcome is ambiguous. Do not release any lease: a Worker may
        // still be processing its request even though this PHP request threw/timed out.
        // Serial fallback will skip these leased Workers and may use only other free endpoints.
        error_log('[EVazar Core] Parallel product-source prefetch transport failed; retaining uncertain Worker leases and falling back safely.');
        $fallback_hosts = array_values(array_unique(array_map(static function ($entry) {
            $host = wp_parse_url((string) ($entry['worker_url'] ?? ''), PHP_URL_HOST);
            return is_string($host) && $host !== '' ? strtolower($host) : 'unknown-worker';
        }, $meta)));
        $elapsed_ms = (int) round((microtime(true) - $started) * 1000);
        $wave_context['reason'] = 'parallel_transport_exception_serial_fallback';
        $wave_context['pool_state_after'] = function_exists('evazar_queue_product_source_worker_pool_state')
            ? evazar_queue_product_source_worker_pool_state('import_source') : [];
        evazar_queue_source_parallel_stats_record(count($requests), 0, count($requests), count($requests), $elapsed_ms, $fallback_hosts, $started, $wave_context);
        return 0;
    }

    $wave_elapsed_ms = (int) round((microtime(true) - $started) * 1000);
    $prefetched = 0;
    $responded = 0;
    $fallback_requests = 0;
    $transport_errors = 0;
    $adaptive_attempted = 0;
    $adaptive_successes = 0;
    $adaptive_source_failures = 0;
    $adaptive_failure_reason = '';
    foreach ($meta as $index => $request_meta) {
        $response_object = $responses[$index] ?? null;
        // A positive HTTP status proves the endpoint returned. Release only this item's exact
        // lease; missing/transport-failed entries keep their lease until the conservative expiry.
        if (is_object($response_object) && isset($response_object->status_code) && (int) $response_object->status_code > 0) {
            evazar_queue_release_product_source_worker_locks([$request_meta]);
        }
        $response = evazar_queue_product_source_wp_response($response_object);
        if (!is_array($response)) {
            $transport_errors++;
            $fallback_requests++;
            evazar_primary_worker_set_cooldown($request_meta['worker_url'], 90, 'parallel_source_transport_error', 0, 'import_source');
            $GLOBALS['evazar_queue_prefetched_product_source'][$request_meta['dkp']] = [
                'mode' => 'fallback', 'request_sent' => true, 'item_id' => $request_meta['item_id'], 'worker_url' => $request_meta['worker_url'],
                'diagnostic' => [
                    'code' => 'worker_transport_error', 'detail' => 'درخواست به Worker ارسال شد، اما پاسخ انتقالی قابل‌خواندن دریافت نشد.',
                    'configured' => count(function_exists('evazar_get_primary_worker_urls') ? evazar_get_primary_worker_urls() : []),
                    'attempted' => 1, 'http_code' => 0, 'worker_host' => function_exists('evazar_primary_worker_host_label') ? evazar_primary_worker_host_label($request_meta['worker_url']) : (string) wp_parse_url($request_meta['worker_url'], PHP_URL_HOST),
                    'worker_version' => '', 'error_scope' => 'worker', 'elapsed_ms' => $wave_elapsed_ms,
                    'purpose' => 'import_source', 'retry_after_seconds' => 90,
                ],
            ];
            continue;
        }
        $responded++;

        $status = (int) wp_remote_retrieve_response_code($response);
        $scope = evazar_queue_product_source_response_error_scope($response, $status);
        $body = (string) wp_remote_retrieve_body($response);
        $adaptive_attempted++;
        $adaptive_payload = json_decode($body, true);
        if ($scope === 'source' && is_array($adaptive_payload)) {
            $source_error = sanitize_key((string) ($adaptive_payload['error'] ?? ''));
            $upstream_statuses = [absint($adaptive_payload['upstream_status_v2'] ?? 0), absint($adaptive_payload['upstream_status_v1'] ?? 0)];
            $overload = in_array($source_error, ['source_server_error', 'source_rate_limited'], true)
                || (bool) array_filter($upstream_statuses, static function ($v) { return $v === 429 || ($v >= 500 && $v <= 599); });
            if ($overload) { $adaptive_source_failures++; $adaptive_failure_reason = $source_error ?: 'digikala_upstream_http_error'; }
        } elseif ($status >= 200 && $status < 300 && is_array($adaptive_payload)
            && !empty($adaptive_payload['success']) && is_array($adaptive_payload['product'] ?? null) && !empty($adaptive_payload['product'])) {
            $adaptive_successes++;
        }

        // Mirror primary Worker failover semantics: source-scoped failures and product 404s are
        // terminal for this request; Worker/runtime errors and legacy ambiguous 404s use the normal
        // dispatcher, which can safely try a different configured Worker.
        $needs_serial_failover = ($scope !== 'source' && $status === 429)
            || ($scope !== 'source' && $scope !== 'product' && $status === 404)
            || ($scope !== 'source' && in_array($status, [401, 403, 500, 502, 503, 504], true));
        if ($needs_serial_failover) {
            $fallback_requests++;
            $fallback_diagnostic = evazar_queue_product_source_response_diagnostic($response, $request_meta['worker_url'], $wave_elapsed_ms);
            $GLOBALS['evazar_queue_prefetched_product_source'][$request_meta['dkp']] = [
                'mode' => 'fallback', 'request_sent' => true, 'response' => $response,
                'diagnostic' => $fallback_diagnostic, 'item_id' => $request_meta['item_id'], 'worker_url' => $request_meta['worker_url'],
            ];
            if ($status === 429 && $scope !== 'source') {
                $daily_limit = (bool) preg_match('/(?:error\s*1027|daily\s+(?:request\s+)?limit|request limit exceeded|workers.{0,30}daily|quota.{0,20}exceeded)/i', strtolower($body));
                $seconds = 300;
                if ($daily_limit) {
                    $next_utc_day = strtotime(gmdate('Y-m-d', time() + DAY_IN_SECONDS) . ' 00:00:00 UTC');
                    $seconds = max(300, $next_utc_day - time());
                }
                evazar_primary_worker_set_cooldown($request_meta['worker_url'], $seconds, $daily_limit ? 'daily_quota_429' : 'rate_limit_429', 429, 'import_source');
            } else {
                evazar_primary_worker_set_cooldown($request_meta['worker_url'], 90, 'worker_http_' . $status, $status, 'import_source');
            }
            continue;
        }

        $diagnostic = evazar_queue_product_source_response_diagnostic($response, $request_meta['worker_url'], $wave_elapsed_ms);
        $GLOBALS['evazar_queue_prefetched_product_source'][$request_meta['dkp']] = [
            'mode' => 'response',
            'request_sent' => true,
            'response' => $response,
            'diagnostic' => $diagnostic,
            'item_id' => $request_meta['item_id'],
        ];
        $prefetched++;
    }

    $adaptive_state_before = evazar_queue_product_source_adaptive_state();
    // Promotion requires a genuinely full-capacity wave: a short queue tail, duplicate DKP,
    // Worker cooldown, or reservation race must not be counted as proof that this concurrency is stable.
    $adaptive_target_concurrency = evazar_queue_product_source_fetch_concurrency();
    $adaptive_full_wave = count($work) >= $adaptive_target_concurrency
        && count($requests) === $adaptive_target_concurrency
        && $adaptive_attempted === $adaptive_target_concurrency;
    $adaptive_observed_attempts = ($adaptive_source_failures > 0)
        ? $adaptive_attempted : ($adaptive_full_wave ? $adaptive_attempted : 0);
    $adaptive_observed_successes = ($adaptive_source_failures > 0 || !$adaptive_full_wave) ? 0 : $adaptive_successes;
    $adaptive_state_after = evazar_queue_product_source_adaptive_observe_wave(
        $adaptive_observed_successes, $adaptive_source_failures, $adaptive_observed_attempts, $adaptive_failure_reason
    );
    // A brief local settling interval follows a confirmed Digikala-origin overload. This
    // is deliberately not a Worker cooldown: the relay endpoint itself may be healthy.
    if ($adaptive_source_failures > 0 && function_exists('usleep')) {
        usleep(1500000);
    }
    $wave_context['adaptive_concurrency_before'] = absint($adaptive_state_before['concurrency'] ?? 2);
    $wave_context['adaptive_concurrency_after'] = absint($adaptive_state_after['concurrency'] ?? 2);
    $wave_context['adaptive_success_streak'] = absint($adaptive_state_after['success_streak'] ?? 0);
    $wave_context['adaptive_outcome'] = sanitize_key((string) ($adaptive_state_after['last_outcome'] ?? ''));

    $hosts = array_values(array_unique(array_map(static function ($entry) {
        $host = wp_parse_url((string) ($entry['worker_url'] ?? ''), PHP_URL_HOST);
        return is_string($host) && $host !== '' ? strtolower($host) : 'unknown-worker';
    }, $meta)));
    $post_wave_pool = evazar_queue_product_source_worker_pool_state('import_source');
    if (empty($post_wave_pool['eligible_count'])) {
        foreach ($work as $entry) {
            $cached = $GLOBALS['evazar_queue_prefetched_product_source'][$entry['dkp']] ?? [];
            if (!is_array($cached) || ($cached['mode'] ?? '') !== 'fallback') continue;
            if (!empty($cached['request_sent'])) {
                $cached['mode'] = 'worker_failure_deferred';
                $cached['pool_state'] = $post_wave_pool;
                if (!is_array($cached['diagnostic'] ?? null)) {
                    $cached['diagnostic'] = ['code' => 'worker_pool_unavailable', 'detail' => 'درخواست ارسال شد، اما Workerهای باقی‌مانده پس از این موج قابل‌استفاده نبودند.', 'attempted' => 1, 'http_code' => 0, 'error_scope' => 'worker'];
                }
                $cached['diagnostic']['retry_after_seconds'] = max(15, absint($post_wave_pool['retry_after_seconds'] ?? 60));
            } else {
                $cached['mode'] = 'pool_unavailable';
                $cached['pool_state'] = $post_wave_pool;
                $cached['diagnostic'] = [
                    'code' => sanitize_key((string) ($post_wave_pool['code'] ?? 'worker_pool_unavailable')),
                    'detail' => sanitize_text_field((string) ($post_wave_pool['reason'] ?? 'هیچ درخواست دیگری ارسال نشد؛ Worker قابل‌استفاده باقی نمانده است.')),
                    'configured' => absint($post_wave_pool['configured_count'] ?? 0), 'attempted' => 0, 'http_code' => 0,
                    'worker_host' => '', 'worker_version' => '', 'error_scope' => 'worker',
                    'retry_after_seconds' => max(15, absint($post_wave_pool['retry_after_seconds'] ?? 60)),
                    'cooldown_wait_seconds' => max(15, absint($post_wave_pool['retry_after_seconds'] ?? 60)),
                    'cooldown_skipped' => absint($post_wave_pool['cooldown_count'] ?? 0),
                    'budget_skipped' => absint($post_wave_pool['budget_count'] ?? 0), 'purpose' => 'import_source',
                ];
            }
            $GLOBALS['evazar_queue_prefetched_product_source'][$entry['dkp']] = $cached;
        }
    }
    $wave_context['selected_workers'] = $hosts;
    $wave_context['pool_state_after'] = $post_wave_pool;
    $expected_from_snapshot = min(5, absint($wave_pool_snapshot['configured_count'] ?? 0), absint($wave_pool_snapshot['eligible_count'] ?? 0), count($work));
    if (count($requests) < $expected_from_snapshot) {
        $wave_context['reason'] = 'worker_reservation_or_selection_race';
    }
    evazar_queue_source_parallel_stats_record(count($requests), $responded, $fallback_requests, $transport_errors, $wave_elapsed_ms, $hosts, $started, $wave_context);
    // Intentionally no per-wave evazar_gemini_log_event here. The aggregated summary is
    // added to batch_dispatch_wave after the whole source-preparation loop finishes.
    return $prefetched;
}

/** Select distinct ready Workers for a wave, rotating the cursor once in the parent process. */
/** Count distinct Workers currently eligible for a product batch; parallelism is applied by the caller. */
/** True when deferred singleton rows have another ready candidate to pair with. */
function evazar_queue_batch_partner_rows_can_be_claimed($waiting_partner_count, $regular_ready_count) {
    $waiting_partner_count = max(0, absint($waiting_partner_count));
    $regular_ready_count = max(0, absint($regular_ready_count));
    return $waiting_partner_count > 0 && ($waiting_partner_count + $regular_ready_count) >= 2;
}

/** Calculate the per-run claim ceiling from the outer queue cap and currently eligible Workers. */
function evazar_queue_adaptive_claim_capacity($queue_limit, $eligible_workers, $products_per_request, $parallel_enabled = false, $parallelism = 5) {
    $queue_limit = max(1, min(250, absint($queue_limit)));
    $eligible_workers = max(0, absint($eligible_workers));
    $products_per_request = max(2, min(50, absint($products_per_request)));
    if ($eligible_workers < 1) return 0;
    $worker_slots = $parallel_enabled
        ? min($eligible_workers, max(1, min(5, absint($parallelism))))
        : $eligible_workers;
    return min($queue_limit, $worker_slots * $products_per_request);
}

function evazar_queue_parallel_healthy_worker_count() {
    if (!function_exists('evazar_get_gemini_worker_urls')) return 0;
    $workers = evazar_get_gemini_worker_urls();
    if (empty($workers)) return 0;
    if (function_exists('evazar_is_gemini_global_quota_cooldown')
        && evazar_is_gemini_global_quota_cooldown()
        && !(function_exists('evazar_is_manual_gemini_quota_bypass') && evazar_is_manual_gemini_quota_bypass())) {
        return 0;
    }
    $timeout = max(45, (int) get_option('evazar_ai_timeout', 60));
    $count = 0;
    foreach ($workers as $url) {
        if (!is_string($url) || trim($url) === '') continue;
        if (function_exists('evazar_is_gemini_worker_quota_cooldown')
            && evazar_is_gemini_worker_quota_cooldown($url)
            && !(function_exists('evazar_is_manual_gemini_quota_bypass') && evazar_is_manual_gemini_quota_bypass())) continue;
        if (function_exists('evazar_gemini_worker_rate_cooldown_until') && evazar_gemini_worker_rate_cooldown_until($url) > time()) continue;
        if (function_exists('evazar_gemini_worker_lock_until') && evazar_gemini_worker_lock_until($url, $timeout) > time()) continue;
        $count++;
    }
    return $count;
}

function evazar_queue_select_parallel_gemini_workers($wanted) {
    $wanted = max(1, min(5, absint($wanted)));
    if (!function_exists('evazar_get_gemini_worker_urls')) return [];
    $worker_urls = evazar_get_gemini_worker_urls();
    if (count($worker_urls) < 2) return [];
    if (function_exists('evazar_is_gemini_global_quota_cooldown') && evazar_is_gemini_global_quota_cooldown() && !(function_exists('evazar_is_manual_gemini_quota_bypass') && evazar_is_manual_gemini_quota_bypass())) return [];

    $rr_key = 'evz_gemini_worker_rr_' . md5(implode('|', $worker_urls));
    $start = (int) get_transient($rr_key);
    if ($start < 0 || $start >= count($worker_urls)) $start = 0;
    $ordered = array_merge(array_slice($worker_urls, $start), array_slice($worker_urls, 0, $start));
    $timeout = max(45, (int) get_option('evazar_ai_timeout', 60));
    $selected = [];
    foreach ($ordered as $url) {
        if (function_exists('evazar_is_gemini_worker_quota_cooldown') && evazar_is_gemini_worker_quota_cooldown($url) && !(function_exists('evazar_is_manual_gemini_quota_bypass') && evazar_is_manual_gemini_quota_bypass())) continue;
        if (function_exists('evazar_gemini_worker_rate_cooldown_until') && evazar_gemini_worker_rate_cooldown_until($url) > time()) continue;
        if (function_exists('evazar_gemini_worker_lock_until') && evazar_gemini_worker_lock_until($url, $timeout) > time()) continue;
        $selected[] = rtrim((string) $url, '/');
        if (count($selected) >= $wanted) break;
    }
    if (!empty($selected)) {
        $last_position = array_search(end($selected), array_map(function($url) { return rtrim((string) $url, '/'); }, $worker_urls), true);
        if (!is_int($last_position)) $last_position = $start;
        set_transient($rr_key, ($last_position + 1) % count($worker_urls), DAY_IN_SECONDS);
    }
    return $selected;
}

/** Return a short, credential-scrubbed diagnostic excerpt from an internal HTTP error body. */
function evazar_queue_parallel_safe_response_excerpt($body) {
    $body = (string) $body;
    if ($body === '') return '';
    $body = strip_tags($body);
    $body = html_entity_decode($body, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $body = preg_replace('/((?:api[_-]?key|authorization|access[_-]?token|secret|password|token)\s*[:=]\s*)[^\s,;"\']+/i', '$1[redacted]', $body);
    $body = preg_replace('/AIza[0-9A-Za-z_-]{20,}/', '[redacted-api-key]', $body);
    $body = preg_replace('/Bearer\s+[^\s,;]+/i', 'Bearer [redacted]', $body);
    $body = preg_replace('/https?:\/\/[^\s"\']+/i', '[url]', $body);
    $body = preg_replace('/\s+/', ' ', trim($body));
    if (function_exists('mb_substr')) return mb_substr($body, 0, 240, 'UTF-8');
    return substr($body, 0, 480);
}

function evazar_queue_parallel_response_error_payload($error) {
    if (!is_wp_error($error)) return ['code' => 'AI_BATCH_FAILED', 'message' => 'درخواست دسته‌ای ناموفق بود.', 'data' => []];
    $code = $error->get_error_code() ?: 'AI_BATCH_FAILED';
    $data = $error->get_error_data($code);
    $safe_data = [];
    if (is_array($data)) {
        foreach (['resume_at', 'request_id', 'retry_after', 'http_code'] as $key) {
            if (isset($data[$key]) && is_scalar($data[$key])) $safe_data[$key] = $data[$key];
        }
    }
    return ['code' => $code, 'message' => $error->get_error_message(), 'data' => $safe_data];
}

/** Serialize one sub-batch, including only the checkpoint data needed by the child request. */
function evazar_queue_parallel_wire_entries($chunk) {
    $wire = [];
    foreach ((array) $chunk as $entry) {
        $item = $entry['item'] ?? null;
        $checkpoint = $entry['checkpoint'] ?? null;
        if (!$item || !is_array($checkpoint) || !is_array($checkpoint['context'] ?? null)) {
            return new WP_Error('gemini_parallel_payload_invalid', 'یکی از محصولات checkpoint معتبر برای ارسال موازی ندارد.');
        }
        $context = $checkpoint['context'];
        $checkpoint_roundtrip = json_decode((string) wp_json_encode($checkpoint, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), true);
        if (!is_array($checkpoint_roundtrip) || !is_array($checkpoint_roundtrip['context'] ?? null)) {
            return new WP_Error('gemini_parallel_payload_invalid', 'زمینه محصول قابل تبدیل ایمن به JSON نیست.');
        }
        $wire[] = [
            'item' => [
                'id' => absint($item->id ?? 0),
                'dkp' => preg_replace('/[^0-9]/', '', (string) ($item->dkp ?? $checkpoint['dkp'] ?? '')),
                'url' => esc_url_raw((string) ($item->url ?? '')),
                // Preserve retry generation across the signed internal request. The
                // batch request ID must change after an invalid output is finalized.
                'retries' => max(0, (int) ($item->retries ?? 0)),
                'error_code' => strtoupper(sanitize_key((string) ($item->error_code ?? ''))),
                'next_attempt_at' => sanitize_text_field((string) ($item->next_attempt_at ?? '')),
            ],
            'checkpoint' => $checkpoint_roundtrip,
        ];
    }
    return $wire;
}

/** Send several signed internal WordPress sub-requests at once using the bundled Requests multi-transport. */
function evazar_queue_parallel_dispatch_wave($chunks, $assigned_workers) {
    if (!evazar_queue_parallel_transport_available()) {
        return new WP_Error('gemini_parallel_unavailable', 'کتابخانهٔ HTTP چنددرخواستی WordPress در این سرور در دسترس نیست؛ هیچ درخواست Gemini ارسال نشد.');
    }
    $secret = evazar_queue_parallel_batch_signing_secret();
    if ($secret === '') return new WP_Error('gemini_parallel_auth_failed', 'توکن داخلی یا نمک امضای WordPress برای ارتباط موازی تنظیم نشده است؛ هیچ درخواست Gemini ارسال نشد.');
    if (count($chunks) !== count($assigned_workers) || empty($chunks)) {
        return new WP_Error('gemini_parallel_unavailable', 'تعداد دسته‌ها با Workerهای اختصاص‌یافته یکسان نیست؛ هیچ درخواست Gemini ارسال نشد.');
    }

    $endpoint = rest_url('evazar/v1/internal-product-ai-batch');
    if (!is_string($endpoint) || strpos($endpoint, 'https://') !== 0) {
        return new WP_Error('gemini_parallel_unavailable', 'آدرس HTTPS برای endpoint داخلی پردازش موازی معتبر نیست.');
    }
    $timeout = min(180, max(60, (int) get_option('evazar_ai_timeout', 60) + 30));
    if (function_exists('set_time_limit')) @set_time_limit($timeout + 30);
    $requests = [];
    $request_sizes = [];
    foreach (array_values($chunks) as $index => $chunk) {
        $wire_entries = evazar_queue_parallel_wire_entries($chunk);
        if (is_wp_error($wire_entries)) return $wire_entries;
        $payload = ['entries' => $wire_entries, 'assigned_worker_url' => rtrim((string) $assigned_workers[$index], '/')];
        $raw_body = wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($raw_body) || $raw_body === '') return new WP_Error('gemini_parallel_payload_invalid', 'ساخت بدنه JSON برای دسته موازی ناموفق بود.');
        $timestamp = (string) time();
        $nonce = bin2hex(random_bytes(16));
        $signature = hash_hmac('sha256', $timestamp . "\n" . $nonce . "\n" . $raw_body, $secret);
        $request_sizes[$index] = strlen($raw_body);
        $requests[$index] = [
            'url' => $endpoint,
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
                'X-EVazar-Parallel-Timestamp' => $timestamp,
                'X-EVazar-Parallel-Nonce' => $nonce,
                'X-EVazar-Parallel-Signature' => $signature,
            ],
            'data' => $raw_body,
            'type' => \WpOrg\Requests\Requests::POST,
            'options' => [
                'timeout' => $timeout,
                'connect_timeout' => 8,
                'verify' => true,
                'verifyname' => true,
                'follow_redirects' => false,
                'redirects' => 0,
                'data_format' => 'body',
            ],
        ];
    }

    try {
        $responses = \WpOrg\Requests\Requests::request_multiple($requests, [
            'timeout' => $timeout,
            'connect_timeout' => 8,
            'verify' => true,
            'verifyname' => true,
            'follow_redirects' => false,
            'redirects' => 0,
            'data_format' => 'body',
            'useragent' => 'EVazar-Core-Parallel-Batch/2.9.56',
        ]);
    } catch (Throwable $e) {
        error_log('[EVazar Core] Parallel sub-batch transport failed; all dispatched outcomes treated as uncertain.');
        $failed = [];
        foreach (array_keys($chunks) as $index) {
            $failed[$index] = new WP_Error('gemini_request_outcome_unknown', 'ارتباط چنددرخواستی قطع شد؛ برای جلوگیری از ارسال مجدد و مصرف تکراری، نتیجه این دسته نامشخص ثبت شد.');
        }
        return $failed;
    }

    $out = [];
    foreach (array_keys($chunks) as $index) {
        $response = $responses[$index] ?? null;
        if (!is_object($response) || !isset($response->status_code)) {
            $out[$index] = new WP_Error('gemini_request_outcome_unknown', 'پاسخ endpoint داخلی دریافت نشد؛ ممکن است دسته اجرا شده باشد، بنابراین ارسال تکراری انجام نمی‌شود.');
            continue;
        }
        $status = (int) $response->status_code;
        $body = isset($response->body) ? (string) $response->body : '';
        if ($status !== 200) {
            if (in_array($status, [400, 401, 403, 404, 405, 413], true)) {
                $error_code = in_array($status, [401, 403], true) ? 'gemini_parallel_auth_failed' : 'gemini_parallel_unavailable';
                $message = 'endpoint داخلی پردازش موازی پاسخ HTTP ' . $status . ' داد؛ درخواست Gemini از این مسیر تأیید نشد.';
                $diagnostic_data = ['resume_at' => time() + 60, 'http_code' => $status, 'request_bytes' => (int) ($request_sizes[$index] ?? 0)];
                if ($status === 413) {
                    $excerpt_source = $body;
                    $decoded_error = json_decode($body, true);
                    if (is_array($decoded_error)) {
                        $remote_code = sanitize_key((string) ($decoded_error['code'] ?? ''));
                        $remote_message = sanitize_textarea_field((string) ($decoded_error['message'] ?? ''));
                        if ($remote_code !== '') $diagnostic_data['endpoint_error_code'] = $remote_code;
                        if ($remote_message !== '') $excerpt_source = $remote_message;
                        if ($remote_code === 'evazar_parallel_payload_invalid') $diagnostic_data['diagnostic_code'] = 'wordpress_internal_payload_limit';
                    }
                    $excerpt = evazar_queue_parallel_safe_response_excerpt($excerpt_source);
                    $message .= ' اندازه بدنه درخواست: ' . number_format_i18n((int) ($request_sizes[$index] ?? 0)) . ' بایت.';
                    if ($excerpt !== '') $message .= ' پاسخ کوتاه سرور: ' . $excerpt;
                    if (empty($diagnostic_data['diagnostic_code'])) $diagnostic_data['diagnostic_code'] = 'internal_endpoint_http_413';
                    $diagnostic_data['response_excerpt'] = $excerpt;
                    $diagnostic_data['request_limit_bytes'] = 4194304;
                }
                $error = new WP_Error($error_code, $message);
                $error->add_data($diagnostic_data);
                $out[$index] = $error;
            } else {
                $out[$index] = new WP_Error('gemini_request_outcome_unknown', 'endpoint داخلی پاسخ HTTP ' . $status . ' داد؛ نتیجهٔ فراخوانی Gemini قطعی نیست و ارسال مجدد خودکار متوقف شد.');
            }
            continue;
        }
        $decoded = json_decode($body, true);
        if (!is_array($decoded)) {
            $out[$index] = new WP_Error('gemini_request_outcome_unknown', 'بدنه endpoint داخلی JSON معتبر نبود؛ برای جلوگیری از ارسال تکراری، دسته نامشخص باقی ماند.');
            continue;
        }
        if (empty($decoded['success'])) {
            $error = is_array($decoded['error'] ?? null) ? $decoded['error'] : [];
            $code = sanitize_key((string) ($error['code'] ?? 'AI_BATCH_FAILED'));
            $message = sanitize_textarea_field((string) ($error['message'] ?? 'درخواست دسته‌ای داخلی ناموفق بود.'));
            $wp_error = new WP_Error($code, $message);
            $data = is_array($error['data'] ?? null) ? $error['data'] : [];
            if (!empty($data)) $wp_error->add_data($data);
            $out[$index] = $wp_error;
            continue;
        }
        if (!is_array($decoded['responses'] ?? null)) {
            $out[$index] = new WP_Error('gemini_request_outcome_unknown', 'پاسخ داخلی موفق اعلام شد اما فهرست نتایج وجود نداشت؛ ارسال تکراری متوقف شد.');
            continue;
        }
        $mapped = [];
        foreach ($decoded['responses'] as $dkp => $value) {
            $dkp = preg_replace('/[^0-9]/', '', (string) $dkp);
            if ($dkp === '') continue;
            if (is_array($value) && !empty($value['__evazar_error'])) {
                $code = sanitize_key((string) ($value['code'] ?? 'AI_BATCH_ITEM_FAILED'));
                $error = new WP_Error($code, sanitize_textarea_field((string) ($value['message'] ?? 'تولید محتوای محصول ناموفق بود.')));
                if (is_array($value['data'] ?? null) && !empty($value['data'])) $error->add_data($value['data']);
                $mapped[$dkp] = $error;
            } else {
                $mapped[$dkp] = $value;
            }
        }
        $out[$index] = $mapped;
    }
    return $out;
}

/** Process a returned parallel wave without allowing one failed chunk to discard successful sibling results. */
function evazar_queue_process_parallel_product_chunks($batch_pending, $claim_token, &$success_cnt, &$failed_cnt, &$deferred_cnt) {
    $partition = evazar_queue_partition_product_batches((array) $batch_pending, evazar_queue_product_batch_size());
    $chunks = $partition['chunks'];
    if (!empty($partition['unpaired'])) {
        $waiting = evazar_queue_defer_batch_partner_entries($partition['unpaired'], $claim_token);
        $deferred_cnt += (int) ($waiting['deferred'] ?? count($partition['unpaired']));
    }
    if (empty($chunks)) return ['halted' => !empty($partition['unpaired']), 'message' => 'محصول منتظر شریک دسته‌ای است و با رسیدن موعد تلاش مجدد به‌صورت کنترل‌شده پردازش می‌شود.'];
    $processable_entries = [];
    foreach ($chunks as $processable_chunk) $processable_entries = array_merge($processable_entries, $processable_chunk);
    if (!evazar_queue_parallel_transport_available() || evazar_queue_parallel_batch_signing_secret() === '') {
        $error_code = evazar_queue_parallel_transport_available() ? 'gemini_parallel_auth_failed' : 'gemini_parallel_unavailable';
        $error = new WP_Error($error_code, 'پیش‌نیاز اجرای موازی فراهم نیست؛ هیچ درخواست Gemini ارسال نشد.');
        $deferred_cnt += count($processable_entries);
        evazar_queue_defer_batched_items($processable_entries, $error, $claim_token);
        return ['halted' => true, 'message' => $error->get_error_message()];
    }
    $all_workers = function_exists('evazar_get_gemini_worker_urls') ? evazar_get_gemini_worker_urls() : [];
    if (count($all_workers) < 2) {
        $error = new WP_Error('gemini_parallel_unavailable', 'برای پردازش موازی دست‌کم دو Worker معتبر Gemini لازم است.');
        $deferred_cnt += count($processable_entries);
        evazar_queue_defer_batched_items($processable_entries, $error, $claim_token);
        return ['halted' => true, 'message' => $error->get_error_message()];
    }

    $chunk_offset = 0;
    while ($chunk_offset < count($chunks)) {
        evazar_queue_heartbeat_run_lock();
        if (evazar_queue_is_manually_paused()) {
            evazar_queue_release_manual_pause_claims($claim_token);
            return ['halted' => true, 'message' => 'توقف دستی صف بین دو موج اعمال شد؛ دسته‌های ارسال‌نشده به صف انتظار برگشتند.'];
        }
        $wanted = min(evazar_queue_product_batch_parallelism(), count($chunks) - $chunk_offset, count($all_workers));
        $assigned = evazar_queue_select_parallel_gemini_workers($wanted);
        if (empty($assigned)) {
            $remaining_chunks = array_slice($chunks, $chunk_offset);
            $remaining_entries = [];
            foreach ($remaining_chunks as $remaining_chunk) $remaining_entries = array_merge($remaining_entries, $remaining_chunk);
            if (empty($remaining_entries)) break;
            $error = new WP_Error('gemini_workers_busy', 'در حال حاضر Worker سالم و آزادی برای موج موازی موجود نیست؛ دسته‌های ارسال‌نشده به تعویق افتادند.');
            $error->add_data(['resume_at' => time() + 45]);
            evazar_queue_defer_batched_items($remaining_entries, $error, $claim_token);
            $deferred_cnt += count($remaining_entries);
            return ['halted' => true, 'message' => $error->get_error_message()];
        }
        $wave_chunks = array_slice($chunks, $chunk_offset, count($assigned));
        if (function_exists('evazar_gemini_log_event')) {
            $assigned_hosts = array_map(function($url) {
                $host = wp_parse_url((string) $url, PHP_URL_HOST);
                return is_string($host) && $host !== '' ? $host : 'unknown-worker';
            }, $assigned);
            $wave_products = 0;
            foreach ($wave_chunks as $wave_chunk) $wave_products += count($wave_chunk);
            $dispatch_message = 'تخصیص خودکار دسته‌ها: ' . count($wave_chunks) . ' درخواست؛ ' . $wave_products . ' محصول؛ Workerهای انتخاب‌شده: ' . implode(', ', $assigned_hosts);
            $dispatch_context = ['purpose' => 'product_import_batch', 'batch_size' => min(50, max(2, count($wave_chunks[0] ?? [])))];
            if (function_exists('evazar_queue_source_parallel_stats_take_summary')) {
                $source_summary = evazar_queue_source_parallel_stats_take_summary();
                if ($source_summary !== '') {
                    $dispatch_message .= $source_summary;
                    $source_stats = $GLOBALS['evazar_queue_source_parallel_stats'] ?? [];
                    $dispatch_context['source_fetch_waves'] = absint($source_stats['waves'] ?? 0);
                    $dispatch_context['source_fetch_requests'] = absint($source_stats['requests'] ?? 0);
                    $dispatch_context['source_fetch_responses'] = absint($source_stats['responses'] ?? 0);
                    $dispatch_context['source_fetch_fallback_requests'] = absint($source_stats['fallback_requests'] ?? 0);
                    $dispatch_context['source_fetch_transport_errors'] = absint($source_stats['transport_errors'] ?? 0);
                    $dispatch_context['source_fetch_elapsed_ms'] = absint($source_stats['total_phase_elapsed_ms'] ?? 0);
                    $dispatch_context['source_fetch_configured_workers'] = absint($source_stats['configured_source_workers'] ?? 0);
                    $dispatch_context['source_fetch_eligible_workers_at_start'] = absint($source_stats['eligible_source_workers_at_start'] ?? 0);
                    $dispatch_context['source_fetch_effective_concurrency_at_start'] = absint($source_stats['source_concurrency_at_start'] ?? 0);
                    $dispatch_context['source_fetch_worker_distribution'] = (string) ($source_stats['worker_request_counts_summary'] ?? '');
                    $dispatch_context['source_fetch_wave_size_distribution'] = (string) ($source_stats['wave_size_counts_summary'] ?? '');
                    $dispatch_context['source_fetch_wave_eligibility_distribution'] = (string) ($source_stats['wave_eligibility_counts_summary'] ?? '');
                    $dispatch_context['source_fetch_wave_reason_distribution'] = (string) ($source_stats['wave_reason_counts_summary'] ?? '');
                    $dispatch_context['source_fetch_worker_availability_summary'] = (string) ($source_stats['worker_availability_summary'] ?? '');
                    $dispatch_context['source_fetch_wave_diagnostics'] = (string) ($source_stats['wave_diagnostics_summary'] ?? '');
                }
            }
            $claim_diagnostic = $GLOBALS['evazar_queue_batch_claim_diagnostics'] ?? [];
            $claim_context = is_array($claim_diagnostic['context'] ?? null) ? $claim_diagnostic['context'] : [];
            $ready_products = count((array) $batch_pending);
            $dispatch_message .= '؛ جمع‌بندی آماده‌سازی: سقف صف=' . (int) ($claim_context['run_capacity'] ?? 0)
                . '؛ واجدشرایط پیش از Claim=' . ((int) ($claim_context['eligible_pending'] ?? -1) >= 0 ? (int) $claim_context['eligible_pending'] : 'نامشخص')
                . '؛ ردیف Claim‌شده و بارگذاری‌شده=' . ((int) ($claim_context['claim_loaded_rows'] ?? 0))
                . '؛ آمادهٔ Gemini=' . $ready_products
                . '؛ خطا پیش از Gemini=' . max(0, (int) $failed_cnt)
                . '؛ تعویق ثبت‌شده تا این نقطه=' . max(0, (int) $deferred_cnt) . '.';
            foreach (['run_capacity', 'pending_total', 'pending_due', 'pending_not_due', 'processing_before_claim', 'eligible_pending', 'claim_updated_rows', 'claim_loaded_rows', 'claim_unfilled_capacity'] as $claim_metric) {
                if (isset($claim_context[$claim_metric])) $dispatch_context['queue_' . $claim_metric] = (int) $claim_context[$claim_metric];
            }
            $dispatch_context['queue_source_ready_products'] = $ready_products;
            $dispatch_context['queue_pre_gemini_success'] = max(0, (int) $success_cnt);
            $dispatch_context['queue_pre_gemini_failed'] = max(0, (int) $failed_cnt);
            $dispatch_context['queue_pre_gemini_deferred'] = max(0, (int) $deferred_cnt);
            evazar_gemini_log_event('batch_dispatch_wave', $dispatch_message, '', 0, 0, $dispatch_context);
        }
        $adaptive_batch_size_before_wave = evazar_queue_product_batch_size();
        $wave_responses = evazar_queue_parallel_dispatch_wave($wave_chunks, $assigned);
        // Adapt only from explicit upstream Gemini errors; internal endpoint/transport failures
        // and uncertain outcomes are intentionally excluded from the controller.
        evazar_queue_product_batch_adaptive_observe_wave($wave_chunks, $wave_responses);
        if (is_wp_error($wave_responses)) {
            $remaining_chunks = array_slice($chunks, $chunk_offset);
            $remaining_entries = [];
            foreach ($remaining_chunks as $remaining_chunk) $remaining_entries = array_merge($remaining_entries, $remaining_chunk);
            $deferred_cnt += count($remaining_entries);
            evazar_queue_defer_batched_items($remaining_entries, $wave_responses, $claim_token);
            return ['halted' => true, 'message' => $wave_responses->get_error_message()];
        }

        $stop_after_wave = false;
        $wave_pause_error = null;
        foreach ($wave_chunks as $local_index => $chunk) {
            $chunk_response = $wave_responses[$local_index] ?? new WP_Error('gemini_request_outcome_unknown', 'نتیجهٔ موج موازی برای این دسته ثبت نشد؛ از ارسال مجدد خودکار جلوگیری شد.');
            if (is_wp_error($chunk_response)) {
                $code = $chunk_response->get_error_code();
                // The internal REST error serializer sanitizes error codes to lowercase.
                // Normalize only for this comparison; pause/error codes elsewhere stay lowercase.
                if (in_array(strtoupper((string) $code), ['AI_BATCH_OUTPUT_INVALID', 'AI_BATCH_INVALID_JSON'], true)) {
                    // Invalid model JSON is a batch-output/validation failure, not a per-product
                    // failure. Return only this already-sent chunk to pending without incrementing
                    // retries; later chunks in the same wave remain eligible to proceed.
                    evazar_queue_defer_batched_items($chunk, $chunk_response, $claim_token, (string) ($assigned[$local_index] ?? ''));
                    $deferred_cnt += count($chunk);
                    if (function_exists('evazar_gemini_log_event')) {
                        evazar_gemini_log_event('batch_json_invalid_deferred', 'خروجی JSON دسته Gemini نامعتبر بود؛ فقط همین دسته بدون افزایش Retry برای تلاش دسته‌ای بعدی به صف برگشت و پردازش دسته‌های دیگر ادامه یافت.', '', 200, (int) (($chunk_response->get_error_data()['resume_at'] ?? 0)), [
                            'purpose' => 'product_import_batch', 'batch_size' => count($chunk), 'diagnostic_code' => 'batch_json_invalid', 'retry' => 1,
                        ]);
                    }
                } elseif ($code === 'gemini_request_outcome_unknown') {
                    evazar_queue_log_batch_deferred_event($chunk, $chunk_response, time() + 120, (string) ($assigned[$local_index] ?? ''), 'نتیجه نامشخص؛ ایمنی جلوگیری از ارسال تکراری فعال شد');
                    foreach ($chunk as $entry) {
                        $final = evazar_queue_finalize_batched_result($entry['item'], $chunk_response, $claim_token);
                        if (($final['kind'] ?? '') === 'failed_unknown') $failed_cnt++;
                        elseif (($final['kind'] ?? '') === 'success') $success_cnt++;
                        elseif (($final['kind'] ?? '') === 'deferred') $deferred_cnt++;
                        else $failed_cnt++;
                    }
                } elseif (evazar_queue_is_gemini_pause_error($chunk_response)) {
                    evazar_queue_defer_batched_items($chunk, $chunk_response, $claim_token, (string) ($assigned[$local_index] ?? ''));
                    $deferred_cnt += count($chunk);
                    $wave_pause_error = $chunk_response;
                    if ($code === 'gemini_parallel_unavailable' || $code === 'gemini_parallel_auth_failed' || $code === 'gemini_ledger_storage_error') $stop_after_wave = true;
                } else {
                    // Keep the precise malformed-output code after a parallel child response;
                    // this helps the queue/admin diagnostics distinguish bad model JSON from transport errors.
                    $batch_error = ($code === 'AI_BATCH_OUTPUT_INVALID')
                        ? $chunk_response
                        : new WP_Error('AI_BATCH_FAILED', 'درخواست دسته‌ای Gemini ناموفق بود: ' . $chunk_response->get_error_message());
                    foreach ($chunk as $entry) {
                        $final = evazar_queue_finalize_batched_result($entry['item'], $batch_error, $claim_token);
                        if (($final['kind'] ?? '') === 'success') $success_cnt++;
                        elseif (($final['kind'] ?? '') === 'deferred') $deferred_cnt++;
                        else $failed_cnt++;
                    }
                }
                continue;
            }

            foreach ($chunk as $entry) {
                $item = $entry['item'];
                $checkpoint = $entry['checkpoint'];
                $dkp = preg_replace('/[^0-9]/', '', (string) ($checkpoint['dkp'] ?? $item->dkp));
                $ai_response = $chunk_response[$dkp] ?? new WP_Error('AI_BATCH_MISSING_RESPONSE', 'برای محصول ' . $dkp . ' خروجی مستقل از Gemini دریافت نشد.');
                if (is_wp_error($ai_response) && evazar_queue_is_gemini_pause_error($ai_response)) {
                    evazar_queue_defer_batched_items([$entry], $ai_response, $claim_token);
                    $deferred_cnt++;
                    $wave_pause_error = $ai_response;
                    if (in_array($ai_response->get_error_code(), ['gemini_parallel_unavailable', 'gemini_parallel_auth_failed', 'gemini_ledger_storage_error'], true)) $stop_after_wave = true;
                    continue;
                }
                if (is_wp_error($ai_response)) {
                    if ($ai_response->get_error_code() === 'gemini_request_outcome_unknown') {
                        $result = $ai_response;
                    } else {
                        $result = new WP_Error('AI_BATCH_ITEM_FAILED', 'تولید محتوای محصول در مرحلهٔ دسته‌ای ناموفق بود: ' . $ai_response->get_error_message());
                    }
                } else {
                    $resume_bundle = [
                        'context' => $checkpoint['context'],
                        'expected_matching_ids' => (array) ($checkpoint['expected_matching_ids'] ?? []),
                    ];
                    $result = evazar_core_process_import($item->dkp, $resume_bundle, $ai_response);
                }
                $final = evazar_queue_finalize_batched_result($item, $result, $claim_token);
                if (($final['kind'] ?? '') === 'pause') {
                    evazar_queue_defer_batched_items([$entry], $final['error'], $claim_token);
                    $deferred_cnt++;
                    $wave_pause_error = $final['error'];
                    if (in_array($final['error']->get_error_code(), ['gemini_parallel_unavailable', 'gemini_parallel_auth_failed', 'gemini_ledger_storage_error'], true)) $stop_after_wave = true;
                } elseif (($final['kind'] ?? '') === 'success') {
                    $success_cnt++;
                } elseif (($final['kind'] ?? '') === 'deferred') {
                    $deferred_cnt++;
                } else {
                    $failed_cnt++;
                }
            }
        }

        $chunk_offset += count($wave_chunks);
        $adaptive_batch_size_after_wave = evazar_queue_product_batch_size();
        $adaptive_repartition = evazar_queue_product_batch_adaptive_repartition_chunks(
            $chunks,
            $chunk_offset,
            $adaptive_batch_size_after_wave !== $adaptive_batch_size_before_wave
        );
        if (!empty($adaptive_repartition['repartitioned'])) {
            $chunks = (array) $adaptive_repartition['chunks'];
            if (!empty($adaptive_repartition['unpaired'])) {
                $waiting = evazar_queue_defer_batch_partner_entries($adaptive_repartition['unpaired'], $claim_token);
                $deferred_cnt += (int) ($waiting['deferred'] ?? count($adaptive_repartition['unpaired']));
            }
            if (function_exists('evazar_gemini_log_event')) {
                evazar_gemini_log_event(
                    'adaptive_batch_adjusted',
                    'دسته‌های ارسال‌نشده پس از تغییر ظرفیت تطبیقی دوباره تقسیم شدند؛ هیچ دسته ارسال‌شده مجدداً ارسال نشد.',
                    '', 0, 0,
                    [
                        'purpose' => 'product_import_batch',
                        'adaptive_reason' => 'unsent_tail_repartition',
                        'effective_batch_size' => (int) ($adaptive_repartition['effective_batch_size'] ?? $adaptive_batch_size_after_wave),
                        'remaining_chunks' => max(0, count($chunks) - $chunk_offset),
                        'unpaired_deferred' => count((array) ($adaptive_repartition['unpaired'] ?? [])),
                    ]
                );
            }
        }
        $global_pause = function_exists('evazar_is_gemini_global_quota_cooldown') && evazar_is_gemini_global_quota_cooldown();
        if ($global_pause) {
            $stop_after_wave = true;
            if (!$wave_pause_error) {
                $wave_pause_error = new WP_Error('gemini_quota_cooldown', 'سهمیه روزانه همه Workerهای Gemini به پایان رسیده است.');
                $wave_pause_error->add_data(['resume_at' => function_exists('evazar_get_gemini_global_quota_cooldown_until') ? evazar_get_gemini_global_quota_cooldown_until() : time() + DAY_IN_SECONDS]);
            }
        }
        if ($stop_after_wave && $chunk_offset < count($chunks)) {
            $remaining_chunks = array_slice($chunks, $chunk_offset);
            $remaining_entries = [];
            foreach ($remaining_chunks as $remaining_chunk) $remaining_entries = array_merge($remaining_entries, $remaining_chunk);
            if (!empty($remaining_entries)) {
                $defer_error = $wave_pause_error ?: new WP_Error('gemini_parallel_unavailable', 'موج بعدی به دلیل خطای عملیاتی ارسال نشد.');
                evazar_queue_defer_batched_items($remaining_entries, $defer_error, $claim_token);
                $deferred_cnt += count($remaining_entries);
            }
            return ['halted' => true, 'message' => $wave_pause_error ? $wave_pause_error->get_error_message() : 'موج بعدی اجرا نشد.'];
        }
    }
    return ['halted' => false];
}

function evazar_queue_is_gemini_pause_error($error) {
    if (!is_wp_error($error)) return false;
    return in_array($error->get_error_code(), ['evazar_queue_manually_paused', 'gemini_quota_cooldown', 'gemini_rate_limited', 'gemini_temporary_unavailable', 'gemini_quota_probe_busy', 'gemini_workers_busy', 'gemini_batch_in_progress', 'gemini_ledger_storage_error', 'gemini_parallel_unavailable', 'gemini_parallel_auth_failed', 'gemini_worker_auth_failed'], true);
}

/** Log one safe, structured Gemini batch deferral event. Never persist raw response bodies or prompts. */
function evazar_queue_log_batch_deferred_event($entries, $error, $resume_at = 0, $worker_url = '', $detail_prefix = '') {
    if (!function_exists('evazar_gemini_log_event')) return;
    $entries = (array) $entries;
    $err_code = is_wp_error($error) ? ($error->get_error_code() ?: 'UNKNOWN') : 'AI_BATCH_FAILED';
    $error_data = is_wp_error($error) ? $error->get_error_data($err_code) : null;
    $error_data = is_array($error_data) ? $error_data : [];
    $http_code = absint($error_data['http_code'] ?? $error_data['status'] ?? $error_data['status_code'] ?? 0);
    if ($http_code < 100 || $http_code > 599) $http_code = 0;
    $error_detail = is_wp_error($error) ? sanitize_textarea_field($error->get_error_message()) : 'جزئیات خطا در دسترس نیست';
    $error_detail = preg_replace('/((?:api[_-]?key|authorization|access[_-]?token|secret|password)\s*[:=]\s*)[^\s,;]+/i', '$1[redacted]', (string) $error_detail);
    $error_detail = preg_replace('/AIza[0-9A-Za-z_-]{20,}/', '[redacted-api-key]', $error_detail);
    if (!$http_code && preg_match('/\bHTTP\s*([1-5][0-9]{2})\b/i', $error_detail, $http_match)) $http_code = (int) $http_match[1];
    if (function_exists('mb_substr')) $error_detail = mb_substr($error_detail, 0, 400, 'UTF-8');
    else $error_detail = substr($error_detail, 0, 800);

    if ($worker_url === '') {
        foreach (['worker_url', 'assigned_worker_url', 'url'] as $worker_key) {
            $candidate = isset($error_data[$worker_key]) && is_scalar($error_data[$worker_key]) ? esc_url_raw((string) $error_data[$worker_key]) : '';
            if ($candidate !== '' && preg_match('#^https?://#i', $candidate)) { $worker_url = $candidate; break; }
        }
    }
    $dkps = [];
    foreach ($entries as $diagnostic_entry) {
        $diagnostic_item = $diagnostic_entry['item'] ?? null;
        $diagnostic_dkp = preg_replace('/[^0-9]/', '', (string) ($diagnostic_item->dkp ?? $diagnostic_entry['checkpoint']['dkp'] ?? ''));
        if ($diagnostic_dkp !== '') $dkps[] = $diagnostic_dkp;
    }
    $dkps = array_values(array_unique($dkps));
    $resume_label = $resume_at > 0 ? (function_exists('evazar_queue_local_datetime') ? evazar_queue_local_datetime($resume_at) : date('Y-m-d H:i:s', $resume_at)) : 'زمان تلاش مجدد نامشخص';
    $extra_diagnostics = [];
    if (isset($error_data['request_bytes']) && is_numeric($error_data['request_bytes'])) $extra_diagnostics[] = 'اندازه درخواست: ' . number_format_i18n(max(0, (int) $error_data['request_bytes'])) . ' بایت';
    if (isset($error_data['request_limit_bytes']) && is_numeric($error_data['request_limit_bytes'])) $extra_diagnostics[] = 'سقف بررسی‌شده: ' . number_format_i18n(max(0, (int) $error_data['request_limit_bytes'])) . ' بایت';
    if (!empty($error_data['endpoint_error_code']) && is_scalar($error_data['endpoint_error_code'])) $extra_diagnostics[] = 'کد endpoint: ' . sanitize_key((string) $error_data['endpoint_error_code']);
    if (!empty($error_data['response_excerpt']) && is_scalar($error_data['response_excerpt'])) {
        $excerpt = evazar_queue_parallel_safe_response_excerpt((string) $error_data['response_excerpt']);
        if ($excerpt !== '') $extra_diagnostics[] = 'پاسخ سرور: ' . $excerpt;
    }
    $detail = trim(($detail_prefix !== '' ? $detail_prefix . '؛ ' : '') . 'کد: ' . $err_code . '؛ HTTP: ' . ($http_code ?: 'نامشخص') . '؛ زمان تلاش مجدد: ' . $resume_label . (empty($extra_diagnostics) ? '' : '؛ ' . implode('؛ ', $extra_diagnostics)) . '؛ جزئیات: ' . $error_detail);
    $context = [
        'purpose' => 'product_import_batch',
        'batch_size' => min(50, count($entries)),
        'dkps' => array_slice($dkps, 0, 50),
        'error_stage' => 'batch_defer',
        'error_code' => $err_code,
        'diagnostic_code' => sanitize_key($err_code),
        'diagnostic_detail' => $detail,
    ];
    foreach (['request_id', 'batch_id'] as $correlation_key) {
        if (!empty($error_data[$correlation_key]) && is_scalar($error_data[$correlation_key])) $context[$correlation_key] = (string) $error_data[$correlation_key];
    }
    $message = count($entries) . ' محصول به علت ' . sanitize_text_field($detail_prefix !== '' ? $detail_prefix : $err_code) . ' به صف بازگشت.';
    evazar_gemini_log_event('queue_batch_deferred', $message, $worker_url, $http_code, max(0, (int) $resume_at), $context);
}

/** Return queue rows held by a failed batch to pending without incrementing retries. */
function evazar_queue_defer_batched_items($entries, $error, $claim_token, $worker_url = '') {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    $err_code = is_wp_error($error) ? $error->get_error_code() : 'AI_BATCH_FAILED';
    $data = is_wp_error($error) ? $error->get_error_data($err_code) : null;
    $resume_at = is_array($data) && !empty($data['resume_at']) ? (int) $data['resume_at'] : 0;
    if ($resume_at <= time() && $err_code === 'gemini_rate_limited' && function_exists('evazar_gemini_rate_cooldown_until')) {
        $resume_at = (int) evazar_gemini_rate_cooldown_until();
    }
    if ($resume_at <= time() && $err_code !== 'gemini_quota_probe_busy' && function_exists('evazar_get_gemini_global_quota_cooldown_until')) {
        $resume_at = (int) evazar_get_gemini_global_quota_cooldown_until();
    }
    if ($resume_at <= time()) {
        // Known daily quota waits use the persisted Cloudflare/Gemini reset timestamp above.
        // Any other missing retry metadata must not strand the batch for a whole day.
        $resume_at = time() + (($err_code === 'gemini_quota_cooldown') ? 300 : 60);
    }

    $resume_mysql = evazar_queue_mysql_timestamp($resume_at);
    $resume_label = ($err_code === 'gemini_quota_cooldown')
        ? (function_exists('evazar_gemini_quota_reset_label') ? evazar_gemini_quota_reset_label($resume_at) : $resume_mysql)
        : (evazar_queue_local_datetime($resume_at) ?: $resume_mysql);
    $queue_code_map = [
        'gemini_quota_cooldown' => 'GEMINI_QUOTA_COOLDOWN',
        'gemini_rate_limited' => 'GEMINI_RATE_LIMITED',
        'gemini_temporary_unavailable' => 'GEMINI_TEMPORARY_UNAVAILABLE',
        'gemini_quota_probe_busy' => 'GEMINI_QUOTA_PROBE_BUSY',
        'gemini_workers_busy' => 'GEMINI_WORKERS_BUSY',
        'gemini_batch_in_progress' => 'GEMINI_BATCH_IN_PROGRESS',
        'gemini_ledger_storage_error' => 'GEMINI_LEDGER_STORAGE_ERROR',
        'gemini_parallel_auth_failed' => 'GEMINI_PARALLEL_AUTH_FAILED',
        'gemini_parallel_unavailable' => 'GEMINI_PARALLEL_UNAVAILABLE',
        'gemini_worker_auth_failed' => 'GEMINI_WORKER_AUTH_FAILED',
        'AI_BATCH_OUTPUT_INVALID' => 'GEMINI_BATCH_JSON_INVALID',
        'AI_BATCH_INVALID_JSON' => 'GEMINI_BATCH_JSON_INVALID',
    ];
    $queue_code = $queue_code_map[$err_code] ?? ($queue_code_map[strtoupper($err_code)] ?? 'GEMINI_BATCH_RETRY');
    $reason_map = [
        'gemini_quota_cooldown' => 'سهمیه روزانه Gemini',
        'gemini_rate_limited' => 'محدودیت موقت Gemini',
        'gemini_temporary_unavailable' => 'اختلال موقت Gemini',
        'gemini_quota_probe_busy' => 'بررسی سهمیه Gemini هنوز در حال اجراست',
        'gemini_workers_busy' => 'همه Workerهای قابل تخصیص مشغول‌اند',
        'gemini_batch_in_progress' => 'همین دسته یا بخشی از آن در حال اجراست',
        'gemini_ledger_storage_error' => 'دفتر ثبت پایدار Gemini در دسترس نیست',
        'gemini_parallel_auth_failed' => 'احراز هویت داخلی پردازش موازی ناموفق بود',
        'gemini_parallel_unavailable' => 'پیش‌نیاز پردازش موازی در دسترس نیست',
        'gemini_worker_auth_failed' => 'توکن داخلی یک Worker نامعتبر است',
        'AI_BATCH_OUTPUT_INVALID' => 'خروجی JSON دسته‌ای Gemini نامعتبر بود',
        'AI_BATCH_INVALID_JSON' => 'JSON پاسخ دسته‌ای Gemini قابل‌تجزیه نبود',
    ];
    $reason = $reason_map[$err_code] ?? ($reason_map[strtoupper($err_code)] ?? 'خطای موقت پردازش Gemini');
    $entry_count = count((array) $entries);
    $error_detail = is_wp_error($error) ? sanitize_textarea_field($error->get_error_message()) : 'جزئیات خطا در دسترس نیست';
    // Never persist credentials if a lower-level error accidentally includes them.
    $error_detail = preg_replace('/((?:api[_-]?key|authorization|access[_-]?token|secret|password)\s*[:=]\s*)[^\s,;]+/i', '$1[redacted]', (string) $error_detail);
    $error_detail = preg_replace('/AIza[0-9A-Za-z_-]{20,}/', '[redacted-api-key]', $error_detail);
    if (function_exists('mb_substr')) $error_detail = mb_substr($error_detail, 0, 400, 'UTF-8');
    else $error_detail = substr($error_detail, 0, 800);
    $message = $reason . '؛ ' . $entry_count . ' محصول تا ' . $resume_label . ' به صف برگشت؛ Retry افزایش نیافت.';

    evazar_queue_log_batch_deferred_event($entries, $error, $resume_at, (string) $worker_url);

    foreach ((array) $entries as $entry) {
        $item = $entry['item'] ?? null;
        if (!$item || empty($item->id)) continue;
        $wpdb->update(
            $table_name,
            [
                'status' => 'pending',
                'error_code' => $queue_code,
                'error_log' => $message . (is_wp_error($error) ? ' جزئیات: ' . $error_detail : ''),
                'last_error_at' => current_time('mysql'),
                'claim_token' => '',
                'claimed_at' => null,
                'next_attempt_at' => $resume_mysql,
            ],
            ['id' => (int) $item->id, 'claim_token' => (string) $claim_token]
        );
    }
    return ['resume_at' => $resume_at, 'resume_label' => $resume_label, 'message' => $message];
}

/** Finalize one resumed batch product using the same queue/history rules as a normal import. */
function evazar_queue_finalize_batched_result($item, $result, $claim_token) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';

    if (is_wp_error($result)) {
        if (evazar_queue_is_gemini_pause_error($result)) {
            return ['kind' => 'pause', 'error' => $result];
        }
        $err_code = $result->get_error_code() ?: 'UNKNOWN';
        if ($err_code === 'gemini_request_outcome_unknown') {
            $wpdb->update($table_name, [
                'status' => 'pending',
                'retries' => ((int) $item->retries) + 1,
                'error_code' => 'GEMINI_OUTCOME_UNKNOWN_RECOVERY',
                'error_log' => sanitize_textarea_field('نتیجهٔ درخواست قبلی Gemini نامشخص ماند؛ پس از مکث یک تلاش تازه با شناسهٔ درخواست جدید انجام می‌شود. ممکن است سهمیهٔ Gemini دوباره مصرف شود. ' . $result->get_error_message()),
                'last_error_at' => current_time('mysql'),
                'claim_token' => '',
                'claimed_at' => null,
                'next_attempt_at' => evazar_queue_mysql_after(120),
            ], ['id' => (int) $item->id, 'claim_token' => (string) $claim_token]);
            return ['kind' => 'deferred'];
        }
        $err_msg = $result->get_error_message();
        if ($err_code === 'DKP_IMPORT_IN_PROGRESS') {
            $saved = $wpdb->update($table_name, [
                'status' => 'pending',
                'error_code' => 'DKP_IMPORT_IN_PROGRESS',
                'error_log' => sanitize_textarea_field($err_msg),
                'last_error_at' => current_time('mysql'),
                'claim_token' => '',
                'claimed_at' => null,
                'next_attempt_at' => evazar_queue_mysql_after(60),
            ], ['id' => (int) $item->id, 'claim_token' => (string) $claim_token]);
            if ($saved !== false) return ['kind' => 'deferred'];
        }
        $next_retries = ((int) $item->retries) + 1;
        // Never abandon an import solely because the retry counter reached a fixed limit.
        // Exponential backoff is capped at 10 minutes to avoid hot loops without delaying recovery for hours.
        $backoff = min(10, max(1, (int) pow(2, min(4, max(0, $next_retries - 1)))));
        $failure_saved = $wpdb->update($table_name, [
            'status' => 'pending',
            'error_code' => sanitize_text_field($err_code),
            'error_log' => sanitize_textarea_field($err_msg),
            'last_error_at' => current_time('mysql'),
            'retries' => $next_retries,
            'claim_token' => '',
            'claimed_at' => null,
            'next_attempt_at' => evazar_queue_mysql_after($backoff * 60),
        ], ['id' => (int) $item->id, 'claim_token' => (string) $claim_token]);
        evazar_queue_log_final_product_failure($item, $err_code, $err_msg, $failure_saved);
        return ['kind' => 'failed'];
    }

    $post_id = absint($result);
    if (!$post_id) {
        return evazar_queue_finalize_batched_result($item, new WP_Error('AI_BATCH_INVALID_PRODUCT_RESULT', 'پاسخ ادامهٔ پردازش محصول، شناسهٔ معتبر محصول نبود.'), $claim_token);
    }

    $late_rewrite_flag = (string) get_post_meta($post_id, '_evazar_force_ai_rewrite', true) === '1';
    $ai_rewrite_ready = get_option('evazar_ai_enabled', '') === 'yes'
        && function_exists('evazar_has_ai_api_key') && evazar_has_ai_api_key();
    if ($late_rewrite_flag && $ai_rewrite_ready) {
        $saved = $wpdb->update($table_name, [
            'status' => 'pending',
            'error_code' => 'AI_REWRITE_REQUEST_PENDING',
            'error_log' => 'درخواست بازنویسی مدیر هنگام پردازش ثبت شد؛ کالا برای اجرای مرحله AI با درخواست تازه به صف بازگشت.',
            'last_error_at' => current_time('mysql'),
            'claim_token' => '',
            'claimed_at' => null,
            'next_attempt_at' => evazar_queue_mysql_after(30),
        ], ['id' => (int) $item->id, 'claim_token' => (string) $claim_token]);
        if ($saved !== false) return ['kind' => 'deferred'];
    }

    $wpdb->update($table_name, [
        'status' => 'completed',
        'error_code' => '',
        'error_log' => '',
        'last_error_at' => null,
        'claim_token' => '',
        'claimed_at' => null,
        'next_attempt_at' => null,
    ], ['id' => (int) $item->id, 'claim_token' => (string) $claim_token]);

    update_post_meta($post_id, '_sku', (string) $item->dkp);
    $history_table = evazar_queue_import_history_table_name();
    $history_saved = $wpdb->replace($history_table, [
        'dkp' => (string) $item->dkp,
        'product_id' => $post_id,
        'source_url' => (string) $item->url,
        'imported_at' => current_time('mysql', true),
    ], ['%s', '%d', '%s', '%s']);
    if ($history_saved === false) {
        error_log('[EVazar Core] Failed to save import history for batched DKP ' . sanitize_text_field((string) $item->dkp) . ': ' . $wpdb->last_error);
    }
    return ['kind' => 'success'];
}

/** Build a truthful claim-vs-capacity diagnostic; capacity is a ceiling, not a promise. */
function evazar_queue_build_batch_claim_diagnostic($planned_capacity, $snapshot = []) {
    $planned_capacity = max(0, (int) $planned_capacity);
    $keys = ['pending_total', 'pending_due', 'pending_not_due', 'processing_before_claim', 'eligible_pending', 'claim_updated_rows', 'claim_loaded_rows', 'invalid_dkp_quarantined'];
    $counts = [];
    foreach ($keys as $key) {
        $value = $snapshot[$key] ?? -1;
        $counts[$key] = is_numeric($value) ? (int) $value : -1;
    }
    $loaded = $counts['claim_loaded_rows'];
    $counts['run_capacity'] = $planned_capacity;
    $counts['claim_unfilled_capacity'] = ($loaded < 0) ? -1 : max(0, $planned_capacity - $loaded);

    if ($counts['claim_updated_rows'] < 0) {
        $reason = 'ثبت Claim در دیتابیس خطا داد؛ تعداد ردیف تغییرکرده از پاسخ دیتابیس قابل تشخیص نیست.';
    } elseif ($counts['claim_updated_rows'] > $counts['claim_loaded_rows']) {
        $reason = 'تعداد ردیف‌های Claim‌شده از دیتابیس بیشتر از تعداد ردیف‌های بارگذاری‌شده است؛ احتمال اشکال در خواندن ردیف‌های Claim‌شده وجود دارد.';
    } elseif ($counts['eligible_pending'] === 0) {
        $reason = 'هیچ ردیفی با شروط فعلی صف واجد شرایط Claim نبود.';
    } elseif ($counts['eligible_pending'] >= 0 && $counts['eligible_pending'] < $planned_capacity && $counts['claim_updated_rows'] === $counts['eligible_pending'] && $counts['claim_loaded_rows'] === $counts['claim_updated_rows']) {
        $reason = 'فقط ' . $counts['eligible_pending'] . ' ردیف طبق شروط واقعی صف واجد شرایط Claim بود؛ ظرفیت ' . $planned_capacity . ' سقف است، نه تعداد تضمین‌شده.';
    } elseif ($counts['eligible_pending'] >= $planned_capacity && $counts['claim_updated_rows'] >= 0 && $counts['claim_updated_rows'] < $planned_capacity) {
        $reason = 'ردیف واجدشرایط به‌اندازه کافی وجود داشت، اما Claim تعداد کمتری را تغییر داد؛ احتمال تغییر هم‌زمان وضعیت ردیف‌ها یا مشکل دیتابیس بررسی شود.';
    } elseif ($counts['claim_loaded_rows'] >= $planned_capacity && $planned_capacity > 0) {
        $reason = 'ظرفیت محاسبه‌شده پر شده است.';
    } else {
        $reason = 'ظرفیت کامل نشده است؛ شمارش واجدشرایط‌ها و وضعیت ردیف‌های Claim‌شده را با مقادیر بالا تطبیق دهید.';
    }

    $label = static function ($value) { return ((int) $value) < 0 ? 'نامشخص' : (string) (int) $value; };
    $message = 'تشخیص ظرفیت و Claim صف: سقف حداکثر=' . $planned_capacity
        . '؛ کل pending=' . $label($counts['pending_total'])
        . '؛ pending با موعد رسیده=' . $label($counts['pending_due'])
        . '؛ pending با موعد آینده=' . $label($counts['pending_not_due'])
        . '؛ processing پیش از Claim=' . $label($counts['processing_before_claim'])
        . '؛ واجدشرایط طبق شرط واقعی Claim=' . $label($counts['eligible_pending'])
        . '؛ ردیف تغییر وضعیت داده‌شده=' . $label($counts['claim_updated_rows'])
        . '؛ ردیف بارگذاری‌شده=' . $label($counts['claim_loaded_rows'])
        . '؛ ردیف DKP نامعتبر قرنطینه‌شده=' . $label($counts['invalid_dkp_quarantined'])
        . '؛ فاصله تا سقف=' . $label($counts['claim_unfilled_capacity'])
        . '؛ علت: ' . $reason;

    return ['message' => $message, 'context' => $counts, 'reason' => $reason];
}

/** Persist one compact claim diagnostic per batch run, without logging individual product waves. */
function evazar_queue_log_batch_claim_diagnostic($planned_capacity, $snapshot = []) {
    $diagnostic = evazar_queue_build_batch_claim_diagnostic($planned_capacity, $snapshot);
    $GLOBALS['evazar_queue_batch_claim_diagnostics'] = $diagnostic;
    if (function_exists('evazar_gemini_log_event')) {
        $event_context = ['purpose' => 'product_import_batch'];
        foreach ((array) ($diagnostic['context'] ?? []) as $metric => $value) {
            if ($metric === 'run_capacity') $event_context['queue_run_capacity'] = (int) $value;
            else $event_context['queue_' . $metric] = (int) $value;
        }
        evazar_gemini_log_event(
            'queue_batch_claim_result',
            $diagnostic['message'],
            '', 0, 0,
            $event_context
        );
    }
    return $diagnostic;
}

/**
 * Log the exact cause for one product that failed before reaching the Gemini checkpoint.
 * Diagnostics are item-scoped: only WP_Error data belonging to this item is trusted, so a
 * previous product's global Worker diagnostic cannot leak into this record.
 */
function evazar_queue_log_pre_gemini_failure($item, $result) {
    if (!is_object($result) || !is_a($result, 'WP_Error') || !function_exists('evazar_gemini_log_event')) return;

    $raw_error_code = (string) ($result->get_error_code() ?: 'unknown');
    $error_code = sanitize_key($raw_error_code);
    $error_message = sanitize_textarea_field((string) $result->get_error_message());
    // WP_Error data lookup is case-sensitive; keep the original code for retrieval.
    $error_data = $result->get_error_data($raw_error_code);
    $error_data = is_array($error_data) ? $error_data : [];
    $diag = [];
    if ($error_code === 'evazar_worker_product_unavailable') {
        // This is the only pre-Gemini error whose error data is contractually the Worker diagnostic.
        $diag = $error_data;
    } elseif (isset($error_data['worker_diagnostic']) && is_array($error_data['worker_diagnostic'])) {
        $diag = $error_data['worker_diagnostic'];
    } elseif (isset($error_data['diagnostic']) && is_array($error_data['diagnostic'])) {
        $diag = $error_data['diagnostic'];
    }

    $queue_id = absint($item->id ?? 0);
    $dkp_raw = (string) ($item->dkp ?? '');
    $dkp = preg_replace('/[^0-9]/', '', $dkp_raw);
    $stage = 'pre_gemini_processing';
    if (in_array($error_code, ['invalid', 'invalid_dkp'], true)) $stage = 'dkp_validation';
    elseif ($error_code === 'dkp_lookup_failed') $stage = 'database_identity_lookup';
    elseif (in_array($error_code, ['dkp_import_lock_unavailable', 'dkp_import_in_progress'], true)) $stage = 'product_lock';
    elseif ($error_code === 'evazar_worker_product_unavailable') $stage = 'source_fetch';
    elseif (strpos($error_code, 'ai_') === 0 || strpos($error_code, 'gemini_') === 0) $stage = 'ai_preflight';

    $diagnostic_code = sanitize_key((string) ($diag['code'] ?? ''));
    $http_code = absint($diag['http_code'] ?? 0);
    $upstream_v2 = absint($diag['upstream_status_v2'] ?? 0);
    $upstream_v1 = absint($diag['upstream_status_v1'] ?? 0);
    $scope = sanitize_key((string) ($diag['error_scope'] ?? ''));
    $source_error_code = sanitize_key((string) ($diag['source_error_code'] ?? ''));
    $upstream_error_v2 = sanitize_text_field((string) ($diag['upstream_error_v2'] ?? ''));
    $upstream_error_v1 = sanitize_text_field((string) ($diag['upstream_error_v1'] ?? ''));
    $upstream_error_v2 = preg_replace('/\bAIza[0-9A-Za-z_-]{20,}\b/', '[REDACTED_API_KEY]', $upstream_error_v2);
    $upstream_error_v1 = preg_replace('/\bAIza[0-9A-Za-z_-]{20,}\b/', '[REDACTED_API_KEY]', $upstream_error_v1);
    $upstream_error_v2 = preg_replace('/\bAQ\.[A-Za-z0-9._-]{12,}\b/', '[REDACTED_API_KEY]', $upstream_error_v2);
    $upstream_error_v1 = preg_replace('/\bAQ\.[A-Za-z0-9._-]{12,}\b/', '[REDACTED_API_KEY]', $upstream_error_v1);
    if (function_exists('mb_substr')) {
        $upstream_error_v2 = mb_substr($upstream_error_v2, 0, 180, 'UTF-8');
        $upstream_error_v1 = mb_substr($upstream_error_v1, 0, 180, 'UTF-8');
    } else {
        $upstream_error_v2 = substr($upstream_error_v2, 0, 360);
        $upstream_error_v1 = substr($upstream_error_v1, 0, 360);
    }
    $worker_host = sanitize_text_field((string) ($diag['worker_host'] ?? ''));
    $worker_version = sanitize_text_field((string) ($diag['worker_version'] ?? ''));
    $attempted_count = absint($diag['attempted'] ?? 0);
    $worker_attempted = ($attempted_count > 0 || $http_code > 0) ? 'yes' : (in_array($stage, ['dkp_validation', 'database_identity_lookup', 'product_lock'], true) ? 'no' : 'unknown');
    $elapsed_ms = absint($diag['elapsed_ms'] ?? 0);
    $diag_detail = sanitize_text_field((string) ($diag['detail'] ?? ''));
    $db_error = '';
    if ($error_code === 'dkp_lookup_failed' && !empty($error_data['db_error'])) {
        // Keep the DB's actual error text useful but bounded; never log the full SQL statement.
        $db_error = sanitize_text_field((string) $error_data['db_error']);
        $db_error = preg_replace('/(?:SELECT|UPDATE|INSERT|DELETE)\b.*$/i', '[SQL omitted]', $db_error);
        if (function_exists('mb_substr')) $db_error = mb_substr($db_error, 0, 220, 'UTF-8');
        else $db_error = substr($db_error, 0, 440);
        if ($db_error !== '') $diag_detail = 'جزئیات دیتابیس: ' . $db_error;
    }
    // Redact common Google API key formats if they ever appear in a remote error message.
    $detail_for_log = $diag_detail !== '' ? $diag_detail : $error_message;
    $detail_for_log = preg_replace('/\bAIza[0-9A-Za-z_-]{20,}\b/', '[REDACTED_API_KEY]', $detail_for_log);
    $detail_for_log = preg_replace('/\bAQ\.[A-Za-z0-9._-]{12,}\b/', '[REDACTED_API_KEY]', $detail_for_log);
    if (function_exists('mb_substr')) $detail_for_log = mb_substr($detail_for_log, 0, 350, 'UTF-8');
    else $detail_for_log = substr($detail_for_log, 0, 700);

    $message = 'خطای پیش از Gemini؛ مرحله=' . $stage
        . '؛ DKP=' . ($dkp !== '' ? $dkp : 'خالی/نامعتبر')
        . '؛ شناسه ردیف صف=' . $queue_id
        . '؛ error_code=' . $error_code
        . '؛ تشخیص=' . ($diagnostic_code !== '' ? $diagnostic_code : 'بدون تشخیص Worker')
        . '؛ درخواست Worker=' . $worker_attempted
        . ($http_code > 0 ? '؛ HTTP Worker=' . $http_code : '')
        . ($scope !== '' ? '؛ scope=' . $scope : '')
        . ($source_error_code !== '' ? '؛ source_error=' . $source_error_code : '')
        . (($source_error_code !== '' || $upstream_v2 > 0 || $upstream_v1 > 0 || $upstream_error_v2 !== '' || $upstream_error_v1 !== '')
            ? '؛ upstream v2=' . ($upstream_v2 > 0 ? $upstream_v2 : 'no-response')
                . ($upstream_error_v2 !== '' ? ' (' . $upstream_error_v2 . ')' : '')
                . '؛ upstream v1=' . ($upstream_v1 > 0 ? $upstream_v1 : 'not-attempted/no-response')
                . ($upstream_error_v1 !== '' ? ' (' . $upstream_error_v1 . ')' : '')
            : '')
        . ($worker_host !== '' ? '؛ Worker=' . $worker_host : '')
        . ($worker_version !== '' ? '؛ نسخه Worker=' . $worker_version : '')
        . ($elapsed_ms > 0 ? '؛ مدت=' . $elapsed_ms . 'ms' : '')
        . '؛ جزئیات=' . ($detail_for_log !== '' ? $detail_for_log : $error_message);

    $context = [
        'purpose' => 'product_import_batch',
        'dkp' => $dkp,
        'queue_item_id' => $queue_id,
        'error_stage' => $stage,
        'error_code' => $error_code,
        'diagnostic_code' => $diagnostic_code,
        'error_scope' => $scope,
        'source_error_code' => $source_error_code,
        'upstream_error_v2' => $upstream_error_v2,
        'upstream_error_v1' => $upstream_error_v1,
        'worker_version' => $worker_version,
        'worker_host' => $worker_host,
        'worker_attempted' => $worker_attempted,
        'diagnostic_http_code' => $http_code,
        'upstream_status_v2' => $upstream_v2,
        'upstream_status_v1' => $upstream_v1,
        'diagnostic_elapsed_ms' => $elapsed_ms,
        'diagnostic_detail' => $detail_for_log,
    ];
    $worker_url = '';
    if ($worker_host !== '' && preg_match('/^[A-Za-z0-9.-]+(?::[0-9]{1,5})?$/', $worker_host)) $worker_url = 'https://' . $worker_host;
    evazar_gemini_log_event('queue_pre_gemini_item_failure', $message, $worker_url, $http_code, 0, $context);
    // The 200-row Import Logs screen reads evazar_import_log()'s file, not the Gemini ops option.
    // Mirror per-product queue failures into that exact log so failures appear beside successes.
    if (function_exists('evazar_import_log')) {
        evazar_import_log('error', $message, $dkp, [
            'title' => 'خطای صف پیش از Gemini · ' . ($error_code !== '' ? $error_code : 'unknown'),
            'source' => 'queue_batch_pre_gemini_failure',
            'worker_error_code' => $diagnostic_code !== '' ? $diagnostic_code : $error_code,
            'worker_http_code' => $http_code,
            'worker_host' => $worker_host,
            'worker_attempted' => $attempted_count,
            'source_error_code' => $source_error_code,
            'upstream_status_v2' => $upstream_v2,
            'upstream_status_v1' => $upstream_v1,
            'upstream_error_v2' => $upstream_error_v2,
            'upstream_error_v1' => $upstream_error_v1,
            'worker_version' => $worker_version,
        ]);
    }

    if (!isset($GLOBALS['evazar_queue_pre_gemini_failure_groups']) || !is_array($GLOBALS['evazar_queue_pre_gemini_failure_groups'])) $GLOBALS['evazar_queue_pre_gemini_failure_groups'] = [];
    $group_key = implode('|', [$stage, $error_code, $diagnostic_code, $http_code, $upstream_v2, $upstream_v1, $source_error_code]);
    if (!isset($GLOBALS['evazar_queue_pre_gemini_failure_groups'][$group_key])) {
        $GLOBALS['evazar_queue_pre_gemini_failure_groups'][$group_key] = [
            'stage' => $stage, 'error_code' => $error_code, 'diagnostic_code' => $diagnostic_code,
            'http_code' => $http_code, 'upstream_status_v2' => $upstream_v2,
            'upstream_status_v1' => $upstream_v1, 'source_error_code' => $source_error_code,
            'upstream_error_v2' => $upstream_error_v2, 'upstream_error_v1' => $upstream_error_v1,
            'count' => 0, 'sample_dkps' => [], 'sample_queue_ids' => [], 'sample_detail' => $detail_for_log,
        ];
    }
    $group =& $GLOBALS['evazar_queue_pre_gemini_failure_groups'][$group_key];
    $group['count']++;
    if ($dkp !== '' && count($group['sample_dkps']) < 8 && !in_array($dkp, $group['sample_dkps'], true)) $group['sample_dkps'][] = $dkp;
    if ($queue_id > 0 && count($group['sample_queue_ids']) < 8 && !in_array($queue_id, $group['sample_queue_ids'], true)) $group['sample_queue_ids'][] = $queue_id;
    unset($group);
    $GLOBALS['evazar_queue_pre_gemini_failure_count'] = (int) ($GLOBALS['evazar_queue_pre_gemini_failure_count'] ?? 0) + 1;
}

/** Record the precise reason a single product failed finalization in the same 200-event Gemini/import log. */
function evazar_queue_log_final_product_failure($item, $error_code, $error_message, $db_result = null) {
    if (!function_exists('evazar_gemini_log_event')) return;
    $dkp = preg_replace('/[^0-9]/', '', (string) ($item->dkp ?? ''));
    $queue_id = absint($item->id ?? 0);
    $retry = max(0, (int) ($item->retries ?? 0)) + 1;
    $detail = trim((string) $error_message);
    if ($db_result === false) {
        global $wpdb;
        $db_error = isset($wpdb->last_error) ? trim((string) $wpdb->last_error) : '';
        $detail .= ' | ذخیره وضعیت خطا در دیتابیس ناموفق بود.' . ($db_error !== '' ? ' DB: ' . $db_error : '');
    }
    $detail = function_exists('mb_substr') ? mb_substr($detail, 0, 380, 'UTF-8') : substr($detail, 0, 760);
    $message = 'شکست نهایی محصول در پردازش دسته‌ای؛ DKP=' . ($dkp !== '' ? $dkp : 'نامشخص') . '؛ کد=' . sanitize_key((string) $error_code) . '؛ تلاش=' . $retry . '؛ علت=' . $detail;
    evazar_gemini_log_event('queue_product_final_failure', $message, '', 0, 0, [
        'purpose' => 'product_import_batch',
        'dkp' => $dkp,
        'queue_item_id' => $queue_id,
        'error_stage' => 'gemini_finalize',
        'error_code' => sanitize_key((string) $error_code),
        'diagnostic_detail' => $detail,
    ]);
    // Mirror final queue failures into the same file-backed 200-event Import Logs table.
    if (function_exists('evazar_import_log')) {
        evazar_import_log('error', $message, $dkp, [
            'title' => 'خطای نهایی صف · ' . sanitize_key((string) $error_code),
            'post_id' => 0,
            'source' => 'queue_batch_final_failure',
            'worker_error_code' => sanitize_key((string) $error_code),
        ]);
    }
}

/** Log final outcomes after queue and Gemini work have actually finished. */
function evazar_queue_log_batch_run_summary($claimed_count, $ready_count, $success_count, $failed_count, $deferred_count, $status = 'completed', $reason = '', $quarantined_count = 0) {
    if (!function_exists('evazar_gemini_log_event')) return;
    $claimed_count = max(0, (int) $claimed_count);
    $ready_count = max(0, (int) $ready_count);
    $success_count = max(0, (int) $success_count);
    $failed_count = max(0, (int) $failed_count);
    $deferred_count = max(0, (int) $deferred_count);
    $quarantined_count = max(0, (int) $quarantined_count);
    if ($status === 'running') {
        $status = 'early_return';
        if ($reason === '') $reason = 'اجرا پیش از پایان عادی خارج شد؛ رویداد خطا یا توقف همین نوبت علت دقیق را نشان می‌دهد.';
    }
    if ($status === 'completed' && ($failed_count > 0 || $deferred_count > 0 || $quarantined_count > 0)) $status = 'completed_with_item_issues';
    $labels = [
        'completed' => 'پایان عادی',
        'completed_with_item_issues' => 'پایان با خطا/تعویق محصول',
        'early_return' => 'خروج زودهنگام',
        'manual_pause' => 'توقف دستی صف',
        'source_restriction' => 'محدودیت منبع',
        'source_circuit_open' => 'محافظ خطای پیاپی منبع',
        'gemini_pause' => 'مکث Gemini',
        'worker_unavailable' => 'Worker واجدشرایط موجود نبود',
        'unknown_gemini_outcome' => 'نتیجه درخواست Gemini نامشخص',
        'dispatch_halted' => 'توقف ارسال دسته‌ای',
        'interrupted' => 'اجرای ناتمام با Claim باقی‌مانده',
    ];
    $status_label = $labels[$status] ?? $status;
    if ($reason === '') $reason = 'برای علت توقف، رویداد خطای همین نوبت را بررسی کنید.';
    $pre_gemini_groups = isset($GLOBALS['evazar_queue_pre_gemini_failure_groups']) && is_array($GLOBALS['evazar_queue_pre_gemini_failure_groups'])
        ? array_values($GLOBALS['evazar_queue_pre_gemini_failure_groups']) : [];
    usort($pre_gemini_groups, static function ($a, $b) { return ((int) ($b['count'] ?? 0)) <=> ((int) ($a['count'] ?? 0)); });
    $pre_gemini_failure_count = max(0, (int) ($GLOBALS['evazar_queue_pre_gemini_failure_count'] ?? 0));
    $failure_group_parts = [];
    foreach (array_slice($pre_gemini_groups, 0, 8) as $group) {
        $group_part = (int) ($group['count'] ?? 0) . '× ' . sanitize_key((string) ($group['stage'] ?? 'unknown'))
            . '/' . sanitize_key((string) ($group['error_code'] ?? 'unknown'));
        if (!empty($group['diagnostic_code'])) $group_part .= '/' . sanitize_key((string) $group['diagnostic_code']);
        if (!empty($group['http_code'])) $group_part .= ' HTTP ' . (int) $group['http_code'];
        if (!empty($group['upstream_status_v2'])) $group_part .= ' v2=' . (int) $group['upstream_status_v2'];
        if (!empty($group['upstream_status_v1'])) $group_part .= ' v1=' . (int) $group['upstream_status_v1'];
        if (!empty($group['source_error_code'])) $group_part .= ' source=' . sanitize_key((string) $group['source_error_code']);
        if (!empty($group['sample_detail'])) {
            $sample_detail = sanitize_text_field((string) $group['sample_detail']);
            if (function_exists('mb_substr')) $sample_detail = mb_substr($sample_detail, 0, 120, 'UTF-8');
            else $sample_detail = substr($sample_detail, 0, 240);
            if ($sample_detail !== '') $group_part .= '؛ جزئیات نمونه: ' . $sample_detail;
        }
        if (!empty($group['sample_dkps'])) $group_part .= '؛ نمونه DKP: ' . implode(',', array_slice(array_map('strval', (array) $group['sample_dkps']), 0, 5));
        $failure_group_parts[] = $group_part;
    }
    $failure_group_summary = !empty($failure_group_parts) ? implode(' | ', $failure_group_parts) : '';
    $claim_diagnostic = $GLOBALS['evazar_queue_batch_claim_diagnostics'] ?? [];
    $claim_context = is_array($claim_diagnostic['context'] ?? null) ? $claim_diagnostic['context'] : [];
    $planned_capacity = max(0, (int) ($claim_context['run_capacity'] ?? 0));
    $eligible_count = (int) ($claim_context['eligible_pending'] ?? -1);
    $processed = $success_count + $failed_count + $deferred_count + $quarantined_count;
    $message = 'نتیجه نهایی نوبت صف: وضعیت=' . $status_label
        . '؛ سقف ظرفیت=' . $planned_capacity
        . '؛ واجدشرایط پیش از Claim=' . ($eligible_count >= 0 ? $eligible_count : 'نامشخص')
        . '؛ Claim واقعی=' . $claimed_count
        . '؛ آماده/Checkpoint برای Gemini=' . $ready_count
        . '؛ موفق نهایی=' . $success_count
        . '؛ خطا=' . $failed_count
        . '؛ تعویق=' . $deferred_count
        . '؛ قرنطینه مسیر دسته‌بندی=' . $quarantined_count
        . '؛ DKP نامعتبر منتقل‌شده به خطا=' . ((int) ($claim_context['invalid_dkp_quarantined'] ?? -1) >= 0 ? (int) $claim_context['invalid_dkp_quarantined'] : 'نامشخص')
        . '؛ تعیین‌تکلیف‌شده=' . $processed
        . '؛ توضیح=' . sanitize_text_field($reason) . '.'
        . ($failure_group_summary !== '' ? '؛ گروه‌بندی خطاهای پیش از Gemini (' . $pre_gemini_failure_count . ' مورد): ' . $failure_group_summary . '.' : '');
    // If no Gemini dispatch log was emitted (e.g. every primary Worker was unavailable before
    // any product reached a checkpoint), preserve the grouped source-wave diagnostics here.
    // The take helper returns an empty string after a normal batch_dispatch_wave already used it.
    $source_wave_summary = function_exists('evazar_queue_source_parallel_stats_take_summary')
        ? evazar_queue_source_parallel_stats_take_summary() : '';
    if ($source_wave_summary !== '') $message .= '؛ تشخیص موج‌های دریافت: ' . $source_wave_summary;
    $summary_context = [
        'purpose' => 'product_import_batch',
        'queue_run_capacity' => $planned_capacity,
        'queue_eligible_pending' => $eligible_count,
        'queue_claim_unfilled_capacity' => (int) ($claim_context['claim_unfilled_capacity'] ?? -1),
        'queue_run_items_claimed' => $claimed_count,
        'queue_run_ready_for_gemini' => $ready_count,
        'queue_run_processed' => $processed,
        'queue_run_success' => $success_count,
        'queue_run_failed' => $failed_count,
        'queue_run_deferred' => $deferred_count,
        'queue_run_quarantined_category_path' => $quarantined_count,
        'queue_invalid_dkp_quarantined' => (int) ($claim_context['invalid_dkp_quarantined'] ?? -1),
        'queue_pre_gemini_failure_count' => $pre_gemini_failure_count,
        'queue_pre_gemini_failure_groups' => array_slice($pre_gemini_groups, 0, 8),
    ];
    if ($source_wave_summary !== '') {
        $source_stats = is_array($GLOBALS['evazar_queue_source_parallel_stats'] ?? null) ? $GLOBALS['evazar_queue_source_parallel_stats'] : [];
        foreach ([
            'waves' => 'source_fetch_waves', 'requests' => 'source_fetch_requests', 'responses' => 'source_fetch_responses',
            'fallback_requests' => 'source_fetch_fallback_requests', 'transport_errors' => 'source_fetch_transport_errors',
            'total_phase_elapsed_ms' => 'source_fetch_elapsed_ms', 'configured_source_workers' => 'source_fetch_configured_workers',
            'eligible_source_workers_at_start' => 'source_fetch_eligible_workers_at_start',
            'source_concurrency_at_start' => 'source_fetch_effective_concurrency_at_start',
        ] as $from => $to) {
            if (isset($source_stats[$from])) $summary_context[$to] = absint($source_stats[$from]);
        }
        foreach ([
            'worker_request_counts_summary' => 'source_fetch_worker_distribution',
            'wave_size_counts_summary' => 'source_fetch_wave_size_distribution',
            'wave_eligibility_counts_summary' => 'source_fetch_wave_eligibility_distribution',
            'wave_reason_counts_summary' => 'source_fetch_wave_reason_distribution',
            'worker_availability_summary' => 'source_fetch_worker_availability_summary',
            'wave_diagnostics_summary' => 'source_fetch_wave_diagnostics',
        ] as $from => $to) {
            if (isset($source_stats[$from])) $summary_context[$to] = (string) $source_stats[$from];
        }
    }
    foreach (['pending_total', 'pending_due', 'pending_not_due', 'processing_before_claim', 'claim_updated_rows', 'claim_loaded_rows'] as $claim_metric) {
        if (isset($claim_context[$claim_metric])) $summary_context['queue_' . $claim_metric] = (int) $claim_context[$claim_metric];
    }
    evazar_gemini_log_event('queue_batch_run_summary', $message, '', 0, 0, $summary_context);
}

// ==========================================
// 4. پردازش پس‌زمینه صف (اجرا توسط Cron)
// ==========================================
add_action('evazar_process_import_queue', 'evazar_cron_worker_logic');
function evazar_queue_has_due_retry_products() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    $table_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name)));
    if ($table_exists !== $table_name) return false;
    $now_mysql = current_time('mysql');
    return (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM `$table_name` WHERE status='pending' AND COALESCE(error_code,'') <> '' AND (next_attempt_at IS NULL OR next_attempt_at <= %s)",
        $now_mysql
    )) > 0;
}

function evazar_cron_worker_logic($is_manual = false) {
    // The manager pause blocks both Cron and the "run now" button before any rows are claimed.
    if (evazar_queue_is_manually_paused()) {
        return [
            'processed' => 0,
            'success' => 0,
            'failed' => 0,
            'message' => 'صف واردات به‌صورت دستی متوقف است؛ هیچ محصول جدیدی Claim یا به Worker ارسال نشد. برای ادامه، صف را از داشبورد فعال کنید.'
        ];
    }

    static $ran_this_request = false;
    if ($ran_this_request) {
        return [
            'processed' => 0,
            'success' => 0,
            'failed' => 0,
            'message' => 'در همین درخواست یک نوبت پردازش صف اجرا شده است؛ از اجرای هم‌زمان دسته دوم جلوگیری شد.'
        ];
    }

    // Manual runs remain on-demand. All automatic runs, including due retries,
    // must honor the randomized not-before timestamp.
    $now = time();
    $next_auto_run = evazar_queue_next_auto_run_at();
    if (!$is_manual && $next_auto_run > $now) {
        evazar_queue_schedule_followup_at($next_auto_run);
        return [
            'processed' => 0,
            'success' => 0,
            'failed' => 0,
            'message' => 'نوبت خودکار صف هنوز نرسیده است؛ اجرای بعدی پس از پایان فاصله تصادفی تنظیم‌شده انجام می‌شود.'
        ];
    }

    // Enforce one queue run across independent PHP requests, not just within this request.
    $run_lock = evazar_queue_acquire_run_lock();
    if ($run_lock === '') {
        return [
            'processed' => 0,
            'success' => 0,
            'failed' => 0,
            'message' => 'یک نوبت واردات هم‌اکنون در حال اجراست؛ این درخواست برای جلوگیری از اجرای موازی متوقف شد.'
        ];
    }

    $ran_this_request = true;
    $GLOBALS['evazar_queue_active_run_lock'] = $run_lock;
    evazar_queue_heartbeat_run_lock($run_lock);
    // Set next run's not-before timestamp at the start (start-to-start cadence).
    // Register in this order: record finish, release the run lock, then schedule a follow-up.
    register_shutdown_function('evazar_queue_finalize_auto_interval', $run_lock);
    register_shutdown_function('evazar_queue_release_run_lock', $run_lock);
    register_shutdown_function('evazar_queue_maybe_schedule_followup');
    evazar_queue_begin_run_interval($run_lock, (bool) $is_manual);
    global $wpdb;
    evazar_queue_ensure_import_history_table();
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    // Recover aged claims before any quota/Worker/configuration early return can bypass cleanup.
    // A newer processing claim is not retried yet; the pre-claim guard below prevents piling a
    // fresh batch on top of it until it either finishes or becomes safely recoverable.
    $queue_stale_recovery = evazar_queue_recover_stale_processing_claims($table_name);
    $queue_stale_recovered = max(0, (int) ($queue_stale_recovery['recovered'] ?? 0));

    $batch_size = intval(get_option('evazar_queue_max_products_per_run', 250));
    if ($batch_size < 1) $batch_size = 1;
    if ($batch_size > 250) $batch_size = 250;
    $queue_setting_limit = $batch_size;

    // Recover old rows left in `failed` by earlier versions; work is bounded to
    // 100 rows per run and is migrated before any Gemini quota/cooldown early return.
    evazar_queue_requeue_legacy_failed_items(100);
    $batch_collect_enabled = evazar_queue_product_batch_enabled();
    // Preserve the legacy 75-item ceiling outside Gemini batch mode. Only the Gemini queue scales to 250.
    if (!$batch_collect_enabled) {
        $batch_size = min(75, $batch_size);
        $queue_setting_limit = $batch_size;
    }
    $ai_product_batch_size = evazar_queue_product_batch_size();
    $queue_php_time_limit = 0;
    $batch_worker_distribution_enabled = false;
    $batch_parallel_transport_enabled = false;
    if ($batch_collect_enabled) {
        // Queue preparation collects product checkpoints before sending AI batches.
        // The batch path uses a short 300ms preparation pause; non-batch import is unchanged.
        // Extend execution before that loop, not later inside the Gemini HTTP call.
        if (function_exists('set_time_limit')) @set_time_limit(300);
        $queue_php_time_limit = (int) ini_get('max_execution_time');
        $batch_worker_distribution_enabled = evazar_queue_product_batch_parallel_enabled();
        $batch_parallel_transport_enabled = $batch_worker_distribution_enabled && evazar_queue_parallel_transport_available();
    }
    $ai_enabled = get_option('evazar_ai_enabled', '') === 'yes';
    $configured_ai_mode = (string) get_option('evazar_ai_engine_mode', '');
    if ($ai_enabled && $configured_ai_mode !== 'gemini_only') {
        return [
            'processed' => 0,
            'success' => 0,
            'failed' => 0,
            'message' => 'پردازش خودکار محتوای محصول در صف فقط با حالت «صرفاً Google Gemini» و درخواست‌های دسته‌ای فعال است. هیچ محصولی Claim نشد و درخواست تک‌محصولی خودکار ارسال نشد.'
        ];
    }
    if ($batch_collect_enabled) {
        // One batch per configured Worker (up to five) is the automatic target.
        // Actual claim capacity is still capped by Workers currently eligible below.
        $batch_size = evazar_queue_effective_run_limit($batch_size);
    }

    // در حالت Gemini-only، قبل از Claim حتی یک محصول هم وضعیت Cooldown را بررسی می‌کنیم.
    // اگر سهمیه روزانه تمام شده باشد، هیچ آیتمی Claim نمی‌شود و هیچ Workerی فراخوانی نمی‌گردد.
    if (!function_exists('evazar_should_pause_queue_for_gemini_quota')) {
        require_once plugin_dir_path(__FILE__) . 'importer.php';
    }
    if (function_exists('evazar_should_pause_queue_for_gemini_quota') && evazar_should_pause_queue_for_gemini_quota()) {
        $rate_until = function_exists('evazar_gemini_rate_cooldown_until') ? evazar_gemini_rate_cooldown_until() : 0;
        $quota_until = function_exists('evazar_get_gemini_global_quota_cooldown_until') ? evazar_get_gemini_global_quota_cooldown_until() : 0;
        $concurrency_until = function_exists('evazar_gemini_concurrency_cooldown_until') ? evazar_gemini_concurrency_cooldown_until() : 0;
        if ($concurrency_until > 0) {
            $resume_at = $concurrency_until;
            $resume_label = evazar_queue_local_datetime($resume_at) ?: evazar_queue_mysql_timestamp($resume_at);
            $pause_message = 'درخواست Gemini دیگری در حال اجراست؛ صف کوتاه‌مدت تا ' . $resume_label . ' مکث می‌کند.';
        } elseif ($rate_until > 0) {
            $resume_at = $rate_until;
            $resume_label = evazar_queue_local_datetime($resume_at) ?: evazar_queue_mysql_timestamp($resume_at);
            $pause_message = 'همه Workerهای آماده Gemini موقتاً محدود یا در دسترس نیستند؛ صف تا ' . $resume_label . ' متوقف است.';
        } else {
            $resume_at = $quota_until;
            $resume_label = $resume_at && function_exists('evazar_gemini_quota_reset_label') ? evazar_gemini_quota_reset_label($resume_at) : '00:00 Pacific روز بعد';
            $pause_message = 'سهمیه روزانه تمام Workerهای Gemini تمام شده است؛ صف تا ' . $resume_label . ' متوقف است.';
        }

        return [
            'processed' => 0,
            'success'   => 0,
            'failed'    => 0,
            'message'   => $pause_message . ' هیچ محصولی Claim و هیچ درخواست جدیدی به Worker ارسال نشد.'
        ];
    }

    // Do not append another Claim while any prior processing rows remain. The run lock means
    // a healthy queue request is not currently owning them; recent rows are held for the safe
    // timeout, while old rows were already recovered above with compare-and-set.
    $previous_claim_guard = evazar_queue_guard_previous_processing_claims($table_name, $queue_stale_recovered);
    if (!empty($previous_claim_guard['blocked'])) {
        return [
            'processed' => 0,
            'success' => 0,
            'failed' => 0,
            'deferred' => 0,
            'message' => (string) ($previous_claim_guard['message'] ?? 'صف برای جلوگیری از انباشته‌شدن Claimها مکث کرد؛ هیچ محصول جدیدی برداشت نشد.'),
        ];
    }

    // Fill free active-queue slots from older held arrivals before the current run claims rows.
    // The function is a no-op while no eligible Worker/capacity is available.
    if (function_exists('evazar_queue_promote_capacity_waiting')) {
        evazar_queue_promote_capacity_waiting();
    }

    // In Gemini-only batch mode, cap each run by eligible Workers × products/request.
    // Apply this to both true parallel fan-out and serialized transport, so exhausted,
    // cooling-down, or already-busy Workers do not inflate the claimed batch size.
    // Automatic Gemini product rewriting is batch-only; no singleton is dispatched.
    if ($batch_collect_enabled) {
        $configured_queue_limit = $batch_size;
        $eligible_workers = evazar_queue_parallel_healthy_worker_count();
        if ($eligible_workers < 1) {
            return [
                'processed' => 0,
                'success' => 0,
                'failed' => 0,
                'message' => 'در حال حاضر Worker دارای سهمیه و آزاد برای پردازش دسته‌ای وجود ندارد؛ هیچ محصولی Claim نشد و صف برای اجرای بعدی باقی ماند.'
            ];
        }
        $run_capacity = evazar_queue_adaptive_claim_capacity(
            $batch_size,
            $eligible_workers,
            evazar_queue_product_batch_size(),
            $batch_worker_distribution_enabled,
            evazar_queue_product_batch_parallelism()
        );
        // Gemini run capacity scales to eligible Workers × products per request (max five Workers / 250 products).
        // For example, four eligible Workers with a batch size of 50 can claim 200 products.
        // Without cURL-multi, keep the claim to one 50-product batch instead of serially risking
        // a PHP timeout after claiming rows that cannot all be dispatched in parallel.
        if (!$batch_parallel_transport_enabled) {
            $run_capacity = min($run_capacity, $ai_product_batch_size);
        }
        $capacity_before_php_guard = $run_capacity;
        // If the host refuses the 300-second runtime extension, a large queue claim can
        // hit PHP's short limit while scraping/preparing products, before Gemini batching
        // starts. Fall back to one complete AI batch for this run; the next Cron continues.
        // A value of 0 means PHP has no execution-time limit.
        if ($queue_php_time_limit > 0 && $queue_php_time_limit < 180) {
            $run_capacity = min($run_capacity, $ai_product_batch_size);
        }
        if ($run_capacity < 2) {
            return [
                'processed' => 0,
                'success' => 0,
                'failed' => 0,
                'message' => 'ظرفیت درخواست دسته‌ای کمتر از دو محصول است؛ هیچ محصولی Claim نشد.'
            ];
        }
        $batch_size = $run_capacity;
        if (function_exists('evazar_gemini_log_event')) {
            $requested_slots = evazar_queue_product_batch_parallelism();
            $effective_slots = $batch_parallel_transport_enabled ? min($eligible_workers, $requested_slots) : min(1, $eligible_workers);
            $ai_chunk_size = evazar_queue_product_batch_size();
            $planned_chunks = (int) ceil($run_capacity / max(2, $ai_chunk_size));
            $chunk_sizes = [];
            $chunk_remaining = max(0, (int) $run_capacity);
            while ($chunk_remaining > 0 && count($chunk_sizes) < 125) {
                $next_chunk = min($ai_chunk_size, $chunk_remaining);
                $chunk_sizes[] = $next_chunk;
                $chunk_remaining -= $next_chunk;
            }
            $chunk_plan_label = !empty($chunk_sizes) ? implode('+', $chunk_sizes) : '0';
            $gemini_urls = function_exists('evazar_get_gemini_worker_urls') ? array_values(array_unique(array_filter(array_map(static function ($url) { return rtrim(trim((string) $url), '/'); }, (array) evazar_get_gemini_worker_urls())))) : [];
            $gemini_configured_count = count($gemini_urls);
            $gemini_auto_capacity = min(250, max(0, (int) $queue_setting_limit), max(0, (int) $effective_slots) * max(2, (int) $ai_chunk_size));
            if (!$batch_parallel_transport_enabled) $gemini_auto_capacity = min($gemini_auto_capacity, $ai_chunk_size);
            if ($queue_php_time_limit > 0 && $queue_php_time_limit < 180) $gemini_auto_capacity = min($gemini_auto_capacity, $ai_chunk_size);
            $source_urls = function_exists('evazar_get_primary_worker_urls') ? array_values(array_unique(array_filter(array_map(static function ($url) { return rtrim(trim((string) $url), '/'); }, (array) evazar_get_primary_worker_urls())))) : [];
            $source_pool_snapshot = function_exists('evazar_queue_product_source_worker_pool_state') ? evazar_queue_product_source_worker_pool_state('import_source') : ['eligible_count' => 0];
            $source_configured_count = count($source_urls);
            $source_eligible_count = max(0, (int) ($source_pool_snapshot['eligible_count'] ?? 0));
            $source_parallel_cap = function_exists('evazar_queue_parallel_transport_available') && evazar_queue_parallel_transport_available()
                ? min(5, $source_configured_count, $source_eligible_count)
                : min(1, $source_eligible_count);
            $transport_label = $batch_parallel_transport_enabled ? 'parallel' : ($batch_worker_distribution_enabled ? 'serial-balanced-fallback' : 'single-worker-batch');
            $plan_message = 'برنامه صف: سقف دستی کل این نوبت=' . $queue_setting_limit . ' محصول؛ '
                . 'دریافت دیجی‌کالا: Workerهای اصلی تنظیم‌شده=' . $source_configured_count . '، واجدشرایط فعلی=' . $source_eligible_count . '، هم‌زمانی حداکثر=' . $source_parallel_cap . ' (هر Worker یک محصول در هر موج)؛ '
                . 'بازنویسی Gemini: Workerهای تنظیم‌شده=' . $gemini_configured_count . '، واجدشرایط=' . $eligible_workers . '، هم‌زمانی مؤثر=' . $effective_slots . '، اندازه هر درخواست=' . $ai_chunk_size . '؛ '
                . 'ظرفیت خودکار Gemini پیش از سقف دستی/محافظ‌ها=' . ($effective_slots * $ai_chunk_size) . '؛ ظرفیت هدف پس از سقف دستی و انتقال=' . $gemini_auto_capacity . '؛ '
                . 'ظرفیت پس از محافظ PHP=' . $run_capacity . '؛ اندازه دسته‌های برنامه‌ریزی‌شده=' . $chunk_plan_label . '؛ تعداد درخواست‌های Gemini=' . $planned_chunks . '؛ '
                . 'محدودیت PHP=' . ($queue_php_time_limit > 0 ? $queue_php_time_limit . ' ثانیه' : 'بدون محدودیت') . '؛ ظرفیت محاسبه‌شده پیش از محافظ PHP=' . $capacity_before_php_guard . '؛ مسیر=' . $transport_label;
            evazar_gemini_log_event(
                'batch_dispatch_plan',
                $plan_message,
                '', 0, 0,
                [
                    'purpose' => 'product_import_batch', 'batch_size' => min(50, max(2, $ai_chunk_size)),
                    'source_workers_configured' => $source_configured_count,
                    'source_workers_eligible' => $source_eligible_count,
                    'source_fetch_max_concurrency' => $source_parallel_cap,
                    'gemini_workers_configured' => $gemini_configured_count,
                    'gemini_workers_eligible' => $eligible_workers,
                    'gemini_effective_concurrency' => $effective_slots,
                    'gemini_auto_capacity' => max(0, $effective_slots * $ai_chunk_size),
                    'queue_manual_cap' => max(0, (int) $queue_setting_limit),
                    'queue_effective_capacity' => max(0, (int) $run_capacity),
                    'gemini_chunk_plan' => $chunk_plan_label,
                ]
            );
        }
    }

    // If the administrator enabled a delayed automatic review retry, promote only due
    // source-category-path quarantine items. The default is manual-only.
    evazar_queue_promote_due_category_quarantine();

    // Recheck the manager pause immediately before claiming rows; another admin request
    // may have paused the queue while this run was performing its preflight checks.
    if (evazar_queue_is_manually_paused()) {
        return [
            'processed' => 0,
            'success' => 0,
            'failed' => 0,
            'message' => 'صف واردات هنگام آماده‌سازی متوقف شد؛ هیچ محصول جدیدی Claim نشد.'
        ];
    }

    // Quarantine malformed legacy rows before the capacity snapshot and atomic Claim.
    // The SQL Claim below also validates the DKP, so rows beyond this bounded cleanup can never consume a batch slot.
    $invalid_dkp_quarantined = evazar_queue_quarantine_invalid_pending_dkps(1000);

    $claim_token = wp_generate_uuid4();
    $claimed_at = current_time('mysql');
    $claim_now_mysql = current_time('mysql');
    $waiting_partner_count = 0;
    $regular_ready_count = 0;
    $mature_waiting_partner_count = 0;
    $claim_eligibility_sql = '(next_attempt_at IS NULL OR next_attempt_at <= %s)';
    $claim_eligibility_args = [$claim_now_mysql];
    $claim_valid_dkp_sql = "(TRIM(COALESCE(dkp,'')) <> '' AND dkp REGEXP '[0-9]')";

    if ($batch_collect_enabled) {
        // Prefer pairing a waiting item with another ready item. If no partner arrives,
        // a due singleton gets one normal batch retry instead of remaining pending forever.
        $waiting_code = 'WAITING_FOR_BATCH_PARTNER';
        $waiting_partner_count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM `$table_name` WHERE status='pending' AND COALESCE(error_code,'')=%s",
            $waiting_code
        ));
        $regular_ready_count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM `$table_name` WHERE status='pending' AND $claim_valid_dkp_sql AND COALESCE(error_code,'')<>%s AND (next_attempt_at IS NULL OR next_attempt_at <= %s)",
            $waiting_code, $claim_now_mysql
        ));
        $mature_waiting_partner_count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM `$table_name` WHERE status='pending' AND $claim_valid_dkp_sql AND COALESCE(error_code,'')=%s AND (next_attempt_at IS NULL OR next_attempt_at <= %s)",
            $waiting_code, $claim_now_mysql
        ));

        if (evazar_queue_batch_partner_rows_can_be_claimed($waiting_partner_count, $regular_ready_count)) {
            $claim_eligibility_sql = "(COALESCE(error_code,'') = %s OR (COALESCE(error_code,'') <> %s AND (next_attempt_at IS NULL OR next_attempt_at <= %s)))";
            $claim_eligibility_args = [$waiting_code, $waiting_code, $claim_now_mysql];
        } elseif ($mature_waiting_partner_count > 0) {
            // No partner is ready: allow only due waiting rows to flow through the
            // explicit singleton-retry exception enforced again by Core and Worker.
            $claim_eligibility_sql = "(COALESCE(error_code,'') = %s AND (next_attempt_at IS NULL OR next_attempt_at <= %s))";
            $claim_eligibility_args = [$waiting_code, $claim_now_mysql];
        } else {
            $claim_eligibility_sql = "(COALESCE(error_code,'') <> %s AND (next_attempt_at IS NULL OR next_attempt_at <= %s))";
            $claim_eligibility_args = [$waiting_code, $claim_now_mysql];
        }
    }

    // Give due failed products priority over untouched backlog so a retry continuation
    // actually retries the failed items instead of repeatedly processing newer intake rows.
    // WAITING_FOR_BATCH_PARTNER still obeys its dedicated WHERE eligibility rules above;
    // this ordering only prioritizes it when its own retry time is due.
    // Count the actual eligible pool using the same WHERE clause as the atomic Claim.
    // This makes a 120-capacity / 36-item run distinguishable from a Claim/DB mismatch.
    $batch_claim_snapshot = [
        'pending_total' => -1,
        'pending_due' => -1,
        'pending_not_due' => -1,
        'processing_before_claim' => -1,
        'eligible_pending' => -1,
        'invalid_dkp_quarantined' => $invalid_dkp_quarantined,
    ];
    if ($batch_collect_enabled) {
        $read_queue_count = static function ($query, $args = []) use ($wpdb) {
            $prepared_query = $query;
            if (!empty($args)) $prepared_query = call_user_func_array([$wpdb, 'prepare'], array_merge([$query], $args));
            $value = $wpdb->get_var($prepared_query);
            return ($value === null || $value === false || $value === '') ? -1 : max(0, (int) $value);
        };
        $batch_claim_snapshot['pending_total'] = $read_queue_count("SELECT COUNT(*) FROM `$table_name` WHERE status='pending'");
        $batch_claim_snapshot['pending_due'] = $read_queue_count(
            "SELECT COUNT(*) FROM `$table_name` WHERE status='pending' AND (next_attempt_at IS NULL OR next_attempt_at <= %s)",
            [$claim_now_mysql]
        );
        $batch_claim_snapshot['pending_not_due'] = $read_queue_count(
            "SELECT COUNT(*) FROM `$table_name` WHERE status='pending' AND next_attempt_at > %s",
            [$claim_now_mysql]
        );
        $batch_claim_snapshot['processing_before_claim'] = $read_queue_count("SELECT COUNT(*) FROM `$table_name` WHERE status='processing'");
        $eligible_count_sql = "SELECT COUNT(*) FROM `$table_name` WHERE status='pending' AND $claim_valid_dkp_sql AND $claim_eligibility_sql";
        $batch_claim_snapshot['eligible_pending'] = $read_queue_count($eligible_count_sql, $claim_eligibility_args);
    }

    $claim_sql = "UPDATE `$table_name` SET status='processing', claim_token=%s, claimed_at=%s WHERE status='pending' AND $claim_valid_dkp_sql AND $claim_eligibility_sql ORDER BY CASE WHEN COALESCE(error_code,'') <> '' AND (next_attempt_at IS NULL OR next_attempt_at <= %s) THEN 0 ELSE 1 END, id ASC LIMIT %d";
    $claim_args = array_merge([$claim_sql, $claim_token, $claimed_at], $claim_eligibility_args, [$claim_now_mysql, $batch_size]);
    $claimed = $wpdb->query(call_user_func_array([$wpdb, 'prepare'], $claim_args));
    if (!$claimed) {
        if ($batch_collect_enabled) {
            $batch_claim_snapshot['claim_updated_rows'] = ($claimed === false) ? -1 : (int) $claimed;
            $batch_claim_snapshot['claim_loaded_rows'] = 0;
            evazar_queue_log_batch_claim_diagnostic($batch_size, $batch_claim_snapshot);
        }
        $message = ($batch_collect_enabled && $waiting_partner_count > 0 && $regular_ready_count === 0 && $mature_waiting_partner_count === 0)
            ? 'محصول در انتظار شریک دسته‌ای است؛ اگر تا پایان مکث محصول دیگری آماده نشود، خودش به‌صورت تلاش مجددِ کنترل‌شده پردازش می‌شود.'
            : 'هیچ کالایی با وضعیت در انتظار و آمادهٔ Claim در صف وجود ندارد.';
        return [
            'processed' => 0,
            'success'   => 0,
            'failed'    => 0,
            'message'   => $message
        ];
    }

    $items = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE claim_token = %s ORDER BY id ASC", $claim_token));
    $loaded_claim_count = is_array($items) ? count($items) : (is_countable($items) ? count($items) : 0);
    if ($batch_collect_enabled) {
        $batch_claim_snapshot['claim_updated_rows'] = ($claimed === false) ? -1 : (int) $claimed;
        $batch_claim_snapshot['claim_loaded_rows'] = $loaded_claim_count;
        evazar_queue_log_batch_claim_diagnostic($batch_size, $batch_claim_snapshot);
    }
    if (empty($items)) {
        return [
            'processed' => 0,
            'success'   => 0,
            'failed'    => 0,
            'message'   => 'آیتم‌های صف قابل دریافت نبودند.'
        ];
    }

    // لود کردن importer برای فراخوانی evazar_core_process_import
    if (!function_exists('evazar_core_process_import')) {
        require_once plugin_dir_path(__FILE__) . 'importer.php';
    }

    $success_cnt = 0;
    $failed_cnt  = 0;
    $deferred_cnt = 0;
    $quarantined_cnt = 0;
    $batch_pending = [];
    $consecutive_source_failures = 0;
    $source_circuit_open = false;
    $source_circuit_state = [];
    $batch_run_summary_status = $batch_collect_enabled ? 'running' : 'disabled';
    $batch_run_summary_reason = '';
    if ($batch_collect_enabled) {
        register_shutdown_function(static function () use (&$items, &$batch_pending, &$success_cnt, &$failed_cnt, &$deferred_cnt, &$quarantined_cnt, &$batch_run_summary_status, &$batch_run_summary_reason, $claim_token, $table_name) {
            global $wpdb;
            if ($batch_run_summary_status === 'running') {
                $remaining_owned = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM `$table_name` WHERE status='processing' AND claim_token=%s",
                    (string) $claim_token
                ));
                if ($remaining_owned > 0) {
                    $batch_run_summary_status = 'interrupted';
                    $batch_run_summary_reason = 'اجرای صف پیش از تعیین نتیجه متوقف شد و ' . $remaining_owned . ' Claim هنوز در وضعیت پردازش باقی مانده است؛ بازیابی امن در اجرای بعدی انجام می‌شود.';
                } else {
                    $batch_run_summary_status = 'early_return';
                    if ($batch_run_summary_reason === '') $batch_run_summary_reason = 'اجرا پیش از رسیدن به پایان عادی خارج شد؛ محصولات Claim‌شده تعیین تکلیف شده‌اند.';
                }
            }
            evazar_queue_log_batch_run_summary(
                is_countable($items) ? count($items) : 0,
                count($batch_pending),
                $success_cnt,
                $failed_cnt,
                $deferred_cnt,
                $batch_run_summary_status,
                $batch_run_summary_reason,
                $quarantined_cnt
            );
        });
    }
    if (function_exists('evazar_queue_source_parallel_stats_reset')) {
        evazar_queue_source_parallel_stats_reset();
    }
    $GLOBALS['evazar_queue_pre_gemini_failure_groups'] = [];
    $GLOBALS['evazar_queue_pre_gemini_failure_count'] = 0;

    foreach ($items as $item_index => $item) {
        evazar_queue_heartbeat_run_lock();
        if (evazar_queue_is_manually_paused()) {
            $released = evazar_queue_release_manual_pause_claims($claim_token);
            return [
                'processed' => $success_cnt + $failed_cnt + $deferred_cnt + $quarantined_cnt,
                'success' => $success_cnt,
                'failed' => $failed_cnt,
                'deferred' => $deferred_cnt,
                'message' => 'توقف دستی صف دریافت شد؛ ' . $released . ' محصولِ ارسال‌نشده بدون افزایش Retry به صف انتظار برگشت. درخواست‌هایی که از قبل در حال اجرا بودند ممکن است تا پایان همان درخواست کامل شوند.'
            ];
        }

        $current_dkp_for_pool = preg_replace('/[^0-9]/', '', (string) ($item->dkp ?? ''));
        $prefetch_map = $GLOBALS['evazar_queue_prefetched_product_source'] ?? [];
        $current_prefetch = ($current_dkp_for_pool !== '' && is_array($prefetch_map) && isset($prefetch_map[$current_dkp_for_pool]) && is_array($prefetch_map[$current_dkp_for_pool]))
            ? $prefetch_map[$current_dkp_for_pool] : [];
        if ($batch_collect_enabled && ($current_prefetch['mode'] ?? '') === 'worker_failure_deferred') {
            $pool_state = is_array($current_prefetch['pool_state'] ?? null) ? $current_prefetch['pool_state'] : evazar_queue_product_source_worker_pool_state('import_source');
            $deferred_one = evazar_queue_defer_attempted_source_item($item, $claim_token, (array) ($current_prefetch['diagnostic'] ?? []), $pool_state);
            unset($GLOBALS['evazar_queue_prefetched_product_source'][$current_dkp_for_pool]);
            $deferred_cnt += absint($deferred_one['deferred'] ?? 0);
            $batch_run_summary_status = 'worker_pool_cooldown';
            $batch_run_summary_reason = 'درخواست واقعی Worker ناموفق بود و پس از آن استخر Workerها در دسترس نماند؛ محصولاتِ درخواست‌شده جداگانه به انتظار برگشتند.';
            continue;
        }
        if (evazar_queue_source_circuit_should_defer_tail($batch_collect_enabled, $source_circuit_open, $current_dkp_for_pool, $current_prefetch)) {
            $pool_state = !empty($source_circuit_state) ? $source_circuit_state : [
                'code' => 'source_circuit_open',
                'reason' => 'پس از سه خطای موقت منبع پیاپی، درخواست‌های جدید دیجی‌کالا تا زمان تلاش مجدد متوقف شده‌اند.',
                'retry_after_seconds' => 60,
                'configured_count' => 0, 'eligible_count' => 0, 'cooldown_count' => 0, 'budget_count' => 0,
            ];
            $deferred_tail = evazar_queue_defer_claimed_source_tail($items, $item_index, $claim_token, $pool_state);
            $deferred_cnt += absint($deferred_tail['deferred'] ?? 0);
            $batch_run_summary_status = 'source_circuit_open';
            $batch_run_summary_reason = (string) ($deferred_tail['message'] ?? 'محصولات هنوز درخواست‌نشده به علت فعال‌شدن محافظ منبع به تعویق افتادند.');
            break;
        }
        if ($batch_collect_enabled && ($current_prefetch['mode'] ?? '') === 'pool_unavailable') {
            $pool_state = is_array($current_prefetch['pool_state'] ?? null) ? $current_prefetch['pool_state'] : (array) ($current_prefetch['diagnostic'] ?? []);
            $deferred_tail = evazar_queue_defer_claimed_source_tail($items, $item_index, $claim_token, $pool_state);
            $deferred_cnt += absint($deferred_tail['deferred'] ?? 0);
            $batch_run_summary_status = 'worker_pool_cooldown';
            $batch_run_summary_reason = (string) ($deferred_tail['message'] ?? 'محصولات ارسال‌نشده به علت نبود Worker قابل‌استفاده به انتظار برگشتند.');
            break;
        }
        if ($batch_collect_enabled && $current_dkp_for_pool !== '' && empty($current_prefetch)
            && function_exists('evazar_queue_product_source_worker_pool_state')) {
            $pool_state = evazar_queue_product_source_worker_pool_state('import_source');
            if (empty($pool_state['eligible_count'])) {
                $deferred_tail = evazar_queue_defer_claimed_source_tail($items, $item_index, $claim_token, $pool_state);
                $deferred_cnt += absint($deferred_tail['deferred'] ?? 0);
                $batch_run_summary_status = 'worker_pool_cooldown';
                $batch_run_summary_reason = (string) ($deferred_tail['message'] ?? 'محصولات ارسال‌نشده به علت نبود Worker قابل‌استفاده به انتظار برگشتند.');
                break;
            }
        }

        // In Gemini batch mode, fetch one product per distinct eligible source Worker (max 5).
        // Each result is cached by DKP and consumed once by the normal import path; the DB claim
        // and per-DKP import lock still govern queue ownership and prevent duplicate writes.
        if ($batch_collect_enabled
            && function_exists('evazar_queue_parallel_transport_available')
            && evazar_queue_parallel_transport_available()
            && function_exists('evazar_queue_prefetch_product_sources_parallel')) {
            $current_dkp = preg_replace('/[^0-9]/', '', (string) $item->dkp);
            $source_cache = $GLOBALS['evazar_queue_prefetched_product_source'] ?? [];
            if ($current_dkp !== '' && (!is_array($source_cache) || !array_key_exists($current_dkp, $source_cache))) {
                $source_wave = [];
                $source_pool_state = function_exists('evazar_queue_product_source_worker_pool_state') ? evazar_queue_product_source_worker_pool_state('import_source') : ['eligible_count' => 0];
                $configured_wave_cap = function_exists('evazar_queue_product_source_fetch_concurrency')
                    ? evazar_queue_product_source_fetch_concurrency() : 5;
                $available_wave_cap = absint($source_pool_state['eligible_count'] ?? 0);
                $wave_cap = max(1, min(5, (int) $configured_wave_cap, max(1, $available_wave_cap)));
                foreach (array_slice($items, $item_index, $wave_cap) as $wave_item) {
                    $wave_dkp = preg_replace('/[^0-9]/', '', (string) ($wave_item->dkp ?? ''));
                    if ($wave_dkp === '' || (is_array($source_cache) && array_key_exists($wave_dkp, $source_cache))) continue;
                    $source_wave[] = $wave_item;
                }
                if (!empty($source_wave)) {
                    evazar_queue_prefetch_product_sources_parallel($source_wave, $wave_cap);
                }
            }
        }

        $post_prefetch_map = $GLOBALS['evazar_queue_prefetched_product_source'] ?? [];
        $post_prefetch_entry = ($current_dkp_for_pool !== '' && is_array($post_prefetch_map) && isset($post_prefetch_map[$current_dkp_for_pool]) && is_array($post_prefetch_map[$current_dkp_for_pool]))
            ? $post_prefetch_map[$current_dkp_for_pool] : [];
        if ($batch_collect_enabled && ($post_prefetch_entry['mode'] ?? '') === 'worker_failure_deferred') {
            $pool_state = is_array($post_prefetch_entry['pool_state'] ?? null) ? $post_prefetch_entry['pool_state'] : evazar_queue_product_source_worker_pool_state('import_source');
            $deferred_one = evazar_queue_defer_attempted_source_item($item, $claim_token, (array) ($post_prefetch_entry['diagnostic'] ?? []), $pool_state);
            unset($GLOBALS['evazar_queue_prefetched_product_source'][$current_dkp_for_pool]);
            $deferred_cnt += absint($deferred_one['deferred'] ?? 0);
            $batch_run_summary_status = 'worker_pool_cooldown';
            $batch_run_summary_reason = 'درخواست واقعی Worker ناموفق بود و پس از آن استخر Workerها در دسترس نماند؛ محصولاتِ درخواست‌شده جداگانه به انتظار برگشتند.';
            continue;
        }
        if ($batch_collect_enabled && ($post_prefetch_entry['mode'] ?? '') === 'pool_unavailable') {
            $pool_state = is_array($post_prefetch_entry['pool_state'] ?? null) ? $post_prefetch_entry['pool_state'] : (array) ($post_prefetch_entry['diagnostic'] ?? []);
            $deferred_tail = evazar_queue_defer_claimed_source_tail($items, $item_index, $claim_token, $pool_state);
            $deferred_cnt += absint($deferred_tail['deferred'] ?? 0);
            $batch_run_summary_status = 'worker_pool_cooldown';
            $batch_run_summary_reason = (string) ($deferred_tail['message'] ?? 'محصولات ارسال‌نشده به علت نبود Worker قابل‌استفاده به انتظار برگشتند.');
            break;
        }

        // In mandatory Gemini-only batch mode, stop each product just before its
        // normal AI request. Products that do not need AI still follow the existing path.
        if ($batch_collect_enabled) $GLOBALS['evazar_ai_product_batch_collect'] = true;
        $result = evazar_core_process_import($item->dkp);
        unset($GLOBALS['evazar_ai_product_batch_collect']);

        if (is_array($result) && !empty($result['__evazar_ai_batch_checkpoint']) && is_array($result['context'] ?? null)) {
            $consecutive_source_failures = 0;
            $batch_pending[] = ['item' => $item, 'checkpoint' => $result];
            // Source requests are already rate-bounded to one product per distinct eligible Worker, max five.
            // Retain the legacy pause only if this host cannot run the parallel transport.
            if ($batch_collect_enabled && !evazar_queue_parallel_transport_available()) usleep(300000);
            elseif (!$batch_collect_enabled && !$is_manual) sleep(2);
            elseif (!$batch_collect_enabled) usleep(200000);
            continue;
        }

        if (is_wp_error($result)) {
            $err_code = $result->get_error_code() ?: 'UNKNOWN';
            $err_msg  = $result->get_error_message();
            if ($batch_collect_enabled && function_exists('evazar_queue_log_pre_gemini_failure')) {
                evazar_queue_log_pre_gemini_failure($item, $result);
            }

            // Only missing/invalid source category paths enter review quarantine. Keep the
            // partially saved product ID so an administrator can inspect it before retrying.
            $category_quarantine_code = evazar_queue_category_source_quarantine_reason($result);
            if ($category_quarantine_code !== '') {
                $outer_data = $result->get_error_data($err_code);
                $outer_data = is_array($outer_data) ? $outer_data : [];
                $related_product_id = absint($outer_data['post_id'] ?? 0);
                $auto_retry_days = evazar_queue_category_quarantine_auto_retry_days();
                $auto_retry_at = $auto_retry_days > 0
                    ? evazar_queue_mysql_after($auto_retry_days * (defined('DAY_IN_SECONDS') ? DAY_IN_SECONDS : 86400))
                    : null;
                $category_inner_code = strtoupper(sanitize_key((string) ($outer_data['category_error_code'] ?? '')));
                $quarantine_message = sanitize_textarea_field(
                    'نیازمند بررسی دستی: مسیر دسته‌بندی مبدأ از دیجی‌کالا موجود/قابل‌تأیید نبود. این وضعیت به معنی غیرفعال بودن قطعی کالا نیست. '
                    . 'خطای داخلی دسته‌بندی=' . ($category_inner_code !== '' ? $category_inner_code : 'unknown')
                    . ($auto_retry_days > 0 ? '؛ تلاش خودکار مجدد پس از ' . $auto_retry_days . ' روز برنامه‌ریزی شد.' : '؛ تلاش خودکار خاموش است و این مورد فقط با اقدام مدیر بازمی‌گردد.')
                    . ' جزئیات اصلی: ' . $err_msg
                );
                $quarantined = $wpdb->update(
                    $table_name,
                    [
                        'status' => 'quarantined',
                        'related_product_id' => $related_product_id,
                        'error_code' => $category_quarantine_code,
                        'error_log' => $quarantine_message,
                        'last_error_at' => current_time('mysql'),
                        'claim_token' => '',
                        'claimed_at' => null,
                        'next_attempt_at' => $auto_retry_at,
                    ],
                    ['id' => (int) $item->id, 'claim_token' => $claim_token, 'status' => 'processing']
                );
                if ($quarantined !== false && (int) $quarantined > 0) {
                    $quarantined_cnt++;
                    if ($batch_run_summary_reason === '') {
                        $batch_run_summary_reason = 'یک یا چند محصول به‌علت نبود مسیر معتبر دسته‌بندی مبدأ به فهرست قرنطینهٔ بررسی منتقل شدند.';
                    }
                    if (function_exists('evazar_gemini_log_event')) {
                        evazar_gemini_log_event(
                            'queue_product_category_path_quarantined',
                            'محصول به‌دلیل نبود مسیر معتبر دسته‌بندی مبدأ از صف عادی خارج و برای بررسی جداگانه نگه داشته شد؛ این به‌تنهایی اثبات غیرفعال بودن کالا نیست.',
                            '', 0, $auto_retry_at ? strtotime($auto_retry_at) : 0,
                            [
                                'queue_item_id' => absint($item->id),
                                'dkp' => sanitize_text_field((string) $item->dkp),
                                'related_product_id' => $related_product_id,
                                'quarantine_code' => $category_quarantine_code,
                                'category_error_code' => $category_inner_code,
                                'automatic_retry_days' => $auto_retry_days,
                                'automatic_retry_at' => (string) ($auto_retry_at ?? ''),
                            ]
                        );
                    }
                    continue;
                }
                error_log('[EVazar Core] Failed to quarantine missing-source-category queue row; queue item ID ' . absint($item->id) . '. Normal retry handling will continue.');
            }

            // Global source restrictions (rate limit/access rejection) defer the claimed run.
            // A transient 5xx/timeout/malformed product response only defers this item, allowing
            // the remaining products to proceed. Three consecutive transient source failures open
            // a short circuit and defer only the not-yet-visited tail; earlier valid checkpoints
            // remain eligible for the Gemini batch below.
            $source_policy = evazar_queue_upstream_source_failure_policy($result);
            if (!empty($source_policy)) {
                $delay = max(30, min(900, absint($source_policy['delay_seconds'] ?? 60)));
                $resume_at = time() + $delay;
                $resume_mysql = evazar_queue_mysql_timestamp($resume_at);
                $resume_label = evazar_queue_local_datetime($resume_at) ?: $resume_mysql;
                $queue_error_code = sanitize_text_field((string) ($source_policy['queue_error_code'] ?? 'DIGIKALA_SOURCE_UNAVAILABLE'));
                $reason = (string) ($source_policy['reason'] ?? 'اختلال موقت منبع دیجی‌کالا');

                if (($source_policy['action'] ?? 'defer_item') === 'defer_run') {
                    $pause_msg = sanitize_textarea_field(
                        $reason . '؛ برای جلوگیری از درخواست‌های پشت‌سرهم، محصولات این نوبت تا ' . $resume_label
                        . ' به تعویق افتادند و شمارنده Retry افزایش نیافت. جزئیات: ' . $err_msg
                    );
                    $updated_rows = $wpdb->update(
                        $table_name,
                        [
                            'status' => 'pending',
                            'error_code' => $queue_error_code,
                            'error_log' => $pause_msg,
                            'last_error_at' => current_time('mysql'),
                            'claim_token' => '',
                            'claimed_at' => null,
                            'next_attempt_at' => $resume_mysql,
                        ],
                        ['status' => 'processing', 'claim_token' => $claim_token]
                    );
                    if ($updated_rows === false) {
                        error_log('[EVazar Core] Failed to defer claimed queue rows after a global Digikala source restriction.');
                        $updated_rows = 0;
                    }
                    $deferred_cnt += max(0, (int) $updated_rows);
                    $batch_run_summary_status = 'source_restriction';
                    $batch_run_summary_reason = $reason . '؛ ' . max(0, (int) $updated_rows) . ' ردیف به تعویق افتاد.';
                    $msg = $reason . ' شناسایی شد؛ این نوبت به‌دلیل محدودیت/رد درخواست منبع متوقف شد. '
                        . max(0, (int) $updated_rows) . ' محصولِ ارسال‌نشده بدون افزایش Retry به صف برگشت. '
                        . 'زمان تلاش بعدی زودتر از ' . $resume_label . ' نخواهد بود.';
                    return [
                        'processed' => $success_cnt + $failed_cnt + $deferred_cnt + $quarantined_cnt,
                        'success' => $success_cnt,
                        'failed' => $failed_cnt,
                        'deferred' => $deferred_cnt,
                        'message' => $msg,
                    ];
                }

                $consecutive_source_failures++;
                $item_msg = sanitize_textarea_field(
                    $reason . '؛ فقط همین محصول به‌طور موقت به صف انتظار برگشت و شمارنده Retry افزایش نیافت. '
                    . 'زمان تلاش مجدد زودتر از ' . $resume_label . ' نخواهد بود. جزئیات: ' . $err_msg
                );
                $item_updated = $wpdb->update(
                    $table_name,
                    [
                        'status' => 'pending',
                        'error_code' => $queue_error_code,
                        'error_log' => $item_msg,
                        'last_error_at' => current_time('mysql'),
                        'claim_token' => '',
                        'claimed_at' => null,
                        'next_attempt_at' => $resume_mysql,
                    ],
                    ['id' => (int) $item->id, 'claim_token' => $claim_token, 'status' => 'processing']
                );
                if ($item_updated === false) {
                    error_log('[EVazar Core] Failed to defer one queue item after a transient Digikala source error; queue item ID ' . absint($item->id) . '.');
                } elseif ((int) $item_updated > 0) {
                    $deferred_cnt++;
                }
                if (function_exists('evazar_gemini_log_event')) {
                    evazar_gemini_log_event(
                        'queue_source_item_deferred',
                        'خطای موقت منبع فقط برای همین محصول ثبت شد؛ پردازش محصولات بعدی ادامه می‌یابد.',
                        '', 0, $resume_at,
                        [
                            'queue_item_id' => absint($item->id),
                            'dkp' => sanitize_text_field((string) $item->dkp),
                            'source_error_code' => sanitize_key((string) ($source_policy['source_error_code'] ?? '')),
                            'consecutive_source_failures' => $consecutive_source_failures,
                            'queue_error_code' => $queue_error_code,
                        ]
                    );
                }

                if ($consecutive_source_failures >= 3 && !$source_circuit_open) {
                    $batch_run_summary_status = 'source_circuit_open';
                    $batch_run_summary_reason = 'سه خطای موقت منبع پیاپی؛ پاسخ‌های دریافت‌شده در موج جاری تعیین‌تکلیف می‌شوند و فقط محصولات بدون درخواست به تعویق می‌افتند.';
                    if ($batch_collect_enabled) {
                        $source_circuit_open = true;
                        $source_pool_snapshot = function_exists('evazar_queue_product_source_worker_pool_state')
                            ? evazar_queue_product_source_worker_pool_state('import_source') : [];
                        $source_circuit_state = [
                            'code' => 'source_circuit_open',
                            'reason' => 'پس از سه خطای موقت منبع پیاپی، درخواست‌های جدید دیجی‌کالا متوقف شده‌اند؛ پاسخ‌های ازقبل‌دریافت‌شده در موج فعلی هنوز پردازش می‌شوند.',
                            'retry_after_seconds' => $delay,
                            'configured_count' => absint($source_pool_snapshot['configured_count'] ?? 0),
                            'eligible_count' => absint($source_pool_snapshot['eligible_count'] ?? 0),
                            'cooldown_count' => absint($source_pool_snapshot['cooldown_count'] ?? 0),
                            'budget_count' => absint($source_pool_snapshot['budget_count'] ?? 0),
                        ];
                        $already_requested_tail = 0;
                        $prefetched_for_circuit = $GLOBALS['evazar_queue_prefetched_product_source'] ?? [];
                        foreach (array_slice($items, $item_index + 1) as $tail_item) {
                            $tail_dkp = preg_replace('/[^0-9]/', '', (string) ($tail_item->dkp ?? ''));
                            $tail_entry = ($tail_dkp !== '' && is_array($prefetched_for_circuit)) ? ($prefetched_for_circuit[$tail_dkp] ?? []) : [];
                            if (evazar_queue_source_item_has_attempted_request($tail_entry)) $already_requested_tail++;
                            // Do not invoke serial failover after opening the source circuit. The
                            // original failed Worker attempt is retained and the item is deferred
                            // individually, instead of creating an extra upstream request.
                            if ($tail_dkp !== '' && is_array($tail_entry) && ($tail_entry['mode'] ?? '') === 'fallback' && !empty($tail_entry['request_sent'])) {
                                $tail_entry['mode'] = 'worker_failure_deferred';
                                $tail_entry['pool_state'] = $source_circuit_state;
                                if (!is_array($tail_entry['diagnostic'] ?? null)) {
                                    $tail_entry['diagnostic'] = ['code' => 'worker_failure_during_source_circuit', 'detail' => 'درخواست Worker ارسال شد اما محافظ منبع پس از خطاهای پیاپی فعال شد؛ درخواست جایگزین جدید ارسال نشد.', 'attempted' => 1, 'http_code' => 0, 'error_scope' => 'worker'];
                                }
                                $tail_entry['diagnostic']['retry_after_seconds'] = $delay;
                                $GLOBALS['evazar_queue_prefetched_product_source'][$tail_dkp] = $tail_entry;
                            }
                        }
                        if (function_exists('evazar_gemini_log_event')) {
                            evazar_gemini_log_event(
                                'queue_source_circuit_open',
                                'پس از سه خطای موقت منبع پیاپی، درخواست‌های جدید متوقف شدند؛ محصولات دارای پاسخ دریافت‌شده در موج جاری همچنان تعیین‌تکلیف می‌شوند.',
                                '', 0, $resume_at,
                                ['consecutive_source_failures' => $consecutive_source_failures, 'already_requested_tail' => $already_requested_tail, 'tail_deferred' => 0, 'claim_token' => substr((string) $claim_token, 0, 8)]
                            );
                        }
                    } else {
                        // Preserve legacy behavior for non-batch imports, which do not prefetch a wave.
                        $tail_items = array_slice($items, $item_index + 1);
                        $tail_count = 0;
                        $circuit_msg = sanitize_textarea_field(
                            'پس از سه خطای موقت منبع پیاپی، محافظ صف فعال شد؛ این محصول هنوز ارسال نشده بود و برای جلوگیری از فشار بیشتر به دیجی‌کالا تا '
                            . $resume_label . ' به تعویق افتاد. شمارنده Retry افزایش نیافت.'
                        );
                        foreach ($tail_items as $tail_item) {
                            $tail_updated = $wpdb->update(
                                $table_name,
                                [
                                    'status' => 'pending', 'error_code' => 'DIGIKALA_SOURCE_CIRCUIT_OPEN',
                                    'error_log' => $circuit_msg, 'last_error_at' => current_time('mysql'),
                                    'claim_token' => '', 'claimed_at' => null, 'next_attempt_at' => $resume_mysql,
                                ],
                                ['id' => (int) $tail_item->id, 'claim_token' => $claim_token, 'status' => 'processing']
                            );
                            if ($tail_updated !== false && (int) $tail_updated > 0) $tail_count++;
                        }
                        $deferred_cnt += $tail_count;
                        if (function_exists('evazar_gemini_log_event')) {
                            evazar_gemini_log_event(
                                'queue_source_circuit_open',
                                'پس از سه خطای موقت منبع پیاپی، فقط محصولات هنوز بررسی‌نشده به تعویق افتادند.',
                                '', 0, $resume_at,
                                ['consecutive_source_failures' => $consecutive_source_failures, 'tail_deferred' => $tail_count, 'claim_token' => substr((string) $claim_token, 0, 8)]
                            );
                        }
                        break;
                    }
                }
                if ($batch_collect_enabled && $source_circuit_open) {
                    // Let any requests already submitted in this five-item wave finish; the next
                    // loop iteration defers only the first item without a real request marker.
                    continue;
                }

                // A short spacing still applies between product-source requests.
                if ($batch_collect_enabled) usleep(300000);
                elseif (!$is_manual) sleep(2);
                else usleep(200000);
                continue;
            }

            // A non-source failure (including product-specific errors) proves that the
            // preceding transient source streak was interrupted.
            $consecutive_source_failures = 0;
            // اتمام سهمیه روزانه Gemini «خطای کالا» نیست.
            // آیتم فعلی و تمام آیتم‌های هنوز پردازش‌نشده Batch را بدون افزایش retries
            // به pending برمی‌گردانیم و همه را تا زمان Reset واقعی Google عقب می‌اندازیم.
            if (in_array($err_code, ['gemini_quota_cooldown', 'gemini_rate_limited', 'gemini_temporary_unavailable', 'gemini_quota_probe_busy'], true)) {
                $data = $result->get_error_data($err_code);
                $resume_at = (is_array($data) && !empty($data['resume_at'])) ? (int) $data['resume_at'] : 0;
                $temporary_error_codes = ['gemini_rate_limited', 'gemini_temporary_unavailable', 'gemini_quota_probe_busy'];
                if ($resume_at <= time()) {
                    if ($err_code === 'gemini_rate_limited' && function_exists('evazar_gemini_rate_cooldown_until')) {
                        $resume_at = evazar_gemini_rate_cooldown_until();
                    } elseif ($err_code !== 'gemini_quota_probe_busy' && function_exists('evazar_get_gemini_global_quota_cooldown_until')) {
                        $resume_at = evazar_get_gemini_global_quota_cooldown_until();
                    }
                }
                if ($resume_at <= time()) $resume_at = time() + (in_array($err_code, $temporary_error_codes, true) ? 60 : DAY_IN_SECONDS);

                $resume_mysql = evazar_queue_mysql_timestamp($resume_at);
                $resume_label = in_array($err_code, $temporary_error_codes, true)
                    ? (evazar_queue_local_datetime($resume_at) ?: $resume_mysql)
                    : (function_exists('evazar_gemini_quota_reset_label') ? evazar_gemini_quota_reset_label($resume_at) : $resume_mysql);
                $pause_msg = $err_code === 'gemini_rate_limited'
                    ? 'محدودیت موقت 429 از Google Gemini دریافت شد؛ این کالا و کالاهای باقی‌مانده Batch تا ' . $resume_label . ' به تعویق افتادند. تعداد Retry افزایش نیافت.'
                    : ($err_code === 'gemini_temporary_unavailable'
                        ? 'Google Gemini موقتاً در دسترس نیست؛ این کالا و کالاهای باقی‌مانده Batch تا ' . $resume_label . ' به تعویق افتادند. تعداد Retry افزایش نیافت.'
                        : ($err_code === 'gemini_quota_probe_busy'
                            ? 'بررسی سهمیه Gemini پس از Reset هنوز در حال اجراست؛ این کالا و کالاهای باقی‌مانده Batch تا ' . $resume_label . ' به تعویق افتادند. تعداد Retry افزایش نیافت.'
                            : 'سهمیه روزانه Gemini تمام شده است؛ این کالا و کالاهای باقی‌مانده Batch تا ' . $resume_label . ' به تعویق افتادند. تعداد Retry افزایش نیافت.'));

                $remaining_ids = [];
                foreach ($items as $remaining_item) {
                    if ((int) $remaining_item->id >= (int) $item->id) {
                        $remaining_ids[] = (int) $remaining_item->id;
                    }
                }
                // If any products were held as batch checkpoints earlier in this same claim,
                // also return those rows to pending on a quota pause instead of leaving them stuck.
                foreach ((array) $batch_pending as $pending_entry) {
                    $pending_item = $pending_entry['item'] ?? null;
                    if ($pending_item && !in_array((int) $pending_item->id, $remaining_ids, true)) {
                        $remaining_ids[] = (int) $pending_item->id;
                    }
                }
                $remaining_ids = array_values(array_unique(array_map('absint', $remaining_ids)));

                if (!empty($remaining_ids)) {
                    $placeholders = implode(',', array_fill(0, count($remaining_ids), '%d'));
                    $queue_error_code = $err_code === 'gemini_rate_limited' ? 'GEMINI_RATE_LIMITED' : ($err_code === 'gemini_temporary_unavailable' ? 'GEMINI_TEMPORARY_UNAVAILABLE' : ($err_code === 'gemini_quota_probe_busy' ? 'GEMINI_QUOTA_PROBE_BUSY' : 'GEMINI_QUOTA_COOLDOWN'));
                    $query = "UPDATE $table_name SET status='pending', error_code=%s, error_log=%s, last_error_at=%s, claim_token='', claimed_at=NULL, next_attempt_at=%s WHERE claim_token=%s AND id IN ($placeholders)";
                    $prepare_args = array_merge([$query, $queue_error_code, $pause_msg, current_time('mysql'), $resume_mysql, $claim_token], $remaining_ids);
                    $wpdb->query(call_user_func_array([$wpdb, 'prepare'], $prepare_args));
                }

                // برای سازگاری با PHP نسخه‌های قدیمی، نتیجه UPDATE بالا به شکل positional
                // با آرایه پارامترهای $wpdb->prepare ساخته شده است؛ هیچ Retry ثبت نمی‌شود.
                $msg_prefix = $err_code === 'gemini_rate_limited' ? 'محدودیت موقت Gemini؛ پردازش صف تا ' : ($err_code === 'gemini_temporary_unavailable' ? 'اختلال موقت Gemini؛ پردازش صف تا ' : 'سهمیه روزانه Gemini تمام شده است؛ پردازش صف تا ');
                $msg = $msg_prefix . $resume_label . ' متوقف شد. هیچ درخواست دیگری به Worker ارسال نخواهد شد.';
                $batch_run_summary_status = 'gemini_pause';
                $batch_run_summary_reason = $pause_msg;
                return [
                    'processed' => $success_cnt,
                    'success'   => $success_cnt,
                    'failed'    => 0,
                    'message'   => $msg
                ];
            }

            // برخورد با قفل DKP یعنی واردات دیگری همین کالا را پردازش می‌کند؛
            // این وضعیت خطای کالا نیست و نباید شمارنده Retry را افزایش دهد.
            if ($err_code === 'DKP_IMPORT_IN_PROGRESS') {
                $defer_result = $wpdb->update(
                    $table_name,
                    [
                        'status'          => 'pending',
                        'error_code'      => 'DKP_IMPORT_IN_PROGRESS',
                        'error_log'       => sanitize_textarea_field($err_msg),
                        'last_error_at'   => current_time('mysql'),
                        'claim_token'     => '',
                        'claimed_at'      => null,
                        'next_attempt_at' => evazar_queue_mysql_after(60),
                    ],
                    ['id' => $item->id, 'claim_token' => $claim_token]
                );
                if ($defer_result !== false) {
                    $deferred_cnt++;
                    continue;
                }
                error_log('[EVazar Core] Failed to defer queue item after DKP lock conflict, queue item ID ' . absint($item->id) . '.');
            }

            if (in_array($err_code, ['invalid', 'invalid_dkp'], true)) {
                $invalid_message = 'شناسه DKP خالی یا فاقد رقم است؛ این محصول به Worker ارسال نشده و به‌عنوان خطای داده‌ای نهایی ثبت شد. برای تلاش مجدد ابتدا DKP رکورد صف باید اصلاح شود.';
                $invalid_saved = $wpdb->update(
                    $table_name,
                    [
                        'status' => 'failed',
                        'error_code' => 'INVALID_DKP',
                        'error_log' => $invalid_message,
                        'last_error_at' => current_time('mysql'),
                        'claim_token' => '',
                        'claimed_at' => null,
                        'next_attempt_at' => null,
                    ],
                    ['id' => (int) $item->id, 'claim_token' => $claim_token, 'status' => 'processing']
                );
                if ($invalid_saved === false) error_log('[EVazar Core] Failed to mark invalid-DKP queue row as terminal; queue item ID ' . absint($item->id) . '.');
                $failed_cnt++;
                continue;
            }

            $next_retries = ((int)$item->retries) + 1;
            // Keep every transient failed import eligible for another attempt; generic retry backoff caps at 10 minutes.
            $backoff = min(10, max(1, (int) pow(2, min(4, max(0, $next_retries - 1)))));
            $wpdb->update(
                $table_name,
                [
                    'status'        => 'pending',
                    'error_code'    => sanitize_text_field($err_code),
                    'error_log'     => sanitize_textarea_field($err_msg),
                    'last_error_at' => current_time('mysql'),
                    'retries'       => $next_retries,
                    'claim_token'   => '',
                    'claimed_at'    => null,
                    'next_attempt_at' => evazar_queue_mysql_after($backoff * 60)
                ],
                ['id' => $item->id, 'claim_token' => $claim_token]
            );
            $failed_cnt++;
        } else {
            $consecutive_source_failures = 0;
            // If the explicit AI rewrite flag appeared after this import had already passed its AI gate,
            // do not mark the queue item complete; let a fresh run observe and honor the flag.
            $late_rewrite_flag = (string) get_post_meta(absint($result), '_evazar_force_ai_rewrite', true) === '1';
            $ai_rewrite_ready = get_option('evazar_ai_enabled', '') === 'yes'
                && function_exists('evazar_has_ai_api_key') && evazar_has_ai_api_key();
            if ($late_rewrite_flag && $ai_rewrite_ready) {
                $defer_result = $wpdb->update(
                    $table_name,
                    [
                        'status' => 'pending',
                        'error_code' => 'AI_REWRITE_REQUEST_PENDING',
                        'error_log' => 'درخواست بازنویسی مدیر هنگام پردازش ثبت شد؛ کالا برای اجرای مرحله AI با درخواست تازه به صف بازگشت.',
                        'last_error_at' => current_time('mysql'),
                        'claim_token' => '',
                        'claimed_at' => null,
                        'next_attempt_at' => evazar_queue_mysql_after(30),
                    ],
                    ['id' => $item->id, 'claim_token' => $claim_token]
                );
                if ($defer_result !== false) {
                    $deferred_cnt++;
                    continue;
                }
                error_log('[EVazar Core] Failed to defer late AI rewrite queue item ID ' . absint($item->id) . '.');
            }

            // موفقیت آمیز
            $wpdb->update(
                $table_name, 
                [
                    'status'        => 'completed',
                    'error_code'    => '',
                    'error_log'     => '',
                    'last_error_at' => null,
                    'claim_token'   => '',
                    'claimed_at'    => null,
                    'next_attempt_at' => null
                ], 
                ['id' => $item->id, 'claim_token' => $claim_token]
            );
            
            // ذخیره SKU جهت جلوگیری از تکرار در آینده
            update_post_meta($result, '_sku', $item->dkp);

            // ثبت آخرین واردات موفق هر DKP در جدول تاریخچه مستقل از صف؛
            // با پاک‌سازی صف یا بازگردانی کالاها برای بازنویسی، تاریخچه حذف نمی‌شود.
            $history_table = evazar_queue_import_history_table_name();
            $imported_at = current_time('mysql', true); // UTC
            $history_saved = $wpdb->replace(
                $history_table,
                [
                    'dkp'         => (string) $item->dkp,
                    'product_id'  => absint($result),
                    'source_url'  => (string) $item->url,
                    'imported_at' => $imported_at,
                ],
                ['%s', '%d', '%s', '%s']
            );
            if ($history_saved === false) {
                // محصول وارد شده است؛ این خطا نباید وضعیت موفق محصول را به خطای واردات تبدیل کند.
                error_log('[EVazar Core] Failed to save import history for DKP ' . sanitize_text_field((string) $item->dkp) . ': ' . $wpdb->last_error);
            }
            $success_cnt++;
        }
        
        // در حالت Gemini دسته‌ای، ورودی‌ها را با فاصله کوتاه و یکنواخت آماده می‌کنیم:
        // ۳۰۰ms به‌جای وقفه ۲ ثانیه‌ای کران‌جاب؛ مسیر غیر دسته‌ای دست‌نخورده می‌ماند.
        if ($batch_collect_enabled) {
            usleep(300000);
        } elseif (!$is_manual) {
            sleep(2);
        } else {
            usleep(200000);
        }
    }

    if (evazar_queue_is_manually_paused()) {
        $released = evazar_queue_release_manual_pause_claims($claim_token);
        return [
            'processed' => $success_cnt + $failed_cnt + $deferred_cnt + $quarantined_cnt,
            'success' => $success_cnt,
            'failed' => $failed_cnt,
            'deferred' => $deferred_cnt,
            'message' => 'توقف دستی پیش از ارسال دسته Gemini اعمال شد؛ ' . $released . ' محصولِ ارسال‌نشده بدون افزایش Retry به صف انتظار برگشت.'
        ];
    }

    // Send the collected product prompts in groups, then resume each product through the
    // existing parser/save path. Worker-aware allocation is automatic; use cURL-multi for
    // concurrency where available, or balanced sequential assignment as a safe fallback.
    if (!empty($batch_pending) && $batch_parallel_transport_enabled) {
        $parallel_dispatch_result = evazar_queue_process_parallel_product_chunks($batch_pending, $claim_token, $success_cnt, $failed_cnt, $deferred_cnt);
        if (is_array($parallel_dispatch_result) && !empty($parallel_dispatch_result['halted'])) {
            $batch_run_summary_status = 'dispatch_halted';
            $batch_run_summary_reason = (string) ($parallel_dispatch_result['message'] ?? 'ارسال موازی دسته‌ها پیش از تکمیل همه دسته‌ها متوقف شد.');
        }
        if (evazar_queue_is_manually_paused()) {
            $released = evazar_queue_release_manual_pause_claims($claim_token);
            return [
                'processed' => $success_cnt + $failed_cnt + $deferred_cnt + $quarantined_cnt,
                'success' => $success_cnt,
                'failed' => $failed_cnt,
                'deferred' => $deferred_cnt,
                'message' => 'صف در حین پردازش دسته‌ای متوقف شد؛ موج جاری تمام شد و ' . $released . ' محصولِ ارسال‌نشده به صف انتظار برگشت.'
            ];
        }
    } elseif (!empty($batch_pending)) {
        $ai_batch_size = evazar_queue_product_batch_size();
        $batch_offset = 0;
        $partition = evazar_queue_partition_product_batches($batch_pending, $ai_batch_size);
        $chunks = $partition['chunks'];
        $process_entries = [];
        foreach ($chunks as $processable_chunk) $process_entries = array_merge($process_entries, $processable_chunk);
        if (!empty($partition['unpaired'])) {
            $waiting = evazar_queue_defer_batch_partner_entries($partition['unpaired'], $claim_token);
            $deferred_cnt += (int) ($waiting['deferred'] ?? count($partition['unpaired']));
        }
        $serial_chunk_index = 0;
        $serial_active_batch_size = $ai_batch_size;
        while ($batch_offset < count($process_entries)) {
            evazar_queue_heartbeat_run_lock();
            $serial_effective_batch_size = evazar_queue_product_batch_size();
            $serial_needs_repartition = ($serial_effective_batch_size !== $serial_active_batch_size);
            if (!$serial_needs_repartition) {
                foreach (array_slice($chunks, $serial_chunk_index) as $queued_chunk) {
                    if (count((array) $queued_chunk) > $serial_effective_batch_size) {
                        $serial_needs_repartition = true;
                        break;
                    }
                }
            }
            if ($serial_needs_repartition) {
                $serial_remaining_entries = array_slice($process_entries, $batch_offset);
                $serial_partition = evazar_queue_partition_product_batches($serial_remaining_entries, $serial_effective_batch_size);
                if (!empty($serial_partition['unpaired'])) {
                    $waiting = evazar_queue_defer_batch_partner_entries($serial_partition['unpaired'], $claim_token);
                    $deferred_cnt += (int) ($waiting['deferred'] ?? count($serial_partition['unpaired']));
                    // Partitioning only leaves an unpaired entry at the end of the unsent tail.
                    array_splice($process_entries, max($batch_offset, count($process_entries) - count($serial_partition['unpaired'])));
                }
                $chunks = (array) ($serial_partition['chunks'] ?? []);
                $serial_chunk_index = 0;
                $serial_active_batch_size = $serial_effective_batch_size;
            }
            $chunk = $chunks[$serial_chunk_index] ?? null;
            if (!is_array($chunk) || empty($chunk)) break;
            if (evazar_queue_is_manually_paused()) {
                $released = evazar_queue_release_manual_pause_claims($claim_token);
                return [
                    'processed' => $success_cnt + $failed_cnt + $deferred_cnt + $quarantined_cnt,
                    'success' => $success_cnt,
                    'failed' => $failed_cnt,
                    'deferred' => $deferred_cnt,
                    'message' => 'صف پیش از ارسال دسته بعدی متوقف شد؛ ' . $released . ' محصولِ ارسال‌نشده به صف انتظار برگشت.'
                ];
            }
            $assigned_worker_url = '';
            if ($batch_worker_distribution_enabled) {
                $serial_assignment = evazar_queue_select_parallel_gemini_workers(1);
                if (empty($serial_assignment)) {
                    $batch_run_summary_status = 'worker_unavailable';
                    $batch_run_summary_reason = 'هیچ Worker واجدشرایطی برای دسته بعدی موجود نبود؛ دسته‌های ارسال‌نشده به صف برگشتند.';
                    $remaining = array_slice($process_entries, $batch_offset);
                    $busy_error = new WP_Error('gemini_workers_busy', 'هیچ Worker واجدشرایطی برای دسته بعدی باقی نمانده؛ دسته‌های ارسال‌نشده به صف بازگشتند.');
                    $busy_error->add_data(['resume_at' => time() + 45]);
                    evazar_queue_defer_batched_items($remaining, $busy_error, $claim_token);
                    return [
                        'processed' => $success_cnt + $failed_cnt + $deferred_cnt + $quarantined_cnt,
                        'success' => $success_cnt,
                        'failed' => $failed_cnt,
                        'deferred' => $deferred_cnt + count($remaining),
                        'message' => 'Worker واجدشرایط برای دسته بعدی موجود نبود؛ دسته‌های باقی‌مانده بدون درخواست تک‌محصولی به صف بازگشتند.'
                    ];
                }
                $assigned_worker_url = (string) $serial_assignment[0];
                if (function_exists('evazar_gemini_log_event')) {
                    $assigned_host = wp_parse_url($assigned_worker_url, PHP_URL_HOST);
                    evazar_gemini_log_event(
                        'batch_worker_assigned',
                        'تخصیص چرخشی دسته‌ای در حالت transport ترتیبی به Worker واجدشرایط: ' . (is_string($assigned_host) ? $assigned_host : 'unknown-worker'),
                        $assigned_worker_url, 0, 0,
                        ['purpose' => 'product_import_batch', 'batch_size' => min(50, count($chunk))]
                    );
                }
            }
            $responses = evazar_generate_product_batch_ai_responses($chunk, $assigned_worker_url);
            if (is_wp_error($responses)) {
                $adaptive_error_kind = evazar_queue_product_batch_adaptive_error_kind($responses);
                if ($adaptive_error_kind !== '') {
                    evazar_queue_product_batch_adaptive_record_failure(
                        $adaptive_error_kind, 1, 1, evazar_queue_product_batch_adaptive_http_code($responses)
                    );
                } else {
                    evazar_queue_product_batch_adaptive_reset_success_streak();
                }
                // Invalid model JSON is not a product failure: defer the whole sent chunk,
                // do not increment retries, and keep processing later chunks/Workers.
                if (in_array($responses->get_error_code(), ['AI_BATCH_OUTPUT_INVALID', 'AI_BATCH_INVALID_JSON'], true)) {
                    evazar_queue_defer_batched_items($chunk, $responses, $claim_token, (string) $assigned_worker_url);
                    $deferred_cnt += count($chunk);
                    if (function_exists('evazar_gemini_log_event')) {
                        evazar_gemini_log_event('batch_json_invalid_deferred', 'خروجی JSON دسته Gemini نامعتبر بود؛ فقط همین دسته بدون افزایش Retry برای تلاش دسته‌ای بعدی به صف برگشت و پردازش دسته‌های دیگر ادامه یافت.', $assigned_worker_url, 200, (int) (($responses->get_error_data()['resume_at'] ?? 0)), [
                            'purpose' => 'product_import_batch', 'batch_size' => count($chunk), 'diagnostic_code' => 'batch_json_invalid', 'retry' => 1,
                        ]);
                    }
                    $batch_offset += count($chunk);
                    $serial_chunk_index++;
                    continue;
                }

                $remaining = array_slice($process_entries, $batch_offset);
                if ($responses->get_error_code() === 'gemini_request_outcome_unknown') {
                    evazar_queue_log_batch_deferred_event($chunk, $responses, time() + 120, (string) $assigned_worker_url, 'نتیجه نامشخص برای دسته ارسال‌شده؛ ایمنی جلوگیری از ارسال تکراری فعال شد');
                    // Only the current chunk was sent. Increment its retry generation so it gets
                    // a fresh request ID after the uncertainty window; later chunks were not sent
                    // and must not consume retries or receive different idempotency identities.
                    $sent_entries = array_slice($remaining, 0, count($chunk));
                    $not_sent_entries = array_slice($remaining, count($chunk));
                    foreach ($sent_entries as $uncertain_entry) {
                        $uncertain_item = $uncertain_entry['item'] ?? null;
                        if (!$uncertain_item || empty($uncertain_item->id)) continue;
                        $wpdb->update($table_name, [
                            'status' => 'pending',
                            'retries' => ((int) $uncertain_item->retries) + 1,
                            'error_code' => 'GEMINI_OUTCOME_UNKNOWN_RECOVERY',
                            'error_log' => sanitize_textarea_field('نتیجهٔ درخواست دسته‌ای Gemini نامشخص ماند؛ پس از مکث ایمنی، این دسته خودکار دوباره پردازش می‌شود. ممکن است سهمیهٔ Gemini دوباره مصرف شود. ' . $responses->get_error_message()),
                            'last_error_at' => current_time('mysql'),
                            'claim_token' => '',
                            'claimed_at' => null,
                            'next_attempt_at' => evazar_queue_mysql_after(120),
                        ], ['id' => (int) $uncertain_item->id, 'claim_token' => (string) $claim_token]);
                    }
                    foreach ($not_sent_entries as $unsent_entry) {
                        $unsent_item = $unsent_entry['item'] ?? null;
                        if (!$unsent_item || empty($unsent_item->id)) continue;
                        $wpdb->update($table_name, [
                            'status' => 'pending',
                            'error_code' => 'BATCH_DEFERRED_AFTER_UNKNOWN',
                            'error_log' => 'این دسته هنوز به Worker ارسال نشده بود؛ پس از مکث کوتاه بدون افزایش Retry دوباره از صف انتخاب می‌شود.',
                            'last_error_at' => current_time('mysql'),
                            'claim_token' => '',
                            'claimed_at' => null,
                            'next_attempt_at' => evazar_queue_mysql_after(30),
                        ], ['id' => (int) $unsent_item->id, 'claim_token' => (string) $claim_token]);
                    }
                    $deferred_cnt += count($remaining);
                    return [
                        'processed' => $success_cnt + $failed_cnt + $deferred_cnt + $quarantined_cnt,
                        'success' => $success_cnt,
                        'failed' => $failed_cnt,
                        'deferred' => $deferred_cnt,
                        'message' => 'نتیجهٔ یک دسته نامشخص بود؛ فقط همان دسته پس از مکث ایمنی با شناسهٔ تازه تلاش می‌شود و دسته‌های ارسال‌نشده بدون افزایش Retry به صف بازگشتند.',
                    ];
                }
                if (evazar_queue_is_gemini_pause_error($responses)) {
                    $pause_code = $responses->get_error_code();
                    $worker_scoped_pause_codes = [
                        'gemini_quota_cooldown',
                        'gemini_rate_limited',
                        'gemini_temporary_unavailable',
                        'gemini_workers_busy',
                        'gemini_batch_in_progress',
                        'gemini_worker_auth_failed',
                    ];
                    // A quota/rate/busy response from the assigned Worker should not strand
                    // later chunks if other configured Workers remain eligible. Defer only
                    // this chunk; the next loop iteration selects a fresh Worker from the
                    // updated cooldown/lock state. If no Worker remains eligible, preserve
                    // fail-closed behavior and defer the whole unsent tail.
                    $workers_ready_for_next_chunks = in_array($pause_code, $worker_scoped_pause_codes, true)
                        ? evazar_queue_parallel_healthy_worker_count()
                        : 0;
                    if ($workers_ready_for_next_chunks > 0) {
                        $paused = evazar_queue_defer_batched_items($chunk, $responses, $claim_token);
                        $deferred_cnt += count($chunk);
                        if (function_exists('evazar_gemini_log_event')) {
                            evazar_gemini_log_event(
                                'batch_worker_paused_continue',
                                'دسته فعلی به علت مکث/اشغال Worker به تعویق افتاد؛ ' . $workers_ready_for_next_chunks . ' Worker برای دسته‌های بعدی واجدشرایط است و پردازش ادامه می‌یابد.',
                                $assigned_worker_url, 0, (int) (($responses->get_error_data()['resume_at'] ?? 0)),
                                ['purpose' => 'product_import_batch', 'batch_size' => min(50, count($chunk)), 'retry' => 1]
                            );
                        }
                        $batch_offset += count($chunk);
                        $serial_chunk_index++;
                        continue;
                    }

                    $paused = evazar_queue_defer_batched_items($remaining, $responses, $claim_token, (string) $assigned_worker_url);
                    $deferred_cnt += count($remaining);
                    return [
                        'processed' => $success_cnt + $failed_cnt + $deferred_cnt + $quarantined_cnt,
                        'success' => $success_cnt,
                        'failed' => $failed_cnt,
                        'deferred' => $deferred_cnt,
                        'message' => $paused['message'] . ' هیچ Worker واجدشرایط دیگری باقی نماند؛ تمام دسته‌های ارسال‌نشده به صف برگشتند.',
                    ];
                }
                $batch_error = new WP_Error('AI_BATCH_FAILED', 'درخواست دسته‌ای Gemini ناموفق بود: ' . $responses->get_error_message());
                foreach ($remaining as $pending_entry) {
                    $final = evazar_queue_finalize_batched_result($pending_entry['item'], $batch_error, $claim_token);
                    if (($final['kind'] ?? '') === 'success') $success_cnt++;
                    elseif (($final['kind'] ?? '') === 'deferred') $deferred_cnt++;
                    else $failed_cnt++;
                }
                break;
            }

            if (evazar_queue_product_batch_adaptive_response_is_successful($chunk, $responses)) {
                evazar_queue_product_batch_adaptive_record_successes(1);
            } else {
                evazar_queue_product_batch_adaptive_reset_success_streak();
            }

            foreach ($chunk as $pending_entry) {
                $item = $pending_entry['item'];
                $checkpoint = $pending_entry['checkpoint'];
                $dkp = preg_replace('/[^0-9]/', '', (string) ($checkpoint['dkp'] ?? $item->dkp));
                $ai_response = $responses[$dkp] ?? new WP_Error('AI_BATCH_MISSING_RESPONSE', 'برای محصول ' . $dkp . ' خروجی مستقلی از Gemini دریافت نشد.');

                if (is_wp_error($ai_response) && evazar_queue_is_gemini_pause_error($ai_response)) {
                    $remaining = array_slice($process_entries, $batch_offset);
                    $paused = evazar_queue_defer_batched_items($remaining, $ai_response, $claim_token);
                    return [
                        'processed' => count($items),
                        'success' => $success_cnt,
                        'failed' => $failed_cnt,
                        'deferred' => $deferred_cnt,
                        'message' => $paused['message'] . ' هیچ درخواست دیگری پس از تشخیص محدودیت ارسال نشد.',
                    ];
                }

                if (is_wp_error($ai_response)) {
                    // Keep the special ambiguous-outcome code intact: wrapping it would
                    // re-enable automatic queue retries for a request that may have run.
                    if ($ai_response->get_error_code() === 'gemini_request_outcome_unknown' || evazar_queue_is_gemini_pause_error($ai_response)) {
                        $result = $ai_response;
                    } else {
                        $result = new WP_Error('AI_BATCH_ITEM_FAILED', 'تولید محتوای محصول در مرحلهٔ دسته‌ای ناموفق بود: ' . $ai_response->get_error_message());
                    }
                } else {
                    $resume_bundle = [
                        'context' => $checkpoint['context'],
                        'expected_matching_ids' => (array) ($checkpoint['expected_matching_ids'] ?? []),
                    ];
                    $result = evazar_core_process_import($item->dkp, $resume_bundle, $ai_response);
                }

                $final = evazar_queue_finalize_batched_result($item, $result, $claim_token);
                if (($final['kind'] ?? '') === 'pause') {
                    $remaining = array_slice($process_entries, $batch_offset);
                    $paused = evazar_queue_defer_batched_items($remaining, $final['error'], $claim_token);
                    return [
                        'processed' => count($items),
                        'success' => $success_cnt,
                        'failed' => $failed_cnt,
                        'deferred' => $deferred_cnt,
                        'message' => $paused['message'] . ' هیچ درخواست دیگری پس از تشخیص محدودیت ارسال نشد.',
                    ];
                }
                if (($final['kind'] ?? '') === 'success') $success_cnt++;
                elseif (($final['kind'] ?? '') === 'deferred') $deferred_cnt++;
                else $failed_cnt++;
                $batch_offset++;
            }
            $serial_chunk_index++;
        }
    }

    if ($batch_collect_enabled && $batch_run_summary_status === 'running') {
        $batch_run_summary_status = 'completed';
        $batch_run_summary_reason = 'نوبت به مسیر پایان عادی رسید.';
    }
    $msg = "تعداد " . count($items) . " کالا از صف پردازش شد (" . $success_cnt . " کالا با موفقیت وارد گردید"
        . ($failed_cnt > 0 ? " و " . $failed_cnt . " مورد در این نوبت خطا داشت" : "")
        . ($deferred_cnt > 0 ? " و " . $deferred_cnt . " مورد با مکث برای تلاش مجدد زمان‌بندی شد" : "")
        . ").";
    return [
        'processed' => count($items),
        'success'   => $success_cnt,
        'failed'    => $failed_cnt,
        'deferred'  => $deferred_cnt,
        'message'   => $msg
    ];
}

// ==========================================
// ==========================================
// 5. اجرای مرکزی عملیات مدیریتی صف (همگام با AJAX و POST)
// ==========================================

/** True only when a taxonomy term has a complete, provenance-stamped source identity. */
if (!function_exists('evazar_queue_term_source_identity_complete')) {
    function evazar_queue_term_source_identity_complete($term_id, $taxonomy) {
        $term_id = absint($term_id);
        if ($term_id <= 0 || !function_exists('get_term_meta')) return false;
        $verified = (string)get_term_meta($term_id, '_evazar_dk_source_verified', true) === '1';
        $kind = (string)get_term_meta($term_id, '_evazar_dk_source_kind', true);
        $version = (string)get_term_meta($term_id, '_evazar_dk_source_map_version', true);
        if ($taxonomy === 'evazar_category') {
            if ($kind === 'derived_brand_landing') {
                $generated = function_exists('evazar_normalize_digikala_source_path')
                    ? evazar_normalize_digikala_source_path((string)get_term_meta($term_id, '_evazar_dk_generated_url', true)) : '';
                return $generated !== '' && in_array($version, ['2.9.84.27-derived', '2.9.84.29-derived'], true);
            }
            $path = function_exists('evazar_normalize_digikala_source_path')
                ? evazar_normalize_digikala_source_path((string)get_term_meta($term_id, '_evazar_dk_url', true)) : '';
            return $verified && $kind === 'digikala_breadcrumb' && $path !== ''
                && in_array($version, ['2.9.19', '2.9.84.27', '2.9.84.28', '2.9.84.29', '2.9.84.29-live-category-metadata-repair'], true);
        }
        if ($taxonomy === 'evazar_brand') {
            $path = function_exists('evazar_normalize_digikala_brand_source_path')
                ? evazar_normalize_digikala_brand_source_path((string)get_term_meta($term_id, '_evazar_dk_url', true)) : '';
            $source_id = absint(get_term_meta($term_id, '_evazar_dk_brand_id', true));
            $code = trim((string)get_term_meta($term_id, '_evazar_dk_brand_code', true));
            $slug = strtolower(trim((string)get_term_meta($term_id, '_evazar_dk_slug', true)));
            $map_version = in_array($version, [
                '2.9.84.20-brand-live-backfill-2026-10-25', '2.9.84.27', '2.9.84.27-live-metadata-repair',
                '2.9.84.28', '2.9.84.28-live-metadata-repair', '2.9.84.29', '2.9.84.29-live-metadata-repair',
                '2.9.84.31-live-metadata-repair', '2.9.84.32-live-metadata-repair',
                '2.9.84.33-live-brand-registration'
            ], true);
            return $verified && $source_id > 0 && $code !== '' && $path !== '' && $slug !== '' && $map_version
                && (preg_match('#^/brand/([^/]+)/$#', $path, $m) === 1) && strtolower((string)$m[1]) === $slug;
        }
        return false;
    }
}

/** Parse stored/source breadcrumbs and require an authoritative URL for every real category. */
if (!function_exists('evazar_queue_breadcrumbs_have_explicit_paths')) {
    function evazar_queue_breadcrumbs_have_explicit_paths($breadcrumbs) {
        if (is_string($breadcrumbs)) $breadcrumbs = json_decode($breadcrumbs, true);
        if (!is_array($breadcrumbs) || !$breadcrumbs || !function_exists('evazar_normalize_digikala_source_path')) return false;
        $seen = 0;
        foreach ($breadcrumbs as $crumb) {
            if (!is_array($crumb)) return false;
            $title = trim((string)($crumb['title'] ?? $crumb['name'] ?? $crumb['title_fa'] ?? ''));
            $raw = $crumb['url']['uri'] ?? ($crumb['url'] ?? '');
            if (is_array($raw)) $raw = $raw['uri'] ?? '';
            if ($title === '' || in_array($title, ['دیجی‌کالا', 'دیجیکالا'], true) || stripos($title, 'dkp-') === 0) continue;
            if (is_string($raw) && strpos($raw, '/product/') !== false) continue;
            $path = evazar_normalize_digikala_source_path((string)$raw);
            if ($path === '' || !preg_match('#^/(?:search|main)/#i', $path)) return false;
            $seen++;
        }
        return $seen > 0;
    }
}

function evazar_queue_run_admin_action($action_name, $context = []) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';

    switch ($action_name) {
        case 'retry_all_quarantined_items':
            // Fail closed if the queue cannot prove DKP uniqueness; do not activate legacy duplicate queue rows.
            if (!function_exists('evazar_queue_table_has_verified_dkp_unique_index') || !evazar_queue_table_has_verified_dkp_unique_index($table_name)) {
                return ['success' => false, 'message' => 'بازگردانی گروهی متوقف شد؛ شاخص یکتای DKP در جدول صف تأیید نشد. این عملیات هیچ ردیف قرنطینه‌ای را جابه‌جا نکرد. ابتدا ساختار جدول و ردیف‌های تکراری قدیمی را بررسی کنید.'];
            }
            $intake_table = evazar_queue_capacity_intake_table_name();
            if (!evazar_queue_ensure_capacity_intake_table()) {
                return ['success' => false, 'message' => 'صف انتظار ظرفیت آماده نیست؛ هیچ ردیف قرنطینه‌ای تغییر نکرد.'];
            }
            if (!function_exists('evazar_queue_table_has_verified_dkp_unique_index') || !evazar_queue_table_has_verified_dkp_unique_index($intake_table)) {
                return ['success' => false, 'message' => 'بازگردانی گروهی متوقف شد؛ یکتایی DKP در صف انتظار ظرفیت تأیید نشد و برای جلوگیری از ثبت تکراری هیچ موردی منتقل نشد.'];
            }
            if (!evazar_queue_capacity_lock_acquire(3)) {
                return ['success' => false, 'message' => 'قفل تخصیص صف مشغول است؛ بازگردانی انجام نشد. چند ثانیه بعد دوباره تلاش کنید.'];
            }

            $transaction_started = false;
            $quarantined_total = 0;
            $eligible_total = 0;
            $already_staged = 0;
            try {
                if ($wpdb->query('START TRANSACTION') === false) {
                    return ['success' => false, 'message' => 'شروع تراکنش پایگاه داده ناموفق بود؛ هیچ ردیف قرنطینه‌ای تغییر نکرد.'];
                }
                $transaction_started = true;
                $quarantined_total = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table_name` WHERE status='quarantined'");
                if (!empty($wpdb->last_error)) {
                    return ['success' => false, 'message' => 'شمارش قرنطینه‌ها ناموفق بود؛ بازگردانی انجام نشد.'];
                }
                if ($quarantined_total < 1) {
                    if ($wpdb->query('COMMIT') === false) return ['success' => false, 'message' => 'ثبت پایان تراکنش ناموفق بود؛ عملیات بازگردانی تأیید نشد.'];
                    $transaction_started = false;
                    return ['success' => true, 'message' => 'هیچ ردیف قرنطینه‌شده‌ای برای بازگردانی وجود ندارد.'];
                }
                // Only strictly numeric DKPs can enter the automated retry pipeline. Invalid identities stay quarantined for review.
                $eligible_total = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table_name` WHERE status='quarantined' AND dkp REGEXP '^[1-9][0-9]*$'");
                if (!empty($wpdb->last_error)) {
                    return ['success' => false, 'message' => 'اعتبارسنجی شناسه‌های DKP ناموفق بود؛ هیچ موردی به صف منتقل نشد.'];
                }
                $already_staged = (int) $wpdb->get_var(
                    "SELECT COUNT(*) FROM `$table_name` q INNER JOIN `$intake_table` i ON i.dkp=q.dkp
                     WHERE q.status='quarantined' AND q.dkp REGEXP '^[1-9][0-9]*$' AND i.mode IN ('qretry','qrewrite')"
                );
                if (!empty($wpdb->last_error)) {
                    return ['success' => false, 'message' => 'بررسی مواردی که قبلاً در صف انتظار هستند ناموفق بود؛ بازگردانی انجام نشد.'];
                }
                if ($eligible_total > 0) {
                    $staged = $wpdb->query(
                        "INSERT INTO `$intake_table` (dkp, url, mode)
                         SELECT dkp, url, 'qretry' FROM `$table_name`
                         WHERE status='quarantined' AND dkp REGEXP '^[1-9][0-9]*$'
                         ORDER BY id ASC
                         ON DUPLICATE KEY UPDATE
                           url = VALUES(url),
                           mode = CASE WHEN mode IN ('rewrite','qrewrite') THEN 'qrewrite' ELSE 'qretry' END"
                    );
                    if ($staged === false) {
                        return ['success' => false, 'message' => 'ثبت موارد قرنطینه در صف انتظار ظرفیت ناموفق بود؛ تغییرات تراکنش بازگردانده شد.'];
                    }
                }
                if ($wpdb->query('COMMIT') === false) {
                    return ['success' => false, 'message' => 'ثبت نهایی صف انتظار ناموفق بود؛ تغییرات تراکنش بازگردانده شد.'];
                }
                $transaction_started = false;
            } finally {
                if ($transaction_started) $wpdb->query('ROLLBACK');
                evazar_queue_capacity_lock_release();
            }

            delete_transient('evazar_queue_dashboard_stats_v2');
            if ($eligible_total < 1) {
                return ['success' => false, 'message' => 'هیچ ردیف قرنطینه‌ای با DKP کاملاً عددی پیدا نشد؛ ' . number_format_i18n($quarantined_total) . ' مورد برای بررسی دستی در قرنطینه باقی ماند.'];
            }
            // This existing scheduler also promotes capacity-waiting rows into only the currently free active slots.
            if (function_exists('evazar_queue_maybe_schedule_followup')) evazar_queue_maybe_schedule_followup();
            $waiting_now = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$intake_table`");
            $quarantine_waiting = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM `$table_name` q INNER JOIN `$intake_table` i ON i.dkp=q.dkp
                 WHERE q.status='quarantined' AND i.mode IN ('qretry','qrewrite')"
            );
            $invalid_total = max(0, $quarantined_total - $eligible_total);
            return [
                'success' => true,
                'message' => number_format_i18n(max(0, $eligible_total - $already_staged)) . ' ردیف قرنطینه با DKP معتبر وارد مسیر تلاش مجدد شد. موارد ابتدا در صف انتظار ظرفیت قرار می‌گیرند و فقط به‌اندازه ظرفیت فعال به صف پردازش می‌روند؛ ' . number_format_i18n($quarantine_waiting) . ' مورد از این گروه هنوز منتظر ظرفیت است. مجموع صف انتظار ظرفیت=' . number_format_i18n($waiting_now) . '.'
                    . ($invalid_total > 0 ? ' تعداد ' . number_format_i18n($invalid_total) . ' ردیف با DKP نامعتبر در قرنطینه باقی ماند و خودکار بازگردانده نشد.' : '')
                    . (function_exists('evazar_queue_is_manually_paused') && evazar_queue_is_manually_paused() ? ' صف در حال حاضر متوقف است؛ موارد در انتظار می‌مانند تا صف را ادامه دهید.' : '')
                    . ' شناسه‌ها و گزارش خطای قبلی حفظ می‌شوند؛ محصولی حذف یا مستقیماً بازنویسی نمی‌شود.'
            ];

        case 'draft_quarantined_product':
            $item_id = absint($context['item_id'] ?? 0);
            if ($item_id < 1) return ['success' => false, 'message' => 'شناسه ردیف صف معتبر نیست.'];
            $row = $wpdb->get_row($wpdb->prepare("SELECT id, dkp, status, error_log, related_product_id, error_code FROM `$table_name` WHERE id=%d LIMIT 1", $item_id));
            if (!$row || (string) $row->status !== 'quarantined' || (string) $row->error_code !== 'SOURCE_CATEGORY_PATH_MISSING') {
                return ['success' => false, 'message' => 'این عملیات فقط برای محصول قرنطینه‌شده به‌علت نبود مسیر دسته‌بندی مبدأ مجاز است.'];
            }
            if (!evazar_queue_quarantine_row_has_saved_partial_product($row)) {
                return ['success' => false, 'message' => 'این تلاش پیش از ذخیره‌سازی متوقف شده یا شواهد ذخیره ناقص ندارد؛ برای جلوگیری از خارج‌کردن محصول قبلیِ احتمالاً سالم از انتشار، وضعیت آن تغییر نکرد.'];
            }
            $related_product_id = absint($row->related_product_id ?? 0);
            if ($related_product_id < 1) return ['success' => false, 'message' => 'این ردیف به محصول ذخیره‌شده‌ای متصل نیست؛ هیچ تغییری انجام نشد.'];
            $draft_result = evazar_queue_draft_quarantined_product($related_product_id);
            if (is_wp_error($draft_result)) return ['success' => false, 'message' => $draft_result->get_error_message()];
            if (empty($draft_result['success'])) return ['success' => false, 'message' => 'تغییر وضعیت محصول انجام نشد.'];
            $note = ' | محصول مرتبط #' . $related_product_id . ' به درخواست مدیر در ' . current_time('mysql') . ' به پیش‌نویس منتقل شد؛ حذف نشده است.';
            $logged = $wpdb->update($table_name, ['error_log' => (string) $row->error_log . $note], ['id' => $item_id, 'status' => 'quarantined']);
            if ($logged === false || (int) $logged !== 1) return ['success' => false, 'message' => 'محصول به پیش‌نویس منتقل شد اما ثبت یادداشت در ردیف قرنطینه تأیید نشد؛ شناسه محصول: ' . $related_product_id];
            delete_transient('evazar_queue_dashboard_stats_v2');
            return ['success' => true, 'message' => $draft_result['message'] . ' شناسه محصول: ' . $related_product_id];

        case 'retry_quarantined_item':
        case 'exclude_quarantined_item':
        case 'requeue_excluded_item':
            $item_id = absint($context['item_id'] ?? 0);
            if ($item_id < 1) return ['success' => false, 'message' => 'شناسه ردیف صف معتبر نیست.'];
            $row = $wpdb->get_row($wpdb->prepare("SELECT id, dkp, status, error_log, related_product_id FROM `$table_name` WHERE id=%d LIMIT 1", $item_id));
            if (!$row) return ['success' => false, 'message' => 'ردیف صف یافت نشد.'];
            $current_status = (string) $row->status;
            $suffix = '';
            $data = [];
            if ($action_name === 'retry_quarantined_item' && $current_status === 'quarantined') {
                $suffix = ' | بازگردانی دستی مدیر به صف در ' . current_time('mysql') . '.';
                $data = [
                    'status' => 'pending', 'retries' => 0, 'error_code' => '',
                    'error_log' => (string) $row->error_log . $suffix,
                    'last_error_at' => current_time('mysql'), 'claim_token' => '',
                    'claimed_at' => null, 'next_attempt_at' => null,
                ];
            } elseif ($action_name === 'exclude_quarantined_item' && $current_status === 'quarantined') {
                $suffix = ' | خروج از صف واردات به درخواست مدیر در ' . current_time('mysql') . '; رکورد صف حفظ شده و محصول موجود در سایت حذف نشده است.';
                $data = [
                    'status' => 'excluded', 'error_code' => 'EXCLUDED_BY_ADMIN',
                    'error_log' => (string) $row->error_log . $suffix,
                    'last_error_at' => current_time('mysql'), 'claim_token' => '',
                    'claimed_at' => null, 'next_attempt_at' => null,
                ];
            } elseif ($action_name === 'requeue_excluded_item' && $current_status === 'excluded') {
                $suffix = ' | بازگردانی دستی رکورد مستثناشده به صف در ' . current_time('mysql') . '.';
                $data = [
                    'status' => 'pending', 'retries' => 0, 'error_code' => '',
                    'error_log' => (string) $row->error_log . $suffix,
                    'last_error_at' => current_time('mysql'), 'claim_token' => '',
                    'claimed_at' => null, 'next_attempt_at' => null,
                ];
            } else {
                return ['success' => false, 'message' => 'عملیات با وضعیت فعلی این ردیف سازگار نیست. وضعیت فعلی: ' . $current_status];
            }
            $updated = $wpdb->update($table_name, $data, ['id' => $item_id, 'status' => $current_status]);
            if ($updated === false || (int) $updated !== 1) return ['success' => false, 'message' => 'به‌روزرسانی ردیف صف انجام نشد؛ وضعیت آن تغییر نکرد.'];
            delete_transient('evazar_queue_dashboard_stats_v2');
            if (in_array($action_name, ['retry_quarantined_item', 'requeue_excluded_item'], true)) {
                if (function_exists('evazar_queue_maybe_schedule_followup')) evazar_queue_maybe_schedule_followup();
                return ['success' => true, 'message' => 'محصول ' . $row->dkp . ' به صف انتظار بازگشت. رکورد محصول موجود در سایت حذف نشده است.'];
            }
            return ['success' => true, 'message' => 'محصول ' . $row->dkp . ' از پردازش خودکار خارج شد؛ رکورد برای جلوگیری از ورود خودکار تکراری حفظ شده است و محصول موجود در سایت حذف نشده است.'];

        case 'pause_queue':
            evazar_queue_set_manual_paused(true);
            delete_transient('evazar_queue_dashboard_stats_v2');
            return [
                'success' => true,
                'message' => 'صف واردات متوقف شد. محصولات جدید همچنان در صف ذخیره می‌شوند، اما پردازش خودکار متوقف است؛ موجی که قبلاً به Worker ارسال شده ممکن است تا پایان کامل شود.'
            ];

        case 'resume_queue':
            evazar_queue_set_manual_paused(false);
            delete_transient('evazar_queue_dashboard_stats_v2');
            return [
                'success' => true,
                'message' => 'صف واردات فعال شد؛ ادامه پردازش پس از مکث کوتاه زمان‌بندی شد و فاصله عادی Cron پس از آن حفظ می‌شود.'
            ];

        case 'manual_process':
            if (evazar_queue_is_manually_paused()) {
                return ['success' => false, 'message' => 'صف واردات متوقف است؛ ابتدا روی «ادامه صف واردات» بزنید.'];
            }
            $res = evazar_cron_worker_logic(true);
            return [
                'success' => true,
                'message' => $res['message'] ?? 'پردازش دستی صف با موفقیت انجام شد.'
            ];

        case 'sync_existing_items':
            if (!function_exists('evazar_sync_product_categories') || !function_exists('evazar_sync_product_brand')) {
                require_once plugin_dir_path(__FILE__) . 'importer.php';
            }
            $posts = get_posts([
                'post_type'      => 'evazar_product',
                'posts_per_page' => 200,
                'post_status'    => 'any',
                'orderby'        => 'ID',
                'order'          => 'ASC',
            ]);
            $synced_cats = 0; $failed_cats = 0;
            $synced_brands = 0; $failed_brands = 0; $skipped_brands = 0;
            $source_fetches = 0;
            $last_errors = [];

            foreach ($posts as $p) {
                $post_id = absint($p->ID);
                $crumbs = get_post_meta($post_id, '_evazar_breadcrumbs', true);
                $cat_name = trim((string)get_post_meta($post_id, '_evazar_category', true));
                $dkp = get_post_meta($post_id, '_evazar_sku', true);
                if (empty($dkp)) $dkp = get_post_meta($post_id, '_sku', true);
                if (empty($dkp)) {
                    $product_url = (string)get_post_meta($post_id, '_evazar_dk_url', true);
                    if (preg_match('/dkp-(\d+)/i', $product_url, $m)) $dkp = $m[1];
                }

                $category_terms = wp_get_object_terms($post_id, 'evazar_category', ['fields' => 'ids']);
                $brand_terms = wp_get_object_terms($post_id, 'evazar_brand', ['fields' => 'ids']);
                $category_terms_error = is_wp_error($category_terms);
                $brand_terms_error = is_wp_error($brand_terms);
                $category_terms = $category_terms_error ? [] : array_values(array_unique(array_map('absint', (array)$category_terms)));
                $brand_terms = $brand_terms_error ? [] : array_values(array_unique(array_map('absint', (array)$brand_terms)));

                $needs_category_refresh = !$category_terms_error && !evazar_queue_breadcrumbs_have_explicit_paths($crumbs);
                if (!$category_terms_error) {
                    foreach ($category_terms as $term_id) {
                        if (!evazar_queue_term_source_identity_complete($term_id, 'evazar_category')) { $needs_category_refresh = true; break; }
                    }
                }
                $needs_brand_refresh = !$brand_terms_error && count($brand_terms) !== 1;
                if (!$brand_terms_error && count($brand_terms) === 1 && !evazar_queue_term_source_identity_complete($brand_terms[0], 'evazar_brand')) $needs_brand_refresh = true;
                $saved_brand_fa = trim((string)get_post_meta($post_id, '_evazar_brand', true));
                if (!$brand_terms && $saved_brand_fa !== '') $needs_brand_refresh = true;
                if ($category_terms_error) { $failed_cats++; $last_errors[] = "کالا {$post_id}: خواندن دسته‌های فعلی ناموفق بود."; }
                if ($brand_terms_error) { $failed_brands++; $last_errors[] = "کالا {$post_id}: خواندن برند فعلی ناموفق بود."; }

                $fresh = false;
                $fresh_error = '';
                if (($needs_category_refresh || $needs_brand_refresh) && ctype_digit((string)$dkp) && (int)$dkp > 0) {
                    $fresh = evazar_fetch_raw_product_data((string)$dkp, true, false, 'taxonomy_identity_sync');
                    $source_fetches++;
                    if (!is_array($fresh)) {
                        $diag = $GLOBALS['evazar_last_product_fetch_diagnostic'] ?? [];
                        $fresh_error = trim((string)($diag['detail'] ?? ''));
                        if ($fresh_error === '') $fresh_error = 'دریافت تازهٔ هویت مبدأ از Worker ناموفق بود.';
                    }
                }

                $live_crumbs = $crumbs;
                $live_cat_name = $cat_name;
                // If category identity actually needs refreshing, never silently fall back to stale
                // stored breadcrumbs when the fresh source payload is missing/invalid.
                if ($needs_category_refresh && !is_array($fresh)) $live_crumbs = '';
                if (is_array($fresh) && $needs_category_refresh && !evazar_queue_breadcrumbs_have_explicit_paths($fresh['breadcrumbs'] ?? [])) $live_crumbs = '';
                if (is_array($fresh)) {
                    if (!empty($fresh['breadcrumbs']) && evazar_queue_breadcrumbs_have_explicit_paths($fresh['breadcrumbs'])) {
                        $live_crumbs = $fresh['breadcrumbs'];
                        $encoded_crumbs = wp_json_encode($live_crumbs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                        if (!is_string($encoded_crumbs) || $encoded_crumbs === '') {
                            $last_errors[] = "کالا {$post_id}: رمزگذاری مسیرهای تازهٔ دسته ناموفق بود.";
                            $live_crumbs = '';
                        } else {
                            update_post_meta($post_id, '_evazar_breadcrumbs', $encoded_crumbs);
                            if ((string)get_post_meta($post_id, '_evazar_breadcrumbs', true) !== $encoded_crumbs) {
                                $last_errors[] = "کالا {$post_id}: ذخیرهٔ بردکرامب تازه تأیید نشد.";
                                $live_crumbs = '';
                            } else { $live_crumbs = $encoded_crumbs; }
                        }
                    }
                    if (!empty($fresh['category'])) {
                        $live_cat_name = trim((string)$fresh['category']);
                        update_post_meta($post_id, '_evazar_category', $live_cat_name);
                    }
                }

                // Category sync now receives only complete, explicit source breadcrumbs. The
                // category function itself validates paths and reports WP_Error; never count an
                // object-shaped WP_Error as success (WP_Error is truthy in PHP).
                // A product with assigned categories (or a refresh need) but no usable source
                // breadcrumbs is a failed category sync, not a silent success. This also catches
                // legacy products that have no stored category name/crumbs and no usable DKP.
                $category_sync_required = $needs_category_refresh || !empty($category_terms) || !empty($live_crumbs) || $live_cat_name !== '';
                if (!$category_terms_error && $category_sync_required) {
                    if (evazar_queue_breadcrumbs_have_explicit_paths($live_crumbs)) {
                        $brand_for_cat = is_array($fresh) && !empty($fresh['brand']) ? (string)$fresh['brand'] : (string)get_post_meta($post_id, '_evazar_brand', true);
                        $brand_en_for_cat = is_array($fresh) && !empty($fresh['brand_en']) ? (string)$fresh['brand_en'] : (string)get_post_meta($post_id, '_evazar_brand_en', true);
                        $cat_result = evazar_sync_product_categories($post_id, $live_crumbs, $live_cat_name, $brand_for_cat, $brand_en_for_cat);
                        if (is_wp_error($cat_result) || !is_numeric($cat_result) || (int)$cat_result <= 0) {
                            $failed_cats++;
                            $msg = is_wp_error($cat_result) ? $cat_result->get_error_message() : 'تابع همگام‌سازی دسته نتیجهٔ معتبر برنگرداند.';
                            $last_errors[] = "کالا {$post_id}: {$msg}";
                            if (function_exists('evazar_import_log')) evazar_import_log('error', 'همگام‌سازی دستهٔ موجود ناموفق بود: ' . $msg, (string)$dkp, ['post_id'=>$post_id, 'source'=>'existing_category_sync_failed']);
                        } else { $synced_cats++; }
                    } else {
                        $failed_cats++;
                        $msg = $fresh_error !== '' ? $fresh_error : 'برای این کالا بردکرامب کامل و دارای URL صریح مبدأ موجود نیست.';
                        $last_errors[] = "کالا {$post_id}: {$msg}";
                        if (function_exists('evazar_import_log')) evazar_import_log('error', 'همگام‌سازی دسته بدون مسیر صریح مبدأ اجرا نشد: ' . $msg, (string)$dkp, ['post_id'=>$post_id, 'source'=>'existing_category_source_missing']);
                    }
                }

                // Resolve brand identity from the exact source payload when a term is missing,
                // unverified, ambiguous, or multiple brands are attached. Otherwise reuse the
                // verified metadata of the single assigned term; never fall back to name-only sync.
                if (!$brand_terms_error && ($needs_brand_refresh || (is_array($fresh) && !empty($fresh['brand_source_path'])))) {
                    $source_path = is_array($fresh) ? evazar_normalize_digikala_brand_source_path((string)($fresh['brand_source_path'] ?? '')) : '';
                    $source_id = is_array($fresh) ? absint($fresh['brand_source_id'] ?? 0) : 0;
                    $source_code = is_array($fresh) ? sanitize_text_field((string)($fresh['brand_source_code'] ?? '')) : '';
                    $brand_fa = is_array($fresh) ? trim((string)($fresh['brand'] ?? '')) : '';
                    $brand_en = is_array($fresh) ? trim((string)($fresh['brand_en'] ?? '')) : '';
                    if ($brand_fa !== '' && $source_path !== '' && $source_id > 0 && $source_code !== '') {
                        $brand_result = evazar_sync_product_brand($post_id, $brand_fa, $brand_en, $source_path, $source_id, $source_code);
                        if (is_wp_error($brand_result) || $brand_result !== true) {
                            $failed_brands++;
                            $msg = is_wp_error($brand_result) ? $brand_result->get_error_message() : 'هویت برند یا اتصال نهایی پس از ذخیره تأیید نشد.';
                            $last_errors[] = "کالا {$post_id}: {$msg}";
                            if (function_exists('evazar_import_log')) evazar_import_log('error', 'همگام‌سازی برند با هویت مبدأ تأیید نشد: ' . $msg, (string)$dkp, ['post_id'=>$post_id, 'source'=>'existing_brand_sync_failed', 'brand_source_id'=>$source_id, 'brand_source_path'=>$source_path]);
                        } else {
                            // evazar_sync_product_brand() has already verified the assigned term and
                            // synchronized legacy display/search metadata from that exact term.
                            $synced_brands++;
                        }
                    } elseif ($saved_brand_fa !== '' || !empty($brand_terms)) {
                        $failed_brands++;
                        $msg = $fresh_error !== '' ? $fresh_error : 'شناسه، کد و URL معتبر مبدأ برند در پاسخ محصول کامل نیست؛ اتصال نام‌محور انجام نشد.';
                        $last_errors[] = "کالا {$post_id}: {$msg}";
                        if (function_exists('evazar_import_log')) evazar_import_log('error', 'همگام‌سازی برند متوقف شد؛ هویت صریح مبدأ ناقص است: ' . $msg, (string)$dkp, ['post_id'=>$post_id, 'source'=>'existing_brand_source_missing']);
                    } else { $skipped_brands++; }
                } elseif (!$brand_terms_error && count($brand_terms) === 1) {
                    $brand_term = get_term($brand_terms[0], 'evazar_brand');
                    $source_path = evazar_normalize_digikala_brand_source_path((string)get_term_meta($brand_terms[0], '_evazar_dk_url', true));
                    $source_id = absint(get_term_meta($brand_terms[0], '_evazar_dk_brand_id', true));
                    $source_code = trim((string)get_term_meta($brand_terms[0], '_evazar_dk_brand_code', true));
                    $brand_en = trim((string)get_term_meta($brand_terms[0], '_evazar_brand_en', true));
                    $brand_fa = ($brand_term && !is_wp_error($brand_term)) ? (string)$brand_term->name : '';
                    if ($brand_fa !== '' && $source_path !== '' && $source_id > 0 && $source_code !== '' && evazar_queue_term_source_identity_complete($brand_terms[0], 'evazar_brand')) {
                        $brand_result = evazar_sync_product_brand($post_id, $brand_fa, $brand_en, $source_path, $source_id, $source_code);
                        if (is_wp_error($brand_result) || $brand_result !== true) {
                            $failed_brands++;
                            $msg = is_wp_error($brand_result) ? $brand_result->get_error_message() : 'اتصال برند تأیید نشد.';
                            $last_errors[] = "کالا {$post_id}: {$msg}";
                        } else { $synced_brands++; }
                    } else {
                        $failed_brands++;
                        $msg = 'متادیتای هویت برند کامل و تأییدشده نیست؛ ابزار ترمیم متادیتای برند را اجرا کن.';
                        $last_errors[] = "کالا {$post_id}: {$msg}";
                    }
                } elseif (!$brand_terms_error && !$brand_terms && $saved_brand_fa === '') {
                    $skipped_brands++;
                }

                // ترمیم ساختار آرایه گالری تصاویر جهت جلوگیری از شکستن کوئری استرینگ‌ها
                $raw_gal = get_post_meta($post_id, '_evazar_gallery', true);
                if (!empty($raw_gal) && is_string($raw_gal) && strpos($raw_gal, '[') !== 0) {
                    $cleaned_gal = preg_split('/,(?=https?:\/\/)/i', $raw_gal);
                    $cleaned_gal = array_values(array_filter(array_map('trim', $cleaned_gal)));
                    update_post_meta($post_id, '_evazar_gallery', json_encode($cleaned_gal, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
                }

                // همگام‌سازی متادیتاهای رنک‌مث برای کالاهای قدیمی (در صورت خالی بودن)
                $existing_rm_desc = get_post_meta($post_id, 'rank_math_description', true);
                if (empty($existing_rm_desc)) {
                    $p_title = get_the_title($post_id);
                    $site_name = get_bloginfo('name') ?: 'ایوازار';
                    $auto_desc = "مشخصات فنی، قیمت و خرید اینترنتی " . mb_substr($p_title, 0, 75) . " در " . $site_name . " با تضمین اصالت و بهترین قیمت روز.";
                    update_post_meta($post_id, 'rank_math_description', $auto_desc);
                }
                $existing_rm_kw = get_post_meta($post_id, 'rank_math_focus_keyword', true);
                if (empty($existing_rm_kw)) {
                    $p_title = get_the_title($post_id);
                    $words = preg_split('/\s+/', trim($p_title));
                    $auto_kw = implode(' ', array_slice($words, 0, 4));
                    update_post_meta($post_id, 'rank_math_focus_keyword', $auto_kw);
                }
                if (!get_post_meta($post_id, 'rank_math_robots', true)) update_post_meta($post_id, 'rank_math_robots', ['index']);

                $existing_short = get_post_field('post_excerpt', $post_id);
                if (!empty($existing_short)) wp_update_post(['ID' => $post_id, 'post_excerpt' => '']);
                delete_post_meta($post_id, '_evazar_short_desc');
            }

            $failed_total = $failed_cats + $failed_brands;
            $message = "همگام‌سازی پایان یافت: دسته‌های موفق {$synced_cats}، دسته‌های ناموفق {$failed_cats}، برندهای موفق {$synced_brands}، برندهای ناموفق {$failed_brands}، برندهای بدون نیاز به تغییر {$skipped_brands}، درخواست‌های تازهٔ منبع {$source_fetches}.";
            if ($last_errors) $message .= ' چند خطای اول: ' . implode(' | ', array_slice($last_errors, 0, 4));
            return [
                'success' => ($failed_total === 0),
                'partial' => ($failed_total > 0),
                'message' => $message,
                'synced_categories' => $synced_cats, 'failed_categories' => $failed_cats,
                'synced_brands' => $synced_brands, 'failed_brands' => $failed_brands,
                'skipped_brands' => $skipped_brands, 'source_fetches' => $source_fetches,
            ];

        case 'generate_terms_seo_content':
            if (!function_exists('evazar_taxonomy_seo_enqueue_missing_terms')) {
                require_once plugin_dir_path(__FILE__) . 'taxonomy-seo-queue.php';
            }
            $result = evazar_taxonomy_seo_enqueue_missing_terms();
            $queued = (int) ($result['queued'] ?? 0);
            $deferred = (int) ($result['deferred'] ?? 0);
            $message = $queued > 0
                ? "{$queued} دسته/برند فاقد محتوای معتبر به صف مستقل سئو اضافه شدند. دسته‌ها و برندها جداگانه و در batchهای ۲ تا ۵ موردی پردازش می‌شوند؛ واردسازی محصولات متوقف نمی‌شود."
                : 'مورد واجد شرایط جدیدی برای صف سئو پیدا نشد؛ محتوای دستی و محتوای معتبر موجود دست‌نخورده ماند.';
            if ($deferred > 0) $message .= " {$deferred} مورد به‌دلیل فاصلهٔ امن تلاش مجدد فعلاً به تعویق افتادند.";
            return [
                'success' => empty($result['error']),
                'message' => $message,
                'queued' => $queued,
                'deferred' => $deferred,
                'attempted' => 0,
                'generated' => 0,
                'errors' => 0,
                'skipped' => 0,
            ];

        case 'cleanup_downloaded_images':
            $cleaned = 0;
            $products = get_posts([
                'post_type'      => 'evazar_product',
                'posts_per_page' => -1,
                'post_status'    => 'any',
                'fields'         => 'ids'
            ]);
            foreach ($products as $pid) {
                $thumb_id = get_post_thumbnail_id($pid);
                if ($thumb_id) {
                    delete_post_thumbnail($pid);
                    wp_delete_attachment($thumb_id, true);
                    $cleaned++;
                }
            }
            return [
                'success' => true,
                'message' => "عملیات پاکسازی با موفقیت انجام شد: {$cleaned} فایل تصویر و بندانگشتی از پوشه uploads هاست حذف شدند. تصاویر کالاها هم‌اکنون به صورت مستقیم و با حداکثر سرعت از CDN دیجی‌کالا لود می‌شوند."
            ];

        case 'retry_failed_items':
            $intake_table = evazar_queue_capacity_intake_table_name();
            if (!evazar_queue_ensure_capacity_intake_table()) {
                return ['success' => false, 'message' => 'جدول صف انتظار ظرفیت در دسترس نیست؛ هیچ وضعیت صفی تغییر نکرد.'];
            }
            if (!evazar_queue_capacity_lock_acquire(3)) {
                return ['success' => false, 'message' => 'قفل مدیریت ظرفیت مشغول است؛ تلاش مجدد انجام نشد. چند ثانیه بعد دوباره اجرا کنید.'];
            }
            $transaction_started = false;
            try {
                if ($wpdb->query('START TRANSACTION') === false) {
                    return ['success' => false, 'message' => 'شروع تراکنش دیتابیس ممکن نشد؛ هیچ وضعیت صفی تغییر نکرد.'];
                }
                $transaction_started = true;
                $failed_total = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table_name` WHERE status='failed'");
                $failed_identifiable = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table_name` WHERE status='failed' AND dkp<>''");
                $staged = $wpdb->query(
                    "INSERT INTO `$intake_table` (dkp, url, mode)
                     SELECT dkp, url, 'retry' FROM `$table_name` WHERE status='failed' AND dkp<>'' ORDER BY id ASC
                     ON DUPLICATE KEY UPDATE
                       url = VALUES(url),
                       mode = CASE WHEN mode='rewrite' THEN mode ELSE 'retry' END"
                );
                if ($staged === false) {
                    return ['success' => false, 'message' => 'ثبت کالاهای خطادار در صف نگهداری ظرفیت ناموفق شد؛ تغییرات صف بازگردانده شد.'];
                }
                $promotion = evazar_queue_promote_capacity_waiting_locked();
                if (!empty($wpdb->last_error)) {
                    return ['success' => false, 'message' => 'انتقال کالاهای خطادار با خطای دیتابیس مواجه شد؛ تغییرات صف بازگردانده شد.'];
                }
                if ($wpdb->query('COMMIT') === false) {
                    return ['success' => false, 'message' => 'ثبت نهایی تلاش مجدد ناموفق بود؛ تغییرات صف بازگردانده شد.'];
                }
                $transaction_started = false;
            } finally {
                if ($transaction_started) $wpdb->query('ROLLBACK');
                evazar_queue_capacity_lock_release();
            }
            delete_transient('evazar_queue_dashboard_stats_v2');
            if (function_exists('evazar_queue_maybe_schedule_followup')) evazar_queue_maybe_schedule_followup();
            $waiting_now = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$intake_table`");
            return [
                'success' => true,
                'message' => 'تلاش مجدد برای ' . $failed_identifiable . ' کالای دارای شناسه ثبت شد؛ ' . (int) ($promotion['promoted'] ?? 0) . ' مورد اکنون به صف فعال منتقل شد و ' . $waiting_now . ' مورد در صف منتظر ظرفیت باقی مانده است.' . ($failed_total > $failed_identifiable ? ' تعداد ' . ($failed_total - $failed_identifiable) . ' ردیف فاقد DKP قابل‌استفاده بود و به صف جدید منتقل نشد.' : '')
            ];

        case 'clear_queue':
            $wpdb->query("TRUNCATE TABLE $table_name");
            $intake_table = evazar_queue_capacity_intake_table_name();
            $wpdb->query("TRUNCATE TABLE `$intake_table`");
            delete_transient('evazar_queue_dashboard_stats_v2');
            return [
                'success' => true,
                'message' => 'تمام آیتم‌های صف فعال و صف انتظار ظرفیت با موفقیت پاک‌سازی شدند.'
            ];

        case 'clear_all_short_descriptions':
        case 'rewrite_old_short_descriptions':
            $all_p = get_posts([
                'post_type'      => 'evazar_product',
                'posts_per_page' => -1,
                'post_status'    => 'any',
                'fields'         => 'ids'
            ]);

            $cleared_count = 0;
            foreach ($all_p as $pid) {
                $cur = get_post_field('post_excerpt', $pid);
                $cur_meta = get_post_meta($pid, '_evazar_short_desc', true);
                if (!empty($cur) || !empty($cur_meta)) {
                    wp_update_post([
                        'ID'           => $pid,
                        'post_excerpt' => ''
                    ]);
                    delete_post_meta($pid, '_evazar_short_desc');
                    $cleared_count++;
                }
            }

            return [
                'success' => true,
                'message' => "توضیحات کوتاه برای تمام کالاهای سایت به طور کامل حذف شد (تعداد {$cleared_count} کالا پاکسازی گردید)."
            ];

        case 'requeue_all_for_ai_rewrite':
            if (get_option('evazar_ai_enabled', '') !== 'yes' || !function_exists('evazar_has_ai_api_key') || !evazar_has_ai_api_key()) {
                return ['success' => false, 'message' => 'برای بازنویسی کامل، ابتدا هوش مصنوعی را در تنظیمات ایوازار فعال کنید و کلید API معتبر را بررسی کنید. هیچ محصول یا صفی تغییر داده نشد.'];
            }
            $intake_table = evazar_queue_capacity_intake_table_name();

            // Mark the requested rewrite without deleting current product content.
            $all_products_to_mark = get_posts([
                'post_type'      => 'evazar_product',
                'posts_per_page' => -1,
                'post_status'    => 'any',
                'fields'         => 'ids'
            ]);
            foreach ($all_products_to_mark as $pid) {
                delete_post_meta($pid, '_evazar_force_ai_rewrite_done');
                update_post_meta($pid, '_evazar_force_ai_rewrite', '1');
            }

            if (!evazar_queue_ensure_capacity_intake_table()) {
                return ['success' => false, 'message' => 'جدول صف انتظار ظرفیت آماده نیست. پرچم بازنویسی ثبت شده، اما صف تغییر نکرده است؛ گزارش دیتابیس را بررسی کنید.'];
            }

            // Collect product identities before taking the queue lock; every queue/intake
            // membership decision is re-read under lock below to avoid crossing admissions.
            $posts_table = $wpdb->posts;
            $meta_table = $wpdb->postmeta;
            $all_products = $wpdb->get_results("
                SELECT p.ID AS post_id,
                    COALESCE(
                        (SELECT pm.meta_value FROM {$meta_table} pm WHERE pm.post_id=p.ID AND pm.meta_key='_evazar_sku' AND pm.meta_value<>'' ORDER BY pm.meta_id ASC LIMIT 1),
                        (SELECT pm.meta_value FROM {$meta_table} pm WHERE pm.post_id=p.ID AND pm.meta_key='_sku' AND pm.meta_value<>'' ORDER BY pm.meta_id ASC LIMIT 1),
                        (SELECT pm.meta_value FROM {$meta_table} pm WHERE pm.post_id=p.ID AND pm.meta_key='_evazar_dk_id' AND pm.meta_value<>'' ORDER BY pm.meta_id ASC LIMIT 1)
                    ) AS dkp
                FROM {$posts_table} p
                WHERE p.post_type='evazar_product' AND p.post_status NOT IN ('trash','auto-draft')
                ORDER BY p.ID ASC
            ");
            if ($wpdb->last_error !== '') {
                error_log('[EVazar Queue] Product identity scan failed during explicit AI rewrite queue reconciliation.');
                return ['success' => false, 'message' => 'خواندن شناسه‌های محصولات برای تکمیل صف بازنویسی با خطای دیتابیس مواجه شد. پرچم‌های بازنویسی حفظ شده‌اند، اما صف تغییر نکرده است.'];
            }

            if (!evazar_queue_capacity_lock_acquire(3)) {
                return ['success' => false, 'message' => 'قفل مدیریت ظرفیت مشغول است. پرچم‌های بازنویسی ثبت شده‌اند، اما صف تغییر نکرده است؛ چند ثانیه بعد دوباره اجرا کنید.'];
            }
            $transaction_started = false;
            try {
                if ($wpdb->query('START TRANSACTION') === false) {
                    return ['success' => false, 'message' => 'شروع تراکنش دیتابیس ممکن نشد. پرچم‌های بازنویسی ثبت شده‌اند، اما صف تغییر نکرده است.'];
                }
                $transaction_started = true;
                $staged_existing = $wpdb->query(
                    "INSERT INTO `$intake_table` (dkp, url, mode)
                     SELECT dkp, url, 'rewrite' FROM `$table_name` WHERE status IN ('completed','failed') AND dkp<>'' ORDER BY id ASC
                     ON DUPLICATE KEY UPDATE
                       url = VALUES(url),
                       mode = 'rewrite'"
                );
                if ($staged_existing === false) {
                    return ['success' => false, 'message' => 'ثبت موارد تکمیل‌شده/خطادار در صف بازنویسی ناموفق بود؛ تغییرات صف بازگردانده شد. پرچم بازنویسی همچنان ثبت شده است.'];
                }

                $queue_dkps = $wpdb->get_col("SELECT dkp FROM `$table_name`");
                if (!empty($wpdb->last_error)) {
                    return ['success' => false, 'message' => 'خواندن صف فعلی برای بازنویسی ناموفق شد؛ تغییرات صف بازگردانده شد.'];
                }
                $intake_dkps = $wpdb->get_col("SELECT dkp FROM `$intake_table`");
                if (!empty($wpdb->last_error)) {
                    return ['success' => false, 'message' => 'خواندن صف نگهداری ظرفیت ناموفق شد؛ تغییرات صف بازگردانده شد.'];
                }
                $existing_map = [];
                foreach (array_merge((array) $queue_dkps, (array) $intake_dkps) as $existing_dkp) {
                    $normalized_dkp = preg_replace('/[^0-9]/', '', (string) $existing_dkp);
                    if ($normalized_dkp !== '') $existing_map[$normalized_dkp] = true;
                }

                $missing_items = [];
                $rewrite_identifiable_count = 0;
                $rewrite_missing_identity_count = 0;
                foreach ((array) $all_products as $product) {
                    $dkp = preg_replace('/[^0-9]/', '', (string) ($product->dkp ?? ''));
                    if ($dkp === '') {
                        $rewrite_missing_identity_count++;
                        continue;
                    }
                    $rewrite_identifiable_count++;
                    if (isset($existing_map[$dkp])) continue;
                    $existing_map[$dkp] = true;
                    $missing_items[] = [
                        'dkp' => $dkp,
                        'url' => 'https://www.digikala.com/product/dkp-' . $dkp . '/',
                        'mode' => 'rewrite',
                    ];
                }
                $staged_missing = evazar_queue_bulk_store_capacity_waiting_locked($missing_items, 100);
                if (empty($staged_missing['success'])) {
                    return ['success' => false, 'message' => 'ثبت بخشی از محصولات جدید در صف بازنویسی ناموفق بود؛ تغییرات صف بازگردانده شد. پرچم‌های بازنویسی حفظ شده‌اند.'];
                }

                // Old capacity-waiting items remain FIFO; rewrite requests get promoted only
                // into free slots and bypass the normal "already imported" filter.
                $promotion = evazar_queue_promote_capacity_waiting_locked();
                if (!empty($wpdb->last_error)) {
                    return ['success' => false, 'message' => 'تخصیص ظرفیت صف بازنویسی با خطای دیتابیس مواجه شد؛ تغییرات صف بازگردانده شد.'];
                }
                if ($wpdb->query('COMMIT') === false) {
                    return ['success' => false, 'message' => 'ثبت نهایی صف بازنویسی ناموفق بود؛ تغییرات صف بازگردانده شد.'];
                }
                $transaction_started = false;
            } finally {
                if ($transaction_started) $wpdb->query('ROLLBACK');
                evazar_queue_capacity_lock_release();
            }

            delete_transient('evazar_queue_dashboard_stats_v2');
            if (function_exists('evazar_queue_maybe_schedule_followup')) evazar_queue_maybe_schedule_followup();
            $waiting_now = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$intake_table`");
            $active_now = evazar_queue_active_item_count();
            $capacity_now = evazar_queue_current_processing_capacity();
            return [
                'success' => true,
                'message' => 'درخواست بازنویسی برای ' . $rewrite_identifiable_count . ' محصول دارای شناسه ثبت شد؛ ' . (int) ($promotion['promoted'] ?? 0) . ' مورد اکنون در صف فعال قرار گرفت و ' . $waiting_now . ' مورد در صف منتظر ظرفیت باقی مانده است. ظرفیت فعال فعلی=' . $capacity_now . '، تعداد آیتم فعال=' . $active_now . '.' . ($rewrite_missing_identity_count > 0 ? ' تعداد ' . $rewrite_missing_identity_count . ' محصول به‌دلیل نداشتن شناسهٔ معتبر وارد صف نشد.' : '') . ' محتوای فعلی محصولات تا موفقیت بازنویسی حفظ می‌شود.'
            ];

        default:
            return [
                'success' => false,
                'message' => 'عملیات درخواستی نامعتبر است.'
            ];
    }
}

// اندپوینت پردازش ایجکس (AJAX Handler) برای عملیات صف بدون فریز شدن مرورگر
add_action('wp_ajax_evazar_queue_ajax_action', 'evazar_queue_ajax_action_callback');
function evazar_queue_ajax_action_callback() {
    check_ajax_referer('evazar_queue_action_nonce', 'security');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'دسترسی غیرمجاز است.']);
    }

    if (function_exists('set_time_limit')) {
        @set_time_limit(300);
    }
    @ini_set('memory_limit', '512M');

    $action_type = isset($_POST['action_type']) ? sanitize_key($_POST['action_type']) : '';
    $action_context = ['item_id' => absint($_POST['item_id'] ?? 0)];
    $res = evazar_queue_run_admin_action($action_type, $action_context);
    delete_transient('evazar_queue_dashboard_stats_v2');

    global $wpdb;
    $table_name = $wpdb->prefix . 'evazar_import_queue';
    $intake_table = evazar_queue_capacity_intake_table_name();
    $history_table = evazar_queue_import_history_table_name();
    $cutoff_1h = gmdate('Y-m-d H:i:s', time() - HOUR_IN_SECONDS);
    $stats = [
        'total'      => intval($wpdb->get_var("SELECT COUNT(*) FROM (SELECT dkp FROM `$table_name` UNION SELECT dkp FROM `$intake_table`) AS evazar_queue_unique_dkps")),
        'pending'    => intval($wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 'pending'")),
        'processing' => intval($wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 'processing'")),
        'completed'  => intval($wpdb->get_var("SELECT COUNT(*) FROM `$table_name` q WHERE q.status='completed' AND NOT EXISTS (SELECT 1 FROM `$intake_table` i WHERE i.dkp=q.dkp)")),
        'failed'     => intval($wpdb->get_var("SELECT COUNT(*) FROM `$table_name` q WHERE q.status='failed' AND NOT EXISTS (SELECT 1 FROM `$intake_table` i WHERE i.dkp=q.dkp)")),
        'quarantined' => intval($wpdb->get_var("SELECT COUNT(*) FROM `$table_name` q WHERE q.status='quarantined' AND NOT EXISTS (SELECT 1 FROM `$intake_table` i WHERE i.dkp=q.dkp AND i.mode IN ('qretry','qrewrite'))")),
        'excluded' => intval($wpdb->get_var("SELECT COUNT(*) FROM `$table_name` WHERE status='excluded'")),
        'capacity_waiting' => intval($wpdb->get_var("SELECT COUNT(*) FROM `$intake_table`")),
        'imported_1h' => intval($wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM `$history_table` WHERE imported_at >= %s",
            $cutoff_1h
        ))),
        'imported_24h' => intval($wpdb->get_var($wpdb->prepare(
            'SELECT COUNT(*) FROM `' . $history_table . '` WHERE imported_at >= %s',
            evazar_queue_import_history_cutoff()
        ))),
    ];

    if ($res['success']) {
        wp_send_json_success([
            'message' => $res['message'],
            'stats'   => $stats
        ]);
    } else {
        wp_send_json_error([
            'message' => $res['message'],
            'stats'   => $stats
        ]);
    }
}

// ==========================================
// 6. صفحه ادمین برای مشاهده وضعیت صف
// ==========================================
add_action('admin_menu', 'evazar_queue_admin_page');
function evazar_queue_admin_page() {
    add_submenu_page(
        'edit.php?post_type=evazar_product',
        'وضعیت صف واردات',
        'صف واردات',
        'manage_options',
        'evazar-queue',
        'evazar_queue_admin_page_html'
    );
}

function evazar_queue_admin_page_html() {
    global $wpdb;
    // Make schema setup explicit on the page render as well as admin_init/activation.
    // This is important for upgrades that replace files without reactivating the plugin.
    evazar_queue_ensure_import_history_table();
    evazar_queue_ensure_table();
    // Recover recent one-product manual imports performed before this fix, if their
    // success records are still present in the rolling 50-entry importer log.
    evazar_queue_backfill_recent_imports_from_logs();
    $table_name = $wpdb->prefix . 'evazar_import_queue';

    // پردازش درخواست‌های سنتی فرم (POST Fallback)
    $post_action = '';
    if (isset($_POST['evazar_pause_queue'])) $post_action = 'pause_queue';
    elseif (isset($_POST['evazar_resume_queue'])) $post_action = 'resume_queue';
    elseif (isset($_POST['evazar_manual_process'])) $post_action = 'manual_process';
    elseif (isset($_POST['evazar_sync_existing_items'])) $post_action = 'sync_existing_items';
    elseif (isset($_POST['evazar_generate_terms_seo_content'])) $post_action = 'generate_terms_seo_content';
    elseif (isset($_POST['evazar_cleanup_downloaded_images'])) $post_action = 'cleanup_downloaded_images';
    elseif (isset($_POST['evazar_retry_failed_items'])) $post_action = 'retry_failed_items';
    elseif (isset($_POST['evazar_clear_queue'])) $post_action = 'clear_queue';
    elseif (isset($_POST['evazar_rewrite_old_short_descriptions'])) $post_action = 'rewrite_old_short_descriptions';

    if (!empty($post_action) && check_admin_referer('evazar_queue_action_nonce')) {
        $result = evazar_queue_run_admin_action($post_action);
        delete_transient('evazar_queue_dashboard_stats_v2');
        $notice_cls = $result['success'] ? 'notice-success' : 'notice-error';
        echo '<div class="notice ' . $notice_cls . ' is-dismissible"><p><strong>' . esc_html($result['message']) . '</strong></p></div>';
    }

    // ذخیره تنظیمات صف
    if (isset($_POST['evazar_save_queue_settings']) && check_admin_referer('evazar_queue_settings_nonce')) {
        $min_interval = max(1, min(60, intval($_POST['evazar_queue_interval_min_minutes'] ?? 5)));
        $max_interval = max(1, min(60, intval($_POST['evazar_queue_interval_max_minutes'] ?? 10)));
        if ($max_interval < $min_interval) $max_interval = $min_interval;
        $old_min_interval = evazar_queue_interval_min_minutes();
        $old_max_interval = evazar_queue_interval_max_minutes();

        update_option('evazar_queue_interval_min_minutes', $min_interval);
        update_option('evazar_queue_interval_max_minutes', $max_interval);
        update_option('evazar_queue_interval_minutes', $min_interval); // legacy compatibility
        // Explicit user-facing maximum for products claimed per queue run.
        // Worker availability and Gemini chunk size can lower this cap, never raise it.
        if (isset($_POST['evazar_queue_max_products_per_run'])) {
            $max_products = max(5, min(250, intval($_POST['evazar_queue_max_products_per_run'])));
            update_option('evazar_queue_max_products_per_run', $max_products);
            update_option('evazar_queue_batch_size', $max_products); // legacy compatibility
        }

        // The per-request Gemini batch size is now saved with the other import-queue controls.
        // Keep the existing option name so queue processing and existing installations are unchanged.
        if (isset($_POST['evazar_ai_product_batch_size'])) {
            $posted_batch_size = function_exists('wp_unslash') ? wp_unslash($_POST['evazar_ai_product_batch_size']) : $_POST['evazar_ai_product_batch_size'];
            $gemini_batch_size = function_exists('evazar_sanitize_ai_product_batch_size')
                ? evazar_sanitize_ai_product_batch_size($posted_batch_size)
                : max(2, min(50, absint($posted_batch_size)));
            update_option('evazar_ai_product_batch_size', $gemini_batch_size, false);
        }

        $posted_quarantine_retry_days = absint($_POST['evazar_queue_category_quarantine_auto_retry_days'] ?? 0);
        if (!in_array($posted_quarantine_retry_days, [0, 1, 3, 7, 14], true)) $posted_quarantine_retry_days = 0;
        $old_quarantine_retry_days = evazar_queue_category_quarantine_auto_retry_days();
        update_option('evazar_queue_category_quarantine_auto_retry_days', $posted_quarantine_retry_days, false);
        if ($old_quarantine_retry_days !== $posted_quarantine_retry_days) {
            if ($posted_quarantine_retry_days > 0) {
                $wpdb->query("UPDATE `$table_name` SET next_attempt_at=DATE_ADD(COALESCE(last_error_at, updated_at, NOW()), INTERVAL " . (int) $posted_quarantine_retry_days . " DAY) WHERE status='quarantined' AND error_code='SOURCE_CATEGORY_PATH_MISSING'");
            } else {
                $wpdb->query("UPDATE `$table_name` SET next_attempt_at=NULL WHERE status='quarantined' AND error_code='SOURCE_CATEGORY_PATH_MISSING'");
            }
            if (function_exists('evazar_queue_maybe_schedule_followup')) evazar_queue_maybe_schedule_followup();
        }

        if ($old_min_interval !== $min_interval || $old_max_interval !== $max_interval) {
            evazar_queue_reschedule_cron();
        }

        echo '<div class="notice notice-success is-dismissible"><p><strong>تنظیمات صف ذخیره شد؛ اندازه دسته Gemini، سقف ایمنی و بازه اجرای بعدی ذخیره شدند.</strong></p></div>';
    }

    $current_min_interval = evazar_queue_interval_min_minutes();
    $current_max_interval = evazar_queue_interval_max_minutes();
    $current_max_products = max(5, min(250, (int) get_option('evazar_queue_max_products_per_run', 250)));
    $current_gemini_batch_size = (int) get_option('evazar_ai_product_batch_size', 50);
    if ($current_gemini_batch_size < 2 || $current_gemini_batch_size > 50) $current_gemini_batch_size = 50;
    $current_quarantine_retry_days = evazar_queue_category_quarantine_auto_retry_days();

    $intake_table = evazar_queue_capacity_intake_table_name();
    $total_all = $wpdb->get_var("SELECT COUNT(*) FROM (SELECT dkp FROM `$table_name` UNION SELECT dkp FROM `$intake_table`) AS evazar_queue_unique_dkps");
    $capacity_waiting = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$intake_table`");
    $pending = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 'pending'");
    $processing = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE status = 'processing'");
    $completed = $wpdb->get_var("SELECT COUNT(*) FROM `$table_name` q WHERE q.status='completed' AND NOT EXISTS (SELECT 1 FROM `$intake_table` i WHERE i.dkp=q.dkp)");
    $failed = $wpdb->get_var("SELECT COUNT(*) FROM `$table_name` q WHERE q.status='failed' AND NOT EXISTS (SELECT 1 FROM `$intake_table` i WHERE i.dkp=q.dkp)");
    $quarantined = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table_name` q WHERE q.status='quarantined' AND NOT EXISTS (SELECT 1 FROM `$intake_table` i WHERE i.dkp=q.dkp AND i.mode IN ('qretry','qrewrite'))");
    $quarantined_requeueable = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table_name` q WHERE q.status='quarantined' AND q.dkp REGEXP '^[1-9][0-9]*$' AND NOT EXISTS (SELECT 1 FROM `$intake_table` i WHERE i.dkp=q.dkp AND i.mode IN ('qretry','qrewrite'))");
    $excluded = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$table_name` WHERE status='excluded'");

    $history_table = evazar_queue_import_history_table_name();
    $import_history_cutoff = evazar_queue_import_history_cutoff();
    $imported_1h_cutoff = gmdate('Y-m-d H:i:s', time() - HOUR_IN_SECONDS);
    $imported_1h_count = intval($wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM `$history_table` WHERE imported_at >= %s",
        $imported_1h_cutoff
    )));
    $imported_24h_count = intval($wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM `$history_table` WHERE imported_at >= %s",
        $import_history_cutoff
    )));

    // فیلتر وضعیت انتخابی کاربر؛ تاریخچه واردات یک نمای جدا از وضعیت فعلی صف است.
    $current_filter = isset($_GET['q_status']) ? sanitize_text_field($_GET['q_status']) : '';
    $is_imported_1h_filter = ($current_filter === 'imported_1h');
    $is_imported_24h_filter = ($current_filter === 'imported_24h');
    $is_capacity_waiting_filter = ($current_filter === 'capacity_waiting');
    $allowed_statuses = ['pending', 'processing', 'completed', 'failed', 'quarantined', 'excluded'];
    if ($is_imported_1h_filter || $is_imported_24h_filter || $is_capacity_waiting_filter) {
        $where_clause = '';
    } elseif (in_array($current_filter, $allowed_statuses, true)) {
        if (in_array($current_filter, ['completed', 'failed'], true)) {
            $where_clause = $wpdb->prepare("WHERE status = %s AND NOT EXISTS (SELECT 1 FROM `$intake_table` i WHERE i.dkp = `$table_name`.dkp)", $current_filter);
        } elseif ($current_filter === 'quarantined') {
            $where_clause = $wpdb->prepare("WHERE status = %s AND NOT EXISTS (SELECT 1 FROM `$intake_table` i WHERE i.dkp = `$table_name`.dkp AND i.mode IN ('qretry','qrewrite'))", $current_filter);
        } else {
            $where_clause = $wpdb->prepare("WHERE status = %s", $current_filter);
        }
    } else {
        $current_filter = '';
        $where_clause = "WHERE NOT EXISTS (SELECT 1 FROM `$intake_table` i WHERE i.dkp = `$table_name`.dkp)";
    }

    if ($is_imported_1h_filter || $is_imported_24h_filter) {
        $recent_items_cutoff = $is_imported_1h_filter ? $imported_1h_cutoff : $import_history_cutoff;
        $recent_items = $wpdb->get_results($wpdb->prepare(
            "SELECT h.id, h.dkp, h.source_url AS url, 'imported' AS status,
                    h.imported_at AS created_at, '' AS error_code, '' AS error_log,
                    NULL AS last_error_at, h.product_id, p.post_title
             FROM `$history_table` h
             LEFT JOIN {$wpdb->posts} p ON p.ID = h.product_id
             WHERE h.imported_at >= %s
             ORDER BY h.imported_at DESC
             LIMIT 50",
            $recent_items_cutoff
        ));
    } elseif ($is_capacity_waiting_filter) {
        $recent_items = $wpdb->get_results(
            "SELECT id, dkp, url, 'capacity_waiting' AS status, created_at,
                    CASE mode WHEN 'rewrite' THEN 'QUEUE_CAPACITY_REWRITE' WHEN 'retry' THEN 'QUEUE_CAPACITY_RETRY' ELSE 'QUEUE_CAPACITY_WAITING' END AS error_code,
                    CASE mode WHEN 'rewrite' THEN 'بازنویسی کامل ثبت شده؛ محصول با آزادشدن ظرفیت وارد صف فعال می‌شود.' WHEN 'retry' THEN 'تلاش مجدد ثبت شده؛ محصول با آزادشدن ظرفیت وارد صف فعال می‌شود.' ELSE 'این محصول پذیرفته شده و تا آزادشدن ظرفیت در صف نگهداری می‌شود.' END AS error_log,
                    NULL AS last_error_at
             FROM `$intake_table` ORDER BY id DESC LIMIT 50"
        );
    } else {
        $recent_items = $wpdb->get_results("SELECT * FROM $table_name $where_clause ORDER BY id DESC LIMIT 50");
    }

    echo '<div class="wrap" style="direction: rtl;">';
    echo '<h1 style="font-weight: 700; margin-bottom: 20px;">داشبورد و وضعیت صف واردات ایوازار</h1>';
    // کارت‌های وضعیت
    echo '<div style="display: flex; gap: 16px; margin-bottom: 25px; flex-wrap: wrap;">';
    echo '<div style="background: #fff; padding: 18px 24px; border-radius: 10px; border-right: 5px solid #f59e0b; box-shadow: 0 2px 6px rgba(0,0,0,0.06); min-width: 170px;"><strong>در انتظار:</strong> <div style="font-size: 26px; font-weight: bold; color: #b45309; margin-top: 5px;">' . intval($pending) . '</div></div>';
    echo '<a href="' . esc_url(add_query_arg('q_status', 'capacity_waiting', admin_url('edit.php?post_type=evazar_product&page=evazar-queue'))) . '" style="display:block;color:inherit;text-decoration:none;background:#fff;padding:18px 24px;border-radius:10px;border-right:5px solid #d97706;box-shadow:0 2px 6px rgba(0,0,0,0.06);min-width:170px;"><strong>منتظر ظرفیت:</strong><div style="font-size:26px;font-weight:bold;color:#b45309;margin-top:5px;">' . intval($capacity_waiting) . '</div></a>';
    echo '<div style="background: #fff; padding: 18px 24px; border-radius: 10px; border-right: 5px solid #3b82f6; box-shadow: 0 2px 6px rgba(0,0,0,0.06); min-width: 170px;"><strong>در حال پردازش:</strong> <div style="font-size: 26px; font-weight: bold; color: #1d4ed8; margin-top: 5px;">' . intval($processing) . '</div></div>';
    echo '<div style="background: #fff; padding: 18px 24px; border-radius: 10px; border-right: 5px solid #10b981; box-shadow: 0 2px 6px rgba(0,0,0,0.06); min-width: 170px;"><strong>تکمیل شده:</strong> <div style="font-size: 26px; font-weight: bold; color: #047857; margin-top: 5px;">' . intval($completed) . '</div></div>';
    echo '<div style="background: #fff; padding: 18px 24px; border-radius: 10px; border-right: 5px solid #ef4444; box-shadow: 0 2px 6px rgba(0,0,0,0.06); min-width: 170px;"><strong>خطا خورده:</strong> <div style="font-size: 26px; font-weight: bold; color: #b91c1c; margin-top: 5px;">' . intval($failed) . '</div></div>';
    // پنجمین بلوک؛ هم‌ظاهر با چهار بلوک وضعیت و در انتهای ردیف.
    $imported_24h_url = add_query_arg('q_status', 'imported_24h', admin_url('edit.php?post_type=evazar_product&page=evazar-queue'));
    echo '<a href="' . esc_url($imported_24h_url) . '" style="display:block; color:inherit; text-decoration:none; background:#fff; padding:18px 24px; border-radius:10px; border-right:5px solid #8b5cf6; box-shadow:0 2px 6px rgba(0,0,0,0.06); min-width:170px;">';
    echo '<strong>محصولات وارد شده ۲۴ ساعت گذشته:</strong><div style="font-size:26px; font-weight:bold; color:#6d28d9; margin-top:5px;">' . intval($imported_24h_count) . '</div>';
    echo '</a>';
    $imported_1h_url = add_query_arg('q_status', 'imported_1h', admin_url('edit.php?post_type=evazar_product&page=evazar-queue'));
    echo '<a href="' . esc_url($imported_1h_url) . '" style="display:block; color:inherit; text-decoration:none; background:#fff; padding:18px 24px; border-radius:10px; border-right:5px solid #0d9488; box-shadow:0 2px 6px rgba(0,0,0,0.06); min-width:170px;">';
    echo '<strong>محصولات وارد شده در یک ساعت گذشته:</strong><div style="font-size:26px; font-weight:bold; color:#0f766e; margin-top:5px;">' . intval($imported_1h_count) . '</div>';
    echo '</a>';
    echo '</div>';

    // پنل تنظیمات زمان‌بندی و بچ
    echo '<div style="background: #fff; padding: 18px 24px; border-radius: 10px; box-shadow: 0 1px 4px rgba(0,0,0,0.06); margin-bottom: 25px;">';
    echo '<h3 style="margin-top: 0; margin-bottom: 16px; font-size: 15px; font-weight: 700; color: #1e293b;">⚙️ تنظیمات زمان‌بندی و سرعت پردازش صف</h3>';
    echo '<form method="post" style="display: flex; gap: 20px; align-items: flex-start; flex-wrap: wrap;">';
    wp_nonce_field('evazar_queue_settings_nonce');
    echo '<div style="display: flex; flex-direction: column;">';
    echo '<label for="evazar_queue_interval_min_minutes" style="font-weight: 600; margin-bottom: 6px; font-size: 13px; color: #334155;">حداقل فاصله بین اجراهای خودکار (دقیقه):</label>';
    echo '<input type="number" id="evazar_queue_interval_min_minutes" name="evazar_queue_interval_min_minutes" value="' . esc_attr($current_min_interval) . '" min="1" max="60" step="1" style="width: 140px; height: 38px; padding: 0 10px; border-radius: 6px; border: 1px solid #cbd5e1; box-sizing: border-box;">';
    echo '<p style="margin: 5px 0 0; font-size: 11px; color: #64748b;">پیش‌فرض: ۵ دقیقه؛ حد مجاز ۱ تا ۶۰ دقیقه</p>';
    echo '</div>';
    echo '<div style="display: flex; flex-direction: column;">';
    echo '<label for="evazar_queue_interval_max_minutes" style="font-weight: 600; margin-bottom: 6px; font-size: 13px; color: #334155;">حداکثر فاصله بین اجراهای خودکار (دقیقه):</label>';
    echo '<input type="number" id="evazar_queue_interval_max_minutes" name="evazar_queue_interval_max_minutes" value="' . esc_attr($current_max_interval) . '" min="' . esc_attr($current_min_interval) . '" max="60" step="1" style="width: 140px; height: 38px; padding: 0 10px; border-radius: 6px; border: 1px solid #cbd5e1; box-sizing: border-box;">';
    echo '<p style="margin: 5px 0 0; font-size: 11px; color: #64748b;">پیش‌فرض: ۱۰ دقیقه؛ در هر بار پایان اجرا، فاصله بعدی به‌صورت تصادفی انتخاب می‌شود.</p>';
    echo '</div>';
    echo '<div style="display: flex; flex-direction: column;">';
    echo '<label for="evazar_ai_product_batch_size" style="font-weight: 600; margin-bottom: 6px; font-size: 13px; color: #334155;">تعداد محصولات هر درخواست Gemini:</label>';
    echo '<select id="evazar_ai_product_batch_size" name="evazar_ai_product_batch_size" style="min-width: 160px; height: 38px; padding: 0 10px; border-radius: 6px; border: 1px solid #cbd5e1; box-sizing: border-box;">';
    $gemini_batch_sizes = [2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30, 40, 50];
    if (!in_array($current_gemini_batch_size, $gemini_batch_sizes, true)) {
        $gemini_batch_sizes[] = $current_gemini_batch_size;
        sort($gemini_batch_sizes, SORT_NUMERIC);
    }
    foreach ($gemini_batch_sizes as $gemini_size) {
        echo '<option value="' . (int) $gemini_size . '" ' . selected($current_gemini_batch_size, $gemini_size, false) . '>' . (int) $gemini_size . ' محصول</option>';
    }
    echo '</select>';
    echo '<p style="margin: 5px 0 0; font-size: 11px; color: #64748b; max-width: 250px;">تعداد محصولات در هر درخواست مجزای Gemini؛ ظرفیت کل هر نوبت با تعداد Workerهای آزاد و سقف ایمنی صف محاسبه می‌شود (مجاز: ۲ تا ۵۰).</p>';
    echo '</div>';
    echo '<div style="display: flex; flex-direction: column;">';
    echo '<label for="evazar_queue_max_products_per_run" style="font-weight: 600; margin-bottom: 6px; font-size: 13px; color: #334155;">سقف ایمنی دستی هر نوبت (ظرفیت واقعی خودکار محاسبه می‌شود):</label>'; 
    echo '<input type="number" id="evazar_queue_max_products_per_run" name="evazar_queue_max_products_per_run" value="' . esc_attr($current_max_products) . '" min="5" max="250" step="1" style="width: 160px; height: 38px; padding: 0 10px; border-radius: 6px; border: 1px solid #cbd5e1; box-sizing: border-box;">';
    echo '<p style="margin: 5px 0 0; font-size: 11px; color: #64748b;">حداکثر فنی ۲۵۰ محصول (۵ Worker × ۵۰ محصول). در حالت Gemini-only، سقف واقعی هر نوبت برابر کمترینِ این مقدار، سقف دستی بالا و تعداد Workerهای آزاد و دارای سهمیه × اندازهٔ هر درخواست است؛ مثلاً ۲×۲۰=۴۰ و ۴×۵۰=۲۰۰. اگر حمل موازی در دسترس نباشد، برای جلوگیری از انباشته‌شدن کار و timeout، ظرفیت به یک دسته محدود می‌شود. حالت‌های غیر Gemini همچنان سقف اجرایی ۷۵ دارند.</p>'; 
    echo '</div>';
    echo '<div style="display: flex; flex-direction: column;">';
    echo '<label for="evazar_queue_category_quarantine_auto_retry_days" style="font-weight: 600; margin-bottom: 6px; font-size: 13px; color: #334155;">تلاش خودکار مجدد برای قرنطینهٔ مسیر دسته‌بندی:</label>';
    echo '<select id="evazar_queue_category_quarantine_auto_retry_days" name="evazar_queue_category_quarantine_auto_retry_days" style="min-width: 190px; height: 38px; padding: 0 10px; border-radius: 6px; border: 1px solid #cbd5e1; box-sizing: border-box;">';
    foreach ([0 => 'خاموش؛ فقط بررسی دستی', 1 => 'پس از ۱ روز', 3 => 'پس از ۳ روز', 7 => 'پس از ۷ روز', 14 => 'پس از ۱۴ روز'] as $retry_days => $retry_label) {
        echo '<option value="' . (int) $retry_days . '" ' . selected($current_quarantine_retry_days, $retry_days, false) . '>' . esc_html($retry_label) . '</option>';
    }
    echo '</select>';
    echo '<p style="margin: 5px 0 0; font-size: 11px; color: #64748b; max-width: 250px;">فقط برای کالاهایی که مسیر دسته‌بندی مبدأ آن‌ها دریافت نشده؛ پیش‌فرض خاموش است. این خطا به‌تنهایی غیرفعال بودن قطعی کالا را ثابت نمی‌کند.</p>';
    echo '</div>';
    echo '<div style="display: flex; flex-direction: column;">';
    echo '<span style="font-size: 13px; line-height: 1.4; margin-bottom: 6px; visibility: hidden; user-select: none;">&nbsp;</span>';
    echo '<button type="submit" name="evazar_save_queue_settings" class="button button-primary" style="height: 38px; line-height: 36px; padding: 0 24px; font-size: 13px; font-weight: 600; border-radius: 6px; display: inline-flex; align-items: center; justify-content: center; gap: 6px; box-shadow: 0 1px 3px rgba(37,99,235,0.25);">💾 ذخیره تنظیمات</button>';
    echo '</div>';
    echo '</form>';

    // Show the independent source-fetch and Gemini pools, plus the live capacity formula.
    $source_urls_for_ui = function_exists('evazar_get_primary_worker_urls') ? array_values(array_unique(array_filter(array_map(static function ($url) { return rtrim(trim((string) $url), '/'); }, (array) evazar_get_primary_worker_urls())))) : [];
    $source_state_for_ui = function_exists('evazar_queue_product_source_worker_pool_state') ? evazar_queue_product_source_worker_pool_state('import_source') : ['eligible_count' => 0];
    $source_configured_for_ui = count($source_urls_for_ui);
    $source_eligible_for_ui = max(0, (int) ($source_state_for_ui['eligible_count'] ?? 0));
    $source_concurrency_for_ui = function_exists('evazar_queue_parallel_transport_available') && evazar_queue_parallel_transport_available()
        ? min(5, $source_configured_for_ui, $source_eligible_for_ui)
        : min(1, $source_eligible_for_ui);
    $gemini_urls_for_ui = function_exists('evazar_get_gemini_worker_urls') ? array_values(array_unique(array_filter(array_map(static function ($url) { return rtrim(trim((string) $url), '/'); }, (array) evazar_get_gemini_worker_urls())))) : [];
    $gemini_configured_for_ui = count($gemini_urls_for_ui);
    $gemini_eligible_for_ui = function_exists('evazar_queue_parallel_healthy_worker_count') ? max(0, (int) evazar_queue_parallel_healthy_worker_count()) : 0;
    $gemini_parallel_for_ui = function_exists('evazar_queue_product_batch_parallel_enabled') && evazar_queue_product_batch_parallel_enabled()
        && function_exists('evazar_queue_parallel_transport_available') && evazar_queue_parallel_transport_available();
    $gemini_effective_batch_for_ui = function_exists('evazar_queue_product_batch_size') ? evazar_queue_product_batch_size() : $current_gemini_batch_size;
    $gemini_adaptive_parallelism_for_ui = function_exists('evazar_queue_product_batch_parallelism') ? evazar_queue_product_batch_parallelism() : 5;
    $gemini_slots_for_ui = $gemini_eligible_for_ui > 0
        ? ($gemini_parallel_for_ui ? min($gemini_adaptive_parallelism_for_ui, $gemini_configured_for_ui, $gemini_eligible_for_ui) : 1) : 0;
    $gemini_target_for_ui = min($current_max_products, $gemini_slots_for_ui * $gemini_effective_batch_for_ui);
    if (!$gemini_parallel_for_ui && $gemini_slots_for_ui > 0) $gemini_target_for_ui = min($gemini_target_for_ui, $gemini_effective_batch_for_ui);
    $gemini_chunks_for_ui = [];
    $gemini_chunk_remaining_for_ui = $gemini_target_for_ui;
    while ($gemini_chunk_remaining_for_ui > 0 && count($gemini_chunks_for_ui) < 125) {
        $gemini_next_chunk_for_ui = min($gemini_effective_batch_for_ui, $gemini_chunk_remaining_for_ui);
        $gemini_chunks_for_ui[] = $gemini_next_chunk_for_ui;
        $gemini_chunk_remaining_for_ui -= $gemini_next_chunk_for_ui;
    }
    $gemini_chunk_plan_for_ui = !empty($gemini_chunks_for_ui) ? implode(' + ', $gemini_chunks_for_ui) : '۰';
    echo '<div style="margin-top:16px;padding:12px 14px;border:1px solid #dbeafe;background:#f8fbff;border-radius:8px;color:#1e293b;font-size:12px;line-height:1.9;">';
    echo '<strong>هماهنگی دو مرحله (مستقل از هم):</strong><br>';
    $source_adaptive_state_for_ui = function_exists('evazar_queue_product_source_adaptive_state') ? evazar_queue_product_source_adaptive_state() : [];
    echo 'دریافت دیجی‌کالا: Worker اصلی تنظیم‌شده=' . (int) $source_configured_for_ui . '؛ واجدشرایط در همین لحظه=' . (int) $source_eligible_for_ui . '؛ هم‌زمانی تطبیقی فعلی=' . (int) $source_concurrency_for_ui . ' محصول؛ پیشرفت ارتقا=' . absint($source_adaptive_state_for_ui['success_streak'] ?? 0) . '/3 موج موفق متوالی (شروع امن ۲، سقف ۵؛ هر Worker حداکثر یک محصول در هر موج).<br>';
    echo 'Gemini: Worker تنظیم‌شده=' . (int) $gemini_configured_for_ui . '؛ واجدشرایط در همین لحظه=' . (int) $gemini_eligible_for_ui . '؛ هم‌زمانی تطبیقی=' . (int) $gemini_slots_for_ui . '؛ اندازه مؤثر هر درخواست=' . (int) $gemini_effective_batch_for_ui . ' (سقف تنظیم‌شده=' . (int) $current_gemini_batch_size . ')؛ ظرفیت برآوردی همین لحظه=min(سقف کل ' . (int) $current_max_products . '، ' . (int) $gemini_slots_for_ui . ' Worker × ' . (int) $gemini_effective_batch_for_ui . ')=' . (int) $gemini_target_for_ui . ' محصول؛ تقسیم درخواست‌ها=' . esc_html($gemini_chunk_plan_for_ui) . '.<br>';
    echo '<span style="color:#475569;">سقف کل هر اجرا یک محدودیت مستقل و سخت است: مثلاً با ۴ Worker Gemini و دستهٔ ۵۰تایی، ظرفیت نظری ۲۰۰ است؛ اما اگر سقف کل روی ۱۲۰ باشد، سیستم عمداً فقط ۱۲۰ محصول را می‌گیرد و دسته‌ها ۵۰ + ۵۰ + ۲۰ خواهند بود. برای ۲۰۰ محصول، سقف کل باید دست‌کم ۲۰۰ باشد. تعداد Workerهای اصلی فقط سرعت دریافت از دیجی‌کالا را تعیین می‌کند و به ظرفیت Gemini اضافه نمی‌شود.</span>';
    echo '</div>';
    echo '</div>';

    // نوار کنترل و دکمه‌های عملیاتی
    $queue_is_paused = evazar_queue_is_manually_paused();
    echo '<div style="background: #fff; padding: 15px 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); margin-bottom: 25px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 15px;">';
    echo '<div style="padding:8px 12px; border-radius:7px; background:' . ($queue_is_paused ? '#fff7ed' : '#f0fdf4') . '; color:' . ($queue_is_paused ? '#9a3412' : '#166534') . '; font-size:13px; font-weight:600;">وضعیت صف: ' . ($queue_is_paused ? '⏸ متوقف به درخواست مدیر' : '● فعال') . '</div>';
    echo '<form method="post" id="evazar-queue-actions-form" style="display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">';
    wp_nonce_field('evazar_queue_action_nonce');
    if ($queue_is_paused) {
        echo '<button type="submit" name="evazar_resume_queue" class="button evazar-ajax-action-btn" data-action="resume_queue" data-title="▶️ ادامه صف واردات" data-desc="صف دوباره فعال می‌شود؛ محصولات باقی‌مانده از همان صف ادامه خواهند یافت." style="padding: 5px 18px; height: auto; font-size: 14px; color:#166534; border-color:#86efac; background:#f0fdf4; font-weight:700;">▶️ ادامه صف واردات</button>';
    } else {
        echo '<button type="submit" name="evazar_pause_queue" class="button evazar-ajax-action-btn" data-action="pause_queue" data-title="⏸ توقف صف واردات" data-desc="شروع پردازش محصولات جدید متوقف می‌شود. موجی که از قبل به Worker ارسال شده ممکن است تا پایان کامل شود؛ محصولات ارسال‌نشده به صف برمی‌گردند." data-confirm="واردات خودکار متوقف شود؟ محصولات در انتظار حذف نمی‌شوند و بعداً قابل ادامه هستند." style="padding: 5px 18px; height: auto; font-size: 14px; color:#9a3412; border-color:#fdba74; background:#fff7ed; font-weight:700;">⏸ توقف صف واردات</button>';
    }
    echo '<button type="submit" name="evazar_manual_process" class="button button-primary evazar-ajax-action-btn" data-action="manual_process" data-title="⚡ اجرای دستی صف واردات" data-desc="سیستم بر اساس ظرفیت فعلی صف و Workerهای آماده، کالاها را پردازش می‌کند." style="padding: 4px 18px; height: auto; font-size: 14px;"' . ($queue_is_paused ? ' disabled="disabled" title="ابتدا صف را ادامه دهید"' : '') . '>⚡ اجرای صف اکنون</button>';
    echo '<details style="flex-basis:100%;margin-top:4px;"><summary style="cursor:pointer;font-weight:600;color:#475569;">ابزارهای نگهداری و پاک‌سازی (پیشرفته)</summary><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;padding:12px 0;">';
    echo '<button type="submit" name="evazar_sync_existing_items" class="button evazar-ajax-action-btn" data-action="sync_existing_items" data-title="🔄 همگام‌سازی دسته‌ها، برندها و مشخصات" data-desc="در حال اتصال کالاها به دسته‌بندی‌های سلسله‌مراتبی، همگام‌سازی برندها، ساختار گالری و متادیتاها..." style="color: #0284c7; border-color: #38bdf8;">🔄 همگام‌سازی دسته‌ها و برندها</button>';
    echo '<button type="submit" name="evazar_requeue_all_for_ai_rewrite" class="button evazar-ajax-action-btn" data-action="requeue_all_for_ai_rewrite" data-title="🔄 بازگردانی تمام کالاها به صف برای بازنویسی" data-desc="در حال بررسی تمام کالاهای سایت و بازگردانی آن‌ها به صف جهت بازنویسی با قوانین جدید هوش مصنوعی..." data-confirm="آیا مایلید تمام کالاهای سایت به صف واردات بازگردند تا با قوانین جدید (حذف نقاط ضعف و اصل تناسب) بازنویسی شوند؟" style="color: #4338ca; border-color: #a5b4fc; background: #eef2ff; font-weight: 600;">🔄 بازگردانی تمام کالاها به صف برای بازنویسی کامل</button>';
    echo '<button type="submit" name="evazar_generate_terms_seo_content" class="button evazar-ajax-action-btn" data-action="generate_terms_seo_content" data-title="🤖 تولید محتوای سئو با هوش مصنوعی" data-desc="در حال تحلیل دسته‌ها و برندهای فاقد محتوا و نگارش مقالات تخصصی راهنمای خرید سئو..." style="color: #15803d; border-color: #86efac;">🤖 تولید محتوای سئو برای دسته‌ها و برندهای خالی</button>';
    echo '<button type="submit" name="evazar_clear_all_short_descriptions" class="button evazar-ajax-action-btn" data-action="clear_all_short_descriptions" data-title="🗑 پاک‌سازی کامل توضیحات کوتاه تمام کالاها" data-desc="در حال پاکسازی و حذف کامل توضیحات کوتاه از تمام کالاهای سایت..." data-confirm="آیا مطمئن هستید که می‌خواهید توضیحات کوتاه از تمام کالاهای سایت به طور کامل حذف شود؟" style="color: #6d28d9; border-color: #c4b5fd; background: #f5f3ff; font-weight: 600;">🗑 پاک‌سازی کامل توضیحات کوتاه تمام کالاها</button>';
    echo '<button type="submit" name="evazar_cleanup_downloaded_images" class="button evazar-ajax-action-btn" data-action="cleanup_downloaded_images" data-title="🧹 آزادسازی فضای هاست و پاکسازی تصاویر" data-desc="در حال پاکسازی فایل‌های ذخیره شده در هاست و اتصال مستقیم تصاویر به CDN دیجی‌کالا..." data-confirm="آیا از حذف تصاویر ذخیره شده در هاست و بازگشت کامل به CDN مطمئن هستید؟ (هیچ عکسی از کالا پاک نمی‌شود، فقط فایل‌های هاست حذف شده و عکس‌ها مستقیم از CDN خوانده می‌شوند)" style="color: #ea580c; border-color: #fdba74;">🧹 پاکسازی تصاویر ذخیره‌شده از هاست</button>';
    echo '<button type="submit" name="evazar_clear_queue" class="button evazar-ajax-action-btn" data-action="clear_queue" data-title="🗑 پاک‌سازی کامل صف" data-desc="در حال تخلیه تمام ردیف‌های صف واردات..." data-confirm="آیا از پاک‌سازی کامل صف مطمئن هستید؟" style="color: #b91c1c; border-color: #fca5a5;">🗑 پاک‌سازی صف</button>';
    echo '</div></details>';
    echo '<a href="' . esc_url(admin_url('edit.php?post_type=evazar_product&page=evazar-importer#evazar-import-logs')) . '" class="button" style="color: #2563eb; border-color: #93c5fd; background: #eff6ff; font-weight: 600;">📋 مشاهده ۲۰۰ لاگ اخیر واردات</a>';
    echo '</form>';
    $next_auto_at = evazar_queue_next_auto_run_at();
    $queue_display_tz = function_exists('wp_timezone') ? wp_timezone() : null;
    $next_auto_label = ($next_auto_at > time() && function_exists('wp_date')) ? wp_date('Y-m-d H:i:s', $next_auto_at, $queue_display_tz) : '';
    $run_diag = get_option('evazar_queue_last_run_diagnostics', []);
    if (!is_array($run_diag)) $run_diag = [];
    $last_started_at = absint($run_diag['started_at'] ?? 0);
    $last_started_label = ($last_started_at > 0 && function_exists('wp_date')) ? wp_date('Y-m-d H:i:s', $last_started_at, $queue_display_tz) : '';
    $last_start_lag = absint($run_diag['start_lag_seconds'] ?? 0);
    $last_run_duration = absint($run_diag['duration_seconds'] ?? 0);
    $run_status_label = (($run_diag['status'] ?? '') === 'running') ? '؛ آخرین اجرا هنوز در حال اجراست' : '';
    $internal_cron_label = (defined('DISABLE_WP_CRON') && DISABLE_WP_CRON)
        ? 'WP-Cron داخلی غیرفعال است؛ باید Cron واقعی سرور فعال باشد.'
        : 'WP-Cron داخلی فعال است؛ برای کاهش تأخیر، Cron واقعی cPanel را هم هر دقیقه اجرا کن.';
    $last_interval_seconds = absint($run_diag['interval_seconds'] ?? get_option('evazar_queue_last_random_interval_seconds', 0));
    $last_interval_display = $last_interval_seconds > 0 ? evazar_queue_format_interval_duration($last_interval_seconds) : '';
    $min_interval_display = evazar_queue_format_interval_duration($current_min_interval * MINUTE_IN_SECONDS);
    $max_interval_display = evazar_queue_format_interval_duration($current_max_interval * MINUTE_IN_SECONDS);
    echo '<span style="color: #64748b; font-size: 13px;">' . ($queue_is_paused ? '<strong style="color:#9a3412;">صف متوقف است؛ ورودی‌های جدید فقط ذخیره می‌شوند.</strong> ' : '') . 'فاصله اجرای خودکار با گام تصادفی یک ثانیه بین <strong>' . esc_html($min_interval_display) . '</strong> و <strong>' . esc_html($max_interval_display) . '</strong> انتخاب و از شروع اجرای قبلی محاسبه می‌شود؛ مثلاً ۶ دقیقه و ۲۰ ثانیه. اگر اجرا طولانی شود، نوبت بعدی فقط پس از آزادشدن قفل شروع می‌شود.' . ($last_interval_display !== '' ? ' فاصله انتخاب‌شده در اجرای اخیر: <strong>' . esc_html($last_interval_display) . '</strong>.' : '') . ($next_auto_label !== '' ? ' موعد بعدی: <strong>' . esc_html($next_auto_label) . '</strong>.' : '') . ' اندازه هر درخواست Gemini برابر <strong>' . (int) evazar_queue_product_batch_size() . '</strong> محصول است. ' . ($last_started_label !== '' ? 'آخرین شروع: <strong>' . esc_html($last_started_label) . '</strong>؛ تأخیر شروع نسبت به موعد: <strong>' . $last_start_lag . ' ثانیه</strong>؛ مدت اجرا: <strong>' . $last_run_duration . ' ثانیه</strong>' . esc_html($run_status_label) . '. ' : '') . esc_html($internal_cron_label) . ' توقف صف، ورودی‌ها را حذف نمی‌کند؛ خطاهای موقت نیز با رعایت فاصله و موعد retry پردازش می‌شوند.</span>';
    echo '</div>';

    // فیلتر تب‌های وضعیت
    $base_page_url = admin_url('edit.php?post_type=evazar_product&page=evazar-queue');
    echo '<div style="margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">';
    echo '<ul class="subsubsub" style="margin: 0; float: none;">';
    echo '<li><a href="' . esc_url($base_page_url) . '" class="' . (empty($current_filter) ? 'current' : '') . '">همه <span class="count">(' . intval($total_all) . ')</span></a> | </li>';
    echo '<li><a href="' . esc_url(add_query_arg('q_status', 'pending', $base_page_url)) . '" class="' . ($current_filter === 'pending' ? 'current' : '') . '">در انتظار <span class="count">(' . intval($pending) . ')</span></a> | </li>';
    echo '<li><a href="' . esc_url(add_query_arg('q_status', 'capacity_waiting', $base_page_url)) . '" class="' . ($is_capacity_waiting_filter ? 'current' : '') . '">منتظر ظرفیت <span class="count">(' . intval($capacity_waiting) . ')</span></a> | </li>';
    echo '<li><a href="' . esc_url(add_query_arg('q_status', 'processing', $base_page_url)) . '" class="' . ($current_filter === 'processing' ? 'current' : '') . '">در حال پردازش <span class="count">(' . intval($processing) . ')</span></a> | </li>';
    echo '<li><a href="' . esc_url(add_query_arg('q_status', 'completed', $base_page_url)) . '" class="' . ($current_filter === 'completed' ? 'current' : '') . '">تکمیل شده <span class="count">(' . intval($completed) . ')</span></a> | </li>';
    echo '<li><a href="' . esc_url(add_query_arg('q_status', 'failed', $base_page_url)) . '" class="' . ($current_filter === 'failed' ? 'current' : '') . '">دارای خطا <span class="count">(' . intval($failed) . ')</span></a> | </li>';
    echo '<li><a href="' . esc_url(add_query_arg('q_status', 'quarantined', $base_page_url)) . '" class="' . ($current_filter === 'quarantined' ? 'current' : '') . '">قرنطینهٔ بررسی <span class="count">(' . intval($quarantined) . ')</span></a> | </li>';
    echo '<li><a href="' . esc_url(add_query_arg('q_status', 'excluded', $base_page_url)) . '" class="' . ($current_filter === 'excluded' ? 'current' : '') . '">خارج‌شده از صف <span class="count">(' . intval($excluded) . ')</span></a> | </li>';
    echo '<li><a href="' . esc_url(add_query_arg('q_status', 'imported_24h', $base_page_url)) . '" class="' . ($is_imported_24h_filter ? 'current' : '') . '">محصولات وارد شده ۲۴ ساعت گذشته <span class="count">(' . intval($imported_24h_count) . ')</span></a> | </li>';
    echo '<li><a href="' . esc_url(add_query_arg('q_status', 'imported_1h', $base_page_url)) . '" class="' . ($is_imported_1h_filter ? 'current' : '') . '">وارد شده در یک ساعت گذشته <span class="count">(' . intval($imported_1h_count) . ')</span></a></li>';
    echo '</ul>';
    echo '<span style="font-size: 13px; color: #64748b;">نمایش آخرین ۵۰ ردیف</span>';
    echo '</div>';

    if ($current_filter === 'quarantined') {
        echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin:0 0 14px;padding:12px 14px;border:1px solid #fed7aa;background:#fff7ed;border-radius:8px;">';
        echo '<div style="font-size:13px;line-height:1.8;color:#7c2d12;"><strong>بازگردانی گروهی قرنطینه</strong><br>همهٔ موارد دارای DKP عددی، نه فقط ۵۰ ردیف قابل‌نمایش، در صف تلاش مجدد ثبت می‌شوند. سیستم فقط به‌اندازهٔ ظرفیت فعال آن‌ها را پردازش می‌کند و بقیه در صف انتظار ظرفیت می‌مانند. موارد با DKP نامعتبر برای بررسی دستی در قرنطینه باقی می‌مانند؛ محصولی حذف یا مستقیماً بازنویسی نمی‌شود.</div>';
        if ((int) $quarantined_requeueable > 0) {
            echo '<button type="button" class="button button-primary evazar-ajax-action-btn" data-action="retry_all_quarantined_items" data-title="بازگردانی همهٔ قرنطینه به صف واردات" data-desc="تمام ردیف‌های قرنطینه‌شده با DKP عددی به صف تلاش مجدد ثبت می‌شوند؛ عبور از سقف ظرفیت فعال انجام نمی‌شود." data-confirm="همهٔ ' . (int) $quarantined_requeueable . ' ردیف قابل‌بازگردانی به سیستم صف واردات سپرده شوند؟ موارد ابتدا در صف انتظار ظرفیت قرار می‌گیرند و به‌اندازهٔ ظرفیت آزاد فعال می‌شوند." style="white-space:nowrap;">↩ افزودن همه به صف واردات (' . number_format_i18n((int) $quarantined_requeueable) . ')</button>';
        } elseif ((int) $quarantined > 0) {
            echo '<button type="button" class="button" disabled="disabled">مورد دارای DKP معتبر برای بازگردانی وجود ندارد</button>';
        } else {
            echo '<button type="button" class="button" disabled="disabled">قرنطینه‌ای برای بازگردانی وجود ندارد</button>';
        }
        echo '</div>';
    }

    // جدول آیتم‌های صف
    echo '<table class="wp-list-table widefat fixed striped" style="border-radius: 8px; overflow: hidden;">';
    echo '<thead><tr>';
    echo '<th style="width: 65px;">' . (($is_imported_1h_filter || $is_imported_24h_filter) ? 'شناسه کالا' : 'شناسه صف') . '</th>';
    echo '<th style="width: 120px;">کد کالا (DKP)</th>';
    echo '<th style="width: 30%;">آدرس دیجی‌کالا</th>';
    echo '<th style="width: 110px;">وضعیت</th>';
    echo '<th style="width: 160px;">' . (($is_imported_1h_filter || $is_imported_24h_filter) ? 'زمان ورود موفق' : 'تاریخ ثبت صف') . '</th>';
    echo '<th>' . (($is_imported_1h_filter || $is_imported_24h_filter) ? 'محصول واردشده' : 'گزارش خطا و وضعیت هوشمند') . '</th>';
    echo '</tr></thead>';
    echo '<tbody>';

    if (empty($recent_items)) {
        $empty_message = $is_imported_1h_filter ? 'در یک ساعت گذشته محصولی از طریق صف واردات با موفقیت ثبت نشده است.' : ($is_imported_24h_filter ? 'در ۲۴ ساعت گذشته محصولی از طریق صف واردات با موفقیت ثبت نشده است.' : 'هیچ موردی مطابق فیلتر انتخابی در صف یافت نشد.');
        echo '<tr><td colspan="6" style="text-align: center; padding: 25px; color: #94a3b8;">' . esc_html($empty_message) . '</td></tr>';
    } else {
        foreach ($recent_items as $item) {
            $badge_style = 'padding: 4px 10px; border-radius: 12px; font-size: 12px; font-weight: bold; display: inline-block;';
            switch ($item->status) {
                case 'imported':
                    $badge = '<span style="' . $badge_style . ' background: #d1fae5; color: #065f46;">وارد شده</span>';
                    break;
                case 'completed':
                    $badge = '<span style="' . $badge_style . ' background: #d1fae5; color: #065f46;">تکمیل شده</span>';
                    break;
                case 'processing':
                    $badge = '<span style="' . $badge_style . ' background: #dbeafe; color: #1e40af;">در حال پردازش</span>';
                    break;
                case 'capacity_waiting':
                    $badge = '<span style="' . $badge_style . ' background: #ffedd5; color: #9a3412;">منتظر ظرفیت</span>';
                    break;
                case 'failed':
                    $badge = '<span style="' . $badge_style . ' background: #fee2e2; color: #991b1b;">خطا خورده</span>';
                    break;
                case 'quarantined':
                    $badge = '<span style="' . $badge_style . ' background: #fef3c7; color: #92400e;">نیازمند بررسی</span>';
                    break;
                case 'excluded':
                    $badge = '<span style="' . $badge_style . ' background: #e2e8f0; color: #334155;">خارج از صف</span>';
                    break;
                default:
                    $badge = '<span style="' . $badge_style . ' background: #fef3c7; color: #92400e;">در انتظار</span>';
                    break;
            }

            // بج ساختاریافته کد خطا
            $error_badge = '';
            if (!empty($item->error_code)) {
                $code = $item->error_code;
                $err_style = 'display: inline-flex; align-items: center; gap: 4px; padding: 3px 8px; border-radius: 6px; font-size: 11px; font-weight: 600; margin-left: 8px; margin-bottom: 4px;';
                if ($code === 'DK_BLOCKED_403') {
                    $error_badge = '<span style="' . $err_style . ' background: #fee2e2; color: #991b1b;">🛡️ مسدودی فایروال (۴۰۳)</span>';
                } elseif ($code === 'DK_RATE_LIMIT_429') {
                    $error_badge = '<span style="' . $err_style . ' background: #ffedd5; color: #9a3412;">⏳ محدودیت نرخ (۴۲۹)</span>';
                } elseif ($code === 'DK_NOT_FOUND_404') {
                    $error_badge = '<span style="' . $err_style . ' background: #f3e8ff; color: #6b21a8;">❌ کالای ناموجود (۴۰۴)</span>';
                } elseif ($code === 'SCHEMA_MISMATCH') {
                    $error_badge = '<span style="' . $err_style . ' background: #e0f2fe; color: #0369a1;">⚠️ تغییر ساختار داده API</span>';
                } elseif ($code === 'API_CONN_ERROR') {
                    $error_badge = '<span style="' . $err_style . ' background: #f1f5f9; color: #475569;">🌐 خطای اتصال شبکه</span>';
                } elseif ($code === 'SOURCE_CATEGORY_PATH_MISSING') {
                    $error_badge = '<span style="' . $err_style . ' background: #fef3c7; color: #92400e;">📂 مسیر دسته‌بندی مبدأ موجود نیست؛ نیازمند بررسی</span>';
                } elseif ($code === 'EXCLUDED_BY_ADMIN') {
                    $error_badge = '<span style="' . $err_style . ' background: #e2e8f0; color: #334155;">⛔ خارج‌شده به درخواست مدیر</span>';
                } else {
                    $error_badge = '<span style="' . $err_style . ' background: #f1f5f9; color: #334155; font-family: monospace;">⚠️ ' . esc_html($code) . '</span>';
                }
            }

            $time_err = !empty($item->last_error_at) ? '<div style="font-size: 11px; color: #94a3b8; margin-top: 3px; direction: ltr; text-align: right;">آخرین رخداد: ' . esc_html($item->last_error_at) . '</div>' : '';

            echo '<tr>';
            $display_id = (($is_imported_1h_filter || $is_imported_24h_filter) && !empty($item->product_id)) ? intval($item->product_id) : $item->id;
            echo '<td>' . esc_html($display_id) . '</td>';
            echo '<td><strong>' . esc_html($item->dkp) . '</strong></td>';
            echo '<td><a href="' . esc_url($item->url) . '" target="_blank" style="direction: ltr; display: inline-block; word-break: break-all;">' . esc_html($item->url) . '</a></td>';
            echo '<td>' . $badge . '</td>';
            $display_created_at = ($is_imported_1h_filter || $is_imported_24h_filter)
                ? get_date_from_gmt((string) $item->created_at, 'Y-m-d H:i:s')
                : (string) $item->created_at;
            echo '<td style="direction: ltr; text-align: right;">' . esc_html($display_created_at) . '</td>';
            echo '<td>';
            if ($is_imported_1h_filter || $is_imported_24h_filter) {
                if (!empty($item->product_id) && !empty($item->post_title)) {
                    $edit_url = admin_url('post.php?post=' . absint($item->product_id) . '&action=edit');
                    echo '<a href="' . esc_url($edit_url) . '" style="font-weight:600;">' . esc_html($item->post_title) . '</a>';
                    echo '<div style="font-size:11px; color:#64748b; margin-top:3px;">شناسه محصول: ' . intval($item->product_id) . '</div>';
                } else {
                    echo '<span style="color:#64748b;">رکورد محصول در حال حاضر قابل مشاهده نیست.</span>';
                }
            } else {
                if ($error_badge) {
                    echo $error_badge;
                }
                if (!empty($item->error_log)) {
                    echo '<div style="color: #475569; font-size: 12px; line-height: 1.6;">' . esc_html($item->error_log) . '</div>';
                } elseif (empty($error_badge)) {
                    echo '<span style="color: #94a3b8;">-</span>';
                }
                echo $time_err;
                $related_product_id = absint($item->related_product_id ?? 0);
                if ($related_product_id > 0) {
                    $edit_url = admin_url('post.php?post=' . $related_product_id . '&action=edit');
                    $related_product_label = evazar_queue_quarantine_row_has_saved_partial_product($item)
                        ? 'بازکردن محصول ذخیره‌شده ناقص #'
                        : 'بازکردن محصول مرتبط #' ;
                    echo '<div style="margin-top:5px;"><a href="' . esc_url($edit_url) . '" target="_blank">' . esc_html($related_product_label . $related_product_id) . ' برای بررسی</a>';
                    if (!evazar_queue_quarantine_row_has_saved_partial_product($item)) echo '<div style="font-size:11px;color:#64748b;">در این تلاش تغییری در محصول موجود داده نشده است.</div>';
                    echo '</div>';
                }
                if ($item->status === 'quarantined') {
                    echo '<div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:8px;">';
                    if ((string) ($item->error_code ?? '') === 'SOURCE_CATEGORY_PATH_MISSING'
                        && $related_product_id > 0
                        && evazar_queue_quarantine_row_has_saved_partial_product($item)) {
                        echo '<button type="button" class="button evazar-ajax-action-btn" data-action="draft_quarantined_product" data-item-id="' . absint($item->id) . '" data-title="انتقال محصول ناقص به پیش‌نویس" data-desc="فقط برای موارد قدیمی که محصول ذخیره شده اما تأیید دسته‌بندی شکست خورده است." data-confirm="محصول ذخیره‌شده به پیش‌نویس منتقل شود؟ این کار محصول را حذف نمی‌کند.">⬇ پیش‌نویس محصول ذخیره‌شده</button>';
                    }
                    echo '<button type="button" class="button button-primary evazar-ajax-action-btn" data-action="retry_quarantined_item" data-item-id="' . absint($item->id) . '" data-title="بازگردانی محصول به صف" data-desc="محصول پس از بررسی دوباره وارد صف انتظار می‌شود." data-confirm="این محصول دوباره وارد صف عادی شود؟">↩ بازگردانی به صف</button>';
                    echo '<button type="button" class="button evazar-ajax-action-btn" data-action="exclude_quarantined_item" data-item-id="' . absint($item->id) . '" data-title="خروج از صف واردات" data-desc="رکورد صف برای جلوگیری از ورود خودکار تکراری حفظ می‌شود؛ محصول ذخیره‌شده در سایت حذف نمی‌شود." data-confirm="این محصول از پردازش خودکار خارج شود؟ محصول موجود در سایت حذف نخواهد شد.">⛔ خروج از صف واردات</button>';
                    echo '</div>';
                    if (!empty($item->next_attempt_at)) echo '<div style="font-size:11px;color:#64748b;margin-top:4px;">تلاش خودکار مجدد: ' . esc_html((string) $item->next_attempt_at) . '</div>';
                } elseif ($item->status === 'excluded') {
                    echo '<div style="margin-top:8px;"><button type="button" class="button evazar-ajax-action-btn" data-action="requeue_excluded_item" data-item-id="' . absint($item->id) . '" data-title="بازگردانی محصول مستثناشده" data-desc="محصول دوباره به صف انتظار بازمی‌گردد." data-confirm="این محصول دوباره وارد صف واردات شود؟">↩ بازگردانی به صف واردات</button></div>';
                }
            }
            echo '</td>';
            echo '</tr>';
        }
    }

    echo '</tbody></table>';
    echo '</div>';

    // مودال پردازش ایجکس و دیالوگ زنده پیشرفت
    ?>
    <div id="evazar-queue-modal-overlay" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(15,23,42,0.68); backdrop-filter:blur(5px); z-index:999999; align-items:center; justify-content:center;">
        <div style="background:#fff; border-radius:16px; max-width:500px; width:92%; padding:32px 26px; box-shadow:0 25px 50px -12px rgba(0,0,0,0.25); text-align:center; font-family:inherit; direction:rtl; position:relative;">
            <div id="evazar-modal-icon-container" style="margin-bottom:18px;">
                <div class="evazar-spinner-circle" style="width:52px; height:52px; border:4px solid #f1f5f9; border-top-color:#ef394e; border-radius:50%; margin:0 auto; animation:evazarSpin 0.85s linear infinite;"></div>
            </div>
            <h3 id="evazar-modal-title" style="margin:0 0 12px; font-size:18px; font-weight:700; color:#1e293b;">در حال پردازش...</h3>
            <p id="evazar-modal-desc" style="margin:0 0 22px; font-size:13.5px; line-height:1.75; color:#64748b;">سیستم در حال برقراری ارتباط با سرور است. لطفاً منتظر بمانید...</p>
            <div id="evazar-modal-progress" style="width:100%; height:6px; background:#f1f5f9; border-radius:99px; overflow:hidden; margin-bottom:22px; position:relative;">
                <div class="evazar-bar-anim" style="width:50%; height:100%; background:linear-gradient(90deg, #ef394e, #f97316); border-radius:99px;"></div>
            </div>
            <div id="evazar-modal-actions" style="display:none; gap:12px; justify-content:center; flex-wrap:wrap;">
                <button type="button" id="evazar-modal-close-btn" class="button button-primary" style="padding:6px 24px; font-size:13px; font-weight:600; border-radius:6px;">متوجه شدم و بستن</button>
                <button type="button" id="evazar-modal-reload-btn" class="button" style="padding:6px 20px; font-size:13px; border-radius:6px;">به‌روزرسانی فوری جدول</button>
            </div>
        </div>
    </div>

    <style>
    @keyframes evazarSpin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    @keyframes evazarPulseBar { 0% { transform: translateX(120%); } 100% { transform: translateX(-120%); } }
    .evazar-bar-anim { animation: evazarPulseBar 1.6s ease-in-out infinite; }
    .evazar-ajax-action-btn:disabled { opacity: 0.6; cursor: not-allowed; }
    </style>

    <script>
    jQuery(document).ready(function($) {
        var overlay = $('#evazar-queue-modal-overlay');
        var iconContainer = $('#evazar-modal-icon-container');
        var titleEl = $('#evazar-modal-title');
        var descEl = $('#evazar-modal-desc');
        var progEl = $('#evazar-modal-progress');
        var actionsEl = $('#evazar-modal-actions');
        var closeBtn = $('#evazar-modal-close-btn');
        var reloadBtn = $('#evazar-modal-reload-btn');

        var spinnerHtml = '<div class="evazar-spinner-circle" style="width:52px; height:52px; border:4px solid #f1f5f9; border-top-color:#ef394e; border-radius:50%; margin:0 auto; animation:evazarSpin 0.85s linear infinite;"></div>';
        var successHtml = '<div style="width:56px; height:56px; border-radius:50%; background:#dcfce7; color:#16a34a; display:flex; align-items:center; justify-content:center; margin:0 auto; font-size:30px; font-weight:bold;">✓</div>';
        var errorHtml = '<div style="width:56px; height:56px; border-radius:50%; background:#fee2e2; color:#dc2626; display:flex; align-items:center; justify-content:center; margin:0 auto; font-size:30px; font-weight:bold;">✕</div>';

        $('.evazar-ajax-action-btn').on('click', function(e) {
            var btn = $(this);
            var action = btn.data('action');
            var confirmMsg = btn.data('confirm');
            var title = btn.data('title') || 'در حال اجرای عملیات...';
            var desc = btn.data('desc') || 'سیستم در حال برقراری ارتباط با سرور و پردازش داده‌هاست. لطفاً صفحه را نبندید...';

            if (confirmMsg && !window.confirm(confirmMsg)) {
                e.preventDefault();
                return false;
            }

            e.preventDefault();

            // باز کردن مودال در وضعیت در حال پردازش
            iconContainer.html(spinnerHtml);
            titleEl.text(title);
            descEl.text(desc);
            progEl.show();
            actionsEl.hide();
            overlay.css('display', 'flex');

            btn.prop('disabled', true);

            // ارسال درخواست ایجکس
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                dataType: 'json',
                timeout: 300000,
                data: {
                    action: 'evazar_queue_ajax_action',
                    action_type: action,
                    item_id: parseInt(btn.data('item-id') || 0, 10),
                    security: $('#evazar-queue-actions-form input[name="_wpnonce"]').val()
                },
                success: function(resp) {
                    btn.prop('disabled', false);
                    progEl.hide();
                    actionsEl.css('display', 'flex');

                    if (resp && resp.success) {
                        iconContainer.html(successHtml);
                        titleEl.text('عملیات با موفقیت انجام شد');
                        descEl.text(resp.data && resp.data.message ? resp.data.message : 'عملیات با موفقیت تکمیل شد.');

                        if (resp.data && resp.data.stats) {
                            var st = resp.data.stats;
                            $('a:contains("همه") .count').text('(' + st.total + ')');
                            $('a:contains("در انتظار") .count').text('(' + st.pending + ')');
                            if (typeof st.capacity_waiting !== 'undefined') {
                                $('a:contains("منتظر ظرفیت") .count').text('(' + st.capacity_waiting + ')');
                            }
                            $('a:contains("در حال پردازش") .count').text('(' + st.processing + ')');
                            $('a:contains("تکمیل شده") .count').text('(' + st.completed + ')');
                            $('a:contains("دارای خطا") .count').text('(' + st.failed + ')');
                            if (typeof st.quarantined !== 'undefined') $('a:contains("قرنطینهٔ بررسی") .count').text('(' + st.quarantined + ')');
                            if (typeof st.excluded !== 'undefined') $('a:contains("خارج‌شده از صف") .count').text('(' + st.excluded + ')');
                            if (typeof st.imported_24h !== 'undefined') {
                                $('a:contains("محصولات وارد شده ۲۴ ساعت گذشته") .count').text('(' + st.imported_24h + ')');
                            }
                            if (typeof st.imported_1h !== 'undefined') {
                                $('a:contains("وارد شده در یک ساعت گذشته") .count').text('(' + st.imported_1h + ')');
                            }
                        }

                        // ریلود خودکار پس از ۳.۵ ثانیه جهت مشاهده جدول به‌روز شده
                        setTimeout(function() {
                            window.location.reload();
                        }, 3500);
                    } else {
                        iconContainer.html(errorHtml);
                        titleEl.text('خطا در پردازش');
                        var err = (resp && resp.data && resp.data.message) ? resp.data.message : 'خطای نامشخصی در پردازش رخ داد.';
                        descEl.text(err);
                    }
                },
                error: function(xhr, status, error) {
                    btn.prop('disabled', false);
                    progEl.hide();
                    actionsEl.css('display', 'flex');
                    iconContainer.html(errorHtml);
                    titleEl.text('خطای ارتباط با سرور');
                    if (status === 'timeout') {
                        descEl.text('زمان پاسخگویی به پایان رسید، اما ممکن است فرآیند در پس‌زمینه سرور در حال تکمیل باشد. صفحه را پس از دقایقی بررسی کنید.');
                    } else {
                        descEl.text('پاسخی از سرور دریافت نشد (' + (error || status) + '). لطفاً مجدداً بررسی فرمایید.');
                    }
                }
            });
        });

        closeBtn.on('click', function() {
            overlay.hide();
            window.location.reload();
        });

        reloadBtn.on('click', function() {
            window.location.reload();
        });
    });
    </script>
    <?php
}


// ==========================================
// 7. Lightweight WordPress dashboard overview
// ==========================================
add_action('wp_dashboard_setup', 'evazar_queue_register_dashboard_widget', 20);
function evazar_queue_register_dashboard_widget() {
    // Import queue metrics and administrative links are restricted to site administrators.
    if (!current_user_can('manage_options')) return;
    wp_add_dashboard_widget(
        'evazar_import_overview_widget',
        'وضعیت واردات ایوازار',
        'evazar_queue_render_dashboard_widget'
    );
}

/**
 * Aggregate queue/history counts with a short shared cache so loading the admin
 * dashboard does not issue repeated COUNT(*) queries against large tables.
 */
function evazar_queue_get_dashboard_stats() {
    global $wpdb;
    $cache_key = 'evazar_queue_dashboard_stats_v2';
    $cached = get_transient($cache_key);
    if (is_array($cached) && isset($cached['generated_at'])) return $cached;

    $stats = [
        'queue_available' => false,
        'queue_stats_ok' => false,
        'history_available' => false,
        'history_stats_ok' => false,
        'total' => 0,
        'pending' => 0,
        'capacity_waiting' => 0,
        'processing' => 0,
        'completed' => 0,
        'failed' => 0,
        'published_products' => 0,
        'imported_1h' => 0,
        'imported_24h' => 0,
        'imported_7d' => 0,
        'last_success' => '',
        'generated_at' => time(),
    ];

    $queue_table = $wpdb->prefix . 'evazar_import_queue';
    $queue_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($queue_table)));
    if ($queue_exists === $queue_table) {
        $stats['queue_available'] = true;
        // Single aggregate query is cheaper than a separate full COUNT(*) per status.
        $row = $wpdb->get_row(
            "SELECT COUNT(*) AS total,
                    COALESCE(SUM(q.status = 'pending'), 0) AS pending,
                    COALESCE(SUM(q.status = 'processing'), 0) AS processing,
                    COALESCE(SUM(q.status = 'completed' AND NOT EXISTS (SELECT 1 FROM `{$wpdb->prefix}evazar_import_intake` i WHERE i.dkp=q.dkp)), 0) AS completed,
                    COALESCE(SUM(q.status = 'failed' AND NOT EXISTS (SELECT 1 FROM `{$wpdb->prefix}evazar_import_intake` i WHERE i.dkp=q.dkp)), 0) AS failed
             FROM `{$queue_table}` q",
            ARRAY_A
        );
        if (is_array($row)) {
            $stats['queue_stats_ok'] = true;
            foreach (['total', 'pending', 'processing', 'completed', 'failed'] as $key) {
                $stats[$key] = absint($row[$key] ?? 0);
            }
            $intake_table = evazar_queue_capacity_intake_table_name();
            $stats['capacity_waiting'] = absint($wpdb->get_var("SELECT COUNT(*) FROM `$intake_table`"));
            $stats['total'] = absint($wpdb->get_var("SELECT COUNT(*) FROM (SELECT dkp FROM `$queue_table` UNION SELECT dkp FROM `$intake_table`) AS evazar_queue_unique_dkps"));
        }
    }

    $history_table = evazar_queue_import_history_table_name();
    $history_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($history_table)));
    if ($history_exists === $history_table) {
        $stats['history_available'] = true;
        $now = time();
        $cutoff_1h = gmdate('Y-m-d H:i:s', $now - HOUR_IN_SECONDS);
        $cutoff_24h = gmdate('Y-m-d H:i:s', $now - DAY_IN_SECONDS);
        $cutoff_7d = gmdate('Y-m-d H:i:s', $now - (7 * DAY_IN_SECONDS));
        // WHERE range uses the existing imported_at index; all history timestamps are UTC.
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT COALESCE(SUM(imported_at >= %s), 0) AS imported_1h,
                    COALESCE(SUM(imported_at >= %s), 0) AS imported_24h,
                    COUNT(*) AS imported_7d,
                    (SELECT MAX(imported_at) FROM `{$history_table}`) AS last_success
             FROM `{$history_table}`
             WHERE imported_at >= %s",
            $cutoff_1h,
            $cutoff_24h,
            $cutoff_7d
        ), ARRAY_A);
        if (is_array($row)) {
            $stats['history_stats_ok'] = true;
            foreach (['imported_1h', 'imported_24h', 'imported_7d'] as $key) {
                $stats[$key] = absint($row[$key] ?? 0);
            }
            $stats['last_success'] = is_string($row['last_success'] ?? null) ? $row['last_success'] : '';
        }
    }

    // WordPress maintains/caches post-type status counts; label this explicitly as published products.
    $post_counts = wp_count_posts('evazar_product');
    if (is_object($post_counts) && isset($post_counts->publish)) {
        $stats['published_products'] = absint($post_counts->publish);
    }

    $stats['generated_at'] = time();
    set_transient($cache_key, $stats, 30);
    return $stats;
}

function evazar_queue_render_dashboard_widget() {
    if (!current_user_can('manage_options')) {
        echo '<p>دسترسی مجاز نیست.</p>';
        return;
    }

    $stats = evazar_queue_get_dashboard_stats();
    $queue_url = admin_url('edit.php?post_type=evazar_product&page=evazar-queue');
    $products_url = admin_url('edit.php?post_type=evazar_product');
    $metric_url = static function ($key) use ($queue_url) {
        return add_query_arg('q_status', $key, $queue_url);
    };
    $queue_ok = !empty($stats['queue_available']) && !empty($stats['queue_stats_ok']);
    $history_ok = !empty($stats['history_available']) && !empty($stats['history_stats_ok']);
    $qvalue = static function ($key) use ($stats, $queue_ok) {
        return $queue_ok ? number_format_i18n((int)($stats[$key] ?? 0)) : '—';
    };
    $hvalue = static function ($key) use ($stats, $history_ok) {
        return $history_ok ? number_format_i18n((int)($stats[$key] ?? 0)) : '—';
    };
    $published_value = number_format_i18n((int)$stats['published_products']);

    $cards = [
        ['label' => 'در صف انتظار', 'value' => $qvalue('pending'), 'color' => '#b45309', 'url' => $metric_url('pending')],
        ['label' => 'منتظر ظرفیت', 'value' => $qvalue('capacity_waiting'), 'color' => '#d97706', 'url' => $metric_url('capacity_waiting')],
        ['label' => 'در حال پردازش', 'value' => $qvalue('processing'), 'color' => '#1d4ed8', 'url' => $metric_url('processing')],
        ['label' => 'تکمیل‌شده در صف', 'value' => $qvalue('completed'), 'color' => '#047857', 'url' => $metric_url('completed')],
        ['label' => 'دارای خطا', 'value' => $qvalue('failed'), 'color' => '#b91c1c', 'url' => $metric_url('failed')],
        ['label' => 'موفق در ۲۴ ساعت اخیر', 'value' => $hvalue('imported_24h'), 'color' => '#6d28d9', 'url' => $metric_url('imported_24h')],
        ['label' => 'کل ردیف‌های صف', 'value' => $qvalue('total'), 'color' => '#334155', 'url' => $queue_url],
        ['label' => 'محصولات منتشرشده', 'value' => $published_value, 'color' => '#0f766e', 'url' => $products_url],
    ];

    echo '<div class="evazar-dashboard-overview" dir="rtl">';
    echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:10px;margin:4px 0 14px;">';
    foreach ($cards as $card) {
        echo '<a href="' . esc_url($card['url']) . '" style="display:block;text-decoration:none;color:inherit;background:#fff;border:1px solid #dcdcde;border-right:4px solid ' . esc_attr($card['color']) . ';border-radius:5px;padding:12px 13px;min-height:70px;box-sizing:border-box;">';
        echo '<span style="display:block;color:#50575e;font-size:12px;line-height:1.6;">' . esc_html($card['label']) . '</span>';
        echo '<strong style="display:block;color:' . esc_attr($card['color']) . ';font-size:23px;line-height:1.5;">' . esc_html((string)$card['value']) . '</strong>';
        echo '</a>';
    }
    echo '</div>';

    echo '<div style="display:flex;gap:14px;flex-wrap:wrap;align-items:center;padding:10px 12px;background:#f6f7f7;border:1px solid #dcdcde;border-radius:5px;margin-bottom:10px;">';
    echo '<span><strong>محصولات ثبت‌شده در یک ساعت اخیر:</strong> ' . esc_html($hvalue('imported_1h')) . '</span>';
    echo '<span><strong>محصولات ثبت‌شده در هفت روز اخیر:</strong> ' . esc_html($hvalue('imported_7d')) . '</span>';
    echo '</div>';

    if ($history_ok && !empty($stats['last_success'])) {
        $last_success_local = get_date_from_gmt($stats['last_success'], 'Y-m-d H:i');
        echo '<p style="margin:0 0 8px;color:#50575e;"><strong>آخرین ثبت موفق:</strong> ' . esc_html($last_success_local ?: $stats['last_success']) . '</p>';
    } elseif ($history_ok) {
        echo '<p style="margin:0 0 8px;color:#646970;">هنوز سابقه ثبت موفق در جدول تاریخچه موجود نیست.</p>';
    }

    if (empty($stats['queue_available'])) {
        echo '<p class="notice notice-warning inline" style="padding:6px 10px;">جدول صف واردات در دسترس نیست؛ آمار صف قابل نمایش نیست.</p>';
    } elseif (empty($stats['queue_stats_ok'])) {
        echo '<p class="notice notice-warning inline" style="padding:6px 10px;">خواندن آمار صف با خطا مواجه شد؛ مقادیر صف تا زمان رفع خطا نمایش داده نمی‌شوند.</p>';
    }
    if (empty($stats['history_available'])) {
        echo '<p class="notice notice-warning inline" style="padding:6px 10px;">جدول تاریخچه واردات در دسترس نیست؛ آمار بازه‌های زمانی قابل نمایش نیست.</p>';
    } elseif (empty($stats['history_stats_ok'])) {
        echo '<p class="notice notice-warning inline" style="padding:6px 10px;">خواندن تاریخچه واردات با خطا مواجه شد؛ آمار بازه‌های زمانی نمایش داده نمی‌شوند.</p>';
    }

    $updated = evazar_queue_local_datetime((int) $stats['generated_at'], 'H:i:s');
    if ($updated === '') $updated = '—';
    echo '<p style="margin:10px 0 0;color:#646970;font-size:11px;">به‌روزرسانی آمار: ' . esc_html($updated) . ' · کش آمار حداکثر ۳۰ ثانیه است.</p>';
    echo '<p style="margin:8px 0 0;"><a class="button button-secondary" href="' . esc_url($queue_url) . '">مشاهده جزئیات صف واردات</a></p>';
    echo '</div>';
}
