# QA — EVazar Core 2.9.84.57

## Regression suite

- 15 PHP regression files passed: 520 assertions/checks total.
- 3 JavaScript regression files passed: 54 assertions/checks total.
- PHP syntax checks passed for 27 PHP files.
- JavaScript syntax checks passed for 6 JS files.

## Focused cases

- The outer `PRODUCT_CATEGORY_SYNC_FAILED` error is quarantined only when its inner category code explicitly reports a missing source category/path.
- Generic term/database sync errors and Worker 502 errors are not incorrectly classified as category-path quarantine.
- Automatic requeue defaults off; only allowlisted intervals (1/3/7/14 days) are accepted.
- Legacy migration matches only known missing-source-path message fragments and uses a one-time migration option.
- Quarantined and excluded DKPs are returned as reserved by the Harvester endpoint; failed DKPs remain deliberately retryable.
- Manual quarantine requeue, exclusion, and requeue of excluded records are wired through the existing admin actions.

## Live test boundary

The tests use local/stubbed WordPress and simulated API responses. No live write/import was made against the production WordPress database, Digikala, or Cloudflare Workers. A direct browser fetch of the supplied Digikala URL returned a cache-miss error in this environment, so live product activation state could not be independently confirmed.

## Line-by-line review follow-up — 2.9.84.58

- Confirmed delayed auto-requeue keeps its exact status/error-code/due-time filter and resets `retries=0` to start a fresh retry generation.
- Confirmed the legacy migration preserves any already-populated `related_product_id`.
- All existing regression suites were rerun against the revised package; see release verification summary.
- Additional review: all early queue return payloads include quarantined items in the processed count, consistent with the final summary.
