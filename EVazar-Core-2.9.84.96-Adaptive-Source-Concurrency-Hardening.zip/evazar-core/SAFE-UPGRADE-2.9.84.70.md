# Safe upgrade — EVazar Core 2.9.84.70

1. Back up the site files and database before replacing Core.
2. Install only `EVazar Core 2.9.84.70`; no Worker deployment is required.
3. Open **ایوازار → گزارش عملیاتی Gemini → پاسخ خام دسته‌های دارای خطای JSON**.
4. For new partially invalid batches, inspect **علت اعتبارسنجی هر محصول**. The report now keeps up to 64,000 bytes of raw model output and up to 20 recent diagnostic records.
5. Batch size, queue retry policy, and unrelated cache behavior are unchanged. No live-site/API test is implied by local tests.
