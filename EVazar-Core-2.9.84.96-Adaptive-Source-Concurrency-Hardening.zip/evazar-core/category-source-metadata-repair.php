<?php
/**
 * Conservative, live-source repair of old evazar_category source metadata.
 * Writes taxonomy source metadata only. Never edits term names/slugs/parents, product assignments,
 * redirect options, product-index rows, cache, or Worker configuration.
 */
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', 'evazar_csmr_register_menu', 99);
add_action('wp_ajax_evazar_csmr_list_candidates', 'evazar_csmr_ajax_list_candidates');
add_action('wp_ajax_evazar_csmr_analyze_batch', 'evazar_csmr_ajax_analyze_batch');
add_action('wp_ajax_evazar_csmr_apply_batch', 'evazar_csmr_ajax_apply_batch');

function evazar_csmr_register_menu() {
    $parent = post_type_exists('evazar_product') ? 'edit.php?post_type=evazar_product' : 'tools.php';
    add_submenu_page($parent, 'بررسی و ترمیم متادیتای دسته‌ها', 'ترمیم متادیتای دسته‌ها', 'manage_options', 'evazar-category-source-repair', 'evazar_csmr_render_page');
}

function evazar_csmr_normalize_identity($value) {
    $value = html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if (class_exists('Normalizer')) {
        $normalized = Normalizer::normalize($value, Normalizer::FORM_KC);
        if (is_string($normalized)) $value = $normalized;
    }
    $value = strtr($value, array('ي'=>'ی', 'ى'=>'ی', 'ك'=>'ک', "\xE2\x80\x8C"=>'', "\xC2\xA0"=>' '));
    $value = preg_replace('/[\s\x{200c}\x{200d}]+/u', ' ', trim($value));
    return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
}

function evazar_csmr_normalize_category_path($value) {
    if (!function_exists('evazar_normalize_digikala_source_path')) return '';
    $path = evazar_normalize_digikala_source_path((string)$value);
    return ($path !== '' && preg_match('#^/(?:search|main)/#i', $path)) ? $path : '';
}

function evazar_csmr_metadata_state($term_id) {
    $term_id = absint($term_id);
    $kind = (string)get_term_meta($term_id, '_evazar_dk_source_kind', true);
    $url = (string)get_term_meta($term_id, '_evazar_dk_url', true);
    $path = evazar_csmr_normalize_category_path($url);
    $version = trim((string)get_term_meta($term_id, '_evazar_dk_source_map_version', true));
    $verified = (string)get_term_meta($term_id, '_evazar_dk_source_verified', true) === '1';
    $trusted = in_array($version, ['2.9.19', '2.9.84.27', '2.9.84.28', '2.9.84.29', '2.9.84.29-live-category-metadata-repair'], true);
    $complete = $verified && $kind === 'digikala_breadcrumb' && $path !== '' && $trusted;
    return [
        'kind'=>$kind, 'url'=>$url, 'path'=>$path, 'version'=>$version,
        'verified'=>$verified, 'trusted_version'=>$trusted, 'complete'=>$complete,
    ];
}

function evazar_csmr_check_access() {
    if (!current_user_can('manage_options')) wp_send_json_error(['message'=>'دسترسی مدیر لازم است.'], 403);
    check_ajax_referer('evazar_csmr_nonce', 'nonce');
    if (!function_exists('evazar_bsmr_queue_guard')) {
        wp_send_json_error(['message'=>'بررسی ایمن صف در Core موجود نیست؛ نسخهٔ افزونه را بررسی کن.'], 409);
    }
    $guard = evazar_bsmr_queue_guard();
    if (is_wp_error($guard)) wp_send_json_error(['message'=>$guard->get_error_message(), 'code'=>$guard->get_error_code()], 409);
}

function evazar_csmr_get_dkp_for_post($post_id) {
    $post_id = absint($post_id);
    if (!$post_id) return ['dkp'=>'', 'conflict'=>false];
    $values = [];
    foreach (['_evazar_sku', '_evazar_dk_id', '_sku'] as $key) {
        $raw = trim((string)get_post_meta($post_id, $key, true));
        if ($raw === '') continue;
        if (preg_match('/(?:^|\b)dkp-(\d+)(?:\b|$)/i', $raw, $m)) $value = ltrim($m[1], '0');
        elseif (ctype_digit($raw)) $value = ltrim($raw, '0');
        else continue;
        if ($value !== '') $values[$value] = true;
    }
    $url = trim((string)get_post_meta($post_id, '_evazar_dk_url', true));
    if (preg_match('/dkp-(\d+)/i', $url, $m)) { $value = ltrim($m[1], '0'); if ($value !== '') $values[$value] = true; }
    if (count($values) > 1) return ['dkp'=>'', 'conflict'=>true];
    $dkp = $values ? (string)array_key_first($values) : '';
    return ['dkp'=>(ctype_digit($dkp) && (int)$dkp > 0) ? $dkp : '', 'conflict'=>false];
}

function evazar_csmr_get_sample_products($term_id) {
    $posts = get_posts([
        'post_type'=>'evazar_product', 'post_status'=>'publish', 'posts_per_page'=>3,
        'fields'=>'ids', 'orderby'=>'ID', 'order'=>'DESC', 'no_found_rows'=>true,
        'tax_query'=>[['taxonomy'=>'evazar_category','field'=>'term_id','terms'=>[absint($term_id)],'include_children'=>false]],
    ]);
    $samples = []; $seen = [];
    foreach ((array)$posts as $post_id) {
        $ident = evazar_csmr_get_dkp_for_post($post_id);
        if (!empty($ident['conflict'])) return new WP_Error('csmr_product_dkp_conflict', 'متادیتای شناسهٔ دیجی‌کالا در یکی از محصولات نمونه متعارض است.');
        $dkp = (string)($ident['dkp'] ?? '');
        if ($dkp === '' || isset($seen[$dkp])) continue;
        $samples[] = ['post_id'=>absint($post_id), 'dkp'=>$dkp];
        $seen[$dkp] = true;
        if (count($samples) >= 2) break;
    }
    return $samples;
}

function evazar_csmr_fetch_product($dkp) {
    $dkp = trim((string)$dkp);
    if (!ctype_digit($dkp) || (int)$dkp <= 0) return new WP_Error('csmr_invalid_dkp', 'شناسهٔ نمونهٔ محصول معتبر نیست.');
    if (!function_exists('evazar_fetch_raw_product_data')) return new WP_Error('csmr_core_fetch_missing', 'تابع دریافت زندهٔ محصول در Core پیدا نشد.');
    $fresh = evazar_fetch_raw_product_data($dkp, true, false, 'category_metadata_repair');
    if (!is_array($fresh) || empty($fresh['breadcrumbs']) || !is_array($fresh['breadcrumbs'])) {
        $diag = $GLOBALS['evazar_last_product_fetch_diagnostic'] ?? [];
        $detail = trim((string)($diag['detail'] ?? ''));
        return new WP_Error('csmr_source_fetch_failed', 'بردکرامب معتبر از Worker دریافت نشد.' . ($detail !== '' ? ' ' . sanitize_text_field($detail) : ''));
    }
    return $fresh;
}

function evazar_csmr_term_chain($term_id) {
    $term = get_term(absint($term_id), 'evazar_category');
    if (!$term || is_wp_error($term) || empty($term->term_id)) return new WP_Error('csmr_term_missing', 'دسته‌بندی پیدا نشد.');
    $chain = []; $cursor = $term; $guard = 0;
    while ($cursor && !is_wp_error($cursor) && !empty($cursor->term_id) && $guard++ < 30) {
        $kind = (string)get_term_meta((int)$cursor->term_id, '_evazar_dk_source_kind', true);
        if ($kind === 'derived_brand_landing') return new WP_Error('csmr_derived_category', 'این مورد یک لندینگ مشتق‌شدهٔ دسته+برند است، نه دستهٔ مستقل مبدأ؛ ترمیم متادیتای بردکرامب برای آن مناسب نیست.');
        $chain[] = ['term_id'=>(int)$cursor->term_id, 'name'=>(string)$cursor->name];
        $parent = absint($cursor->parent ?? 0);
        $cursor = $parent ? get_term($parent, 'evazar_category') : null;
    }
    if ($guard >= 30) return new WP_Error('csmr_hierarchy_loop', 'ساختار والدهای دسته‌بندی نامعتبر یا حلقه‌ای است.');
    return array_reverse($chain);
}

/** Match the term and its full WordPress ancestor chain against a contiguous source breadcrumb chain. */
function evazar_csmr_match_breadcrumbs($term_id, $breadcrumbs) {
    $chain = evazar_csmr_term_chain($term_id);
    if (is_wp_error($chain)) return $chain;
    if (is_string($breadcrumbs)) $breadcrumbs = json_decode($breadcrumbs, true);
    if (!is_array($breadcrumbs) || !$breadcrumbs) return new WP_Error('csmr_breadcrumbs_missing', 'بردکرامب مبدأ خالی یا نامعتبر است.');
    $crumbs = [];
    foreach ($breadcrumbs as $crumb) {
        if (!is_array($crumb)) continue;
        $title = trim((string)($crumb['title'] ?? $crumb['name'] ?? $crumb['title_fa'] ?? ''));
        $raw = $crumb['url']['uri'] ?? ($crumb['url'] ?? '');
        if (is_array($raw)) $raw = $raw['uri'] ?? '';
        if ($title === '' || in_array($title, ['دیجی‌کالا', 'دیجیکالا'], true) || stripos($title, 'dkp-') === 0) continue;
        if (is_string($raw) && strpos($raw, '/product/') !== false) continue;
        $path = evazar_csmr_normalize_category_path((string)$raw);
        $crumbs[] = ['title'=>$title, 'norm'=>evazar_csmr_normalize_identity($title), 'path'=>$path];
    }
    if (count($crumbs) < count($chain)) return new WP_Error('csmr_breadcrumbs_incomplete', 'بردکرامب زنده برای تمام والدهای این دسته مسیر کامل ندارد.');

    $matches = [];
    $chain_count = count($chain);
    for ($end = $chain_count - 1; $end < count($crumbs); $end++) {
        $start = $end - $chain_count + 1;
        $ok = true; $matched = [];
        foreach ($chain as $i=>$node) {
            $crumb = $crumbs[$start + $i] ?? null;
            if (!$crumb || $crumb['norm'] !== evazar_csmr_normalize_identity($node['name']) || $crumb['path'] === '') { $ok = false; break; }
            $stored_verified = (string)get_term_meta($node['term_id'], '_evazar_dk_source_verified', true) === '1';
            $stored_path = evazar_csmr_normalize_category_path((string)get_term_meta($node['term_id'], '_evazar_dk_url', true));
            if ($stored_verified && $stored_path !== '' && $stored_path !== $crumb['path']) {
                return new WP_Error('csmr_verified_ancestor_conflict', 'مسیر مبدأ تأییدشدهٔ یکی از والدهای این دسته با بردکرامب زنده تعارض دارد.');
            }
            $matched[] = ['term_id'=>(int)$node['term_id'], 'name'=>(string)$node['name'], 'path'=>$crumb['path']];
        }
        if ($ok) $matches[] = $matched;
    }
    if (!$matches) return new WP_Error('csmr_hierarchy_mismatch', 'نام دسته و زنجیرهٔ والدهای وردپرس با بردکرامب زنده تطبیق کامل ندارند.');
    $unique = [];
    foreach ($matches as $match) $unique[wp_json_encode(array_column($match, 'path'))] = $match;
    if (count($unique) > 1) return new WP_Error('csmr_multiple_source_paths', 'برای همین ساختار دسته بیش از یک مسیر مبدأ محتمل پیدا شد؛ بررسی دستی لازم است.');
    return array_values($unique)[0];
}

function evazar_csmr_snapshot($term_id, $term = null) {
    $term_id = absint($term_id);
    $term = $term ?: get_term($term_id, 'evazar_category');
    if (!$term || is_wp_error($term)) return false;
    $keys = ['_evazar_dk_url','_evazar_dk_slug','_evazar_dk_source_verified','_evazar_dk_source_map_version','_evazar_dk_source_kind','_evazar_dk_generated_url'];
    $meta = [];
    foreach ($keys as $key) $meta[$key] = (string)get_term_meta($term_id, $key, true);
    return ['term_id'=>$term_id,'name'=>(string)$term->name,'slug'=>(string)$term->slug,'parent'=>absint($term->parent ?? 0),'meta'=>$meta];
}

function evazar_csmr_source_path_owner_conflict($term_id, $path) {
    // Compare normalized values rather than a raw SQL equality lookup: older rows may store the
    // full Digikala URL while current Core stores only the relative path.
    $terms = get_terms(['taxonomy'=>'evazar_category','hide_empty'=>false,'number'=>0]);
    if (is_wp_error($terms)) return new WP_Error('csmr_owner_lookup_failed', 'بررسی مالک مسیر مبدأ در دسته‌بندی‌ها ناموفق بود.');
    foreach ((array)$terms as $owner) {
        if (!is_object($owner) || empty($owner->term_id) || (int)$owner->term_id === absint($term_id)) continue;
        if ((string)get_term_meta((int)$owner->term_id, '_evazar_dk_source_kind', true) === 'derived_brand_landing') continue;
        $owned_path = evazar_csmr_normalize_category_path((string)get_term_meta((int)$owner->term_id, '_evazar_dk_url', true));
        if ($owned_path !== '' && $owned_path === $path) {
            return new WP_Error('csmr_source_path_owned', 'این مسیر مبدأ از قبل در ترم دسته‌بندی دیگری ثبت شده است؛ هیچ متادیتایی تغییر نکرد.');
        }
    }
    return true;
}

function evazar_csmr_candidate_key($term_id) { return 'evazar_csmr_' . absint(get_current_user_id()) . '_' . absint($term_id); }

function evazar_csmr_analyze_term($term_id) {
    $term_id = absint($term_id); $term = get_term($term_id, 'evazar_category');
    if (!$term || is_wp_error($term)) return ['term_id'=>$term_id,'status'=>'TERM_MISSING','reason'=>'دسته‌بندی پیدا نشد.'];
    $state = evazar_csmr_metadata_state($term_id);
    if ($state['kind'] === 'derived_brand_landing') return ['term_id'=>$term_id,'name'=>$term->name,'slug'=>$term->slug,'status'=>'DERIVED_LANDING','reason'=>'لندینگ مشتق‌شده است و نباید به‌عنوان دستهٔ مستقل مبدأ علامت‌گذاری شود.'];
    if ($state['complete']) return ['term_id'=>$term_id,'name'=>$term->name,'slug'=>$term->slug,'status'=>'ALREADY_VERIFIED','reason'=>'متادیتای مسیر مبدأ از قبل کامل و تأییدشده است.'];
    if ($state['verified'] && $state['path'] !== '') return ['term_id'=>$term_id,'name'=>$term->name,'slug'=>$term->slug,'status'=>'VERIFIED_METADATA_CONFLICT','reason'=>'متادیتای فعلی دارای نشانگر تأیید است اما قالب/نسخهٔ آن قابل اعتماد نیست؛ بازنویسی خودکار ممنوع است.'];
    $samples = evazar_csmr_get_sample_products($term_id);
    if (is_wp_error($samples)) return ['term_id'=>$term_id,'name'=>$term->name,'slug'=>$term->slug,'status'=>'SAMPLE_DKP_CONFLICT','reason'=>$samples->get_error_message()];
    if (!$samples) return ['term_id'=>$term_id,'name'=>$term->name,'slug'=>$term->slug,'status'=>'NO_SAMPLE','reason'=>'محصول منتشرشدهٔ قابل بررسی با شناسهٔ DKP به این دسته متصل نیست.'];

    $matched_samples = [];
    foreach ($samples as $sample) {
        $live = evazar_csmr_fetch_product($sample['dkp']);
        if (is_wp_error($live)) return ['term_id'=>$term_id,'name'=>$term->name,'slug'=>$term->slug,'status'=>'LIVE_FETCH_FAILED','reason'=>$live->get_error_message()];
        $identity = evazar_csmr_match_breadcrumbs($term_id, $live['breadcrumbs']);
        if (is_wp_error($identity)) return ['term_id'=>$term_id,'name'=>$term->name,'slug'=>$term->slug,'status'=>strtoupper($identity->get_error_code()),'reason'=>$identity->get_error_message()];
        $matched_samples[] = ['post_id'=>$sample['post_id'],'dkp'=>$sample['dkp'],'chain'=>$identity];
    }
    $first = $matched_samples[0]['chain'];
    foreach (array_slice($matched_samples, 1) as $sample) {
        if (wp_json_encode(array_column($first,'path')) !== wp_json_encode(array_column($sample['chain'],'path'))) {
            return ['term_id'=>$term_id,'name'=>$term->name,'slug'=>$term->slug,'status'=>'SAMPLE_DISAGREEMENT','reason'=>'دو محصول مستقل مسیر یا زنجیرهٔ دسته‌بندی متفاوتی گزارش کردند؛ متادیتا ثبت نشد.'];
        }
    }
    $target = end($first); $target_path = (string)$target['path'];
    $existing_path = $state['path'];
    if ($state['verified'] && $existing_path !== '' && $existing_path !== $target_path) {
        return ['term_id'=>$term_id,'name'=>$term->name,'slug'=>$term->slug,'status'=>'VERIFIED_SOURCE_CONFLICT','reason'=>'مسیر تأییدشدهٔ ذخیره‌شده با مبدأ زنده متفاوت است؛ بررسی دستی لازم است.'];
    }
    $owner = evazar_csmr_source_path_owner_conflict($term_id, $target_path);
    if (is_wp_error($owner)) return ['term_id'=>$term_id,'name'=>$term->name,'slug'=>$term->slug,'status'=>strtoupper($owner->get_error_code()),'reason'=>$owner->get_error_message()];

    $path_slug = basename(rtrim($target_path, '/'));
    $stored_matches = $existing_path !== '' && $existing_path === $target_path;
    $public_slug_matches = sanitize_title((string)$term->slug) === sanitize_title($path_slug)
        || (function_exists('evazar_digikala_category_slug_from_path') && sanitize_title((string)$term->slug) === sanitize_title(evazar_digikala_category_slug_from_path($target_path)));
    if (count($matched_samples) < 2 && !$stored_matches && !$public_slug_matches) {
        return ['term_id'=>$term_id,'name'=>$term->name,'slug'=>$term->slug,'status'=>'NEEDS_SECOND_SAMPLE','reason'=>'فقط یک محصول هویت را تأیید کرد و نامک عمومی نیز با مسیر مبدأ تطبیق ندارد؛ برای ثبت امن به نمونهٔ دوم نیاز است.'];
    }
    $candidate = [
        'user_id'=>get_current_user_id(),'term_id'=>$term_id,'snapshot'=>evazar_csmr_snapshot($term_id,$term),
        'target_path'=>$target_path,'chain'=>$first,'samples'=>array_map(static function($s){return ['post_id'=>(int)$s['post_id'],'dkp'=>(string)$s['dkp']];},$matched_samples),
        'created_at'=>time(),
    ];
    set_transient(evazar_csmr_candidate_key($term_id), $candidate, 2 * HOUR_IN_SECONDS);
    return ['term_id'=>$term_id,'name'=>$term->name,'slug'=>$term->slug,'status'=>'READY','reason'=>count($matched_samples) >= 2 ? 'دو محصول مستقل، نام دسته و مسیر کامل مبدأ را تأیید کردند.' : 'مسیر ذخیره‌شده یا نامک فعلی با مبدأ مطابقت دارد و ساختار والدها هم تأیید شد.','source_url'=>$target_path,'samples'=>count($matched_samples)];
}

function evazar_csmr_ajax_list_candidates() {
    evazar_csmr_check_access();
    if (!taxonomy_exists('evazar_category')) wp_send_json_error(['message'=>'تاکسونومی دسته‌بندی در دسترس نیست.'], 409);
    $terms = get_terms(['taxonomy'=>'evazar_category','hide_empty'=>false,'number'=>0,'orderby'=>'term_id','order'=>'ASC']);
    if (is_wp_error($terms)) wp_send_json_error(['message'=>'خواندن فهرست دسته‌بندی‌ها ناموفق بود.'], 500);
    $rows=[];
    foreach ((array)$terms as $term) {
        if (!is_object($term) || empty($term->term_id)) continue;
        $state=evazar_csmr_metadata_state((int)$term->term_id);
        if ($state['complete'] || $state['kind']==='derived_brand_landing') continue;
        $parent = absint($term->parent ?? 0); $parent_term = $parent ? get_term($parent,'evazar_category') : null;
        $rows[]=['term_id'=>(int)$term->term_id,'name'=>(string)$term->name,'slug'=>(string)$term->slug,'parent_id'=>$parent,'parent_name'=>($parent_term && !is_wp_error($parent_term))?(string)$parent_term->name:'','product_count'=>(int)($term->count ?? 0),'source_url'=>$state['url'],'verified'=>$state['verified']?'1':'0','version'=>$state['version']];
    }
    wp_send_json_success(['total'=>count($rows),'rows'=>$rows,'message'=>'فقط دسته‌های فاقد متادیتای کامل و معتبر فهرست شدند؛ لندینگ‌های مشتق‌شده کنار گذاشته شدند.']);
}

function evazar_csmr_ajax_analyze_batch() {
    evazar_csmr_check_access();
    $ids=json_decode((string)wp_unslash($_POST['term_ids'] ?? ''),true);
    if (!is_array($ids) || !$ids || count($ids)>10) wp_send_json_error(['message'=>'در هر مرحله ۱ تا ۱۰ دسته را برای بررسی انتخاب کن.'],400);
    $ids=array_values(array_unique(array_filter(array_map('absint',$ids)))); $results=[];
    foreach ($ids as $id) $results[]=evazar_csmr_analyze_term($id);
    wp_send_json_success(['results'=>$results]);
}

function evazar_csmr_apply_candidate($term_id) {
    $term_id=absint($term_id); $candidate=get_transient(evazar_csmr_candidate_key($term_id));
    if (!is_array($candidate) || (int)($candidate['user_id'] ?? 0)!==(int)get_current_user_id() || (int)($candidate['term_id'] ?? 0)!==$term_id) return ['term_id'=>$term_id,'status'=>'SKIPPED','reason'=>'گزارش معتبر و تازه‌ای برای این دسته وجود ندارد؛ دوباره بررسی کن.'];
    $term=get_term($term_id,'evazar_category');
    if (!$term || is_wp_error($term)) return ['term_id'=>$term_id,'status'=>'SKIPPED','reason'=>'دسته از زمان بررسی حذف شده است.'];
    $snapshot=$candidate['snapshot'] ?? [];
    if (evazar_csmr_snapshot($term_id,$term) !== $snapshot) return ['term_id'=>$term_id,'status'=>'SKIPPED','reason'=>'نام، نامک، والد یا متادیتای دسته از زمان بررسی تغییر کرده است.'];
    $verified_samples=[];
    foreach ((array)($candidate['samples'] ?? []) as $sample) {
        $post_id=absint($sample['post_id'] ?? 0); $dkp=(string)($sample['dkp'] ?? '');
        if (!$post_id || !ctype_digit($dkp)) return ['term_id'=>$term_id,'status'=>'SKIPPED','reason'=>'مشخصات نمونه معتبر نیست.'];
        $post=get_post($post_id);
        if (!$post || $post->post_type!=='evazar_product' || $post->post_status!=='publish') return ['term_id'=>$term_id,'status'=>'SKIPPED','reason'=>'محصول نمونه از زمان بررسی تغییر کرده است.'];
        $assigned=wp_get_object_terms($post_id,'evazar_category',['fields'=>'ids']);
        if (is_wp_error($assigned) || !in_array($term_id,array_map('absint',(array)$assigned),true)) return ['term_id'=>$term_id,'status'=>'SKIPPED','reason'=>'محصول نمونه دیگر به این دسته متصل نیست.'];
        $fresh_id=evazar_csmr_get_dkp_for_post($post_id);
        if (!empty($fresh_id['conflict']) || (string)($fresh_id['dkp'] ?? '')!==$dkp) return ['term_id'=>$term_id,'status'=>'SKIPPED','reason'=>'شناسهٔ مبدأ محصول نمونه تغییر کرده یا متعارض شده است.'];
        $live=evazar_csmr_fetch_product($dkp);
        if (is_wp_error($live)) return ['term_id'=>$term_id,'status'=>'LIVE_RECHECK_FAILED','reason'=>'بررسی مجدد مبدأ هنگام ثبت ناموفق بود؛ متادیتا نوشته نشد. '.$live->get_error_message()];
        $identity=evazar_csmr_match_breadcrumbs($term_id,$live['breadcrumbs']);
        if (is_wp_error($identity) || wp_json_encode(array_column($identity,'path'))!==wp_json_encode(array_column($candidate['chain'] ?? [],'path'))) {
            return ['term_id'=>$term_id,'status'=>'SOURCE_CHANGED_AFTER_REVIEW','reason'=>'هویت یا زنجیرهٔ مبدأ پس از بررسی تغییر کرده؛ برای جلوگیری از ثبت اطلاعات قدیمی، عملیات متوقف شد.'];
        }
        $verified_samples[]=$identity;
    }
    if (!$verified_samples) return ['term_id'=>$term_id,'status'=>'SKIPPED','reason'=>'نمونهٔ زنده‌ای برای تأیید هنگام ثبت وجود ندارد.'];
    $target_path=(string)($candidate['target_path'] ?? '');
    $first_live_chain = $verified_samples[0];
    $first_live_target = end($first_live_chain);
    if ($target_path==='' || !is_array($first_live_target) || (string)($first_live_target['path'] ?? '')!==$target_path) return ['term_id'=>$term_id,'status'=>'SOURCE_CHANGED_AFTER_REVIEW','reason'=>'مسیر هدف با نمونهٔ زنده یکسان نیست.'];
    $owner=evazar_csmr_source_path_owner_conflict($term_id,$target_path);
    if (is_wp_error($owner)) return ['term_id'=>$term_id,'status'=>'SKIPPED','reason'=>$owner->get_error_message()];
    if (!function_exists('evazar_persist_category_source_metadata')) return ['term_id'=>$term_id,'status'=>'SKIPPED','reason'=>'تابع ذخیرهٔ امن متادیتای دسته در Core موجود نیست.'];
    $before=['name'=>(string)$term->name,'slug'=>(string)$term->slug,'parent'=>absint($term->parent ?? 0)];
    $saved=evazar_persist_category_source_metadata($term_id,$target_path,'digikala_breadcrumb');
    if (is_wp_error($saved) || $saved!==true) {
        update_term_meta($term_id,'_evazar_dk_source_verified','0');
        return ['term_id'=>$term_id,'status'=>'WRITE_FAILED','reason'=>is_wp_error($saved)?$saved->get_error_message():'ذخیرهٔ امن متادیتا تأیید نشد.'];
    }
    // Distinguish source repaired by a fresh live review while preserving the source metadata tuple.
    update_term_meta($term_id,'_evazar_dk_source_map_version','2.9.84.29-live-category-metadata-repair');
    if ((string)get_term_meta($term_id,'_evazar_dk_source_map_version',true)!=='2.9.84.29-live-category-metadata-repair') {
        update_term_meta($term_id,'_evazar_dk_source_verified','0');
        return ['term_id'=>$term_id,'status'=>'WRITE_FAILED','reason'=>'نسخهٔ منشأ ترمیم‌شده ذخیره نشد؛ دسته verified باقی نماند.'];
    }
    update_term_meta($term_id,'_evazar_dk_source_verified','1');
    $saved_term=get_term($term_id,'evazar_category');
    if ((string)get_term_meta($term_id,'_evazar_dk_source_verified',true)!=='1' || !$saved_term || is_wp_error($saved_term)
        || (string)$saved_term->name!==$before['name'] || (string)$saved_term->slug!==$before['slug'] || absint($saved_term->parent ?? 0)!==$before['parent']
        || evazar_csmr_normalize_category_path((string)get_term_meta($term_id,'_evazar_dk_url',true))!==$target_path) {
        update_term_meta($term_id,'_evazar_dk_source_verified','0');
        return ['term_id'=>$term_id,'status'=>'WRITE_FAILED','reason'=>'بازخوانی نهایی متادیتا/ترم تأیید نشد؛ علامت verified لغو شد.'];
    }
    delete_transient(evazar_csmr_candidate_key($term_id));
    return ['term_id'=>$term_id,'status'=>'SAVED','reason'=>'متادیتای مسیر مبدأ با دو نمونهٔ زنده (یا مسیر دقیق قبلی) ثبت شد؛ نام، نامک، والد و تخصیص محصولات تغییر نکردند.'];
}

function evazar_csmr_ajax_apply_batch() {
    evazar_csmr_check_access();
    $ids=json_decode((string)wp_unslash($_POST['term_ids'] ?? ''),true);
    if (!is_array($ids) || !$ids || count($ids)>10) wp_send_json_error(['message'=>'در هر مرحله ۱ تا ۱۰ دستهٔ آماده‌ثبت انتخاب کن.'],400);
    $ids=array_values(array_unique(array_filter(array_map('absint',$ids)))); $results=[];
    foreach ($ids as $id) $results[]=evazar_csmr_apply_candidate($id);
    wp_send_json_success(['results'=>$results]);
}

function evazar_csmr_render_page() {
    if (!current_user_can('manage_options')) return;
    $nonce=wp_create_nonce('evazar_csmr_nonce');
    ?>
    <div class="wrap" dir="rtl" style="max-width:1350px">
      <h1>بررسی و ترمیم متادیتای مبدأ دسته‌ها</h1>
      <p>این ابزار URL کامل هر دسته را با بردکرامب زندهٔ محصولات متصل و زنجیرهٔ والدهای وردپرس تطبیق می‌دهد. فقط متادیتای هویت مبدأ نوشته می‌شود.</p>
      <p><strong>ایمنی:</strong> قبل از تحلیل یا ثبت، صف واردات باید متوقف و تعداد <code>processing</code> صفر باشد. نام، نامک، والد دسته، تخصیص محصولات، ریدایرکت، کش و Worker تغییر نمی‌کنند. لندینگ‌های مشتق‌شدهٔ دسته+برند از این ابزار کنار گذاشته می‌شوند.</p>
      <p><button class="button button-primary" id="evazar-csmr-load">۱. فهرست دسته‌های ناقص</button> <button class="button" id="evazar-csmr-analyze" disabled>۲. بررسی زندهٔ انتخاب‌شده‌ها (حداکثر ۱۰)</button> <button class="button button-primary" id="evazar-csmr-apply" disabled>۳. ثبت موارد آماده (حداکثر ۱۰)</button></p>
      <p id="evazar-csmr-status" role="status">هنوز بررسی شروع نشده است.</p>
      <table class="widefat striped" style="margin-top:14px"><thead><tr><th><input type="checkbox" id="evazar-csmr-all" aria-label="انتخاب همه"></th><th>شناسه</th><th>دسته</th><th>نامک سایت</th><th>والد</th><th>متادیتای فعلی</th><th>وضعیت</th><th>توضیح</th></tr></thead><tbody id="evazar-csmr-rows"><tr><td colspan="8">ابتدا فهرست را بارگذاری کن.</td></tr></tbody></table>
    </div>
    <script>
    (function(){
      const nonce=<?php echo wp_json_encode($nonce); ?>; const $=id=>document.getElementById(id); const rows=new Map();
      const labels={READY:'آماده ثبت امن',ALREADY_VERIFIED:'از قبل تأیید شده',DERIVED_LANDING:'لندینگ مشتق‌شده',NO_SAMPLE:'نمونه محصول ندارد',SAMPLE_DKP_CONFLICT:'تعارض شناسه محصول',NEEDS_SECOND_SAMPLE:'نیازمند نمونه دوم',SAMPLE_DISAGREEMENT:'تعارض نمونه‌ها',LIVE_FETCH_FAILED:'خطای دریافت مبدأ',VERIFIED_SOURCE_CONFLICT:'تعارض متادیتای تأییدشده',VERIFIED_METADATA_CONFLICT:'متادیتای قدیمی نیازمند بررسی',CSMR_VERIFIED_ANCESTOR_CONFLICT:'تعارض والد تأییدشده',CSMR_HIERARCHY_MISMATCH:'تعارض سلسله‌مراتب',CSMR_SOURCE_PATH_OWNED:'مسیر متعلق به دسته دیگر',SOURCE_CHANGED_AFTER_REVIEW:'مبدأ پس از بررسی تغییر کرده',LIVE_RECHECK_FAILED:'خطای بررسی مجدد',WRITE_FAILED:'خطای ذخیره',SAVED:'ثبت شد',SKIPPED:'رد شد',TERM_MISSING:'دسته پیدا نشد'};
      function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
      function selected(){return [...document.querySelectorAll('.evazar-csmr-select:checked')].map(x=>Number(x.value)).filter(Boolean);}
      function statusLabel(s){return labels[s]||s||'—';}
      function draw(){const body=$('evazar-csmr-rows');if(!rows.size){body.innerHTML='<tr><td colspan="8">موردی برای نمایش نیست.</td></tr>';return;}body.innerHTML=[...rows.values()].map(r=>`<tr><td><input class="evazar-csmr-select" type="checkbox" value="${r.term_id}" ${r.status==='READY'?'checked':''}></td><td>${r.term_id}</td><td>${esc(r.name)}</td><td><code>${esc(r.slug)}</code></td><td>${esc(r.parent_name||'—')}</td><td><code>${esc(r.source_url||'—')}</code></td><td>${esc(statusLabel(r.status))}</td><td>${esc(r.reason||'')}</td></tr>`).join('');}
      async function call(action,data={}){const fd=new FormData();fd.append('action',action);fd.append('nonce',nonce);Object.keys(data).forEach(k=>fd.append(k,typeof data[k]==='string'?data[k]:JSON.stringify(data[k])));const resp=await fetch(ajaxurl,{method:'POST',credentials:'same-origin',body:fd});const json=await resp.json();if(!resp.ok||!json.success)throw new Error(json?.data?.message||('HTTP '+resp.status));return json.data;}
      $('evazar-csmr-load').onclick=async()=>{try{$('evazar-csmr-status').textContent='در حال خواندن دسته‌های ناقص...';const d=await call('evazar_csmr_list_candidates');rows.clear();for(const r of d.rows){r.status='';r.reason='برای تحلیل انتخاب کن.';rows.set(r.term_id,r);}draw();$('evazar-csmr-status').textContent=`${d.total} دسته نیازمند بررسی اولیه است. ${d.message}`;$('evazar-csmr-analyze').disabled=!rows.size;$('evazar-csmr-apply').disabled=true;}catch(e){$('evazar-csmr-status').textContent=e.message;}};
      $('evazar-csmr-all').onchange=e=>document.querySelectorAll('.evazar-csmr-select').forEach(x=>x.checked=e.target.checked);
      $('evazar-csmr-analyze').onclick=async()=>{const ids=selected();if(!ids.length||ids.length>10){$('evazar-csmr-status').textContent='بین ۱ تا ۱۰ دسته را انتخاب کن.';return;}try{$('evazar-csmr-analyze').disabled=true;for(let i=0;i<ids.length;i++){const d=await call('evazar_csmr_analyze_batch',{term_ids:[ids[i]]});const r=d.results?.[0];if(r)rows.set(Number(r.term_id),Object.assign(rows.get(Number(r.term_id))||{},r));draw();$('evazar-csmr-status').textContent=`بررسی ${i+1} از ${ids.length}: ${r?.name||ids[i]} — ${statusLabel(r?.status)}`;} $('evazar-csmr-apply').disabled=![...rows.values()].some(r=>r.status==='READY');}catch(e){$('evazar-csmr-status').textContent=e.message;}finally{$('evazar-csmr-analyze').disabled=false;}};
      $('evazar-csmr-apply').onclick=async()=>{const ids=selected().filter(id=>rows.get(id)?.status==='READY');if(!ids.length||ids.length>10){$('evazar-csmr-status').textContent='۱ تا ۱۰ ردیف دارای وضعیت «آماده ثبت امن» را انتخاب کن.';return;}if(!confirm(`متادیتای مبدأ ${ids.length} دسته ثبت شود؟ نامک و محصولات تغییر نمی‌کنند.`))return;try{$('evazar-csmr-apply').disabled=true;const d=await call('evazar_csmr_apply_batch',{term_ids:ids});for(const r of d.results||[])rows.set(Number(r.term_id),Object.assign(rows.get(Number(r.term_id))||{},r));draw();$('evazar-csmr-status').textContent=(d.results||[]).map(r=>`${r.term_id}: ${statusLabel(r.status)} — ${r.reason}`).join(' | ');}catch(e){$('evazar-csmr-status').textContent=e.message;}finally{$('evazar-csmr-apply').disabled=false;}};
    })();
    </script>
    <?php
}
