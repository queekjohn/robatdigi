# Safe upgrade — EVazar Core 2.9.84.30 / Worker 1.13.19

1. Back up the current Core plugin and database.
2. Deploy Worker 1.13.19 to all active URLs in `evazar_cf_worker_urls` and `evazar_cf_worker_url` before upgrading Core. Preserve `EVAZAR_INTERNAL_TOKEN`, existing secrets, routes, and bindings.
3. Verify each deployed primary Worker responds with `X-Evazar-Worker-Version: 1.13.19`. The new authenticated audit endpoint is `POST /brand-audit/product` and requires the same `EVAZAR_INTERNAL_TOKEN` value via `X-Evazar-Internal-Token`.
4. Upgrade the WordPress plugin to Core 2.9.84.30. The embedded Worker now matches the standalone Worker 1.13.19 source exactly; installing Core does not deploy Cloudflare changes automatically.
5. For category metadata repair, pause the import queue and confirm `processing = 0` before running the tool. Apply only rows explicitly marked READY after reviewing the preview.
6. This package does not change cache configuration or purge behavior. Do not edit `.htaccess` as part of this upgrade.
