<?php
/**
 * Disambiguated admin brand selector for EVazar.
 * Brand choices are identified and saved by term ID; labels include the public slug.
 * This module does not change brand slugs, import logic, redirect mappings, cache code, or Workers.
 */
if (!defined('ABSPATH')) {
    exit;
}

add_filter('quick_edit_show_taxonomy', 'evazar_brand_selector_hide_native_flat_brand_field', 10, 3);
add_action('add_meta_boxes_evazar_product', 'evazar_brand_selector_register_product_metabox', 100, 1);
add_action('quick_edit_custom_box', 'evazar_brand_selector_quick_edit_box', 20, 3);
add_action('bulk_edit_custom_box', 'evazar_brand_selector_bulk_edit_box', 20, 2);
add_action('save_post_evazar_product', 'evazar_brand_selector_save_product_terms', 99, 3);
// Reconcile custom picker fields after WordPress has finished the full classic/inline save flow.
if (!function_exists('is_admin') || is_admin()) {
    add_action('shutdown', 'evazar_brand_selector_finalize_posted_assignment', 99);
}
// Reconcile Gutenberg REST taxonomy updates after the REST controller handles normal terms.
add_action('rest_after_insert_evazar_product', 'evazar_brand_selector_reconcile_rest_assignment', 99, 3);
// Native WP bulk editing can skip save_post when no standard post fields changed.
// Finalize the chosen taxonomy assignments from WordPress' bulk_edit_posts payload instead.
add_action('bulk_edit_posts', 'evazar_brand_selector_finalize_bulk_edit', 20, 2);
add_action('wp_ajax_evazar_brand_selector_search', 'evazar_brand_selector_ajax_search');
add_action('admin_enqueue_scripts', 'evazar_brand_selector_enqueue_admin_assets');
add_action('enqueue_block_editor_assets', 'evazar_brand_selector_enqueue_block_editor_assets');

/** The default WordPress tag box saves flat taxonomy terms by name, which is ambiguous for duplicate names. */
function evazar_brand_selector_hide_native_flat_brand_field($show, $taxonomy, $post_type) {
    if ($taxonomy === 'evazar_brand' && $post_type === 'evazar_product') {
        return false;
    }
    return $show;
}

function evazar_brand_selector_is_block_editor($post) {
    return function_exists('use_block_editor_for_post') && $post && use_block_editor_for_post($post);
}

function evazar_brand_selector_register_product_metabox($post) {
    // Gutenberg has its own selector below; the legacy taxonomy meta box is removed on both editors.
    remove_meta_box('tagsdiv-evazar_brand', 'evazar_product', 'side');
    if (evazar_brand_selector_is_block_editor($post)) {
        return;
    }
    add_meta_box(
        'evazar-brand-selector',
        'برند کالا (نام و نامک)',
        'evazar_brand_selector_render_product_metabox',
        'evazar_product',
        'side',
        'default'
    );
}

function evazar_brand_selector_render_product_metabox($post) {
    if (!current_user_can('edit_post', $post->ID) || !current_user_can(get_taxonomy('evazar_brand')->cap->assign_terms)) {
        echo '<p>دسترسی انتخاب برند برای این کالا وجود ندارد.</p>';
        return;
    }
    wp_nonce_field('evazar_brand_selector_save', 'evazar_brand_selector_nonce');
    echo '<input type="hidden" name="evazar_brand_selector_present" value="1" />';
    $terms = wp_get_object_terms($post->ID, 'evazar_brand', ['fields' => 'all']);
    $term_ids = [];
    if (!is_wp_error($terms) && is_array($terms)) {
        foreach ($terms as $term) {
            $term_ids[] = (int) $term->term_id;
        }
    }
    evazar_brand_selector_render_widget([
        'mode' => 'replace',
        'input_name' => 'evazar_brand_term_ids[]',
        'term_ids' => $term_ids,
        'title' => 'جست‌وجو و انتخاب برند',
        'help' => 'جست‌وجو با نام فارسی یا نامک انگلیسی ممکن است. نامک و شناسه زیر نام هر نتیجه نمایش داده می‌شود. ذخیره، فهرست برندهای این کالا را دقیقاً با انتخاب‌های بالا جایگزین می‌کند.',
    ]);
}

function evazar_brand_selector_quick_edit_box($column_name, $post_type, $taxonomy = '') {
    if ($post_type !== 'evazar_product' || $column_name !== 'taxonomy-evazar_brand') {
        return;
    }
    if (!current_user_can('edit_posts') || !current_user_can(get_taxonomy('evazar_brand')->cap->assign_terms)) {
        return;
    }
    echo '<fieldset class="inline-edit-col-right evazar-brand-inline-field"><div class="inline-edit-col">';
    evazar_brand_selector_render_widget([
        'mode' => 'append',
        'input_name' => 'evazar_quick_brand_term_ids[]',
        'title' => 'افزودن برند (با نامک انگلیسی)',
        'help' => 'برند انتخاب‌شده به برندهای فعلی کالا اضافه می‌شود؛ برندهای قبلی حذف نمی‌شوند.',
    ]);
    echo '</div></fieldset>';
}

function evazar_brand_selector_bulk_edit_box($column_name, $post_type) {
    if ($post_type !== 'evazar_product' || $column_name !== 'taxonomy-evazar_brand') {
        return;
    }
    if (!current_user_can('edit_posts') || !current_user_can(get_taxonomy('evazar_brand')->cap->assign_terms)) {
        return;
    }
    echo '<fieldset class="inline-edit-col-right evazar-brand-inline-field"><div class="inline-edit-col">';
    // Replacement mode does not add the widget's append-mode nonce, so include one explicitly here.
    echo '<input type="hidden" name="evazar_brand_selector_nonce" value="' . esc_attr(wp_create_nonce('evazar_brand_selector_save')) . '" />';
    evazar_brand_selector_render_widget([
        'mode' => 'replace',
        'input_name' => 'evazar_bulk_brand_term_ids[]',
        'title' => 'جایگزینی برند کالاهای انتخاب‌شده',
        'help' => 'وقتی یک یا چند برند انتخاب کنی، برندهای فعلی کالاهای انتخاب‌شده دقیقاً با همین انتخاب‌ها جایگزین می‌شوند. اگر هیچ برندی انتخاب نکنی، برندهای فعلی بدون تغییر می‌مانند.',
    ]);
    echo '</div></fieldset>';
}

function evazar_brand_selector_render_widget($args) {
    $mode = isset($args['mode']) && $args['mode'] === 'replace' ? 'replace' : 'append';
    $input_name = isset($args['input_name']) ? (string) $args['input_name'] : 'evazar_brand_term_ids[]';
    $term_ids = isset($args['term_ids']) ? evazar_brand_selector_validate_term_ids($args['term_ids']) : [];
    $title = isset($args['title']) ? (string) $args['title'] : 'انتخاب برند';
    $help = isset($args['help']) ? (string) $args['help'] : '';

    echo '<div class="evazar-brand-picker" data-mode="' . esc_attr($mode) . '" data-input-name="' . esc_attr($input_name) . '">';
    if ($mode === 'append') {
        echo '<input type="hidden" name="evazar_brand_selector_nonce" value="' . esc_attr(wp_create_nonce('evazar_brand_selector_save')) . '" />';
    }
    echo '<label class="evazar-brand-picker-title"><strong>' . esc_html($title) . '</strong></label>';
    echo '<input type="search" class="evazar-brand-picker-search" autocomplete="off" placeholder="نام فارسی یا نامک انگلیسی را بنویسید…" aria-label="جست‌وجوی برند با نام یا نامک" />';
    echo '<div class="evazar-brand-picker-results" role="listbox" aria-live="polite"></div>';
    echo '<div class="evazar-brand-picker-selected" aria-live="polite">';
    foreach ($term_ids as $term_id) {
        $term = get_term($term_id, 'evazar_brand');
        if (!$term || is_wp_error($term)) {
            continue;
        }
        evazar_brand_selector_render_selected_term($term, $input_name);
    }
    echo '</div>';
    if ($help !== '') {
        echo '<p class="description evazar-brand-picker-help">' . esc_html($help) . '</p>';
    }
    echo '</div>';
}

function evazar_brand_selector_render_selected_term($term, $input_name) {
    $term_id = (int) $term->term_id;
    echo '<div class="evazar-brand-picker-selected-item" data-term-id="' . esc_attr($term_id) . '">';
    echo '<span class="evazar-brand-picker-selected-label"><strong>' . esc_html($term->name) . '</strong><small>نامک: <code>' . esc_html($term->slug) . '</code> · شناسه: ' . esc_html($term_id) . '</small></span>';
    echo '<button type="button" class="button-link evazar-brand-picker-remove" aria-label="حذف انتخاب ' . esc_attr($term->name) . '">×</button>';
    echo '<input type="hidden" name="' . esc_attr($input_name) . '" value="' . esc_attr($term_id) . '" />';
    echo '</div>';
}

/** Return only existing terms from the EVazar brand taxonomy; never accept a slug/name as an ID. */
function evazar_brand_selector_validate_term_ids($raw_ids) {
    $raw_ids = is_array($raw_ids) ? $raw_ids : [$raw_ids];
    $ids = [];
    foreach ($raw_ids as $raw_id) {
        if (is_array($raw_id) || is_object($raw_id)) {
            continue;
        }
        $id = absint($raw_id);
        if ($id < 1 || isset($ids[$id])) {
            continue;
        }
        $term = get_term($id, 'evazar_brand');
        if ($term && !is_wp_error($term) && (int) $term->term_id === $id) {
            $ids[$id] = $id;
        }
    }
    return array_values($ids);
}

/** Restore the two legacy display/search fields after a partial metadata write. */
function evazar_brand_selector_restore_product_brand_meta($post_id, $snapshot) {
    $post_id = absint($post_id);
    foreach (['_evazar_brand', '_evazar_brand_en'] as $meta_key) {
        $old_value = (string) ($snapshot[$meta_key] ?? '');
        if ($old_value !== '') {
            update_post_meta($post_id, $meta_key, $old_value);
        } else {
            delete_post_meta($post_id, $meta_key);
        }
    }
    return (string) get_post_meta($post_id, '_evazar_brand', true) === (string) ($snapshot['_evazar_brand'] ?? '')
        && (string) get_post_meta($post_id, '_evazar_brand_en', true) === (string) ($snapshot['_evazar_brand_en'] ?? '');
}

/**
 * Keep legacy display/search metadata aligned with the exact assigned brand term.
 * A single term is authoritative. For append/multi-brand assignments, retain a primary
 * only when the current metadata identifies exactly one of the selected term IDs; otherwise
 * remove ambiguous scalar metadata rather than keeping a stale brand name.
 */
function evazar_brand_selector_sync_product_brand_meta($post_id, $term_ids) {
    $post_id = absint($post_id);
    if ($post_id < 1 || get_post_type($post_id) !== 'evazar_product') return false;

    $previous_meta = [
        '_evazar_brand' => (string) get_post_meta($post_id, '_evazar_brand', true),
        '_evazar_brand_en' => (string) get_post_meta($post_id, '_evazar_brand_en', true),
    ];
    $term_ids = evazar_brand_selector_validate_term_ids($term_ids);
    $primary_term = null;

    if (count($term_ids) === 1) {
        $primary_term = get_term($term_ids[0], 'evazar_brand');
    } elseif (count($term_ids) > 1) {
        $saved_name = trim((string) get_post_meta($post_id, '_evazar_brand', true));
        $saved_english = trim((string) get_post_meta($post_id, '_evazar_brand_en', true));
        $name_matches = [];
        if ($saved_name !== '') {
            foreach ($term_ids as $term_id) {
                $term = get_term($term_id, 'evazar_brand');
                if ($term && !is_wp_error($term) && trim((string) $term->name) === $saved_name) $name_matches[] = $term;
            }
        }
        if (count($name_matches) === 1) {
            $primary_term = $name_matches[0];
        } elseif ($saved_english !== '') {
            $normalize = static function ($value) {
                $value = trim((string) $value);
                return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
            };
            $english_matches = [];
            foreach ($term_ids as $term_id) {
                $term = get_term($term_id, 'evazar_brand');
                if (!$term || is_wp_error($term)) continue;
                $term_english = trim((string) get_term_meta((int) $term->term_id, '_evazar_brand_en', true));
                if ($term_english !== '' && $normalize($term_english) === $normalize($saved_english)) $english_matches[] = $term;
            }
            if (count($english_matches) === 1) $primary_term = $english_matches[0];
        }
    }

    if (!$primary_term || is_wp_error($primary_term) || empty($primary_term->term_id)) {
        delete_post_meta($post_id, '_evazar_brand');
        delete_post_meta($post_id, '_evazar_brand_en');
        $cleared = trim((string) get_post_meta($post_id, '_evazar_brand', true)) === ''
            && trim((string) get_post_meta($post_id, '_evazar_brand_en', true)) === '';
        if (!$cleared) evazar_brand_selector_restore_product_brand_meta($post_id, $previous_meta);
        return $cleared;
    }

    $canonical_name = trim((string) $primary_term->name);
    if ($canonical_name === '') return false;
    update_post_meta($post_id, '_evazar_brand', $canonical_name);

    $canonical_english = trim((string) get_term_meta((int) $primary_term->term_id, '_evazar_brand_en', true));
    if ($canonical_english !== '') {
        update_post_meta($post_id, '_evazar_brand_en', $canonical_english);
    } else {
        // Never retain a previous brand's English name when the selected term has none.
        delete_post_meta($post_id, '_evazar_brand_en');
    }

    $saved_name = trim((string) get_post_meta($post_id, '_evazar_brand', true));
    $saved_english_after = trim((string) get_post_meta($post_id, '_evazar_brand_en', true));
    $verified = $saved_name === $canonical_name && $saved_english_after === $canonical_english;
    if (!$verified) evazar_brand_selector_restore_product_brand_meta($post_id, $previous_meta);
    return $verified;
}

/**
 * Write exact term IDs and verify the persisted relationship. Modes:
 * - replace: the selected IDs become the entire assignment; an empty array explicitly clears it.
 * - append: selected IDs are added to existing IDs; an empty array is a no-op.
 * Read-before-write prevents duplicate taxonomy/index hooks when both save_post and a late
 * lifecycle reconciliation observe the same successful selection.
 */
function evazar_brand_selector_apply_term_ids($post_id, $term_ids, $mode = 'replace', $source = 'admin') {
    $post_id = absint($post_id);
    if ($post_id < 1 || get_post_type($post_id) !== 'evazar_product') return false;
    if (!current_user_can('edit_post', $post_id)) return false;
    $taxonomy = get_taxonomy('evazar_brand');
    if (!$taxonomy || empty($taxonomy->cap->assign_terms) || !current_user_can($taxonomy->cap->assign_terms)) return false;

    $raw_ids = is_array($term_ids) ? $term_ids : (is_null($term_ids) ? [] : [$term_ids]);
    $target_ids = evazar_brand_selector_validate_term_ids($raw_ids);
    $current_ids = wp_get_object_terms($post_id, 'evazar_brand', ['fields' => 'ids']);
    if (is_wp_error($current_ids)) {
        error_log('[EVazar Brand Selector] Could not read current brand IDs for product #' . $post_id . ' during ' . sanitize_key($source) . '; write skipped.');
        return false;
    }
    $current_ids = evazar_brand_selector_validate_term_ids($current_ids);

    if ($mode === 'append') {
        if (empty($target_ids)) return true;
        $target_ids = array_values(array_unique(array_merge(array_map('absint', $current_ids), $target_ids)));
    } else {
        $mode = 'replace';
    }

    $compare_current = $current_ids;
    $compare_target = $target_ids;
    sort($compare_current, SORT_NUMERIC);
    sort($compare_target, SORT_NUMERIC);
    if ($compare_current === $compare_target) {
        // Repeated save/shutdown reconciliation also repairs stale legacy brand metadata.
        if (!evazar_brand_selector_sync_product_brand_meta($post_id, $current_ids)) {
            error_log('[EVazar Brand Selector] Could not verify legacy brand metadata sync for product #' . $post_id . ' during ' . sanitize_key($source) . '.');
            return false;
        }
        return true;
    }

    $write_result = wp_set_object_terms($post_id, $target_ids, 'evazar_brand', false);
    if (is_wp_error($write_result) || $write_result === false) {
        $message = is_wp_error($write_result) && method_exists($write_result, 'get_error_message')
            ? $write_result->get_error_message() : 'wp_set_object_terms returned false';
        error_log('[EVazar Brand Selector] ' . $mode . ' assignment failed for product #' . $post_id . ' during ' . sanitize_key($source) . ': ' . $message);
        return false;
    }

    $confirmed_ids = wp_get_object_terms($post_id, 'evazar_brand', ['fields' => 'ids']);
    if (is_wp_error($confirmed_ids)) {
        error_log('[EVazar Brand Selector] Could not verify saved brands for product #' . $post_id . ' during ' . sanitize_key($source) . '.');
        return false;
    }
    $confirmed_ids = evazar_brand_selector_validate_term_ids($confirmed_ids);
    sort($confirmed_ids, SORT_NUMERIC);
    if ($confirmed_ids !== $compare_target) {
        error_log('[EVazar Brand Selector] Saved brand IDs failed verification for product #' . $post_id . ' during ' . sanitize_key($source) . '.');
        return false;
    }
    if (!evazar_brand_selector_sync_product_brand_meta($post_id, $confirmed_ids)) {
        $rollback = wp_set_object_terms($post_id, $current_ids, 'evazar_brand', false);
        $rollback_ids_raw = wp_get_object_terms($post_id, 'evazar_brand', ['fields' => 'ids']);
        $rollback_read_failed = is_wp_error($rollback_ids_raw);
        $rollback_ids = $rollback_read_failed ? [] : evazar_brand_selector_validate_term_ids($rollback_ids_raw);
        $expected_rollback_ids = $current_ids;
        sort($rollback_ids, SORT_NUMERIC);
        sort($expected_rollback_ids, SORT_NUMERIC);
        $rollback_verified = !is_wp_error($rollback) && $rollback !== false && !$rollback_read_failed && $rollback_ids === $expected_rollback_ids;
        error_log('[EVazar Brand Selector] Taxonomy metadata sync failed for product #' . $post_id . ' during ' . sanitize_key($source) . '; assignment rollback verified=' . ($rollback_verified ? 'yes' : 'no') . '.');
        return false;
    }
    return true;
}

/**
 * Apply a bulk brand replacement idempotently. Empty selections remain a no-op.
 */
function evazar_brand_selector_apply_bulk_brand_ids($post_id, $term_ids) {
    $target_ids = evazar_brand_selector_validate_term_ids($term_ids);
    if (empty($target_ids)) return false; // Empty/invalid bulk selection is always a no-op.
    return evazar_brand_selector_apply_term_ids($post_id, $target_ids, 'replace', 'bulk-edit');
}

/**
 * WordPress 6.3+ invokes this after processing the standard bulk-edit form.
 * Use its original shared payload so taxonomy assignment does not depend on
 * save_post firing for a post whose ordinary fields did not change.
 */
function evazar_brand_selector_finalize_bulk_edit($updated_post_ids, $post_data) {
    if (!is_array($updated_post_ids) || empty($updated_post_ids) || !is_array($post_data)) {
        return;
    }
    if (!isset($post_data['evazar_brand_selector_nonce']) || !is_scalar($post_data['evazar_brand_selector_nonce'])) {
        return;
    }
    $nonce = sanitize_text_field(wp_unslash((string) $post_data['evazar_brand_selector_nonce']));
    if (!wp_verify_nonce($nonce, 'evazar_brand_selector_save')) {
        return;
    }
    if (!isset($post_data['evazar_bulk_brand_term_ids']) || !is_array($post_data['evazar_bulk_brand_term_ids'])) {
        return;
    }
    $target_ids = evazar_brand_selector_validate_term_ids(wp_unslash($post_data['evazar_bulk_brand_term_ids']));
    if (empty($target_ids)) {
        return; // Do not clear brands unless a valid brand was explicitly selected.
    }
    foreach ($updated_post_ids as $updated_post_id) {
        $updated_post_id = absint($updated_post_id);
        if ($updated_post_id > 0) {
            evazar_brand_selector_apply_bulk_brand_ids($updated_post_id, $target_ids);
        }
    }
}

function evazar_brand_selector_save_product_terms($post_id, $post, $update) {
    if (!$post || $post->post_type !== 'evazar_product' || wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    $taxonomy = get_taxonomy('evazar_brand');
    if (!$taxonomy || !current_user_can($taxonomy->cap->assign_terms)) {
        return;
    }
    if (!isset($_POST['evazar_brand_selector_nonce']) || !is_scalar($_POST['evazar_brand_selector_nonce'])) {
        return;
    }
    $nonce = sanitize_text_field(wp_unslash((string) $_POST['evazar_brand_selector_nonce']));
    if (!wp_verify_nonce($nonce, 'evazar_brand_selector_save')) {
        return;
    }

    // Full classic product edit uses explicit replacement, permitting intentional removal of all brands.
    if (isset($_POST['evazar_brand_selector_present']) && is_scalar($_POST['evazar_brand_selector_present'])
        && (string) wp_unslash($_POST['evazar_brand_selector_present']) === '1') {
        $raw_ids = isset($_POST['evazar_brand_term_ids']) && is_array($_POST['evazar_brand_term_ids'])
            ? wp_unslash($_POST['evazar_brand_term_ids']) : [];
        evazar_brand_selector_apply_term_ids($post_id, $raw_ids, 'replace', 'classic-save_post');
        return;
    }

    // Bulk edit is explicit replacement: when a brand is selected, assign exactly those IDs.
    // An absent/empty choice is a no-op, so opening bulk edit alone never clears existing brands.
    if (array_key_exists('evazar_bulk_brand_term_ids', $_POST)) {
        $bulk_ids = is_array($_POST['evazar_bulk_brand_term_ids'])
            ? evazar_brand_selector_validate_term_ids(wp_unslash($_POST['evazar_bulk_brand_term_ids']))
            : [];
        if (!empty($bulk_ids)) {
            evazar_brand_selector_apply_bulk_brand_ids($post_id, $bulk_ids);
        }
        return;
    }

    // Quick Edit keeps its previous additive behavior; only bulk edit has replacement semantics.
    if (!isset($_POST['evazar_quick_brand_term_ids']) || !is_array($_POST['evazar_quick_brand_term_ids'])) {
        return;
    }
    $to_add = evazar_brand_selector_validate_term_ids(wp_unslash($_POST['evazar_quick_brand_term_ids']));
    if (empty($to_add)) return;
    evazar_brand_selector_apply_term_ids($post_id, $to_add, 'append', 'quick-save_post');
}

/**
 * Some admin save flows process taxonomy input after save_post. Re-apply only our explicit
 * picker payload at shutdown so core's later taxonomy handling cannot silently undo it.
 * A valid per-form nonce and per-product capability checks are required again here.
 */
function evazar_brand_selector_finalize_posted_assignment() {
    if (empty($_POST) || !is_array($_POST)) return;
    if (!isset($_POST['evazar_brand_selector_nonce']) || !is_scalar($_POST['evazar_brand_selector_nonce'])) return;
    $nonce = sanitize_text_field(wp_unslash((string) $_POST['evazar_brand_selector_nonce']));
    if (!wp_verify_nonce($nonce, 'evazar_brand_selector_save')) return;

    $post_id = 0;
    foreach (['post_ID', 'post_id'] as $key) {
        if (isset($_POST[$key]) && is_scalar($_POST[$key])) {
            $post_id = absint(wp_unslash($_POST[$key]));
            if ($post_id > 0) break;
        }
    }
    if ($post_id < 1 || get_post_type($post_id) !== 'evazar_product' || !current_user_can('edit_post', $post_id)) return;

    if (isset($_POST['evazar_brand_selector_present']) && is_scalar($_POST['evazar_brand_selector_present'])
        && (string) wp_unslash($_POST['evazar_brand_selector_present']) === '1') {
        $raw_ids = isset($_POST['evazar_brand_term_ids']) && is_array($_POST['evazar_brand_term_ids'])
            ? wp_unslash($_POST['evazar_brand_term_ids']) : [];
        evazar_brand_selector_apply_term_ids($post_id, $raw_ids, 'replace', 'late-classic-save');
        return;
    }

    if (isset($_POST['evazar_quick_brand_term_ids']) && is_array($_POST['evazar_quick_brand_term_ids'])) {
        $raw_ids = evazar_brand_selector_validate_term_ids(wp_unslash($_POST['evazar_quick_brand_term_ids']));
        if (!empty($raw_ids)) {
            evazar_brand_selector_apply_term_ids($post_id, $raw_ids, 'append', 'late-quick-edit-save');
        }
    }
}

/** Ensure Gutenberg's REST update leaves the exact term IDs selected in the custom panel. */
function evazar_brand_selector_reconcile_rest_assignment($post, $request, $creating) {
    if (!is_object($post) || empty($post->ID) || !is_object($request) || !method_exists($request, 'has_param') || !method_exists($request, 'get_param')) return;
    if (!$request->has_param('evazar_brand')) return;
    $raw_ids = $request->get_param('evazar_brand');
    if (!is_array($raw_ids)) return;
    evazar_brand_selector_apply_term_ids((int) $post->ID, $raw_ids, 'replace', 'rest-after-insert');
}

function evazar_brand_selector_ajax_search() {
    if (!current_user_can('edit_posts')) {
        wp_send_json_error(['message' => 'forbidden'], 403);
    }
    check_ajax_referer('evazar_brand_selector_search', 'nonce');

    $requested_ids = [];
    if (isset($_GET['ids']) && is_scalar($_GET['ids'])) {
        foreach (explode(',', (string) wp_unslash($_GET['ids'])) as $raw_id) {
            $id = absint($raw_id);
            if ($id > 0) $requested_ids[$id] = $id;
        }
    }

    if (!empty($requested_ids)) {
        $terms = get_terms([
            'taxonomy' => 'evazar_brand',
            'include' => array_values($requested_ids),
            'hide_empty' => false,
            'number' => count($requested_ids),
            'orderby' => 'include',
            'update_term_meta_cache' => false,
        ]);
        if (is_wp_error($terms)) {
            wp_send_json_error(['message' => 'term_query_failed'], 500);
        }
        $results = [];
        foreach ($terms as $term) {
            $results[] = ['id' => (int) $term->term_id, 'name' => (string) $term->name, 'slug' => (string) $term->slug];
        }
        wp_send_json_success($results);
    }

    $query = isset($_GET['q']) && is_scalar($_GET['q']) ? sanitize_text_field(wp_unslash((string) $_GET['q'])) : '';
    $query = trim($query);
    if ($query === '') {
        wp_send_json_success([]);
    }
    if (function_exists('mb_substr')) {
        $query = mb_substr($query, 0, 100, 'UTF-8');
    } else {
        $query = substr($query, 0, 100);
    }
    global $wpdb;
    $like = '%' . $wpdb->esc_like($query) . '%';
    $sql = $wpdb->prepare(
        "SELECT t.term_id, t.name, t.slug
         FROM {$wpdb->terms} AS t
         INNER JOIN {$wpdb->term_taxonomy} AS tt ON tt.term_id = t.term_id
         WHERE tt.taxonomy = %s AND (t.name LIKE %s OR t.slug LIKE %s)
         ORDER BY t.name ASC, t.slug ASC, t.term_id ASC
         LIMIT 40",
        'evazar_brand', $like, $like
    );
    $rows = $wpdb->get_results($sql);
    if ($rows === null && !empty($wpdb->last_error)) {
        wp_send_json_error(['message' => 'term_query_failed'], 500);
    }
    $results = [];
    foreach ((array) $rows as $row) {
        $results[] = ['id' => (int) $row->term_id, 'name' => (string) $row->name, 'slug' => (string) $row->slug];
    }
    wp_send_json_success($results);
}

function evazar_brand_selector_enqueue_admin_assets($hook_suffix) {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen) return;
    $is_product_list = $screen->base === 'edit' && $screen->post_type === 'evazar_product';
    $is_product_edit = $screen->base === 'post' && $screen->post_type === 'evazar_product';
    $is_brand_list = $screen->base === 'edit-tags' && $screen->taxonomy === 'evazar_brand';
    if (!$is_product_list && !$is_product_edit && !$is_brand_list) return;

    $handle = 'evazar-brand-selector-admin';
    wp_enqueue_script($handle, plugin_dir_url(__FILE__) . 'brand-selector-admin.js', [], '2.9.84.40', true);
    wp_localize_script($handle, 'EvazarBrandSelector', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('evazar_brand_selector_search'),
        'labels' => [
            'noResults' => 'نتیجه‌ای پیدا نشد.',
            'searching' => 'در حال جست‌وجو…',
            'searchPrompt' => 'برای جست‌وجو، نام فارسی یا نامک انگلیسی را وارد کن.',
            'slug' => 'نامک: ',
            'id' => 'شناسه: ',
            'select' => 'انتخاب',
        ],
    ]);

    wp_register_style('evazar-brand-selector-admin', false, [], '2.9.84.40');
    wp_enqueue_style('evazar-brand-selector-admin');
    wp_add_inline_style('evazar-brand-selector-admin', '.evazar-brand-picker{margin:8px 0;max-width:100%}.evazar-brand-picker-title{display:block;margin:0 0 6px}.evazar-brand-picker-search{width:100%;max-width:100%;box-sizing:border-box}.evazar-brand-picker-results{max-height:220px;overflow:auto;margin-top:6px}.evazar-brand-picker-result{display:block;width:100%;text-align:right;background:#fff;border:1px solid #dcdcde;border-radius:3px;padding:7px 9px;margin:3px 0;cursor:pointer;color:#1d2327}.evazar-brand-picker-result:hover,.evazar-brand-picker-result:focus{border-color:#2271b1;background:#f0f6fc}.evazar-brand-picker-result strong,.evazar-brand-picker-selected-label strong{display:block}.evazar-brand-picker-result small,.evazar-brand-picker-selected-label small{display:block;color:#646970;font-size:11px;margin-top:2px;direction:ltr;text-align:right}.evazar-brand-picker-selected{display:flex;flex-direction:column;gap:4px;margin-top:8px}.evazar-brand-picker-selected-item{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:6px 8px;background:#f6f7f7;border:1px solid #dcdcde;border-radius:3px}.evazar-brand-picker-selected-label{min-width:0}.evazar-brand-picker-selected-label code{direction:ltr;unicode-bidi:embed}.evazar-brand-picker-remove{font-size:18px;text-decoration:none;color:#b32d2e!important}.evazar-brand-picker-message{margin:6px 0;color:#646970}.evazar-brand-picker-help{margin-top:7px!important}.evazar-term-slug-under-name{display:block;color:#646970;font-size:11px;margin-top:3px}.evazar-brand-inline-field{min-width:280px}.evazar-brand-inline-field .evazar-brand-picker{max-width:360px}.evazar-brand-inline-field .evazar-brand-picker-selected-item{max-width:340px}.evazar-brand-editor-results{display:flex;flex-direction:column;gap:5px;margin-top:8px}.evazar-brand-editor-results .components-button{height:auto;min-height:36px;justify-content:flex-start;white-space:normal;width:100%;padding:7px 10px}.evazar-brand-editor-result{display:block;text-align:right;width:100%}.evazar-brand-editor-result strong,.evazar-brand-editor-result small{display:block}.evazar-brand-editor-result small{direction:ltr;text-align:right;color:#646970;font-size:11px;margin-top:2px}.evazar-brand-editor-selected{display:flex;flex-direction:column;gap:5px;margin:8px 0}.evazar-brand-editor-selected-item{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:7px;border:1px solid #dcdcde;border-radius:3px}.evazar-brand-editor-selected-item small{display:block;direction:ltr;text-align:right;color:#646970;font-size:11px;margin-top:2px}');
}

function evazar_brand_selector_enqueue_block_editor_assets() {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen || $screen->post_type !== 'evazar_product') return;
    wp_enqueue_script(
        'evazar-brand-selector-editor',
        plugin_dir_url(__FILE__) . 'brand-selector-editor.js',
        ['wp-plugins', 'wp-edit-post', 'wp-element', 'wp-components', 'wp-data'],
        '2.9.84.40',
        true
    );
    wp_localize_script('evazar-brand-selector-editor', 'EvazarBrandSelectorEditor', [
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('evazar_brand_selector_search'),
    ]);
}
