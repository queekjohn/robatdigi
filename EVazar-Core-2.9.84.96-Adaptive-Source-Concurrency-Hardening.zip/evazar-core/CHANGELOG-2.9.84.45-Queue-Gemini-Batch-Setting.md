# EVazar Core 2.9.84.45 — Queue Gemini Batch Setting

- Moved the “تعداد محصولات هر درخواست Gemini” control from the general AI settings screen into “تنظیمات زمان‌بندی و سرعت پردازش صف” on the import queue dashboard.
- Saved the selection through the queue settings form while preserving the existing `evazar_ai_product_batch_size` option and its sanitizer, so batch processing behavior and existing saved values remain compatible.
- Kept scheduling interval and queue safety-cap controls unchanged.
- No Worker, Theme, cache, prompt, or Gemini model behavior changed.
