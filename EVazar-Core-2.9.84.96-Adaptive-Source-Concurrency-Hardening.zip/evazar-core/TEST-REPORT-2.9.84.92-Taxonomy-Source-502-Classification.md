# Test report — EVazar Core 2.9.84.92

## Finding fixed

In Worker 1.13.27, taxonomy public-page and legacy taxonomy API proxy errors can carry source-provenance headers without `X-Evazar-Error-Scope: source`. Before this release, Core treated those upstream 502 responses as Worker failures, cooled down each endpoint, and retried the same source request through the rest of the Worker pool. This could produce `worker_pool_exhausted_http_errors` even when the Worker endpoints were healthy and the common failure was Digikala's upstream response.

## Implemented correction

- For `purpose=import_source` only, Core recognizes the existing Worker 1.13.27 provenance headers and classifies a source-provenance HTTP error as `error_scope=source`.
- This classification returns the failure to the taxonomy fetcher immediately, without fanning out to the other Worker endpoints and without cooling down healthy Workers.
- Bare 502 responses without source provenance remain Worker/edge failures and keep the existing failover and cooldown behavior.
- Taxonomy source attempts now retain bounded diagnostic metadata: Worker version, upstream HTTP status/host/error, source path, fetch duration, upstream type, content status, redirect count and final path. Response bodies, tokens and credentials are not logged.
- Prior 2.9.84.91 lease timeout safety remains unchanged.
- Embedded and deployed Worker version stays at 1.13.27; no Worker rollout is required.

## Automated results

- PHP regression scripts: 28 executed, 0 failures.
- JavaScript regression scripts: 4 executed, 0 failures.
- PHP syntax checks: 41 files, 0 errors.
- Node syntax check for the embedded Worker: passed.
- ZIP integrity: passed.
- Focused primary Worker/source diagnostic regression: 31 assertions passed.
- Focused regression cases cover:
  - Worker 1.13.27 public source-page 502 diagnostic headers.
  - Legacy taxonomy API upstream 502 diagnostic headers.
  - No Worker pool fan-out or cooldown for source-origin failures.
  - Additional source detail preserved in taxonomy retry diagnostics.
  - Bare 502 without source provenance still triggers Worker failover/cooldown.
  - Existing serial and parallel lease safety remains passing in the full suite.

## Worker parity

The embedded Worker remains byte-identical to the previous release's embedded Worker 1.13.27. SHA-256:

`0fc82e8cdd7886739c4560ae81d2f4fb1affaf6f8a6adf39386cf1e668909074`

## Validation boundary

Tests were run locally using PHP CLI and Node.js. The package was not installed on the live evazar.ir server, and no live cPanel, WordPress database, Cloudflare, or Digikala request was performed during this build.
