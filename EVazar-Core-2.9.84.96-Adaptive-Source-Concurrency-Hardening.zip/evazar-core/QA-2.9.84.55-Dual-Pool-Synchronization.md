# QA — EVazar Core 2.9.84.55

## Intended behavior
- Five primary source Workers, all eligible: source fetch concurrency is five, one product per Worker in each wave. A stable 120-product source phase should be 24 five-product waves with 24 requests per Worker.
- Four eligible Gemini Workers, batch size 30 and manual ceiling >=120: per-run capacity is 120 and expected Gemini chunks are 30+30+30+30.
- Four eligible Gemini Workers, batch size 50 and manual ceiling 120: per-run capacity remains 120 by explicit manual ceiling, expected chunks are 50+50+20. Raising the manual ceiling to >=200 allows 200 products and four 50-product chunks.
- Three eligible Gemini Workers, batch size 30: automatic capacity is 90.
- The source pool count never increases Gemini capacity; the Gemini pool count never increases source-fetch concurrency.

## Verification
- New regression assertions cover per-source-Worker request counts, wave-size distribution and the capacity formula.
- Full local PHP/JavaScript syntax and regression suites are run for this package before release.
- Live Digikala/Gemini/Cloudflare behavior is not claimed until tested on the user's environment.
