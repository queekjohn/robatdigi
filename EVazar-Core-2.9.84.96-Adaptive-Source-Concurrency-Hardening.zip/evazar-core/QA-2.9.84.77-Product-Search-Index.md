# QA — EVazar Core 2.9.84.77 Product Search Index

- New Core title-token search index: `tests/product-search-index-regression.php` — 21 passed, 0 failed.
- All Core+Theme PHP regression scripts: 25 scripts passed, 0 failed.
- PHP syntax: 49/49 files passed `php -l`.
- JavaScript syntax: 11/11 files passed `node --check`.
- Executed Worker regression scripts: 54 checks passed across 3 scripts.
- ZIP archive integrity checked after packaging.
- `cache-purge.php` and `worker/digikala-worker.js` byte-identical against Core 2.9.84.76 baseline.
- Existing archive/filter code was not edited.

## Limitations

The new index query was checked via local regression stubs/static SQL assertions, not executed against production MySQL/MariaDB. Query latency, execution plans, real row coverage and live AJAX response times still need production/staging measurements. Until the backfill option reports `ready`, Theme uses the legacy `WP_Query` fallback.
