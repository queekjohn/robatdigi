# QA — EVazar Core 2.9.84.42 / Worker 1.13.24

Date: 2026-10-26

## Change scope
- Automatic Gemini product batch limit: 30 → 50, end-to-end in Core validation, request metadata, queue partitioning, dispatch headers, operation logs, and Worker policy.
- Worker source version: 1.13.23 → 1.13.24; standalone and Core-embedded Worker files are byte-identical.
- New one-time migration promotes the saved default 30 to 50 but preserves intentionally lower custom batch sizes.
- Gemini queue-run ceiling: 150 → 250, allowing five eligible Workers × 50 products; new migration promotes old 150 cap and preserves lower manually chosen caps.
- Taxonomy SEO batch remains capped at five. Non-Gemini queue remains capped at 75. No Theme or cache changes.

## Local verification
- PHP syntax: `evazar-core.php`, `importer.php`, `queue-manager.php`, and PHP regression harness passed.
- JavaScript syntax: Worker source and JS regression harness passed.
- Worker integration tests: 41 passed, 0 failed; includes accept 50 and reject 51 before upstream Gemini call.
- Core regression tests: 137 passed, 0 failed; includes partitioning for batch sizes 2–50, 250-item queue ceiling, and migration preserving custom lower values.
- Embedded Worker byte comparison against standalone Worker: passed.

## Not verified
No live WordPress site, Cloudflare deployment, real Gemini API call, quota behavior, or production queue was exercised. These are local source/mock tests only.
