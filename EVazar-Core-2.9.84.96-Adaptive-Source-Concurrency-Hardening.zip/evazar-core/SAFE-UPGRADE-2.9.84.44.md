# Safe Upgrade — EVazar Core 2.9.84.44

- Upgrade the existing `evazar-core` plugin with this ZIP. It preserves queue data and settings; no database migration is required.
- This build includes the existing embedded Worker source version 1.13.24, but installing the WordPress plugin does **not** deploy code to Cloudflare.
- Before running batches above 30 products, verify that every configured Gemini Worker URL is actually deployed as Worker 1.13.24 or later. Worker 1.13.23 rejects batches above 30. If needed, deploy the standalone `EVazar-Worker-1.13.24-Gemini-Product-Batch-50.zip` to each active Worker while preserving all secrets, routes and bindings.
- Confirm Core reports 2.9.84.44 and each Worker endpoint reports 1.13.24. Then test one 40-product batch and inspect the operation log before returning to full queue processing.
- No cache, Theme, prompt, model, queue-interval, or Worker source behavior was changed in 2.9.84.44.
