# Safe Upgrade — EVazar Core 2.9.84.45

- Install the Core ZIP through the WordPress plugin updater/installer.
- In “داشبورد و وضعیت صف واردات ایوازار”, find “تنظیمات زمان‌بندی و سرعت پردازش صف”. The “تعداد محصولات هر درخواست Gemini” selector is now grouped there with interval and queue-cap controls.
- Existing value in `evazar_ai_product_batch_size` is retained and should appear selected (for example, 40).
- Save this form to update batch size from the queue page.
- No Worker update is required for this UI-only change. Verify a single scheduled batch in the operations log before resuming normal monitoring.
- No cache, Theme, prompt, model, or worker-source behavior was changed.
