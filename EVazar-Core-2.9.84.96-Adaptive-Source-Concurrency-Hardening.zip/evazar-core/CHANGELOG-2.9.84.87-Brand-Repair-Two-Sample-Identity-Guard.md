# EVazar Core 2.9.84.87 — Two-Sample Brand Identity Guard

- Brand source-metadata repair now requires two independent published product samples to agree on explicit source ID, source code, source URL/path, source slug and Persian brand name for every candidate, including when the local public slug matches the first source slug.
- If the two attached products resolve to different source identities (for example `/brand/carrera/` versus `/brand/carrera-brand/`), automatic metadata repair is blocked with `SAMPLE_DISAGREEMENT`; it does not guess which identity owns the shared display name.
- If fewer than two complete, independent source samples can be verified, the candidate stays blocked as `NEEDS_SECOND_SAMPLE`.
- The repair still writes source metadata only after live re-checks. It does not rename public terms, reassign products, change 301 mappings, touch cache settings, alter import/queue processing, or modify the Worker.
