# QA — EVazar Core 2.9.84.82

Scope: Worker source URL extraction only.

- [x] Supports URL fields supplied as strings or objects (`uri`, `url`, `href`, `path`, `url_path`, canonical URL, `@id`).
- [x] Supports breadcrumb arrays and common JSON-LD wrappers (`itemListElement`, `items`, `breadcrumb`).
- [x] Does not synthesize category URLs from names/slugs.
- [x] Core source-path preflight remains fail-closed before Gemini/product writes.
- [ ] Live Digikala payload for DKP 17815976, 22055693, 22271601 and 15551286 must be confirmed after deploying Worker 1.13.26; live upstream access is not available in this build environment.
