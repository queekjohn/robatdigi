# Safe upgrade — EVazar Core 2.9.84.72

1. Back up the current `evazar-core/` plugin folder and the WordPress database.
2. Replace the existing plugin folder with the `evazar-core/` folder in this ZIP; keep the folder name unchanged.
3. Do not redeploy or change Cloudflare Workers. No database migration is required.
4. This is diagnostic-only: it records the byte size of the serialized internal parallel request and a short credential-scrubbed response excerpt for HTTP 413. It never logs the request body or checkpoint/prompt contents.
5. If HTTP 413 recurs, inspect the `تعویق دسته Gemini` event for `اندازه درخواست`, `سقف بررسی‌شده`, `کد endpoint`, and `پاسخ سرور`.
6. Local syntax and regression tests are run for this release; production WordPress/hosting and live Gemini requests are not tested here.
