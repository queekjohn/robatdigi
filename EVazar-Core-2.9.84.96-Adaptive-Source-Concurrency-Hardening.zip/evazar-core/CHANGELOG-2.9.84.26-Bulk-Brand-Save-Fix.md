# EVazar Core 2.9.84.26 — reliable bulk brand replacement

- Fixed a production path gap in the 2.9.84.25 bulk brand selector: brand replacement is now finalized from WordPress' `bulk_edit_posts` completion action and its shared original request payload, instead of relying only on `save_post` being fired for ordinary post-field changes.
- The save path validates nonce, existing brand term IDs, product type, per-product edit permission, and taxonomy assignment permission.
- Replacement is idempotent: if `save_post` already applied the selected IDs, the completion hook confirms the same IDs and avoids a redundant taxonomy write.
- Verifies the resulting term IDs after writes and logs failures without claiming success.
- Empty or invalid selection remains a no-op; Quick Edit remains additive; full product editor behavior is unchanged.
- No cache code, import code, queue code, product-index code, redirect logic, or Worker code was edited.

## Known compatibility
- The completion action `bulk_edit_posts` is available in WordPress 6.3 and newer. The existing `save_post` path remains as a fallback for installs where that action is not available.
