# Safe upgrade — EVazar Core 2.9.84.83

1. Back up the currently installed Core plugin ZIP/folder and database as usual.
2. Replace Core with `EVazar-Core-2.9.84.83-Category-Source-Trailing-Hyphen-Fix.zip`. No Cloudflare Worker redeploy is needed; Worker 1.13.26 is unchanged.
3. Use single-product import to retry only `dkp-22055693`.
4. Confirm the previous `source_category_path_missing` error is gone and inspect the import result/log before retrying other products.

This release does not change cache configuration, cache-purge code, Gemini prompts/model/settings, queue schedule, price/stock handling, or Worker code.
