<?php
/**
 * Admin-only management for the EVazar Core brand 301 redirect map.
 * This module only edits the evazar_brand_slug_redirects option. It never edits terms,
 * products, term metadata, rewrite rules, cache state, or Workers.
 */
if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_menu', 'evazar_brand_redirect_admin_register_menu');
add_action('admin_post_evazar_brand_redirect_export', 'evazar_brand_redirect_admin_export');
add_action('admin_post_evazar_brand_redirect_delete_selected', 'evazar_brand_redirect_admin_delete_selected');

function evazar_brand_redirect_admin_register_menu() {
    add_submenu_page(
        'edit.php?post_type=evazar_product',
        'مدیریت ریدایرکت برندها',
        'ریدایرکت برندها',
        'manage_options',
        'evazar-brand-redirects',
        'evazar_brand_redirect_admin_page'
    );
}

/** Create the selected-key lookup without accepting arbitrary map destinations from POST. */
function evazar_brand_redirect_admin_remove_selected_entries($raw_map, $selected) {
    if (!is_array($raw_map) || !is_array($selected) || empty($selected)) {
        return is_array($raw_map) ? $raw_map : [];
    }
    $new_map = $raw_map;
    foreach (array_keys($new_map) as $raw_slug) {
        $normalized_slug = sanitize_title((string) $raw_slug);
        if ($normalized_slug !== '' && array_key_exists($normalized_slug, $selected)) {
            unset($new_map[$raw_slug]);
        }
    }
    return $new_map;
}

function evazar_brand_redirect_admin_validate_selection($posted, $current_map) {
    $valid = [];
    $skipped = 0;
    if (!is_array($posted) || !is_array($current_map)) {
        return ['valid' => [], 'skipped' => 0];
    }
    foreach ($posted as $posted_slug => $posted_target_id) {
        if (is_array($posted_target_id) || is_object($posted_target_id)) {
            $skipped++;
            continue;
        }
        $slug = sanitize_title((string) wp_unslash($posted_slug));
        $target_id = absint(wp_unslash($posted_target_id));
        if ($slug === '' || $target_id < 1 || !array_key_exists($slug, $current_map) || (int) $current_map[$slug] !== $target_id) {
            $skipped++;
            continue;
        }
        $valid[$slug] = $target_id;
    }
    return ['valid' => $valid, 'skipped' => $skipped];
}

/** Render the current normalized map for review and explicit selection. */
function evazar_brand_redirect_admin_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    $raw_map = get_option('evazar_brand_slug_redirects', []);
    if (!is_array($raw_map)) {
        $raw_map = [];
    }
    $map = function_exists('evazar_brand_slug_redirect_map') ? evazar_brand_slug_redirect_map() : [];
    $search = isset($_GET['s']) && is_scalar($_GET['s']) ? sanitize_text_field(wp_unslash((string) $_GET['s'])) : '';
    $page_num = isset($_GET['paged']) && is_scalar($_GET['paged']) ? max(1, absint(wp_unslash((string) $_GET['paged']))) : 1;
    $error_code = isset($_GET['error']) && is_scalar($_GET['error']) ? sanitize_key(wp_unslash((string) $_GET['error'])) : '';
    $deleted_count = isset($_GET['deleted']) && is_scalar($_GET['deleted']) ? absint(wp_unslash((string) $_GET['deleted'])) : null;
    $skipped_count = isset($_GET['skipped']) && is_scalar($_GET['skipped']) ? absint(wp_unslash((string) $_GET['skipped'])) : 0;
    $per_page = 200; // The reported batch of 133 entries fits on one page.
    $rows = [];

    foreach ($map as $old_slug => $target_id) {
        $term = get_term((int) $target_id, 'evazar_brand');
        $term_is_valid = $term && !is_wp_error($term) && !empty($term->term_id);
        $target_name = $term_is_valid ? (string) $term->name : 'مقصد یافت نشد';
        $target_slug = $term_is_valid ? (string) $term->slug : '';
        $target_url = $term_is_valid ? get_term_link($term, 'evazar_brand') : '';
        if (is_wp_error($target_url)) {
            $target_url = '';
        }
        $current_owner = get_term_by('slug', $old_slug, 'evazar_brand');
        $owner_conflict = $current_owner && !is_wp_error($current_owner) && (int) $current_owner->term_id !== (int) $target_id;
        if (!$term_is_valid) {
            $status = 'مقصد نامعتبر';
        } elseif ($owner_conflict) {
            $status = 'نامک قدیمی اکنون متعلق به برند دیگری است';
        } elseif ($old_slug === $target_slug) {
            $status = 'نامک مبدأ و مقصد یکسان است';
        } else {
            $status = 'نگاشت ۳۰۱ ذخیره‌شده';
        }

        $row = [
            'old_slug' => (string) $old_slug,
            'target_id' => (int) $target_id,
            'target_name' => $target_name,
            'target_slug' => $target_slug,
            'target_url' => is_string($target_url) ? $target_url : '',
            'status' => $status,
            'owner_conflict' => (bool) $owner_conflict,
        ];
        if ($search !== '') {
            $haystack = $row['old_slug'] . ' ' . $row['target_id'] . ' ' . $row['target_name'] . ' ' . $row['target_slug'] . ' ' . $row['status'];
            if (stripos($haystack, $search) === false) {
                continue;
            }
        }
        $rows[] = $row;
    }

    usort($rows, static function ($a, $b) {
        return strnatcasecmp($a['old_slug'], $b['old_slug']);
    });
    $total_rows = count($rows);
    $total_pages = max(1, (int) ceil($total_rows / $per_page));
    if ($page_num > $total_pages) {
        $page_num = $total_pages;
    }
    $visible_rows = array_slice($rows, ($page_num - 1) * $per_page, $per_page);
    $active_map_count = count($map);
    $raw_count = count($raw_map);
    $base_url = admin_url('edit.php?post_type=evazar_product&page=evazar-brand-redirects');
    ?>
    <div class="wrap" dir="rtl">
      <h1>مدیریت ریدایرکت برندها</h1>
      <p>این صفحه فقط نگاشت ذخیره‌شدهٔ <code>evazar_brand_slug_redirects</code> را نمایش می‌دهد. حذف هر مورد فقط همان نگاشت ۳۰۱ را از پایگاه داده پاک می‌کند؛ برندها، محصولات، متادیتا، کش و Worker تغییر نمی‌کنند.</p>
      <div class="notice notice-warning inline"><p><strong>قبل از حذف:</strong> ابتدا فایل پشتیبان JSON را دانلود کن. حذف ریدایرکت ممکن است باعث شود URL قدیمی به‌جای انتقال، پاسخ 404 بگیرد.</p></div>
      <?php if ($deleted_count !== null): ?>
        <div class="notice notice-success is-dismissible"><p>تعداد نگاشت‌های حذف‌شده: <strong><?php echo esc_html($deleted_count); ?></strong><?php if ($skipped_count > 0): ?>؛ موارد تغییرکرده یا نامعتبر و حذف‌نشده: <strong><?php echo esc_html($skipped_count); ?></strong><?php endif; ?></p></div>
      <?php endif; ?>
      <?php if ($error_code === 'backup_required'): ?>
        <div class="notice notice-error"><p>برای ادامه، ابتدا فایل پشتیبان JSON را دانلود و ذخیره کن و سپس گزینهٔ تأیید پشتیبان را علامت بزن.</p></div>
      <?php elseif ($error_code === 'no_selection'): ?>
        <div class="notice notice-error"><p>هیچ نگاشت معتبری برای حذف انتخاب نشده است یا نگاشت از زمان بارگذاری صفحه تغییر کرده است.</p></div>
      <?php elseif ($error_code === 'save_failed'): ?>
        <div class="notice notice-error"><p>ذخیرهٔ تغییر در پایگاه داده تأیید نشد؛ هیچ موفقیتی اعلام نمی‌شود. صفحه را تازه‌سازی کن و وضعیت را بررسی کن.</p></div>
      <?php elseif ($error_code === 'map_changed'): ?>
        <div class="notice notice-error"><p>نگاشت ریدایرکت هم‌زمان تغییر کرده است؛ برای جلوگیری از بازنویسی اطلاعات جدید، حذف انجام نشد. صفحه را تازه‌سازی و انتخاب را دوباره انجام بده.</p></div>
      <?php endif; ?>

      <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin:14px 0">
        <span>تعداد نگاشت‌های قابل‌خواندن: <strong><?php echo esc_html(number_format_i18n($active_map_count)); ?></strong></span>
        <span>تعداد رکوردهای خام ذخیره‌شده: <strong><?php echo esc_html(number_format_i18n($raw_count)); ?></strong></span>
        <span>تعداد نتیجهٔ فعلی: <strong><?php echo esc_html(number_format_i18n($total_rows)); ?></strong></span>
        <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=evazar_brand_redirect_export'), 'evazar_brand_redirect_export')); ?>">دانلود پشتیبان JSON</a>
      </div>

      <form method="get" action="<?php echo esc_url(admin_url('edit.php')); ?>" style="margin:12px 0 18px">
        <input type="hidden" name="post_type" value="evazar_product" />
        <input type="hidden" name="page" value="evazar-brand-redirects" />
        <label for="evazar-redirect-search">جست‌وجوی نامک قدیمی، نامک/نام مقصد یا شناسهٔ برند: </label>
        <input id="evazar-redirect-search" type="search" name="s" value="<?php echo esc_attr($search); ?>" />
        <button class="button">جست‌وجو</button>
        <?php if ($search !== ''): ?> <a class="button" href="<?php echo esc_url($base_url); ?>">پاک‌کردن فیلتر</a><?php endif; ?>
      </form>

      <?php if ($total_pages > 1): ?>
        <p>صفحهٔ <?php echo esc_html(number_format_i18n($page_num)); ?> از <?php echo esc_html(number_format_i18n($total_pages)); ?>؛ در هر صفحه حداکثر <?php echo esc_html(number_format_i18n($per_page)); ?> مورد.</p>
      <?php endif; ?>

      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="evazar-brand-redirect-delete-form">
        <input type="hidden" name="action" value="evazar_brand_redirect_delete_selected" />
        <?php wp_nonce_field('evazar_brand_redirect_delete_selected'); ?>
        <p><label><input type="checkbox" id="evazar-brand-redirect-select-all" /> انتخاب همهٔ موارد نمایش‌داده‌شده</label></p>
        <div style="overflow:auto">
          <table class="widefat striped">
            <thead><tr><th style="width:34px">انتخاب</th><th>نامک قدیمی</th><th>مقصد (برند / ID)</th><th>نامک فعلی مقصد</th><th>وضعیت نگاشت</th></tr></thead>
            <tbody>
            <?php if (empty($visible_rows)): ?>
              <tr><td colspan="5">هیچ نگاشتی پیدا نشد.</td></tr>
            <?php else: foreach ($visible_rows as $row): ?>
              <tr>
                <td><input type="checkbox" class="evazar-brand-redirect-row" name="redirect_items[<?php echo esc_attr($row['old_slug']); ?>]" value="<?php echo esc_attr($row['target_id']); ?>" /></td>
                <td><code>/brand/<?php echo esc_html($row['old_slug']); ?>/</code></td>
                <td><?php if ($row['target_url'] !== ''): ?><a href="<?php echo esc_url($row['target_url']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($row['target_name']); ?></a><?php else: ?><?php echo esc_html($row['target_name']); ?><?php endif; ?> <span style="color:#646970">(#<?php echo esc_html($row['target_id']); ?>)</span></td>
                <td><code><?php echo esc_html($row['target_slug'] !== '' ? '/brand/' . $row['target_slug'] . '/' : '—'); ?></code></td>
                <td><?php echo esc_html($row['status']); ?></td>
              </tr>
            <?php endforeach; endif; ?>
            </tbody>
          </table>
        </div>
        <p style="margin-top:14px"><label><input type="checkbox" name="backup_confirmed" value="1" required /> فایل پشتیبان JSON را دانلود و در رایانه ذخیره کرده‌ام.</label></p>
        <p><button type="submit" class="button button-primary" onclick="return confirm('فقط نگاشت‌های انتخاب‌شدهٔ ۳۰۱ از پایگاه داده حذف شوند؟ خود برندها و محصولات حذف نمی‌شوند؛ URLهای قدیمی ممکن است 404 شوند.');">حذف نگاشت‌های انتخاب‌شده</button></p>
      </form>

      <?php if ($total_pages > 1): ?>
        <div class="tablenav"><div class="tablenav-pages">
          <?php
          for ($i = 1; $i <= $total_pages; $i++) {
              $url = add_query_arg(['post_type' => 'evazar_product', 'page' => 'evazar-brand-redirects', 'paged' => $i, 's' => $search], admin_url('edit.php'));
              if ($i === $page_num) {
                  echo '<span class="tablenav-pages-navspan button disabled" aria-current="page">' . esc_html($i) . '</span> ';
              } else {
                  echo '<a class="button" href="' . esc_url($url) . '">' . esc_html($i) . '</a> ';
              }
          }
          ?>
        </div></div>
      <?php endif; ?>
    </div>
    <script>
    (function() {
      var master = document.getElementById('evazar-brand-redirect-select-all');
      if (!master) return;
      master.addEventListener('change', function() {
        document.querySelectorAll('.evazar-brand-redirect-row').forEach(function(box) { box.checked = master.checked; });
      });
      document.querySelectorAll('.evazar-brand-redirect-row').forEach(function(box) {
        box.addEventListener('change', function() {
          var all = document.querySelectorAll('.evazar-brand-redirect-row');
          var checked = document.querySelectorAll('.evazar-brand-redirect-row:checked');
          master.checked = all.length > 0 && checked.length === all.length;
        });
      });
    })();
    </script>
    <?php
}

/** Download the exact currently saved redirect option as a JSON snapshot. */
function evazar_brand_redirect_admin_export() {
    if (!current_user_can('manage_options')) {
        wp_die('عدم دسترسی');
    }
    check_admin_referer('evazar_brand_redirect_export');
    $raw_map = get_option('evazar_brand_slug_redirects', []);
    if (!is_array($raw_map)) {
        $raw_map = [];
    }
    $payload = [
        'format' => 'evazar-brand-redirect-map-v1',
        'option_name' => 'evazar_brand_slug_redirects',
        'exported_at' => current_time('mysql'),
        'record_count' => count($raw_map),
        'redirects' => $raw_map,
    ];
    nocache_headers();
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="evazar-brand-redirects-' . gmdate('Ymd-His') . '.json"');
    echo wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/** Remove only the selected old-slug keys and only if their target IDs still match the page snapshot. */
function evazar_brand_redirect_admin_delete_selected() {
    if (!current_user_can('manage_options')) {
        wp_die('عدم دسترسی');
    }
    check_admin_referer('evazar_brand_redirect_delete_selected');
    $back_url = admin_url('edit.php?post_type=evazar_product&page=evazar-brand-redirects');
    if (empty($_POST['backup_confirmed']) || (string) wp_unslash($_POST['backup_confirmed']) !== '1') {
        wp_safe_redirect(add_query_arg('error', 'backup_required', $back_url));
        exit;
    }

    $raw_map = get_option('evazar_brand_slug_redirects', []);
    if (!is_array($raw_map)) {
        wp_safe_redirect(add_query_arg('error', 'save_failed', $back_url));
        exit;
    }
    $current_map = function_exists('evazar_brand_slug_redirect_map') ? evazar_brand_slug_redirect_map() : [];
    $posted_items = isset($_POST['redirect_items']) ? wp_unslash($_POST['redirect_items']) : [];
    $selection = evazar_brand_redirect_admin_validate_selection($posted_items, $current_map);
    $selected = $selection['valid'];
    $skipped = (int) $selection['skipped'];
    if (empty($selected)) {
        wp_safe_redirect(add_query_arg(['error' => 'no_selection', 'skipped' => $skipped], $back_url));
        exit;
    }

    $new_map = evazar_brand_redirect_admin_remove_selected_entries($raw_map, $selected);

    $expected_deletions = count($raw_map) - count($new_map);
    if ($expected_deletions < 1) {
        wp_safe_redirect(add_query_arg(['error' => 'no_selection', 'skipped' => $skipped], $back_url));
        exit;
    }

    // Fail closed if another import changed the option while this admin page was open.
    $latest_raw_map = get_option('evazar_brand_slug_redirects', []);
    if (!is_array($latest_raw_map) || $latest_raw_map !== $raw_map) {
        wp_safe_redirect(add_query_arg('error', 'map_changed', $back_url));
        exit;
    }

    update_option('evazar_brand_slug_redirects', $new_map, false);
    $saved_map = get_option('evazar_brand_slug_redirects', []);
    if (!is_array($saved_map) || $saved_map !== $new_map) {
        wp_safe_redirect(add_query_arg('error', 'save_failed', $back_url));
        exit;
    }

    $remaining = evazar_brand_slug_redirect_map();
    $deleted_effective = 0;
    foreach (array_keys($selected) as $slug) {
        if (!array_key_exists($slug, $remaining)) {
            $deleted_effective++;
        } else {
            $skipped++;
        }
    }
    wp_safe_redirect(add_query_arg(['deleted' => $deleted_effective, 'skipped' => $skipped], $back_url));
    exit;
}
