# EVazar Core 2.9.84.55 — Dual Worker Pool Synchronization

- Clarified and surfaced the independent primary-source and Gemini Worker pools in the queue plan log and admin UI.
- Source fetch remains bounded at one product per distinct eligible primary Worker, up to five concurrent requests; the summary now reports configured/eligible source Workers, actual requests per Worker, actual wave-size distribution, fallbacks, and total preparation time.
- Gemini run capacity remains `min(manual per-run ceiling, eligible Gemini Workers × products/request)`, further reduced when parallel transport or PHP runtime guards require it. The plan now logs the exact chunk plan (e.g. `30+30+30+30` or `50+50+20`) and distinguishes source Worker counts from Gemini Worker counts.
- Added safe structured fields to the operation log for the two pools and their capacities. No Worker code, cache behavior, product import logic, or existing queue state was changed.
