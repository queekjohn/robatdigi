# EVazar Core 2.9.84.11 — Brand source path and old-slug redirects

## Changes
- Accepts a brand source path only when a complete `/brand/<slug>/` path or an official `digikala.com` URL is explicitly present in the upstream brand object or entered in Brand Tools.
- Worker output adds optional `product.brand_source_path`; it never derives this value from `title_en`, `code`, the WordPress slug, or the displayed brand name.
- Imports preserve the source URL separately from the WordPress taxonomy slug and `brand_en`.
- A title-derived slug remains an unverified diagnostic hint only. It is no longer persisted as a new `_evazar_dk_url`, and unverified old brand source paths are not used for brand source-content fetching.
- Brand Tools rename operations record old WordPress slugs and issue a direct HTTP 301 to the current brand term URL, preserving pagination and query strings. A mapping does not redirect if the old slug is now owned by a different term.
- Brand audit add-on version 1.1.1 clarifies source-path status and includes a dry-run CSV for review; no automatic bulk corrections or merges were introduced.

## Explicitly out of scope
- Cache behavior, cache purge hooks, TTLs, headers, and cache keys were not intentionally changed.
- No brand terms/products are bulk-renamed, merged, or modified automatically.
- No live canonical Digikala URL is claimed as verified unless a complete explicit source path is present or a manager enters a URL they have independently checked. Availability of the current Digikala API could not be confirmed from the local test environment.
