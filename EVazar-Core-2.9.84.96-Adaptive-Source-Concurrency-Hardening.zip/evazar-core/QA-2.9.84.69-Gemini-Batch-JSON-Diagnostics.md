# QA — Core 2.9.84.69

- `php -l` is required for modified PHP files and the new regression test.
- Regression checks cover structured output schema, bounded response diagnostics, admin visibility, JSON parser diagnostics, and serial/parallel safe deferral.
- The malformed-output path must leave each affected queue row `pending`, clear its claim, set a future `next_attempt_at`, and not increment `retries`. The next attempt must get a different idempotency request ID so it cannot replay the same cached malformed response.
- Later independent chunks must continue after a completed HTTP-200 response with invalid JSON.
- No live WordPress, Cloudflare Worker, or Gemini API test is claimed by these local checks.
