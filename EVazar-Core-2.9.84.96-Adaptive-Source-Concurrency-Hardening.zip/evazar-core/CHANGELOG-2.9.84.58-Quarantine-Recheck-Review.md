# EVazar Core 2.9.84.58 — Quarantine Recheck Review

- Follow-up line-by-line review of category-path quarantine and all manual/automatic requeue paths.
- Configured automatic quarantine rechecks reset `retries=0`, starting a fresh retry generation instead of inheriting pre-quarantine retry history.
- Legacy migration no longer overwrites a populated `related_product_id` with zero.
- Every early queue return now includes quarantined items in the `processed` count, consistent with the final queue summary.
- Core behavior otherwise remains unchanged: only explicit missing source-category-path errors are quarantined; ordinary category/database sync errors stay retryable.
