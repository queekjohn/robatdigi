# EVazar Core 2.9.84.34 — Brand Source Registration Review Fixes
Date: 2026-10-25

- Fixed source-identity provenance recognition in `evazar_queue_term_source_identity_complete()`: verified brands created by the registration tool (`2.9.84.33-live-brand-registration`) and repaired under the newer 2.9.84.31/2.9.84.32 provenance stamps are now accepted by existing-item taxonomy synchronization.
- On successful brand creation, enqueue the new term through the existing independent taxonomy SEO queue, matching the normal importer behavior. This happens only after source metadata is written and read back successfully.
- Embedded Worker upgraded to 1.13.23: brand-source API failures are tagged as `X-Evazar-Error-Scope: source`, preventing upstream Digikala 429/5xx or missing identity responses from incorrectly cooling down a healthy Worker in the Core dispatcher.
- Worker enforces the 2 KiB JSON request limit against actual UTF-8 body bytes even if `Content-Length` is missing.
- Did not modify `cache-purge.php`, `product-index.php`, LiteSpeed cache settings/rules, or any direct cache-purge logic. Normal WordPress hooks still execute when a new `evazar_brand` term is created.
