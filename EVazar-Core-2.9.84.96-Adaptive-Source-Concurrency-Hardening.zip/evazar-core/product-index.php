<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Evazar Product Index 1.0
 * هدف: خارج کردن فیلتر/مرتب‌سازی‌های پرتکرار از wp_postmeta و فراهم‌کردن
 * یک ایندکس سریع و قابل توسعه برای 50k+ کالا.
 */
const EVAZAR_PRODUCT_INDEX_DB_VERSION = '1.3.0';

function evazar_product_index_table() {
    global $wpdb;
    return $wpdb->prefix . 'evazar_product_index';
}
function evazar_product_category_index_table() {
    global $wpdb;
    return $wpdb->prefix . 'evazar_product_category_index';
}

// Separate, title-token index for live search. Kept independent from the stock/facet index version.
const EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION = '1.0.0';

function evazar_product_search_index_documents_table() {
    global $wpdb;
    return $wpdb->prefix . 'evazar_product_search_index';
}

function evazar_product_search_index_terms_table() {
    global $wpdb;
    return $wpdb->prefix . 'evazar_product_search_terms';
}


/** Runtime-safe search options shared by the admin panel and front-end theme. */
function evazar_product_search_runtime_settings() {
    $min_chars = absint(get_option('evazar_search_min_chars', 2));
    if (!in_array($min_chars, [2, 3, 4], true)) $min_chars = 2;

    $debounce = absint(get_option('evazar_search_debounce_ms', 250));
    if (!in_array($debounce, [150, 250, 350, 500, 750], true)) $debounce = 250;

    $visible_products = absint(get_option('evazar_search_live_product_limit', 5));
    if (!in_array($visible_products, [3, 5, 8], true)) $visible_products = 5;

    $batch_size = absint(get_option('evazar_search_index_batch_size', 250));
    if (!in_array($batch_size, [100, 250, 500], true)) $batch_size = 250;

    return [
        'indexed_enabled' => get_option('evazar_search_indexed_enabled', '1') !== '0',
        'min_chars' => $min_chars,
        'debounce_ms' => $debounce,
        'live_product_limit' => $visible_products,
        'index_batch_size' => $batch_size,
    ];
}

function evazar_product_search_index_acceleration_enabled() {
    $settings = evazar_product_search_runtime_settings();
    return !empty($settings['indexed_enabled']);
}

function evazar_product_search_index_ensure_tables($force = false) {
    global $wpdb;
    $current = (string) get_option('evazar_product_search_index_db_version', '');
    if (!$force && $current === EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION) return true;

    $documents = evazar_product_search_index_documents_table();
    $terms = evazar_product_search_index_terms_table();
    $documents_exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($documents))) === $documents);
    $terms_exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($terms))) === $terms);
    $needs_rebuild = $current !== EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION || !$documents_exists || !$terms_exists;

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $charset = $wpdb->get_charset_collate();
    $sql_documents = "CREATE TABLE {$documents} (
        product_id bigint(20) unsigned NOT NULL,
        normalized_title varchar(512) NOT NULL DEFAULT '',
        index_version varchar(20) NOT NULL DEFAULT '1.0.0',
        updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (product_id),
        KEY index_version (index_version)
    ) {$charset};";
    $sql_terms = "CREATE TABLE {$terms} (
        product_id bigint(20) unsigned NOT NULL,
        token varchar(180) NOT NULL,
        PRIMARY KEY  (product_id, token),
        KEY token_product (token, product_id)
    ) {$charset};";
    dbDelta($sql_documents);
    dbDelta($sql_terms);

    if ($needs_rebuild) {
        update_option('evazar_product_search_index_state', 'building', false);
    }
    update_option('evazar_product_search_index_db_version', EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION, false);
    return true;
}

/** Normalize search text exactly enough to keep Persian/Arabic and numeric forms aligned with the theme. */
function evazar_product_search_index_normalize_text($text) {
    $text = wp_strip_all_tags((string) $text);
    $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
    $text = str_replace(
        ['ي','ى','ئ','ك','ة','ۀ','ؤ','أ','إ','آ','ٱ',"\u{200c}",'ـ'],
        ['ی','ی','ی','ک','ه','ه','و','ا','ا','ا','ا',' ',''],
        $text
    );
    $text = preg_replace('/[\\x{064B}-\\x{065F}\\x{0670}]/u', '', $text);
    $text = strtr($text, [
        '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
        '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
    ]);
    $text = preg_replace('/\\s+/u', ' ', $text);
    return mb_strtolower(trim((string) $text), 'UTF-8');
}

function evazar_product_search_index_tokenize($text) {
    $normalized = evazar_product_search_index_normalize_text($text);
    if ($normalized === '') return [];
    $parts = preg_split('/[^\\p{L}\\p{N}]+/u', $normalized, -1, PREG_SPLIT_NO_EMPTY);
    $tokens = [];
    foreach ((array) $parts as $part) {
        // One-digit terms such as model numbers remain searchable; one-letter noise is omitted.
        if (mb_strlen($part, 'UTF-8') < 2 && !preg_match('/^\\d$/u', $part)) continue;
        $part = mb_substr($part, 0, 180, 'UTF-8');
        if ($part !== '') $tokens[$part] = $part;
    }
    return array_values($tokens);
}

function evazar_product_search_index_is_ready() {
    return get_option('evazar_product_search_index_db_version') === EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION
        && get_option('evazar_product_search_index_state') === 'ready';
}

function evazar_product_search_index_mark_failure($post_id) {
    $post_id = absint($post_id);
    if (!$post_id) return;
    $now = time();
    $previous_retry = (int) get_post_meta($post_id, '_evazar_product_search_index_sync_next_retry', true);
    $previous_error = (string) get_post_meta($post_id, '_evazar_product_search_index_sync_error', true);
    $attempts = max(0, (int) get_post_meta($post_id, '_evazar_product_search_index_sync_attempts', true));
    // set_object_terms and save_post may call sync twice in one request; do not consume the retry budget twice.
    if ($previous_error === 'sync_failed' && $previous_retry > $now && $attempts > 0) {
        update_option('evazar_product_search_index_state', 'building', false);
        return;
    }
    $attempts = min(8, $attempts + 1);
    $delay = min(DAY_IN_SECONDS, 300 * (2 ** max(0, $attempts - 1)));
    update_post_meta($post_id, '_evazar_product_search_index_sync_error', 'sync_failed');
    update_post_meta($post_id, '_evazar_product_search_index_sync_attempts', $attempts);
    update_post_meta($post_id, '_evazar_product_search_index_sync_next_retry', $now + $delay);
    update_option('evazar_product_search_index_state', 'building', false);
}

function evazar_product_search_index_sync($post_id) {
    global $wpdb;
    $post_id = absint($post_id);
    if (!$post_id || get_post_type($post_id) !== 'evazar_product') return false;
    if (get_option('evazar_product_search_index_db_version') !== EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION) {
        evazar_product_search_index_ensure_tables();
    }
    $post = get_post($post_id);
    if (!$post) return false;

    $documents = evazar_product_search_index_documents_table();
    $terms = evazar_product_search_index_terms_table();
    $normalized_title = mb_substr(evazar_product_search_index_normalize_text($post->post_title), 0, 512, 'UTF-8');
    $existing_title = $wpdb->get_var($wpdb->prepare(
        "SELECT normalized_title FROM {$documents} WHERE product_id=%d AND index_version=%s LIMIT 1",
        $post_id, EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION
    ));
    if ($wpdb->last_error === '' && $existing_title !== null && (string)$existing_title === $normalized_title
        && get_post_meta($post_id, '_evazar_product_search_index_sync_error', true) === '') {
        return true;
    }
    $tokens = evazar_product_search_index_tokenize($normalized_title);

    // Add current tokens first; stale tokens are removed only after the document row is saved.
    if ($tokens) {
        foreach (array_chunk($tokens, 120) as $chunk) {
            $holders = [];
            $values = [];
            foreach ($chunk as $token) {
                $holders[] = '(%d,%s)';
                $values[] = $post_id;
                $values[] = $token;
            }
            $inserted = $wpdb->query($wpdb->prepare(
                "INSERT IGNORE INTO {$terms} (product_id, token) VALUES " . implode(',', $holders),
                ...$values
            ));
            if ($inserted === false) {
                evazar_product_search_index_mark_failure($post_id);
                error_log('[EVazar Product Search Index] Token insertion failed for product ID ' . $post_id . '.');
                return false;
            }
        }
    }

    $doc_result = $wpdb->replace($documents, [
        'product_id' => $post_id,
        'normalized_title' => $normalized_title,
        'index_version' => EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION,
    ], ['%d','%s','%s']);
    if ($doc_result === false) {
        evazar_product_search_index_mark_failure($post_id);
        error_log('[EVazar Product Search Index] Document update failed for product ID ' . $post_id . '.');
        return false;
    }

    if ($tokens) {
        $holders = implode(',', array_fill(0, count($tokens), '%s'));
        $delete_result = $wpdb->query($wpdb->prepare(
            "DELETE FROM {$terms} WHERE product_id=%d AND token NOT IN ({$holders})",
            ...array_merge([$post_id], $tokens)
        ));
    } else {
        $delete_result = $wpdb->delete($terms, ['product_id' => $post_id], ['%d']);
    }
    if ($delete_result === false) {
        evazar_product_search_index_mark_failure($post_id);
        error_log('[EVazar Product Search Index] Stale-token cleanup failed for product ID ' . $post_id . '.');
        return false;
    }

    delete_post_meta($post_id, '_evazar_product_search_index_sync_error');
    delete_post_meta($post_id, '_evazar_product_search_index_sync_attempts');
    delete_post_meta($post_id, '_evazar_product_search_index_sync_next_retry');
    return true;
}

/** Returns null when the index is not complete/usable, otherwise a bounded list of matching product IDs. */
function evazar_product_search_index_search_ids($query, $limit = 12, $brand_id = 0, $in_stock_only = false) {
    global $wpdb;
    if (!evazar_product_search_index_acceleration_enabled() || !evazar_product_search_index_is_ready()) return null;

    $normalized = evazar_product_search_index_normalize_text($query);
    $raw_tokens = preg_split('/[^\p{L}\p{N}]+/u', $normalized, -1, PREG_SPLIT_NO_EMPTY);
    foreach ((array) $raw_tokens as $raw_token) {
        if (mb_strlen($raw_token, 'UTF-8') < 2 && !preg_match('/^\d$/u', $raw_token)) return null;
    }
    $query_tokens = evazar_product_search_index_tokenize($normalized);
    if (!$query_tokens || count($query_tokens) > 6) return null;
    $query_tokens = array_values(array_unique($query_tokens));
    if (!$query_tokens) return null;

    $terms = evazar_product_search_index_terms_table();
    $documents = evazar_product_search_index_documents_table();
    $products = evazar_product_index_table();
    $posts = $wpdb->posts;
    $joins = " FROM {$terms} t0 INNER JOIN {$documents} d ON d.product_id=t0.product_id AND d.index_version=%s INNER JOIN {$posts} p ON p.ID=d.product_id ";
    $params = [EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION];
    for ($i = 1; $i < count($query_tokens); $i++) {
        $alias = 't' . $i;
        $joins .= " INNER JOIN {$terms} {$alias} ON {$alias}.product_id=t0.product_id AND {$alias}.token LIKE %s AND {$alias}.token<>t0.token ";
        $params[] = $wpdb->esc_like($query_tokens[$i]) . '%';
        for ($j = 1; $j < $i; $j++) {
            $prior = 't' . $j;
            $joins .= " AND {$alias}.token<>{$prior}.token ";
        }
    }

    $where = " WHERE p.post_type='evazar_product' AND p.post_status='publish' AND t0.token LIKE %s ";
    $params[] = $wpdb->esc_like($query_tokens[0]) . '%';
    // Avoid joining the broader facet index for ordinary title search; join it only when a facet is actually needed.
    if ($brand_id > 0 || $in_stock_only) {
        $joins .= " LEFT JOIN {$products} pi ON pi.product_id=p.ID ";
    }
    if ($brand_id > 0) {
        $where .= ' AND pi.brand_id=%d ';
        $params[] = absint($brand_id);
    }
    if ($in_stock_only) {
        $where .= ' AND pi.stock_status=1 ';
    }

    $limit = max(1, min(12, absint($limit)));
    $phrase_prefix = $wpdb->esc_like($normalized) . '%';
    $sql = "SELECT d.product_id, d.normalized_title, p.post_date {$joins} {$where}
            GROUP BY d.product_id, d.normalized_title, p.post_date
            ORDER BY MIN(CASE WHEN d.normalized_title=%s THEN 0 WHEN d.normalized_title LIKE %s THEN 1 ELSE 2 END) ASC,
                     p.post_date DESC, d.product_id DESC
            LIMIT %d";
    $params[] = $normalized;
    $params[] = $phrase_prefix;
    $params[] = $limit;
    $prepared = $wpdb->prepare($sql, ...$params);
    $rows = $wpdb->get_results($prepared);
    if ($wpdb->last_error !== '') {
        error_log('[EVazar Product Search Index] Search query failed; theme will use legacy search.');
        return null;
    }

    $ids = [];
    foreach ((array) $rows as $row) {
        $pid = (int) ($row->product_id ?? 0);
        $title = (string) ($row->normalized_title ?? '');
        if ($pid <= 0 || $title === '') continue;
        // Defensive validation avoids stale-token false positives during concurrent index refreshes.
        $title_tokens = evazar_product_search_index_tokenize($title);
        $matches = true;
        foreach ($query_tokens as $qtoken) {
            $found = false;
            foreach ($title_tokens as $ttoken) {
                if (strpos($ttoken, $qtoken) === 0) { $found = true; break; }
            }
            if (!$found) { $matches = false; break; }
        }
        if ($matches) $ids[] = $pid;
    }
    return array_values(array_unique($ids));
}

/**
 * Returns null when every published product has both current index rows, a positive ID
 * when work/errors remain, and false on SQL error. Used twice at readiness activation
 * so a concurrent sync failure cannot be overwritten by a stale `ready` decision.
 */
function evazar_product_search_index_find_remaining_published_product() {
    global $wpdb;
    $documents = evazar_product_search_index_documents_table();
    $products = $wpdb->posts;
    $remaining = $wpdb->get_var($wpdb->prepare(
        "SELECT p.ID FROM {$products} p
         LEFT JOIN {$documents} d ON d.product_id=p.ID AND d.index_version=%s
         LEFT JOIN " . evazar_product_index_table() . " i ON i.product_id=p.ID
         WHERE p.post_type='evazar_product' AND p.post_status='publish'
           AND (d.product_id IS NULL OR i.product_id IS NULL OR i.index_version<>%s
             OR EXISTS (
               SELECT 1 FROM {$wpdb->postmeta} pm_err
               WHERE pm_err.post_id=p.ID AND pm_err.meta_key='_evazar_product_search_index_sync_error'
             )
             OR EXISTS (
               SELECT 1 FROM {$wpdb->postmeta} pm_core_err
               WHERE pm_core_err.post_id=p.ID AND pm_core_err.meta_key='_evazar_product_index_sync_error'
             ))
         LIMIT 1",
        EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION, EVAZAR_PRODUCT_INDEX_DB_VERSION
    ));
    if ($wpdb->last_error !== '') {
        error_log('[EVazar Product Search Index] Completeness probe failed; index remains unavailable.');
        return false;
    }
    return ($remaining === null) ? null : absint($remaining);
}

function evazar_product_search_index_backfill_batch($limit = 250) {
    global $wpdb;
    $documents = evazar_product_search_index_documents_table();
    $terms = evazar_product_search_index_terms_table();
    $products = $wpdb->posts;
    $documents_exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($documents))) === $documents);
    $terms_exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($terms))) === $terms);
    if (get_option('evazar_product_search_index_db_version') !== EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION || !$documents_exists || !$terms_exists) {
        evazar_product_search_index_ensure_tables(true);
    }
    if (get_option('evazar_product_search_index_state') !== 'building') return 0;

    $now = time();
    $ids = $wpdb->get_results($wpdb->prepare(
        "SELECT p.ID, i.product_id AS indexed_product_id, i.index_version AS product_index_version,
           EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm_core_err_select
                   WHERE pm_core_err_select.post_id=p.ID AND pm_core_err_select.meta_key='_evazar_product_index_sync_error') AS has_core_sync_error
         FROM {$products} p
         LEFT JOIN {$documents} d ON d.product_id=p.ID AND d.index_version=%s
         LEFT JOIN " . evazar_product_index_table() . " i ON i.product_id=p.ID
         WHERE p.post_type='evazar_product' AND p.post_status='publish'
           AND (d.product_id IS NULL OR i.product_id IS NULL OR i.index_version<>%s
             OR EXISTS (
               SELECT 1 FROM {$wpdb->postmeta} pm_err
               WHERE pm_err.post_id=p.ID AND pm_err.meta_key='_evazar_product_search_index_sync_error'
             )
             OR EXISTS (
               SELECT 1 FROM {$wpdb->postmeta} pm_core_err
               WHERE pm_core_err.post_id=p.ID AND pm_core_err.meta_key='_evazar_product_index_sync_error'
             ))
           AND NOT EXISTS (
             SELECT 1 FROM {$wpdb->postmeta} pm_retry
             WHERE pm_retry.post_id=p.ID AND pm_retry.meta_key='_evazar_product_search_index_sync_next_retry'
               AND CAST(pm_retry.meta_value AS UNSIGNED) > %d
           )
           AND NOT EXISTS (
             SELECT 1 FROM {$wpdb->postmeta} pm_core_retry
             WHERE pm_core_retry.post_id=p.ID AND pm_core_retry.meta_key='_evazar_product_index_sync_next_retry'
               AND CAST(pm_core_retry.meta_value AS UNSIGNED) > %d
           )
         ORDER BY p.ID ASC LIMIT %d",
        EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION, EVAZAR_PRODUCT_INDEX_DB_VERSION, $now, $now, max(1, min(500, (int) $limit))
    ));
    if ($wpdb->last_error !== '') {
        error_log('[EVazar Product Search Index] Backfill selection failed; index remains in building state.');
        return 0;
    }
    $synced = 0;
    foreach ((array) $ids as $row) {
        $id = absint($row->ID ?? 0);
        if (!$id) continue;
        // Repair the canonical facet/identity index first if this product has no current row.
        if (empty($row->indexed_product_id)
            || (string)($row->product_index_version ?? '') !== EVAZAR_PRODUCT_INDEX_DB_VERSION
            || !empty($row->has_core_sync_error)) {
            // A canonical index error can coexist with a current-looking product row
            // (for example, a failed category-index write). Retry the canonical sync
            // after its backoff expires; refreshing search tokens alone cannot clear it.
            if (evazar_product_index_sync($id)) $synced++;
            continue; // successful Core sync also refreshed the search document
        }
        if (evazar_product_search_index_sync($id)) $synced++;
    }

    // A second completeness probe after the provisional ready write closes the race where
    // a concurrent product-index sync failure sets `building` between the first probe and
    // readiness activation. The failure writer stores its error marker before its state write.
    $remaining = evazar_product_search_index_find_remaining_published_product();
    if ($remaining !== false) {
        $ready = ($remaining === null);
        update_option('evazar_product_search_index_state', $ready ? 'ready' : 'building', false);
        if ($ready) {
            $verification = evazar_product_search_index_find_remaining_published_product();
            if ($verification !== null) {
                // Includes a positive product ID or a DB error (`false`); both fail closed.
                $ready = false;
                update_option('evazar_product_search_index_state', 'building', false);
            }
        }
        update_option('evazar_product_search_index_backfill_last_run', [
            'time' => time(), 'synced' => $synced, 'ready' => $ready,
        ], false);
    }
    return $synced;
}

/** Exact DKP/SKU lookup via the Core's indexed dkp/sku columns. Null means fallback is required. */
function evazar_product_index_find_identifier_ids($values, $limit = 12, $in_stock_only = false) {
    global $wpdb;
    if (!evazar_product_search_index_acceleration_enabled() || !evazar_product_search_index_is_ready() || !function_exists('evazar_product_index_exists') || !evazar_product_index_exists()) return null;
    $values = array_values(array_unique(array_filter(array_map(static function($value) {
        return trim(sanitize_text_field((string)$value));
    }, (array)$values), static function($value) { return $value !== ''; })));
    if (!$values) return [];

    $table = evazar_product_index_table();
    $placeholders = implode(',', array_fill(0, count($values), '%s'));
    $sql = "SELECT i.product_id FROM {$table} i
            INNER JOIN {$wpdb->posts} p ON p.ID=i.product_id
            WHERE p.post_type='evazar_product' AND p.post_status='publish'
              AND (i.dkp IN ({$placeholders}) OR i.sku IN ({$placeholders}))";
    $params = array_merge($values, $values);
    if ($in_stock_only) $sql .= ' AND i.stock_status=1';
    $sql .= ' ORDER BY CASE WHEN i.dkp IN (' . $placeholders . ') THEN 0 ELSE 1 END ASC, p.post_date DESC, i.product_id DESC LIMIT %d';
    $params = array_merge($params, $values, [max(1, min(12, absint($limit)))]);
    $ids = $wpdb->get_col($wpdb->prepare($sql, ...$params));
    if ($wpdb->last_error !== '') return null;
    $positive_ids = [];
    foreach ((array)$ids as $raw_id) {
        $id = (int)$raw_id;
        if ($id > 0) $positive_ids[] = $id;
    }
    return array_values(array_unique($positive_ids));
}

function evazar_product_search_index_delete($post_id) {
    global $wpdb;
    $post_id = absint($post_id);
    if (!$post_id) return;
    $wpdb->delete(evazar_product_search_index_terms_table(), ['product_id' => $post_id], ['%d']);
    $wpdb->delete(evazar_product_search_index_documents_table(), ['product_id' => $post_id], ['%d']);
}

function evazar_product_index_ensure_tables() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $charset = $wpdb->get_charset_collate();
    $products = evazar_product_index_table();
    $categories = evazar_product_category_index_table();
    $sql1 = "CREATE TABLE {$products} (
        product_id bigint(20) unsigned NOT NULL,
        dkp varchar(64) NOT NULL DEFAULT '',
        sku varchar(64) NOT NULL DEFAULT '',
        brand_id bigint(20) unsigned NOT NULL DEFAULT 0,
        price decimal(18,2) NOT NULL DEFAULT 0,
        old_price decimal(18,2) NOT NULL DEFAULT 0,
        discount smallint unsigned NOT NULL DEFAULT 0,
        stock_status tinyint NOT NULL DEFAULT 0,
        availability_source varchar(32) NOT NULL DEFAULT '',
        stock_checked_at bigint(20) unsigned NOT NULL DEFAULT 0,
        views bigint(20) unsigned NOT NULL DEFAULT 0,
        rating decimal(4,2) NOT NULL DEFAULT 0,
        rating_count bigint(20) unsigned NOT NULL DEFAULT 0,
        satisfaction smallint unsigned NOT NULL DEFAULT 0,
        post_date datetime NULL DEFAULT NULL,
        updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        index_version varchar(20) NOT NULL DEFAULT '1.2.1',
        PRIMARY KEY (product_id),
        KEY dkp (dkp),
        KEY sku (sku),
        KEY brand_id (brand_id),
        KEY price (price),
        KEY stock_status (stock_status),
        KEY availability_source (availability_source),
        KEY stock_checked_at (stock_checked_at),
        KEY rating (rating),
        KEY satisfaction (satisfaction),
        KEY post_date (post_date),
        KEY stock_price (stock_status, price),
        KEY stock_date (stock_status, post_date),
        KEY stock_views (stock_status, views),
        KEY stock_rating (stock_status, rating_count),
        KEY stock_satisfaction (stock_status, satisfaction)
    ) {$charset};";
    $sql2 = "CREATE TABLE {$categories} (
        product_id bigint(20) unsigned NOT NULL,
        category_id bigint(20) unsigned NOT NULL,
        PRIMARY KEY (product_id, category_id),
        KEY category_id (category_id),
        KEY product_id (product_id)
    ) {$charset};";
    dbDelta($sql1);
    dbDelta($sql2);
    update_option('evazar_product_index_db_version', EVAZAR_PRODUCT_INDEX_DB_VERSION, false);
    evazar_product_search_index_ensure_tables(true);
}

function evazar_product_index_maybe_upgrade() {
    if (get_option('evazar_product_index_db_version') !== EVAZAR_PRODUCT_INDEX_DB_VERSION) {
        evazar_product_index_ensure_tables();
    }
    if (get_option('evazar_product_search_index_db_version') !== EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION) {
        evazar_product_search_index_ensure_tables();
    }
}

function evazar_product_index_schedule_backfill() {
    $event = wp_get_scheduled_event('evazar_product_index_backfill');
    if (!$event) {
        wp_schedule_event(time() + 120, 'evazar_stock_5min', 'evazar_product_index_backfill');
    }
}
function evazar_product_index_clear_schedule() {
    $timestamp = wp_next_scheduled('evazar_product_index_backfill');
    while ($timestamp) {
        wp_unschedule_event($timestamp, 'evazar_product_index_backfill');
        $timestamp = wp_next_scheduled('evazar_product_index_backfill');
    }
}
add_action('init', function() {
    if (function_exists('evazar_product_index_schedule_backfill')) {
        evazar_product_index_schedule_backfill();
    }
}, 21);

function evazar_product_index_normalize_number($value) {
    $raw = (string)$value;
    $raw = str_replace(['٬', ',', '،', ' '], '', $raw);
    $raw = strtr($raw, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
    return is_numeric($raw) ? (float)$raw : 0.0;
}

function evazar_product_index_availability_source_for_post($post_id) {
    $source = sanitize_key((string)get_post_meta($post_id, '_evazar_availability_source', true));
    $allowed = ['explicit_unavailable','explicit_available','fallback'];
    return in_array($source, $allowed, true) ? $source : '';
}

function evazar_product_index_stock_status_for_post($post_id) {
    $price = evazar_product_index_normalize_number(get_post_meta($post_id, '_evazar_current_price', true));
    $source = evazar_product_index_availability_source_for_post($post_id);
    if ($source === 'explicit_unavailable') return 0;
    return $price > 0 ? 1 : 0;
}


function evazar_product_index_mark_sync_failure($post_id, $code) {
    $post_id = absint($post_id);
    if (!$post_id) return;
    $code = sanitize_key((string) $code);
    // Search fast-path filters and exact identifiers depend on the canonical Core index too.
    // Persist the error marker before changing readiness, so a concurrent completion probe
    // either sees this marker or is followed by this final fail-closed state write.
    $now = time();
    $previous_code = (string) get_post_meta($post_id, '_evazar_product_index_sync_error', true);
    $previous_retry = (int) get_post_meta($post_id, '_evazar_product_index_sync_next_retry', true);
    $attempts = max(0, (int) get_post_meta($post_id, '_evazar_product_index_sync_attempts', true));

    // Repeated save hooks in one request must not consume the retry budget or keep pushing backoff forward.
    if ($previous_code === $code && $previous_retry > $now && $attempts > 0) {
        update_option('evazar_product_search_index_state', 'building', false);
        return;
    }

    $attempts = min(5, $attempts + 1);
    $delay = min(DAY_IN_SECONDS, 300 * (2 ** max(0, $attempts - 1)));
    update_post_meta($post_id, '_evazar_product_index_sync_error', $code);
    update_post_meta($post_id, '_evazar_product_index_sync_attempts', $attempts);
    update_post_meta($post_id, '_evazar_product_index_sync_next_retry', $now + $delay);
    update_option('evazar_product_search_index_state', 'building', false);
}

function evazar_product_index_clear_sync_failure($post_id) {
    $post_id = absint($post_id);
    if (!$post_id) return;
    delete_post_meta($post_id, '_evazar_product_index_sync_error');
    delete_post_meta($post_id, '_evazar_product_index_sync_attempts');
    delete_post_meta($post_id, '_evazar_product_index_sync_next_retry');
}

/**
 * همگام‌سازی سبک وضعیت لحظه‌ای کالا با Product Index.
 *
 * این مسیر فقط فیلدهایی را که Live Inquiry تغییر می‌دهد به‌روزرسانی می‌کند
 * و عمداً سراغ taxonomy/category sync نمی‌رود تا فشار DB حداقل باشد.
 */
function evazar_product_index_sync_live_status($post_id) {
    global $wpdb;
    $post_id = absint($post_id);
    if (!$post_id || get_post_type($post_id) !== 'evazar_product') return false;
    if (!evazar_product_index_exists()) {
        evazar_product_index_mark_sync_failure($post_id, 'index_table_missing');
        return false;
    }

    $products = evazar_product_index_table();
    $price = evazar_product_index_normalize_number(get_post_meta($post_id, '_evazar_current_price', true));
    $old_price = evazar_product_index_normalize_number(get_post_meta($post_id, '_evazar_old_price', true));
    $discount = max(0, (int) evazar_product_index_normalize_number(get_post_meta($post_id, '_evazar_discount_percent', true)));
    $stock = evazar_product_index_stock_status_for_post($post_id);
    $source = evazar_product_index_availability_source_for_post($post_id);
    $checked = max(0, (int) get_post_meta($post_id, '_evazar_last_stock_check', true));

    $update_result = $wpdb->query($wpdb->prepare(
        "UPDATE {$products}
         SET price=%f,
             old_price=%f,
             discount=%d,
             stock_status=%d,
             availability_source=%s,
             stock_checked_at=%d,
             updated_at=NOW()
         WHERE product_id=%d",
        $price, $old_price, $discount, $stock, $source, $checked, $post_id
    ));
    if ($update_result === false) {
        evazar_product_index_mark_sync_failure($post_id, 'live_status_update_failed');
        error_log('[EVazar Product Index] Live-status SQL update failed for product ID ' . $post_id . '.');
        return false;
    }

    // صفر ردیف تغییرکرده می‌تواند به معنی یکسان بودن داده‌ها یا نبودن ردیف باشد؛ تفکیک می‌کنیم.
    if ((int) $wpdb->rows_affected === 0) {
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT product_id FROM {$products} WHERE product_id=%d LIMIT 1",
            $post_id
        ));
        if ($wpdb->last_error !== '') {
            evazar_product_index_mark_sync_failure($post_id, 'live_status_existence_check_failed');
            error_log('[EVazar Product Index] Live-status existence check failed for product ID ' . $post_id . '.');
            return false;
        }
        if ($exists === null) {
            return evazar_product_index_sync($post_id);
        }
    }

    do_action('evazar_product_index_synced', $post_id);
    return true;
}

function evazar_product_index_sync($post_id) {
    global $wpdb;
    $post_id = absint($post_id);
    if (!$post_id || get_post_type($post_id) !== 'evazar_product') return false;
    $post = get_post($post_id);
    if (!$post) return false;
    $products = evazar_product_index_table();
    $categories = evazar_product_category_index_table();

    $dkp = get_post_meta($post_id, '_evazar_sku', true) ?: get_post_meta($post_id, '_sku', true);
    if (!$dkp) $dkp = get_post_meta($post_id, '_evazar_dk_id', true); // legacy product identity
    if (!$dkp) {
        $url = get_post_meta($post_id, '_evazar_dk_url', true);
        if ($url && preg_match('/dkp-(\d+)/i', $url, $m)) $dkp = $m[1];
    }
    $dkp = trim((string) $dkp);
    if (preg_match('/(?:^|\b)DKP\s*[-:#]?\s*(\d+)\b/i', $dkp, $legacy_match)) {
        $dkp = $legacy_match[1];
    }
    $sku = (string)($dkp ?: get_post_meta($post_id, '_sku', true));
    $brand_id = 0;
    $brand_terms = wp_get_object_terms($post_id, 'evazar_brand', ['fields'=>'ids']);
    if (is_wp_error($brand_terms)) {
        evazar_product_index_mark_sync_failure($post_id, 'brand_term_lookup_failed');
        error_log('[EVazar Product Index] Brand-term lookup failed for product ID ' . $post_id . '; index sync stopped before writing.');
        return false;
    }
    if (!empty($brand_terms)) $brand_id = (int)$brand_terms[0];
    $category_ids = wp_get_object_terms($post_id, 'evazar_category', ['fields'=>'ids']);
    if (is_wp_error($category_ids)) {
        evazar_product_index_mark_sync_failure($post_id, 'category_term_lookup_failed');
        error_log('[EVazar Product Index] Category-term lookup failed for product ID ' . $post_id . '; index sync stopped before writing.');
        return false;
    }

    $stock = evazar_product_index_stock_status_for_post($post_id);
    $availability_source = evazar_product_index_availability_source_for_post($post_id);
    $stock_checked = (int)get_post_meta($post_id, '_evazar_last_stock_check', true);
    $data = [
        'product_id'=>(int)$post_id,
        'dkp'=>sanitize_text_field((string)$dkp),
        'sku'=>sanitize_text_field((string)$sku),
        'brand_id'=>$brand_id,
        'price'=>evazar_product_index_normalize_number(get_post_meta($post_id,'_evazar_current_price',true)),
        'old_price'=>evazar_product_index_normalize_number(get_post_meta($post_id,'_evazar_old_price',true)),
        'discount'=>max(0,(int)evazar_product_index_normalize_number(get_post_meta($post_id,'_evazar_discount_percent',true))),
        'stock_status'=>$stock,
        'availability_source'=>$availability_source,
        'stock_checked_at'=>max(0,$stock_checked),
        'views'=>max(0,(int)get_post_meta($post_id,'_evazar_views_count',true)),
        'rating'=>evazar_product_index_normalize_number(get_post_meta($post_id,'_evazar_rating',true)),
        'rating_count'=>max(0,(int)get_post_meta($post_id,'_evazar_rating_count',true)),
        'satisfaction'=>max(0,(int)get_post_meta($post_id,'_evazar_satisfaction',true)),
        'post_date'=>($post->post_date && $post->post_date !== '0000-00-00 00:00:00') ? $post->post_date : null,
        'index_version'=>EVAZAR_PRODUCT_INDEX_DB_VERSION,
    ];
    $replace_result = $wpdb->replace($products, $data, ['%d','%s','%s','%d','%f','%f','%d','%d','%s','%d','%d','%f','%d','%d','%s','%s']);
    if ($replace_result === false) {
        evazar_product_index_mark_sync_failure($post_id, 'product_row_replace_failed');
        error_log('[EVazar Product Index] Product-index REPLACE failed for product ID ' . $post_id . '.');
        return false;
    }

    // ابتدا رابطه‌های فعلی را اضافه می‌کنیم؛ فقط پس از موفقیت INSERT رابطه‌های منسوخ حذف می‌شوند.
    // در صورت خطای درج، دسته‌های قبلی باقی می‌مانند و ایندکس خالی نمی‌شود.
    $normalized_category_ids = array_values(array_unique(array_filter(array_map('absint', (array) $category_ids))));
    if ($normalized_category_ids) {
        $values = [];
        $placeholders = [];
        foreach ($normalized_category_ids as $cid) {
            $placeholders[] = '(%d,%d)';
            $values[] = $post_id;
            $values[] = $cid;
        }
        $insert_result = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO {$categories} (product_id, category_id) VALUES " . implode(',', $placeholders),
            ...$values
        ));
        if ($insert_result === false) {
            evazar_product_index_mark_sync_failure($post_id, 'category_index_insert_failed');
            error_log('[EVazar Product Index] Category-index insert failed for product ID ' . $post_id . '; existing category relationships were preserved.');
            return false;
        }

        $not_in = implode(',', array_fill(0, count($normalized_category_ids), '%d'));
        $delete_sql = $wpdb->prepare(
            "DELETE FROM {$categories} WHERE product_id=%d AND category_id NOT IN ({$not_in})",
            ...array_merge([$post_id], $normalized_category_ids)
        );
        $delete_result = $wpdb->query($delete_sql);
    } else {
        // خالی بودن آرایه تنها پس از موفقیت خواندن taxonomy تایید شده است.
        $delete_result = $wpdb->delete($categories, ['product_id'=>$post_id], ['%d']);
    }
    if ($delete_result === false) {
        evazar_product_index_mark_sync_failure($post_id, 'category_index_cleanup_failed');
        error_log('[EVazar Product Index] Stale category-index cleanup failed for product ID ' . $post_id . '; current category relationships were kept.');
        return false;
    }
    // Search index has its own readiness state and backfill; its transient failure must not corrupt stock/facet sync status.
    if (function_exists('evazar_product_search_index_sync')) {
        evazar_product_search_index_sync($post_id);
    }
    evazar_product_index_clear_sync_failure($post_id);
    do_action('evazar_product_index_synced', $post_id);
    return true;
}

add_action('set_object_terms', function($object_id, $terms, $tt_ids, $taxonomy) {
    if (get_post_type($object_id) === 'evazar_product' && in_array($taxonomy, ['evazar_category','evazar_brand'], true)) {
        evazar_product_index_sync((int)$object_id);
    }
}, 20, 4);
add_action('save_post_evazar_product', function($post_id, $post, $update) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id)) return;
    evazar_product_index_sync((int)$post_id);
}, 20, 3);

function evazar_product_index_backfill_batch($limit = 250) {
    global $wpdb;
    $products = evazar_product_index_table();
    $categories = evazar_product_category_index_table();

    // Cheap checks every batch; full dbDelta runs only if version or table state requires it.
    $products_exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($products))) === $products);
    $categories_exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($categories))) === $categories);
    if (get_option('evazar_product_index_db_version') !== EVAZAR_PRODUCT_INDEX_DB_VERSION || !$products_exists || !$categories_exists) {
        evazar_product_index_ensure_tables();
    }

    $ids = $wpdb->get_col($wpdb->prepare(
        "SELECT p.ID
         FROM {$wpdb->posts} p
         LEFT JOIN {$products} i ON i.product_id=p.ID AND i.index_version=%s
         WHERE p.post_type='evazar_product' AND p.post_status='publish'
           AND (
             (i.product_id IS NULL AND NOT EXISTS (
                SELECT 1 FROM {$wpdb->postmeta} pm_failed
                WHERE pm_failed.post_id=p.ID AND pm_failed.meta_key='_evazar_product_index_sync_error'
             ))
             OR EXISTS (
                SELECT 1 FROM {$wpdb->postmeta} pm_sync_err
                WHERE pm_sync_err.post_id=p.ID AND pm_sync_err.meta_key='_evazar_product_index_sync_error'
                  AND COALESCE((SELECT CAST(pm_retry.meta_value AS UNSIGNED) FROM {$wpdb->postmeta} pm_retry WHERE pm_retry.post_id=p.ID AND pm_retry.meta_key='_evazar_product_index_sync_next_retry' ORDER BY pm_retry.meta_id ASC LIMIT 1),0) <= %d
                  AND COALESCE((SELECT CAST(pm_tries.meta_value AS UNSIGNED) FROM {$wpdb->postmeta} pm_tries WHERE pm_tries.post_id=p.ID AND pm_tries.meta_key='_evazar_product_index_sync_attempts' ORDER BY pm_tries.meta_id ASC LIMIT 1),0) < 5
             )
           )
         ORDER BY p.ID ASC LIMIT %d",
        EVAZAR_PRODUCT_INDEX_DB_VERSION, time(), max(1, min(500, (int) $limit))
    ));
    if ($wpdb->last_error !== '') {
        error_log('[EVazar Product Index] Backfill selection failed; no rows will be synced in this batch.');
        return 0;
    }
    $synced = 0;
    foreach ((array) $ids as $id) {
        if (evazar_product_index_sync((int) $id)) $synced++;
    }
    return $synced;
}
add_action('evazar_product_index_backfill', function() {
    evazar_product_index_backfill_batch(250);
    $search_settings = function_exists('evazar_product_search_runtime_settings') ? evazar_product_search_runtime_settings() : ['index_batch_size' => 250];
    evazar_product_search_index_backfill_batch((int) ($search_settings['index_batch_size'] ?? 250));
});

add_action('before_delete_post', function($post_id) {
    if (get_post_type($post_id) === 'evazar_product') {
        evazar_product_search_index_delete((int) $post_id);
    }
}, 20);

/**
 * Canonical Related Product Engine.
 *
 * Theme should only render the returned IDs. Product selection is based on the
 * Core Product Index so availability and ranking have one source of truth.
 */
function evazar_get_related_product_ids($post_id, $limit = 4, $hide_outofstock = true, $offset = 0) {
    global $wpdb;

    $post_id = absint($post_id);
    $limit = max(1, min(50, (int)$limit));
    // Offset represents the position in the final ranked list, not a SQL candidate window.
    // Keep pagination bounded so a public AJAX request cannot force a deep unbounded scan.
    $offset = max(0, (int)$offset);
    if (!$post_id || get_post_type($post_id) !== 'evazar_product') return [];
    if (!evazar_product_index_exists()) return [];
    $max_ranked_candidates = 500;
    if ($offset >= $max_ranked_candidates) return [];

    // A short-lived per-product cache avoids re-running the aggregate/sort for every
    // scroll batch. Common visits cache 120 IDs; the window expands only when a visitor
    // scrolls deeper. This bounds both SQL output and transient size for high traffic.
    $cache_key = 'evazar_rel_rank_' . md5($post_id . ':' . ($hide_outofstock ? '1' : '0'));
    $required_count = min($max_ranked_candidates, $offset + $limit);
    $cache_payload = get_transient($cache_key);
    if (is_array($cache_payload) && isset($cache_payload['ids'], $cache_payload['complete']) && is_array($cache_payload['ids'])) {
        $cached_ids = array_values(array_unique(array_filter(array_map('absint', $cache_payload['ids']))));
        $cache_complete = !empty($cache_payload['complete']);
        if ($cache_complete || count($cached_ids) >= $required_count) {
            return array_slice($cached_ids, $offset, $limit);
        }
    }
    $candidate_limit = min($max_ranked_candidates, max(120, $offset + $limit + 12));

    $products = evazar_product_index_table();
    $categories = evazar_product_category_index_table();
    $posts = $wpdb->posts;

    $current_category_ids = wp_get_object_terms($post_id, 'evazar_category', ['fields'=>'ids']);
    if (is_wp_error($current_category_ids)) $current_category_ids = [];
    $current_category_ids = array_values(array_unique(array_filter(array_map('absint', (array)$current_category_ids))));

    $deepest_category_id = 0;
    $deepest_depth = -1;
    foreach ($current_category_ids as $category_id) {
        $depth = count((array)get_ancestors($category_id, 'evazar_category'));
        if ($depth > $deepest_depth) {
            $deepest_depth = $depth;
            $deepest_category_id = $category_id;
        }
    }

    $exact_category_ids = $current_category_ids;
    if ($deepest_category_id > 0) {
        $children = get_term_children($deepest_category_id, 'evazar_category');
        if (!is_wp_error($children)) $exact_category_ids = array_merge($exact_category_ids, array_map('absint', (array)$children));
    }
    $exact_category_ids = array_values(array_unique(array_filter(array_map('absint', $exact_category_ids))));

    $branch_category_ids = [];
    if ($deepest_category_id > 0) {
        $deepest_term = get_term($deepest_category_id, 'evazar_category');
        $branch_root_id = ($deepest_term && !is_wp_error($deepest_term) && !empty($deepest_term->parent))
            ? absint($deepest_term->parent)
            : $deepest_category_id;
        if ($branch_root_id > 0) {
            $branch_category_ids[] = $branch_root_id;
            $branch_children = get_term_children($branch_root_id, 'evazar_category');
            if (!is_wp_error($branch_children)) $branch_category_ids = array_merge($branch_category_ids, array_map('absint', (array)$branch_children));
        }
    }
    $branch_category_ids = array_values(array_unique(array_filter(array_map('absint', $branch_category_ids))));

    $brand_id = 0;
    $brand_terms = wp_get_object_terms($post_id, 'evazar_brand', ['fields'=>'ids']);
    if (!is_wp_error($brand_terms) && !empty($brand_terms)) $brand_id = absint($brand_terms[0]);
    if ($brand_id <= 0) {
        $brand_name = trim((string)get_post_meta($post_id, '_evazar_brand', true));
        if ($brand_name !== '') {
            $brand_term = get_term_by('name', $brand_name, 'evazar_brand');
            if (!$brand_term) $brand_term = get_term_by('slug', sanitize_title($brand_name), 'evazar_brand');
            if ($brand_term && !is_wp_error($brand_term)) $brand_id = absint($brand_term->term_id);
        }
    }

    $score_parts = ['0'];
    $score_params = [];

    if ($exact_category_ids) {
        $ph = implode(',', array_fill(0, count($exact_category_ids), '%d'));
        $score_parts[] = "CASE WHEN SUM(CASE WHEN cat_idx.category_id IN ({$ph}) THEN 1 ELSE 0 END) > 0 THEN 120 ELSE 0 END";
        foreach ($exact_category_ids as $id) $score_params[] = $id;
    }
    if ($current_category_ids) {
        $ph = implode(',', array_fill(0, count($current_category_ids), '%d'));
        $score_parts[] = "LEAST(60, SUM(CASE WHEN cat_idx.category_id IN ({$ph}) THEN 25 ELSE 0 END))";
        foreach ($current_category_ids as $id) $score_params[] = $id;
    }
    if ($branch_category_ids) {
        $ph = implode(',', array_fill(0, count($branch_category_ids), '%d'));
        $score_parts[] = "CASE WHEN SUM(CASE WHEN cat_idx.category_id IN ({$ph}) THEN 1 ELSE 0 END) > 0 THEN 25 ELSE 0 END";
        foreach ($branch_category_ids as $id) $score_params[] = $id;
    }
    if ($brand_id > 0) {
        $score_parts[] = 'CASE WHEN idx.brand_id = %d THEN 70 ELSE 0 END';
        $score_params[] = $brand_id;
    }

    $where = [
        "p.post_type = 'evazar_product'",
        "p.post_status = 'publish'",
        $wpdb->prepare('p.ID <> %d', $post_id),
    ];
    if ($hide_outofstock) $where[] = 'idx.stock_status = 1';

    $score_sql = '(' . implode(' + ', $score_parts) . ')';
    $sql = "SELECT idx.product_id, {$score_sql} AS relevance_score, idx.post_date
            FROM {$products} idx
            INNER JOIN {$posts} p ON p.ID = idx.product_id
            LEFT JOIN {$categories} cat_idx ON cat_idx.product_id = idx.product_id
            WHERE " . implode(' AND ', $where) . "
            GROUP BY idx.product_id
            ORDER BY relevance_score DESC, idx.post_date DESC, idx.product_id DESC
            LIMIT %d";

    // Retrieve the ranked window once (at most 500 IDs), cache it briefly, and apply
    // page offsets in PHP. Older three-argument callers still receive the first page.
    $rows = $wpdb->get_results($wpdb->prepare($sql, ...array_merge($score_params, [$candidate_limit])));
    if ($wpdb->last_error !== '') {
        error_log('[EVazar Product Index] Related-product ranking query failed; returning no related IDs.');
        return [];
    }

    $ranked_ids = [];
    foreach ((array)$rows as $row) {
        $id = absint($row->product_id ?? 0);
        if ($id > 0 && $id !== $post_id) $ranked_ids[] = $id;
    }
    $ranked_ids = array_values(array_unique($ranked_ids));
    $cache_payload = [
        'ids' => $ranked_ids,
        // Fewer rows than the requested SQL window proves there are no more candidates.
        'complete' => count((array)$rows) < $candidate_limit,
    ];
    set_transient($cache_key, $cache_payload, 12 * HOUR_IN_SECONDS);

    return array_slice($ranked_ids, $offset, $limit);
}

function evazar_product_index_exists() {
    global $wpdb;
    static $exists = null;
    if ($exists !== null) return $exists;
    $table = evazar_product_index_table();
    $exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table);
    return $exists;
}
