# Safe Upgrade — EVazar Core 2.9.84.34 / Worker 1.13.23

## Deployment order
1. Deploy Worker 1.13.23's `digikala-worker.js` to **every primary Digikala Worker configured in Core**. Set `EVAZAR_INTERNAL_TOKEN` on each Worker to match Core's `evazar_cf_worker_token`.
2. Install/upgrade Core from this ZIP.
3. In WordPress, open **Tools → ثبت برند از لینک دیجی‌کالا**, preview a known source URL, verify the returned identity fields, then explicitly confirm.

## Scope
- Server-to-Worker flow uses the existing authenticated primary Worker pool; the browser does not call Digikala or Worker directly.
- New brands are created only after fresh identity is fetched twice (preview and confirmation) and conflict checks pass.
- No product assignment, existing term mutation, redirect writes, or direct cache-purge call. Existing WordPress hooks run normally on term creation.
- The new term is added to the existing taxonomy SEO queue after metadata read-back verification.
- Queue provenance allowlist recognizes trusted 2.9.84.31, 2.9.84.32 and registration stamps.
- If the Worker route/API is unavailable or identity is incomplete/conflicting, registration fails closed.
