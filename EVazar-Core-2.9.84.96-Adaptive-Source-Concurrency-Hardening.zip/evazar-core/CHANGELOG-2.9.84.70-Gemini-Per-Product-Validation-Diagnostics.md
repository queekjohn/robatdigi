# EVazar Core 2.9.84.70 — Gemini Per-Product Validation Diagnostics

- Preserve up to 64,000 bytes of model output per diagnostic (previously 12,000), while retaining the 20-entry cap and non-autoloaded option storage.
- Record a specific validation reason for each invalid DKP: missing item, missing review field, non-string review, empty review, or duplicate DKP.
- Show per-DKP reasons in the Gemini operations report so an administrator can distinguish omitted output from malformed item content.
- Keep the existing structured JSON request, queue deferral behavior, and batch size unchanged; this is diagnostic-only and does not reduce product batch size.
- No Worker changes.
