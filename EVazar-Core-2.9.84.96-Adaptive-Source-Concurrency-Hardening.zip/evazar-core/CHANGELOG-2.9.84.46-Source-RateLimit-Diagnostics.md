# EVazar Core 2.9.84.46 — Source Failure Diagnostics and Queue Backoff

- Preserve the upstream source error code, v1/v2 HTTP statuses, upstream network diagnostics, Worker version, and `Retry-After` from source-scoped Worker responses.
- Persist the source diagnostic fields in lightweight import logs instead of replacing all details with a generic source-unavailable message.
- Stop the current claimed queue run on an explicit source-scoped failure. Return all still-claimed/unsubmitted rows to `pending` with a bounded `next_attempt_at`; do not increment Retry counts.
- Keep product-specific 404 and Gemini errors on their existing paths. Do not touch cache behavior.
- Embedded Worker bumped to 1.13.25. See the standalone Worker package for the upstream fallback guard.
