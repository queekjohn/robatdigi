# EVazar Core 2.9.84.77 — Product Search Index

- Adds a separate title-token index for live product search, independent of stock/facet index versioning.
- Syncs normalized title tokens on product saves and taxonomy-driven index syncs.
- Builds the index in bounded background batches; indexed search is enabled only after every published product has a current document row.
- Keeps a legacy WP_Query fallback until the index is ready and whenever indexed results are insufficient or unsupported filters are requested.
- Uses indexed title-token prefix matching and the existing product index for optional in-stock/brand constraints.
- Removes per-keystroke live-AJAX search-stat writes; the search results page continues recording submitted searches.
- No Worker, page-cache purge, filter UI, or category archive query changes.
