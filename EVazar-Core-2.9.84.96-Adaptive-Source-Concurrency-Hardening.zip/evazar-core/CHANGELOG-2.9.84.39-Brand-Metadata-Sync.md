# EVazar Core 2.9.84.39 — Brand Metadata Sync

- After successful `evazar_brand` assignment, synchronize legacy `_evazar_brand` and `_evazar_brand_en` from the authoritative selected term when a primary term can be identified.
- Explicitly clearing all brand terms removes stale scalar brand metadata.
- Multi-term assignments preserve a primary only when existing metadata uniquely identifies one assigned term; otherwise ambiguous scalar metadata is cleared.
- Idempotent selector saves also run metadata reconciliation, so stale values can repair even when term IDs already match.
- No cache-purge implementation, LiteSpeed handling, Worker code, or import/redirect logic was changed.
