<?php
/**
 * Admin-only, conservative repair of missing Digikala brand source metadata.
 * Metadata-only: never changes term names/slugs, product assignments, redirect map, cache, or Worker code.
 */
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', 'evazar_bsmr_register_menu', 99);
add_action('wp_ajax_evazar_bsmr_list_candidates', 'evazar_bsmr_ajax_list_candidates');
add_action('wp_ajax_evazar_bsmr_analyze_one', 'evazar_bsmr_ajax_analyze_one');
add_action('wp_ajax_evazar_bsmr_apply_batch', 'evazar_bsmr_ajax_apply_batch');

function evazar_bsmr_register_menu() {
    $parent = post_type_exists('evazar_product') ? 'edit.php?post_type=evazar_product' : 'tools.php';
    add_submenu_page($parent, 'بررسی و ترمیم متادیتای برندها', 'ترمیم متادیتای برندها', 'manage_options', 'evazar-brand-source-repair', 'evazar_bsmr_render_page');
}

function evazar_bsmr_normalize_identity($value) {
    $value = html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if (class_exists('Normalizer')) {
        $normalized = Normalizer::normalize($value, Normalizer::FORM_KC);
        if (is_string($normalized)) $value = $normalized;
    }
    $value = strtr($value, array('ي'=>'ی', 'ى'=>'ی', 'ك'=>'ک', "\xE2\x80\x8C"=>'', "\xC2\xA0"=>' '));
    $value = preg_replace('/[\s\x{200c}\x{200d}]+/u', ' ', trim($value));
    return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
}

function evazar_bsmr_source_slug($path) {
    $path = function_exists('evazar_normalize_digikala_brand_source_path')
        ? evazar_normalize_digikala_brand_source_path((string)$path) : '';
    if ($path === '' || !preg_match('#^/brand/([\p{L}\p{M}\p{N}]+(?:[._-][\p{L}\p{M}\p{N}]+)*)/$#iu', $path, $m)) return '';
    $slug = (string)$m[1];
    if (class_exists('Normalizer')) {
        $normalized = Normalizer::normalize($slug, Normalizer::FORM_C);
        if (is_string($normalized)) $slug = $normalized;
    }
    return function_exists('mb_strtolower') ? mb_strtolower($slug, 'UTF-8') : strtolower($slug);
}

function evazar_bsmr_metadata_state($term_id) {
    $url = (string)get_term_meta($term_id, '_evazar_dk_url', true);
    $normalized_url = function_exists('evazar_normalize_digikala_brand_source_path')
        ? evazar_normalize_digikala_brand_source_path($url) : '';
    $source_id = trim((string)get_term_meta($term_id, '_evazar_dk_brand_id', true));
    $pending_source_id = trim((string)get_term_meta($term_id, '_evazar_dk_brand_source_id_pending', true));
    $source_id_for_identity = $source_id !== '' ? $source_id : $pending_source_id;
    $source_code = trim((string)get_term_meta($term_id, '_evazar_dk_brand_code', true));
    $source_slug = strtolower(trim((string)get_term_meta($term_id, '_evazar_dk_slug', true)));
    $source_map_version = trim((string)get_term_meta($term_id, '_evazar_dk_source_map_version', true));
    $verified = (string)get_term_meta($term_id, '_evazar_dk_source_verified', true) === '1';
    $path_slug = evazar_bsmr_source_slug($normalized_url);
    // Older Core releases could persist a guessed /brand/{brand_en}/ path while setting the
    // legacy verification flag. Only recognize provenance stamps that are written after explicit
    // URL/ID/code validation; all other complete-looking tuples are rechecked against live source.
    $trusted_map_version = in_array($source_map_version, array(
        '2.9.84.20-brand-live-backfill-2026-10-25',
        '2.9.84.27',
        '2.9.84.27-live-metadata-repair',
        '2.9.84.28',
        '2.9.84.28-live-metadata-repair',
        '2.9.84.29',
        '2.9.84.29-live-metadata-repair',
        '2.9.84.31-live-metadata-repair',
        '2.9.84.32-live-metadata-repair',
        '2.9.84.33-live-brand-registration',
    ), true);
    $complete = $verified && $trusted_map_version && ctype_digit($source_id) && (int)$source_id > 0
        && $source_code !== '' && $normalized_url !== '' && $path_slug !== '' && $source_slug === $path_slug;
    return array(
        'source_id'=>$source_id_for_identity, 'pending_source_id'=>$pending_source_id, 'source_code'=>$source_code, 'source_url'=>$url,
        'normalized_url'=>$normalized_url, 'source_slug'=>$source_slug, 'path_slug'=>$path_slug,
        'source_map_version'=>$source_map_version, 'trusted_map_version'=>$trusted_map_version,
        'public_slug_override'=>(string)get_term_meta($term_id, '_evazar_dk_public_slug_override', true),
        'public_slug_override_reason'=>(string)get_term_meta($term_id, '_evazar_dk_public_slug_override_reason', true),
        'verified'=>$verified, 'complete'=>$complete,
    );
}

function evazar_bsmr_queue_guard() {
    if (get_option('evazar_import_queue_manual_paused', 'no') !== 'yes') {
        return new WP_Error('bsmr_queue_not_paused', 'ابتدا صف واردات Core را متوقف کن.');
    }
    global $wpdb;
    if (!isset($wpdb) || !is_object($wpdb) || empty($wpdb->prefix) || !method_exists($wpdb, 'get_var') || !method_exists($wpdb, 'prepare') || !method_exists($wpdb, 'esc_like')) {
        return new WP_Error('bsmr_queue_uninspectable', 'وضعیت جدول صف واردات قابل بررسی نیست؛ عملیات مسدود شد.');
    }
    $table = $wpdb->prefix . 'evazar_import_queue';
    $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));
    if ($found !== $table) return new WP_Error('bsmr_queue_table_missing', 'وجود جدول صف واردات تأیید نشد؛ عملیات مسدود شد.');
    $processing = $wpdb->get_var("SELECT COUNT(*) FROM `" . str_replace('`', '', $table) . "` WHERE status = 'processing'");
    if (!is_numeric($processing)) return new WP_Error('bsmr_queue_count_failed', 'تعداد محصولات در حال پردازش قابل خواندن نیست.');
    if ((int)$processing > 0) return new WP_Error('bsmr_queue_processing', 'هنوز ' . (int)$processing . ' محصول در حالت processing است.');
    return true;
}

function evazar_bsmr_check_access() {
    if (!current_user_can('manage_options')) wp_send_json_error(array('message'=>'دسترسی مدیر لازم است.'), 403);
    check_ajax_referer('evazar_bsmr_nonce', 'nonce');
    $guard = evazar_bsmr_queue_guard();
    if (is_wp_error($guard)) wp_send_json_error(array('message'=>$guard->get_error_message(), 'code'=>$guard->get_error_code()), 409);
}

function evazar_bsmr_get_dkp_for_post($post_id) {
    $post_id = absint($post_id);
    if (!$post_id) return array('dkp'=>'', 'conflict'=>false, 'reason'=>'post_id_invalid');
    $values = array();
    foreach (array('_evazar_sku', '_evazar_dk_id', '_sku') as $key) {
        $raw = trim((string)get_post_meta($post_id, $key, true));
        if ($raw === '') continue;
        if (preg_match('/(?:^|\b)dkp-(\d+)(?:\b|$)/i', $raw, $m)) $value = ltrim($m[1], '0');
        elseif (ctype_digit($raw)) $value = ltrim($raw, '0');
        else continue;
        if ($value !== '') $values[$value] = true;
    }
    $url = trim((string)get_post_meta($post_id, '_evazar_dk_url', true));
    if (preg_match('/dkp-(\d+)/i', $url, $m)) {
        $value = ltrim($m[1], '0');
        if ($value !== '') $values[$value] = true;
    }
    if (count($values) > 1) return array('dkp'=>'', 'conflict'=>true, 'reason'=>'شناسه‌های دیجی‌کالا در متادیتای کالا با هم تعارض دارند.');
    $dkp = $values ? (string)array_key_first($values) : '';
    if ($dkp === '' || !ctype_digit($dkp) || (int)$dkp <= 0) return array('dkp'=>'', 'conflict'=>false, 'reason'=>'شناسهٔ دیجی‌کالا برای این کالا پیدا نشد.');
    return array('dkp'=>$dkp, 'conflict'=>false, 'reason'=>'');
}

function evazar_bsmr_get_sample_products($term_id, $limit = 20) {
    $term_id = absint($term_id);
    $posts = get_posts(array(
        'post_type'=>'evazar_product', 'post_status'=>'publish', 'posts_per_page'=>max(2, min(50, (int)$limit)),
        'fields'=>'ids', 'orderby'=>'ID', 'order'=>'DESC', 'no_found_rows'=>true,
        'tax_query'=>array(array('taxonomy'=>'evazar_brand', 'field'=>'term_id', 'terms'=>array($term_id), 'include_children'=>false)),
    ));
    $samples = array(); $seen_dkp = array(); $conflicts = 0;
    foreach ((array)$posts as $post_id) {
        $identity = evazar_bsmr_get_dkp_for_post($post_id);
        if (!empty($identity['conflict'])) { $conflicts++; continue; }
        $dkp = (string)($identity['dkp'] ?? '');
        if ($dkp === '' || isset($seen_dkp[$dkp])) continue;
        $samples[] = array('post_id'=>absint($post_id), 'dkp'=>$dkp, 'title'=>(string)get_the_title($post_id));
        $seen_dkp[$dkp] = true;
        if (count($samples) >= max(2, min(10, (int)$limit))) break;
    }
    return array('samples'=>$samples, 'conflict_count'=>$conflicts);
}

function evazar_bsmr_fetch_brand_identity($dkp, $term_id = 0) {
    $dkp = trim((string)$dkp);
    if (!ctype_digit($dkp) || (int)$dkp <= 0) return new WP_Error('bsmr_invalid_dkp', 'شناسهٔ محصول نمونه معتبر نیست.');
    if (!function_exists('evazar_primary_worker_request') || !function_exists('evazar_normalize_digikala_brand_source_path')) {
        return new WP_Error('bsmr_core_contract_missing', 'توابع درخواست Worker یا اعتبارسنجی URL در Core موجود نیستند.');
    }
    $headers = array('Accept'=>'application/json', 'Cache-Control'=>'no-store');
    if (function_exists('evazar_worker_auth_headers')) $headers = array_merge($headers, evazar_worker_auth_headers());
    $response = evazar_primary_worker_request('', array('dkp'=>$dkp, 'fresh'=>'1'), array(
        'timeout'=>20, 'redirection'=>0, 'reject_unsafe_urls'=>true, 'headers'=>$headers,
    ), 'GET', 'brand_metadata');
    if (is_wp_error($response)) return new WP_Error('bsmr_worker_request_failed', 'دریافت هویت برند از Worker انجام نشد: ' . $response->get_error_message());
    $status = (int)wp_remote_retrieve_response_code($response);
    $body = (string)wp_remote_retrieve_body($response);
    $json = json_decode($body, true);
    if ($status !== 200 || !is_array($json) || empty($json['success']) || !is_array($json['product'] ?? null)) {
        $detail = is_array($json) ? (string)($json['message'] ?? $json['error'] ?? '') : '';
        return new WP_Error('bsmr_source_fetch_failed', 'پاسخ زندهٔ Worker معتبر نبود (HTTP ' . $status . ')' . ($detail !== '' ? ': ' . sanitize_text_field($detail) : '.') );
    }
    $p = $json['product'];
    $path = evazar_normalize_digikala_brand_source_path((string)($p['brand_source_path'] ?? ''));
    $id = absint($p['brand_source_id'] ?? 0);
    $code = sanitize_text_field((string)($p['brand_source_code'] ?? ''));
    $fa = sanitize_text_field((string)($p['brand'] ?? ''));
    $en = sanitize_text_field((string)($p['brand_en'] ?? ''));
    $slug = evazar_bsmr_source_slug($path);
    if (!$id || $code === '' || $path === '' || $slug === '' || $fa === '') {
        return new WP_Error('bsmr_source_fields_incomplete', 'مبدأ زنده هر پنج مورد لازم را نداد: شناسه، کد، نام فارسی، URL و نامک برند.');
    }
    return array('dkp'=>$dkp, 'post_id'=>0, 'brand_id'=>(string)$id, 'brand_code'=>$code, 'brand_fa'=>$fa, 'brand_en'=>$en, 'source_url'=>$path, 'source_slug'=>$slug);
}

function evazar_bsmr_find_source_owners($term_id, $source_id, $source_url, $source_slug) {
    $terms = get_terms(array('taxonomy'=>'evazar_brand', 'hide_empty'=>false, 'number'=>0));
    if (is_wp_error($terms)) return new WP_Error('bsmr_terms_unreadable', 'فهرست برندها برای بررسی تعارض قابل خواندن نیست.');
    $term = get_term((int)$term_id, 'evazar_brand');
    $public_slug = $term && !is_wp_error($term) ? sanitize_title((string)$term->slug) : '';
    $public_source_slug = $source_slug !== '' ? sanitize_title((string)$source_slug) : '';
    $is_collision_suffix = $public_source_slug !== '' && (bool)preg_match('/^' . preg_quote($public_source_slug, '/') . '-[1-9][0-9]*$/', $public_slug);
    foreach ((array)$terms as $other) {
        if (!is_object($other) || empty($other->term_id) || (int)$other->term_id === (int)$term_id) continue;
        $other_id_raw = trim((string)get_term_meta((int)$other->term_id, '_evazar_dk_brand_id', true));
        if ($other_id_raw === '') $other_id_raw = trim((string)get_term_meta((int)$other->term_id, '_evazar_dk_brand_source_id_pending', true));
        $other_id = $other_id_raw !== '' && ctype_digit($other_id_raw) ? (int)$other_id_raw : 0;
        if ($other_id > 0 && $other_id === (int)$source_id) {
            return new WP_Error('bsmr_source_id_owned', 'شناسهٔ مبدأ ' . $source_id . ' قبلاً به برند دیگر (ترم ' . (int)$other->term_id . ') تعلق دارد.');
        }
        $other_path = function_exists('evazar_normalize_digikala_brand_source_path')
            ? evazar_normalize_digikala_brand_source_path((string)get_term_meta((int)$other->term_id, '_evazar_dk_url', true)) : '';
        if ($other_path !== '' && $other_path === $source_url && !($other_id > 0 && $other_id !== (int)$source_id)) {
            return new WP_Error('bsmr_source_url_owned', 'URL مبدأ با برند دیگری هم‌پوشانی دارد و شناسهٔ متفاوتِ تأییدشده برای رفع تعارض وجود ندارد (ترم ' . (int)$other->term_id . ').');
        }
        if ($public_source_slug !== '' && sanitize_title((string)($other->slug ?? '')) === $public_source_slug) {
            $other_verified = (string)get_term_meta((int)$other->term_id, '_evazar_dk_source_verified', true) === '1';
            $known_different_id = $other_id > 0 && $other_id !== (int)$source_id;
            $known_different_path = $other_verified && $other_path !== '' && $other_path !== $source_url;
            // A public-slug collision is allowed only when this term has a numeric local suffix
            // and the owner of the source slug has a verifiably different source identity.
            // Unknown/manual owners stay protected and require manual review/repair first.
            if (!($is_collision_suffix && ($known_different_id || $known_different_path))) {
                return new WP_Error('bsmr_source_slug_occupied', 'نامک عمومی ' . $source_slug . ' در اختیار برندی است که متفاوت‌بودن هویتش تأیید نشده؛ متادیتا ثبت نشد.');
            }
        }
    }
    return true;
}

function evazar_bsmr_snapshot($term_id, $term = null) {
    if (!$term) $term = get_term($term_id, 'evazar_brand');
    if (!$term || is_wp_error($term)) return false;
    $state = evazar_bsmr_metadata_state($term_id);
    return array(
        'term_id'=>(int)$term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug,
        'source_id'=>$state['source_id'], 'source_code'=>$state['source_code'], 'source_url'=>(string)$state['source_url'],
        'source_slug'=>$state['source_slug'], 'source_map_version'=>$state['source_map_version'], 'verified'=>$state['verified'] ? '1' : '0',
        'pending_source_id'=>$state['pending_source_id'], 'public_slug_override'=>$state['public_slug_override'], 'public_slug_override_reason'=>$state['public_slug_override_reason'],
    );
}

function evazar_bsmr_analyze_term($term_id) {
    $term_id = absint($term_id);
    // A failed re-analysis must never leave an earlier READY approval reusable.
    delete_transient(evazar_bsmr_candidate_key($term_id));
    $term = get_term($term_id, 'evazar_brand');
    if (!$term || is_wp_error($term) || empty($term->term_id)) return array('term_id'=>$term_id, 'status'=>'TERM_MISSING', 'reason'=>'برند دیگر وجود ندارد.');
    $state = evazar_bsmr_metadata_state($term_id);
    if ($state['complete']) return array('term_id'=>$term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug, 'status'=>'ALREADY_VERIFIED', 'reason'=>'متادیتای منبع از قبل کامل و تأییدشده است.');

    $sample_set = evazar_bsmr_get_sample_products($term_id, 30);
    if (empty($sample_set['samples'])) {
        return array('term_id'=>$term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug, 'status'=>!empty($sample_set['conflict_count']) ? 'SAMPLE_DKP_CONFLICT' : 'NO_SAMPLE', 'reason'=>!empty($sample_set['conflict_count']) ? 'محصول‌های نمونه شناسهٔ دیجی‌کالای متعارض دارند.' : 'محصول منتشرشدهٔ متصل با شناسهٔ معتبر دیجی‌کالا پیدا نشد.');
    }

    // Some Digikala product API records expose a partial brand object. Try other products
    // attached to this term before declaring its source metadata incomplete. A candidate is
    // still rejected if two usable products disagree about the brand identity.
    $live1 = null;
    $first = null;
    $first_error = null;
    $attempted = 0;
    foreach ($sample_set['samples'] as $sample) {
        $attempted++;
        $fresh_identity = evazar_bsmr_fetch_brand_identity($sample['dkp'], $term_id);
        if (is_wp_error($fresh_identity)) {
            $first_error = $fresh_identity;
            continue;
        }
        $live1 = $fresh_identity;
        $first = $sample;
        $live1['post_id'] = (int)$sample['post_id'];
        break;
    }
    if (!$live1 || !$first) {
        $error = $first_error instanceof WP_Error ? $first_error : new WP_Error('bsmr_source_fields_incomplete', 'اطلاعات معتبر هویت برند از نمونه‌های زنده دریافت نشد.');
        return array('term_id'=>$term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug,
            'status'=>strtoupper($error->get_error_code()),
            'reason'=>$error->get_error_message() . ' تعداد نمونه‌های بررسی‌شده: ' . $attempted . '؛ در صورت ادامهٔ خطا، محصولات متصل را بررسی کن.',
            'sample_title'=>(string)($sample_set['samples'][0]['title'] ?? ''));
    }

    $samples_used = array($first);
    $source_slug = (string)$live1['source_slug'];
    $public_slug_matches = sanitize_title((string)$term->slug) === sanitize_title($source_slug);

    // Always require two independent products, even when the public slug equals the first
    // live source slug. Same-name/same-slug brands can still represent different Digikala IDs;
    // a single sample must never authorize metadata that could misclassify other attached items.
    $second_identity = null;
    $second_sample = null;
    foreach ($sample_set['samples'] as $sample) {
        if ((int)$sample['post_id'] === (int)$first['post_id']) continue;
        $live2 = evazar_bsmr_fetch_brand_identity($sample['dkp'], $term_id);
        if (is_wp_error($live2)) {
            $first_error = $live2;
            continue;
        }
        $same_live_identity = (string)$live2['brand_id'] === (string)$live1['brand_id']
            && (string)$live2['brand_code'] === (string)$live1['brand_code']
            && (string)$live2['source_url'] === (string)$live1['source_url']
            && (string)$live2['source_slug'] === (string)$live1['source_slug']
            && evazar_bsmr_normalize_identity((string)$live2['brand_fa']) === evazar_bsmr_normalize_identity((string)$live1['brand_fa']);
        if (!$same_live_identity) {
            return array('term_id'=>$term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug,
                'status'=>'SAMPLE_DISAGREEMENT', 'reason'=>'شناسه، کد، URL یا نام فارسی برند در دو محصول نمونهٔ مستقل یکسان نیست؛ ثبت خودکار مسدود شد تا دو برند هم‌نام با هم ادغام نشوند.',
                'sample_title'=>$first['title'], 'sample2_title'=>$sample['title']);
        }
        $second_identity = $live2;
        $second_sample = $sample;
        break;
    }
    if (!$second_identity || !$second_sample) {
        $reason = 'برای تأیید هویت برند، حتی در صورت تطابق نامک عمومی و نامک مبدأ، دو محصول مستقل با هویت مبدأ کامل و یکسان لازم است.';
        if ($first_error instanceof WP_Error) $reason .= ' آخرین خطای نمونهٔ دوم: ' . $first_error->get_error_message();
        return array('term_id'=>$term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug,
            'status'=>'NEEDS_SECOND_SAMPLE', 'reason'=>$reason, 'sample_title'=>$first['title']);
    }
    $live1['sample2_post_id'] = (int)$second_sample['post_id'];
    $live1['sample2_dkp'] = (string)$second_sample['dkp'];
    $samples_used[] = $second_sample;

    $term_name_matches = evazar_bsmr_normalize_identity((string)$term->name) === evazar_bsmr_normalize_identity((string)$live1['brand_fa']);
    $stored_en = trim((string)get_term_meta($term_id, '_evazar_brand_en', true));
    if (!$term_name_matches) {
        return array('term_id'=>$term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug, 'status'=>'BRAND_NAME_MISMATCH', 'reason'=>'نام فارسی برند سایت با نام فارسی مبدأ زنده تطبیق ندارد؛ بررسی دستی لازم است.', 'source_url'=>$live1['source_url'], 'live_brand_fa'=>$live1['brand_fa']);
    }
    if ($stored_en !== '' && $live1['brand_en'] !== '' && sanitize_title($stored_en) !== sanitize_title($live1['brand_en'])) {
        return array('term_id'=>$term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug, 'status'=>'BRAND_ENGLISH_MISMATCH', 'reason'=>'نام انگلیسی ذخیره‌شده با مبدأ زنده تفاوت دارد؛ برای جلوگیری از اتصال اشتباه بررسی دستی لازم است.', 'source_url'=>$live1['source_url'], 'live_brand_en'=>$live1['brand_en']);
    }

    if ($state['source_id'] !== '' && (!ctype_digit($state['source_id']) || (int)$state['source_id'] !== (int)$live1['brand_id'])) {
        return array('term_id'=>$term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug, 'status'=>'STORED_SOURCE_ID_CONFLICT', 'reason'=>'شناسهٔ مبدأ ذخیره‌شده با شناسهٔ زنده متفاوت است؛ چیزی بازنویسی نشد.');
    }
    if ($state['trusted_map_version'] && $state['verified'] && $state['normalized_url'] !== '' && $state['normalized_url'] !== $live1['source_url']) {
        return array('term_id'=>$term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug, 'status'=>'VERIFIED_SOURCE_CONFLICT', 'reason'=>'URL تأییدشدهٔ فعلی با URL زنده متفاوت است؛ بازنویسی خودکار ممنوع شد.');
    }
    if ($state['trusted_map_version'] && $state['verified'] && $state['source_code'] !== '' && $state['source_code'] !== $live1['brand_code']) {
        return array('term_id'=>$term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug, 'status'=>'VERIFIED_CODE_CONFLICT', 'reason'=>'کد منبع تأییدشده با کد زنده متفاوت است؛ بررسی دستی لازم است.');
    }
    $owners = evazar_bsmr_find_source_owners($term_id, $live1['brand_id'], $live1['source_url'], $live1['source_slug']);
    if (is_wp_error($owners)) return array('term_id'=>$term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug, 'status'=>strtoupper($owners->get_error_code()), 'reason'=>$owners->get_error_message());

    $snapshot = evazar_bsmr_snapshot($term_id, $term);
    $candidate = array(
        'user_id'=>get_current_user_id(), 'term_id'=>$term_id, 'snapshot'=>$snapshot,
        'brand_id'=>(string)$live1['brand_id'], 'brand_code'=>(string)$live1['brand_code'],
        'brand_fa'=>(string)$live1['brand_fa'], 'brand_en'=>(string)$live1['brand_en'],
        'source_slug'=>(string)$live1['source_slug'], 'source_url'=>(string)$live1['source_url'],
        'sample_ids'=>array_map(static function($s) { return array('post_id'=>(int)$s['post_id'], 'dkp'=>(string)$s['dkp']); }, $samples_used),
        'created_at'=>time(),
    );
    $transient = evazar_bsmr_candidate_key($term_id);
    set_transient($transient, $candidate, 2 * HOUR_IN_SECONDS);
    return array(
        'term_id'=>$term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug,
        'status'=>'READY', 'reason'=>$public_slug_matches ? 'نام برند، نامک مبدأ و نمونهٔ زنده منطبق‌اند.' : 'دو محصول مستقل، نام برند و هویت یکسان مبدأ را تأیید کردند؛ نامک عمومی بدون تغییر حفظ می‌شود.',
        'source_url'=>$candidate['source_url'], 'source_slug'=>$candidate['source_slug'], 'source_id'=>$candidate['brand_id'], 'source_code'=>$candidate['brand_code'],
        'samples'=>count($samples_used), 'candidate'=>true,
    );
}

function evazar_bsmr_candidate_key($term_id) {
    return 'evazar_bsmr_' . absint(get_current_user_id()) . '_' . absint($term_id);
}

function evazar_bsmr_ajax_list_candidates() {
    evazar_bsmr_check_access();
    if (!taxonomy_exists('evazar_brand')) wp_send_json_error(array('message'=>'تاکسونومی برند در دسترس نیست.'), 409);
    $terms = get_terms(array('taxonomy'=>'evazar_brand', 'hide_empty'=>false, 'number'=>0, 'orderby'=>'term_id', 'order'=>'ASC'));
    if (is_wp_error($terms)) wp_send_json_error(array('message'=>'خواندن فهرست برندها ناموفق بود.'), 500);
    $rows = array();
    foreach ((array)$terms as $term) {
        if (!is_object($term) || empty($term->term_id)) continue;
        $state = evazar_bsmr_metadata_state((int)$term->term_id);
        if ($state['complete']) continue;
        $rows[] = array(
            'term_id'=>(int)$term->term_id, 'name'=>(string)$term->name, 'slug'=>(string)$term->slug,
            'product_count'=>(int)($term->count ?? 0), 'source_id'=>$state['source_id'], 'source_url'=>$state['source_url'],
            'source_map_version'=>$state['source_map_version'], 'source_verified'=>$state['verified'] ? '1' : '0',
        );
    }
    wp_send_json_success(array('total'=>count($rows), 'rows'=>$rows, 'message'=>'فقط برندهایی فهرست شدند که متادیتای منبعشان ناقص یا تأییدنشده است.'));
}

function evazar_bsmr_ajax_analyze_one() {
    evazar_bsmr_check_access();
    $term_id = absint(wp_unslash($_POST['term_id'] ?? 0));
    if (!$term_id) wp_send_json_error(array('message'=>'شناسهٔ برند نامعتبر است.'), 400);
    $result = evazar_bsmr_analyze_term($term_id);
    wp_send_json_success(array('result'=>$result));
}

function evazar_bsmr_apply_candidate($term_id) {
    $term_id = absint($term_id);
    $candidate = get_transient(evazar_bsmr_candidate_key($term_id));
    if (!is_array($candidate) || (int)($candidate['user_id'] ?? 0) !== (int)get_current_user_id() || (int)($candidate['term_id'] ?? 0) !== $term_id) {
        return array('term_id'=>$term_id, 'status'=>'SKIPPED', 'reason'=>'گزارش معتبر یا تازه‌ای برای این برند وجود ندارد؛ دوباره بررسی کن.');
    }
    $term = get_term($term_id, 'evazar_brand');
    if (!$term || is_wp_error($term) || empty($term->term_id)) return array('term_id'=>$term_id, 'status'=>'SKIPPED', 'reason'=>'برند از زمان بررسی حذف شده است.');
    $snapshot = $candidate['snapshot'] ?? array();
    if ((string)$term->name !== (string)($snapshot['name'] ?? '') || (string)$term->slug !== (string)($snapshot['slug'] ?? '')) {
        return array('term_id'=>$term_id, 'status'=>'SKIPPED', 'reason'=>'نام یا نامک برند از زمان بررسی تغییر کرده؛ دوباره بررسی کن.');
    }
    $current = evazar_bsmr_snapshot($term_id, $term);
    if (!$current || $current !== $snapshot) return array('term_id'=>$term_id, 'status'=>'SKIPPED', 'reason'=>'متادیتای برند پس از بررسی تغییر کرده؛ برای جلوگیری از بازنویسی، عملیات متوقف شد.');

    $live_samples = array();
    foreach ((array)($candidate['sample_ids'] ?? array()) as $sample) {
        $post_id = absint($sample['post_id'] ?? 0);
        $dkp = (string)($sample['dkp'] ?? '');
        if (!$post_id || !ctype_digit($dkp)) return array('term_id'=>$term_id, 'status'=>'SKIPPED', 'reason'=>'اطلاعات نمونهٔ محصول ذخیره‌شده نامعتبر است.');
        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'evazar_product' || $post->post_status !== 'publish') return array('term_id'=>$term_id, 'status'=>'SKIPPED', 'reason'=>'محصول نمونه از زمان بررسی تغییر کرده است.');
        $terms = wp_get_object_terms($post_id, 'evazar_brand', array('fields'=>'ids'));
        if (is_wp_error($terms) || !in_array($term_id, array_map('absint', (array)$terms), true)) return array('term_id'=>$term_id, 'status'=>'SKIPPED', 'reason'=>'محصول نمونه دیگر به این برند متصل نیست.');
        $fresh_id = evazar_bsmr_get_dkp_for_post($post_id);
        if (!empty($fresh_id['conflict']) || (string)($fresh_id['dkp'] ?? '') !== $dkp) return array('term_id'=>$term_id, 'status'=>'SKIPPED', 'reason'=>'شناسهٔ محصول نمونه تغییر کرده یا متعارض شده است.');

        // Re-fetch the live product during APPLY, not just ANALYZE. The source may have changed
        // while the transient approval was waiting, so only the exact same identity is writable.
        $live = evazar_bsmr_fetch_brand_identity($dkp, $term_id);
        if (is_wp_error($live)) return array('term_id'=>$term_id, 'status'=>'LIVE_RECHECK_FAILED', 'reason'=>'بررسی مجدد مبدأ زنده انجام نشد؛ متادیتا نوشته نشد: ' . $live->get_error_message());
        $same_identity = (string)$live['brand_id'] === (string)($candidate['brand_id'] ?? '')
            && (string)$live['brand_code'] === (string)($candidate['brand_code'] ?? '')
            && (string)$live['source_url'] === (string)($candidate['source_url'] ?? '')
            && (string)$live['source_slug'] === (string)($candidate['source_slug'] ?? '')
            && evazar_bsmr_normalize_identity((string)$live['brand_fa']) === evazar_bsmr_normalize_identity((string)($candidate['brand_fa'] ?? ''));
        if (!$same_identity) return array('term_id'=>$term_id, 'status'=>'SOURCE_CHANGED_AFTER_REVIEW', 'reason'=>'هویت مبدأ زنده از زمان بررسی تغییر کرده؛ برای جلوگیری از ثبت اطلاعات قدیمی، این ردیف متوقف شد.');
        $candidate_en = trim((string)($candidate['brand_en'] ?? ''));
        if ($candidate_en !== '' && $live['brand_en'] !== '' && sanitize_title($candidate_en) !== sanitize_title($live['brand_en'])) {
            return array('term_id'=>$term_id, 'status'=>'SOURCE_CHANGED_AFTER_REVIEW', 'reason'=>'نام انگلیسی مبدأ از زمان بررسی تغییر کرده؛ متادیتا نوشته نشد.');
        }
        $live_samples[] = $live;
    }
    $stored_en = trim((string)get_term_meta($term_id, '_evazar_brand_en', true));
    if ($stored_en !== '' && !empty($live_samples[0]['brand_en']) && sanitize_title($stored_en) !== sanitize_title($live_samples[0]['brand_en'])) {
        return array('term_id'=>$term_id, 'status'=>'SKIPPED', 'reason'=>'نام انگلیسی ذخیره‌شده با مبدأ زنده متفاوت است؛ بررسی دستی لازم است.');
    }
    $owners = evazar_bsmr_find_source_owners($term_id, $candidate['brand_id'], $candidate['source_url'], $candidate['source_slug']);
    if (is_wp_error($owners)) return array('term_id'=>$term_id, 'status'=>'SKIPPED', 'reason'=>$owners->get_error_message());

    // Clear any stale/partial trust marker first. A failure must not leave an incomplete tuple marked verified.
    update_term_meta($term_id, '_evazar_dk_source_verified', '0');
    if ((string)get_term_meta($term_id, '_evazar_dk_source_verified', true) !== '0') {
        return array('term_id'=>$term_id, 'status'=>'WRITE_FAILED', 'reason'=>'نشانگر تأیید قبلی قابل غیرفعال‌کردن و بازخوانی نبود؛ هیچ فیلد دیگری تغییر نکرد.');
    }

    // Write source facts only. Public term identity, term slug, product assignments, redirects and cache are untouched.
    $values = array(
        '_evazar_dk_brand_id'=>(string)$candidate['brand_id'],
        '_evazar_dk_brand_code'=>(string)$candidate['brand_code'],
        '_evazar_dk_slug'=>(string)$candidate['source_slug'],
        '_evazar_dk_url'=>(string)$candidate['source_url'],
        '_evazar_dk_source_map_version'=>'2.9.84.32-live-metadata-repair',
        '_evazar_dk_source_path_updated'=>gmdate('c'),
        '_evazar_dk_public_slug_override'=>sanitize_title((string)$term->slug) !== sanitize_title((string)$candidate['source_slug']) ? '1' : '0',
        '_evazar_dk_public_slug_override_reason'=>sanitize_title((string)$term->slug) !== sanitize_title((string)$candidate['source_slug']) ? ((bool)preg_match('/^' . preg_quote(sanitize_title((string)$candidate['source_slug']), '/') . '-[1-9][0-9]*$/', sanitize_title((string)$term->slug)) ? 'source_slug_collision' : 'legacy_public_slug_preserved') : '',
    );
    foreach ($values as $key=>$value) {
        update_term_meta($term_id, $key, $value);
        if ((string)get_term_meta($term_id, $key, true) !== (string)$value) {
            return array('term_id'=>$term_id, 'status'=>'WRITE_FAILED', 'reason'=>'ذخیره و بازخوانی متادیتا تأیید نشد: ' . $key . '. نشانگر تأیید هنوز ثبت نشده است.');
        }
    }
    update_term_meta($term_id, '_evazar_dk_source_verified', '1');
    if ((string)get_term_meta($term_id, '_evazar_dk_source_verified', true) !== '1') {
        return array('term_id'=>$term_id, 'status'=>'WRITE_FAILED', 'reason'=>'نشانگر تأیید مبدأ ذخیره نشد؛ این ردیف موفق محسوب نمی‌شود.');
    }
    delete_term_meta($term_id, '_evazar_dk_brand_source_id_pending');
    if ((string)get_term_meta($term_id, '_evazar_dk_brand_source_id_pending', true) !== '') {
        update_term_meta($term_id, '_evazar_dk_source_verified', '0');
        return array('term_id'=>$term_id, 'status'=>'WRITE_FAILED', 'reason'=>'نشانگر بازیابی موقت حذف نشد؛ تأیید نهایی لغو شد.');
    }
    delete_transient(evazar_bsmr_candidate_key($term_id));
    return array('term_id'=>$term_id, 'status'=>'SAVED', 'reason'=>'متادیتای منبع نوشته و از دیتابیس بازخوانی شد؛ نامک و محصولات تغییر نکردند.');
}

function evazar_bsmr_ajax_apply_batch() {
    evazar_bsmr_check_access();
    $ids = json_decode((string)wp_unslash($_POST['term_ids'] ?? ''), true);
    if (!is_array($ids) || !$ids || count($ids) > 20) wp_send_json_error(array('message'=>'در هر مرحله ۱ تا ۲۰ برند انتخاب کن.'), 400);
    $ids = array_values(array_unique(array_filter(array_map('absint', $ids))));
    $results = array();
    foreach ($ids as $id) $results[] = evazar_bsmr_apply_candidate($id);
    wp_send_json_success(array('results'=>$results));
}

function evazar_bsmr_render_page() {
    if (!current_user_can('manage_options')) return;
    $nonce = wp_create_nonce('evazar_bsmr_nonce');
    ?>
    <div class="wrap" dir="rtl" style="max-width:1250px">
      <h1>بررسی و ترمیم متادیتای مبدأ برندها</h1>
      <p>این ابزار فقط برندهای فاقد متادیتای کامل یا تأییدشده را بررسی می‌کند. منبع از اطلاعات زندهٔ محصول در Digikala و از مسیر Workerهای تنظیم‌شده خوانده می‌شود.</p>
      <p><strong>ایمنی:</strong> صف واردات باید متوقف باشد و تعداد <code>processing</code> صفر باشد. این ابزار نامک، نام نمایشی، محصولات، ریدایرکت‌ها و کش را تغییر نمی‌دهد.</p>
      <p><button class="button button-primary" id="evazar-bsmr-load">۱. فهرست برندهای نیازمند بررسی</button> <button class="button" id="evazar-bsmr-analyze" disabled>۲. بررسی مبدأ زنده</button> <button class="button button-primary" id="evazar-bsmr-apply" disabled>۳. ثبت متادیتای موارد تأییدشده</button> <button class="button" id="evazar-bsmr-stop" disabled>توقف بررسی</button></p>
      <p id="evazar-bsmr-status" role="status">هنوز بررسی شروع نشده است.</p>
      <div id="evazar-bsmr-progress" style="background:#ddd;height:8px;max-width:700px"><div style="background:#2271b1;width:0;height:8px"></div></div>
      <table class="widefat striped" style="margin-top:14px"><thead><tr><th><input type="checkbox" id="evazar-bsmr-select-all" aria-label="انتخاب همه موارد قابل ثبت"></th><th>شناسه ترم</th><th>برند</th><th>نامک سایت</th><th>هویت مبدأ</th><th>نسخهٔ ثبت</th><th>وضعیت بررسی</th><th>توضیح</th></tr></thead><tbody id="evazar-bsmr-rows"><tr><td colspan="8">ابتدا فهرست را بارگذاری کن.</td></tr></tbody></table>
    </div>
    <script>
    (function(){
      const nonce=<?php echo wp_json_encode($nonce); ?>;
      const $=id=>document.getElementById(id);
      const rows=new Map(); let stopped=false; let running=false;
      const labels={READY:'آماده ثبت امن',ALREADY_VERIFIED:'از قبل تأیید شده',NO_SAMPLE:'نمونه محصول ندارد',SAMPLE_DKP_CONFLICT:'تعارض شناسه نمونه',NEEDS_SECOND_SAMPLE:'نیازمند نمونه دوم',SAMPLE_DISAGREEMENT:'نمونه‌ها متفاوت‌اند',BRAND_NAME_MISMATCH:'تفاوت نام فارسی',BRAND_ENGLISH_MISMATCH:'تفاوت نام انگلیسی',STORED_SOURCE_ID_CONFLICT:'تعارض شناسه مبدأ',VERIFIED_SOURCE_CONFLICT:'تعارض URL تأییدشده',VERIFIED_CODE_CONFLICT:'تعارض کد تأییدشده',BSMR_SOURCE_ID_OWNED:'شناسه متعلق به برند دیگر',BSMR_SOURCE_URL_OWNED:'URL متعلق به برند دیگر',BSMR_SOURCE_SLUG_OCCUPIED:'نامک در اختیار برند دیگر با هویت نامشخص',BSMR_SOURCE_FIELDS_INCOMPLETE:'اطلاعات مبدأ ناقص',BSMR_WORKER_REQUEST_FAILED:'خطای Worker',BSMR_SOURCE_FETCH_FAILED:'خطای دریافت مبدأ',BSMR_CORE_CONTRACT_MISSING:'تابع Core در دسترس نیست',BSMR_TERMS_UNREADABLE:'خواندن برندها ناموفق',SECOND_SAMPLE_FAILED:'نمونه دوم ناموفق',LIVE_RECHECK_FAILED:'بررسی مجدد مبدأ ناموفق',SOURCE_CHANGED_AFTER_REVIEW:'هویت مبدأ تغییر کرده',SAVED:'ثبت شد',WRITE_FAILED:'خطای ذخیره',SKIPPED:'رد شد',REQUEST_FAILED:'خطای درخواست'};
      function statusLabel(s){return labels[s]||s||'—';}
      function esc(s){return String(s??'');}
      function updateStatus(s){$('evazar-bsmr-status').textContent=s;}
      function render(){const body=$('evazar-bsmr-rows');body.replaceChildren();if(!rows.size){const tr=document.createElement('tr'),td=document.createElement('td');td.colSpan=8;td.textContent='موردی برای نمایش وجود ندارد.';tr.append(td);body.append(tr);return;}
        rows.forEach(r=>{const tr=document.createElement('tr');const td0=document.createElement('td');const cb=document.createElement('input');cb.type='checkbox';cb.className='evazar-bsmr-row-check';cb.value=String(r.term_id);cb.checked=r.status==='READY';cb.disabled=r.status!=='READY';td0.append(cb);tr.append(td0);
          [r.term_id,r.name,r.slug,(r.source_id?('ID '+r.source_id+' · '+(r.source_url||'')):(r.source_url||'—')),(r.source_map_version||'—'),statusLabel(r.status),r.reason||''].forEach(v=>{const td=document.createElement('td');td.textContent=esc(v);tr.append(td);});body.append(tr);});
        $('evazar-bsmr-apply').disabled=!Array.from(rows.values()).some(r=>r.status==='READY');
      }
      async function request(action,data={}){const body=new URLSearchParams({action,nonce,...data});const response=await fetch(ajaxurl,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body});let json;try{json=await response.json();}catch(e){throw new Error('پاسخ سرور قابل خواندن نیست.');}if(!response.ok||!json.success)throw new Error(json?.data?.message||('HTTP '+response.status));return json.data;}
      $('evazar-bsmr-load').addEventListener('click',async()=>{if(running)return;try{updateStatus('در حال خواندن فهرست برندها…');const data=await request('evazar_bsmr_list_candidates');rows.clear();(data.rows||[]).forEach(r=>rows.set(Number(r.term_id),{...r,status:'WAITING',reason:'در انتظار بررسی مبدأ'}));render();updateStatus('تعداد برندهای ناقص: '+data.total+'؛ برای دریافت اطلاعات زنده روی «بررسی مبدأ زنده» کلیک کن.');$('evazar-bsmr-analyze').disabled=!data.total;$('evazar-bsmr-select-all').checked=false;}catch(e){updateStatus('خطا: '+e.message);}});
      $('evazar-bsmr-analyze').addEventListener('click',async()=>{if(running)return;running=true;stopped=false;$('evazar-bsmr-stop').disabled=false;$('evazar-bsmr-load').disabled=true;$('evazar-bsmr-analyze').disabled=true;const list=Array.from(rows.values()).filter(r=>r.status==='WAITING');let done=0;
        try{for(const item of list){if(stopped)break;try{const data=await request('evazar_bsmr_analyze_one',{term_id:String(item.term_id)});const result=data.result||{};rows.set(Number(item.term_id),{...item,...result});}catch(e){rows.set(Number(item.term_id),{...item,status:'REQUEST_FAILED',reason:e.message});}done++;$('evazar-bsmr-progress').firstElementChild.style.width=(list.length?Math.round(done/list.length*100):100)+'%';updateStatus('بررسی '+done+' از '+list.length+'؛ آماده ثبت: '+Array.from(rows.values()).filter(r=>r.status==='READY').length);render();}
          updateStatus((stopped?'بررسی توسط مدیر متوقف شد. ':'بررسی پایان یافت. ')+'قابل ثبت: '+Array.from(rows.values()).filter(r=>r.status==='READY').length+'؛ موارد نیازمند بررسی دستی: '+Array.from(rows.values()).filter(r=>!['READY','ALREADY_VERIFIED','WAITING'].includes(r.status)).length+'.');
        }finally{running=false;$('evazar-bsmr-stop').disabled=true;$('evazar-bsmr-load').disabled=false;$('evazar-bsmr-analyze').disabled=!Array.from(rows.values()).some(r=>['WAITING','REQUEST_FAILED'].includes(r.status));render();}});
      $('evazar-bsmr-stop').addEventListener('click',()=>{stopped=true;updateStatus('درخواست توقف ثبت شد؛ پس از پایان درخواست فعلی متوقف می‌شود.');});
      $('evazar-bsmr-select-all').addEventListener('change',e=>document.querySelectorAll('.evazar-bsmr-row-check:not(:disabled)').forEach(cb=>cb.checked=e.target.checked));
      $('evazar-bsmr-apply').addEventListener('click',async()=>{if(running)return;const ids=Array.from(document.querySelectorAll('.evazar-bsmr-row-check:checked')).map(cb=>Number(cb.value));if(!ids.length){updateStatus('هیچ مورد آماده‌ای انتخاب نشده است.');return;}if(!confirm('متادیتای مبدأ فقط برای '+ids.length+' برند انتخاب‌شده ثبت شود؟ نامک، محصولات و ریدایرکت‌ها تغییر نمی‌کنند.'))return;running=true;$('evazar-bsmr-apply').disabled=true;let saved=0,failed=0;
        try{for(let i=0;i<ids.length;i+=10){const data=await request('evazar_bsmr_apply_batch',{term_ids:JSON.stringify(ids.slice(i,i+10))});(data.results||[]).forEach(r=>{const old=rows.get(Number(r.term_id))||{term_id:r.term_id};rows.set(Number(r.term_id),{...old,status:r.status==='SAVED'?'SAVED':r.status,reason:r.reason||''});if(r.status==='SAVED')saved++;else failed++;});render();updateStatus('ثبت: '+saved+'؛ ردشده/ناموفق: '+failed+'؛ باقی‌مانده: '+Math.max(0,ids.length-i-10));}}
        catch(e){updateStatus('خطا هنگام ثبت: '+e.message+'. موارد قبلی گزارش‌شده را بررسی کن.');}finally{running=false;updateStatus('پایان ثبت. موفق: '+saved+'؛ ردشده/ناموفق: '+failed+'.');render();}});
    })();
    </script>
    <?php
}
