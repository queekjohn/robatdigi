# Safe upgrade — EVazar Core 2.9.84.73

1. Back up the current `evazar-core/` plugin folder and the WordPress database.
2. Replace the existing plugin folder with the `evazar-core/` folder in this ZIP; keep the folder name unchanged.
3. No database migration is required. Do not redeploy or change Cloudflare Workers.
4. The internal parallel endpoint body limit is increased from 2 MiB to 4 MiB. The diagnostic report now displays the matching 4 MiB limit.
5. Batch size, queue/retry/cooldown behavior, worker selection, duplicate protection, and cache behavior are unchanged.
6. If HTTP 413 persists, inspect the new `تعویق دسته Gemini` event. A lower PHP, web-server, proxy, or hosting limit may still reject the request before the endpoint processes it.
7. Local syntax and regression tests are run for this release; production hosting and live Gemini requests are not tested here.
