# EVazar Core 2.9.84.48 — Queue Start Cadence & Diagnostics

- Randomized automatic interval is chosen and persisted at run start; its target is measured start-to-start, not completion-to-start.
- The persistent queue lock still prevents overlapping runs. If a run outlasts its target, follow-up scheduling can only start after the lock is released.
- Added queue-run diagnostics: scheduled timestamp, actual start, lateness relative to due time, duration, run status, and next target timestamp. The Queue dashboard displays last start lag and duration.
- Fixed Gemini-only product collection's checkpoint `continue` branch so it observes the existing 300ms preparation spacing like the normal success path.
- No Cloudflare Worker code changed. Source fetching remains sequential; bounded concurrency is intentionally not enabled in this release until timing diagnostics are confirmed on the live site.
- No cache behavior, product schema, prompts, batch limits, or source routing changed.

## Deployment note

The plugin cannot configure the hosting account's cPanel Cron by itself. Configure a real server Cron to call `https://evazar.ir/wp-cron.php?doing_wp_cron` every minute. Verify that scheduled events run before setting `DISABLE_WP_CRON` to `true`; do not disable WordPress's request-triggered Cron before the server Cron is confirmed.
