# EVazar Core 2.9.84.61 — Randomized Queue Interval with Second Granularity

- The configured minimum/maximum interval values remain in whole minutes, preserving all existing settings.
- Actual scheduling now picks a random integer number of seconds between `min_minutes * 60` and `max_minutes * 60`, inclusive. For a 5–8 minute range this includes values such as 6m20s and 7m10s, with endpoints exactly 5m00s and 8m00s.
- Queue start, initial schedule, and manual reschedule paths all use the seconds-based interval helper.
- The exact interval is persisted as `evazar_queue_last_random_interval_seconds` and recorded in run diagnostics; the old `evazar_queue_last_random_interval_minutes` option remains as a compatibility field.
- Scheduler start logs and queue settings diagnostics display the selected duration (minutes and seconds where applicable).
- Bumped the queue cron schedule schema to version 4 so existing installations refresh the next scheduled run and adopt seconds precision.
- Worker logic, product queue processing, Gemini batch behavior, and cache logic are unchanged.
