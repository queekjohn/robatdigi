# EVazar Core 2.9.84.51 — Queue Claim Diagnostics

- Clarifies in the batch planning event that the configured run size is a maximum capacity, not a guaranteed claim count.
- Adds `queue_batch_claim_result` with total pending, due/future pending, already-processing, exact eligible count, DB claim update count, rows loaded, unfilled capacity, and a diagnostic reason.
- Adds `queue_batch_run_summary` after the run to report actual successful, failed, deferred, claimed, and Gemini-ready product counts, together with halt reason where known.
- Adds preparation metrics to `batch_dispatch_wave` so available capacity can be compared with actual products ready for Gemini.
- Preserves the queue selection/claim behavior; diagnostics only. No database schema, Worker, cache, or product-processing logic changes.
