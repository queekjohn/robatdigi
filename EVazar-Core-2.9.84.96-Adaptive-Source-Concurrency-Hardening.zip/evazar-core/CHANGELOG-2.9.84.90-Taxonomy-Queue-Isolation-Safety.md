# EVazar Core 2.9.84.90 — Taxonomy Queue Isolation & Worker Safety

## Scope

This release hardens the independent SEO queues for product categories and brands while preserving the existing product-import pipeline and prompt/content behavior.

## Changes

- Added separate database-backed run locks and heartbeat records for the category SEO queue and brand SEO queue. A second run of the same type is blocked while its prior run is active; the category and brand queues retain separate locks.
- Added same-type stale-claim recovery under the per-type run lock. Recent `processing` claims are not reclaimed; a new same-type batch is blocked while those claims remain live/recent.
- Added claim-token and run-lock ownership checks before source preparation, before Gemini dispatch, and before taxonomy content writes.
- Taxonomy queue completion now reports success only when exactly one matching row was updated under the expected term type, processing status, and batch token.
- Added final taxonomy-run summaries, source-fetch/Gemini duration metrics, and shutdown/interruption reporting.
- Distinguished a transient Worker/transport/upstream failure from a successful response with genuinely no usable source text. Transient failures return to retry with backoff; valid empty source remains a terminal no-source result.
- Added bounded source diagnostics (phase, Worker host label, HTTP/error code, retry hint, payload validity). Response bodies, internal tokens, and credentials are not stored in these diagnostics.
- Added a cross-request database lease per primary Digikala Worker. Taxonomy source fetches and product parallel cURL-multi waves use the same lease, preventing two PHP requests from issuing overlapping work to the same primary Worker.
- Product source-pool reporting now distinguishes busy Workers. Product imports and forced stock refreshes defer when capacity is temporarily held by another queue instead of treating lease contention as a product/source failure.
- Kept the existing per-Gemini-Worker lock path shared by product and taxonomy calls; no separate Gemini Worker pool was introduced.

## Preserved behavior

- Product queue run lock, claim model, adaptive Gemini batching, product prompts, product validation, and product persistence flow remain intact.
- Category and brand remain distinct by `term_type`, with separate scheduler hooks and separate run locks.
- Taxonomy batch size remains within the existing 2–5 range (default 3).
- Taxonomy source preparation and final term writes remain sequential and bounded. No new parallel term writes were introduced.
- Existing category/brand source identity checks, manual-content protection, prompt templates, HTML sanitization, and Rank Math metadata behavior are preserved.
- No Worker JavaScript, Theme files, cache logic, product data schema, taxonomy content format, or taxonomy queue schema changes are included.

## Operational notes

- The new locks are temporary non-autoloaded WordPress options; the existing product and taxonomy queue tables are reused.
- When all configured primary or Gemini Workers are busy, the affected queue should defer/retry rather than collide on a Worker. Queues remain logically independent but still share finite server and Worker capacity.
