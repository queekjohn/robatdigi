# EVazar Core 2.9.84.81 — Search Readiness and Repair Fixes

- If live completeness counts contradict a stored `ready` flag, settings status now switches the search index back to `building` and ensures the scheduled backfill exists. This prevents continued use of an apparently ready but incomplete index.
- Search-index backfill now retries canonical Core index sync when a canonical sync-error marker remains, even if a version-matching product-index row exists. It respects the stored retry-not-before timestamp.
- No schema migration or table truncation was added.
- Worker, importer, cache-purge logic, and archive filter assets are unchanged.
