# EVazar Core 2.9.84.44 — Gemini Batch Validation Review

- Retains the 2.9.84.43 fix: request-context preparation and operations-event creation preserve up to 50 unique DKPs.
- Fixes the remaining diagnostics-table display cap so all 40/50 DKPs are visible rather than silently showing only the first 30.
- Adds regression assertions that Core emits matching Worker batch-size/count headers for 2, 30, 40 and 50 products.
- Confirms embedded Worker is 1.13.24 and allows up to 50 products. No new Worker source change in this release.
- Queue timing, prompts, model selection, cache code and brand logic are unchanged.

## Validation
All 21 PHP files linted; 9 PHP regression scripts passed (347 assertions); 2 JavaScript regression scripts passed (47 checks). Local/mock only; no live site or real Gemini request was executed.
