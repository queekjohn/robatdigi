# EVazar Core 2.9.84.42 — Gemini product batch size 50

- Raises the maximum automatic Gemini product batch from 30 to 50 end-to-end in Core validation, request metadata, logging, queue chunking, dispatch and Worker policy.
- Updates the embedded and standalone Cloudflare Worker to 1.13.24; the Worker rejects batches above 50 before calling Gemini.
- Adds a one-time migration from the previous default 30 to 50 while preserving intentionally lower custom batch sizes.
- Raises the Gemini outer queue-run ceiling from 150 to 250 so five eligible Workers can each receive one 50-product batch; the migration promotes the previous 150 default while preserving lower manual caps. Non-Gemini processing remains capped at 75.
- Taxonomy SEO batches remain capped at five items.
- Local source/regression tests should be run before deployment; no live WordPress, Cloudflare, or Gemini environment is available in this package build.
