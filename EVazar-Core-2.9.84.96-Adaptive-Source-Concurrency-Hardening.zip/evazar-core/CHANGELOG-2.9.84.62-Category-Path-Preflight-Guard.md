# EVazar Core 2.9.84.62 — Category-Path Preflight Guard

- Reuse a single pure source-category-path validator before Gemini checkpoint/AI and before any product post/meta write.
- Missing or invalid explicit Digikala category paths return a structured `PRODUCT_CATEGORY_SYNC_FAILED` WP_Error with `saved=false`, preserving queue quarantine routing and linking an already-existing product ID where one exists.
- Category sync uses the same validator so preflight and final sync cannot drift in what they accept.
- Add an administrator-confirmed, non-destructive action on source-category quarantine rows to move an already-saved related product to Draft; it does not delete product data and leaves the queue row quarantined.
- No Worker, Gemini request behavior, queue capacity, or cache logic changed.
