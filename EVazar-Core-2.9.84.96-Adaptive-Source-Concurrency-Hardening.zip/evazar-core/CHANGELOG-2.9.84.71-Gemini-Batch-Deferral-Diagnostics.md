# EVazar Core 2.9.84.71 — Gemini Batch Deferral Diagnostics

- Add one dedicated `queue_batch_deferred` operations event whenever a claimed Gemini batch is returned to the queue.
- Record batch size, available DKP identifiers, normalized error code, HTTP status when available, worker host when supplied by error metadata, and the next retry time.
- Show redacted diagnostic detail in the existing Gemini operations report; API keys and common credential fields are masked, and raw response bodies/prompts are not stored.
- Preserve queue status, retry counters, cooldown behavior, batch sizes, parallel dispatch, and duplicate-request safety behavior.
- No Worker changes; no cache changes.
