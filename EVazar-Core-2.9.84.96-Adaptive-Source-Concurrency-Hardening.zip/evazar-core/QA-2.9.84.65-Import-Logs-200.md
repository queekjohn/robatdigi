# QA — EVazar Core 2.9.84.65

- Regression: `php tests/import-log-retention-regression.php` — 8 assertions.
- `php -l` passed for all PHP files in the package.
- Updated version-pinned regression tests to 2.9.84.65.
- Full existing PHP and JavaScript regression suites run before packaging.
- ZIP integrity and extracted package version checked.
