# Safe upgrade — 2.9.84.38

- Back up the currently installed Core plugin and database before replacing files.
- Install `EVazar-Core-2.9.84.38.zip` over the current EVazar Core plugin; do not install it as a second copy.
- Do not update or redeploy Cloudflare Worker for this patch. Worker 1.13.23 is unchanged.
- Test one product via Quick Edit: search/select one brand, save, reload the product row/editor, and verify exact brand slug/term ID.
- Test one product via the full product editor: choose one brand, update, reload, and verify the assignment. Full edit replaces the current selection; Quick Edit appends the selected brand.
- Then test a Gutenberg product if that editor is enabled; its taxonomy update is handled by REST and reconciled after REST insertion.
- Verify queue timing remains configured to the expected min/max (default 5–10 minutes). Production code for timing is unchanged; only the regression suite was extended.
- No cache purge, product index, importer, queue manager, price/stock, redirect map, or Worker code is changed in this release.
