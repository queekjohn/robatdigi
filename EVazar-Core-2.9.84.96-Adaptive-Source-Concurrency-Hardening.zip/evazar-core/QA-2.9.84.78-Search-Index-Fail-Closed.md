# QA — EVazar Core 2.9.84.78

## Deep-review finding corrected
A failure in the canonical Core product/facet index could leave the live title-search state at `ready`. That could allow the indexed path to use stale brand/stock/DKP/SKU data or omit a newly saved/updated product. `evazar_product_index_mark_sync_failure()` now fails closed by moving the search state to `building`; the existing scheduled backfill retries and only reactivates the fast path after completeness checks pass.

## Local checks on final source
- Core + Theme PHP regression scripts: 25 passed, 0 failed.
- PHP syntax: 49/49 passed.
- JavaScript syntax: 11/11 passed.
- Worker JavaScript regression scripts: 3 passed (54 checks total).
- Product-search-index regression: 22 checks passed, including the new fail-closed assertion.
- Core package integrity checked after ZIP creation.
- Only Core `evazar-core.php`, `product-index.php`, release notes and regression-test expectations changed from Core 2.9.84.76. Worker and `cache-purge.php` are byte-identical to the baseline.

## Not verified
No production database or real MySQL/MariaDB query plan was available. Live AJAX latency, index row coverage, and production backfill duration need to be checked after installation.
