# Deep Review QA — EVazar Core 2.9.84.34 / Worker 1.13.23
Date: 2026-10-25

## Review against Core 2.9.84.32 and Worker 1.13.21

### Confirmed request path and safeguards
- Admin page is registered under WordPress Tools and is restricted to `manage_options`.
- Preview and create actions both require independent WordPress nonces. The preview token is random, user-scoped in a transient, and expires after 15 minutes.
- Core validates the supplied URL against approved Digikala hosts and a strict `/brand/{slug}/` or `/brand-landing/{slug}/` path before any Worker call. Query strings, fragments, userinfo, ports, traversal, encoded slash/backslash, foreign hosts, and product URLs are rejected.
- The browser submits only to WordPress `admin-post.php`; Core sends a server-side authenticated POST through `evazar_primary_worker_request()` and the configured primary Worker pool. The new route has no direct Core-to-Digikala fallback and calls only the fixed API URL `https://api.digikala.com/v1/brands/{slug}/search/`.
- Worker returns only an explicit `data.brand` identity. It does not synthesize a slug from `brand_en`, title, or public WordPress slug. An explicit conflicting API URL blocks registration even if the code matches. Confirmation re-fetches identity and compares ID, code, both names, source URL/slug, and proposed public slug before creating anything.
- The create step checks duplicate source ID, duplicate normalized source URL, occupied public slug, and redirect-reserved slug. It creates one new `evazar_brand` term, writes and reads back source metadata, sets verified only after write-back checks, and removes only the just-created term if the metadata verification fails. No products are assigned and no existing term or redirect is changed.

### Issues found in the first build and corrected here
1. The queue's provenance allowlist omitted newer metadata-repair/registration stamps, so a just-registered brand could be treated as incomplete during existing-product taxonomy identity checks. Core 2.9.84.34 now accepts those trusted stamps.
2. Upstream API 429/5xx responses from Worker 1.13.22 lacked `X-Evazar-Error-Scope: source`, which could lead Core to cool down a healthy Worker as if the Worker itself failed. Worker 1.13.23 labels source/API failures so they do not trigger the Worker cooldown.
3. The first Worker build checked only the optional `Content-Length`; 1.13.23 also checks actual UTF-8 request-body size.
4. The first build did not enqueue the newly registered brand for taxonomy SEO; Core 2.9.84.34 now calls the existing SEO queue after metadata verification.

### Regression results (local stubs/mocked network)
- Worker brand/source regression: **41 passed, 0 failed** (includes identity mismatch, API 429/503 source classification, and actual body-size limit).
- Worker authenticated brand-audit regression: **6 passed, 0 failed**.
- Core brand/source regression: **120 passed, 0 failed**.
- Brand metadata repair regression: **26 passed, 0 failed**.
- Category metadata repair regression: **16 passed, 0 failed**.
- Queue taxonomy identity sync regression: **11 passed, 0 failed**, including 2.9.84.32 and registration provenance acceptance.
- Brand selector regression: **24 passed, 0 failed**.
- Gemini cooldown/recovery: **32 assertions passed**.
- Registration-tool regression: **13 passed, 0 failed**.
- PHP syntax: all PHP files passed `php -l`; Worker and test JS passed `node --check`.
- Worker embedded in Core and standalone Worker JS are byte-identical. ZIP integrity checked.

### Cache scope clarification
`cache-purge.php` was not edited and remains byte-for-byte identical to Core 2.9.84.32. However, like any newly created `evazar_brand` term, `wp_insert_term()` fires WordPress's existing `created_evazar_brand` hook, which may invoke the existing exact-term archive purge. The registration tool does not call cache-purge APIs directly and introduces no new cache-purge code.

### Limits
These checks are local and use mocked API responses/WordPress stubs. No live WordPress DB or Cloudflare deployment was accessed. Before production use, deploy Worker 1.13.23 to every configured primary Worker and smoke-test a known brand URL in the admin preview; only then confirm a registration.
