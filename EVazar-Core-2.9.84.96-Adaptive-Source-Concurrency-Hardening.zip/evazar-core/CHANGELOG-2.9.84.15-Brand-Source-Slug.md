# EVazar Core 2.9.84.15 — Canonical Digikala Brand Slugs

## Changes
- Treat the explicitly extracted Digikala `brand.url.uri` path as the authoritative source for the EVazar brand term slug.
- Persist upstream `brand.id` and `brand.code` as term metadata for stable identity checks across imports.
- When an imported product confirms an existing legacy term's identity, migrate its public slug to the source URL slug and register the former public slug as a direct 301 mapping.
- Prevent a term from being reused when its stored Digikala brand ID conflicts with the incoming source ID, or when a different previously verified source path conflicts and no matching source ID proves continuity.
- If a new brand has no explicit source URL, do not create a new public brand term from a guessed `brand_en` slug. Existing terms can still be reused conservatively, but their public slug is not renamed without a source URL.
- In Brand Tools, when the admin supplies a valid Digikala brand URL for create/rename, derive the WordPress slug from that URL instead of the separately typed slug.
- Keep old public brand URLs routed through the existing 301 handler; redirect-map and slug collisions are not overwritten.

## Scope and safety
- No cache code, cache rules, cache purge code, queue scheduling, price/stock code, or Theme code was changed.
- This does not bulk-migrate every historical term in one run. A historical brand is migrated when a product import provides an explicit source path and its existing term can be identified safely. Rows whose source paths remain unverified must be revalidated before they can be migrated automatically.

## Compatibility baseline
- Built from Core 2.9.84.14 / Worker 1.13.13.3. Gemini product batch maximum remains 15 and taxonomy SEO batch maximum remains 5; unrelated batch-limit changes are excluded.
