# QA — EVazar Core 2.9.84.92 Taxonomy Source 502 Classification

## Regression cases

- Worker 1.13.27 public source-page 502 with `X-Evazar-Source-*` headers is classified as a source error.
- Legacy taxonomy API 502 with `X-Evazar-Upstream-*` headers and a Digikala host is classified as a source error.
- Source-scoped failures do not fan out to other Worker URLs and do not cool down healthy Worker endpoints.
- Bare 502 without source provenance remains a Worker failure, fails over across eligible Workers, and applies per-Worker cooldown.
- Source diagnostics retain only bounded, sanitized metadata; no raw response body, token, or secrets are logged.
- Existing timeout lease safety and taxonomy queue retry classification remain covered.

## Worker compatibility

- Embedded Worker file remains version 1.13.27 and unchanged.
- No update to any deployed Cloudflare Worker is required.

## Validation boundary

Local PHP/Node tests only; not exercised on the live cPanel/WordPress/Cloudflare/Digikala stack.
