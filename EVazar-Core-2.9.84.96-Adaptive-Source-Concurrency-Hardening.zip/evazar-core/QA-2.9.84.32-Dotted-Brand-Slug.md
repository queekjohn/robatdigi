# QA — EVazar Core 2.9.84.32 / Worker 1.13.21

## Purpose
Fix the valid Digikala source brand slug `j.one`, which previous validators rejected because `.` was not an accepted slug character.

## Expected behavior
- `/brand/j.one` and `/brand-landing/j.one/` normalize to the same metadata source path `/brand/j.one/`.
- WordPress public slug `j-one` is preserved; source metadata retains the original source identity `j.one`.
- The source-page proxy accepts the dotted path and verifies that the final redirect still identifies `j.one`, rejecting redirects to another brand.
- Metadata repair only saves after two independent product samples agree and all owner/conflict checks pass.
- `mo` remains blocked by name mismatch until explicit review; a URL alone does not prove equivalence between term name `مو` and source page title `ام اند او`.
- `carrera` remains blocked if independent attached products report conflicting brand identities.

## Local checks
- Core brand-source regression includes dotted URL, brand-landing alias and generic source-page cases.
- Worker regression includes dotted URL normalization, identity parsing, source-page redirect proxy, and a different-brand redirect rejection.
- Metadata-repair regression includes the exact `j.one` source slug and asserts that only metadata changes while public `j-one` remains.
- PHP syntax, JavaScript syntax and ZIP integrity checked separately.
- Embedded Worker and standalone Worker source must be byte-identical.

## Limits
No live WordPress database or Cloudflare account was accessed; these are local regressions only. No production metadata is changed by the tests.
