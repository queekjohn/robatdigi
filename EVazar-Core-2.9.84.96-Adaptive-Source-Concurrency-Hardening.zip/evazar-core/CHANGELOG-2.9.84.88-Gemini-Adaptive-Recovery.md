# EVazar Core 2.9.84.88 — Faster Gemini Adaptive Recovery

- Gemini adaptive recovery now requires three consecutive successful batch requests instead of ten.
- Each recovery step increases the effective product batch size by 10, respecting the administrator-configured cap.
- Parallelism still increases by one per recovery step, up to the existing maximum of five.
- Existing failure classification, failure-driven reductions, and handling of uncertain/Worker/source errors remain unchanged.
