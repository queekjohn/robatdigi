# EVazar Core 2.9.84.25 — bulk brand replacement

- Bulk editing products now replaces each selected product's existing `evazar_brand` assignments with the selected brand term IDs.
- Selecting multiple brands replaces the existing list with exactly those selected IDs.
- If no brand is selected, the bulk action does not alter any existing brand assignment.
- Quick Edit remains additive; full product edit remains exact replacement.
- Search and selection continue to use term IDs; duplicate Persian names remain distinguishable by slug and ID.
- No brand records, slugs, redirects, imports, queue behavior, cache behavior, or Worker code were changed.
