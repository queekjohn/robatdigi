# QA — EVazar Core 2.9.84.94

## Regression addressed

The pre-Gemini report for DKP 22027358 showed Worker HTTP 503 with body error `source_server_error` and upstream v2 HTTP 502, but the diagnostic rendered `Worker=Array` and classified the response as `worker_http_503`. The parallel Requests response adapter had retained array-valued header values; later string casts lost `X-Evazar-Error-Scope` and `X-Evazar-Worker-Version`.

## Focused coverage added

- `X-Evazar-Error-Scope: ['source']` is normalized to `source` in parallel responses.
- `X-Evazar-Worker-Version: ['1.13.27']` is preserved as `1.13.27`, never `Array`.
- Worker HTTP 503 with `source_server_error` and upstream v2=502 is recorded as `worker_upstream_source_server_error` with `error_scope=source`.
- This upstream source failure is not sent through serial failover and does not create a Worker cooldown.
- The same classification works when the scope header is absent but the Worker's source-error JSON includes a version and explicit upstream diagnostics.
- Serial primary-Worker dispatch applies the same array-header normalization and source classification.
- Queue policy explicitly verifies that Worker HTTP 503 + upstream v2 HTTP 502 defers only the affected product for 60 seconds without treating it as a queue-wide restriction.
- Pre-Gemini event coverage verifies separate Worker HTTP 503 and upstream v2 HTTP 502 fields, visible `source` scope, and the actual Worker version `1.13.27`.
- Existing Worker/runtime 502 failover, product 404 handling, source 429 handling, transport leases, and product parallel-wave behaviors remain covered by regression tests.

## Validation boundary

Validation results: 28 PHP regression scripts (0 failures), 4 JavaScript regression scripts (0 failures), 41 PHP syntax checks, and 7 JavaScript syntax checks passed. Focused assertions also cover the exact `503/502` product event and its item-only queue deferral.

The local suite uses WordPress/Requests test doubles and synthetic source responses. It validates Core's classification and queue behavior, not the availability of Digikala's upstream API or the production Cloudflare network. Production PHP 8.3 and live cPanel/Cloudflare validation remain post-install checks.
