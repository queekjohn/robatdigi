# Deploy Worker 1.13.23

Deploy `digikala-worker.js` from the standalone Worker ZIP to every primary Worker in Core's configured pool. Match the `EVAZAR_INTERNAL_TOKEN` secret to Core's `evazar_cf_worker_token`.

This version tags source/API failures on `/brand-source/inspect` with `X-Evazar-Error-Scope: source`, so upstream errors do not incorrectly cool down a healthy Worker. It also enforces the JSON body-size limit without relying solely on `Content-Length`.
