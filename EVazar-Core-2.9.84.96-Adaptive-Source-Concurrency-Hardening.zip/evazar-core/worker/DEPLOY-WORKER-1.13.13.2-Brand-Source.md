# Cloudflare Worker 1.13.13.2 — deployment note

1. Deploy the complete `digikala-worker.js` file, not only the added helper. Keep the existing Worker name, routes, bindings, secrets and environment variables unchanged.
2. Confirm the response header `X-Evazar-Worker-Version` is `1.13.13.2` after deployment.
3. Run a fresh product-source request for a product whose upstream `brand` object contains an explicit official Digikala `/brand/<slug>/` path or URL. Confirm `product.brand_source_path` is returned as a normalized relative path.
4. Run a product whose brand object contains only `title_fa`, `title_en`, or `code`. Confirm `product.brand_source_path` is omitted rather than inferred.
5. Import one known product and confirm Core stores `_evazar_dk_url` independently from the public WordPress `evazar_brand` term slug. If the upstream payload does not contain an explicit brand URL/path, the source URL should remain unverified and the taxonomy source-fetch should be skipped.

The local regression tests use mocked upstream responses and do not prove what the current live Digikala API returns. Do not mark a path as canonically verified solely because the local synthetic test passed.
