/**
 * Cloudflare Worker for EVazar / Digikala.
 * Version 1.13.27: accept explicit Digikala source-path segments ending in one hyphen, aligned with Core validation.
 * Product/source extraction, image, price/stock, and authenticated AI API proxy routes remain.
 */
const DIGIKALA_WORKER_VERSION = '1.13.27';

export default {
    async fetch(request, env, ctx) {
        return handleRequest(request, env, ctx);
    }
};


function hasInternalToken(request, env) {
    const expected = (env && env.EVAZAR_INTERNAL_TOKEN) ? String(env.EVAZAR_INTERNAL_TOKEN).trim() : '';
    if (!expected) return false;
    const received = (request.headers.get('X-Evazar-Internal-Token') || '').trim();
    return received !== '' && received === expected;
}

function requireInternalToken(request, env) {
    const expected = (env && env.EVAZAR_INTERNAL_TOKEN) ? String(env.EVAZAR_INTERNAL_TOKEN).trim() : '';
    if (!expected || !hasInternalToken(request, env)) {
        return new Response(JSON.stringify({ success: false, message: 'Unauthorized.' }), {
            status: 401,
            headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
        });
    }
    return null;
}

/**
 * Narrow, authenticated, read-only proxy for the EVazar Brand Live Verifier.
 * This endpoint never uses the product response cache and returns only the product
 * identity and brand fields required for the audit. It cannot fetch arbitrary URLs.
 */
async function handleBrandAuditProduct(request, env, corsHeaders) {
    const authError = requireInternalToken(request, env);
    const noStoreHeaders = {
        ...corsHeaders,
        'Cache-Control': 'no-store, no-cache, must-revalidate',
        'CDN-Cache-Control': 'no-store',
        'Pragma': 'no-cache',
        'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION
    };
    if (authError) {
        const headers = new Headers(authError.headers);
        for (const [key, value] of Object.entries(noStoreHeaders)) headers.set(key, value);
        return new Response(authError.body, { status: authError.status, statusText: authError.statusText, headers });
    }
    if (request.method !== 'POST') {
        return new Response(JSON.stringify({ success: false, error: 'method_not_allowed', message: 'Use POST.' }), {
            status: 405, headers: { ...noStoreHeaders, 'Allow': 'POST' }
        });
    }
    const contentLength = Number.parseInt(request.headers.get('Content-Length') || '', 10);
    if (Number.isFinite(contentLength) && contentLength > 2048) {
        return new Response(JSON.stringify({ success: false, error: 'request_too_large' }), { status: 413, headers: noStoreHeaders });
    }
    let payload;
    try { payload = await request.json(); }
    catch (_) {
        return new Response(JSON.stringify({ success: false, error: 'invalid_json', message: 'Expected a JSON request body.' }), { status: 400, headers: noStoreHeaders });
    }
    const dkpId = String(payload && (payload.dkp_id ?? '')).trim();
    if (!/^[0-9]{1,15}$/.test(dkpId) || !/[1-9]/.test(dkpId)) {
        return new Response(JSON.stringify({ success: false, error: 'invalid_product_id', message: 'A numeric Digikala product ID is required.' }), { status: 400, headers: noStoreHeaders });
    }

    const upstreamHeaders = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Referer': 'https://www.digikala.com/',
        'Cache-Control': 'no-cache'
    };
    let v2Response;
    let v1Response = null;
    try { v2Response = await fetchDigiWithCookie(`https://api.digikala.com/v2/product/${dkpId}/`, upstreamHeaders, 8000); }
    catch (_) { v2Response = null; }
    const upstreamStatus = (response) => {
        if (!response) return 0;
        const headerStatus = Number.parseInt(response.headers.get('X-Evazar-Upstream-Status') || '', 10);
        return Number.isFinite(headerStatus) && headerStatus > 0 ? headerStatus : response.status;
    };
    let selectedResponse = v2Response;
    let selectedApiVersion = 'v2';
    const v2Status = upstreamStatus(v2Response);
    let v1Status = 0;
    // Do not make a second upstream request after explicit rate-limit/access-denied replies.
    // On other v2 failures, try the legacy endpoint once, preserving the existing Core fallback behavior.
    const v2Error = String(v2Response?.headers?.get('X-Evazar-Upstream-Error') || '');
    const v2TimedOut = /timeout|abort/i.test(v2Error);
    const shouldTryV1 = (!v2Response || !v2Response.ok) && ![401, 403, 429].includes(v2Status) && !v2TimedOut;
    if (shouldTryV1) {
        try { await v2Response?.body?.cancel(); } catch (_) {}
        try { v1Response = await fetchDigiWithCookie(`https://api.digikala.com/v1/product/${dkpId}/`, upstreamHeaders, 8000); }
        catch (_) { v1Response = null; }
        v1Status = upstreamStatus(v1Response);
        if (v1Response && v1Response.ok) {
            selectedResponse = v1Response;
            selectedApiVersion = 'v1';
        }
    }

    if (!selectedResponse || !selectedResponse.ok) {
        const statusList = [v2Status, v1Status].filter(status => status > 0);
        const blocked = statusList.some(code => code === 401 || code === 403);
        const bothNotFound = statusList.length >= 2 && statusList.every(code => code === 404);
        const rateLimited = statusList.includes(429);
        const status = rateLimited ? 429 : (blocked ? 502 : (bothNotFound ? 404 : (statusList.some(code => code >= 500) || !statusList.length ? 503 : 502)));
        const error = rateLimited ? 'digikala_rate_limited' : (blocked ? 'digikala_access_blocked' : (bothNotFound ? 'digikala_product_not_found' : 'digikala_upstream_unavailable'));
        return new Response(JSON.stringify({
            success: false,
            error,
            message: rateLimited
                ? 'Digikala rate-limited the request; no second API version was queried.'
                : (blocked ? 'Digikala refused the request; the brand is not classified as invalid.' : (bothNotFound ? 'The product was not found in either Digikala product API.' : 'Digikala did not return a usable product response through the Worker.')),
            product_id: dkpId,
            upstream_status_v2: v2Status,
            upstream_status_v1: v1Status
        }), { status, headers: noStoreHeaders });
    }

    let decoded;
    try { decoded = await selectedResponse.json(); }
    catch (_) {
        return new Response(JSON.stringify({
            success: false, error: 'digikala_invalid_json', message: 'The upstream response was not valid JSON.',
            product_id: dkpId, upstream_status_v2: v2Status, upstream_status_v1: v1Status, source_api_version: selectedApiVersion
        }), { status: 502, headers: noStoreHeaders });
    }
    const product = decoded && decoded.data && decoded.data.product;
    if (!product || typeof product !== 'object' || Array.isArray(product)) {
        return new Response(JSON.stringify({
            success: false, error: 'digikala_product_not_found', message: 'The upstream JSON did not contain data.product.',
            product_id: dkpId, upstream_status_v2: v2Status, upstream_status_v1: v1Status, source_api_version: selectedApiVersion
        }), { status: 404, headers: noStoreHeaders });
    }

    const rawBrand = product.brand && typeof product.brand === 'object' && !Array.isArray(product.brand) ? product.brand : null;
    const brand = rawBrand ? {
        id: Number.isSafeInteger(Number(rawBrand.id)) && Number(rawBrand.id) > 0 ? Number(rawBrand.id) : null,
        code: typeof rawBrand.code === 'string' ? rawBrand.code.slice(0, 120) : '',
        title_fa: typeof rawBrand.title_fa === 'string' ? rawBrand.title_fa.slice(0, 300) : '',
        title_en: typeof rawBrand.title_en === 'string' ? rawBrand.title_en.slice(0, 300) : '',
        url: { uri: typeof rawBrand.url?.uri === 'string' ? rawBrand.url.uri.slice(0, 2048) : '' }
    } : null;
    const responsePayload = {
        success: true,
        version: DIGIKALA_WORKER_VERSION,
        source_api_version: selectedApiVersion,
        upstream_status_v2: v2Status,
        upstream_status_v1: v1Status,
        data: {
            product: {
                id: Number.isSafeInteger(Number(product.id)) && Number(product.id) > 0 ? Number(product.id) : Number(dkpId),
                title_fa: typeof product.title_fa === 'string' ? product.title_fa.slice(0, 1000) : '',
                brand
            }
        }
    };
    return new Response(JSON.stringify(responsePayload), { status: 200, headers: noStoreHeaders });
}

// Accept only a directly represented Digikala brand URL/path found inside the upstream
// brand object. Never infer a source slug from title_en, code, or a WordPress slug.
function normalizeDigikalaBrandSourcePath(value) {
    if (typeof value !== 'string') return '';
    const input = value.trim();
    if (!input || input.length > 2048) return '';

    let path = input;
    if (/^https?:\/\//i.test(input)) {
        let parsed;
        try { parsed = new URL(input); } catch (_) { return ''; }
        const host = String(parsed.hostname || '').toLowerCase();
        const authorityMatch = input.match(/^https?:\/\/([^/?#]+)/i);
        const authority = authorityMatch ? authorityMatch[1].toLowerCase() : '';
        if (!['digikala.com', 'www.digikala.com'].includes(host)) return '';
        // Compare the raw authority too: URL.port hides an explicitly supplied default :443.
        if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password || parsed.port || authority !== host) return '';
        if (parsed.search || parsed.hash) return '';
        path = parsed.pathname;
    }

    if (!path.startsWith('/') || path.includes('\\') || path.includes('\0') || path.includes('?') || path.includes('#')) return '';
    // Percent-encoded slashes/backslashes are path separators, never a valid slug character.
    if (/%(?:2f|5c)/i.test(path)) return '';
    let decoded;
    try { decoded = decodeURIComponent(path).normalize('NFC'); } catch (_) { return ''; }
    if (decoded.includes('\\') || decoded.includes('\0') || decoded.includes('//') || /\/(?:\.|\.\.)(?:\/|$)/.test(decoded)) return '';
    // Digikala may expose the same brand through /brand/{slug}/ or redirect it to
    // /brand-landing/{slug}/. Persian/Unicode slugs are valid source identities too.
    const match = decoded.match(/^\/(?:brand|brand-landing)\/([\p{L}\p{M}\p{N}]+(?:[._-][\p{L}\p{M}\p{N}]+)*)\/?$/iu);
    if (!match) return '';
    return `/brand/${match[1].normalize('NFC').toLowerCase()}/`;
}

function extractDigikalaBrandSourcePath(brandValue, depth = 0) {
    if (depth > 6 || brandValue == null) return '';
    if (typeof brandValue === 'string') return normalizeDigikalaBrandSourcePath(brandValue);
    if (Array.isArray(brandValue)) {
        for (const value of brandValue) {
            const path = extractDigikalaBrandSourcePath(value, depth + 1);
            if (path) return path;
        }
        return '';
    }
    if (typeof brandValue === 'object') {
        for (const value of Object.values(brandValue)) {
            const path = extractDigikalaBrandSourcePath(value, depth + 1);
            if (path) return path;
        }
    }
    return '';
}

/**
 * Authenticated, read-only inspection of a manually supplied Digikala brand URL.
 * It queries only the fixed Digikala brand-search API and returns explicit API identity fields.
 * It does not accept arbitrary hosts, assign products, or write any data.
 */
async function handleBrandSourceInspect(request, env, corsHeaders) {
    const noStoreHeaders = {
        ...corsHeaders,
        'Cache-Control': 'no-store, no-cache, must-revalidate',
        'CDN-Cache-Control': 'no-store',
        'Pragma': 'no-cache',
        'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION
    };
    const sourceErrorHeaders = { ...noStoreHeaders, 'X-Evazar-Error-Scope': 'source' };
    const authError = requireInternalToken(request, env);
    if (authError) {
        const headers = new Headers(authError.headers);
        for (const [key, value] of Object.entries(noStoreHeaders)) headers.set(key, value);
        return new Response(authError.body, { status: authError.status, statusText: authError.statusText, headers });
    }
    if (request.method !== 'POST') {
        return new Response(JSON.stringify({ success: false, error: 'method_not_allowed', message: 'Use POST.' }), {
            status: 405, headers: { ...noStoreHeaders, 'Allow': 'POST' }
        });
    }
    const contentLength = Number.parseInt(request.headers.get('Content-Length') || '', 10);
    if (Number.isFinite(contentLength) && contentLength > 2048) {
        return new Response(JSON.stringify({ success: false, error: 'request_too_large' }), { status: 413, headers: noStoreHeaders });
    }
    let rawBody;
    try { rawBody = await request.text(); }
    catch (_) { return new Response(JSON.stringify({ success: false, error: 'invalid_body', message: 'Unable to read the JSON request body.' }), { status: 400, headers: noStoreHeaders }); }
    // Content-Length is not guaranteed on every transport; enforce the limit against actual UTF-8 bytes too.
    if (new TextEncoder().encode(rawBody).byteLength > 2048) {
        return new Response(JSON.stringify({ success: false, error: 'request_too_large' }), { status: 413, headers: noStoreHeaders });
    }
    let payload;
    try { payload = JSON.parse(rawBody); }
    catch (_) { return new Response(JSON.stringify({ success: false, error: 'invalid_json', message: 'Expected a JSON request body.' }), { status: 400, headers: noStoreHeaders }); }

    const suppliedPath = String(payload && (payload.source_url ?? payload.source_path ?? '')).trim();
    const sourcePath = normalizeDigikalaBrandSourcePath(suppliedPath);
    const match = sourcePath.match(/^\/brand\/([\p{L}\p{M}\p{N}]+(?:[._-][\p{L}\p{M}\p{N}]+)*)\/$/iu);
    if (!match) {
        return new Response(JSON.stringify({ success: false, error: 'invalid_brand_url', message: 'یک URL معتبر و مستقیم از صفحهٔ برند دیجی‌کالا لازم است.' }), { status: 400, headers: noStoreHeaders });
    }
    const sourceSlug = String(match[1]).normalize('NFC').toLowerCase();
    const encodedSlug = encodeURIComponent(match[1].normalize('NFC'));
    const apiUrl = `https://api.digikala.com/v1/brands/${encodedSlug}/search/`;
    const upstreamHeaders = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
        'Referer': `https://www.digikala.com${sourcePath}`,
        'Cache-Control': 'no-cache'
    };
    let upstream;
    try { upstream = await fetchDigiWithCookie(apiUrl, upstreamHeaders, 12000); }
    catch (err) {
        return new Response(JSON.stringify({ success: false, error: 'brand_api_network_error', message: 'دریافت اطلاعات برند از API دیجی‌کالا ناموفق بود.', detail: String(err && err.message || err).slice(0, 160) }), { status: 503, headers: sourceErrorHeaders });
    }
    const upstreamStatusHeader = Number.parseInt(upstream.headers.get('X-Evazar-Upstream-Status') || '', 10);
    const upstreamStatus = Number.isFinite(upstreamStatusHeader) && upstreamStatusHeader > 0 ? upstreamStatusHeader : upstream.status;
    if (!upstream.ok) {
        return new Response(JSON.stringify({ success: false, error: 'brand_api_unavailable', message: 'API دیجی‌کالا اطلاعات قابل استفاده‌ای برای این صفحهٔ برند برنگرداند.', upstream_status: upstreamStatus }), { status: upstreamStatus === 429 ? 429 : 502, headers: sourceErrorHeaders });
    }
    let decoded;
    try { decoded = await upstream.json(); }
    catch (_) { return new Response(JSON.stringify({ success: false, error: 'brand_api_invalid_json', message: 'پاسخ API برند قابل خواندن نبود.' }), { status: 502, headers: sourceErrorHeaders }); }

    const brand = decoded && decoded.data && decoded.data.brand && typeof decoded.data.brand === 'object' && !Array.isArray(decoded.data.brand)
        ? decoded.data.brand : null;
    if (!brand) {
        return new Response(JSON.stringify({ success: false, error: 'brand_identity_missing', message: 'پاسخ API صفحه را برگرداند، اما شیء صریح هویت برند (data.brand) در پاسخ وجود نداشت؛ ثبت حدسی مجاز نیست.', upstream_status: upstreamStatus }), { status: 502, headers: sourceErrorHeaders });
    }
    const id = Number.isSafeInteger(Number(brand.id)) && Number(brand.id) > 0 ? Number(brand.id) : 0;
    const code = typeof brand.code === 'string' ? brand.code.trim().slice(0, 120) : '';
    const nameFa = typeof brand.title_fa === 'string' ? brand.title_fa.trim().slice(0, 300) : '';
    const nameEn = typeof brand.title_en === 'string' ? brand.title_en.trim().slice(0, 300) : '';
    const apiUrlRaw = typeof brand.url?.uri === 'string' ? brand.url.uri.trim() : '';
    const apiBrandPath = normalizeDigikalaBrandSourcePath(apiUrlRaw);
    const apiCodeNorm = code.normalize('NFC').toLowerCase();
    const sourceSlugNorm = sourceSlug.normalize('NFC').toLowerCase();
    const urlConfirms = apiBrandPath !== '' && apiBrandPath === sourcePath;
    const codeConfirms = apiCodeNorm !== '' && apiCodeNorm === sourceSlugNorm;
    // An explicit but conflicting/malformed API URL overrides the code fallback and must block.
    const sourceRouteConfirmed = apiUrlRaw !== '' ? urlConfirms : codeConfirms;
    if (!id || !code || !nameFa || !sourceRouteConfirmed) {
        return new Response(JSON.stringify({
            success: false,
            error: 'brand_identity_unconfirmed',
            message: 'هویت برند با شناسه، کد، نام فارسی و تطبیق مسیر منبع تأیید نشد؛ هیچ ثبت خودکاری انجام نمی‌شود.',
            source_path: sourcePath,
            api_source_path: apiBrandPath,
            source_slug: sourceSlug,
            api_brand_id: id || null,
            api_brand_code: code,
            has_persian_name: Boolean(nameFa),
            upstream_status: upstreamStatus
        }), { status: 409, headers: sourceErrorHeaders });
    }
    return new Response(JSON.stringify({
        success: true,
        version: DIGIKALA_WORKER_VERSION,
        source_api: 'v1-brand-search',
        upstream_status: upstreamStatus,
        identity: {
            brand_id: String(id),
            brand_code: code,
            brand_fa: nameFa,
            brand_en: nameEn,
            source_url: sourcePath,
            source_slug: sourceSlug,
            api_source_url: apiBrandPath,
            url_confirmed: urlConfirms,
            code_confirmed: codeConfirms
        }
    }), { status: 200, headers: noStoreHeaders });
}

async function handleRequest(request, env, event) {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, X-Evazar-Internal-Token, X-EVazar-Allow-Singleton-Retry',
        'Content-Type': 'application/json; charset=utf-8'
    };

    if (request.method === 'OPTIONS') {
        return new Response(null, { headers: corsHeaders });
    }

    try {
        const urlObj = new URL(request.url);
        const pathname = urlObj.pathname;
        let dkp = urlObj.searchParams.get('dkp') || urlObj.searchParams.get('id');
        let query = (urlObj.searchParams.get('q') || urlObj.searchParams.get('search') || '').trim().slice(0, 100);
        let page = Number.parseInt(urlObj.searchParams.get('page') || '1', 10);
        if (!Number.isFinite(page)) page = 1;
        page = Math.max(1, Math.min(page, 100));
        let isFresh = urlObj.searchParams.get('fresh') === '1' || urlObj.searchParams.get('nocache') === '1';
        let route = urlObj.searchParams.get('route');
        let sourcePagePath = urlObj.searchParams.get('source_page') || '';

        // Extract DKP from URL if full product URL is provided
        const fullUrl = urlObj.searchParams.get('url');
        if (fullUrl) {
            const match = fullUrl.match(/dkp-(\d+)/i) || fullUrl.match(/product\/(\d+)/i);
            if (match) {
                dkp = match[1];
            }
        }

        // Clean DKP numeric ID
        if (dkp) {
            dkp = dkp.replace(/[^0-9]/g, '');
        }

        // 0a. Authenticated read-only Digikala brand audit. Must run before generic dkp/cache route.
        if (pathname.replace(/\/+$/, '') === '/brand-audit/product') {
            return await handleBrandAuditProduct(request, env, corsHeaders);
        }

        // 0b. Authenticated server-to-Worker brand URL inspection for the Core admin registration tool.
        if (pathname.replace(/\/+$/, '') === '/brand-source/inspect') {
            return await handleBrandSourceInspect(request, env, corsHeaders);
        }

        // 0. AI Reverse Proxy — فقط ارتباط داخلی Core
        if (pathname.includes('/ai/') || pathname.includes('/gemini') || pathname.includes('/openai') || urlObj.searchParams.get('action') === 'ai_proxy') {
            const authError = requireInternalToken(request, env);
            if (authError) return authError;
            return await handleAiProxy(request, urlObj, corsHeaders, env);
        }

        // 1. Image Proxy & Edge Cache for img.evazar.ir
        const imgParam = urlObj.searchParams.get('img') || urlObj.searchParams.get('image');
        if (pathname.includes('/digikala-') || pathname.match(/\.(jpg|jpeg|png|webp|gif|svg)$/i) || imgParam) {
            return await handleImageProxy(request, urlObj, imgParam, event);
        }

        // 1. Single Product Fetch — عمومی و cacheable؛ داده حساس یا کلید API در پاسخ نیست.
        if (dkp) {
            return await fetchSingleProduct(dkp, corsHeaders, isFresh, event);
        }

        // 2. Search / Category Query Fetch
        if (query) {
            return await fetchSearchResults(query, page, corsHeaders);
        }

        // 2b. Exact public Digikala source-page proxy for category/brand SEO content.
        // Only relative /search/ and /brand/ paths are accepted; arbitrary URLs cannot be proxied.
        if (sourcePagePath) {
            const diagnosticHeaders = {
                'Cache-Control': 'no-store',
                'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION,
                'X-Evazar-Source-Path': 'rejected'
            };
            if (request.method !== 'GET') {
                return new Response(JSON.stringify({ success: false, version: DIGIKALA_WORKER_VERSION, message: 'Method not allowed.' }), {
                    status: 405,
                    headers: { ...corsHeaders, ...diagnosticHeaders, 'Allow': 'GET' }
                });
            }
            const safePath = validateDigikalaSourcePagePath(sourcePagePath);
            if (!safePath) {
                return new Response(JSON.stringify({ success: false, version: DIGIKALA_WORKER_VERSION, message: 'Invalid source page path.' }), {
                    status: 400,
                    headers: { ...corsHeaders, ...diagnosticHeaders }
                });
            }
            const targetPageUrl = `https://www.digikala.com${safePath}`;
            // Keep the server-side request close to a normal desktop navigation. Digikala's
            // edge can return a tiny Next.js /routing/ shell to generic fetch clients.
            // These headers are isolated to public source-page requests only.
            const pageHeaders = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Language': 'en-US,en;q=0.9,fa;q=0.8',
                'Referer': 'https://www.digikala.com/',
                'Sec-CH-UA': '\"Microsoft Edge\";v=\"155\", \"Chromium\";v=\"155\", \"Not(A:Brand\";v=\"24\"',
                'Sec-CH-UA-Mobile': '?0',
                'Sec-CH-UA-Platform': '\"Windows\"',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'none',
                'Sec-Fetch-User': '?1',
                'Upgrade-Insecure-Requests': '1'
            };
            const startedAt = Date.now();
            const pageResponse = await fetchDigiWithCookie(targetPageUrl, pageHeaders);
            const upstreamTypeRaw = (pageResponse.headers.get('X-Evazar-Upstream-Type') || pageResponse.headers.get('Content-Type') || '').toLowerCase();
            const diagnostic = {
                'X-Evazar-Source-Path': safePath,
                'X-Evazar-Source-Upstream-Status': String(pageResponse.headers.get('X-Evazar-Upstream-Status') || pageResponse.status),
                'X-Evazar-Source-Upstream-Type': upstreamTypeRaw.slice(0, 100) || 'missing',
                'X-Evazar-Source-Upstream-Length': pageResponse.headers.get('Content-Length') || 'unknown',
                'X-Evazar-Source-Upstream-Host': pageResponse.headers.get('X-Evazar-Upstream-Host') || 'unknown',
                'X-Evazar-Source-Redirects': pageResponse.headers.get('X-Evazar-Upstream-Redirects') || '0',
                'X-Evazar-Source-Final-Path': pageResponse.headers.get('X-Evazar-Upstream-Final-Path') || 'unknown',
                ...(pageResponse.headers.get('X-Evazar-Redirect-Blocked') ? { 'X-Evazar-Redirect-Blocked': pageResponse.headers.get('X-Evazar-Redirect-Blocked') } : {}),
                ...(pageResponse.headers.get('X-Evazar-Upstream-Error') ? { 'X-Evazar-Upstream-Error': pageResponse.headers.get('X-Evazar-Upstream-Error') } : {}),
                'X-Evazar-Source-Fetch-Ms': String(Date.now() - startedAt),
                'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION,
                'Cache-Control': 'no-store'
            };
            if (!pageResponse.ok) {
                return new Response(JSON.stringify({
                    success: false, version: DIGIKALA_WORKER_VERSION,
                    message: `Digikala source page fetch failed (${pageResponse.status}).`,
                    upstream_status: diagnostic['X-Evazar-Source-Upstream-Status'],
                    upstream_type: diagnostic['X-Evazar-Source-Upstream-Type'],
                    upstream_host: diagnostic['X-Evazar-Source-Upstream-Host'],
                    redirect_count: diagnostic['X-Evazar-Source-Redirects'],
                    final_path: diagnostic['X-Evazar-Source-Final-Path'],
                    fetch_ms: diagnostic['X-Evazar-Source-Fetch-Ms']
                }), {
                    status: pageResponse.status === 504 ? 504 : 502,
                    headers: { ...corsHeaders, ...diagnostic, 'Content-Type': 'application/json; charset=utf-8' }
                });
            }
            const requestedBrandSlug = extractBrandRouteIdentitySlug(safePath);
            if (requestedBrandSlug) {
                const finalBrandSlug = extractBrandRouteIdentitySlug(diagnostic['X-Evazar-Source-Final-Path']);
                if (!finalBrandSlug || finalBrandSlug !== requestedBrandSlug) {
                    return new Response(JSON.stringify({
                        success: false, version: DIGIKALA_WORKER_VERSION,
                        message: 'Brand page redirected to a different or unrecognized brand path; source identity verification was rejected.',
                        source_path: safePath,
                        final_path: diagnostic['X-Evazar-Source-Final-Path'],
                        redirect_count: diagnostic['X-Evazar-Source-Redirects']
                    }), {
                        status: 502,
                        headers: { ...corsHeaders, ...diagnostic, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
                    });
                }
            }
            if (!upstreamTypeRaw.includes('text/html') && !upstreamTypeRaw.includes('application/xhtml+xml')) {
                return new Response(JSON.stringify({ success: false, version: DIGIKALA_WORKER_VERSION, message: 'Digikala source page did not return HTML.' }), {
                    status: 502,
                    headers: { ...corsHeaders, ...diagnostic, 'Content-Type': 'application/json; charset=utf-8' }
                });
            }
            const upstreamLength = Number.parseInt(pageResponse.headers.get('Content-Length') || '', 10);
            if (Number.isFinite(upstreamLength) && upstreamLength > 6 * 1024 * 1024) {
                return new Response(JSON.stringify({ success: false, version: DIGIKALA_WORKER_VERSION, message: 'Source HTML exceeds the 6 MiB safety limit.', upstream_bytes: upstreamLength }), {
                    status: 502,
                    headers: { ...corsHeaders, ...diagnostic, 'X-Evazar-Source-Bytes': String(upstreamLength), 'Content-Type': 'application/json; charset=utf-8' }
                });
            }
            let htmlBytes;
            try {
                const reader = pageResponse.body ? pageResponse.body.getReader() : null;
                if (!reader) htmlBytes = new Uint8Array(0);
                else {
                    const chunks = [];
                    let total = 0;
                    while (true) {
                        const { done, value } = await reader.read();
                        if (done) break;
                        total += value.byteLength;
                        if (total > 6 * 1024 * 1024) {
                            try { await reader.cancel('source HTML exceeds safety limit'); } catch (_) {}
                            return new Response(JSON.stringify({ success: false, version: DIGIKALA_WORKER_VERSION, message: 'Source HTML exceeds the 6 MiB safety limit.', upstream_bytes_at_least: total }), {
                                status: 502,
                                headers: { ...corsHeaders, ...diagnostic, 'X-Evazar-Source-Bytes': `>${6 * 1024 * 1024}`, 'Content-Type': 'application/json; charset=utf-8' }
                            });
                        }
                        chunks.push(value);
                    }
                    htmlBytes = new Uint8Array(total);
                    let offset = 0;
                    for (const chunk of chunks) { htmlBytes.set(chunk, offset); offset += chunk.byteLength; }
                }
            } catch (err) {
                return new Response(JSON.stringify({ success: false, version: DIGIKALA_WORKER_VERSION, message: 'Failed while reading source HTML.', error: String(err && err.message || err).slice(0, 180) }), {
                    status: 502,
                    headers: { ...corsHeaders, ...diagnostic, 'Content-Type': 'application/json; charset=utf-8' }
                });
            }
            // Validate that a 200 HTML body is the requested page, not Digikala's
            // generic /routing/ app shell. Without this check Core can misclassify it
            // as an ordinary page with zero usable source text.
            const sourceHtml = new TextDecoder('utf-8').decode(htmlBytes);
            const canonicalTag = (sourceHtml.match(/<link\b(?=[^>]*\brel=[\"']canonical[\"'])[^>]*>/i) || [])[0] || '';
            const canonicalValue = ((canonicalTag.match(/\bhref=[\"']([^\"']+)[\"']/i) || [])[1] || '').trim();
            const titleValue = (((sourceHtml.match(/<title\b[^>]*>([\s\S]*?)<\/title>/i) || [])[1] || '')
                .replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim()).slice(0, 180);
            const nextDataMatch = sourceHtml.match(/<script\b[^>]*id=[\"']__NEXT_DATA__[\"'][^>]*>([\s\S]*?)<\/script>/i);
            let nextPage = '';
            if (nextDataMatch) {
                try {
                    const nextData = JSON.parse(nextDataMatch[1]);
                    nextPage = String(nextData && nextData.page || '').slice(0, 100);
                } catch (_) {
                    const pageMatch = nextDataMatch[1].match(/\"page\"\s*:\s*\"([^\"]+)\"/);
                    if (pageMatch) nextPage = pageMatch[1].slice(0, 100);
                }
            }
            const routingCanonical = /(?:^|\/)routing\/?(?:[?#].*)?$/i.test(canonicalValue);
            const isRoutingShell = routingCanonical || nextPage === '/routing';
            const contentStatus = isRoutingShell ? 'routing-shell' : 'html-unverified';
            // HTTP header values must be ASCII ByteStrings; percent-encode the Persian title for safe diagnostics.
            diagnostic['X-Evazar-Source-Title'] = titleValue ? encodeURIComponent(titleValue).slice(0, 250) : 'missing';
            diagnostic['X-Evazar-Source-Canonical'] = canonicalValue ? (/[^\x20-\x7e]/.test(canonicalValue) ? encodeURIComponent(canonicalValue).slice(0, 500) : canonicalValue) : 'missing';
            diagnostic['X-Evazar-Source-Content-Status'] = contentStatus;

            if (isRoutingShell) {
                return new Response(JSON.stringify({
                    success: false,
                    version: DIGIKALA_WORKER_VERSION,
                    message: 'Digikala returned its /routing/ application shell instead of the requested source page.',
                    source_path: safePath,
                    upstream_status: diagnostic['X-Evazar-Source-Upstream-Status'],
                    canonical: canonicalValue || 'missing',
                    title: titleValue || 'missing',
                    next_page: nextPage || 'missing',
                    source_bytes: htmlBytes.byteLength
                }), {
                    status: 502,
                    headers: { ...corsHeaders, ...diagnostic, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }
                });
            }

            return new Response(request.method === 'HEAD' ? null : htmlBytes, {
                status: 200,
                headers: {
                    ...corsHeaders,
                    ...diagnostic,
                    'Content-Type': 'text/html; charset=utf-8',
                    'Content-Length': String(htmlBytes.byteLength),
                    'X-Evazar-Source-Bytes': String(htmlBytes.byteLength),
                    'Cache-Control': 'no-store, no-cache, must-revalidate'
                }
            });
        }

        // 3. Narrowly allowlisted taxonomy API proxy plus legacy category/brand API routes.
        if (route) {
            // Exact category+brand listing endpoint: used only to retrieve the source SEO fields
            // emitted by Digikala for routes like /search/category-washing-machines/daewoo/.
            // Parse and rebuild the upstream URL; never concatenate an untrusted arbitrary route.
            let categoryBrandRouteUrl = null;
            try {
                if (typeof route === 'string' && route.length <= 900 && route.startsWith('/') &&
                    !route.startsWith('//') && !route.includes('//') && !route.includes('..') &&
                    !route.includes('%') && !route.includes('\\') && !route.includes('#')) {
                    categoryBrandRouteUrl = new URL(route, 'https://api.digikala.com');
                }
            } catch (_) { categoryBrandRouteUrl = null; }

            const categoryBrandMatch = categoryBrandRouteUrl &&
                categoryBrandRouteUrl.origin === 'https://api.digikala.com' &&
                categoryBrandRouteUrl.pathname.match(/^\/discovery\/api\/v1\/categories\/([a-z0-9_-]+)\/brands\/([a-z0-9_-]+)\/products\/?$/i);

            if (categoryBrandMatch) {
                if (request.method !== 'GET' && request.method !== 'HEAD') {
                    return new Response(JSON.stringify({ success: false, version: DIGIKALA_WORKER_VERSION, message: 'Method not allowed.' }), {
                        status: 405,
                        headers: { ...corsHeaders, 'Allow': 'GET, HEAD', 'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION, 'Cache-Control': 'no-store' }
                    });
                }
                const allowedQueryKeys = new Set(['page', '_rch']);
                for (const key of categoryBrandRouteUrl.searchParams.keys()) {
                    if (!allowedQueryKeys.has(key)) {
                        return new Response(JSON.stringify({ success: false, version: DIGIKALA_WORKER_VERSION, message: 'Unsupported category-brand API query parameter.' }), {
                            status: 400,
                            headers: { ...corsHeaders, 'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION, 'Cache-Control': 'no-store' }
                        });
                    }
                }
                const pageValue = categoryBrandRouteUrl.searchParams.get('page') || '1';
                if (!/^\d{1,3}$/.test(pageValue) || Number(pageValue) < 1 || Number(pageValue) > 100) {
                    return new Response(JSON.stringify({ success: false, version: DIGIKALA_WORKER_VERSION, message: 'Invalid category-brand API page.' }), {
                        status: 400,
                        headers: { ...corsHeaders, 'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION, 'Cache-Control': 'no-store' }
                    });
                }
                const rchValue = categoryBrandRouteUrl.searchParams.get('_rch');
                if (rchValue !== null && !/^[a-z0-9_-]{1,64}$/i.test(rchValue)) {
                    return new Response(JSON.stringify({ success: false, version: DIGIKALA_WORKER_VERSION, message: 'Invalid category-brand API cache token.' }), {
                        status: 400,
                        headers: { ...corsHeaders, 'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION, 'Cache-Control': 'no-store' }
                    });
                }
                const categorySlug = categoryBrandMatch[1].toLowerCase();
                const brandSlug = categoryBrandMatch[2].toLowerCase();
                const targetApi = new URL(`https://api.digikala.com/discovery/api/v1/categories/${categorySlug}/brands/${brandSlug}/products`);
                targetApi.searchParams.set('page', pageValue);
                if (rchValue !== null) targetApi.searchParams.set('_rch', rchValue);
                const referer = `https://www.digikala.com/search/category-${categorySlug}/${brandSlug}/`;
                const digiHeaders = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0',
                    'Accept': 'application/json, text/plain, */*',
                    'Accept-Language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
                    'Referer': referer,
                    'Sec-Fetch-Dest': 'empty',
                    'Sec-Fetch-Mode': 'cors',
                    'Sec-Fetch-Site': 'same-site'
                };
                const upstream = await fetchDigiWithCookie(targetApi.toString(), digiHeaders);
                const proxyHeaders = new Headers(upstream.headers);
                proxyHeaders.set('Access-Control-Allow-Origin', '*');
                proxyHeaders.set('X-Evazar-Worker-Version', DIGIKALA_WORKER_VERSION);
                proxyHeaders.set('X-Evazar-Taxonomy-Source-API', 'category-brand-products');
                proxyHeaders.set('X-Evazar-Taxonomy-Category', categorySlug);
                proxyHeaders.set('X-Evazar-Taxonomy-Brand', brandSlug);
                proxyHeaders.set('Cache-Control', 'no-store');
                return new Response(request.method === 'HEAD' ? null : upstream.body, {
                    status: upstream.status,
                    statusText: upstream.statusText,
                    headers: proxyHeaders
                });
            }

            // Existing broad-but-host-fixed API routes stay compatible with prior Core versions.
            if (route.startsWith('/v1/categories/') || route.startsWith('/v1/brands/')) {
                const targetApiUrl = `https://api.digikala.com${route}`;
                const digiHeaders = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Accept': 'application/json, text/plain, */*',
                    'Referer': 'https://www.digikala.com/'
                };
                const response = await fetchDigiWithCookie(targetApiUrl, digiHeaders);
                const proxyHeaders = new Headers(response.headers);
                proxyHeaders.set('Access-Control-Allow-Origin', '*');
                proxyHeaders.set('X-Evazar-Worker-Version', DIGIKALA_WORKER_VERSION);
                return new Response(response.body, { status: response.status, headers: proxyHeaders });
            }
        }

        return new Response(JSON.stringify({
            success: false,
            version: DIGIKALA_WORKER_VERSION,
            message: 'لطفاً پارامتر dkp یا q را ارسال کنید.'
        }), { status: 400, headers: corsHeaders });

    } catch (err) {
        return new Response(JSON.stringify({
            success: false,
            version: DIGIKALA_WORKER_VERSION,
            error: err.message
        }), { status: 500, headers: { ...corsHeaders, 'Cache-Control': 'no-cache, no-store, must-revalidate', 'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION } });
    }
}

/**
 * Resilient Image Proxy & 1-Year Cloudflare Edge Cache for img.evazar.ir
 */
async function handleImageProxy(request, urlObj, imgParam, event) {
    if (request.method !== 'GET') {
        return new Response('Method not allowed', { status: 405 });
    }

    let targetUrl = '';
    if (imgParam) {
        targetUrl = imgParam;
    } else {
        const path = urlObj.pathname.startsWith('/') ? urlObj.pathname.substring(1) : urlObj.pathname;
        targetUrl = `https://dkstatics-public.digikala.com/${path}${urlObj.search}`;
    }

    if (!/^https?:\/\//i.test(targetUrl)) {
        targetUrl = `https://${targetUrl}`;
    }

    // Recovery control parameters belong to the Worker, never to the Digikala origin URL.
    const forceRetry = urlObj.searchParams.get('evazar_retry') === '1' || urlObj.searchParams.get('evazar_direct_retry') === '1';
    try {
        const parsed = new URL(targetUrl);
        parsed.searchParams.delete('evazar_retry');
        parsed.searchParams.delete('evazar_direct_retry');
        targetUrl = parsed.toString();
    } catch (_) {
        return new Response('Invalid image URL', { status: 400, headers: { 'Cache-Control': 'no-store' } });
    }

    let parsedTarget;
    try {
        parsedTarget = new URL(targetUrl);
    } catch (_) {
        return new Response('Invalid image URL', { status: 400, headers: { 'Cache-Control': 'no-store' } });
    }

    const allowedImageHosts = new Set(['dkstatics-public.digikala.com']);
    if (!allowedImageHosts.has(parsedTarget.hostname.toLowerCase())) {
        return new Response('Image host not allowed', { status: 403, headers: { 'Cache-Control': 'no-store' } });
    }

    // ساخت کلید امن کش بدون تداخل هدرهای کلاینت
    let cacheKey;
    try {
        cacheKey = new Request(targetUrl, { method: 'GET' });
    } catch (_) {
        cacheKey = new Request(targetUrl);
    }

    const cache = caches.default;
    let response = null;
    if (!forceRetry) {
        try {
            response = await cache.match(cacheKey);
        } catch (_) {}
    }

    if (response) {
        const cachedType = (response.headers.get('Content-Type') || '').toLowerCase();
        if (response.ok && cachedType.startsWith('image/')) {
            const newHeaders = new Headers(response.headers);
            newHeaders.set('Access-Control-Allow-Origin', '*');
            newHeaders.set('X-Evazar-CDN-Cache', 'HIT');
            newHeaders.set('X-Evazar-Worker-Version', DIGIKALA_WORKER_VERSION);
            return new Response(response.body, {
                status: response.status,
                statusText: response.statusText,
                headers: newHeaders
            });
        }
        // Old Worker releases could put 4xx/5xx or HTML denial pages into Cache API.
        try { await cache.delete(cacheKey); } catch (_) {}
    }

    const fetchHeaders = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
        'Referer': 'https://www.digikala.com/'
    };

    const imageAttempts = [
        { delay: 0, sendReferer: true },
        { delay: 250, sendReferer: false },
        { delay: 750, sendReferer: true }
    ];

    let upstreamRes = null;
    for (let attempt = 0; attempt < imageAttempts.length; attempt++) {
        const attemptCfg = imageAttempts[attempt];
        if (attemptCfg.delay > 0) {
            await new Promise(resolve => setTimeout(resolve, attemptCfg.delay));
        }

        const attemptHeaders = { ...fetchHeaders };
        if (!attemptCfg.sendReferer) {
            delete attemptHeaders['Referer'];
        }

        try {
            // Do not force-cache an upstream 2xx response before validating its MIME type:
            // a challenge/HTML body at a .jpg URL must never become a year-long cached entry.
            // Validated image responses are cached below, after Content-Type validation.
            const fetchOptions = { headers: attemptHeaders, cache: 'no-store' };
            const candidate = await fetch(targetUrl, fetchOptions);

            upstreamRes = candidate;
            const candidateType = (candidate.headers.get('Content-Type') || '').toLowerCase();
            const candidateIsImage = candidate.ok && candidateType.startsWith('image/');
            const retryableStatus = [404, 429, 500, 502, 503, 504, 522, 524].includes(candidate.status);
            const retryableNonImage = candidate.ok && !candidateIsImage;
            const hasMoreAttempts = attempt < imageAttempts.length - 1;

            // A 200 HTML/JSON response is still a failed image request: retry it just like
            // a transient gateway/rate-limit failure, without storing that response in cache.
            if (candidateIsImage) break;
            if (hasMoreAttempts && (retryableStatus || retryableNonImage)) {
                try { if (candidate.body) await candidate.body.cancel(); } catch (_) {}
                continue;
            }
            break;
        } catch (e) {
            upstreamRes = null;
        }
    }

    if (!upstreamRes) {
        return new Response('Error loading image', { status: 502, headers: {
            'Cache-Control': 'no-store', 'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION,
            'X-Evazar-Image-Error': 'origin-fetch-failed'
        } });
    }

    if (!upstreamRes.ok) {
        return new Response('Image not found', {
            status: upstreamRes.status,
            headers: {
                'Cache-Control': 'no-store', 'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION,
                'X-Evazar-Origin-Status': String(upstreamRes.status),
                'X-Evazar-Image-Error': 'origin-http-error'
            }
        });
    }

    const upstreamType = (upstreamRes.headers.get('Content-Type') || '').toLowerCase();
    if (!upstreamType.startsWith('image/')) {
        return new Response('Origin returned a non-image response', {
            status: 502,
            headers: {
                'Cache-Control': 'no-store',
                'CDN-Cache-Control': 'no-store',
                'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION,
                'X-Evazar-Image-Error': 'non-image-origin-response',
                'X-Evazar-Origin-Status': String(upstreamRes.status),
                'X-Evazar-Origin-Content-Type': (upstreamRes.headers.get('Content-Type') || 'missing').split(';')[0].slice(0, 100)
            }
        });
    }

    const responseHeaders = new Headers(upstreamRes.headers);
    responseHeaders.set('Access-Control-Allow-Origin', '*');
    // Explicit recovery requests must reach this Worker again on future retries; do not
    // allow browser/edge response caches to short-circuit those URLs.
    responseHeaders.set('Cache-Control', forceRetry ? 'no-store' : 'public, max-age=31536000, immutable');
    responseHeaders.set('CDN-Cache-Control', forceRetry ? 'no-store' : 'public, max-age=31536000, stale-if-error=604800');

    const upstreamCacheStatus = (upstreamRes.headers.get('CF-Cache-Status') || '').toUpperCase();
    responseHeaders.set('X-Evazar-CDN-Cache', upstreamCacheStatus === 'HIT' ? 'UPSTREAM-HIT' : 'MISS');
    responseHeaders.set('X-Evazar-Worker-Version', DIGIKALA_WORKER_VERSION);
    responseHeaders.set('X-Evazar-Image-Retry', forceRetry ? 'FORCED' : 'AUTO');
    responseHeaders.set('Vary', 'Accept');
    if (!responseHeaders.get('Content-Type')) {
        responseHeaders.set('Content-Type', 'image/jpeg');
    }
    // حذف قطعی Set-Cookie برای جلوگیری از Cache ناامن/خطای 520
    responseHeaders.delete('Set-Cookie');

    response = new Response(upstreamRes.body, {
        status: upstreamRes.status,
        statusText: upstreamRes.statusText,
        headers: responseHeaders
    });

    // L1 محلی را نگه می‌داریم تا درخواست‌های هم‌زمان در یک Edge سریع پاسخ بگیرند؛
    // subrequest بالا نیز از مسیر fetch/cf cache استفاده می‌کند و با Tiered Cache سازگار است.
    if (request.method === 'GET' && response.ok && (response.headers.get('Content-Type') || '').toLowerCase().startsWith('image/') && event && typeof event.waitUntil === 'function') {
        try {
            const responseToCache = response.clone();
            responseToCache.headers.delete('Set-Cookie');
            // Cache API stores only this validated image, even when the public recovery
            // response itself is no-store to force a future retry request through the Worker.
            responseToCache.headers.set('Cache-Control', 'public, max-age=31536000, immutable');
            event.waitUntil(cache.put(cacheKey, responseToCache).catch(() => {}));
        } catch (_) {}
    }

    return response;
}

/**
 * Safe Digikala fetch with bounded, allowlisted redirects.
 * Cookies are forwarded only to the exact same origin that issued them.
 */
function validateDigikalaSourcePagePath(input) {
    if (typeof input !== 'string') return '';
    const rawPath = input.trim();
    if (!rawPath || rawPath.length > 500 || !rawPath.startsWith('/') || rawPath.startsWith('//')) return '';
    if (/[?#\\\u0000-\u0020]/.test(rawPath) || /%(?:2f|5c)/i.test(rawPath)) return '';
    let decoded;
    try { decoded = decodeURIComponent(rawPath).normalize('NFC'); } catch (_) { return ''; }
    if (/[?#\\\u0000-\u0020]/.test(decoded) || decoded.includes('//')) return '';
    const segments = decoded.split('/').filter(Boolean);
    if (segments.length < 2 || segments.some(seg => seg === '.' || seg === '..')) return '';
    const route = String(segments[0] || '').toLowerCase();
    if (!['search', 'brand', 'brand-landing', 'main'].includes(route)) return '';
    const slugPattern = /^[\p{L}\p{M}\p{N}]+(?:[._-][\p{L}\p{M}\p{N}]+)*-?$/u;
    if (!segments.slice(1).every(seg => slugPattern.test(seg))) return '';
    // Re-encode each path segment so response headers stay ASCII even for Persian slugs.
    return `/${route}/${segments.slice(1).map(seg => encodeURIComponent(seg)).join('/')}/`;
}

function extractBrandRouteIdentitySlug(path) {
    if (typeof path !== 'string' || !path) return '';
    let decoded;
    try { decoded = decodeURIComponent(path).normalize('NFC'); } catch (_) { return ''; }
    const match = decoded.match(/^\/(?:brand|brand-landing)\/([\p{L}\p{M}\p{N}]+(?:[._-][\p{L}\p{M}\p{N}]+)*)\/?$/iu);
    return match ? match[1].normalize('NFC').toLowerCase() : '';
}

const DIGIKALA_FETCH_ALLOWED_HOSTS = new Set(['www.digikala.com', 'digikala.com', 'api.digikala.com']);
const DIGIKALA_REDIRECT_STATUSES = new Set([301, 302, 303, 307, 308]);

function fetchDiagnosticResponse(status, message, extraHeaders = {}) {
    return new Response(JSON.stringify({ success: false, message }), {
        status,
        headers: {
            'Content-Type': 'application/json; charset=utf-8',
            'Cache-Control': 'no-store',
            'X-Evazar-Upstream-Status': String(status),
            ...extraHeaders
        }
    });
}

async function fetchDigiWithCookie(targetUrl, baseHeaders, timeoutMs = 12000) {
    let currentUrl;
    try { currentUrl = new URL(targetUrl); }
    catch (_) { return fetchDiagnosticResponse(502, 'Invalid upstream URL.'); }
    if (currentUrl.protocol !== 'https:' || !DIGIKALA_FETCH_ALLOWED_HOSTS.has(currentUrl.hostname.toLowerCase())) {
        return fetchDiagnosticResponse(502, 'Upstream host is not allowed.', { 'X-Evazar-Redirect-Blocked': '1' });
    }

    let headers = new Headers(baseHeaders || {});
    headers.delete('Cookie');
    let redirectCount = 0;
    const maxRedirects = 5;

    while (true) {
        let response;
        try {
            response = await fetch(currentUrl.toString(), {
                headers,
                redirect: 'manual',
                signal: AbortSignal.timeout(Math.max(1000, Math.min(12000, Number(timeoutMs) || 12000)))
            });
        } catch (err) {
            const detail = String(err && (err.name || err.message) || err);
            const timedOut = /timeout|abort/i.test(detail);
            return fetchDiagnosticResponse(timedOut ? 504 : 502, timedOut ? 'Upstream request timed out.' : 'Upstream request failed.', {
                'X-Evazar-Upstream-Host': currentUrl.hostname,
                'X-Evazar-Upstream-Redirects': String(redirectCount),
                'X-Evazar-Upstream-Error': detail.slice(0, 80)
            });
        }

        if (!DIGIKALA_REDIRECT_STATUSES.has(response.status)) {
            const outHeaders = new Headers(response.headers);
            // Do not trust upstream-supplied EVazar diagnostic headers; only this proxy may set them.
            for (const internalHeader of [
                'X-Evazar-Upstream-Error', 'X-Evazar-Upstream-Host',
                'X-Evazar-Upstream-Status', 'X-Evazar-Upstream-Redirects',
                'X-Evazar-Redirect-Blocked', 'X-Evazar-Upstream-Final-Path'
            ]) outHeaders.delete(internalHeader);
            outHeaders.set('X-Evazar-Upstream-Status', String(response.status));
            outHeaders.set('X-Evazar-Upstream-Host', currentUrl.hostname);
            outHeaders.set('X-Evazar-Upstream-Redirects', String(redirectCount));
            outHeaders.set('X-Evazar-Upstream-Final-Path', currentUrl.pathname);
            return new Response(response.body, { status: response.status, statusText: response.statusText, headers: outHeaders });
        }

        if (redirectCount >= maxRedirects) {
            try { await response.body?.cancel(); } catch (_) {}
            return fetchDiagnosticResponse(502, 'Upstream redirect limit exceeded.', {
                'X-Evazar-Upstream-Host': currentUrl.hostname,
                'X-Evazar-Upstream-Redirects': String(redirectCount),
                'X-Evazar-Redirect-Blocked': 'limit'
            });
        }

        const location = response.headers.get('Location');
        if (!location) {
            try { await response.body?.cancel(); } catch (_) {}
            return fetchDiagnosticResponse(502, 'Upstream redirect had no Location header.', {
                'X-Evazar-Upstream-Host': currentUrl.hostname,
                'X-Evazar-Upstream-Redirects': String(redirectCount),
                'X-Evazar-Redirect-Blocked': 'missing-location'
            });
        }

        let nextUrl;
        try { nextUrl = new URL(location, currentUrl); }
        catch (_) {
            try { await response.body?.cancel(); } catch (_) {}
            return fetchDiagnosticResponse(502, 'Invalid upstream redirect Location.', {
                'X-Evazar-Upstream-Host': currentUrl.hostname,
                'X-Evazar-Upstream-Redirects': String(redirectCount),
                'X-Evazar-Redirect-Blocked': 'invalid-location'
            });
        }
        if (nextUrl.protocol !== 'https:' || !DIGIKALA_FETCH_ALLOWED_HOSTS.has(nextUrl.hostname.toLowerCase())) {
            try { await response.body?.cancel(); } catch (_) {}
            return fetchDiagnosticResponse(502, 'Upstream redirect to a non-allowlisted host was blocked.', {
                'X-Evazar-Upstream-Host': currentUrl.hostname,
                'X-Evazar-Upstream-Status': String(response.status),
                'X-Evazar-Upstream-Type': response.headers.get('Content-Type') || 'missing',
                'X-Evazar-Upstream-Redirects': String(redirectCount),
                'X-Evazar-Redirect-Blocked': 'host'
            });
        }

        // Never forward cookies between origins, even between two allowlisted Digikala hosts.
        const setCookie = response.headers.get('set-cookie');
        const cookiePair = setCookie ? setCookie.split(';', 1)[0].trim() : '';
        const sameOrigin = nextUrl.origin === currentUrl.origin;
        const nextHeaders = new Headers(headers);
        if (!sameOrigin) nextHeaders.delete('Cookie');
        if (sameOrigin && cookiePair && /^[!#$%&'*+.^_`|~0-9A-Za-z-]+=[^;\r\n]*$/.test(cookiePair)) {
            nextHeaders.set('Cookie', cookiePair);
        }
        try { await response.body?.cancel(); } catch (_) {}
        currentUrl = nextUrl;
        headers = nextHeaders;
        redirectCount++;
    }
}

async function fetchSingleProduct(dkpId, corsHeaders, isFresh = false, ctx = null) {
    const targetApiUrl = `https://api.digikala.com/v2/product/${dkpId}/`;

    // fallback cache محلی برای زمانی که Workers Caching در deployment فعال نشده باشد.
    const productCache = caches.default;
    const productCacheKey = new Request(`https://cache.evazar.internal/product/${encodeURIComponent(dkpId)}?v=1.12.0`, { method: 'GET' });
    if (!isFresh) {
        try {
            const cached = await productCache.match(productCacheKey);
            if (cached) {
                const hitHeaders = new Headers(cached.headers);
                hitHeaders.set('X-Evazar-Product-Cache', 'HIT');
                hitHeaders.set('X-Evazar-Fresh', '0');
                return new Response(cached.body, { status: cached.status, statusText: cached.statusText, headers: hitHeaders });
            }
        } catch (_) {}
    }
    
    const digiHeaders = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Referer': 'https://www.digikala.com/'
    };

    let response = null;
    let v2Status = 0;
    let v1Status = 0;
    let v2Error = '';
    let v1Error = '';
    try {
        response = await fetchDigiWithCookie(targetApiUrl, digiHeaders);
        v2Status = response.status || 0;
        v2Error = String(response.headers.get('X-Evazar-Upstream-Error') || '').slice(0, 80);
    } catch (err) {
        v2Error = String(err && (err.name || err.message) || err).slice(0, 80);
    }

    // Do not amplify an upstream rate limit/access denial or a timed-out v2 request
    // with a second call to Digikala. A v1 fallback is retained for other v2 failures.
    const v2TimedOut = /timeout|abort/i.test(v2Error);
    const v2RateLimitedOrDenied = [401, 403, 429].includes(v2Status);
    const v2ServerError = v2Status >= 500;
    const shouldTryV1 = (!response || !response.ok) && !v2RateLimitedOrDenied && !v2TimedOut && !v2ServerError;
    let v1SkippedReason = '';
    if (shouldTryV1) {
        try {
            response = await fetchDigiWithCookie(`https://api.digikala.com/v1/product/${dkpId}/`, digiHeaders);
            v1Status = response.status || 0;
            v1Error = String(response.headers.get('X-Evazar-Upstream-Error') || '').slice(0, 80);
        } catch (err) {
            v1Error = String(err && (err.name || err.message) || err).slice(0, 80);
            response = null;
        }
    } else if (!response || !response.ok) {
        v1SkippedReason = v2TimedOut ? 'v2 timeout'
            : (v2Status === 429 ? 'v2 rate limited'
                : ([401, 403].includes(v2Status) ? `v2 access denied (${v2Status})`
                    : (v2ServerError ? `v2 server error (${v2Status})` : 'v2 fallback guard')));
    }

    if (!response || !response.ok) {
        const attempts = [
            { version: 'v2', status: v2Status, networkError: v2Error },
            { version: 'v1', status: v1Status, networkError: v1Error, skippedReason: v1SkippedReason }
        ];
        const realUpstreamStatuses = attempts
            .filter((attempt) => attempt.status > 0 && !attempt.networkError)
            .map((attempt) => attempt.status);
        const bothNotFound = attempts.every((attempt) => attempt.status === 404 && !attempt.networkError);
        const sourceRateLimited = realUpstreamStatuses.includes(429);
        const sourceServerError = realUpstreamStatuses.some((status) => status >= 500);
        const sourceNetworkFailure = attempts.some((attempt) => Boolean(attempt.networkError));
        const noResponse = attempts.every((attempt) => !attempt.status && !attempt.networkError);
        const error = bothNotFound ? 'product_not_found'
            : sourceRateLimited ? 'source_rate_limited'
            : (sourceNetworkFailure || noResponse) ? 'source_fetch_failed'
            : sourceServerError ? 'source_server_error'
            : 'source_request_rejected';
        const status = bothNotFound ? 404 : (sourceRateLimited ? 429 : (error === 'source_request_rejected' ? 502 : 503));
        const describeAttempt = (attempt) => attempt.networkError
            ? `network-error (${attempt.networkError})`
            : (attempt.skippedReason ? `not-attempted (${attempt.skippedReason})` : (attempt.status || 'no-response'));
        const message = bothNotFound
            ? `محصول با شناسه DKP-${dkpId} در هر دو API دیجی‌کالا پیدا نشد.`
            : `منبع دیجی‌کالا پاسخ قابل‌استفاده نداد؛ وضعیت‌ها: v2=${describeAttempt(attempts[0])}، v1=${describeAttempt(attempts[1])}.`;
        return new Response(JSON.stringify({
            success: false, error, message, product_id: dkpId,
            upstream_status_v2: v2Status, upstream_status_v1: v1Status,
            upstream_error_v2: v2Error, upstream_error_v1: v1Error,
            worker_version: DIGIKALA_WORKER_VERSION
        }), {
            status,
            headers: {
                ...corsHeaders,
                'Cache-Control': 'no-cache, no-store, must-revalidate',
                'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION,
                'X-Evazar-Error-Scope': bothNotFound ? 'product' : 'source',
                ...(sourceRateLimited ? { 'X-Evazar-Retry-After': '30', 'Retry-After': '30' } : {})
            }
        });
    }

    let raw;
    try {
        raw = await response.json();
    } catch (err) {
        return new Response(JSON.stringify({
            success: false, error: 'source_invalid_json',
            message: 'دیجی‌کالا پاسخ غیرقابل‌خواندن برگرداند.',
            upstream_status: response.status || 0,
            worker_version: DIGIKALA_WORKER_VERSION
        }), { status: 502, headers: { ...corsHeaders, 'Cache-Control': 'no-store', 'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION, 'X-Evazar-Error-Scope': 'source' } });
    }
    const p = raw?.data?.product;

    if (!p) {
        return new Response(JSON.stringify({
            success: false, error: 'source_product_payload_missing',
            message: 'ساختار داده دریافتی از دیجی‌کالا فاقد محصول معتبر بود.',
            upstream_status: response.status || 0,
            worker_version: DIGIKALA_WORKER_VERSION
        }), { status: 502, headers: { ...corsHeaders, 'Cache-Control': 'no-store', 'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION, 'X-Evazar-Error-Scope': 'source' } });
    }

    // Extract Gallery Images (Zero Host Storage)
    const gallery = [];
    const mainImg = p.images?.main?.url?.[0] || '';
    if (mainImg) gallery.push(mainImg);
    if (Array.isArray(p.images?.list)) {
        for (const img of p.images.list) {
            const u = img?.url?.[0];
            if (u && !gallery.includes(u)) {
                gallery.push(u);
            }
        }
    }

    // Extract Specifications and retain the source section/group for structured display.
    // product.specs stays flat for backward compatibility; product.spec_groups carries grouping.
    const specs = [];
    const specGroups = [];
    if (Array.isArray(p.specifications)) {
        for (const sg of p.specifications) {
            if (!sg || typeof sg !== 'object' || !Array.isArray(sg.attributes)) continue;

            const groupTitleRaw = [sg.title, sg.title_fa, sg.name, sg.label, sg.group_title]
                .find(value => typeof value === 'string' && value.trim()) || '';
            const groupTitle = String(groupTitleRaw).replace(/[\r\n]+/g, ' ').replace(/\s+/g, ' ').trim();
            const groupSpecs = [];

            for (const attr of sg.attributes) {
                if (!attr || typeof attr !== 'object') continue;

                const titleRaw = (typeof attr.title === 'string' && attr.title.trim())
                    ? attr.title
                    : (typeof attr.name === 'string' && attr.name.trim() ? attr.name : (typeof attr.label === 'string' ? attr.label : ''));
                const title = titleRaw.replace(/[\r\n]+/g, ' ').replace(/\s+/g, ' ').trim();
                if (!title) continue;

                let rawValue;
                if (Array.isArray(attr.values) && attr.values.length > 0) {
                    rawValue = attr.values;
                } else if (attr.value !== undefined && attr.value !== null && attr.value !== '') {
                    rawValue = attr.value;
                } else {
                    rawValue = attr.values;
                }

                const valueItems = Array.isArray(rawValue) ? rawValue.flat(Infinity) : [rawValue];
                const valueParts = valueItems
                    .filter(value => typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean')
                    .map(value => String(value).replace(/[\r\n]+/g, ' ').replace(/\s+/g, ' ').trim())
                    .filter(Boolean);
                const cleanVal = valueParts.join('، ');
                if (!cleanVal) continue;

                const row = { title, value: cleanVal };
                specs.push(row);
                groupSpecs.push(row);
            }

            if (groupSpecs.length) {
                specGroups.push({ title: groupTitle, specs: groupSpecs });
            }
        }
    }

    // Extract Breadcrumbs (Parent Categories)
    const breadcrumbs = [];
    const rawBreadcrumbs = raw?.data?.breadcrumb
                        || raw?.data?.breadcrumbs
                        || raw?.data?.seo?.markup?.breadcrumb
                        || p?.breadcrumb
                        || p?.breadcrumb_list
                        || [];

    const productTitleFa = (p.title_fa || '').trim();

    // Digikala responses have used several explicit URL shapes over time. Accept only
    // URL/path values supplied by the source; never construct a category URL from a title.
    const explicitSourceUrl = (entry) => {
        if (typeof entry === 'string') return entry.trim();
        if (!entry || typeof entry !== 'object') return '';
        const candidates = [
            entry.uri, entry.url, entry.href, entry.path, entry.url_path,
            entry.canonical_url, entry.canonicalUrl, entry['@id'],
            entry.item?.uri, entry.item?.url, entry.item?.href, entry.item?.['@id'],
            entry.link?.uri, entry.link?.url, entry.link?.href
        ];
        for (const candidate of candidates) {
            if (typeof candidate === 'string' && candidate.trim()) return candidate.trim();
        }
        return '';
    };

    // JSON-LD and API variants may wrap crumbs in itemListElement/items.
    const breadcrumbList = Array.isArray(rawBreadcrumbs) ? rawBreadcrumbs
        : (Array.isArray(rawBreadcrumbs?.itemListElement) ? rawBreadcrumbs.itemListElement
        : (Array.isArray(rawBreadcrumbs?.items) ? rawBreadcrumbs.items
        : (Array.isArray(rawBreadcrumbs?.breadcrumb) ? rawBreadcrumbs.breadcrumb : [])));

    for (const bc of breadcrumbList) {
        const title = String(bc?.title || bc?.title_fa || bc?.name || bc?.item?.name || bc?.item?.title || '').trim();
        if (!title || title === 'دیجی‌کالا' || title.toLowerCase().startsWith('dkp-')) continue;
        const uri = explicitSourceUrl(bc?.url) || explicitSourceUrl(bc?.item) || explicitSourceUrl(bc);
        // Exclude product links, not category links.
        if (uri.includes('/product/') || (productTitleFa && title === productTitleFa)) continue;
        breadcrumbs.push({ title, url: uri });
    }

    // Direct category fallback: preserve a URL only when the API explicitly supplies it.
    const sourceCategory = p?.category || raw?.data?.category || {};
    const catTitle = String(sourceCategory?.title_fa || sourceCategory?.title || sourceCategory?.name || '').trim();
    const catUri = explicitSourceUrl(sourceCategory?.url) || explicitSourceUrl(sourceCategory?.link) || explicitSourceUrl(sourceCategory);
    if (breadcrumbs.length === 0 && catTitle) {
        breadcrumbs.push({ title: catTitle, url: catUri });
    }

    const finalCategory = catTitle || (breadcrumbs.length > 0 ? breadcrumbs[breadcrumbs.length - 1].title : '');

    // Price & BuyBox Winning Seller parsing (Digikala Marketplace Logic)
    const defaultVariant = (p.default_variant && typeof p.default_variant === 'object') ? p.default_variant : {};
    const variantList = Array.isArray(p.variants) ? p.variants.filter(v => v && typeof v === 'object') : [];
    // برخی پاسخ‌های Digikala، default_variant را ناقص برمی‌گردانند. بهترین واریانت
    // دارای قیمت و فروشنده را نیز بررسی می‌کنیم تا false-negative رخ ندهد.
    const candidateVariants = [defaultVariant, ...variantList];
    const sellableVariant = candidateVariants.find(v => {
        const price = Number(v?.price?.selling_price || 0);
        const seller = v?.seller;
        return price > 0 && seller && typeof seller === 'object' && Object.keys(seller).length > 0;
    }) || defaultVariant;
    const effectiveVariant = sellableVariant && typeof sellableVariant === 'object' ? sellableVariant : {};
    const sellingPriceRials = Number(effectiveVariant?.price?.selling_price || 0);
    const rrpPriceRials = Number(effectiveVariant?.price?.rrp_price || sellingPriceRials);
    // موجودی: ابتدا سیگنال‌های صریح واریانت/محصول را بررسی می‌کنیم. اگر API
    // وضعیت صریحی ندهد، ترکیب واریانت معتبر + قیمت فروش + فروشنده را fallback
    // می‌گیریم تا false-negative ایجاد نشود. سیگنال صریح ناموجود همیشه اولویت دارد.
    const falseTokens = ['unavailable','out_of_stock','out-of-stock','outofstock','sold_out','sold-out','not_available','not-available','inactive','disabled','ناموجود','اتمام موجودی','تمام شد','موجود نیست','قابل خرید نیست'];
    const trueTokens = ['marketable','available','in_stock','in-stock','instock','purchasable','buyable','موجود','قابل خرید','قابل‌خرید'];
    const boolKeys = ['is_available','available','in_stock','is_in_stock','is_marketable','marketable','is_purchasable','purchasable','buyable','is_buyable'];
    const textKeys = ['status','availability','availability_status','stock_status','availability_text','status_text','stock_text','purchase_status'];
    function scanAvailability(obj) {
        if (!obj || typeof obj !== 'object') return {pos:false, neg:false};
        let pos=false, neg=false;
        for (const key of boolKeys) {
            if (!(key in obj)) continue;
            const v=obj[key];
            if (v===true || v===1 || v==='1' || String(v).toLowerCase()==='true' || String(v).toLowerCase()==='yes') pos=true;
            if (v===false || v===0 || v==='0' || String(v).toLowerCase()==='false' || String(v).toLowerCase()==='no') neg=true;
        }
        for (const key of textKeys) {
            if (obj[key] == null) continue;
            const v=String(obj[key]).trim().toLowerCase();
            if (!v) continue;
            if (falseTokens.some(t=>v.includes(t))) neg=true;
            if (v==='marketable' || trueTokens.some(t=>v.includes(t))) pos=true;
        }
        return {pos,neg};
    }
    const productAvail = scanAvailability(p);
    const variantAvail = scanAvailability(defaultVariant);
    const effectiveVariantAvail = scanAvailability(effectiveVariant);
    const availabilitySource = (productAvail.neg || variantAvail.neg || effectiveVariantAvail.neg) ? 'explicit_unavailable' : ((productAvail.pos || variantAvail.pos || effectiveVariantAvail.pos) ? 'explicit_available' : 'fallback');
    const isAvailable = availabilitySource === 'explicit_unavailable'
        ? false
        : (availabilitySource === 'explicit_available'
            ? true
            : sellingPriceRials > 0 && Boolean(effectiveVariant?.seller));
    const sellerTitle = effectiveVariant?.seller?.title || 'دیجی‌کالا';
    const sellerCode = effectiveVariant?.seller?.code || '';
    const sellerRating = effectiveVariant?.seller?.stars || effectiveVariant?.seller?.rating || null;
    const warranty = effectiveVariant?.warranty?.title_fa || '';
    const leadTime = effectiveVariant?.shipment_methods?.description || '';

    // Rating & Satisfaction Logic (Zero-review honest handling)
    const rawRatingCount = (typeof p.rating?.count !== 'undefined' && p.rating.count !== null) ? Number(p.rating.count) : (Number(p.rating?.rates_count) || 0);
    let rating = 0;
    let satisfaction = 0;
    let rating_count = rawRatingCount;

    if (rating_count > 0 && p.rating?.rate) {
        rating = Number(p.rating.rate);
        if (rating > 5) {
            satisfaction = Math.floor(rating);
            rating = Number((rating / 20).toFixed(1));
        } else {
            satisfaction = Math.floor((rating / 5) * 100);
        }
        
        // Use true satisfaction if count_buyers exists
        if (p.rating?.count_buyers && p.rating?.count && p.rating.count > 0) {
            const calculated = Math.round((p.rating.count_buyers / p.rating.count) * 100);
            satisfaction = calculated > 100 ? 100 : (calculated < 0 ? 0 : calculated);
        }
    }

    // استخراج جامع و عمیق تمام بخش‌های معرفی و بررسی تخصصی دیجی‌کالا
    const descParts = [];

    // ۱. متن معرفی اولیه (review.description)
    const introDesc = (p.review?.description || '').trim();
    if (introDesc) {
        descParts.push(introDesc);
    }

    // ۲. بررسی تخصصی کامل (expert_reviews شامل تمام review_sections و زیربخش‌های متنی)
    if (p.expert_reviews) {
        if (typeof p.expert_reviews === 'string' && p.expert_reviews.trim()) {
            if (!descParts.includes(p.expert_reviews.trim())) {
                descParts.push(p.expert_reviews.trim());
            }
        } else if (typeof p.expert_reviews === 'object') {
            const rawSections = p.expert_reviews.review_sections || p.review?.review_sections || [];
            if (Array.isArray(rawSections)) {
                for (const sec of rawSections) {
                    const secTitle = (sec?.title || '').trim();
                    const subTexts = [];
                    if (Array.isArray(sec?.sections)) {
                        for (const sub of sec.sections) {
                            const txt = (sub?.text || sub?.template || '').replace(/&zwnj;/g, '‌').replace(/<[^>]+>/g, '').trim();
                            if (txt && !txt.startsWith('http')) subTexts.push(txt);
                        }
                    } else if (sec?.text) {
                        const txt = (sec.text || '').replace(/&zwnj;/g, '‌').replace(/<[^>]+>/g, '').trim();
                        if (txt && !txt.startsWith('http')) subTexts.push(txt);
                    }
                    if (subTexts.length > 0) {
                        const block = (secTitle ? secTitle + ":\n" : "") + subTexts.join("\n");
                        if (!descParts.some(prev => prev.includes(subTexts[0]))) {
                            descParts.push(block);
                        }
                    }
                }
            }

            if (descParts.length === 0 && typeof p.expert_reviews.description === 'string' && p.expert_reviews.description.trim()) {
                descParts.push(p.expert_reviews.description.trim());
            }
        }
    }

    // ۳. فال‌بک content در صورت خالی بودن
    if (descParts.length === 0 && p.content) {
        const cDesc = typeof p.content === 'string' ? p.content : (p.content?.description || '');
        if (cDesc.trim()) descParts.push(cDesc.trim());
    }

    const prodDesc = descParts.join("\n\n");

    const brandSourcePath = extractDigikalaBrandSourcePath(p.brand);
    const cleanResult = {
        success: true,
        version: DIGIKALA_WORKER_VERSION,
        product: {
            id: p.id,
            title_fa: p.title_fa || '',
            title_en: p.title_en || '',
            url: `https://www.digikala.com/product/dkp-${p.id}/`,
            is_available: isAvailable,
            availability_source: availabilitySource,
            status_text: isAvailable ? 'موجود' : 'ناموجود',
            price_toman: Math.floor(sellingPriceRials / 10),
            regular_price_toman: Math.floor(rrpPriceRials / 10),
            discount_percent: effectiveVariant?.price?.discount_percent || 0,
            seller: sellerTitle,
            seller_code: sellerCode,
            seller_rating: sellerRating,
            warranty: warranty,
            lead_time: leadTime,
            image: mainImg,
            gallery: gallery.slice(0, 10),
            description: prodDesc,
            specs: specs,
            spec_groups: specGroups,
            breadcrumbs: breadcrumbs,
            category: finalCategory,
            category_id: p.category?.id || null,
            rating: rating,
            satisfaction: satisfaction,
            rating_count: rating_count,
            brand: p.brand?.title_fa || 'دیجی‌کالا',
            brand_en: p.brand?.title_en || '',
            ...(brandSourcePath ? { brand_source_path: brandSourcePath } : {}),
            ...(Number.isSafeInteger(Number(p.brand?.id)) && Number(p.brand.id) > 0 ? { brand_source_id: Number(p.brand.id) } : {}),
            ...(typeof p.brand?.code === 'string' && p.brand.code.trim() !== '' ? { brand_source_code: p.brand.code.trim().slice(0, 120) } : {})
        }
    };

    const cacheHeader = isFresh
        ? 'no-cache, no-store, must-revalidate'
        : 'public, max-age=120'; // 2 minutes; price/availability freshness

    const resultResponse = new Response(JSON.stringify(cleanResult), {
        headers: {
            ...corsHeaders,
            'Cache-Control': cacheHeader,
            'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION,
            'X-Evazar-Product-Cache': isFresh ? 'BYPASS' : 'MISS',
            'X-Evazar-Fresh': isFresh ? '1' : '0'
        }
    });

    if (!isFresh) {
        try {
            const cacheCopy = resultResponse.clone();
            if (ctx && typeof ctx.waitUntil === 'function') {
                ctx.waitUntil(productCache.put(productCacheKey, cacheCopy));
            } else {
                await productCache.put(productCacheKey, cacheCopy);
            }
        } catch (_) {}
    }

    return resultResponse;
}

async function fetchSearchResults(query, page, corsHeaders) {
    const encoded = encodeURIComponent(query);
    const targetApiUrl = `https://api.digikala.com/v1/search/?q=${encoded}&page=${page}`;

    const digiHeaders = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Referer': 'https://www.digikala.com/'
    };

    const response = await fetchDigiWithCookie(targetApiUrl, digiHeaders);
    if (!response.ok) {
        return new Response(JSON.stringify({ success: false, message: 'خطا در دریافت نتایج جستجو.' }), { status: 500, headers: { ...corsHeaders, 'Cache-Control': 'no-cache, no-store, must-revalidate' } });
    }

    const data = await response.json();
    const products = (data?.data?.products || []).slice(0, 20).map(p => {
        const sellingPrice = p.default_variant?.price?.selling_price || 0;
        const rrpPrice = p.default_variant?.price?.rrp_price || sellingPrice;
        return {
            id: p.id,
            title: p.title_fa,
            price: Math.floor(sellingPrice / 10),
            rrp_price: Math.floor(rrpPrice / 10),
            image: p.images?.main?.url?.[0] || '',
            rating: (p.rating?.count > 0 && p.rating?.rate) ? Number(p.rating.rate) : 0,
            url: `https://www.digikala.com/product/dkp-${p.id}/`
        };
    });

    return new Response(JSON.stringify({
        success: true,
        version: DIGIKALA_WORKER_VERSION,
        count: products.length,
        products: products
    }), { headers: { ...corsHeaders, 'Cache-Control': 'public, max-age=60' } });
}


/**
 * AI Reverse Proxy — Multi-Key Secure Mode
 * کلید Gemini فقط از Secret با نام GEMINI_API_KEY خوانده می‌شود؛ چرخش کلید در Worker انجام نمی‌شود.
 */
/* Duplicate AI proxy implementation removed in 1.9.4; single secured handler follows. */

async function handleAiProxy(request, urlObj, corsHeaders, env) {
    const pathname = urlObj.pathname;
    const isGemini = pathname.includes('gemini') || urlObj.searchParams.get('provider') === 'gemini';
    const isOpenAI = pathname.includes('openai') || urlObj.searchParams.get('provider') === 'openai';

    // Idempotency status lookup. Requires Durable Object binding and internal token.
    if (request.method === 'GET' && urlObj.searchParams.get('action') === 'idempotency_status') {
        const requestId = (urlObj.searchParams.get('request_id') || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 64);
        if (!requestId) return new Response(JSON.stringify({ success: false, status: 'invalid_request_id' }), { status: 400, headers: { ...corsHeaders, 'Cache-Control': 'no-store' } });
        if (!env || !env.EVAZAR_GEMINI_IDEMPOTENCY) return new Response(JSON.stringify({ success: false, status: 'idempotency_unavailable' }), { status: 503, headers: { ...corsHeaders, 'Cache-Control': 'no-store' } });
        const id = env.EVAZAR_GEMINI_IDEMPOTENCY.idFromName(requestId);
        const stub = env.EVAZAR_GEMINI_IDEMPOTENCY.get(id);
        return await stub.fetch('https://evazar-idempotency.internal/status?request_id=' + encodeURIComponent(requestId), { method: 'GET' });
    }

    // GET: بازگرداندن اطلاعات ورکر (بدون نمایش کلید)
    if (request.method === 'GET') {
        return new Response(JSON.stringify({
            worker: 'evazar-ai-proxy',
            version: DIGIKALA_WORKER_VERSION,
            has_gemini_key: !!(env && env.GEMINI_API_KEY),
            has_openai_key: !!(env && env.OPENAI_API_KEY),
            mode: 'secure-env-secret'
        }), {
            status: 200,
            headers: { ...corsHeaders, 'Content-Type': 'application/json; charset=utf-8' }
        });
    }

    if (request.method !== 'POST') {
        return new Response(JSON.stringify({ error: 'POST method required for AI proxy' }), { status: 405, headers: corsHeaders });
    }

    // Defense in depth: the Worker independently enforces Core's product-AI request policy
    // before any upstream Gemini call. One product is allowed only for the explicit manual test
    // or a signed/authenticated Core batch retry marked as previously deferred and now due.
    // Legacy automatic single-product fallback purposes are always rejected.
    const requestPurpose = (request.headers.get('X-EVazar-Request-Purpose') || '').trim().toLowerCase();
    const requestIdForPolicy = (request.headers.get('X-Evazar-Request-ID') || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 64);
    const declaredBatchSizeRaw = (request.headers.get('X-EVazar-Batch-Size') || '').trim();
    const declaredBatchCountRaw = (request.headers.get('X-EVazar-Batch-Count') || '').trim();
    // Strict decimal parsing rejects ambiguous values such as "2junk" rather than parseInt()-coercing them.
    const declaredBatchSize = /^\d+$/.test(declaredBatchSizeRaw) ? Number(declaredBatchSizeRaw) : NaN;
    const declaredBatchCount = /^\d+$/.test(declaredBatchCountRaw) ? Number(declaredBatchCountRaw) : NaN;
    const manualSingleTest = request.headers.get('X-EVazar-Manual-Single-Test') === '1';
    if (isGemini) {
        const policyError = (message, code = 'EVZ_GEMINI_REQUEST_POLICY_REJECTED') => new Response(JSON.stringify({
            success: false, error: code, message, version: DIGIKALA_WORKER_VERSION
        }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION } });
        if (!requestPurpose) return policyError('X-EVazar-Request-Purpose is required; no upstream request was sent.', 'EVZ_GEMINI_PURPOSE_REQUIRED');
        if (['product_import_batch_single', 'product_import_batch_item_fallback'].includes(requestPurpose)
            || /^(?:gm-single-|gm-fallback-)/i.test(requestIdForPolicy)) {
            return policyError('Automatic single-product fallback requests are disabled.', 'EVZ_AUTOMATIC_SINGLE_PRODUCT_BLOCKED');
        }
        if (requestPurpose === 'product_import' && !manualSingleTest) {
            return policyError('Single-product Gemini requests are allowed only from the explicit manual importer test.', 'EVZ_AUTOMATIC_SINGLE_PRODUCT_BLOCKED');
        }
        if (manualSingleTest && requestPurpose !== 'product_import') {
            return policyError('Manual single-product marker is valid only for product_import.', 'EVZ_GEMINI_REQUEST_POLICY_REJECTED');
        }
        if (manualSingleTest && (declaredBatchSize !== 1 || declaredBatchCount !== 1)) {
            return policyError('The manual single-product exception must declare exactly one product.', 'EVZ_GEMINI_MANUAL_SINGLE_DECLARATION_INVALID');
        }
        if (requestPurpose === 'product_import_batch') {
            const singletonRetryMarker = request.headers.get('X-EVazar-Allow-Singleton-Retry') === '1';
            const singletonRetryValid = singletonRetryMarker
                && declaredBatchSize === 1
                && declaredBatchCount === 1
                && /^gm-batch-/i.test(requestIdForPolicy);
            const minimumBatchSize = singletonRetryValid ? 1 : 2;
            if (!Number.isInteger(declaredBatchSize) || declaredBatchSize < minimumBatchSize || declaredBatchSize > 50
                || !Number.isInteger(declaredBatchCount) || declaredBatchCount !== declaredBatchSize
                || (declaredBatchSize === 1 && !singletonRetryValid)) {
                return policyError('Automatic product batches must declare 2–50 unique products; only an explicitly marked, deferred singleton retry may declare one product.', 'EVZ_GEMINI_BATCH_SIZE_INVALID');
            }
        } else if (requestPurpose === 'taxonomy_seo_batch') {
            const taxonomyType = (request.headers.get('X-Evazar-Taxonomy-Type') || '').trim().toLowerCase();
            if (!Number.isInteger(declaredBatchSize) || declaredBatchSize < 2 || declaredBatchSize > 5
                || !Number.isInteger(declaredBatchCount) || declaredBatchCount !== declaredBatchSize
                || !['category', 'brand'].includes(taxonomyType)) {
                return policyError('Taxonomy SEO batches must declare 2–5 items of exactly one taxonomy type.', 'EVZ_TAXONOMY_BATCH_SIZE_INVALID');
            }
        } else if (requestPurpose === 'taxonomy_seo_single') {
            const taxonomyType = (request.headers.get('X-Evazar-Taxonomy-Type') || '').trim().toLowerCase();
            if (declaredBatchSize !== 1 || declaredBatchCount !== 1
                || !['category', 'brand'].includes(taxonomyType)
                || !/^gm-taxsingle-/i.test(requestIdForPolicy)) {
                return policyError('Taxonomy SEO singleton must declare exactly one item, one taxonomy type, and a stable taxonomy request ID.', 'EVZ_TAXONOMY_SINGLE_SIZE_INVALID');
            }
        } else if (!['product_import', 'taxonomy_seo'].includes(requestPurpose)) {
            return policyError('Unsupported Gemini request purpose; no upstream request was sent.', 'EVZ_GEMINI_PURPOSE_UNSUPPORTED');
        }
    }

    let targetUrl = '';
    let authHeaders = { 'Content-Type': 'application/json' };

    if (isGemini || (!isOpenAI)) {
        // ========================================================
        // GEMINI: کلید از Environment Secret — نه از URL یا body
        // ========================================================
        const geminiKey = (env && env.GEMINI_API_KEY) ? env.GEMINI_API_KEY.trim() : '';
        if (!geminiKey) {
            return new Response(JSON.stringify({
                error: 'GEMINI_API_KEY not configured in Worker environment secrets.'
            }), { status: 503, headers: corsHeaders });
        }

        // Gemini model is intentionally fixed for this deployment; path values cannot select other models.
        const modelAndMethod = 'gemini-3.5-flash-lite';

        // کلید فقط روی سرور اضافه می‌شود — هرگز از client نمی‌آید
        targetUrl = `https://generativelanguage.googleapis.com/v1beta/models/${modelAndMethod}:generateContent?key=${geminiKey}`;

    } else {
        // ========================================================
        // OPENAI: کلید از Environment Secret
        // ========================================================
        const openaiKey = (env && env.OPENAI_API_KEY) ? env.OPENAI_API_KEY.trim() : '';
        if (!openaiKey) {
            return new Response(JSON.stringify({
                error: 'OPENAI_API_KEY not configured in Worker environment secrets.'
            }), { status: 503, headers: corsHeaders });
        }
        targetUrl = 'https://api.openai.com/v1/chat/completions';
        authHeaders['Authorization'] = `Bearer ${openaiKey}`;
    }

    try {
        // Receive and preserve the native API request body, except client-supplied credential fields
        // and all Gemini tool configuration, which is deliberately disabled in this release.
        let bodyText = await request.text();

        try {
            const bodyObj = JSON.parse(bodyText);
            // Remove any client-supplied credentials. The actual Gemini key is a Worker Secret.
            delete bodyObj._key;
            delete bodyObj._api_key;
            delete bodyObj.key;

            if (isGemini || !isOpenAI) {
                // Web grounding / external tool use is intentionally disabled in Worker 1.12.6.
                // Drop both fields even if an old Core or a manual client includes them.
                delete bodyObj.tools;
                delete bodyObj.toolConfig;
            }
            bodyText = JSON.stringify(bodyObj);
        } catch (_) {
            if (isGemini) {
                return new Response(JSON.stringify({ error: 'Invalid JSON body for Gemini request.' }), {
                    status: 400,
                    headers: { ...corsHeaders, 'Cache-Control': 'no-store', 'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION }
                });
            }
        }

        // Use Durable Object as an atomic per-request idempotency gate when configured.
        // The request ID is supplied by EVazar Core and must remain stable on retry.
        const requestId = (request.headers.get('X-Evazar-Request-ID') || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 64);
        if (isGemini && env && env.EVAZAR_GEMINI_IDEMPOTENCY) {
            if (!requestId) return new Response(JSON.stringify({ error: 'X-Evazar-Request-ID is required for idempotent Gemini requests.' }), { status: 400, headers: { ...corsHeaders, 'Cache-Control': 'no-store' } });
            const id = env.EVAZAR_GEMINI_IDEMPOTENCY.idFromName(requestId);
            const stub = env.EVAZAR_GEMINI_IDEMPOTENCY.get(id);
            return await stub.fetch('https://evazar-idempotency.internal/execute', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-Evazar-Request-ID': requestId },
                body: JSON.stringify({ url: targetUrl, headers: authHeaders, body: bodyText })
            });
        }

        const upstreamRes = await fetch(targetUrl, {
            method: 'POST',
            headers: authHeaders,
            body: bodyText
        });

        const upstreamBody = await upstreamRes.text();
        const proxyHeaders = {
            ...corsHeaders,
            'Content-Type': 'application/json; charset=utf-8',
            'Cache-Control': 'no-store',
            'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION
        };
        // Forward only the standard retry hint; do not expose upstream credentials/headers.
        const retryAfter = upstreamRes.headers.get('Retry-After');
        if (retryAfter) proxyHeaders['Retry-After'] = retryAfter;
        if (isGemini && upstreamRes.status >= 500 && upstreamRes.status < 600) {
            // This marker is added only after fetch() received a real upstream HTTP response.
            // Core may safely cool this Worker and requeue the product without treating the
            // response as a lost/unknown transport outcome.
            proxyHeaders['X-Evazar-Gemini-Outcome'] = 'retryable';
        }
        return new Response(upstreamBody, {
            status: upstreamRes.status,
            headers: proxyHeaders
        });
    } catch (e) {
        return new Response(JSON.stringify({ error: 'Worker AI Proxy Failed: ' + e.message }), { status: 502, headers: corsHeaders });
    }
}


/**
 * Durable, atomic idempotency store for Gemini calls.
 * Configure binding EVAZAR_GEMINI_IDEMPOTENCY and migrate this class before enabling.
 * A stale in-progress request is never replayed with the same ID automatically; Core's queue may retry with a new generation after its safety window.
 */
export class GeminiIdempotencyDO {
    constructor(state, env) { this.state = state; this.env = env; }

    async fetch(request) {
        const url = new URL(request.url);
        const requestId = (request.headers.get('X-Evazar-Request-ID') || url.searchParams.get('request_id') || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 64);
        if (!requestId) return this.json({ success: false, status: 'invalid_request_id' }, 400);

        if (request.method === 'GET' && url.pathname === '/status') {
            const record = await this.state.storage.get('record');
            if (!record) return this.json({ success: true, status: 'not_found', request_id: requestId }, 200);
            if (record.status === 'completed') return this.json({ success: true, status: 'completed', request_id: requestId, http_status: record.http_status, body: record.body, headers: record.headers || {} }, 200);
            if (record.status === 'retryable') return this.json({ success: true, status: 'retryable', request_id: requestId, http_status: record.http_status, body: record.body, headers: record.headers || {}, retry_at: record.retry_at || 0 }, 200);
            if (record.status === 'uncertain') return this.json({ success: true, status: 'uncertain', request_id: requestId, age_ms: Date.now() - Number(record.started_at || 0), error_code: record.error_code || 'upstream_fetch_failed' }, 200);
            const age = Date.now() - Number(record.started_at || 0);
            return this.json({ success: true, status: age > 600000 ? 'uncertain' : 'processing', request_id: requestId, age_ms: age }, 200);
        }
        if (request.method !== 'POST' || url.pathname !== '/execute') return this.json({ success: false, error: 'Method/path not allowed.' }, 405);

        let payload;
        try { payload = await request.json(); } catch (_) { return this.json({ success: false, error: 'Invalid idempotency payload.' }, 400); }
        if (!payload || typeof payload.url !== 'string' || !payload.url.startsWith('https://generativelanguage.googleapis.com/')) return this.json({ success: false, error: 'Invalid Gemini upstream URL.' }, 400);

        const reservation = await this.state.storage.transaction(async txn => {
            const current = await txn.get('record');
            if (current && current.status === 'retryable') {
                if (Date.now() < Number(current.retry_at || 0)) return { kind: 'retry_wait', record: current };
                const next = { status: 'processing', request_id: requestId, started_at: Date.now(), attempts: Number(current.attempts || 1) + 1 };
                await txn.put('record', next);
                return { kind: 'reserved', record: next };
            }
            if (current) return { kind: current.status, record: current };
            const next = { status: 'processing', request_id: requestId, started_at: Date.now(), attempts: 1 };
            await txn.put('record', next);
            return { kind: 'reserved', record: next };
        });
        if (reservation.kind === 'completed') {
            return new Response(reservation.record.body || '', { status: reservation.record.http_status || 200, headers: { ...(reservation.record.headers || {}), 'X-Evazar-Idempotency-Replay': '1', 'Cache-Control': 'no-store' } });
        }
        if (reservation.kind === 'retry_wait') {
            const waitSeconds = Math.max(1, Math.ceil((Number(reservation.record.retry_at || Date.now() + 1000) - Date.now()) / 1000));
            return new Response(reservation.record.body || '', { status: reservation.record.http_status || 429, headers: { ...(reservation.record.headers || {}), 'Retry-After': String(waitSeconds), 'X-Evazar-Idempotency-Replay': '1', 'Cache-Control': 'no-store' } });
        }
        if (reservation.kind !== 'reserved') {
            const age = Date.now() - Number(reservation.record.started_at || 0);
            return this.json({ success: false, status: age > 600000 ? 'uncertain' : 'processing', request_id: requestId, age_ms: age }, 202);
        }

        try {
            const upstream = await fetch(payload.url, { method: 'POST', headers: payload.headers || { 'Content-Type': 'application/json' }, body: String(payload.body || '') });
            const body = await upstream.text();
            const retryAfter = upstream.headers.get('Retry-After') || '';
            const headers = { 'Content-Type': upstream.headers.get('Content-Type') || 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Evazar-Worker-Version': DIGIKALA_WORKER_VERSION };
            if (retryAfter) headers['Retry-After'] = retryAfter;
            // A 429 is a definitive rejection, not a generated result. Keep its response for
            // Core recovery, then permit a fresh upstream attempt only after the provider delay.
            if (upstream.status === 429) {
                let delaySeconds = 0;
                if (/^\d+$/.test(retryAfter)) delaySeconds = Number(retryAfter);
                else if (retryAfter) { const date = Date.parse(retryAfter); if (Number.isFinite(date)) delaySeconds = Math.max(0, Math.ceil((date - Date.now()) / 1000)); }
                if (delaySeconds <= 0) {
                    try {
                        const parsed = JSON.parse(body);
                        const details = parsed && parsed.error && Array.isArray(parsed.error.details) ? parsed.error.details : [];
                        for (const detail of details) { const m = String(detail && detail.retryDelay || '').match(/^(\d+(?:\.\d+)?)s$/); if (m) { delaySeconds = Math.ceil(Number(m[1])); break; } }
                    } catch (_) {}
                }
                delaySeconds = Math.max(60, delaySeconds || 60);
                headers['Retry-After'] = String(delaySeconds);
                const record = { status: 'retryable', request_id: requestId, started_at: reservation.record.started_at, completed_at: Date.now(), http_status: 429, body, headers, retry_at: Date.now() + delaySeconds * 1000, attempts: Number(reservation.record.attempts || 1) };
                await this.state.storage.put('record', record);
                return new Response(body, { status: 429, headers });
            }
            // A received upstream 5xx is a definitive transient rejection, unlike a thrown fetch
            // error. Persist it as retryable so the same request ID can be safely retried after
            // Retry-After; the Core also uses the marker to avoid leaving queue items locked.
            if (upstream.status >= 500 && upstream.status < 600) {
                let delaySeconds = 0;
                if (/^\d+$/.test(retryAfter)) delaySeconds = Number(retryAfter);
                else if (retryAfter) {
                    const date = Date.parse(retryAfter);
                    if (Number.isFinite(date)) delaySeconds = Math.max(0, Math.ceil((date - Date.now()) / 1000));
                }
                if (delaySeconds <= 0) {
                    try {
                        const parsed = JSON.parse(body);
                        const details = parsed && parsed.error && Array.isArray(parsed.error.details) ? parsed.error.details : [];
                        for (const detail of details) {
                            const match = String(detail && detail.retryDelay || '').match(/^(\d+(?:\.\d+)?)s$/);
                            if (match) { delaySeconds = Math.ceil(Number(match[1])); break; }
                        }
                    } catch (_) {}
                }
                delaySeconds = Math.max(30, delaySeconds || 30);
                headers['Retry-After'] = String(delaySeconds);
                headers['X-Evazar-Gemini-Outcome'] = 'retryable';
                const record = {
                    status: 'retryable', request_id: requestId, started_at: reservation.record.started_at,
                    completed_at: Date.now(), http_status: upstream.status, body, headers,
                    retry_at: Date.now() + delaySeconds * 1000,
                    attempts: Number(reservation.record.attempts || 1)
                };
                await this.state.storage.put('record', record);
                return new Response(body, { status: upstream.status, headers });
            }
            const record = { status: 'completed', request_id: requestId, started_at: reservation.record.started_at, completed_at: Date.now(), http_status: upstream.status, body, headers, attempts: Number(reservation.record.attempts || 1) };
            await this.state.storage.put('record', record);
            return new Response(body, { status: upstream.status, headers });
        } catch (error) {
            const detail = String(error && error.message || error).slice(0, 180);
            const lower = detail.toLowerCase();
            const errorCode = /timeout|timed out|abort|deadline/.test(lower) ? 'upstream_timeout'
                : /dns|resolve|enotfound/.test(lower) ? 'upstream_dns'
                : /connect|econnrefused|econnreset|network/.test(lower) ? 'upstream_connection'
                : /tls|ssl|certificate/.test(lower) ? 'upstream_tls'
                : 'upstream_fetch_failed';
            await this.state.storage.put({ status: 'uncertain', request_id: requestId, started_at: reservation.record.started_at, error_code: errorCode, error: detail });
            return this.json({ success: false, status: 'uncertain', request_id: requestId, error_code: errorCode, error: 'Gemini upstream outcome is uncertain; retry is blocked.' }, 502);
        }
    }

    json(value, status = 200) {
        return new Response(JSON.stringify(value), { status, headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' } });
    }
}
