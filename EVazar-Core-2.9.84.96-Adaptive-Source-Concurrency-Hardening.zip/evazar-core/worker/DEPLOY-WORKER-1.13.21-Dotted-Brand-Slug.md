# Deploy Worker 1.13.21 — Dotted Brand Slug Support

1. Publish `digikala-worker.js` to the existing EVazar Worker service.
2. Preserve the existing route, `EVAZAR_INTERNAL_TOKEN`, Secrets, and Bindings.
3. Verify the response version header is `X-Evazar-Worker-Version: 1.13.21`.
4. Test source-page resolution for `/brand/j.one/`; the final route may be `/brand-landing/j.one/`, but the brand slug must remain `j.one`.
5. Test that `/brand/j.one/` redirecting to a different brand slug is rejected.

Do not create a new Worker service just to deploy this update.
