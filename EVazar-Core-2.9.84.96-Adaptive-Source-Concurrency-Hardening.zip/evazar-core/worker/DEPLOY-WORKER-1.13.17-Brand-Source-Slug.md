# Deploy Cloudflare Worker 1.13.17 — Brand Source Slug

This release is rebased directly on EVazar Worker 1.13.13.3. It retains the pre-existing batch constraints unchanged: automatic Gemini product batches allow up to 15 products; taxonomy SEO batches allow up to 5 items. No batch-limit reduction/increase is included.

Deploy the included `digikala-worker.js` as the Cloudflare Worker source. The product response passes through these fields only when explicitly present in Digikala's product payload:
- `brand_source_path` from `product.brand.url` / explicit URL path
- `brand_source_id` from `product.brand.id`
- `brand_source_code` from `product.brand.code`

The supplied API fixture confirms `id: 18`, `code: "samsung"`, and `url.uri: "/brand/samsung/"`.

Deploy together with EVazar Core 2.9.84.15 for source-ID-aware brand slug reconciliation. No cache configuration or cache purge action is required.
