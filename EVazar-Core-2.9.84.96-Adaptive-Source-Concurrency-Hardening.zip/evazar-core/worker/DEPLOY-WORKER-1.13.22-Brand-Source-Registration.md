# Deploy Cloudflare Worker 1.13.22 — Brand Source Registration

1. Replace `digikala-worker.js` in **every primary Digikala Worker configured in EVazar Core** with this release. The Core request uses the configured primary Worker pool; leaving any pool member on an older release can make registration fail when that member receives the request.
2. Keep the Worker environment secret `EVAZAR_INTERNAL_TOKEN` configured. It must match the token saved in Core's `evazar_cf_worker_token` setting.
3. Deploy/publish the Worker, then install Core 2.9.84.33.
4. In WordPress, open **Tools → ثبت برند از لینک دیجی‌کالا**. Enter a brand page URL, inspect the returned identity, then confirm registration.

The new `POST /brand-source/inspect` endpoint requires the internal token. It accepts only a validated Digikala brand path and queries the fixed `/v1/brands/{slug}/search/` API route. The Core does not perform direct-origin fallback for this tool.

No product assignment, existing taxonomy mutation, redirect write, or cache operation is part of this endpoint.
