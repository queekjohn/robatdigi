# Historical Worker release — 1.13.18

This document records the original Worker 1.13.18 rollout for Gemini product batch size 30. This is historical documentation for the original 1.13.18 rollout. For Core 2.9.84.31, use `DEPLOY-WORKER-1.13.20-Brand-Unicode-Redirects.md` and deploy Worker 1.13.20. It retains the 30-product batch ceiling and authenticated brand-audit endpoint while adding Persian/Unicode source URL handling and safe `/brand/` → `/brand-landing/` route verification.
