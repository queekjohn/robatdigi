# Historical deployment note: Cloudflare Worker 1.13.19 — authenticated brand audit

1. Publish this exact `digikala-worker.js` to every Worker URL in EVazar Core's primary Worker list (`evazar_cf_worker_urls`) and the legacy URL (`evazar_cf_worker_url`) if used. The audit tool uses the primary pool.
2. Keep the current `EVAZAR_INTERNAL_TOKEN`, Gemini API key, other secrets, and bindings unchanged. Do not place tokens in source.
3. Confirm each Worker reports `X-Evazar-Worker-Version: 1.13.19`.
4. The new route is `POST /brand-audit/product` with header `X-Evazar-Internal-Token` and body `{"dkp_id":"123456"}`. It is read-only, allowlisted to Digikala's product API, returns only minimal product/brand identity, and uses no-store headers.
5. The route does not use or modify the product cache. Other existing product/Gemini routes keep their existing behavior; default fetch timeout remains 12 seconds for existing routes.
