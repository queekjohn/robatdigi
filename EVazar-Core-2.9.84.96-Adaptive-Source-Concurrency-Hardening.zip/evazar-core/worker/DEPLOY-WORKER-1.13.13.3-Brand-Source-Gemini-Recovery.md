# Worker 1.13.13.3 — Brand Source + Gemini Recovery Diagnostics

This patch release retains the 1.13.13.2 brand-source behavior and adds error classification for uncertain Gemini Durable Object outcomes from the 1.13.15 branch.

- Keeps explicit validated `brand_source_path`; no title-derived slug guessing.
- Adds `error_code` for uncertain outcomes: timeout, DNS, connection, TLS, or generic upstream failure.
- Preserves 1.13.13.2 cache behavior, product batch limits, and taxonomy batch limits; no unrelated Worker branch was merged.
- Verify `EVAZAR_GEMINI_IDEMPOTENCY` Durable Object binding and class migration in Cloudflare.
