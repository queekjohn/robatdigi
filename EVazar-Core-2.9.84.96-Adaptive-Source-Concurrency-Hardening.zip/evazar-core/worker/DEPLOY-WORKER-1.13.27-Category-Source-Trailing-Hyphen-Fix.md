# Deploy Cloudflare Worker 1.13.27 — Source Path Trailing-Hyphen Fix

1. Open the existing primary EVazar Digikala Worker in Cloudflare and replace its script with the companion `EVazar-Cloudflare-Worker-1.13.27-Category-Source-Trailing-Hyphen-Fix.js` file.
2. Keep all existing Worker routes/custom domains, secrets (including `EVAZAR_INTERNAL_TOKEN`), API keys, bindings, and environment settings unchanged.
3. Deploy and verify the product response reports `version: "1.13.27"` / header `X-Evazar-Worker-Version: 1.13.27`.
4. Test the exact source-page request by adding `source_page=%2Fsearch%2Fcategory-men-sport-shoes-%2F` to the active Worker URL. A valid request must not return HTTP 400 `Invalid source page path`; an upstream fetch failure, if any, should instead show the upstream status diagnostics.
5. Deploy Core 2.9.84.84 separately after Worker 1.13.27 is active.

The runtime change is limited to source-page path validation: one final hyphen is allowed in an explicit route segment. The route allowlist and traversal/encoded-separator checks remain in place. No cache, product import, Gemini or price/stock behavior is changed by this Worker patch.
