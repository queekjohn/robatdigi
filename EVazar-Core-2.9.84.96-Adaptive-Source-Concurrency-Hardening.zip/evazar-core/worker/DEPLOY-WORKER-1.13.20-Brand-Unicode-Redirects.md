# Deploy Cloudflare Worker 1.13.20 — Unicode brand URL and redirect handling

1. Publish this Worker source to every primary Worker URL configured in `evazar_cf_worker_urls`, and the legacy primary URL if it is active.
2. Preserve the existing `EVAZAR_INTERNAL_TOKEN`, API keys, Secrets, and bindings; do not put secrets in the source file.
3. Confirm each primary Worker returns `X-Evazar-Worker-Version: 1.13.20`.
4. Then install EVazar Core 2.9.84.31. Core's embedded Worker and this standalone file are byte-identical.

## Brand identity rules
- Explicit source paths in ASCII or Persian/Unicode are accepted after safe URL decoding. No slug is inferred from the display name alone.
- `/brand/{slug}/` and `/brand-landing/{slug}/` represent the same source identity when their slug matches; both normalize to `/brand/{slug}/`.
- The source-page proxy follows HTTPS redirects only through the existing Digikala host allowlist, reports the final path, and refuses a brand redirect to a different/unrecognized slug.
- Brand metadata audit continues to use the explicit source API product object for brand ID, code, Persian name, and URL. If a sample is incomplete, the Core repair tool tries other attached products (up to ten) and remains fail-closed if identity cannot be established.

## Scope
- No change to product/Gemini batch ceilings, image proxy cache policy, product price/stock cache behavior, or import queue capacity.
