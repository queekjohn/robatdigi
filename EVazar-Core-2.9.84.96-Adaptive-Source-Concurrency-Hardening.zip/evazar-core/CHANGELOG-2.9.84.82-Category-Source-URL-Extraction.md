# EVazar Core 2.9.84.82 — Category Source URL Extraction

- Bundled Digikala Worker version 1.13.26.
- Extract category URLs from supported explicit API/JSON-LD URL fields and breadcrumb wrappers.
- Direct category fallback now preserves a URL only if Digikala supplied one. No URL is fabricated from a category title or slug.
- The Core pre-Gemini source-path validation remains enabled; missing source identity remains quarantined before Gemini or product writes.
- No cache, Gemini model/prompt, queue scheduling, price/stock, or product-save behavior changed.
