# EVazar Core 2.9.84.65 — Import Log Window Expanded to 200

- Increased the lightweight import log ring buffer from 50 to 200 entries.
- Updated the importer log view to render up to 200 recent entries.
- Updated the link label, empty-state copy, and displayed retention count.
- Kept queue backfill deliberately limited to the 50 most recent logs; only the visible/import-log retention window expands.
- No changes to Worker, Gemini batching, queue behavior, or cache behavior.
