# EVazar Core 2.9.84.49 — Bounded parallel product-source fetch

- Adds a maximum of three concurrent Digikala source lookups per wave, routed only through the configured Cloudflare primary Workers while a Gemini batch is being prepared.
- Uses small rolling waves rather than prefetching the entire claimed queue, so source restrictions halt later waves promptly.
- Keeps each response and diagnostic keyed to the exact DKP and consumes it once; repeated DKPs in a wave are deduplicated.
- Preserves the existing serial Worker failover route for Worker/runtime failures, legacy ambiguous 404s, non-source 429s, transport exceptions, or hosts without cURL-multi support.
- Source-scoped upstream failures and product-specific 404 responses remain item-scoped and are passed to the existing queue source-failure policy without unnecessary extra requests.
- Validates that the Worker product payload is a JSON object before parsing and reports successful source diagnostics accurately.
- Retains atomic queue claims, per-DKP import locks, queue retry logic, Gemini batch dispatch, and start-based scheduling.
- No Cloudflare Worker code, database schema, product content rules, or cache behavior changed.

Local regression coverage includes wave-size limits, distinct Worker URL selection, authentication headers, TLS and timeout options, reversed result completion order, DKP-to-response mapping, duplicate DKP deduplication, source 502 diagnostics, product 404 isolation, malformed payload validation, Worker-level failover, and multi-transport fallback. All existing local PHP/JS tests and syntax checks pass. Live hosting/Cloudflare/Digikala validation remains required.
