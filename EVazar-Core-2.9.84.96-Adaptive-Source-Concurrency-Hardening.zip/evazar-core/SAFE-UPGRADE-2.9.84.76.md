# Safe upgrade — EVazar Core 2.9.84.76

1. Back up the current `evazar-core/` plugin folder and the WordPress database.
2. Replace the existing `evazar-core/` plugin folder with the folder in this ZIP; keep the folder name unchanged.
3. No database schema migration is required. Adaptive batch state is stored in a non-autoloaded WordPress option; stale locks are reclaimed using a conditional compare-and-delete.
4. Do not redeploy Cloudflare Workers for this release; Worker source is byte-identical to Core 2.9.84.73.
5. The administrator's configured Gemini batch size remains the maximum. A confirmed Gemini upstream 5xx decreases the effective batch for unsent work in the same queue run; already-dispatched chunks are not resubmitted. Capacity recovers gradually after successful requests.
6. Check the operations log for `تنظیم تطبیقی ظرفیت Gemini` to inspect reductions, recovery, and unsent-tail repartitioning.
7. Local syntax, regression, and package-integrity tests are included. Live Gemini, production queue execution, PHP 8.3, and actual cross-process WordPress contention have not been tested here.
