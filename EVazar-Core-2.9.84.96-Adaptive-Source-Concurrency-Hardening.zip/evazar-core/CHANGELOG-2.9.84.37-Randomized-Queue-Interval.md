# EVazar Core 2.9.84.37 — Randomized Import Queue Scheduling

## Changes
- Replaced the single fixed queue interval with configurable minimum and maximum intervals; defaults are 5 and 10 minutes.
- Each next automatic run is selected uniformly/inclusively from the configured range when the prior run finishes, rather than at run start.
- Kept the recurring WP-Cron event as a safety-net tick; actual execution is gated by the randomized `evazar_queue_next_auto_run_at` timestamp.
- Added an atomic WordPress-option lock across PHP requests to prevent concurrent queue waves; stale locks are reclaimed conditionally after 15 minutes.
- Retry continuations now respect the same randomized interval in addition to each item's `next_attempt_at` and Gemini/Worker cooldown gates.
- Added the chosen delay, last finish timestamp, and upcoming run timestamp to queue settings/status display.
- Migrated cron schedule version to 3 so existing fixed-interval events are rebuilt on the next admin initialization.
- Existing one-click pause, resume, and manual-run actions remain available. Resume remains an explicit near-immediate action (5-second wake-up); subsequent completed runs return to randomized scheduling.

## Scope protection
- No edits to `cache-purge.php`, `product-index.php`, the Cloudflare Worker, brand-source registration, product-import/source parsing, stock/price sync, or Gemini API request logic.
