# Safe upgrade — EVazar Core 2.9.84.78

Install this Core version with Theme 1.13.29 to use the indexed live-search path. This release adds no database schema change beyond the search index already introduced in Core 2.9.84.77. If a canonical Core index sync fails, live autocomplete deliberately falls back to the legacy WP_Query path until scheduled backfill repairs the index and verifies completeness. No Worker or cache-purge code changed.
