# EVazar Core 2.9.84.32 — Dotted Digikala Brand Slugs

- Adds support for explicit Digikala brand source slugs containing dots, such as `/brand/j.one/`.
- Normalizes `/brand/j.one/` and `/brand-landing/j.one/` to the same source identity while preserving source slug `j.one`.
- The public WordPress slug remains WordPress-safe (`j-one`) when that is the existing term slug; metadata repair does not rename terms.
- Metadata-repair compares the public slug to the sanitized public representation of the source slug, while preserving the original dotted slug in source metadata.
- Retains rejection of path traversal, encoded slash/backslash, foreign hosts, query, fragment and invalid dot-only segments.
- No cache-purge, product-index, queue, or product-cache behavior changed.

Worker companion: 1.13.21.
