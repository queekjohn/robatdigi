# QA — EVazar Core 2.9.84.45

## Scope
Move the Gemini products-per-request UI to the import queue scheduling/speed section. Preserve the existing saved option and processing implementation.

## Automated checks
- PHP syntax checks pass for the changed PHP files.
- Regression test confirms the field is no longer registered on the general AI settings page and is rendered in the queue scheduling section.
- Regression test confirms options 40 and 50 remain present and that form submission uses the existing sanitizer and option key.
- Existing PHP and JavaScript regression suites are run against this package.

## Operational note
This is a UI placement and settings-save change only. It does not change Cloudflare Worker code or publish anything to a live site.
