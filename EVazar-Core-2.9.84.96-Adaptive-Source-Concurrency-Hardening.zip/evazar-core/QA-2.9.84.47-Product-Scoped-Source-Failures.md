# QA — EVazar Core 2.9.84.47

## Behavior verified
- One upstream 502/server error maps to `defer_item`, not `defer_run`.
- One source timeout/network failure maps to `defer_item`.
- Invalid/missing per-product source payload maps to `defer_item`.
- Source-side 429 remains `defer_run` with bounded Retry-After handling.
- Explicit upstream 401/403 access rejection remains `defer_run`; ambiguous 4xx request rejection is item-scoped.
- A single product failure only updates the current row, clears its claim, sets a not-before timestamp, and does not increment retries.
- Three consecutive transient source errors open the circuit breaker; only the not-yet-visited tail is deferred. Already collected Gemini checkpoints remain processable.
- Product-specific 404 and Gemini rate-limit paths remain distinct.

## Test execution
- `tests/queue-random-interval-regression.php` — passed.
- `tests/product-source-failure-regression.js` — expected to pass unchanged; Worker package is unchanged.
- All PHP files must pass `php -l`.
- All JS test files must pass under Node.js.

Live WordPress / Cloudflare / Digikala requests were not made during local tests.
