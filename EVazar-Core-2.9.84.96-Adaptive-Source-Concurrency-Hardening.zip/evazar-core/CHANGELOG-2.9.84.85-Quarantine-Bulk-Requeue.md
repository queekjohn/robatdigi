# EVazar Core 2.9.84.85 — Bulk Requeue from Review Quarantine

- Adds a button on the **قرنطینهٔ بررسی** filter to return every currently quarantined queue row to `pending` in one status-scoped database update. This is all rows, not only the 50 displayed rows.
- Uses the existing authenticated admin AJAX action, nonce, and `manage_options` capability check.
- Resets retries, queue error code, claim fields, and retry scheduling exactly as the per-row retry operation does. Existing queue IDs, DKPs, related product posts, and diagnostic error text are retained; no product post is deleted or written by the bulk action.
- A second click is a safe no-op once no quarantined rows remain. A paused queue leaves the returned rows pending until the queue is resumed.
- Uses one SQL UPDATE rather than looping through thousands of records in PHP. It only touches rows whose current status is `quarantined`.
- Includes Worker 1.13.27 unchanged from Core 2.9.84.84.
- No changes to cache code, Gemini prompts/API handling, queue processing pipeline, or import logic.
