<?php
/** Focused runtime harness for the existing-product taxonomy identity sync action. */
if (!defined('ABSPATH')) define('ABSPATH', __DIR__ . '/');
if (!class_exists('WP_Error')) {
    class WP_Error {
        private $code; private $message; private $data;
        public function __construct($code = '', $message = '', $data = null) { $this->code=$code; $this->message=$message; $this->data=$data; }
        public function get_error_code() { return $this->code; }
        public function get_error_message() { return $this->message; }
        public function get_error_data() { return $this->data; }
    }
}
function is_wp_error($v) { return $v instanceof WP_Error; }
function add_action(...$args) {}
function add_filter(...$args) {}
function register_activation_hook(...$args) {}
function register_deactivation_hook(...$args) {}
function plugin_dir_path($file) { return dirname($file) . '/'; }
if (!function_exists('mb_substr')) { function mb_substr($s,$start,$length=null,$encoding=null) { return $length===null ? substr((string)$s,$start) : substr((string)$s,$start,$length); } }
function absint($v) { return abs((int)$v); }
function sanitize_text_field($v) { return trim(strip_tags((string)$v)); }
function wp_json_encode($v, $flags=0) { return json_encode($v, $flags); }
function evazar_normalize_digikala_source_path($v) {
    $v=trim((string)$v);
    if (preg_match('#^https?://(?:www\.)?digikala\.com(/(?:search|main)/[^?\#]*)#i',$v,$m)) $v=$m[1];
    if (!preg_match('#^/(?:search|main)/[A-Za-z0-9\-_/]+/?$#',$v)) return '';
    return '/' . trim(preg_replace('#/+#','/',$v), '/') . '/';
}
function evazar_normalize_digikala_brand_source_path($v) {
    $v=trim((string)$v);
    if (preg_match('#^https?://(?:www\.)?digikala\.com(/brand/[^?\#]*)#i',$v,$m)) $v=$m[1];
    if (!preg_match('#^/brand/[A-Za-z0-9\-_/]+/?$#',$v)) return '';
    return '/' . trim(preg_replace('#/+#','/',$v), '/') . '/';
}
$GLOBALS['qids_posts']=[]; $GLOBALS['qids_post_meta']=[]; $GLOBALS['qids_term_meta']=[]; $GLOBALS['qids_term_ids']=[]; $GLOBALS['qids_terms']=[];
$GLOBALS['qids_category_result']=null; $GLOBALS['qids_brand_result']=true; $GLOBALS['qids_fetch_result']=false; $GLOBALS['qids_fetch_count']=0; $GLOBALS['qids_brand_calls']=[]; $GLOBALS['qids_logs']=[];
function get_posts($args=[]) { return $GLOBALS['qids_posts']; }
function get_post_meta($post_id,$key='',$single=true) { return $GLOBALS['qids_post_meta'][(int)$post_id][$key] ?? ''; }
function update_post_meta($post_id,$key,$value) { $GLOBALS['qids_post_meta'][(int)$post_id][$key]=$value; return true; }
function delete_post_meta($post_id,$key) { unset($GLOBALS['qids_post_meta'][(int)$post_id][$key]); return true; }
function wp_get_object_terms($post_id,$taxonomy,$args=[]) { return $GLOBALS['qids_term_ids'][(int)$post_id][$taxonomy] ?? []; }
function get_term_meta($term_id,$key='',$single=true) { return $GLOBALS['qids_term_meta'][(int)$term_id][$key] ?? ''; }
function get_term($term_id,$taxonomy='') { return $GLOBALS['qids_terms'][(int)$term_id] ?? false; }
function get_the_title($id=0) { return 'test product'; }
function get_bloginfo($show='') { return 'EVazar'; }
function get_post_field($field,$post_id=0) { return ''; }
function get_post_thumbnail_id($post_id=0) { return 0; }
function wp_update_post($postarr=[]) { return $postarr['ID'] ?? 0; }
function evazar_import_log($level,$message,$dkp='',$context=[]) { $GLOBALS['qids_logs'][]=[$level,$message,$dkp,$context]; }
function evazar_fetch_raw_product_data($dkp,$force_fresh=false,$allow_direct_fallback=false,$purpose='default') { $GLOBALS['qids_fetch_count']++; return $GLOBALS['qids_fetch_result']; }
function evazar_sync_product_categories($post_id,$breadcrumbs,$category_name='',$brand_name='',$brand_en='') { return $GLOBALS['qids_category_result']; }
function evazar_sync_product_brand($post_id,$brand_fa,$brand_en='',$source_path='',$source_id=0,$source_code='') { $GLOBALS['qids_brand_calls'][]=[$post_id,$brand_fa,$brand_en,$source_path,$source_id,$source_code]; return $GLOBALS['qids_brand_result']; }
function csm_sync_check($name,$ok) { echo ($ok?'PASS':'FAIL') . ' - ' . $name . "\n"; if(!$ok)$GLOBALS['qids_fail']++; else $GLOBALS['qids_pass']++; }
$GLOBALS['qids_pass']=0; $GLOBALS['qids_fail']=0;
class QidsWpdb { public $prefix='wp_'; }
$GLOBALS['wpdb']=new QidsWpdb();
require_once __DIR__ . '/../queue-manager.php';

function qids_reset($post_id=101) {
    $GLOBALS['qids_posts']=[(object)['ID'=>$post_id,'post_status'=>'publish']];
    $GLOBALS['qids_post_meta']=[$post_id=>[]];
    $GLOBALS['qids_term_meta']=[]; $GLOBALS['qids_term_ids']=[$post_id=>['evazar_category'=>[],'evazar_brand'=>[]]]; $GLOBALS['qids_terms']=[];
    $GLOBALS['qids_category_result']=null; $GLOBALS['qids_brand_result']=true; $GLOBALS['qids_fetch_result']=false; $GLOBALS['qids_fetch_count']=0; $GLOBALS['qids_brand_calls']=[]; $GLOBALS['qids_logs']=[];
}
function qids_set_verified_category($id=10) {
    $GLOBALS['qids_term_meta'][$id]=['_evazar_dk_source_verified'=>'1','_evazar_dk_source_kind'=>'digikala_breadcrumb','_evazar_dk_url'=>'/search/category-test/','_evazar_dk_source_map_version'=>'2.9.84.29'];
    $GLOBALS['qids_terms'][$id]=(object)['term_id'=>$id,'name'=>'دسته آزمایش','slug'=>'category-test','parent'=>0];
}
function qids_set_verified_brand($id=20) {
    $GLOBALS['qids_term_meta'][$id]=['_evazar_dk_source_verified'=>'1','_evazar_dk_url'=>'/brand/test-brand/','_evazar_dk_brand_id'=>'812','_evazar_dk_brand_code'=>'test-brand','_evazar_dk_slug'=>'test-brand','_evazar_dk_source_map_version'=>'2.9.84.29','_evazar_brand_en'=>'Test Brand'];
    $GLOBALS['qids_terms'][$id]=(object)['term_id'=>$id,'name'=>'برند آزمایش','slug'=>'test-brand','parent'=>0];
}

// Newly repaired/registered brands must be recognized by the existing-product identity check.
qids_reset(106); qids_set_verified_brand(22);
$GLOBALS['qids_term_meta'][22]['_evazar_dk_source_map_version']='2.9.84.33-live-brand-registration';
csm_sync_check('new registration provenance is accepted by queue identity validator', evazar_queue_term_source_identity_complete(22, 'evazar_brand'));
$GLOBALS['qids_term_meta'][22]['_evazar_dk_source_map_version']='2.9.84.32-live-metadata-repair';
csm_sync_check('2.9.84.32 metadata-repair provenance is accepted by queue identity validator', evazar_queue_term_source_identity_complete(22, 'evazar_brand'));

// Missing taxonomy source must never be reported as a successful sync when source fetch is impossible.
qids_reset(101); $GLOBALS['qids_term_ids'][101]['evazar_category']=[10]; $GLOBALS['qids_post_meta'][101]['_evazar_sku']='';
$result=evazar_queue_run_admin_action('sync_existing_items');
csm_sync_check('missing breadcrumbs + no source identifier counts as category failure',!$result['success'] && $result['failed_categories']===1);
csm_sync_check('missing category identity is reported to admin',strpos($result['message'],'دسته‌های ناموفق 1')!==false);

// Category WP_Error must be reported as failure even while verified brand sync succeeds.
qids_reset(102); qids_set_verified_category(10); qids_set_verified_brand(20);
$GLOBALS['qids_term_ids'][102]=['evazar_category'=>[10],'evazar_brand'=>[20]];
$GLOBALS['qids_post_meta'][102]['_evazar_breadcrumbs']=[['title'=>'دسته آزمایش','url'=>'/search/category-test/']];
$GLOBALS['qids_post_meta'][102]['_evazar_brand']='برند آزمایش';
$GLOBALS['qids_category_result']=new WP_Error('category_test_error','category rejected');
$GLOBALS['qids_brand_result']=true;
$result=evazar_queue_run_admin_action('sync_existing_items');
csm_sync_check('WP_Error from category sync is not treated as success',!$result['success'] && $result['failed_categories']===1);
csm_sync_check('verified brand can still sync when category sync fails', $result['synced_brands']===1 && $result['failed_brands']===0);

// A null return is invalid here: the real category sync contract returns a positive term count.
qids_reset(105); qids_set_verified_category(10); qids_set_verified_brand(20);
$GLOBALS['qids_term_ids'][105]=['evazar_category'=>[10],'evazar_brand'=>[20]];
$GLOBALS['qids_post_meta'][105]['_evazar_breadcrumbs']=[['title'=>'دسته آزمایش','url'=>'/search/category-test/']];
$GLOBALS['qids_post_meta'][105]['_evazar_brand']='برند آزمایش';
$GLOBALS['qids_category_result']=null; $GLOBALS['qids_brand_result']=true;
$result=evazar_queue_run_admin_action('sync_existing_items');
csm_sync_check('null category sync result is not reported as success',!$result['success'] && $result['failed_categories']===1);

// Incomplete brand metadata must require explicit live identity, not a title-only assignment.
qids_reset(103); $GLOBALS['qids_term_ids'][103]['evazar_brand']=[30];
$GLOBALS['qids_terms'][30]=(object)['term_id'=>30,'name'=>'ال جی','slug'=>'lg','parent'=>0];
$GLOBALS['qids_post_meta'][103]['_evazar_brand']='ال جی';
$GLOBALS['qids_post_meta'][103]['_evazar_sku']='1044001';
$GLOBALS['qids_fetch_result']=['brand'=>'ال جی','brand_en'=>'LG','brand_source_path'=>'','brand_source_id'=>0,'brand_source_code'=>'','breadcrumbs'=>[]];
$result=evazar_queue_run_admin_action('sync_existing_items');
csm_sync_check('incomplete brand source identity fails closed and does not call name-only sync',!$result['success'] && $result['failed_brands']===1 && count($GLOBALS['qids_brand_calls'])===0);

// Explicit source identity is passed through, but a failed assignment must be counted.
qids_reset(104); $GLOBALS['qids_term_ids'][104]['evazar_brand']=[30];
$GLOBALS['qids_terms'][30]=(object)['term_id'=>30,'name'=>'ال جی','slug'=>'lg','parent'=>0];
$GLOBALS['qids_post_meta'][104]['_evazar_brand']='ال جی'; $GLOBALS['qids_post_meta'][104]['_evazar_sku']='1044002';
$GLOBALS['qids_fetch_result']=['brand'=>'ال جی','brand_en'=>'LG','brand_source_path'=>'/brand/lg-pc/','brand_source_id'=>997,'brand_source_code'=>'lg-pc','breadcrumbs'=>[['title'=>'دسته آزمایش','url'=>'/search/category-test/']]];
$GLOBALS['qids_category_result']=1; $GLOBALS['qids_brand_result']=new WP_Error('brand_test_error','brand rejected');
$result=evazar_queue_run_admin_action('sync_existing_items');
csm_sync_check('explicit-source brand assignment WP_Error is counted as failure',!$result['success'] && $result['failed_brands']===1);
csm_sync_check('queue passes exact Digikala identity to the brand sync function',isset($GLOBALS['qids_brand_calls'][0]) && $GLOBALS['qids_brand_calls'][0][3]==='/brand/lg-pc/' && $GLOBALS['qids_brand_calls'][0][4]===997 && $GLOBALS['qids_brand_calls'][0][5]==='lg-pc');
csm_sync_check('brand assignment failure does not overwrite stored display name',($GLOBALS['qids_post_meta'][104]['_evazar_brand']??'')==='ال جی');
$qids_queue_source = file_get_contents(__DIR__ . '/../queue-manager.php');
csm_sync_check('successful queue repair does not overwrite term-canonical brand metadata with raw source labels', strpos($qids_queue_source, "update_post_meta(\$post_id, '_evazar_brand', \$brand_fa)") === false && strpos($qids_queue_source, "update_post_meta(\$post_id, '_evazar_brand_en', \$brand_en)") === false);

echo "\nRESULT: {$GLOBALS['qids_pass']} passed, {$GLOBALS['qids_fail']} failed\n";
exit($GLOBALS['qids_fail']?1:0);
