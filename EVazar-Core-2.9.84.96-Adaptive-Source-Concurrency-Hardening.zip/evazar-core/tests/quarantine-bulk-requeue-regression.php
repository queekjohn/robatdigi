<?php
/** Regression tests for bulk return of all review-quarantined products to the import queue. */
error_reporting(E_ALL);
ini_set('display_errors', '1');
if (!defined('ABSPATH')) define('ABSPATH', __DIR__ . '/../');
if (!defined('MINUTE_IN_SECONDS')) define('MINUTE_IN_SECONDS', 60);
if (!defined('HOUR_IN_SECONDS')) define('HOUR_IN_SECONDS', 3600);
if (!defined('DAY_IN_SECONDS')) define('DAY_IN_SECONDS', 86400);

$GLOBALS['qbr_options'] = [];
$GLOBALS['qbr_transients_deleted'] = [];
function add_action(...$args) {}
function add_filter(...$args) {}
function register_activation_hook(...$args) {}
function register_deactivation_hook(...$args) {}
function sanitize_key($value) { return preg_replace('/[^a-z0-9_\-]/', '', strtolower((string)$value)); }
function absint($value) { return abs((int)$value); }
function current_time($type = 'mysql', $gmt = false) { return '2026-10-29 16:00:00'; }
function delete_transient($name) { $GLOBALS['qbr_transients_deleted'][] = $name; return true; }
function get_option($name, $default = false) { return array_key_exists($name, $GLOBALS['qbr_options']) ? $GLOBALS['qbr_options'][$name] : $default; }
function update_option($name, $value, $autoload = null) { $GLOBALS['qbr_options'][$name] = $value; return true; }
function get_current_user_id() { return 7; }
function number_format_i18n($number, $decimals = 0) { return number_format((float)$number, $decimals, '.', ','); }

class QBR_FakeWpdb {
    public $prefix = 'wp_';
    public $postmeta = 'wp_postmeta';
    public $rows = [];
    public $fail_query = false;
    public $fail_insert = false;
    public $has_unique_dkp_index = true;
    public $has_unique_intake_dkp_index = true;
    public $queue_index_shape = 'single_dkp';
    public $intake_index_shape = 'single_dkp';
    public $last_error = '';
    public $intake_rows = [];
    public $next_intake_id = 1;
    public $last_query = '';
    public $last_args = [];
    public function prepare($query, ...$args) { $this->last_query = $query; $this->last_args = $args; return $query; }
    public function esc_like($value) { return (string)$value; }
    public function get_row($query) {
        $this->last_query = $query;
        if (stripos($query, 'SHOW INDEX') !== false) {
            if (stripos($query, 'wp_evazar_import_queue') !== false && $this->has_unique_dkp_index) return (object)['Non_unique' => 0];
            if (stripos($query, 'wp_evazar_import_intake') !== false && $this->has_unique_intake_dkp_index) return (object)['Non_unique' => 0];
        }
        return null;
    }
    public function get_var($query) {
        $this->last_query = $query; $this->last_error = '';
        if (strpos($query, 'SHOW TABLES LIKE') !== false) return 'wp_evazar_import_intake';
        if (strpos($query, 'SHOW COLUMNS') !== false) return 'mode';
        if (strpos($query, 'GET_LOCK') !== false) return '1';
        if (strpos($query, 'RELEASE_LOCK') !== false) return '1';
        if (strpos($query, "SELECT COUNT(*) FROM `wp_evazar_import_queue` WHERE status IN ('pending','processing')") !== false) {
            return count(array_filter($this->rows, static fn($r) => in_array(($r['status'] ?? ''), ['pending','processing'], true)));
        }
        if (preg_match('/SELECT status FROM `wp_evazar_import_queue` WHERE id = (\d+)/', $query, $m)) {
            return (string) ($this->rows[(int)$m[1]]['status'] ?? '');
        }
        if (strpos($query, "SELECT COUNT(*) FROM `wp_evazar_import_queue` WHERE status='quarantined' AND dkp REGEXP") !== false) {
            return count(array_filter($this->rows, static fn($r) => ($r['status'] ?? '') === 'quarantined' && preg_match('/^[1-9][0-9]*$/', (string)($r['dkp'] ?? ''))));
        }
        if (strpos($query, "SELECT COUNT(*) FROM `wp_evazar_import_queue` WHERE status='quarantined'") !== false) {
            return count(array_filter($this->rows, static fn($r) => ($r['status'] ?? '') === 'quarantined'));
        }
        if (strpos($query, "INNER JOIN `wp_evazar_import_intake`") !== false && strpos($query, "i.mode IN ('qretry','qrewrite')") !== false) {
            $count = 0;
            foreach ($this->intake_rows as $dkp => $intake) foreach ($this->rows as $row) {
                if (($row['dkp'] ?? '') === $dkp && ($row['status'] ?? '') === 'quarantined' && in_array($intake['mode'] ?? '', ['qretry','qrewrite'], true)) $count++;
            }
            return $count;
        }
        if (strpos($query, 'COUNT(*) FROM `wp_evazar_import_intake`') !== false) return count($this->intake_rows);
        return 0;
    }
    public function get_results($query) {
        $this->last_query = $query;
        if (stripos($query, 'SHOW INDEX') !== false) {
            if (stripos($query, 'wp_evazar_import_queue') !== false && $this->has_unique_dkp_index) {
                if ($this->queue_index_shape === 'single_dkp') return [(object)['Non_unique'=>0,'Column_name'=>'dkp','Seq_in_index'=>1,'Sub_part'=>null]];
                if ($this->queue_index_shape === 'composite') return [(object)['Non_unique'=>0,'Column_name'=>'dkp','Seq_in_index'=>1,'Sub_part'=>null], (object)['Non_unique'=>0,'Column_name'=>'other_col','Seq_in_index'=>2,'Sub_part'=>null]];
                if ($this->queue_index_shape === 'wrong_column') return [(object)['Non_unique'=>0,'Column_name'=>'other_col','Seq_in_index'=>1,'Sub_part'=>null]];
            }
            if (stripos($query, 'wp_evazar_import_intake') !== false && $this->has_unique_intake_dkp_index) {
                if ($this->intake_index_shape === 'single_dkp') return [(object)['Non_unique'=>0,'Column_name'=>'dkp','Seq_in_index'=>1,'Sub_part'=>null]];
                if ($this->intake_index_shape === 'composite') return [(object)['Non_unique'=>0,'Column_name'=>'dkp','Seq_in_index'=>1,'Sub_part'=>null], (object)['Non_unique'=>0,'Column_name'=>'other_col','Seq_in_index'=>2,'Sub_part'=>null]];
                if ($this->intake_index_shape === 'wrong_column') return [(object)['Non_unique'=>0,'Column_name'=>'other_col','Seq_in_index'=>1,'Sub_part'=>null]];
            }
            return [];
        }
        if (strpos($query, 'SELECT id, dkp, url, mode FROM `wp_evazar_import_intake`') !== false) {
            $rows = array_values($this->intake_rows);
            usort($rows, static fn($a,$b) => ($a['id'] ?? 0) <=> ($b['id'] ?? 0));
            preg_match('/LIMIT (\d+)/', $query, $m);
            $rows = array_slice($rows, 0, isset($m[1]) ? (int)$m[1] : count($rows));
            return array_map(static fn($r) => (object)$r, $rows);
        }
        if (strpos($query, 'SELECT id, dkp, url, status, related_product_id, error_log FROM `wp_evazar_import_queue` WHERE dkp IN') !== false) {
            $wanted = array_map('strval', $this->last_args);
            $out = [];
            foreach ($this->rows as $row) if (in_array((string)($row['dkp'] ?? ''), $wanted, true)) $out[] = (object)$row;
            return $out;
        }
        return [];
    }
    public function get_col($query) { return []; }
    public function update($table, $data, $where, $format = null, $where_format = null) {
        if ($table !== 'wp_evazar_import_queue') return false;
        $id = (int)($where['id'] ?? 0);
        if (!isset($this->rows[$id])) return 0;
        foreach ($where as $key=>$value) if ((string)($this->rows[$id][$key] ?? '') !== (string)$value) return 0;
        foreach ($data as $key=>$value) $this->rows[$id][$key]=$value;
        return 1;
    }
    public function delete($table, $where, $where_format = null) {
        if ($table !== 'wp_evazar_import_intake') return false;
        $id = (int)($where['id'] ?? 0);
        foreach ($this->intake_rows as $dkp=>$row) {
            if ((int)($row['id'] ?? 0) === $id) { unset($this->intake_rows[$dkp]); return 1; }
        }
        return 0;
    }
    public function query($query) {
        $this->last_query = $query; $this->last_error = '';
        if ($this->fail_query || ($this->fail_insert && stripos($query, 'INSERT INTO `wp_evazar_import_intake`') !== false)) { $this->last_error = 'simulated database error'; return false; }
        if (in_array($query, ['START TRANSACTION','COMMIT','ROLLBACK'], true)) return 1;
        if (stripos($query, 'INSERT INTO `wp_evazar_import_intake`') !== false && stripos($query, "SELECT dkp, url, 'qretry'") !== false) {
            foreach ($this->rows as $row) {
                if (($row['status'] ?? '') !== 'quarantined' || !preg_match('/^[1-9][0-9]*$/', (string)($row['dkp'] ?? ''))) continue;
                $dkp=(string)$row['dkp'];
                if (!isset($this->intake_rows[$dkp])) $this->intake_rows[$dkp]=['id'=>$this->next_intake_id++,'dkp'=>$dkp,'url'=>'https://www.digikala.com/product/dkp-'.$dkp.'/','mode'=>'qretry'];
                else $this->intake_rows[$dkp]['mode'] = in_array($this->intake_rows[$dkp]['mode'] ?? '', ['rewrite','qrewrite'], true) ? 'qrewrite' : 'qretry';
            }
            return count($this->intake_rows);
        }
        return 0;
    }
}
function check_qbr($name, $passed) {
    if (!$passed) { fwrite(STDERR, "FAIL: {$name}\n"); exit(1); }
    echo "PASS: {$name}\n";
}
require_once __DIR__ . '/../queue-manager.php';

$source = file_get_contents(__DIR__ . '/../queue-manager.php');
$core = file_get_contents(__DIR__ . '/../evazar-core.php');
check_qbr('Core plugin version bumped to 2.9.84.96', strpos($core, '* Version: 2.9.84.96') !== false);
check_qbr('new bulk action is routed in the central admin action dispatcher', strpos($source, "case 'retry_all_quarantined_items':") !== false);
check_qbr('bulk stage is restricted to rows currently quarantined and numeric DKPs', strpos($source, "WHERE status='quarantined' AND dkp REGEXP '^[1-9][0-9]*$'") !== false);
check_qbr('bulk button is only presented on the quarantine filter and explicitly says all rows, not only visible 50', strpos($source, "if (\$current_filter === 'quarantined')") !== false && strpos($source, 'نه فقط ۵۰ ردیف قابل‌نمایش') !== false);
check_qbr('AJAX endpoint keeps nonce verification and administrator capability checks', strpos($source, "check_ajax_referer('evazar_queue_action_nonce', 'security')") !== false && strpos($source, "if (!current_user_can('manage_options'))") !== false);
$bulk_start = strpos($source, "case 'retry_all_quarantined_items':");
$bulk_end = strpos($source, "case 'draft_quarantined_product':", $bulk_start ?: 0);
$bulk_code = ($bulk_start !== false && $bulk_end !== false) ? substr($source, $bulk_start, $bulk_end - $bulk_start) : '';
check_qbr('bulk action stages overflow in the durable intake queue instead of bypassing active capacity', $bulk_code !== '' && strpos($bulk_code, 'INSERT INTO `$intake_table` (dkp, url, mode)') !== false && strpos($bulk_code, "mode IN ('qretry','qrewrite')") !== false && strpos($bulk_code, "evazar_queue_capacity_lock_acquire(3)") !== false);
check_qbr('bulk action requires verified single-column unique DKP indexes on both queue tables', strpos($bulk_code, '!evazar_queue_table_has_verified_dkp_unique_index($table_name)') !== false && strpos($bulk_code, '!evazar_queue_table_has_verified_dkp_unique_index($intake_table)') !== false);
check_qbr('capacity promotion only releases staged quarantine rows for explicit qretry/qrewrite modes', strpos($source, "\$existing_status === 'quarantined' && in_array(\$mode, ['qretry', 'qrewrite'], true)") !== false);

$wpdb = new QBR_FakeWpdb();
$wpdb->rows = [
    1 => ['id'=>1, 'dkp'=>'22055693', 'related_product_id'=>0, 'status'=>'quarantined', 'retries'=>4, 'error_code'=>'SOURCE_CATEGORY_PATH_MISSING', 'error_log'=>'diagnostic A', 'last_error_at'=>null, 'claim_token'=>'old-1', 'claimed_at'=>'2026-10-29 15:00:00', 'next_attempt_at'=>'2026-10-30 00:00:00'],
    2 => ['id'=>2, 'dkp'=>'17815976', 'related_product_id'=>8765, 'status'=>'quarantined', 'retries'=>2, 'error_code'=>'SOURCE_CATEGORY_PATH_MISSING', 'error_log'=>'diagnostic B', 'last_error_at'=>null, 'claim_token'=>'old-2', 'claimed_at'=>'2026-10-29 15:00:00', 'next_attempt_at'=>null],
    3 => ['id'=>3, 'dkp'=>'22271601', 'related_product_id'=>0, 'status'=>'quarantined', 'retries'=>1, 'error_code'=>'OTHER_REVIEW_REASON', 'error_log'=>'diagnostic C', 'last_error_at'=>null, 'claim_token'=>'old-3', 'claimed_at'=>'2026-10-29 15:00:00', 'next_attempt_at'=>null],
    4 => ['id'=>4, 'dkp'=>'15551286', 'related_product_id'=>0, 'status'=>'pending', 'retries'=>2, 'error_code'=>'KEEP_PENDING', 'error_log'=>'pending untouched', 'last_error_at'=>null, 'claim_token'=>'', 'claimed_at'=>null, 'next_attempt_at'=>null],
    5 => ['id'=>5, 'dkp'=>'11111111', 'related_product_id'=>0, 'status'=>'processing', 'retries'=>1, 'error_code'=>'KEEP_PROCESSING', 'error_log'=>'processing untouched', 'last_error_at'=>null, 'claim_token'=>'active', 'claimed_at'=>'2026-10-29 15:30:00', 'next_attempt_at'=>null],
    6 => ['id'=>6, 'dkp'=>'22222222', 'related_product_id'=>0, 'status'=>'excluded', 'retries'=>3, 'error_code'=>'EXCLUDED_BY_ADMIN', 'error_log'=>'excluded untouched', 'last_error_at'=>null, 'claim_token'=>'', 'claimed_at'=>null, 'next_attempt_at'=>null],
];
$GLOBALS['wpdb'] = $wpdb;
$result = evazar_queue_run_admin_action('retry_all_quarantined_items');
check_qbr('bulk action succeeds and reports numeric quarantined rows for retry', !empty($result['success']) && strpos($result['message'], '3 ردیف قرنطینه') !== false);
check_qbr('all eligible quarantines enter the capacity-intake queue without activating beyond capacity', isset($wpdb->intake_rows['22055693'], $wpdb->intake_rows['17815976'], $wpdb->intake_rows['22271601']) && $wpdb->rows[1]['status']==='quarantined' && $wpdb->rows[2]['status']==='quarantined' && $wpdb->rows[3]['status']==='quarantined');
check_qbr('existing queue IDs, DKPs, related product IDs and original diagnosis text are preserved', $wpdb->rows[2]['id']===2 && $wpdb->rows[2]['dkp']==='17815976' && $wpdb->rows[2]['related_product_id']===8765 && strpos($wpdb->rows[2]['error_log'], 'diagnostic B')===0);
check_qbr('pending, processing, and excluded rows are not modified', $wpdb->rows[4]['status']==='pending' && $wpdb->rows[4]['error_code']==='KEEP_PENDING' && $wpdb->rows[5]['status']==='processing' && $wpdb->rows[5]['claim_token']==='active' && $wpdb->rows[6]['status']==='excluded');
check_qbr('queue dashboard statistics transient is invalidated after action', in_array('evazar_queue_dashboard_stats_v2', $GLOBALS['qbr_transients_deleted'], true));

$result_none = evazar_queue_run_admin_action('retry_all_quarantined_items');
check_qbr('repeating the action is idempotent and does not create duplicate intake DKPs', !empty($result_none['success']) && count($wpdb->intake_rows)===3 && isset($wpdb->intake_rows['22055693']));

$wpdb->rows[7] = ['id'=>7, 'dkp'=>'33333333', 'related_product_id'=>0, 'status'=>'quarantined', 'retries'=>1, 'error_code'=>'SOURCE_CATEGORY_PATH_MISSING', 'error_log'=>'diagnostic D', 'last_error_at'=>null, 'claim_token'=>'x', 'claimed_at'=>'2026-10-29 15:00:00', 'next_attempt_at'=>null];
$wpdb->has_unique_dkp_index = false;
$result_no_index = evazar_queue_run_admin_action('retry_all_quarantined_items');
check_qbr('missing unique DKP index blocks bulk requeue without changing queue or intake rows', empty($result_no_index['success']) && $wpdb->rows[7]['status']==='quarantined' && !isset($wpdb->intake_rows['33333333']));
$wpdb->has_unique_dkp_index = true;
$wpdb->has_unique_intake_dkp_index = false;
$result_no_intake_index = evazar_queue_run_admin_action('retry_all_quarantined_items');
check_qbr('missing intake unique DKP index also blocks staging safely', empty($result_no_intake_index['success']) && $wpdb->rows[7]['status']==='quarantined' && !isset($wpdb->intake_rows['33333333']));
$wpdb->has_unique_intake_dkp_index = true;
$wpdb->queue_index_shape = 'composite';
$result_composite_queue_index = evazar_queue_run_admin_action('retry_all_quarantined_items');
check_qbr('composite unique index named dkp_unique is not mistaken for unique DKP', empty($result_composite_queue_index['success']) && !isset($wpdb->intake_rows['33333333']));
$wpdb->queue_index_shape = 'single_dkp';
$wpdb->intake_index_shape = 'wrong_column';
$result_wrong_intake_index = evazar_queue_run_admin_action('retry_all_quarantined_items');
check_qbr('intake index with the right name but wrong column blocks staging safely', empty($result_wrong_intake_index['success']) && !isset($wpdb->intake_rows['33333333']));
$wpdb->intake_index_shape = 'single_dkp';

$wpdb->fail_insert = true;
$result_error = evazar_queue_run_admin_action('retry_all_quarantined_items');
check_qbr('database failure during intake staging is reported as failure rather than false success', empty($result_error['success']) && $wpdb->rows[7]['status']==='quarantined' && !isset($wpdb->intake_rows['33333333']));
$wpdb->fail_insert = false;

$wpdb->rows[8] = ['id'=>8, 'dkp'=>'not-a-dkp', 'related_product_id'=>0, 'status'=>'quarantined', 'retries'=>1, 'error_code'=>'INVALID_DKP', 'error_log'=>'invalid identity', 'last_error_at'=>null, 'claim_token'=>'', 'claimed_at'=>null, 'next_attempt_at'=>null];
$wpdb->rows[9] = ['id'=>9, 'dkp'=>'022255555', 'related_product_id'=>0, 'status'=>'quarantined', 'retries'=>1, 'error_code'=>'LEGACY_DKP_FORMAT', 'error_log'=>'leading zero identity', 'last_error_at'=>null, 'claim_token'=>'', 'claimed_at'=>null, 'next_attempt_at'=>null];
$result_invalid = evazar_queue_run_admin_action('retry_all_quarantined_items');
check_qbr('non-canonical or non-numeric quarantined DKPs remain held for manual review, not staged to intake', !empty($result_invalid['success']) && $wpdb->rows[8]['status']==='quarantined' && $wpdb->rows[9]['status']==='quarantined' && !isset($wpdb->intake_rows['not-a-dkp']) && !isset($wpdb->intake_rows['022255555']) && isset($wpdb->intake_rows['33333333']));

$GLOBALS['qbr_options']['evazar_queue_max_products_per_run'] = 4;
$promotion = evazar_queue_promote_capacity_waiting();
check_qbr('capacity promotion only activates items up to the effective cap and leaves overflow staged', !empty($promotion) && $wpdb->rows[1]['status']==='pending' && $wpdb->rows[2]['status']==='pending' && $wpdb->rows[3]['status']==='quarantined' && $wpdb->rows[7]['status']==='quarantined' && isset($wpdb->intake_rows['22271601'], $wpdb->intake_rows['33333333']) && count(array_filter($wpdb->rows, static fn($r) => in_array(($r['status'] ?? ''), ['pending','processing'], true))) === 4);
check_qbr('promoted quarantine rows have reset retry claims but preserve diagnostic history', $wpdb->rows[1]['retries']===0 && $wpdb->rows[1]['claim_token']==='' && strpos($wpdb->rows[1]['error_log'], 'diagnostic A')===0 && strpos($wpdb->rows[1]['error_log'], 'بازگردانی گروهی قرنطینه')!==false);
