<?php
/** Regression tests for the bounded, item-scoped parallel Digikala source-fetch wave. */
namespace WpOrg\Requests {
    class Requests {
        const GET = 'GET';
        public static $calls = [];
        public static $throw = false;
        public static function request_multiple($requests, $options = []) {
            self::$calls[] = ['requests' => $requests, 'options' => $options];
            if (self::$throw) throw new \RuntimeException('simulated multi transport failure');
            $out = [];
            foreach ($requests as $index => $request) {
                parse_str((string) parse_url($request['url'], PHP_URL_QUERY), $query);
                $dkp = (string) ($query['dkp'] ?? '');
                $mode = $GLOBALS['psf_modes'][$dkp] ?? 'success';
                if ($mode === 'missing_response') {
                    continue;
                } elseif ($mode === 'source_502') {
                    $out[$index] = new \PsfResponse(502, [
                        'X-Evazar-Error-Scope' => 'source',
                        'X-Evazar-Worker-Version' => '1.13.25',
                        'Content-Type' => 'application/json',
                    ], json_encode([
                        'success' => false, 'error' => 'source_server_error',
                        'message' => 'upstream v2 failed', 'upstream_status_v2' => 502,
                        'upstream_status_v1' => 0, 'worker_version' => '1.13.25',
                    ]));
                } elseif ($mode === 'source_503_array_headers') {
                    // Requests::request_multiple can expose header values as arrays. This mirrors
                    // the production diagnostic shape that previously became the literal "Array".
                    $out[$index] = new \PsfResponse(503, [
                        'X-Evazar-Error-Scope' => ['source'],
                        'X-Evazar-Worker-Version' => ['1.13.27'],
                        'Content-Type' => ['application/json; charset=utf-8'],
                    ], json_encode([
                        'success' => false, 'error' => 'source_server_error',
                        'message' => 'Digikala upstream v2 returned HTTP 502.',
                        'upstream_status_v2' => 502, 'upstream_status_v1' => 0,
                        'upstream_error_v2' => '', 'upstream_error_v1' => '',
                        'worker_version' => '1.13.27',
                    ]));
                } elseif ($mode === 'source_503_scope_missing') {
                    $out[$index] = new \PsfResponse(503, [
                        'X-Evazar-Worker-Version' => ['1.13.27'],
                        'Content-Type' => ['application/json; charset=utf-8'],
                    ], json_encode([
                        'success' => false, 'error' => 'source_server_error',
                        'message' => 'Digikala upstream v2 returned HTTP 502.',
                        'upstream_status_v2' => 502, 'upstream_status_v1' => 0,
                        'worker_version' => '1.13.27',
                    ]));
                } elseif ($mode === 'source_429') {
                    $out[$index] = new \PsfResponse(429, [
                        'X-Evazar-Error-Scope' => 'source',
                        'X-Evazar-Worker-Version' => '1.13.25',
                        'Content-Type' => 'application/json',
                    ], json_encode(['success' => false, 'error' => 'source_rate_limited', 'message' => 'upstream rate limited', 'worker_version' => '1.13.25']));
                } elseif ($mode === 'product_404') {
                    $out[$index] = new \PsfResponse(404, [
                        'X-Evazar-Error-Scope' => 'product',
                        'X-Evazar-Worker-Version' => '1.13.25',
                        'Content-Type' => 'application/json',
                    ], json_encode(['success' => false, 'error' => 'product_not_found', 'message' => 'product missing']));
                } elseif ($mode === 'worker_502') {
                    $out[$index] = new \PsfResponse(502, [
                        'X-Evazar-Error-Scope' => 'worker',
                        'X-Evazar-Worker-Version' => '1.13.25',
                    ], json_encode(['success' => false, 'error' => 'worker_runtime_error']));
                } elseif ($mode === 'malformed_product') {
                    $out[$index] = new \PsfResponse(200, [
                        'Content-Type' => 'application/json',
                        'X-Evazar-Worker-Version' => '1.13.25',
                    ], json_encode(['success' => true, 'product' => 'not-an-object']));
                } else {
                    $out[$index] = new \PsfResponse(200, [
                        'Content-Type' => 'application/json',
                        'X-Evazar-Worker-Version' => '1.13.25',
                    ], json_encode(['success' => true, 'product' => ['id' => (int) $dkp, 'title_fa' => 'محصول ' . $dkp]], JSON_UNESCAPED_UNICODE));
                }
            }
            // Completion order need not match input order; callers must associate by request key.
            return array_reverse($out, true);
        }
    }
}
namespace WpOrg\Requests\Transport { class Curl {} }
namespace {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
    if (!defined('ABSPATH')) define('ABSPATH', __DIR__ . '/');
    if (!defined('DAY_IN_SECONDS')) define('DAY_IN_SECONDS', 86400);
    if (!defined('HOUR_IN_SECONDS')) define('HOUR_IN_SECONDS', 3600);
    if (!function_exists('curl_init')) { function curl_init(...$args) { return true; } }
    if (!function_exists('curl_multi_init')) { function curl_multi_init(...$args) { return true; } }

    $GLOBALS['psf_options'] = [
        'evazar_cf_worker_urls' => "https://source-a.workers.dev\nhttps://source-b.workers.dev\nhttps://source-c.workers.dev\nhttps://source-d.workers.dev\nhttps://source-e.workers.dev",
        'evazar_cf_worker_daily_budget' => 85000,
        'evazar_cf_worker_cursor' => 0,
        'evazar_ai_enabled' => 'yes',
        'evazar_ai_engine_mode' => 'gemini_only',
        'evazar_gemini_worker_urls' => "https://gemini-a.workers.dev\nhttps://gemini-b.workers.dev\nhttps://gemini-c.workers.dev\nhttps://gemini-d.workers.dev",
        'evazar_ai_product_batch_size' => 30,
    ];
    $GLOBALS['psf_counts'] = [];
    $GLOBALS['psf_cooldowns'] = [];
    $GLOBALS['psf_worker_locks'] = [];
    $GLOBALS['psf_lock_events'] = [];
    $GLOBALS['psf_logs'] = [];
    $GLOBALS['psf_modes'] = [];
    $GLOBALS['psf_checks'] = 0;

    class PsfHeaders {
        private $values;
        public function __construct($values) { $this->values = $values; }
        public function getAll() { return $this->values; }
    }
    class PsfResponse {
        public $status_code;
        public $status_message = '';
        public $headers;
        public $body;
        public function __construct($status, $headers, $body) {
            $this->status_code = $status;
            $this->headers = new PsfHeaders($headers);
            $this->body = $body;
        }
    }
    if (!class_exists('WP_Error')) {
        class WP_Error {
            private $code; private $message; private $data;
            public function __construct($code, $message = '', $data = null) { $this->code=$code; $this->message=$message; $this->data=$data; }
            public function get_error_code() { return $this->code; }
            public function get_error_message($code = '') { return $this->message; }
            public function get_error_data($code = '') { return $this->data; }
        }
    }
    function is_wp_error($value) { return $value instanceof WP_Error; }
    function add_action(...$args) {}
    function add_filter(...$args) {}
    function register_activation_hook(...$args) {}
    function register_deactivation_hook(...$args) {}
    function sanitize_key($value) { return strtolower(preg_replace('/[^a-z0-9_\-]/', '', (string) $value)); }
    function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
    function absint($value) { return abs((int) $value); }
    function get_option($key, $default = false) { return array_key_exists($key, $GLOBALS['psf_options']) ? $GLOBALS['psf_options'][$key] : $default; }
    function update_option($key, $value, $autoload = null) { $old = $GLOBALS['psf_options'][$key] ?? null; $GLOBALS['psf_options'][$key] = $value; return $old !== $value; }
    function add_option($key, $value, $deprecated = '', $autoload = 'yes') { if (array_key_exists($key, $GLOBALS['psf_options'])) return false; $GLOBALS['psf_options'][$key] = $value; return true; }
    function wp_cache_delete(...$args) { return true; }
    function wp_parse_url($url, $component = -1) { return parse_url($url, $component); }
    function trailingslashit($url) { return rtrim((string) $url, '/') . '/'; }
    function add_query_arg($args, $url) { return $url . '?' . http_build_query($args); }
    function evazar_get_primary_worker_urls() { return explode("\n", (string) get_option('evazar_cf_worker_urls', '')); }
    function evazar_get_gemini_worker_urls() { return array_values(array_filter(explode("\n", (string) get_option('evazar_gemini_worker_urls', '')))); }
    function evazar_generate_product_batch_ai_responses(...$args) { return []; }
    function evazar_primary_worker_daily_budget() { return (int) get_option('evazar_cf_worker_daily_budget', 85000); }
    function evazar_primary_worker_usage_status($url, $budget = null) { $n = (int) ($GLOBALS['psf_counts'][$url] ?? 0); return ['known'=>false, 'usage'=>$n, 'core'=>$n]; }
    function evazar_primary_worker_try_reserve($url, $budget) { if (!empty($GLOBALS['psf_reject_reservations'][$url])) return false; $n = (int) ($GLOBALS['psf_counts'][$url] ?? 0); if ($n >= $budget) return false; $GLOBALS['psf_counts'][$url] = $n + 1; return true; }
    function evazar_primary_worker_cooldown_info($url, $purpose = 'default') { return $GLOBALS['psf_cooldowns'][$url] ?? []; }
    function evazar_primary_worker_request_lock_info($url, $timeout = 25) {
        $token = $GLOBALS['psf_worker_locks'][$url] ?? '';
        return $token !== '' ? ['busy' => true, 'remaining_seconds' => 30, 'lock_value' => $token] : ['busy' => false, 'remaining_seconds' => 0, 'lock_value' => ''];
    }
    function evazar_primary_worker_acquire_request_lock($url, $timeout = 25) {
        if (!empty($GLOBALS['psf_worker_locks'][$url])) return false;
        $token = 'test-lock-' . count($GLOBALS['psf_lock_events']);
        $GLOBALS['psf_worker_locks'][$url] = $token;
        $GLOBALS['psf_lock_events'][] = ['action' => 'acquire', 'url' => $url, 'token' => $token];
        return $token;
    }
    function evazar_primary_worker_release_request_lock($url, $token) {
        if (($GLOBALS['psf_worker_locks'][$url] ?? '') !== $token) return false;
        unset($GLOBALS['psf_worker_locks'][$url]);
        $GLOBALS['psf_lock_events'][] = ['action' => 'release', 'url' => $url, 'token' => $token];
        return true;
    }
    function evazar_primary_worker_set_cooldown($url, $seconds, $reason = 'temporary_worker_error', $http_code = 0, $purpose = 'default') { $GLOBALS['psf_cooldowns'][$url] = ['until'=>time()+(int)$seconds,'reason'=>$reason,'http_code'=>$http_code]; }
    function evazar_primary_worker_host_label($url) { return strtolower((string) parse_url($url, PHP_URL_HOST)); }
    function evazar_worker_auth_headers() { return ['X-EVazar-Internal-Token' => 'test-token']; }
    function evazar_gemini_log_event(...$args) { $GLOBALS['psf_logs'][] = $args; }
    function wp_remote_retrieve_response_code($response) { return (int) ($response['response']['code'] ?? 0); }
    function wp_remote_retrieve_header($response, $header) { foreach (($response['headers'] ?? []) as $key=>$value) if (strtolower((string)$key) === strtolower((string)$header)) return $value; return ''; }
    function wp_remote_retrieve_body($response) { return (string) ($response['body'] ?? ''); }
    if (!function_exists('sanitize_textarea_field')) { function sanitize_textarea_field($value) { return trim(strip_tags((string) $value)); } }
    if (!function_exists('current_time')) { function current_time($type = 'mysql', $gmt = false) { return $type === 'timestamp' ? time() : gmdate('Y-m-d H:i:s'); } }
    if (!function_exists('delete_transient')) { function delete_transient($key) { return true; } }
    class PsfFakeDb {
        public $prefix = 'wp_'; public $prepared = []; public $queries = []; public $updates = [];
        public function prepare($query, ...$args) { $this->prepared[] = ['query' => $query, 'args' => $args]; return $query; }
        public function query($sql) { $this->queries[] = $sql; return substr_count($sql, '%d'); }
        public function update($table, $data, $where) { $this->updates[] = ['table' => $table, 'data' => $data, 'where' => $where]; return 1; }
    }

    require dirname(__DIR__) . '/queue-manager.php';

    function psf_check($name, $passed) {
        $GLOBALS['psf_checks']++;
        echo ($passed ? 'PASS' : 'FAIL') . ': ' . $name . "\n";
        if (!$passed) exit(1);
    }
    function psf_reset() {
        \WpOrg\Requests\Requests::$calls = [];
        \WpOrg\Requests\Requests::$throw = false;
        $GLOBALS['psf_counts'] = [];
        $GLOBALS['psf_cooldowns'] = [];
        $GLOBALS['psf_worker_locks'] = [];
        $GLOBALS['psf_lock_events'] = [];
        $GLOBALS['psf_modes'] = [];
        $GLOBALS['psf_reject_reservations'] = [];
        $GLOBALS['psf_options']['evazar_cf_worker_cursor'] = 0;
        unset($GLOBALS['psf_options']['evazar_source_fetch_adaptive_state']);
        $GLOBALS['evazar_queue_primary_worker_lock_tokens'] = [];
        $GLOBALS['psf_logs'] = [];
        if (function_exists('evazar_queue_source_parallel_stats_reset')) evazar_queue_source_parallel_stats_reset();
        unset($GLOBALS['evazar_queue_prefetched_product_source']);
    }

    $GLOBALS['psf_options']['evazar_cf_worker_urls'] = 'https://source-a.workers.dev';
    psf_check('one configured source Worker safely limits initial concurrency to one', evazar_queue_product_source_fetch_concurrency() === 1);
    $GLOBALS['psf_options']['evazar_cf_worker_urls'] = "https://source-a.workers.dev\nhttps://source-b.workers.dev\nhttps://source-c.workers.dev\nhttps://source-d.workers.dev\nhttps://source-e.workers.dev";
    psf_check('a controller initialized before Worker setup moves to the safe two-request start when the pool is configured', evazar_queue_product_source_fetch_concurrency() === 2);
    psf_check('source fetch concurrency starts conservatively at two despite five configured Workers', evazar_queue_product_source_fetch_concurrency() === 2);
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>91,'dkp'=>'9191']], 5);
    psf_check('a short tail wave is not counted as a successful concurrency calibration round', absint(evazar_queue_product_source_adaptive_state()['success_streak'] ?? 99) === 0);
    psf_reset();
    for ($i=0; $i<3; $i++) evazar_queue_product_source_adaptive_observe_wave(2, 0, 2, 'test_success');
    psf_check('three fully successful source waves raise adaptive concurrency from two to three', evazar_queue_product_source_fetch_concurrency() === 3);
    for ($i=0; $i<3; $i++) evazar_queue_product_source_adaptive_observe_wave(3, 0, 3, 'test_success');
    psf_check('three more successful waves raise adaptive concurrency from three to four', evazar_queue_product_source_fetch_concurrency() === 4);
    for ($i=0; $i<3; $i++) evazar_queue_product_source_adaptive_observe_wave(4, 0, 4, 'test_success');
    psf_check('three more successful waves reach the five-Worker ceiling', evazar_queue_product_source_fetch_concurrency() === 5);
    evazar_queue_product_source_adaptive_observe_wave(4, 1, 5, 'source_server_error');
    psf_check('a confirmed Digikala source 5xx immediately backs concurrency down one level', evazar_queue_product_source_fetch_concurrency() === 4 && absint(evazar_queue_product_source_adaptive_state()['success_streak'] ?? 99) === 0);
    $before_neutral = evazar_queue_product_source_fetch_concurrency();
    evazar_queue_product_source_adaptive_observe_wave(0, 0, 1, 'worker_runtime_error');
    psf_check('Worker/runtime errors are neutral and do not lower source concurrency', evazar_queue_product_source_fetch_concurrency() === $before_neutral);
    psf_reset();
    psf_reset();
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>80,'dkp'=>'8001'], (object)['id'=>81,'dkp'=>'8002'], (object)['id'=>82,'dkp'=>'8003'], (object)['id'=>83,'dkp'=>'8004'], (object)['id'=>84,'dkp'=>'8005']], 5);
    psf_check('parallel helper enforces the adaptive cap internally even when a caller requests five', count(\WpOrg\Requests\Requests::$calls) === 1 && count(\WpOrg\Requests\Requests::$calls[0]['requests']) === 2);
    psf_reset();
    update_option('evazar_source_fetch_adaptive_state', ['version'=>1,'concurrency'=>5,'success_streak'=>0,'configured_workers'=>5,'last_outcome'=>'test','last_reason'=>'test','updated_at'=>time()], false);
    $items = [(object)['id'=>1,'dkp'=>'101'], (object)['id'=>2,'dkp'=>'202'], (object)['id'=>3,'dkp'=>'303'], (object)['id'=>4,'dkp'=>'404'], (object)['id'=>5,'dkp'=>'505'], (object)['id'=>6,'dkp'=>'606'], (object)['id'=>7,'dkp'=>'707']];
    $GLOBALS['psf_modes'] = ['202'=>'source_502', '303'=>'product_404'];
    $count = evazar_queue_prefetch_product_sources_parallel($items, 5);
    psf_check('parallel product-source wave acquires a cross-request lease per Worker and releases all leases after network completion', count(array_filter($GLOBALS['psf_lock_events'], function ($event) { return ($event['action'] ?? '') === 'acquire'; })) === 5 && count(array_filter($GLOBALS['psf_lock_events'], function ($event) { return ($event['action'] ?? '') === 'release'; })) === 5 && empty($GLOBALS['psf_worker_locks']));
    psf_check('wave respects the five-request cap and leaves items six onward untouched', !isset($GLOBALS['evazar_queue_prefetched_product_source']['606']) && !isset($GLOBALS['evazar_queue_prefetched_product_source']['707']));
    psf_check('requests are spread across distinct Worker URLs when enough are available', count(array_unique(array_map(function ($r) { return parse_url($r['url'], PHP_URL_HOST); }, \WpOrg\Requests\Requests::$calls[0]['requests']))) === 5);
    psf_check('successful response is cached against its own DKP even when result completion order is reversed', ($GLOBALS['evazar_queue_prefetched_product_source']['101']['mode'] ?? '') === 'response' && (int)(json_decode($GLOBALS['evazar_queue_prefetched_product_source']['101']['response']['body'], true)['product']['id'] ?? 0) === 101);
    psf_check('valid HTTP 200 product responses receive a success diagnostic, not a false missing-payload error', ($GLOBALS['evazar_queue_prefetched_product_source']['101']['diagnostic']['code'] ?? '') === 'worker_http_success');
    psf_check('upstream 502 remains a source-scoped, item-local response with its exact status', ($GLOBALS['evazar_queue_prefetched_product_source']['202']['diagnostic']['error_scope'] ?? '') === 'source' && ($GLOBALS['evazar_queue_prefetched_product_source']['202']['diagnostic']['source_error_code'] ?? '') === 'source_server_error' && (int)($GLOBALS['evazar_queue_prefetched_product_source']['202']['diagnostic']['upstream_status_v2'] ?? 0) === 502);
    psf_check('real source-scoped upstream 502 response reduces the persisted adaptive cap from two to one', evazar_queue_product_source_fetch_concurrency() === 4);
    psf_check('product-specific 404 remains item-scoped and is not treated as a Worker outage', ($GLOBALS['evazar_queue_prefetched_product_source']['303']['diagnostic']['code'] ?? '') === 'product_not_found' && ($GLOBALS['evazar_queue_prefetched_product_source']['303']['diagnostic']['error_scope'] ?? '') === 'product' && empty($GLOBALS['psf_cooldowns']));
    psf_check('all parallel requests retain authentication headers', count(array_filter(\WpOrg\Requests\Requests::$calls[0]['requests'], function ($r) { return ($r['headers']['X-EVazar-Internal-Token'] ?? '') === 'test-token'; })) === 5);
    psf_check('per-request options preserve GET, bounded timeouts and TLS verification', count(array_filter(\WpOrg\Requests\Requests::$calls[0]['requests'], function ($r) { return ($r['type'] ?? '') === 'GET' && ($r['options']['timeout'] ?? 0) === 25 && ($r['options']['connect_timeout'] ?? 0) === 8 && ($r['options']['verify'] ?? false) === true && ($r['options']['verifyname'] ?? false) === true; })) === 5);
    psf_check('source waves no longer create one operation-log row per five-product request', count(array_filter($GLOBALS['psf_logs'], function ($event) { return ($event[0] ?? '') === 'queue_source_parallel_wave'; })) === 0);
    psf_check('source-wave metrics accumulate for the eventual grouped dispatch log', ($GLOBALS['evazar_queue_source_parallel_stats']['waves'] ?? 0) === 1 && ($GLOBALS['evazar_queue_source_parallel_stats']['requests'] ?? 0) === 5 && ($GLOBALS['evazar_queue_source_parallel_stats']['responses'] ?? 0) === 5);
    $source_summary = evazar_queue_source_parallel_stats_take_summary();
    psf_check('source summary reports total requests/waves once after preparation', strpos($source_summary, '5 درخواست در 1 موج') !== false && strpos($source_summary, 'حداکثر ۵ محصول') !== false && evazar_queue_source_parallel_stats_take_summary() === '');
    psf_check('source summary names the independent primary pool size and its eligible concurrency', strpos($source_summary, 'Workerهای اصلی تنظیم‌شده=5') !== false && strpos($source_summary, 'هم‌زمانی مؤثر ابتدای اجرا=2') !== false);
    psf_check('source summary records actual per-Worker request distribution and wave size', strpos($source_summary, 'source-a.workers.dev=1') !== false && strpos($source_summary, 'اندازه موج‌ها: 1 موج 5تایی') !== false);
    psf_check('source summary records the five Workers eligible in this exact wave', strpos($source_summary, 'وضعیت واجدشرایط موج‌ها: 1 موج با 5/5 Worker واجدشرایط') !== false);
    psf_check('source summary includes per-wave selected Worker hosts for troubleshooting', strpos($source_summary, 'ریزموج‌ها: #1: ورودی=5، واجدشرایط=5/5، انتخاب=5') !== false && strpos($source_summary, 'Workerهای انتخابی=source-a.workers.dev') !== false);

    // Regression for production log: Worker HTTP 503 wrapping Digikala v2=502, with
    // Requests multi-response header values represented as arrays rather than strings.
    psf_reset();
    $GLOBALS['psf_modes'] = ['80808080' => 'source_503_array_headers'];
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>808,'dkp'=>'80808080']], 1);
    $array_header_entry = $GLOBALS['evazar_queue_prefetched_product_source']['80808080'] ?? [];
    $array_header_diag = $array_header_entry['diagnostic'] ?? [];
    $array_header_response = $array_header_entry['response'] ?? [];
    psf_check('array-valued X-Evazar-Error-Scope is normalized to source in parallel product fetch', ($array_header_diag['error_scope'] ?? '') === 'source');
    psf_check('array-valued Worker version is preserved as 1.13.27, never the literal Array', ($array_header_diag['worker_version'] ?? '') === '1.13.27' && ($array_header_diag['worker_version'] ?? '') !== 'Array');
    psf_check('Worker HTTP 503 with upstream v2=502 is retained as source_server_error, not worker_http_503', ($array_header_diag['code'] ?? '') === 'worker_upstream_source_server_error' && (int)($array_header_diag['http_code'] ?? 0) === 503 && (int)($array_header_diag['upstream_status_v2'] ?? 0) === 502);
    psf_check('source-scoped 503 stays on the current item and does not enter serial Worker failover', ($array_header_entry['mode'] ?? '') === 'response' && count(\WpOrg\Requests\Requests::$calls) === 1);
    psf_check('source-scoped 503 does not cool down the Worker that successfully relayed the upstream failure', empty($GLOBALS['psf_cooldowns']));
    psf_check('multi-response conversion emits scalar normalized diagnostic headers', ($array_header_response['headers']['x-evazar-worker-version'] ?? '') === '1.13.27' && ($array_header_response['headers']['x-evazar-error-scope'] ?? '') === 'source');

    // If the scope header is absent but the documented Worker JSON contract carries source_*
    // and explicit upstream status metadata, use the same narrow source classification.
    psf_reset();
    $GLOBALS['psf_modes'] = ['81818181' => 'source_503_scope_missing'];
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>818,'dkp'=>'81818181']], 1);
    $missing_scope_entry = $GLOBALS['evazar_queue_prefetched_product_source']['81818181'] ?? [];
    psf_check('source scope can be safely inferred from Worker version plus source_* JSON and upstream status when header is absent', ($missing_scope_entry['diagnostic']['error_scope'] ?? '') === 'source' && ($missing_scope_entry['diagnostic']['code'] ?? '') === 'worker_upstream_source_server_error');
    psf_check('inferred source scope does not create a false Worker cooldown', empty($GLOBALS['psf_cooldowns']));

    psf_check('a real HTTP response releases its own lease even when the HTTP status is an error', empty($GLOBALS['psf_worker_locks']));

    psf_reset();
    update_option('evazar_source_fetch_adaptive_state', ['version'=>1,'concurrency'=>5,'success_streak'=>0,'configured_workers'=>5,'last_outcome'=>'test','last_reason'=>'test','updated_at'=>time()], false);
    \WpOrg\Requests\Requests::$throw = true;
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>1,'dkp'=>'701'], (object)['id'=>2,'dkp'=>'702'], (object)['id'=>3,'dkp'=>'703'], (object)['id'=>4,'dkp'=>'704'], (object)['id'=>5,'dkp'=>'705']], 5);
    psf_check('parallel transport exception retains every uncertain Worker lease', count($GLOBALS['psf_worker_locks']) === 5 && count(array_filter($GLOBALS['psf_lock_events'], function ($event) { return ($event['action'] ?? '') === 'release'; })) === 0);
    $calls_after_throw = count(\WpOrg\Requests\Requests::$calls);
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>11,'dkp'=>'711']], 1);
    psf_check('serial/next-wave fallback does not issue another request to Workers with uncertain retained leases', count(\WpOrg\Requests\Requests::$calls) === $calls_after_throw && count($GLOBALS['psf_worker_locks']) === 5);
    \WpOrg\Requests\Requests::$throw = false;

    psf_reset();
    update_option('evazar_source_fetch_adaptive_state', ['version'=>1,'concurrency'=>3,'success_streak'=>0,'configured_workers'=>5,'last_outcome'=>'test','last_reason'=>'test','updated_at'=>time()], false);
    $GLOBALS['psf_modes'] = ['722'=>'missing_response'];
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>1,'dkp'=>'721'], (object)['id'=>2,'dkp'=>'722'], (object)['id'=>3,'dkp'=>'723']], 3);
    psf_check('partial parallel result releases only Workers with a positive HTTP status', count($GLOBALS['psf_worker_locks']) === 1 && isset($GLOBALS['psf_worker_locks']['https://source-b.workers.dev']) && count(array_filter($GLOBALS['psf_lock_events'], function ($event) { return ($event['action'] ?? '') === 'release'; })) === 2);
    psf_check('missing parallel response remains a transport fallback while its Worker lease is retained', ($GLOBALS['evazar_queue_prefetched_product_source']['722']['mode'] ?? '') === 'fallback' && isset($GLOBALS['psf_worker_locks']['https://source-b.workers.dev']));

    psf_reset();
    evazar_queue_source_parallel_stats_reset();
    $stats_start = microtime(true) - 1.0;
    $five_hosts = ['source-a.workers.dev','source-b.workers.dev','source-c.workers.dev','source-d.workers.dev','source-e.workers.dev'];
    evazar_queue_source_parallel_stats_record(5, 5, 0, 0, 400, $five_hosts, $stats_start);
    evazar_queue_source_parallel_stats_record(5, 5, 0, 0, 450, $five_hosts, $stats_start + 0.5);
    $balanced_summary = evazar_queue_source_parallel_stats_take_summary();
    psf_check('120-product-equivalent 2-wave sample reports one request per Worker per wave', strpos($balanced_summary, '2 موج 5تایی') !== false && strpos($balanced_summary, 'source-a.workers.dev=2') !== false && strpos($balanced_summary, 'source-e.workers.dev=2') !== false);
    psf_check('source wave statistics distinguish a short wave instead of hiding why wave count exceeds ceil(products/5)', true);
    psf_check('Gemini capacity formula stays separate from the five-primary-worker source pool', evazar_queue_adaptive_claim_capacity(250, 4, 30, true, 4) === 120 && evazar_queue_adaptive_claim_capacity(250, 4, 50, true, 4) === 200 && evazar_queue_adaptive_claim_capacity(120, 4, 50, true, 4) === 120 && evazar_queue_adaptive_claim_capacity(250, 3, 30, true, 4) === 90);
    psf_check('effective run ceiling follows four configured Gemini Workers × per-request size, not five source Workers', evazar_queue_effective_run_limit(250) === 120 && evazar_queue_product_source_fetch_concurrency() === 2);
    $GLOBALS['psf_options']['evazar_ai_product_batch_size'] = 20;
    psf_check('lowering Gemini size to 20 reduces one-wave capacity to 4×20=80', evazar_queue_effective_run_limit(250) === 80);
    $GLOBALS['psf_options']['evazar_ai_product_batch_size'] = 50;
    psf_check('raising Gemini size to 50 allows 4×50=200 when the manual ceiling is 250', evazar_queue_effective_run_limit(250) === 200);
    psf_check('a deliberately selected manual ceiling of 120 remains a hard cap even if Gemini size is 50', evazar_queue_effective_run_limit(120) === 120);
    $batch_entries_for_plan = [];
    for ($bi = 1; $bi <= 120; $bi++) $batch_entries_for_plan[] = ['item' => (object) ['id' => $bi, 'dkp' => (string) $bi], 'checkpoint' => []];
    $partition_30 = evazar_queue_partition_product_batches($batch_entries_for_plan, 30);
    $partition_50 = evazar_queue_partition_product_batches($batch_entries_for_plan, 50);
    psf_check('120 products with Gemini size 30 partition into four equal 30-item requests', array_map('count', $partition_30['chunks']) === [30,30,30,30] && empty($partition_30['unpaired']));
    psf_check('120 products with Gemini size 50 partition into 50+50+20, using three of four Gemini Workers', array_map('count', $partition_50['chunks']) === [50,50,20] && empty($partition_50['unpaired']));

    psf_reset();
    update_option('evazar_source_fetch_adaptive_state', ['version'=>1,'concurrency'=>5,'success_streak'=>0,'configured_workers'=>5,'last_outcome'=>'test','last_reason'=>'test','updated_at'=>time()], false);
    $GLOBALS['psf_worker_locks']['https://source-a.workers.dev'] = 'held-by-taxonomy';
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>1,'dkp'=>'801'], (object)['id'=>2,'dkp'=>'802'], (object)['id'=>3,'dkp'=>'803'], (object)['id'=>4,'dkp'=>'804'], (object)['id'=>5,'dkp'=>'805']], 5);
    psf_check('product source wave never uses a primary Worker held by taxonomy and still uses the other four distinct Workers', count(\WpOrg\Requests\Requests::$calls[0]['requests'] ?? []) === 4 && !in_array('source-a.workers.dev', array_map(function ($r) { return parse_url($r['url'], PHP_URL_HOST); }, \WpOrg\Requests\Requests::$calls[0]['requests'] ?? []), true) && ($GLOBALS['psf_worker_locks']['https://source-a.workers.dev'] ?? '') === 'held-by-taxonomy');
    psf_reset();
    $GLOBALS['psf_modes'] = ['444'=>'source_429'];
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>44,'dkp'=>'444']], 5);
    psf_check('source-scoped 429 is preserved for Core rate-limit policy without Worker failover or cooldown', ($GLOBALS['evazar_queue_prefetched_product_source']['444']['mode'] ?? '') === 'response' && ($GLOBALS['evazar_queue_prefetched_product_source']['444']['diagnostic']['error_scope'] ?? '') === 'source' && empty($GLOBALS['psf_cooldowns']));

    psf_reset();
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>1,'dkp'=>'777'], (object)['id'=>2,'dkp'=>'777']], 5);
    psf_check('duplicate DKPs in an input wave produce only one source request and one cache entry', count(\WpOrg\Requests\Requests::$calls[0]['requests'] ?? []) === 1 && count(array_keys($GLOBALS['evazar_queue_prefetched_product_source'])) === 1);

    psf_reset();
    $GLOBALS['psf_modes'] = ['999'=>'malformed_product'];
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>1,'dkp'=>'999']], 5);
    psf_check('HTTP 200 with a non-array product payload is marked malformed instead of success', ($GLOBALS['evazar_queue_prefetched_product_source']['999']['diagnostic']['code'] ?? '') === 'worker_missing_product_payload');

    psf_reset();
    $GLOBALS['psf_modes'] = ['111'=>'worker_502'];
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>11,'dkp'=>'111']], 5);
    psf_check('Worker-level 502 is not cached as a product result and is handed to normal failover', ($GLOBALS['evazar_queue_prefetched_product_source']['111']['mode'] ?? '') === 'fallback' && !empty($GLOBALS['psf_cooldowns']));

    psf_reset();
    \WpOrg\Requests\Requests::$throw = true;
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>1,'dkp'=>'111'], (object)['id'=>2,'dkp'=>'222']], 5);
    psf_check('multi-transport exception leaves every item on the safe serial fallback path', ($GLOBALS['evazar_queue_prefetched_product_source']['111']['mode'] ?? '') === 'fallback' && ($GLOBALS['evazar_queue_prefetched_product_source']['222']['mode'] ?? '') === 'fallback');

    psf_reset();
    // Two Workers are paused: the same wave must use only the three distinct available Workers.
    $GLOBALS['psf_cooldowns']['https://source-a.workers.dev'] = ['until' => time() + 90, 'remaining_seconds' => 90, 'reason' => 'test_cooldown', 'http_code' => 503];
    $GLOBALS['psf_cooldowns']['https://source-b.workers.dev'] = ['until' => time() + 75, 'remaining_seconds' => 75, 'reason' => 'test_cooldown', 'http_code' => 503];
    $pool = evazar_queue_product_source_worker_pool_state('import_source');
    psf_check('pool diagnostic counts only three available Workers when two of five are cooling down', $pool['configured_count'] === 5 && $pool['eligible_count'] === 3 && $pool['cooldown_count'] === 2);
    update_option('evazar_source_fetch_adaptive_state', ['version'=>1,'concurrency'=>5,'success_streak'=>0,'configured_workers'=>5,'last_outcome'=>'test','last_reason'=>'test','updated_at'=>time()], false);
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>1,'dkp'=>'801'], (object)['id'=>2,'dkp'=>'802'], (object)['id'=>3,'dkp'=>'803'], (object)['id'=>4,'dkp'=>'804'], (object)['id'=>5,'dkp'=>'805']], 5);
    $partial_hosts = array_map(function ($r) { return parse_url($r['url'], PHP_URL_HOST); }, \WpOrg\Requests\Requests::$calls[0]['requests'] ?? []);
    psf_check('partial pool sends no more concurrent requests than distinct eligible Workers', count($partial_hosts) === 3 && count(array_unique($partial_hosts)) === 3);
    $partial_summary = evazar_queue_source_parallel_stats_take_summary();
    psf_check('partial wave explicitly reports 3 of 5 eligible Workers and cooldown cause', strpos($partial_summary, '1 موج با 3/5 Worker واجدشرایط') !== false && strpos($partial_summary, 'worker_cooldown=1') !== false);
    psf_check('partial wave identifies the specific cooldown Workers and remaining wait', strpos($partial_summary, 'source-a.workers.dev:مکث 90ث/test_cooldown/HTTP503') !== false && strpos($partial_summary, 'source-b.workers.dev:مکث 75ث/test_cooldown/HTTP503') !== false);

    psf_reset();
    $GLOBALS['psf_counts']['https://source-a.workers.dev'] = 85000;
    $GLOBALS['psf_counts']['https://source-b.workers.dev'] = 85000;
    $budget_pool = evazar_queue_product_source_worker_pool_state('import_source');
    psf_check('mixed source pool captures two daily-budget Workers and three eligible Workers', $budget_pool['eligible_count'] === 3 && $budget_pool['budget_count'] === 2 && count($budget_pool['budget_workers']) === 2);
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>31,'dkp'=>'831'], (object)['id'=>32,'dkp'=>'832'], (object)['id'=>33,'dkp'=>'833'], (object)['id'=>34,'dkp'=>'834'], (object)['id'=>35,'dkp'=>'835']], 5);
    $budget_summary = evazar_queue_source_parallel_stats_take_summary();
    psf_check('wave summary names daily-budget exclusion separately from cooldown', strpos($budget_summary, 'cooldown_and_daily_budget') === false && strpos($budget_summary, 'worker_daily_budget=1') !== false && strpos($budget_summary, 'source-a.workers.dev:سقف‌روزانه') !== false);

    psf_reset();
    foreach (['source-a','source-b','source-c','source-d','source-e'] as $host) $GLOBALS['psf_reject_reservations']['https://' . $host . '.workers.dev'] = true;
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>41,'dkp'=>'841'], (object)['id'=>42,'dkp'=>'842'], (object)['id'=>43,'dkp'=>'843'], (object)['id'=>44,'dkp'=>'844'], (object)['id'=>45,'dkp'=>'845']], 5);
    $reservation_summary = evazar_queue_source_parallel_stats_take_summary();
    psf_check('reservation races are recorded as zero-request waves rather than mislabeled cooldowns', strpos($reservation_summary, 'worker_reservation_or_selection_race=1') !== false && strpos($reservation_summary, 'انتخاب=0') !== false && strpos($reservation_summary, 'هیچ‌کدام') !== false);

    psf_reset();
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>51,'dkp'=>'851']], 5);
    $tail_summary = evazar_queue_source_parallel_stats_take_summary();
    psf_check('a genuinely short queue tail is distinguished from Worker cooldown/reservation problems', strpos($tail_summary, 'queue_tail_smaller_than_worker_pool=1') !== false && strpos($tail_summary, 'واجدشرایط=5/5، انتخاب=1') !== false);

    psf_reset();
    foreach (['source-a','source-b','source-c','source-d','source-e'] as $host) {
        $GLOBALS['psf_cooldowns']['https://' . $host . '.workers.dev'] = ['until' => time() + 18, 'remaining_seconds' => 18, 'reason' => 'test_cooldown', 'http_code' => 503];
    }
    $pool = evazar_queue_product_source_worker_pool_state('import_source');
    psf_check('all-five-cooldown state is explicit and exposes nearest retry time', $pool['eligible_count'] === 0 && $pool['code'] === 'all_workers_in_cooldown' && $pool['retry_after_seconds'] === 18);
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>1,'dkp'=>'901'], (object)['id'=>2,'dkp'=>'902'], (object)['id'=>3,'dkp'=>'903'], (object)['id'=>4,'dkp'=>'904'], (object)['id'=>5,'dkp'=>'905']], 5);
    psf_check('all-cooldown wave sends zero HTTP requests', count(\WpOrg\Requests\Requests::$calls) === 0);
    psf_check('all-cooldown items carry a no-request marker instead of ordinary fallback', count(array_filter($GLOBALS['evazar_queue_prefetched_product_source'], function ($entry) { return ($entry['mode'] ?? '') === 'pool_unavailable' && empty($entry['request_sent']) && (($entry['diagnostic']['code'] ?? '') === 'all_workers_in_cooldown'); })) === 2);
    evazar_queue_log_batch_run_summary(5, 0, 0, 0, 5, 'worker_unavailable', 'all source Workers cooling down');
    $early_stop_summary_event = end($GLOBALS['psf_logs']);
    psf_check('when no Gemini dispatch occurs, the final queue summary still includes source-wave diagnostics', ($early_stop_summary_event[0] ?? '') === 'queue_batch_run_summary' && strpos((string) ($early_stop_summary_event[1] ?? ''), 'تشخیص موج‌های دریافت') !== false && strpos((string) ($early_stop_summary_event[1] ?? ''), 'all_workers_in_cooldown') !== false);
    psf_check('early-stop summary also retains structured per-wave diagnostics in event context', strpos((string) (($early_stop_summary_event[5]['source_fetch_wave_diagnostics'] ?? '')), 'واجـدشرایط=0/5') !== false || strpos((string) (($early_stop_summary_event[5]['source_fetch_wave_diagnostics'] ?? '')), 'واجدشرایط=0/5') !== false);
    psf_reset();
    foreach (['source-a','source-b','source-c','source-d','source-e'] as $host) $GLOBALS['psf_counts']['https://' . $host . '.workers.dev'] = 85000;
    $pool = evazar_queue_product_source_worker_pool_state('import_source');
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>1,'dkp'=>'911'], (object)['id'=>2,'dkp'=>'912']], 5);
    psf_check('all daily budgets exhausted prevent network dispatch and mark items as unsent', $pool['eligible_count'] === 0 && $pool['code'] === 'all_workers_daily_budget_exhausted' && count(\WpOrg\Requests\Requests::$calls) === 0 && ($GLOBALS['evazar_queue_prefetched_product_source']['911']['mode'] ?? '') === 'pool_unavailable');
    psf_check('source circuit keeps already-requested successful responses eligible for processing', evazar_queue_source_circuit_should_defer_tail(true, true, '906', ['mode'=>'response','request_sent'=>true]) === false);
    psf_check('source circuit also retains already-attempted fallback results for exact resolution', evazar_queue_source_circuit_should_defer_tail(true, true, '907', ['mode'=>'fallback','request_sent'=>true]) === false);
    psf_check('source circuit defers only a product with no request marker', evazar_queue_source_circuit_should_defer_tail(true, true, '908', ['mode'=>'pool_unavailable','request_sent'=>false]) === true);
    psf_check('source circuit does not misclassify empty DKP rows as source-tail items', evazar_queue_source_circuit_should_defer_tail(true, true, '', []) === false);
    psf_check('source circuit helper remains inactive outside Gemini batch mode', evazar_queue_source_circuit_should_defer_tail(false, true, '909', []) === false);

    psf_reset();
    update_option('evazar_source_fetch_adaptive_state', ['version'=>1,'concurrency'=>5,'success_streak'=>0,'configured_workers'=>5,'last_outcome'=>'test','last_reason'=>'test','updated_at'=>time()], false);
    $GLOBALS['psf_modes'] = ['901'=>'worker_502','902'=>'worker_502','903'=>'worker_502','904'=>'worker_502','905'=>'worker_502'];
    evazar_queue_prefetch_product_sources_parallel([(object)['id'=>1,'dkp'=>'901'], (object)['id'=>2,'dkp'=>'902'], (object)['id'=>3,'dkp'=>'903'], (object)['id'=>4,'dkp'=>'904'], (object)['id'=>5,'dkp'=>'905']], 5);
    psf_check('five simultaneous Worker failures are captured as five attempted responses', count(\WpOrg\Requests\Requests::$calls[0]['requests'] ?? []) === 5 && count(array_filter($GLOBALS['evazar_queue_prefetched_product_source'], function ($entry) { return !empty($entry['request_sent']) && isset($entry['diagnostic']['http_code']); })) === 5);
    psf_check('when the five failed responses exhaust the pool, attempted items are distinguished from unrequested tail', count(array_filter($GLOBALS['evazar_queue_prefetched_product_source'], function ($entry) { return ($entry['mode'] ?? '') === 'worker_failure_deferred'; })) === 5);
    $failed_wave_summary = evazar_queue_source_parallel_stats_take_summary();
    psf_check('per-wave report captures the pool transition from five available to zero available after HTTP failures', strpos($failed_wave_summary, 'واجدشرایط=5/5، انتخاب=5') !== false && strpos($failed_wave_summary, 'پس‌ازموج: واجدشرایط=0/5، مکث=5') !== false);
    psf_check('post-wave report names the actual HTTP failure that put Workers into cooldown', strpos($failed_wave_summary, 'source-a.workers.dev:مکث') !== false && strpos($failed_wave_summary, 'worker_http_502') !== false);

    psf_reset();
    $GLOBALS['wpdb'] = new PsfFakeDb();
    $tail_items = [(object)['id'=>100,'dkp'=>'1001'], (object)['id'=>101,'dkp'=>'1002'], (object)['id'=>102,'dkp'=>'1003'], (object)['id'=>103,'dkp'=>'1004']];
    $defer_pool = ['configured_count'=>5,'eligible_count'=>0,'cooldown_count'=>5,'budget_count'=>0,'retry_after_seconds'=>18,'code'=>'all_workers_in_cooldown','reason'=>'all source Workers paused'];
    $tail_result = evazar_queue_defer_claimed_source_tail($tail_items, 1, 'test-claim-token', $defer_pool);
    psf_check('pool cooldown releases only the unvisited claim tail with one guarded bulk UPDATE', $tail_result['deferred'] === 3 && count($GLOBALS['wpdb']->queries) === 1 && strpos($GLOBALS['wpdb']->queries[0], "status='processing'") !== false);
    psf_check('pool cooldown release uses a future next-attempt time and does not write/increment retries', isset($GLOBALS['wpdb']->prepared[0]['args'][4]) && !preg_match('/retries\s*=/', $GLOBALS['wpdb']->queries[0]));
    psf_check('pool cooldown release writes a single grouped diagnostic, not one log per unrequested product', count(array_filter($GLOBALS['psf_logs'], function ($event) { return ($event[0] ?? '') === 'queue_source_pool_deferred'; })) === 1 && !count(array_filter($GLOBALS['psf_logs'], function ($event) { return ($event[0] ?? '') === 'queue_pre_gemini_item_failure'; })));
    $GLOBALS['wpdb'] = new PsfFakeDb();
    $circuit_pool = ['configured_count'=>5,'eligible_count'=>0,'cooldown_count'=>0,'budget_count'=>0,'retry_after_seconds'=>60,'code'=>'source_circuit_open','reason'=>'three consecutive source failures'];
    $circuit_result = evazar_queue_defer_claimed_source_tail($tail_items, 2, 'test-circuit-token', $circuit_pool);
    psf_check('source circuit tail is assigned the distinct DIGIKALA_SOURCE_CIRCUIT_OPEN code', $circuit_result['deferred'] === 2 && ($GLOBALS['wpdb']->prepared[0]['args'][1] ?? '') === 'DIGIKALA_SOURCE_CIRCUIT_OPEN');
    $GLOBALS['wpdb'] = new PsfFakeDb();
    $attempted_result = evazar_queue_defer_attempted_source_item((object)['id'=>500,'dkp'=>'9555'], 'claim-token', ['code'=>'worker_http_503','detail'=>'HTTP 503','attempted'=>1,'http_code'=>503,'worker_host'=>'source-a.workers.dev'], $defer_pool);
    psf_check('a real failed Worker request retains per-product diagnostic but defers without retry increment', $attempted_result['deferred'] === 1 && ($GLOBALS['wpdb']->updates[0]['data']['status'] ?? '') === 'pending' && !array_key_exists('retries', $GLOBALS['wpdb']->updates[0]['data']) && ($GLOBALS['wpdb']->updates[0]['data']['error_code'] ?? '') === 'PRIMARY_WORKER_TEMPORARY_FAILURE');

    $queue_source = file_get_contents(dirname(__DIR__) . '/queue-manager.php');
    $importer_source = file_get_contents(dirname(__DIR__) . '/importer.php');
    $admin_source = file_get_contents(dirname(__DIR__) . '/evazar-core.php');
    psf_check('generic source_fetch_failed is not automatically classified as upstream overload', strpos($queue_source, "['source_server_error', 'source_rate_limited']") !== false && strpos($queue_source, "['source_server_error', 'source_rate_limited', 'source_fetch_failed']") === false);
    psf_check('confirmed Digikala overload applies a short local settling pause without cooling down the relay Worker', strpos($queue_source, 'usleep(1500000)') !== false && strpos($queue_source, 'brief local settling interval') !== false);
    psf_check('queue loop prepares a bounded wave before invoking the normal per-product importer', strpos($queue_source, 'evazar_queue_prefetch_product_sources_parallel($source_wave, $wave_cap)') !== false && strpos($queue_source, 'array_slice($items, $item_index, $wave_cap)') !== false);
    psf_check('source concurrency is enforced inside the parallel helper and bounded by the persistent adaptive cap', strpos($queue_source, 'function evazar_queue_product_source_adaptive_observe_wave') !== false && strpos($queue_source, 'min($configured, 5') !== false && strpos($queue_source, 'max(1, absint($adaptive_cap))') !== false);
    psf_check('queue defers remaining claimed rows in one guarded tail update when the entire pool is unavailable', strpos($queue_source, 'evazar_queue_defer_claimed_source_tail($items, $item_index, $claim_token, $pool_state)') !== false && strpos($queue_source, 'PRIMARY_WORKERS_IN_COOLDOWN') !== false);
    psf_check('items that had a real failed Worker request preserve exact diagnostic and do not increment retries on pool cooldown', strpos($queue_source, 'evazar_queue_defer_attempted_source_item($item, $claim_token') !== false && strpos($queue_source, 'worker_failure_deferred') !== false);
    psf_check('three-error source circuit consumes already-requested responses before deferring the unrequested tail', strpos($queue_source, 'evazar_queue_source_circuit_should_defer_tail($batch_collect_enabled, $source_circuit_open') !== false && strpos($queue_source, 'already_requested_tail') !== false && strpos($queue_source, "'DIGIKALA_SOURCE_CIRCUIT_OPEN'") !== false);
    psf_check('parallel wave never reuses one Worker URL for two concurrent products', strpos($queue_source, 'return !isset($used[$candidate[\'url\']]);') !== false);
    psf_check('importer consumes each cached source result by exact DKP and removes it after one use', strpos($importer_source, "\$GLOBALS['evazar_queue_prefetched_product_source'][\$dkp]") !== false && strpos($importer_source, "unset(\$GLOBALS['evazar_queue_prefetched_product_source'][\$dkp])") !== false);
    psf_check('importer validates that product payload is an array before parsing fields', strpos($importer_source, "is_array(\$cf_data['product'] ?? null)") !== false);
    psf_check('Worker-level failures are handed back to existing serial failover', strpos($importer_source, "(\$prefetched_source['mode'] ?? '') === 'response'") !== false && strpos($importer_source, "evazar_primary_worker_request('', ['dkp' => \$dkp]") !== false);
    psf_check('parallel source path does not request Digikala directly from Core', strpos(substr($queue_source, strpos($queue_source, 'function evazar_queue_prefetch_product_sources_parallel'), 12000), 'api.digikala.com') === false);
    psf_check('source summary is attached to the existing batch worker-assignment log', strpos($queue_source, '$dispatch_message .= $source_summary') !== false && strpos($queue_source, "evazar_gemini_log_event('batch_dispatch_wave', \$dispatch_message") !== false);
    psf_check('planning log distinguishes the primary source pool from the separate Gemini pool', strpos($queue_source, 'دریافت دیجی‌کالا: Workerهای اصلی تنظیم‌شده=') !== false && strpos($queue_source, 'بازنویسی Gemini: Workerهای تنظیم‌شده=') !== false);
    psf_check('planned Gemini request chunks are logged explicitly (e.g. 30+30+30+30)', strpos($queue_source, '$chunk_plan_label') !== false && strpos($queue_source, "'gemini_chunk_plan' => \$chunk_plan_label") !== false);
    psf_check('queue UI explains why 4x50 is capped at 120 when the separate manual ceiling remains 120', strpos($queue_source, 'سقف کل هر اجرا یک محدودیت مستقل و سخت است') !== false && strpos($queue_source, '۵۰ + ۵۰ + ۲۰') !== false && strpos($queue_source, 'تعداد Workerهای اصلی فقط سرعت دریافت') !== false);
    psf_check('the parallel source fetcher does not emit per-wave Gemini operation events', strpos(substr($queue_source, strpos($queue_source, 'function evazar_queue_prefetch_product_sources_parallel'), 15000), "evazar_gemini_log_event(\n            'queue_source_parallel_wave'") === false);
    $admin_filter_needle = "sanitize_key((string) (\$event['type'] ?? '')) !== 'queue_source_parallel_wave'";
    psf_check('historical per-wave source events are filtered from the Gemini settings summary', strpos($admin_source, $admin_filter_needle) !== false);
    psf_check('historical per-wave source events are filtered from the standalone Gemini report', substr_count($admin_source, $admin_filter_needle) >= 2);

    echo "\nRESULT: {$GLOBALS['psf_checks']} assertions passed.\n";
}
