<?php
/** Regression checks for 200-entry lightweight import log retention and display. */
$root = dirname(__DIR__);
$importer = file_get_contents($root . '/importer.php');
$queue = file_get_contents($root . '/queue-manager.php');
$core = file_get_contents($root . '/evazar-core.php');
$assertions = 0;
$failures = 0;
function evz_log_retention_check($name, $condition) {
    global $assertions, $failures;
    $assertions++;
    if (!$condition) {
        $failures++;
        fwrite(STDERR, "FAIL: {$name}\n");
    } else {
        echo "PASS: {$name}\n";
    }
}
evz_log_retention_check('Core version bumped to 2.9.84.96', strpos($core, '* Version: 2.9.84.96') !== false);
evz_log_retention_check('import log writer retains up to 200 entries', strpos($importer, 'if (count($lines) > 200)') !== false && strpos($importer, 'array_slice($lines, 0, 200)') !== false);
evz_log_retention_check('log fetch defaults to 200 and clamps to 1..200', strpos($importer, 'function evazar_import_get_last_logs($limit = 200)') !== false && strpos($importer, '$limit = max(1, min(200, (int) $limit));') !== false);
evz_log_retention_check('rendered import log table requests 200 entries', strpos($importer, '$logs = evazar_import_get_last_logs(200);') !== false && strpos($importer, 'function evazar_render_import_logs_table()') !== false);
evz_log_retention_check('empty state and footer both identify 200-entry log window', strpos($importer, 'گزارش ۲۰۰ عملیات اخیر') !== false && strpos($importer, 'از حداکثر ۲۰۰') !== false);
evz_log_retention_check('importer-page button says 200 recent import logs', strpos($queue, 'مشاهده ۲۰۰ لاگ اخیر واردات') !== false);
evz_log_retention_check('queue backfill still intentionally consumes only 50 logs', strpos($queue, 'evazar_import_get_last_logs(50)') !== false);
evz_log_retention_check('old 50-entry truncation is gone from active import logger', strpos($importer, 'count($lines) > 50') === false && strpos($importer, 'array_slice($lines, 0, 50)') === false);
if ($failures) {
    fwrite(STDERR, "{$failures}/{$assertions} failed\n");
    exit(1);
}
echo "{$assertions} assertions passed.\n";
