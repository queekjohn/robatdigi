<?php
/** Regression tests for exact per-product failures before Gemini and grouped run diagnostics. */
error_reporting(E_ALL);
ini_set('display_errors', '1');
if (!defined('ABSPATH')) define('ABSPATH', dirname(__DIR__) . '/');
if (!defined('MINUTE_IN_SECONDS')) define('MINUTE_IN_SECONDS', 60);
if (!defined('HOUR_IN_SECONDS')) define('HOUR_IN_SECONDS', 3600);
if (!defined('DAY_IN_SECONDS')) define('DAY_IN_SECONDS', 86400);
$GLOBALS['pgd_options'] = [];
$GLOBALS['pgd_assertions'] = 0;
function add_action(...$args) {}
function add_filter(...$args) {}
function register_activation_hook(...$args) {}
function register_deactivation_hook(...$args) {}
function sanitize_key($value) { $value = strtolower((string) $value); return preg_replace('/[^a-z0-9_\-]/', '', $value); }
function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
function sanitize_textarea_field($value) { return trim(strip_tags((string) $value)); }
function absint($value) { return abs((int) $value); }
function esc_url_raw($value) { return (string) $value; }
function wp_parse_url($url, $component = -1) { return parse_url($url, $component); }
function get_option($name, $default = false) { return array_key_exists($name, $GLOBALS['pgd_options']) ? $GLOBALS['pgd_options'][$name] : $default; }
function update_option($name, $value, $autoload = null) { $GLOBALS['pgd_options'][$name] = $value; return true; }
function current_time($type = 'mysql', $gmt = false) { return '2026-10-27 00:00:00'; }
function wp_upload_dir() { return ['basedir' => sys_get_temp_dir() . '/evazar-pgd-test']; }
function wp_mkdir_p($path) { return is_dir($path) || mkdir($path, 0777, true); }
function delete_transient($name) { return true; }
function check_pgd($name, $passed) {
    $GLOBALS['pgd_assertions']++;
    if (!$passed) { fwrite(STDERR, "FAIL: {$name}\n"); exit(1); }
    echo "PASS: {$name}\n";
}
if (!class_exists('WP_Error')) {
    class WP_Error {
        private $code; private $message; private $data;
        public function __construct($code, $message = '', $data = null) { $this->code = $code; $this->message = $message; $this->data = $data; }
        public function get_error_code() { return $this->code; }
        public function get_error_message($code = '') { return $this->message; }
        public function get_error_data($code = '') { return ($code === '' || $code === $this->code) ? $this->data : null; }
    }
}
if (!function_exists('is_wp_error')) { function is_wp_error($thing) { return $thing instanceof WP_Error; } }
require_once __DIR__ . '/../importer.php';
require_once __DIR__ . '/../queue-manager.php';

$GLOBALS['pgd_options']['evz_gemini_ops_log'] = [];
$GLOBALS['evazar_queue_pre_gemini_failure_groups'] = [];
$GLOBALS['evazar_queue_pre_gemini_failure_count'] = 0;
$GLOBALS['evazar_last_product_fetch_diagnostic'] = ['code' => 'STALE_DIAGNOSTIC', 'http_code' => 418, 'worker_host' => 'stale.example'];

$worker_diag = [
    'code' => 'worker_upstream_source_server_error',
    'detail' => 'دیجی‌کالا در API نسخه v2 خطای سرور برگرداند. Token=AIza123456789012345678901234567890',
    'http_code' => 502,
    'worker_host' => 'source-a.workers.dev',
    'worker_version' => '1.13.25',
    'attempted' => 1,
    'error_scope' => 'source',
    'source_error_code' => 'source_server_error',
    'upstream_status_v2' => 502,
    'upstream_status_v1' => 0,
    'upstream_error_v2' => 'upstream returned HTTP 502',
    'elapsed_ms' => 413,
];
$source_error = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'دریافت محصول ناموفق بود.', $worker_diag);
$busy_pool_error = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'همه Workerها مشغول‌اند.', [
    'code' => 'worker_pool_busy', 'attempted' => 0, 'busy_skipped' => 5,
    'retry_after_seconds' => 75, 'error_scope' => 'worker',
]);
$busy_pool_policy = evazar_queue_upstream_source_failure_policy($busy_pool_error);
check_pgd('serial product import fallback treats cross-queue Worker leases as run deferral, not final product failure', ($busy_pool_policy['action'] ?? '') === 'defer_run' && ($busy_pool_policy['queue_error_code'] ?? '') === 'PRIMARY_WORKERS_BUSY' && (int) ($busy_pool_policy['delay_seconds'] ?? 0) === 75);
$mixed_pool_error = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'Workerها در حال آزاد شدن هستند.', [
    'code' => 'worker_pool_unavailable', 'attempted' => 0, 'busy_skipped' => 2,
    'cooldown_skipped' => 3, 'retry_after_seconds' => 45,
]);
$mixed_pool_policy = evazar_queue_upstream_source_failure_policy($mixed_pool_error);
check_pgd('mixed busy and cooldown pool also defers without retry inflation', ($mixed_pool_policy['action'] ?? '') === 'defer_run' && ($mixed_pool_policy['queue_error_code'] ?? '') === 'PRIMARY_WORKERS_TEMPORARILY_UNAVAILABLE');
evazar_queue_log_pre_gemini_failure((object) ['id' => 51, 'dkp' => '12876545'], $source_error);
$event = $GLOBALS['pgd_options']['evz_gemini_ops_log'][0] ?? [];
check_pgd('per-product source failure event is created with the exact DKP and queue row id', ($event['type'] ?? '') === 'queue_pre_gemini_item_failure' && ($event['dkp'] ?? '') === '12876545' && ($event['queue_item_id'] ?? 0) === 51);
check_pgd('uppercase WP_Error code retrieves its associated source diagnostic case-sensitively', ($event['diagnostic_code'] ?? '') === 'worker_upstream_source_server_error' && ($event['diagnostic_http_code'] ?? 0) === 502);
check_pgd('event records exact upstream and Worker metadata without leaking stale global diagnostic', ($event['worker'] ?? '') === 'source-a.workers.dev' && ($event['worker_version'] ?? '') === '1.13.25' && ($event['upstream_status_v2'] ?? 0) === 502 && ($event['upstream_status_v1'] ?? -1) === 0 && strpos($event['message'], 'stale.example') === false);
check_pgd('sensitive key-like text is redacted from the per-product diagnostic', strpos($event['message'], 'AIza123456789012345678901234567890') === false && strpos($event['message'], '[REDACTED_API_KEY]') !== false);
check_pgd('event explains that the failure happened during source fetch and Worker was attempted', ($event['error_stage'] ?? '') === 'source_fetch' && ($event['worker_attempted'] ?? '') === 'yes' && strpos($event['message'], 'HTTP Worker=502') !== false && strpos($event['message'], 'upstream v1=not-attempted/no-response') !== false && ($event['upstream_error_v2'] ?? '') === 'upstream returned HTTP 502');
$worker_503_diag = array_merge($worker_diag, [
    'code' => 'worker_upstream_source_server_error',
    'detail' => 'منبع دیجی‌کالا در API نسخه v2 خطای 502 برگرداند.',
    'http_code' => 503,
    'worker_version' => '1.13.27',
    'error_scope' => 'source',
    'source_error_code' => 'source_server_error',
    'upstream_status_v2' => 502,
    'upstream_status_v1' => 0,
]);
$worker_503_error = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'Worker HTTP 503 caused by Digikala v2 HTTP 502.', $worker_503_diag);
evazar_queue_log_pre_gemini_failure((object) ['id' => 55, 'dkp' => '22027358'], $worker_503_error);
$worker_503_event = $GLOBALS['pgd_options']['evz_gemini_ops_log'][0] ?? [];
check_pgd('Worker HTTP 503 remains distinct from the upstream v2 HTTP 502 in event fields', ($worker_503_event['diagnostic_http_code'] ?? 0) === 503 && ($worker_503_event['upstream_status_v2'] ?? 0) === 502 && ($worker_503_event['worker_version'] ?? '') === '1.13.27');
check_pgd('source scope and correct Worker version are visible in the pre-Gemini event message', ($worker_503_event['error_scope'] ?? '') === 'source' && strpos($worker_503_event['message'], 'HTTP Worker=503') !== false && strpos($worker_503_event['message'], 'scope=source') !== false && strpos($worker_503_event['message'], 'نسخه Worker=1.13.27') !== false && strpos($worker_503_event['message'], '[Worker=Array]') === false);

$db_error = new WP_Error('DKP_LOOKUP_FAILED', 'خواندن وضعیت موجودی محصول با خطای دیتابیس مواجه شد.', ['db_error' => 'Unknown column `foo` in field list; SELECT secret FROM wp_posts']);
evazar_queue_log_pre_gemini_failure((object) ['id' => 52, 'dkp' => '12876546'], $db_error);
$db_event = $GLOBALS['pgd_options']['evz_gemini_ops_log'][0] ?? [];
check_pgd('database lookup failure is categorized separately and says Worker was not called', ($db_event['error_stage'] ?? '') === 'database_identity_lookup' && ($db_event['worker_attempted'] ?? '') === 'no');
check_pgd('database diagnostic is bounded and omits the SQL statement', strpos($db_event['message'], 'Unknown column') !== false && strpos($db_event['message'], 'SELECT secret') === false);

$invalid = new WP_Error('invalid', 'شناسه DKP معتبر نیست.');
evazar_queue_log_pre_gemini_failure((object) ['id' => 53, 'dkp' => 'abc'], $invalid);
$invalid_event = $GLOBALS['pgd_options']['evz_gemini_ops_log'][0] ?? [];
check_pgd('invalid DKP failure is identified as pre-request validation, not a Worker failure', ($invalid_event['error_stage'] ?? '') === 'dkp_validation' && ($invalid_event['worker_attempted'] ?? '') === 'no' && ($invalid_event['dkp'] ?? '') === '');

// A second item with the same source error must aggregate into the same group.
evazar_queue_log_pre_gemini_failure((object) ['id' => 54, 'dkp' => '12876547'], $source_error);
check_pgd('same failure signature is aggregated with an exact count and DKP samples', ($GLOBALS['evazar_queue_pre_gemini_failure_count'] ?? 0) === 5 && count($GLOBALS['evazar_queue_pre_gemini_failure_groups']) === 4);
$GLOBALS['evazar_queue_batch_claim_diagnostics'] = ['context' => ['run_capacity' => 120, 'eligible_pending' => 168942, 'claim_unfilled_capacity' => 0, 'invalid_dkp_quarantined' => 0]];
evazar_queue_log_batch_run_summary(120, 45, 45, 75, 0, 'completed', 'test run');
$summary = $GLOBALS['pgd_options']['evz_gemini_ops_log'][0] ?? [];
check_pgd('final run summary includes grouped pre-Gemini causes and failure count', ($summary['type'] ?? '') === 'queue_batch_run_summary' && ($summary['queue_pre_gemini_failure_count'] ?? 0) === 5 && !empty($summary['queue_pre_gemini_failure_groups']) && strpos($summary['message'], 'گروه‌بندی خطاهای پیش از Gemini (5 مورد)') !== false);
check_pgd('summary group includes source HTTP 502 and representative DKP', (strpos($summary['message'], 'worker_upstream_source_server_error HTTP 502') !== false && strpos($summary['message'], 'worker_upstream_source_server_error HTTP 503') !== false) && strpos($summary['message'], '12876545') !== false);

// Ensure enough of a high-volume run remains available for inspection in the admin report.
$GLOBALS['pgd_options']['evz_gemini_ops_log'] = array_fill(0, 249, ['type' => 'old', 'time' => time(), 'message' => 'old']);
evazar_gemini_log_event('queue_pre_gemini_item_failure', 'diagnostic cap check', '', 0, 0, ['dkp' => '12345', 'queue_item_id' => 55, 'error_stage' => 'source_fetch', 'error_code' => 'EVAZAR_WORKER_PRODUCT_UNAVAILABLE']);
check_pgd('Gemini operation log retains up to 250 events so 75-product failure runs are inspectable', count($GLOBALS['pgd_options']['evz_gemini_ops_log']) === 250 && ($GLOBALS['pgd_options']['evz_gemini_ops_log'][0]['queue_item_id'] ?? 0) === 55);

$queue = file_get_contents(__DIR__ . '/../queue-manager.php');
$core = file_get_contents(__DIR__ . '/../evazar-core.php');
check_pgd('queue loop logs each WP_Error before handling or deferring it', strpos($queue, 'evazar_queue_log_pre_gemini_failure($item, $result)') !== false && strpos($queue, "'queue_pre_gemini_item_failure'") !== false);
check_pgd('compact admin cards display up to 250 events and expose queue row/stage in card details', strpos($core, 'array_slice($events, 0, 250)') !== false && strpos($core, 'ردیف صف #') !== false && strpos($core, 'مرحله خطا') !== false && strpos($core, 'evz-gemini-card__details') !== false);
$failure_helper_start = strpos($queue, 'function evazar_queue_log_pre_gemini_failure');
$failure_helper_end = strpos($queue, '/** Log final outcomes after queue and Gemini work have actually finished. */', $failure_helper_start ?: 0);
$failure_helper = ($failure_helper_start !== false && $failure_helper_end !== false) ? substr($queue, $failure_helper_start, $failure_helper_end - $failure_helper_start) : '';
check_pgd('per-product logging excludes prompts and raw request bodies', $failure_helper !== '' && strpos($failure_helper, '\'diagnostic_detail\' => $detail_for_log') !== false && strpos($failure_helper, 'user_msg') === false && strpos($failure_helper, 'request_body') === false);
check_pgd('plugin version is bumped to 2.9.84.96', strpos($core, '* Version: 2.9.84.96') !== false);

fwrite(STDOUT, "\nRESULT: {$GLOBALS['pgd_assertions']} assertions passed.\n");
