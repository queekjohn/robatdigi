const fs = require('fs');
const path = require('path');
const source = fs.readFileSync(path.join(__dirname, '..', 'worker', 'digikala-worker.js'), 'utf8');
let passed = 0;
function check(name, condition) {
  if (!condition) { console.error('FAIL:', name); process.exitCode = 1; }
  else { passed++; console.log('PASS:', name); }
}
check('worker version is bumped to 1.13.27', source.includes("const DIGIKALA_WORKER_VERSION = '1.13.27';"));
check('explicit URL extraction supports uri/url/href/path fields', /entry\.uri, entry\.url, entry\.href, entry\.path, entry\.url_path/.test(source));
check('explicit URL extraction supports canonical URLs and JSON-LD @id', /entry\.canonical_url, entry\.canonicalUrl, entry\['@id'\]/.test(source));
check('breadcrumb JSON-LD wrappers are supported', /rawBreadcrumbs\?\.itemListElement/.test(source) && /rawBreadcrumbs\?\.items/.test(source));
check('direct category fallback preserves only source-supplied URL', /const catUri = explicitSourceUrl\(sourceCategory\?\.url\)/.test(source) && /breadcrumbs\.push\(\{ title: catTitle, url: catUri \}\)/.test(source));
check('no category URL is built from category title/slug', !/url\s*:\s*`\/search\//.test(source));
check('source-page slug pattern allows one explicit terminal hyphen', source.includes("const slugPattern = /^[\\p{L}\\p{M}\\p{N}]+(?:[._-][\\p{L}\\p{M}\\p{N}]+)*-?$/u;"));
check('source-page validator remains bounded to explicit path segments', /if \(!\['search', 'brand', 'brand-landing', 'main'\]\.includes\(route\)\) return ''/.test(source));
check('Core preflight still rejects missing source category paths', fs.readFileSync(path.join(__dirname, '..', 'importer.php'), 'utf8').includes('PRODUCT_CATEGORY_SOURCE_PATH_MISSING'));
console.log(`${passed} assertions passed`);
