<?php
/** Regression coverage for orphaned queue claims and run-lock heartbeats. */
error_reporting(E_ALL);
ini_set('display_errors', '1');
if (!defined('ABSPATH')) define('ABSPATH', dirname(__DIR__) . '/');
if (!defined('MINUTE_IN_SECONDS')) define('MINUTE_IN_SECONDS', 60);
if (!defined('HOUR_IN_SECONDS')) define('HOUR_IN_SECONDS', 3600);
$GLOBALS['qcr_options'] = ['gmt_offset' => 0, 'timezone_string' => ''];
$GLOBALS['qcr_fail'] = 0;
$GLOBALS['qcr_pass'] = 0;

function add_action(...$args) {}
function add_filter(...$args) {}
function register_activation_hook(...$args) {}
function register_deactivation_hook(...$args) {}
function get_option($name, $default = false) { return array_key_exists($name, $GLOBALS['qcr_options']) ? $GLOBALS['qcr_options'][$name] : $default; }
function update_option($name, $value, $autoload = null) { $old = $GLOBALS['qcr_options'][$name] ?? null; $GLOBALS['qcr_options'][$name] = $value; return $old !== $value; }
function delete_option($name) { if (!array_key_exists($name, $GLOBALS['qcr_options'])) return false; unset($GLOBALS['qcr_options'][$name]); return true; }
function delete_transient($name) { return true; }
function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
function wp_cache_delete(...$args) { return true; }
function current_time($type = 'mysql', $gmt = false) { return gmdate('Y-m-d H:i:s'); }

class QcrQueueDb {
    public $prefix = 'wp_';
    public $options = 'wp_options';
    public $rows = [];
    public $last_error = '';
    private $prepared_args = [];
    public function esc_like($value) { return addcslashes((string) $value, '_%\\'); }
    public function prepare($query, ...$args) { $this->prepared_args = $args; return $query; }
    public function get_var($query) {
        $args = $this->prepared_args;
        if (stripos($query, 'SHOW TABLES LIKE') !== false) return 'wp_evazar_import_queue';
        if (stripos($query, "SELECT COUNT(*) FROM `wp_evazar_import_queue` WHERE status='processing'") !== false) {
            return count(array_filter($this->rows, static fn($r) => $r['status'] === 'processing'));
        }
        if (stripos($query, "SELECT MIN(claimed_at) FROM `wp_evazar_import_queue` WHERE status='processing'") !== false) {
            $values = array_values(array_filter(array_map(static fn($r) => $r['status'] === 'processing' ? $r['claimed_at'] : null, $this->rows)));
            sort($values);
            return $values[0] ?? null;
        }
        return null;
    }
    public function get_results($query) {
        $args = $this->prepared_args;
        $cutoff = (string) ($args[0] ?? '');
        $limit = max(1, (int) ($args[1] ?? 1000));
        $rows = [];
        foreach ($this->rows as $row) {
            if ($row['status'] === 'processing' && $row['claimed_at'] !== null && $row['claimed_at'] < $cutoff) $rows[] = $row;
        }
        usort($rows, static fn($a, $b) => strcmp($a['claimed_at'], $b['claimed_at']));
        return array_map(static fn($r) => (object) $r, array_slice($rows, 0, $limit));
    }
    public function query($query) {
        $args = $this->prepared_args;
        if (strpos($query, "UPDATE `wp_evazar_import_queue` SET status='pending'") !== false && count($args) >= 8) {
            [$new_retries, $error_log, $last_error_at, $next_attempt_at, $id, $token, $claimed_at, $cutoff] = $args;
            foreach ($this->rows as &$row) {
                if ((int) $row['id'] !== (int) $id) continue;
                if ($row['status'] !== 'processing' || (string) $row['claim_token'] !== (string) $token || (string) $row['claimed_at'] !== (string) $claimed_at || !($row['claimed_at'] < $cutoff)) return 0;
                $row['status'] = 'pending';
                $row['retries'] = (int) $new_retries;
                $row['error_code'] = 'STALE_CLAIM';
                $row['error_log'] = (string) $error_log;
                $row['last_error_at'] = (string) $last_error_at;
                $row['next_attempt_at'] = (string) $next_attempt_at;
                $row['claim_token'] = '';
                $row['claimed_at'] = null;
                unset($row);
                return 1;
            }
            unset($row);
            return 0;
        }
        return false;
    }
}
$GLOBALS['wpdb'] = new QcrQueueDb();

require_once dirname(__DIR__) . '/queue-manager.php';

function qcr_check($label, $passed) {
    echo ($passed ? 'PASS' : 'FAIL') . ' - ' . $label . "\n";
    if ($passed) $GLOBALS['qcr_pass']++; else $GLOBALS['qcr_fail']++;
}

$table = 'wp_evazar_import_queue';
$old_time = gmdate('Y-m-d H:i:s', time() - 22 * MINUTE_IN_SECONDS);
$recent_time = gmdate('Y-m-d H:i:s', time() - 3 * MINUTE_IN_SECONDS);

// Exact user scenario: first 200 were abandoned 17+ minutes ago; the next run must
// recover those claims before it can claim another batch, keeping processing at 200.
for ($i = 1; $i <= 200; $i++) {
    $GLOBALS['wpdb']->rows[$i] = ['id' => $i, 'status' => 'processing', 'retries' => 0, 'claim_token' => 'first-run', 'claimed_at' => $old_time, 'error_code' => '', 'error_log' => '', 'last_error_at' => null, 'next_attempt_at' => null];
}
for ($i = 201; $i <= 400; $i++) {
    $GLOBALS['wpdb']->rows[$i] = ['id' => $i, 'status' => 'pending', 'retries' => 0, 'claim_token' => '', 'claimed_at' => null, 'error_code' => '', 'error_log' => '', 'last_error_at' => null, 'next_attempt_at' => null];
}
$first_cycle_recovery = evazar_queue_recover_stale_processing_claims($table);
$first_cycle_guard = evazar_queue_guard_previous_processing_claims($table, $first_cycle_recovery['recovered']);
if (empty($first_cycle_guard['blocked'])) {
    foreach (range(201, 400) as $id) {
        $GLOBALS['wpdb']->rows[$id]['status'] = 'processing';
        $GLOBALS['wpdb']->rows[$id]['claim_token'] = 'next-run';
        $GLOBALS['wpdb']->rows[$id]['claimed_at'] = current_time('mysql');
    }
}
$processing_after_next_claim = count(array_filter($GLOBALS['wpdb']->rows, static fn($r) => $r['status'] === 'processing'));
qcr_check('17-minute-old first batch is recovered before the next batch is claimed', $first_cycle_recovery['recovered'] === 200 && empty($first_cycle_guard['blocked']));
qcr_check('the simulated next 200-product Claim leaves exactly 200 processing, not 400', $processing_after_next_claim === 200);

// Reset to the mixed 200-stale + 200-recent state produced by the reported two-run incident.
$GLOBALS['wpdb']->rows = [];
for ($i = 1; $i <= 200; $i++) {
    $GLOBALS['wpdb']->rows[$i] = ['id' => $i, 'status' => 'processing', 'retries' => 0, 'claim_token' => 'run-first', 'claimed_at' => $old_time, 'error_code' => '', 'error_log' => '', 'last_error_at' => null, 'next_attempt_at' => null];
}
for ($i = 201; $i <= 400; $i++) {
    $GLOBALS['wpdb']->rows[$i] = ['id' => $i, 'status' => 'processing', 'retries' => 0, 'claim_token' => 'run-second', 'claimed_at' => $recent_time, 'error_code' => '', 'error_log' => '', 'last_error_at' => null, 'next_attempt_at' => null];
}

$recovery1 = evazar_queue_recover_stale_processing_claims($table);
qcr_check('the previous 200-product claim older than the lease is recovered', $recovery1['recovered'] === 200);
qcr_check('recovered rows return to pending with a cleared claim and a retry delay', $GLOBALS['wpdb']->rows[1]['status'] === 'pending' && $GLOBALS['wpdb']->rows[1]['claim_token'] === '' && $GLOBALS['wpdb']->rows[1]['claimed_at'] === null && $GLOBALS['wpdb']->rows[1]['error_code'] === 'STALE_CLAIM' && $GLOBALS['wpdb']->rows[1]['retries'] === 1 && $GLOBALS['wpdb']->rows[1]['next_attempt_at'] > current_time('mysql'));
qcr_check('the recent second claim is not retried early', $GLOBALS['wpdb']->rows[201]['status'] === 'processing' && $GLOBALS['wpdb']->rows[201]['claim_token'] === 'run-second');
$guard1 = evazar_queue_guard_previous_processing_claims($table, $recovery1['recovered']);
qcr_check('the guard blocks another 200-product Claim while the recent 200 remain processing', !empty($guard1['blocked']) && $guard1['processing_count'] === 200);
qcr_check('guard does not mutate the remaining live/recent claim', $GLOBALS['wpdb']->rows[201]['status'] === 'processing' && $GLOBALS['wpdb']->rows[201]['retries'] === 0);

// Simulate the next scheduler cycle after the second Claim also became stale.
$older_second_time = gmdate('Y-m-d H:i:s', time() - 22 * MINUTE_IN_SECONDS);
for ($i = 201; $i <= 400; $i++) $GLOBALS['wpdb']->rows[$i]['claimed_at'] = $older_second_time;
$recovery2 = evazar_queue_recover_stale_processing_claims($table);
$guard2 = evazar_queue_guard_previous_processing_claims($table, $recovery2['recovered']);
qcr_check('the next safe cycle recovers the second abandoned 200-product claim', $recovery2['recovered'] === 200);
qcr_check('after all abandoned claims are recovered, the guard permits a fresh Claim', empty($guard2['blocked']) && $guard2['processing_count'] === 0);
qcr_check('no row remains permanently processing after both abandoned generations are recovered', count(array_filter($GLOBALS['wpdb']->rows, static fn($r) => $r['status'] === 'processing')) === 0);

$source = file_get_contents(dirname(__DIR__) . '/queue-manager.php');
$core = file_get_contents(dirname(__DIR__) . '/evazar-core.php');
$guard_pos = strpos($source, '$previous_claim_guard = evazar_queue_guard_previous_processing_claims');
$claim_pos = strpos($source, '$claim_sql = "UPDATE `$table_name` SET status=\'processing\'');
$logic_start = strpos($source, 'function evazar_cron_worker_logic');
$recovery_pos = strpos($source, '$queue_stale_recovery = evazar_queue_recover_stale_processing_claims', $logic_start);
$mode_check_pos = strpos($source, '$ai_enabled = get_option(\'evazar_ai_enabled\'', $logic_start);
qcr_check('stale-claim recovery runs before AI/Worker early returns', $recovery_pos !== false && $mode_check_pos !== false && $recovery_pos < $mode_check_pos);
qcr_check('the processing guard runs before the SQL that claims a new batch', $guard_pos !== false && $claim_pos !== false && $guard_pos < $claim_pos);
qcr_check('run-lock heartbeat is refreshed in source, parallel Gemini, and serial Gemini loops', substr_count($source, 'evazar_queue_heartbeat_run_lock();') >= 3);
qcr_check('plugin version is 2.9.84.96', strpos($core, '* Version: 2.9.84.96') !== false);

fwrite(STDOUT, "\nRESULT: {$GLOBALS['qcr_pass']} passed, {$GLOBALS['qcr_fail']} failed.\n");
if ($GLOBALS['qcr_fail'] > 0) exit(1);
