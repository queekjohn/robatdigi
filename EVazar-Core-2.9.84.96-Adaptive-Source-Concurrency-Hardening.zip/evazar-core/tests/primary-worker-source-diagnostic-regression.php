<?php
/** Regression test: preserve the real upstream diagnosis and do not cooldown/fail over for source-scoped 429. */
error_reporting(E_ALL);
ini_set('display_errors', '1');
if (!defined('ABSPATH')) define('ABSPATH', __DIR__ . '/');
if (!defined('DAY_IN_SECONDS')) define('DAY_IN_SECONDS', 86400);
if (!defined('HOUR_IN_SECONDS')) define('HOUR_IN_SECONDS', 3600);
$GLOBALS['pws_options'] = [
    'evazar_cf_worker_urls' => 'https://source-diagnostic-test.workers.dev',
    'evazar_cf_worker_daily_budget' => 85000,
];
$GLOBALS['pws_transients'] = [];
$GLOBALS['pws_requests'] = [];
$GLOBALS['pws_checks'] = 0;
$GLOBALS['pws_force_transport_error'] = false;
$GLOBALS['pws_override_response'] = null;

function add_action(...$args) {}
function add_filter(...$args) {}
function get_option($key, $default = false) { return array_key_exists($key, $GLOBALS['pws_options']) ? $GLOBALS['pws_options'][$key] : $default; }
function update_option($key, $value, $autoload = null) { $GLOBALS['pws_options'][$key] = $value; return true; }
function delete_option($key) { if (!array_key_exists($key, $GLOBALS['pws_options'])) return false; unset($GLOBALS['pws_options'][$key]); return true; }
function wp_generate_uuid4() { static $n = 0; return '00000000-0000-4000-8000-' . str_pad((string) (++$n), 12, '0', STR_PAD_LEFT); }
function add_option($key, $value, $deprecated = '', $autoload = 'yes') {
    if (array_key_exists($key, $GLOBALS['pws_options'])) return false;
    $GLOBALS['pws_options'][$key] = $value;
    return true;
}
function wp_parse_url($url, $component = -1) { return parse_url($url, $component); }
function esc_url_raw($url) { return (string)$url; }
function sanitize_key($value) { return strtolower(preg_replace('/[^a-z0-9_\-]/', '', (string)$value)); }
function sanitize_text_field($value) { return trim(strip_tags((string)$value)); }
function absint($value) { return abs((int)$value); }
function wp_cache_delete(...$args) { return true; }
function get_transient($key) { return $GLOBALS['pws_transients'][$key] ?? false; }
function set_transient($key, $value, $expiration = 0) { $GLOBALS['pws_transients'][$key] = $value; return true; }
function trailingslashit($value) { return rtrim((string)$value, '/') . '/'; }
function add_query_arg($args, $url) { return $url . '?' . http_build_query($args); }
function wp_remote_retrieve_response_code($response) { return (int)($response['response']['code'] ?? 0); }
function wp_remote_retrieve_header($response, $header) {
    foreach (($response['headers'] ?? []) as $key => $value) if (strtolower((string)$key) === strtolower((string)$header)) return $value;
    return '';
}
function wp_remote_retrieve_body($response) { return (string)($response['body'] ?? ''); }
function wp_remote_request($url, $args = []) {
    $GLOBALS['pws_requests'][] = ['url'=>$url, 'args'=>$args];
    if (!empty($GLOBALS['pws_force_transport_error'])) return new WP_Error('http_request_failed', 'simulated timeout');
    if (is_array($GLOBALS['pws_override_response'] ?? null)) return $GLOBALS['pws_override_response'];
    return [
        'response' => ['code' => 429],
        'headers' => [
            'X-Evazar-Error-Scope' => 'source',
            'X-Evazar-Worker-Version' => '1.13.25',
            'Retry-After' => '30',
            'Content-Type' => 'application/json',
        ],
        'body' => json_encode([
            'success' => false,
            'error' => 'source_rate_limited',
            'message' => 'منبع دیجی‌کالا پاسخ قابل‌استفاده نداد؛ وضعیت‌ها: v2=429، v1=not-attempted (v2 rate limited).',
            'upstream_status_v2' => 429,
            'upstream_status_v1' => 0,
            'upstream_error_v2' => '',
            'upstream_error_v1' => '',
            'worker_version' => '1.13.25',
        ], JSON_UNESCAPED_UNICODE),
    ];
}
class PwsWpdb {
    public $options = 'wp_options';
    public $prepared_args = [];
    public function esc_like($value) { return addcslashes((string)$value, '_%\\'); }
    public function prepare($query, ...$args) { $this->prepared_args = $args; return $query; }
    public function query($query) {
        if (stripos($query, 'DELETE FROM wp_options') === 0 && count($this->prepared_args) >= 2) {
            [$key, $value] = $this->prepared_args;
            if (($GLOBALS['pws_options'][$key] ?? null) === $value) { unset($GLOBALS['pws_options'][$key]); return 1; }
            return 0;
        }
        return 0;
    }
}
$GLOBALS['wpdb'] = new PwsWpdb();
if (!class_exists('WP_Error')) {
    class WP_Error {
        private $code; private $message; private $data;
        public function __construct($code, $message = '', $data = null) { $this->code = $code; $this->message = $message; $this->data = $data; }
        public function get_error_code() { return $this->code; }
        public function get_error_message($code = '') { return $this->message; }
        public function get_error_data($code = '') { return $this->data; }
    }
}
function is_wp_error($value) { return $value instanceof WP_Error; }
function pws_check($name, $ok) {
    $GLOBALS['pws_checks']++;
    echo ($ok ? 'PASS' : 'FAIL') . ': ' . $name . "\n";
    if (!$ok) exit(1);
}
// Minimal CLI compatibility shims for this regression harness; production WordPress provides these.
if (!function_exists('mb_strlen')) {
    function mb_strlen($value, $encoding = null) {
        $length = iconv_strlen((string) $value, $encoding ?: 'UTF-8');
        return ($length === false) ? strlen((string) $value) : $length;
    }
}
if (!function_exists('mb_substr')) {
    function mb_substr($value, $start, $length = null, $encoding = null) {
        $result = iconv_substr((string) $value, (int) $start, $length === null ? iconv_strlen((string) $value, $encoding ?: 'UTF-8') : (int) $length, $encoding ?: 'UTF-8');
        return ($result === false) ? substr((string) $value, (int) $start, $length) : $result;
    }
}
if (!function_exists('wp_strip_all_tags')) {
    function wp_strip_all_tags($text, $remove_breaks = false) {
        $text = strip_tags((string) $text);
        if ($remove_breaks) $text = preg_replace('/[\r\n\t ]+/', ' ', $text);
        return trim($text);
    }
}
require dirname(__DIR__) . '/importer.php';

$response = evazar_primary_worker_request('', ['dkp' => '12345678'], ['timeout' => 8], 'GET', 'import_source');
$diag = evazar_primary_worker_last_diagnostic();
pws_check('source-scoped upstream 429 is returned to the importer without being treated as a Worker 429', !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 429 && ($diag['error_scope'] ?? '') === 'source');
pws_check('diagnostic retains the specific source error code', ($diag['source_error_code'] ?? '') === 'source_rate_limited' && ($diag['code'] ?? '') === 'worker_upstream_source_rate_limited');
pws_check('diagnostic retains exact upstream v2/v1 status values', (int)($diag['upstream_status_v2'] ?? 0) === 429 && (int)($diag['upstream_status_v1'] ?? -1) === 0);
pws_check('diagnostic retains Worker version and Retry-After guidance', ($diag['worker_version'] ?? '') === '1.13.25' && (int)($diag['retry_after_seconds'] ?? 0) === 30);
pws_check('upstream source failure does not set Worker cooldown', count($GLOBALS['pws_transients']) === 0);
pws_check('only one Worker is called for a source-scoped failure', count($GLOBALS['pws_requests']) === 1);
$source_lock_key = evazar_primary_worker_request_lock_option_name('https://source-diagnostic-test.workers.dev');

// Regression for WP/Requests responses whose header values are arrays.
$GLOBALS['pws_override_response'] = [
    'response' => ['code' => 503],
    'headers' => [
        'X-Evazar-Error-Scope' => ['source'],
        'X-Evazar-Worker-Version' => ['1.13.27'],
        'Content-Type' => ['application/json; charset=utf-8'],
    ],
    'body' => json_encode([
        'success' => false, 'error' => 'source_server_error',
        'message' => 'Digikala upstream v2 returned HTTP 502.',
        'upstream_status_v2' => 502, 'upstream_status_v1' => 0,
        'worker_version' => '1.13.27',
    ]),
];
unset($GLOBALS['pws_options'][evazar_primary_worker_counter_key('https://source-diagnostic-test.workers.dev')]);
$request_count_before_array_headers = count($GLOBALS['pws_requests']);
$array_header_response = evazar_primary_worker_request('', ['dkp' => '22027358'], ['timeout' => 25], 'GET', 'import_source');
$array_header_diag = evazar_primary_worker_last_diagnostic();
pws_check('serial dispatcher reads array-valued source scope as source, not Array', !is_wp_error($array_header_response) && ($array_header_diag['error_scope'] ?? '') === 'source');
pws_check('serial dispatcher preserves array-valued Worker version and upstream diagnostics', ($array_header_diag['worker_version'] ?? '') === '1.13.27' && (int)($array_header_diag['upstream_status_v2'] ?? 0) === 502 && (int)($array_header_diag['upstream_status_v1'] ?? -1) === 0);
pws_check('serial source_server_error over Worker HTTP 503 is not cooled down or retried against another Worker', count($GLOBALS['pws_requests']) === $request_count_before_array_headers + 1 && get_transient(evazar_primary_worker_cooldown_key('https://source-diagnostic-test.workers.dev', 'import_source')) === false);

// Worker 1.13.27 public-page failures carry source diagnostics but omit Error-Scope.
// Core must identify these as Digikala source failures, not cool down every Worker.
$source_page_workers = [
    'https://source-page-a.workers.dev',
    'https://source-page-b.workers.dev',
];
$GLOBALS['pws_options']['evazar_cf_worker_urls'] = implode("\n", $source_page_workers);
$GLOBALS['pws_options']['evazar_cf_worker_url'] = '';
foreach ($source_page_workers as $url) unset($GLOBALS['pws_options'][evazar_primary_worker_counter_key($url)]);
$GLOBALS['pws_override_response'] = [
    'response' => ['code' => 502],
    'headers' => [
        'X-Evazar-Worker-Version' => '1.13.27',
        'X-Evazar-Source-Path' => '/search/electronic-devices/',
        'X-Evazar-Source-Upstream-Status' => '502',
        'X-Evazar-Source-Upstream-Type' => 'application/json',
        'X-Evazar-Source-Fetch-Ms' => '1240',
        'X-Evazar-Source-Redirects' => '1',
        'Content-Type' => 'application/json',
    ],
    'body' => json_encode(['success' => false, 'message' => 'Digikala source page fetch failed (502).', 'upstream_status' => 502, 'upstream_host' => 'www.digikala.com', 'redirect_count' => 1, 'fetch_ms' => 1240]),
];
$request_count_before_source_page = count($GLOBALS['pws_requests']);
$source_page_response = evazar_primary_worker_request('', ['source_page' => '/search/electronic-devices/'], ['timeout' => 15], 'GET', 'import_source');
$source_page_diag = evazar_primary_worker_last_diagnostic();
pws_check('Worker 1.13.27 public-page 502 with signed source headers is classified as a Digikala source error', !is_wp_error($source_page_response) && ($source_page_diag['error_scope'] ?? '') === 'source' && ($source_page_diag['code'] ?? '') === 'worker_upstream_source_http_502');
pws_check('public-page source diagnostic retains upstream status, host, path, fetch time and Worker version', (int)($source_page_diag['source_upstream_status'] ?? 0) === 502 && ($source_page_diag['source_upstream_host'] ?? '') === 'www.digikala.com' && ($source_page_diag['source_path'] ?? '') === '/search/electronic-devices/' && (int)($source_page_diag['source_fetch_ms'] ?? 0) === 1240 && ($source_page_diag['worker_version'] ?? '') === '1.13.27');
pws_check('public-page source 502 is not fanned out to a second Worker', count($GLOBALS['pws_requests']) === $request_count_before_source_page + 1 && ($source_page_diag['attempted'] ?? 0) === 1);
pws_check('public-page source 502 does not create Worker cooldowns', get_transient(evazar_primary_worker_cooldown_key($source_page_workers[0], 'import_source')) === false && get_transient(evazar_primary_worker_cooldown_key($source_page_workers[1], 'import_source')) === false);
evazar_taxonomy_source_trace_begin();
evazar_primary_worker_diag_set($source_page_diag);
evazar_taxonomy_source_trace_record('public_page', $source_page_response, false, (string) ($GLOBALS['pws_override_response']['body'] ?? ''));
$source_page_trace = evazar_taxonomy_source_trace_result('', 'public_page');
$source_page_trace_attempt = $source_page_trace['diagnostic']['attempts'][0] ?? [];
pws_check('taxonomy retry event preserves the source-page Worker version, upstream status, host, path and timing', ($source_page_trace['state'] ?? '') === 'retry' && ($source_page_trace_attempt['worker_version'] ?? '') === '1.13.27' && (int)($source_page_trace_attempt['source_upstream_status'] ?? 0) === 502 && ($source_page_trace_attempt['source_upstream_host'] ?? '') === 'www.digikala.com' && ($source_page_trace_attempt['source_path'] ?? '') === '/search/electronic-devices/' && (int)($source_page_trace_attempt['source_fetch_ms'] ?? 0) === 1240);

// Legacy taxonomy API proxy responses use X-Evazar-Upstream-* rather than Source-* headers.
foreach ($source_page_workers as $url) {
    unset($GLOBALS['pws_options'][evazar_primary_worker_counter_key($url)]);
    unset($GLOBALS['pws_options'][evazar_primary_worker_request_lock_option_name($url)]);
}
$GLOBALS['pws_override_response'] = [
    'response' => ['code' => 502],
    'headers' => [
        'X-Evazar-Worker-Version' => '1.13.27',
        'X-Evazar-Upstream-Status' => '502',
        'X-Evazar-Upstream-Host' => 'api.digikala.com',
        'X-Evazar-Upstream-Error' => 'upstream_gateway_error',
        'Content-Type' => 'application/json',
    ],
    'body' => json_encode(['message' => 'Digikala API returned HTTP 502.']),
];
$request_count_before_api = count($GLOBALS['pws_requests']);
$taxonomy_api_response = evazar_primary_worker_request('', ['route' => '/v1/categories/electronic-devices/search/'], ['timeout' => 12], 'GET', 'import_source');
$taxonomy_api_diag = evazar_primary_worker_last_diagnostic();
pws_check('legacy taxonomy API 502 with Digikala upstream headers is classified as a source error', !is_wp_error($taxonomy_api_response) && ($taxonomy_api_diag['error_scope'] ?? '') === 'source' && ($taxonomy_api_diag['code'] ?? '') === 'worker_upstream_source_upstream_gateway_error');
pws_check('legacy taxonomy API diagnostic identifies api.digikala.com and upstream 502', ($taxonomy_api_diag['source_upstream_host'] ?? '') === 'api.digikala.com' && (int)($taxonomy_api_diag['source_upstream_status'] ?? 0) === 502);
pws_check('legacy taxonomy API source error does not fan out or cool down healthy Workers', count($GLOBALS['pws_requests']) === $request_count_before_api + 1 && get_transient(evazar_primary_worker_cooldown_key($source_page_workers[0], 'import_source')) === false && get_transient(evazar_primary_worker_cooldown_key($source_page_workers[1], 'import_source')) === false);

// A bare Cloudflare/Worker 502 without source provenance must still trigger Worker failover.
foreach ($source_page_workers as $url) {
    unset($GLOBALS['pws_options'][evazar_primary_worker_counter_key($url)]);
    unset($GLOBALS['pws_options'][evazar_primary_worker_request_lock_option_name($url)]);
    unset($GLOBALS['pws_transients'][evazar_primary_worker_cooldown_key($url, 'import_source')]);
}
$GLOBALS['pws_override_response'] = [
    'response' => ['code' => 502],
    'headers' => ['X-Evazar-Worker-Version' => '1.13.27', 'Content-Type' => 'text/plain'],
    'body' => 'Cloudflare Bad Gateway',
];
$request_count_before_bare_502 = count($GLOBALS['pws_requests']);
$bare_502_response = evazar_primary_worker_request('', ['source_page' => '/search/electronic-devices/'], ['timeout' => 15], 'GET', 'import_source');
$bare_502_diag = evazar_primary_worker_last_diagnostic();
pws_check('bare 502 without upstream provenance remains a Worker failure and continues pool failover', !is_wp_error($bare_502_response) && ($bare_502_diag['code'] ?? '') === 'worker_pool_exhausted_http_errors' && (int)($bare_502_diag['attempted'] ?? 0) === 2 && count($GLOBALS['pws_requests']) === $request_count_before_bare_502 + 2);
pws_check('true Worker 502 responses still place only the failed Worker URLs into cooldown', get_transient(evazar_primary_worker_cooldown_key($source_page_workers[0], 'import_source')) !== false && get_transient(evazar_primary_worker_cooldown_key($source_page_workers[1], 'import_source')) !== false);
$GLOBALS['pws_override_response'] = null;
foreach ($source_page_workers as $url) {
    unset($GLOBALS['pws_transients'][evazar_primary_worker_cooldown_key($url, 'import_source')]);
    unset($GLOBALS['pws_options'][evazar_primary_worker_counter_key($url)]);
    unset($GLOBALS['pws_options'][evazar_primary_worker_request_lock_option_name($url)]);
}
$GLOBALS['pws_options']['evazar_cf_worker_urls'] = 'https://source-diagnostic-test.workers.dev';
$GLOBALS['pws_options']['evazar_cf_worker_url'] = '';

pws_check('serial source request releases its shared Worker lease after the HTTP response', !isset($GLOBALS['pws_options'][$source_lock_key]));
unset($GLOBALS['pws_options'][evazar_primary_worker_counter_key('https://source-diagnostic-test.workers.dev')]);
$GLOBALS['pws_force_transport_error'] = true;
$timeout_response = evazar_primary_worker_request('', ['dkp' => '12345681'], ['timeout' => 8], 'GET', 'import_source');
$timeout_token = get_option($source_lock_key, '');
$timeout_diag = evazar_primary_worker_last_diagnostic();
pws_check('serial transport timeout retains its uncertain Worker lease instead of releasing it early', is_wp_error($timeout_response) && $timeout_token !== '' && strpos($timeout_token, '|') !== false);
unset($GLOBALS['pws_transients'][evazar_primary_worker_cooldown_key('https://source-diagnostic-test.workers.dev', 'import_source')]);
$requests_before_busy_retry = count($GLOBALS['pws_requests']);
$busy_after_timeout = evazar_primary_worker_request('', ['dkp' => '12345682'], ['timeout' => 8], 'GET', 'import_source');
$busy_after_timeout_diag = evazar_primary_worker_last_diagnostic();
pws_check('a second queue cannot dispatch to the same Worker while the timed-out request may still be running', is_wp_error($busy_after_timeout) && ($busy_after_timeout_diag['code'] ?? '') === 'worker_pool_busy' && count($GLOBALS['pws_requests']) === $requests_before_busy_retry);
pws_check('uncertain Worker lease uses a conservative minimum 180-second stale window', evazar_primary_worker_request_lock_stale_after(8) === 180);
$GLOBALS['pws_force_transport_error'] = false;
$GLOBALS['pws_options'][$source_lock_key] = (time() - 181) . '|expired-timeout-token';
$expired_timeout_token = evazar_primary_worker_acquire_request_lock('https://source-diagnostic-test.workers.dev', 8);
pws_check('uncertain timeout lease becomes reclaimable only after the conservative stale window', is_string($expired_timeout_token) && $expired_timeout_token !== '');
evazar_primary_worker_release_request_lock('https://source-diagnostic-test.workers.dev', $expired_timeout_token);
$held_token = evazar_primary_worker_acquire_request_lock('https://source-diagnostic-test.workers.dev', 8);
pws_check('a second PHP request cannot acquire a Worker already leased by another queue', is_string($held_token) && $held_token !== '' && evazar_primary_worker_acquire_request_lock('https://source-diagnostic-test.workers.dev', 8) === false);
$blocked_response = evazar_primary_worker_request('', ['dkp' => '12345679'], ['timeout' => 8], 'GET', 'import_source');
$blocked_diag = evazar_primary_worker_last_diagnostic();
pws_check('when every configured primary Worker is leased, dispatch returns a retryable worker_pool_busy signal without sending HTTP', is_wp_error($blocked_response) && ($blocked_diag['code'] ?? '') === 'worker_pool_busy' && (int) ($blocked_diag['attempted'] ?? -1) === 0 && (int) ($blocked_diag['busy_skipped'] ?? 0) === 1);
$GLOBALS['pws_options']['evazar_cf_worker_urls'] = "https://source-diagnostic-busy.workers.dev\nhttps://source-diagnostic-cooldown.workers.dev";
$GLOBALS['pws_options']['evazar_cf_worker_url'] = '';
$busy_mixed_key = evazar_primary_worker_request_lock_option_name('https://source-diagnostic-busy.workers.dev');
$busy_mixed_token = evazar_primary_worker_acquire_request_lock('https://source-diagnostic-busy.workers.dev', 8);
evazar_primary_worker_set_cooldown('https://source-diagnostic-cooldown.workers.dev', 60, 'worker_http_503', 503, 'import_source');
$mixed_response = evazar_primary_worker_request('', ['dkp' => '12345680'], ['timeout' => 8], 'GET', 'import_source');
$mixed_diag = evazar_primary_worker_last_diagnostic();
pws_check('a mixed busy-plus-cooldown pool is not mislabeled as all workers in cooldown', is_wp_error($mixed_response) && ($mixed_diag['code'] ?? '') === 'worker_pool_unavailable' && (int) ($mixed_diag['busy_skipped'] ?? 0) === 1 && (int) ($mixed_diag['cooldown_skipped'] ?? 0) === 1 && (int) ($mixed_diag['attempted'] ?? -1) === 0);
evazar_primary_worker_release_request_lock('https://source-diagnostic-busy.workers.dev', $busy_mixed_token);
unset($GLOBALS['pws_transients'][evazar_primary_worker_cooldown_key('https://source-diagnostic-cooldown.workers.dev', 'import_source')]);
$GLOBALS['pws_options']['evazar_cf_worker_urls'] = 'https://source-diagnostic-test.workers.dev';
$GLOBALS['pws_options'][$source_lock_key] = 'newer-owner-token';
pws_check('an old request cannot release a replacement Worker lease', evazar_primary_worker_release_request_lock('https://source-diagnostic-test.workers.dev', $held_token) === false && get_option($source_lock_key, '') === 'newer-owner-token');
$GLOBALS['pws_options'][$source_lock_key] = (time() - 2000) . '|stale-worker-token';
$reclaimed_token = evazar_primary_worker_acquire_request_lock('https://source-diagnostic-test.workers.dev', 8);
pws_check('an abandoned source Worker lease is reclaimed only after its timeout window', is_string($reclaimed_token) && $reclaimed_token !== '' && $reclaimed_token !== (time() - 2000) . '|stale-worker-token');
evazar_primary_worker_release_request_lock('https://source-diagnostic-test.workers.dev', $reclaimed_token);
pws_check('visible diagnostic includes the actual v2 429 and skipped v1 fallback', strpos((string)($diag['detail'] ?? ''), 'v2=429') !== false && strpos((string)($diag['detail'] ?? ''), 'not-attempted') !== false);

// Taxonomy preflight distinguishes a transient Worker/source failure from a valid empty response.
evazar_taxonomy_source_trace_begin();
$temporary_diag = array_merge($diag, ['code' => 'worker_upstream_source_rate_limited', 'http_code' => 429, 'retry_after_seconds' => 30, 'error_scope' => 'source']);
evazar_primary_worker_diag_set($temporary_diag);
$temporary_error = new WP_Error('worker_upstream_source_rate_limited', 'temporary source failure');
evazar_taxonomy_source_trace_record('api', $temporary_error, false, '');
$temporary_result = evazar_taxonomy_source_trace_result('', 'api_and_page_empty');
pws_check('taxonomy source trace classifies Worker 429 as retry, never as terminal no-content', ($temporary_result['state'] ?? '') === 'retry' && ($temporary_result['retry_kind'] ?? '') === 'source' && (int) ($temporary_result['retry_after_seconds'] ?? 0) >= 30);
pws_check('taxonomy source retry diagnostics retain only bounded attempt metadata and no response body', !empty($temporary_result['diagnostic']['attempts']) && !array_key_exists('body', $temporary_result['diagnostic']));

// A syntactically valid, successful upstream response with no usable extracted text is terminal no-content.
evazar_taxonomy_source_trace_begin();
$valid_diag = array_merge($diag, ['code' => 'worker_http_success', 'http_code' => 200, 'retry_after_seconds' => 0, 'error_scope' => '']);
evazar_primary_worker_diag_set($valid_diag);
evazar_taxonomy_source_trace_record('api', ['response' => ['code' => 200], 'headers' => [], 'body' => '{}'], true, '{}');
$empty_result = evazar_taxonomy_source_trace_result('', 'api_and_page_empty');
pws_check('successful valid source response without usable text is classified as no_content', ($empty_result['state'] ?? '') === 'no_content');

// A missing primary Worker pool is a configuration retry, not a permanently skipped taxonomy term.
$GLOBALS['pws_options']['evazar_cf_worker_urls'] = '';
$GLOBALS['pws_options']['evazar_cf_worker_url'] = '';
$GLOBALS['pws_options']['evazar_image_cdn_domain'] = 'not-a-valid-worker-url';
evazar_taxonomy_source_trace_begin();
$missing_worker_result = evazar_taxonomy_source_trace_result('', 'api_and_page_empty');
pws_check('unconfigured source Worker pool yields a one-hour configuration retry', ($missing_worker_result['state'] ?? '') === 'retry' && ($missing_worker_result['retry_kind'] ?? '') === 'configuration' && (int) ($missing_worker_result['retry_after_seconds'] ?? 0) === 3600);

// Regression for Digikala discovery category+brand payloads: seo.content/category_brand.description
// may be empty while seo.description and brand.description contain usable source material.
$taxonomy_api_fixture = [
    'data' => [
        'category' => [
            'code' => 'men-analouge-watches',
            'title_fa' => 'ساعت عقربه‌ای مردانه',
        ],
        'brand' => [
            'code' => 'valentino-rudy',
            'title_fa' => 'والنتینو رودی',
            'description' => '<p style="text-align: justify;">برند &laquo;والنتینو رودی&raquo; یک برند شناخته‌شده در حوزه ساعت و اکسسوری است. این برند مجموعه‌ای از ساعت‌های مردانه با طراحی‌های متنوع و مشخصات متفاوت عرضه می‌کند. خریداران می‌توانند با توجه به طراحی، نوع موتور، جنس بند و ویژگی‌های صفحه ساعت انتخاب کنند.</p>',
        ],
        'category_brand' => ['description' => ''],
        'seo' => [
            'content' => null,
            'content_html' => null,
            'description' => 'خرید اینترنتی و لیست قیمت انواع ساعت عقربه‌ای مردانه والنتینو رودی با بررسی مشخصات و مقایسه مدل‌ها.',
        ],
        'products' => [],
    ],
];
$taxonomy_api_source = evazar_extract_taxonomy_api_source_content($taxonomy_api_fixture);
pws_check('discovery category-brand API fallback combines page SEO description and brand description when full SEO fields are empty', strpos($taxonomy_api_source, 'خرید اینترنتی و لیست قیمت') !== false && strpos($taxonomy_api_source, 'برند «والنتینو رودی»') !== false);
pws_check('taxonomy API description extraction strips HTML and decodes entities before sending source text to Gemini', strpos($taxonomy_api_source, '<p') === false && strpos($taxonomy_api_source, '&laquo;') === false && strpos($taxonomy_api_source, 'والنتینو رودی') !== false);
pws_check('taxonomy API normalization preserves paragraph boundaries instead of concatenating separate brand paragraphs', strpos($taxonomy_api_source, "\n") !== false);
pws_check('taxonomy API fallback keeps explicit source labels for page and brand descriptions', strpos($taxonomy_api_source, 'توضیحات سئوی صفحه:') !== false && strpos($taxonomy_api_source, 'توضیحات برند:') !== false);

$priority_fixture = $taxonomy_api_fixture;
$priority_fixture['data']['category_brand']['description'] = '<p>متن کامل و اختصاصی منبع دسته و برند که باید بر سایر توضیحات متادیتا اولویت داشته باشد.</p>';
$priority_text = evazar_extract_taxonomy_api_source_content($priority_fixture);
pws_check('exact category-brand editorial description remains higher priority than SEO metadata and generic brand description', strpos($priority_text, 'متن کامل و اختصاصی منبع دسته و برند') !== false && strpos($priority_text, 'توضیحات برند:') === false);

$full_seo_fixture = $taxonomy_api_fixture;
$full_seo_fixture['data']['seo']['content'] = '<p>محتوای کامل و معتبر سئوی صفحه دسته و برند که در API به‌صورت محتوای اصلی منتشر شده است.</p>';
$full_seo_text = evazar_extract_taxonomy_api_source_content($full_seo_fixture);
pws_check('full seo.content retains precedence and does not append fallback metadata descriptions', strpos($full_seo_text, 'محتوای کامل و معتبر سئوی صفحه') !== false && strpos($full_seo_text, 'توضیحات برند:') === false);

$dedupe_fixture = [
    'data' => [
        'seo' => ['description' => 'این توضیحات مشترک و تکراری برای صفحه برند استفاده شده است.'],
        'brand' => ['description' => '<p>این توضیحات مشترک و تکراری برای صفحه برند استفاده شده است.</p>'],
    ],
];
$dedupe_text = evazar_extract_taxonomy_api_source_content($dedupe_fixture);
pws_check('duplicate or nested API descriptions are not repeated in the composed source', substr_count($dedupe_text, 'این توضیحات مشترک') === 1);
$nested_dedupe_fixture = [
    'data' => [
        'seo' => ['description' => 'جمله کوتاه مشترک درباره ویژگی‌های محصول و برند.'],
        'brand' => ['description' => '<p>جمله کوتاه مشترک درباره ویژگی‌های محصول و برند. این توضیح کامل‌تر برند شامل اطلاعات تکمیلی درباره طراحی، کیفیت ساخت و تنوع محصولات است.</p>'],
    ],
];
$nested_dedupe_text = evazar_extract_taxonomy_api_source_content($nested_dedupe_fixture);
pws_check('a fuller brand description supersedes a shorter SEO sentence when it already contains that sentence', strpos($nested_dedupe_text, 'توضیحات برند:') !== false && strpos($nested_dedupe_text, 'توضیحات سئوی صفحه:') === false);
$category_only_fixture = [
    'data' => ['category' => ['description' => '<p>این دسته شامل مجموعه‌ای از محصولات با ویژگی‌ها و کاربردهای متنوع است که باید هنگام انتخاب بررسی شوند.</p>']],
];
pws_check('category-only API fallback accepts its explicit category description', strpos(evazar_extract_taxonomy_api_source_content($category_only_fixture), 'توضیحات دسته‌بندی:') !== false);
$long_description_fixture = ['data' => ['brand' => ['description' => '<p>' . str_repeat('توضیح معتبر برند و ویژگی‌های محصولات. ', 900) . '</p>']]];
$long_description_text = evazar_extract_taxonomy_api_source_content($long_description_fixture);
pws_check('composed API source text remains bounded to the 18000-character safety limit', mb_strlen($long_description_text, 'UTF-8') <= 18000);
pws_check('empty or unrelated API payloads still produce no source text', evazar_extract_taxonomy_api_source_content(['data' => ['products' => []]]) === '');

// Exercise the full exact category+brand API fetch path with the live response shape supplied by the user.
$GLOBALS['pws_options']['evazar_cf_worker_urls'] = 'https://taxonomy-api-test.workers.dev';
$GLOBALS['pws_options']['evazar_cf_worker_url'] = '';
$GLOBALS['pws_options']['evazar_cf_worker_cursor'] = 0;
$GLOBALS['pws_requests'] = [];
$GLOBALS['pws_override_response'] = [
    'response' => ['code' => 200],
    'headers' => ['Content-Type' => 'application/json; charset=utf-8'],
    'body' => json_encode($taxonomy_api_fixture, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
];
$taxonomy_full_result = evazar_fetch_taxonomy_source_content('/search/category-men-analouge-watches/valentino-rudy/', 'category');
$taxonomy_full_request_count = count($GLOBALS['pws_requests']);
$taxonomy_full_url = (string) ($GLOBALS['pws_requests'][0]['url'] ?? '');
pws_check('exact category-brand API response now makes the taxonomy source ready without requesting the broken public HTML page', ($taxonomy_full_result['state'] ?? '') === 'ready' && ($taxonomy_full_result['method'] ?? '') === 'api_category_brand_seo_content' && $taxonomy_full_request_count === 1 && strpos($taxonomy_full_url, 'discovery%2Fapi%2Fv1') !== false && strpos($taxonomy_full_url, 'source_page=') === false);
pws_check('full category-brand fetch supplies both page-level SEO copy and the exact brand description to the source prompt', strpos((string) ($taxonomy_full_result['content'] ?? ''), 'توضیحات سئوی صفحه:') !== false && strpos((string) ($taxonomy_full_result['content'] ?? ''), 'توضیحات برند:') !== false && strpos((string) ($taxonomy_full_result['content'] ?? ''), 'والنتینو رودی') !== false);

$mismatched_fixture = $taxonomy_api_fixture;
$mismatched_fixture['data']['brand']['code'] = 'another-brand';
$GLOBALS['pws_override_response']['body'] = json_encode($mismatched_fixture, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$mismatched_text = evazar_fetch_taxonomy_category_brand_api_source_content('/search/category-men-analouge-watches/valentino-rudy/');
pws_check('category-brand API extraction rejects descriptions when the returned brand code does not match the requested source path', $mismatched_text === '');

$missing_identity_fixture = $taxonomy_api_fixture;
unset($missing_identity_fixture['data']['category']['code']);
$GLOBALS['pws_override_response']['body'] = json_encode($missing_identity_fixture, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$missing_identity_text = evazar_fetch_taxonomy_category_brand_api_source_content('/search/category-men-analouge-watches/valentino-rudy/');
pws_check('category-brand API extraction rejects payloads that omit either exact identity code', $missing_identity_text === '');
$mismatched_category_fixture = $taxonomy_api_fixture;
$mismatched_category_fixture['data']['category']['code'] = 'another-category';
$GLOBALS['pws_override_response']['body'] = json_encode($mismatched_category_fixture, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$mismatched_category_text = evazar_fetch_taxonomy_category_brand_api_source_content('/search/category-men-analouge-watches/valentino-rudy/');
pws_check('category-brand API extraction rejects descriptions when the returned category code does not match the requested source path', $mismatched_category_text === '');
$GLOBALS['pws_override_response'] = null;

 echo "\nRESULT: {$GLOBALS['pws_checks']} assertions passed.\n";
