<?php
/** Regression tests for planned-capacity vs actual queue claims and stage counters. */
error_reporting(E_ALL);
ini_set('display_errors', '1');
if (!defined('ABSPATH')) define('ABSPATH', dirname(__DIR__) . '/');
if (!defined('MINUTE_IN_SECONDS')) define('MINUTE_IN_SECONDS', 60);
if (!defined('HOUR_IN_SECONDS')) define('HOUR_IN_SECONDS', 3600);
if (!defined('DAY_IN_SECONDS')) define('DAY_IN_SECONDS', 86400);
$GLOBALS['qbc_options'] = [];
$GLOBALS['qbc_assertions'] = 0;
function add_action(...$args) {}
function add_filter(...$args) {}
function register_activation_hook(...$args) {}
function register_deactivation_hook(...$args) {}
function sanitize_key($value) { return strtolower(preg_replace('/[^a-z0-9_\-]/', '', (string) $value)); }
function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
function sanitize_textarea_field($value) { return trim(strip_tags((string) $value)); }
function absint($value) { return abs((int) $value); }
function esc_url_raw($value) { return (string) $value; }
function wp_parse_url($url, $component = -1) { return parse_url($url, $component); }
function get_option($name, $default = false) { return array_key_exists($name, $GLOBALS['qbc_options']) ? $GLOBALS['qbc_options'][$name] : $default; }
function update_option($name, $value, $autoload = null) { $GLOBALS['qbc_options'][$name] = $value; return true; }
function check_qbc($name, $passed) {
    $GLOBALS['qbc_assertions']++;
    if (!$passed) { fwrite(STDERR, "FAIL: {$name}\n"); exit(1); }
    echo "PASS: {$name}\n";
}
function current_time($type = 'mysql', $gmt = false) { return '2026-10-27 00:00:00'; }
function delete_transient($name) { return true; }
class QbcInvalidDkpDb {
    public $prefix = 'wp_';
    public $last_error = '';
    public $last_query = '';
    public function prepare($query, ...$args) { return $query; }
    public function query($query) { $this->last_query = $query; return 75; }
}
require_once __DIR__ . '/../importer.php';
require_once __DIR__ . '/../queue-manager.php';

$low_claim = evazar_queue_build_batch_claim_diagnostic(120, [
    'pending_total' => 160,
    'pending_due' => 36,
    'pending_not_due' => 124,
    'processing_before_claim' => 0,
    'eligible_pending' => 36,
    'claim_updated_rows' => 36,
    'claim_loaded_rows' => 36,
]);
check_qbc('underfilled capacity is explained by the exact eligible queue size', strpos($low_claim['reason'], 'فقط 36 ردیف') !== false);
check_qbc('120 target minus 36 loaded rows reports 84 unused slots', $low_claim['context']['claim_unfilled_capacity'] === 84);
check_qbc('claim diagnostic includes pending, due, future, processing and eligible counts', strpos($low_claim['message'], 'کل pending=160') !== false && strpos($low_claim['message'], 'pending با موعد رسیده=36') !== false && strpos($low_claim['message'], 'pending با موعد آینده=124') !== false && strpos($low_claim['message'], 'processing پیش از Claim=0') !== false && strpos($low_claim['message'], 'واجدشرایط طبق شرط واقعی Claim=36') !== false);

$race = evazar_queue_build_batch_claim_diagnostic(120, [
    'pending_total' => 150, 'pending_due' => 130, 'pending_not_due' => 20,
    'processing_before_claim' => 0, 'eligible_pending' => 130,
    'claim_updated_rows' => 36, 'claim_loaded_rows' => 36,
]);
check_qbc('diagnostic distinguishes enough eligible rows from a smaller DB Claim update', strpos($race['reason'], 'احتمال تغییر هم‌زمان') !== false);

$read_gap = evazar_queue_build_batch_claim_diagnostic(120, [
    'pending_total' => 120, 'pending_due' => 120, 'pending_not_due' => 0,
    'processing_before_claim' => 0, 'eligible_pending' => 120,
    'claim_updated_rows' => 120, 'claim_loaded_rows' => 36,
]);
check_qbc('diagnostic identifies claimed-vs-loaded row mismatch', strpos($read_gap['reason'], 'بیشتر از تعداد ردیف‌های بارگذاری‌شده') !== false);

$no_eligible = evazar_queue_build_batch_claim_diagnostic(120, [
    'pending_total' => 50, 'pending_due' => 0, 'pending_not_due' => 50,
    'processing_before_claim' => 0, 'eligible_pending' => 0,
    'claim_updated_rows' => 0, 'claim_loaded_rows' => 0,
]);
check_qbc('diagnostic reports when no item meets the claim eligibility rules', strpos($no_eligible['reason'], 'هیچ ردیفی') !== false);

// Exercise the actual logger serializer and verify that structured counters are retained.
$GLOBALS['qbc_options']['evz_gemini_ops_log'] = [];
$logged = evazar_queue_log_batch_claim_diagnostic(120, [
    'pending_total' => 160, 'pending_due' => 36, 'pending_not_due' => 124,
    'processing_before_claim' => 0, 'eligible_pending' => 36,
    'claim_updated_rows' => 36, 'claim_loaded_rows' => 36,
]);
$events = $GLOBALS['qbc_options']['evz_gemini_ops_log'];
check_qbc('one compact queue-batch-claim-result event is created', count($events) === 1 && $events[0]['type'] === 'queue_batch_claim_result');
check_qbc('structured event retains the planned capacity and actual claimed counts', ($events[0]['queue_run_capacity'] ?? 0) === 120 && ($events[0]['queue_eligible_pending'] ?? -1) === 36 && ($events[0]['queue_claim_updated_rows'] ?? -1) === 36 && ($events[0]['queue_claim_loaded_rows'] ?? -1) === 36 && ($events[0]['queue_claim_unfilled_capacity'] ?? -1) === 84);
check_qbc('event message explains that capacity is a ceiling rather than a guaranteed batch size', strpos($events[0]['message'], 'سقف است، نه تعداد تضمین‌شده') !== false);

$GLOBALS['qbc_options']['evz_gemini_ops_log'] = [];
$GLOBALS['evazar_queue_batch_claim_diagnostics'] = $logged;
evazar_queue_log_batch_run_summary(36, 35, 33, 1, 2, 'completed', 'اجرای آزمایشی');
$summary_events = $GLOBALS['qbc_options']['evz_gemini_ops_log'];
check_qbc('one end-of-run summary records actual success/failure/deferred counts', count($summary_events) === 1 && $summary_events[0]['type'] === 'queue_batch_run_summary' && ($summary_events[0]['queue_run_success'] ?? -1) === 33 && ($summary_events[0]['queue_run_failed'] ?? -1) === 1 && ($summary_events[0]['queue_run_deferred'] ?? -1) === 2);
check_qbc('end-of-run summary repeats capacity/eligible/claim/ready counts in one row', strpos($summary_events[0]['message'], 'سقف ظرفیت=120') !== false && strpos($summary_events[0]['message'], 'واجدشرایط پیش از Claim=36') !== false && strpos($summary_events[0]['message'], 'Claim واقعی=36') !== false && strpos($summary_events[0]['message'], 'آماده/Checkpoint برای Gemini=35') !== false);

$queue = file_get_contents(__DIR__ . '/../queue-manager.php');
$importer = file_get_contents(__DIR__ . '/../importer.php');
$core = file_get_contents(__DIR__ . '/../evazar-core.php');
check_qbc('eligible count and atomic update require numeric DKP with the same eligibility arguments', strpos($queue, 'WHERE status=\'pending\' AND $claim_valid_dkp_sql AND $claim_eligibility_sql') !== false && strpos($queue, '$batch_claim_snapshot[\'eligible_pending\'] = $read_queue_count($eligible_count_sql, $claim_eligibility_args)') !== false);
check_qbc('both empty claims and successful claims emit a diagnostic', substr_count($queue, 'evazar_queue_log_batch_claim_diagnostic($batch_size, $batch_claim_snapshot)') >= 2);
check_qbc('dispatch summary records actual ready products and pre-Gemini failures/deferrals', strpos($queue, "\$dispatch_context['queue_source_ready_products'] = \$ready_products") !== false && strpos($queue, "queue_pre_gemini_failed") !== false && strpos($queue, "queue_pre_gemini_deferred") !== false);
check_qbc('structured batch claim metrics are supported by Gemini event storage', strpos($importer, "'queue_eligible_pending'") !== false && strpos($importer, "'queue_claim_loaded_rows'") !== false && strpos($importer, "'queue_pre_gemini_deferred'") !== false);
check_qbc('planning log describes capacity as a maximum rather than actual claimed count', strpos($queue, 'ظرفیت پس از محافظ PHP=') !== false && strpos($queue, 'Gemini: Workerهای تنظیم‌شده=') !== false);
check_qbc('end-of-run summary is registered after item counters are initialized', strpos($queue, 'register_shutdown_function(static function () use (&$items, &$batch_pending, &$success_cnt, &$failed_cnt, &$deferred_cnt') !== false && strpos($queue, "evazar_gemini_log_event('queue_batch_run_summary'") !== false);
check_qbc('Core version is bumped to 2.9.84.96', strpos($core, '* Version: 2.9.84.96') !== false);
$quarantine_start = strpos($queue, 'function evazar_queue_quarantine_invalid_pending_dkps');
$quarantine_end = strpos($queue, '/** Requeue identifiable legacy failures', $quarantine_start ?: 0);
$quarantine_code = ($quarantine_start !== false && $quarantine_end !== false) ? substr($queue, $quarantine_start, $quarantine_end - $quarantine_start) : '';
check_qbc('invalid pending DKPs are quarantined without deletion or Retry increment', $quarantine_code !== '' && strpos($quarantine_code, "SET status='failed', error_code='INVALID_DKP'") !== false && strpos($quarantine_code, "'retries' =>") === false);
check_qbc('quarantine runs before the fresh queue Claim', strpos($queue, 'evazar_queue_quarantine_invalid_pending_dkps(1000)') < strpos($queue, '$claim_sql ='));
check_qbc('atomic Claim excludes DKPs that normalize to no digits', strpos($queue, '$claim_valid_dkp_sql =') !== false && strpos($queue, "dkp REGEXP '[0-9]'") !== false && strpos($queue, 'AND $claim_valid_dkp_sql AND $claim_eligibility_sql ORDER BY') !== false);
check_qbc('legacy failed-row auto retry cannot requeue invalid DKPs', strpos($queue, "WHERE status='failed' AND dkp<>'' AND dkp REGEXP '[0-9]' AND COALESCE(error_code,'') <> 'INVALID_DKP'") !== false);
check_qbc('runtime invalid-DKP errors become terminal and do not increment retry counter', strpos($queue, 'in_array($err_code, [\'invalid\', \'invalid_dkp\'], true)') !== false && strpos($queue, "'error_code' => 'INVALID_DKP'") !== false && strpos($queue, "'next_attempt_at' => null") !== false);
check_qbc('claim and final summaries expose the invalid-DKP quarantine count', strpos($queue, 'ردیف DKP نامعتبر قرنطینه‌شده=') !== false && strpos($queue, 'DKP نامعتبر منتقل‌شده به خطا=') !== false && strpos($importer, "'queue_invalid_dkp_quarantined'") !== false);

$GLOBALS['wpdb'] = new QbcInvalidDkpDb();
$GLOBALS['qbc_options']['evz_gemini_ops_log'] = [];
$quarantined = evazar_queue_quarantine_invalid_pending_dkps(1000);
$quarantine_sql = $GLOBALS['wpdb']->last_query;
$quarantine_event = $GLOBALS['qbc_options']['evz_gemini_ops_log'][0] ?? [];
check_qbc('quarantine returns the exact affected-row count and records one aggregate event', $quarantined === 75 && ($quarantine_event['type'] ?? '') === 'queue_invalid_dkp_quarantined' && ($quarantine_event['queue_invalid_dkp_quarantined'] ?? -1) === 75);
check_qbc('quarantine SQL only updates malformed pending rows to failed without deleting or incrementing retries', strpos($quarantine_sql, "SET status='failed', error_code='INVALID_DKP'") !== false && strpos($quarantine_sql, "WHERE status='pending' AND (TRIM(COALESCE(dkp,''))='' OR dkp NOT REGEXP '[0-9]')") !== false && stripos($quarantine_sql, 'DELETE') === false && stripos($quarantine_sql, 'retries=') === false);

fwrite(STDOUT, "\nRESULT: {$GLOBALS['qbc_assertions']} assertions passed.\n");
