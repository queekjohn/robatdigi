'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const sourcePath = path.join(__dirname, '..', 'worker', 'digikala-worker.js');
let source = fs.readFileSync(sourcePath, 'utf8')
  .replace('export default {', 'const WorkerDefault = {')
  .replace('export class GeminiIdempotencyDO', 'class GeminiIdempotencyDO');

let upstreamPayload;
let upstreamFetchCount = 0;
let geminiFetchCount = 0;
let brandSourcePayload = { data: { brand: { id: 1266, code: 'carrera-brand', title_fa: 'کررا', title_en: 'Carrera', url: { uri: '/brand/carrera-brand/' } } } };
let brandSourceHttpStatus = 200;
const context = vm.createContext({
  URL, Response, Request, Headers, AbortSignal, TextDecoder, TextEncoder, console,
  caches: { default: { match: async () => null, put: async () => {} } },
  fetch: async (url) => {
    const requestUrl = String(url);
    if (requestUrl === 'https://www.digikala.com/search/category-men-sport-shoes-/') {
      return new Response('<!doctype html><html><head><title>کفش ورزشی مردانه</title><link rel="canonical" href="https://www.digikala.com/search/category-men-sport-shoes-/"></head><body><h1>کفش ورزشی مردانه</h1><p>متن آزمایشی صفحه دسته بندی.</p></body></html>', { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
    }
    if (requestUrl === 'https://www.digikala.com/brand/anker/') {
      return new Response(null, { status: 301, headers: { Location: '/brand-landing/anker/' } });
    }
    if (requestUrl === 'https://www.digikala.com/brand-landing/anker/') {
      return new Response('<!doctype html><html><head><title>انکر</title><link rel=\"canonical\" href=\"https://www.digikala.com/brand-landing/anker/\"></head><body>انکر</body></html>', { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
    }
    if (requestUrl === 'https://www.digikala.com/brand/j.one/') {
      return new Response(null, { status: 301, headers: { Location: '/brand-landing/j.one/' } });
    }
    if (requestUrl === 'https://www.digikala.com/brand-landing/j.one/') {
      return new Response('<!doctype html><html><head><title>جی وان</title><link rel=\"canonical\" href=\"https://www.digikala.com/brand-landing/j.one/\"></head><body>جی وان</body></html>', { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
    }
    if (requestUrl === 'https://www.digikala.com/brand/other/') {
      return new Response(null, { status: 301, headers: { Location: '/brand-landing/not-anker/' } });
    }
    if (requestUrl === 'https://www.digikala.com/brand-landing/not-anker/') {
      return new Response('<!doctype html><html><head><title>Other</title><link rel=\"canonical\" href=\"https://www.digikala.com/brand-landing/not-anker/\"></head><body>Other</body></html>', { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
    }
    if (requestUrl.startsWith('https://www.digikala.com/brand/%DA%86%D8%B1%D9%85-%D8%A2%D8%B1%D8%A7%D9%87%D9%85%D8%B1%D8%A7%D9%87/')) {
      return new Response('<!doctype html><html><head><title>چرم آراهمراه</title><link rel=\"canonical\" href=\"https://www.digikala.com/brand/%DA%86%D8%B1%D9%85-%D8%A2%D8%B1%D8%A7%D9%87%D9%85%D8%B1%D8%A7%D9%87/\"></head><body>چرم آراهمراه</body></html>', { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
    }
    if (requestUrl === 'https://api.digikala.com/v1/brands/carrera-brand/search/') {
      return new Response(brandSourceHttpStatus === 200 ? JSON.stringify(brandSourcePayload) : JSON.stringify({ error: 'mocked upstream failure' }), { status: brandSourceHttpStatus, headers: { 'Content-Type': 'application/json; charset=utf-8' } });
    }
    if (requestUrl.startsWith('https://api.digikala.com/v2/product/123/')) {
      upstreamFetchCount++;
      return new Response(JSON.stringify(upstreamPayload), {
        status: 200,
        headers: { 'Content-Type': 'application/json; charset=utf-8' }
      });
    }
    if (requestUrl.startsWith('https://generativelanguage.googleapis.com/')) {
      geminiFetchCount++;
      return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: '{"items":[]}' }] } }] }), {
        status: 200,
        headers: { 'Content-Type': 'application/json; charset=utf-8' }
      });
    }
    throw new Error(`Unexpected mocked fetch URL: ${requestUrl}`);
  }
});
vm.runInContext(source, context, { filename: sourcePath });
const normalize = vm.runInContext('normalizeDigikalaBrandSourcePath', context);
const extract = vm.runInContext('extractDigikalaBrandSourcePath', context);
const validateSourcePagePath = vm.runInContext('validateDigikalaSourcePagePath', context);
const extractBrandRouteIdentitySlug = vm.runInContext('extractBrandRouteIdentitySlug', context);
const handleRequest = vm.runInContext('handleRequest', context);
const fetchSingleProduct = vm.runInContext('fetchSingleProduct', context);
const handleAiProxy = vm.runInContext('handleAiProxy', context);
const tests = [
  ['relative path canonicalization', () => assert.equal(normalize('/brand/SoNy/'), '/brand/sony/')],
  ['official URL canonicalization', () => assert.equal(normalize('https://www.digikala.com/brand/Sony/'), '/brand/sony/')],
  ['nested URL extraction', () => assert.equal(extract({ id: 42, url: { uri: 'https://www.digikala.com/brand/sony/' } }), '/brand/sony/')],
  ['real API brand.url.uri shape', () => assert.equal(extract({ id: 18, code: 'samsung', title_en: 'Samsung', url: { uri: '/brand/Samsung/' } }), '/brand/samsung/')],
  ['Persian brand URL is accepted', () => assert.equal(normalize('/brand/چرم-آراهمراه/'), '/brand/چرم-آراهمراه/')],
  ['percent-encoded Persian brand URL is accepted', () => assert.equal(normalize('https://www.digikala.com/brand/%DA%86%D8%B1%D9%85-%D8%A2%D8%B1%D8%A7%D9%87%D9%85%D8%B1%D8%A7%D9%87/'), '/brand/چرم-آراهمراه/')],
  ['brand-landing URL normalizes to the same logical brand identity', () => assert.equal(normalize('/brand-landing/Anker/'), '/brand/anker/')],
  ['dot in brand slug is preserved as source identity', () => assert.equal(normalize('/brand/j.one'), '/brand/j.one/')],
  ['dotted brand-landing alias normalizes to the same identity', () => assert.equal(normalize('/brand-landing/j.one/'), '/brand/j.one/')],
  ['source-page validator accepts a dotted brand slug', () => assert.equal(validateSourcePagePath('/brand/j.one/'), '/brand/j.one/')],
  ['source-page validator accepts Digikala category slug with one terminal hyphen', () => assert.equal(validateSourcePagePath('/search/category-men-sport-shoes-/'), '/search/category-men-sport-shoes-/')],
  ['source-page validator rejects duplicate trailing hyphens', () => assert.equal(validateSourcePagePath('/search/category-men-sport-shoes--/'), '')],
  ['source-page validator grammar rejects repeated internal separators', () => assert.equal(validateSourcePagePath('/search/category--men/'), '')],
  ['brand route identity extraction accepts j.one', () => assert.equal(extractBrandRouteIdentitySlug('/brand-landing/j.one/'), 'j.one')],
  ['source-page validator supports Persian brand slug and ASCII-safe encoding', () => assert.equal(validateSourcePagePath('/brand/چرم-آراهمراه/'), '/brand/%DA%86%D8%B1%D9%85-%D8%A2%D8%B1%D8%A7%D9%87%D9%85%D8%B1%D8%A7%D9%87/')],
  ['source-page validator explicitly allows brand-landing', () => assert.equal(validateSourcePagePath('/brand-landing/anker/'), '/brand-landing/anker/')],
  ['route identity parser accepts final brand-landing path', () => assert.equal(extractBrandRouteIdentitySlug('/brand-landing/anker/'), 'anker')],
  ['route identity parser accepts Persian encoded path', () => assert.equal(extractBrandRouteIdentitySlug('/brand/%DA%86%D8%B1%D9%85-%D8%A2%D8%B1%D8%A7%D9%87%D9%85%D8%B1%D8%A7%D9%87/'), 'چرم-آراهمراه')],
  ['source-page validator rejects encoded slash in slug', () => assert.equal(validateSourcePagePath('/brand/anker%2Fother/'), '')],
  ['no guessed slug from titles/code', () => assert.equal(extract({ title_fa: 'سونی', title_en: 'Sony', code: 'SONY' }), '')],
  ['reject foreign host', () => assert.equal(normalize('https://evil.example/brand/sony/'), '')],
  ['reject product URL', () => assert.equal(normalize('https://www.digikala.com/product/dkp-42/'), '')],
  ['reject query string', () => assert.equal(normalize('https://www.digikala.com/brand/sony/?x=1'), '')],
  ['reject path traversal', () => assert.equal(normalize('/brand/../sony/'), '')],
  ['reject encoded path traversal', () => assert.equal(normalize('/brand/%2e%2e/sony/'), '')],
  ['reject URL credentials', () => assert.equal(normalize('https://user@www.digikala.com/brand/sony/'), '')],
  ['reject URL port', () => assert.equal(normalize('https://www.digikala.com:443/brand/sony/'), '')],
  ['reject spoofed host suffix', () => assert.equal(normalize('https://www.digikala.com.evil.example/brand/sony/'), '')],
  ['reject malformed encoding', () => assert.equal(normalize('/brand/%E0%A4%A/'), '')],
  ['Worker source enforces product batch max 50', () => assert.match(source, /declaredBatchSize > 50/)],
  ['Worker source keeps taxonomy SEO batch max 5', () => assert.match(source, /requestPurpose === 'taxonomy_seo_batch'[\s\S]*?declaredBatchSize > 5/)],
];
let failed = 0;
function check(label, run) {
  try { run(); console.log(`PASS: ${label}`); }
  catch (e) { failed++; console.error(`FAIL: ${label}\n${e.stack}`); }
}

function productPayload(brand) {
  return { data: { product: {
    id: 123,
    title_fa: 'محصول نمونه',
    title_en: 'Sample Product',
    brand,
    default_variant: { price: { selling_price: 120000, rrp_price: 120000 }, seller: { title: 'دیجی‌کالا', code: 1 } },
    images: { main: { url: [] }, list: [] },
    category: { title_fa: 'دسته نمونه' },
    breadcrumb: [], specifications: [], rating: { count: 0 }
  } } };
}

(async () => {
  for (const [name, run] of tests) check(name, run);

  try {
    const unauthorized = await handleRequest(new Request('https://worker.test/brand-source/inspect', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ source_url: 'https://www.digikala.com/brand/carrera-brand/' })
    }), { EVAZAR_INTERNAL_TOKEN: 'secret-token' }, null);
    assert.equal(unauthorized.status, 401);
    check('brand source inspection requires the internal token', () => {});
  } catch (e) { failed++; console.error(`FAIL: brand source inspection requires the internal token\n${e.stack}`); }

  try {
    const inspected = await handleRequest(new Request('https://worker.test/brand-source/inspect', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Evazar-Internal-Token': 'secret-token' },
      body: JSON.stringify({ source_url: 'https://www.digikala.com/brand/carrera-brand/' })
    }), { EVAZAR_INTERNAL_TOKEN: 'secret-token' }, null);
    const json = await inspected.json();
    assert.equal(inspected.status, 200);
    assert.equal(json.identity.brand_id, '1266');
    assert.equal(json.identity.brand_code, 'carrera-brand');
    assert.equal(json.identity.brand_fa, 'کررا');
    assert.equal(json.identity.source_url, '/brand/carrera-brand/');
    assert.equal(json.identity.url_confirmed, true);
    check('brand source inspection returns explicit API identity through Worker', () => {});
  } catch (e) { failed++; console.error(`FAIL: brand source inspection returns explicit API identity through Worker\n${e.stack}`); }

  try {
    brandSourcePayload = { data: { brand: { id: 1266, code: 'another-code', title_fa: 'کررا', title_en: 'Carrera', url: { uri: '/brand/different-source/' } } } };
    const mismatch = await handleRequest(new Request('https://worker.test/brand-source/inspect', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Evazar-Internal-Token': 'secret-token' },
      body: JSON.stringify({ source_url: 'https://www.digikala.com/brand/carrera-brand/' })
    }), { EVAZAR_INTERNAL_TOKEN: 'secret-token' }, null);
    assert.equal(mismatch.status, 409);
    const mismatchJson = await mismatch.json();
    assert.equal(mismatchJson.error, 'brand_identity_unconfirmed');
    check('brand source inspection rejects an API identity that does not match the supplied URL', () => {});
  } catch (e) { failed++; console.error(`FAIL: brand source inspection rejects an API identity that does not match the supplied URL\n${e.stack}`); }

  try {
    brandSourcePayload = { data: { brand: { id: 1266, code: 'carrera-brand', title_fa: 'کررا', title_en: 'Carrera', url: { uri: '/brand/different-source/' } } } };
    const urlMismatch = await handleRequest(new Request('https://worker.test/brand-source/inspect', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Evazar-Internal-Token': 'secret-token' },
      body: JSON.stringify({ source_url: 'https://www.digikala.com/brand/carrera-brand/' })
    }), { EVAZAR_INTERNAL_TOKEN: 'secret-token' }, null);
    assert.equal(urlMismatch.status, 409);
    assert.equal((await urlMismatch.json()).error, 'brand_identity_unconfirmed');
    check('explicit conflicting API URL is rejected even when brand code matches', () => {});
  } catch (e) { failed++; console.error(`FAIL: explicit conflicting API URL is rejected even when brand code matches\n${e.stack}`); }

  brandSourcePayload = { data: { brand: { id: 1266, code: 'carrera-brand', title_fa: 'کررا', title_en: 'Carrera', url: { uri: '/brand/carrera-brand/' } } } };

  for (const upstreamStatus of [429, 503]) {
    try {
      brandSourceHttpStatus = upstreamStatus;
      const response = await handleRequest(new Request('https://worker.test/brand-source/inspect', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Evazar-Internal-Token': 'secret-token' },
        body: JSON.stringify({ source_url: 'https://www.digikala.com/brand/carrera-brand/' })
      }), { EVAZAR_INTERNAL_TOKEN: 'secret-token' }, null);
      assert.equal(response.headers.get('X-Evazar-Error-Scope'), 'source');
      assert.equal(response.status, upstreamStatus === 429 ? 429 : 502);
      check(`upstream HTTP ${upstreamStatus} is marked as source failure, not Worker failure`, () => {});
    } catch (e) { failed++; console.error(`FAIL: upstream HTTP ${upstreamStatus} is marked as source failure, not Worker failure\n${e.stack}`); }
  }
  brandSourceHttpStatus = 200;

  try {
    const oversizedBody = JSON.stringify({ source_url: 'https://www.digikala.com/brand/carrera-brand/', padding: 'x'.repeat(3000) });
    const response = await handleRequest(new Request('https://worker.test/brand-source/inspect', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Evazar-Internal-Token': 'secret-token' },
      body: oversizedBody
    }), { EVAZAR_INTERNAL_TOKEN: 'secret-token' }, null);
    assert.equal(response.status, 413);
    check('actual request body larger than 2 KiB is rejected without relying on Content-Length', () => {});
  } catch (e) { failed++; console.error(`FAIL: actual request body larger than 2 KiB is rejected without relying on Content-Length\n${e.stack}`); }

  try {
    const response = await handleRequest(new Request('https://worker.test/?source_page=%2Fbrand%2Fanker%2F'), {}, null);
    assert.equal(response.status, 200);
    assert.equal(response.headers.get('X-Evazar-Source-Redirects'), '1');
    assert.equal(response.headers.get('X-Evazar-Source-Final-Path'), '/brand-landing/anker/');
    check('source-page proxy follows same-slug brand-landing redirect and reports final path', () => {});
  } catch (e) { failed++; console.error(`FAIL: source-page proxy follows same-slug brand-landing redirect and reports final path\n${e.stack}`); }

  try {
    const response = await handleRequest(new Request('https://worker.test/?source_page=' + encodeURIComponent('/brand/j.one/')), {}, null);
    assert.equal(response.status, 200);
    assert.equal(response.headers.get('X-Evazar-Source-Final-Path'), '/brand-landing/j.one/');
    check('source-page proxy accepts j.one and verifies same-slug landing redirect', () => {});
  } catch (e) { failed++; console.error(`FAIL: source-page proxy accepts j.one and verifies same-slug landing redirect\n${e.stack}`); }

  try {
    const response = await handleRequest(new Request('https://worker.test/?source_page=%2Fbrand%2Fother%2F'), {}, null);
    assert.equal(response.status, 502);
    const body = await response.json();
    assert.match(body.message, /different or unrecognized brand path/);
    check('source-page proxy rejects redirect to a different brand slug', () => {});
  } catch (e) { failed++; console.error(`FAIL: source-page proxy rejects redirect to a different brand slug\n${e.stack}`); }

  try {
    const response = await handleRequest(new Request('https://worker.test/?source_page=' + encodeURIComponent('/brand/چرم-آراهمراه/')), {}, null);
    assert.equal(response.status, 200);
    assert.match(response.headers.get('X-Evazar-Source-Final-Path') || '', /^\/brand\//);
    check('source-page proxy serves a Persian-slugged source page', () => {});
  } catch (e) { failed++; console.error(`FAIL: source-page proxy serves a Persian-slugged source page\n${e.stack}`); }

  try {
    const path = '/search/category-men-sport-shoes-/';
    const response = await handleRequest(new Request('https://worker.test/?source_page=' + encodeURIComponent(path)), {}, null);
    assert.equal(response.status, 200);
    assert.equal(response.headers.get('X-Evazar-Source-Path'), path);
    assert.equal(response.headers.get('X-Evazar-Worker-Version'), '1.13.27');
    check('source-page proxy fetches the exact trailing-hyphen category path instead of returning 400', () => {});
  } catch (e) { failed++; console.error(`FAIL: source-page proxy fetches the exact trailing-hyphen category path instead of returning 400\n${e.stack}`); }

  try {
    upstreamPayload = productPayload({ id: 18, code: 'samsung', title_fa: 'سامسونگ', title_en: 'Samsung', url: { uri: '/brand/samsung/' } });
    const response = await fetchSingleProduct('123', {}, true, null);
    const result = await response.json();
    assert.equal(response.status, 200);
    assert.equal(result.version, '1.13.27');
    assert.equal(result.product.brand_source_path, '/brand/samsung/');
    assert.equal(result.product.brand_source_id, 18);
    assert.equal(result.product.brand_source_code, 'samsung');
    assert.equal(response.headers.get('X-Evazar-Worker-Version'), '1.13.27');
    check('fetchSingleProduct emits explicit brand ID/code/path in serialized response', () => {});
  } catch (e) { failed++; console.error(`FAIL: fetchSingleProduct emits explicit brand ID/code/path in serialized response\n${e.stack}`); }

  try {
    upstreamPayload = productPayload({ id: 9, code: 'charm-arahamrah', title_fa: 'چرم آراهمراه', title_en: 'Charm Arah Hamrah', url: { uri: '/brand/چرم-آراهمراه/' } });
    const response = await fetchSingleProduct('123', {}, true, null);
    const result = await response.json();
    assert.equal(response.status, 200);
    assert.equal(result.product.brand_source_path, '/brand/چرم-آراهمراه/');
    assert.equal(result.product.brand_source_id, 9);
    check('product API Persian brand URL is preserved in the actual Worker payload', () => {});
  } catch (e) { failed++; console.error(`FAIL: product API Persian brand URL is preserved in the actual Worker payload\n${e.stack}`); }

  try {
    upstreamPayload = productPayload({ id: 1025, code: 'j.one', title_fa: 'جی وان', title_en: 'J.One', url: { uri: '/brand/j.one' } });
    const response = await fetchSingleProduct('123', {}, true, null);
    const result = await response.json();
    assert.equal(response.status, 200);
    assert.equal(result.product.brand_source_path, '/brand/j.one/');
    assert.equal(result.product.brand_source_id, 1025);
    assert.equal(result.product.brand_source_code, 'j.one');
    check('product API j.one dotted brand path is emitted with source ID/code', () => {});
  } catch (e) { failed++; console.error(`FAIL: product API j.one dotted brand path is emitted with source ID/code\n${e.stack}`); }

  try {
    upstreamPayload = productPayload({ id: 18, code: 'anker', title_fa: 'انکر', title_en: 'Anker', url: { uri: '/brand-landing/anker/' } });
    const response = await fetchSingleProduct('123', {}, true, null);
    const result = await response.json();
    assert.equal(response.status, 200);
    assert.equal(result.product.brand_source_path, '/brand/anker/');
    check('product API brand-landing URL is emitted as the stable logical brand path', () => {});
  } catch (e) { failed++; console.error(`FAIL: product API brand-landing URL is emitted as the stable logical brand path\n${e.stack}`); }

  try {
    upstreamPayload = productPayload({ id: 8, title_fa: 'سونی', title_en: 'Sony', code: 'SONY' });
    const response = await fetchSingleProduct('123', {}, true, null);
    const result = await response.json();
    assert.equal(response.status, 200);
    assert.equal(Object.hasOwn(result.product, 'brand_source_path'), false);
    check('fetchSingleProduct does not emit a guessed brand path', () => {});
  } catch (e) { failed++; console.error(`FAIL: fetchSingleProduct does not emit a guessed brand path\n${e.stack}`); }

  try {
    const callProxy = async (purpose, size, taxonomyType = '') => {
      const headers = new Headers({
        'Content-Type': 'application/json',
        'X-EVazar-Request-Purpose': purpose,
        'X-Evazar-Request-ID': `gm-batch-test-${purpose}-${size}`,
        'X-EVazar-Batch-Size': String(size),
        'X-EVazar-Batch-Count': String(size)
      });
      if (taxonomyType) headers.set('X-Evazar-Taxonomy-Type', taxonomyType);
      const req = new Request('https://worker.test/gemini', { method: 'POST', headers, body: JSON.stringify({ contents: [{ parts: [{ text: 'test' }] }] }) });
      return await handleAiProxy(req, new URL('https://worker.test/gemini'), new Headers(), { GEMINI_API_KEY: 'test-only-key' });
    };
    const accepted50 = await callProxy('product_import_batch', 50);
    assert.equal(accepted50.status, 200);
    assert.equal(geminiFetchCount, 1);
    check('Worker policy accepts a declared 50-product request', () => {});
    const rejected51 = await callProxy('product_import_batch', 51);
    assert.equal(rejected51.status, 400);
    assert.equal(geminiFetchCount, 1, '51-product request must be rejected before the upstream API call');
    check('Worker policy rejects 51 products before upstream API call', () => {});
    const rejectedTaxonomy6 = await callProxy('taxonomy_seo_batch', 6, 'brand');
    assert.equal(rejectedTaxonomy6.status, 400);
    assert.equal(geminiFetchCount, 1);
    check('Worker keeps taxonomy SEO ceiling at five', () => {});
    const acceptedTaxonomy5 = await callProxy('taxonomy_seo_batch', 5, 'brand');
    assert.equal(acceptedTaxonomy5.status, 200);
    assert.equal(geminiFetchCount, 2);
    check('Worker accepts five-item taxonomy SEO batch', () => {});
  } catch (e) {
    failed++;
    console.error(`FAIL: Worker product/taxonomy batch policy boundary tests\n${e.stack}`);
  }

  check('Worker integration tests used mocked network only', () => assert.equal(upstreamFetchCount, 5));
  console.log(`\nRESULT: ${tests.length + 13 - failed} passed, ${failed} failed`);
  process.exitCode = failed ? 1 : 0;
})();
