<?php
error_reporting(E_ALL); ini_set('display_errors','1');
define('ABSPATH', __DIR__ . '/');
if (!defined('HOUR_IN_SECONDS')) define('HOUR_IN_SECONDS', 3600);
class WP_Error { private $code; private $message; public function __construct($code='',$message=''){ $this->code=$code; $this->message=$message; } public function get_error_code(){return $this->code;} public function get_error_message(){return $this->message;} }
$GLOBALS['csmr_terms']=[]; $GLOBALS['csmr_meta']=[]; $GLOBALS['csmr_posts']=[]; $GLOBALS['csmr_post_meta']=[]; $GLOBALS['csmr_rel']=['evazar_category'=>[]]; $GLOBALS['csmr_live']=[]; $GLOBALS['csmr_transients']=[]; $GLOBALS['csmr_pass']=0; $GLOBALS['csmr_fail']=0; $GLOBALS['csmr_meta_writes']=0;
function csmr_check($name,$ok){ if($ok){$GLOBALS['csmr_pass']++; echo "PASS - {$name}\n";}else{$GLOBALS['csmr_fail']++; echo "FAIL - {$name}\n";} }
function add_action(...$args){} function add_filter(...$args){} function remove_action(...$args){} function remove_filter(...$args){} function add_shortcode(...$args){} function register_activation_hook(...$args){} function register_deactivation_hook(...$args){}
function plugin_dir_path($file){return dirname($file).'/';} function post_type_exists($x){return true;} function add_submenu_page(...$args){}
function taxonomy_exists($tax){return in_array($tax,['evazar_category','evazar_brand'],true);} function current_user_can(...$args){return true;} function get_current_user_id(){return 7;} function check_ajax_referer(...$args){return true;} function wp_send_json_error($d=[],$s=400){throw new RuntimeException('json-error: '.json_encode($d));} function wp_send_json_success($d=[]){throw new RuntimeException('json-success: '.json_encode($d));}
function is_wp_error($v){return $v instanceof WP_Error;} function absint($v){return abs((int)$v);} function sanitize_text_field($v){return trim(strip_tags((string)$v));} function sanitize_title($v){$v=strtolower(trim((string)$v));return preg_replace('/[^a-z0-9_-]+/','-',$v);} function wp_unslash($v){return $v;}
function wp_json_encode($v,$flags=0){return json_encode($v,$flags);} function get_term($id,$tax=''){ $t=$GLOBALS['csmr_terms'][(int)$id]??null; if($t&&$tax!==''&&$t->taxonomy!==$tax)return null; return $t?clone $t:null; }
function get_term_meta($id,$key,$single=true){return $GLOBALS['csmr_meta'][(int)$id][$key]??'';} function update_term_meta($id,$key,$value){$GLOBALS['csmr_meta_writes']++;$GLOBALS['csmr_meta'][(int)$id][$key]=$value;return true;} function delete_term_meta($id,$key){unset($GLOBALS['csmr_meta'][(int)$id][$key]);return true;}
function get_post_meta($id,$key,$single=true){return $GLOBALS['csmr_post_meta'][(int)$id][$key]??'';} function get_post($id){return $GLOBALS['csmr_posts'][(int)$id]??null;} function get_posts($args=[]){$term=absint($args['tax_query'][0]['terms'][0]??0);$ids=[];foreach($GLOBALS['csmr_rel']['evazar_category'] as $pid=>$tids){if(in_array($term,array_map('absint',(array)$tids),true)&&isset($GLOBALS['csmr_posts'][$pid])&&$GLOBALS['csmr_posts'][$pid]->post_status==='publish')$ids[]=(int)$pid;}rsort($ids);return array_slice($ids,0,(int)($args['posts_per_page']??3));}
function wp_get_object_terms($post_id,$tax,$args=[]){return $GLOBALS['csmr_rel'][$tax][(int)$post_id]??[];} function get_terms($args=[]){$out=[];foreach($GLOBALS['csmr_terms'] as $t){if(($args['taxonomy']??'')!==''&&$t->taxonomy!==$args['taxonomy'])continue;$ok=true;foreach((array)($args['meta_query']??[]) as $q){if((string)get_term_meta($t->term_id,$q['key'],true)!==(string)($q['value']??'')){$ok=false;break;}}if($ok)$out[]=$t;}return $out;}
function set_transient($k,$v,$ttl=0){$GLOBALS['csmr_transients'][$k]=$v;return true;} function get_transient($k){return $GLOBALS['csmr_transients'][$k]??false;} function delete_transient($k){unset($GLOBALS['csmr_transients'][$k]);return true;}
function evazar_normalize_digikala_source_path($v){$v=trim((string)$v);if($v==='')return ''; $p=parse_url($v);if(!is_array($p))return '';if(!empty($p['host'])&&!in_array(strtolower($p['host']),['digikala.com','www.digikala.com'],true))return ''; $path=rawurldecode((string)($p['path']??''));if(!preg_match('#^/(search|main|brand)/[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*/?$#i',$path))return '';return rtrim($path,'/').'/';}
function evazar_digikala_category_slug_from_path($p){$p=evazar_normalize_digikala_source_path($p);if(preg_match('#^/search/([^/]+)/#',$p,$m))return $m[1];if(preg_match('#^/main/([^/]+)/#',$p,$m))return 'category-'.$m[1];return '';}
function evazar_fetch_raw_product_data($dkp,$force=false,$fallback=false,$purpose=''){return $GLOBALS['csmr_live'][(string)$dkp]??false;}
function evazar_bsmr_queue_guard(){return true;}
function evazar_persist_category_source_metadata($id,$path,$kind='digikala_breadcrumb'){ $path=evazar_normalize_digikala_source_path($path);if(!$path)return new WP_Error('badpath','bad path');$old=(string)get_term_meta($id,'_evazar_dk_url',true);$ver=(string)get_term_meta($id,'_evazar_dk_source_verified',true);if($ver==='1'&&$old!==''&&$old!==$path)return new WP_Error('conflict','verified conflict');update_term_meta($id,'_evazar_dk_source_verified','0');update_term_meta($id,'_evazar_dk_url',$path);update_term_meta($id,'_evazar_dk_source_kind',$kind);update_term_meta($id,'_evazar_dk_source_map_version','2.9.84.29');update_term_meta($id,'_evazar_dk_source_path_updated','test');update_term_meta($id,'_evazar_dk_source_verified','1');return true;}

// Load the actual queue helpers and category-repair implementation.
require_once dirname(__DIR__).'/queue-manager.php';
require_once dirname(__DIR__).'/category-source-metadata-repair.php';

function csmr_seed_term($id,$name,$slug,$parent=0,$meta=[]){$GLOBALS['csmr_terms'][$id]=(object)['term_id'=>$id,'name'=>$name,'slug'=>$slug,'parent'=>$parent,'taxonomy'=>'evazar_category','count'=>0];$GLOBALS['csmr_meta'][$id]=$meta;}
function csmr_seed_post($id,$dkp,$terms,$live){$GLOBALS['csmr_posts'][$id]=(object)['ID'=>$id,'post_type'=>'evazar_product','post_status'=>'publish'];$GLOBALS['csmr_post_meta'][$id]=['_evazar_sku'=>$dkp,'_evazar_dk_url'=>'https://www.digikala.com/product/dkp-'.$dkp.'/'];$GLOBALS['csmr_rel']['evazar_category'][$id]=$terms;$GLOBALS['csmr_live'][(string)$dkp]=['breadcrumbs'=>$live];}
$crumbs=[['title'=>'خانه','url'=>'/search/home/'],['title'=>'ماشین لباسشویی','url'=>'/search/category-washing-machines/'],['title'=>'ال جی','url'=>'/search/category-washing-machines/lg/']];
csmr_seed_term(1,'خانه','home',0);csmr_seed_term(2,'ماشین لباسشویی','category-washing-machines',1);csmr_seed_term(3,'ال جی','lg',2);
csmr_seed_post(101,'500101',[1,2,3],$crumbs);csmr_seed_post(102,'500102',[1,2,3],$crumbs);
$r=evazar_csmr_analyze_term(3);csmr_check('two independent products agreeing on category chain are READY',($r['status']??'')==='READY'&&($r['samples']??0)===2);
$before_rel=$GLOBALS['csmr_rel']['evazar_category'];$before_slug=$GLOBALS['csmr_terms'][3]->slug;$before_writes=$GLOBALS['csmr_meta_writes'];$a=evazar_csmr_apply_candidate(3);
csmr_check('apply writes verified source metadata',($a['status']??'')==='SAVED'&&get_term_meta(3,'_evazar_dk_source_verified',true)==='1'&&get_term_meta(3,'_evazar_dk_url',true)==='/search/category-washing-machines/lg/');
csmr_check('category repair preserves public slug and product assignments',$GLOBALS['csmr_terms'][3]->slug===$before_slug&&$GLOBALS['csmr_rel']['evazar_category']===$before_rel);
csmr_check('category repair records live-repair provenance',get_term_meta(3,'_evazar_dk_source_map_version',true)==='2.9.84.29-live-category-metadata-repair');

// A source change after analysis must not be persisted.
csmr_seed_term(4,'دوو','daewoo',2);csmr_seed_post(103,'500103',[1,2,4],[['title'=>'خانه','url'=>'/search/home/'],['title'=>'ماشین لباسشویی','url'=>'/search/category-washing-machines/'],['title'=>'دوو','url'=>'/search/category-washing-machines/daewoo/']]);
csmr_seed_post(104,'500104',[1,2,4],[['title'=>'خانه','url'=>'/search/home/'],['title'=>'ماشین لباسشویی','url'=>'/search/category-washing-machines/'],['title'=>'دوو','url'=>'/search/category-washing-machines/daewoo/']]);
$r=evazar_csmr_analyze_term(4);$GLOBALS['csmr_live']['500104']['breadcrumbs'][2]['url']='/search/category-washing-machines/other/';$a=evazar_csmr_apply_candidate(4);
csmr_check('changed source after review is rejected',($r['status']??'')==='READY'&&($a['status']??'')==='SOURCE_CHANGED_AFTER_REVIEW'&&get_term_meta(4,'_evazar_dk_source_verified',true)!=='1');

// Disagreement between live product paths blocks analysis.
csmr_seed_term(5,'سونی','sony',2);csmr_seed_post(105,'500105',[1,2,5],[['title'=>'خانه','url'=>'/search/home/'],['title'=>'ماشین لباسشویی','url'=>'/search/category-washing-machines/'],['title'=>'سونی','url'=>'/search/category-washing-machines/sony/']]);csmr_seed_post(106,'500106',[1,2,5],[['title'=>'خانه','url'=>'/search/home/'],['title'=>'ماشین لباسشویی','url'=>'/search/category-washing-machines/'],['title'=>'سونی','url'=>'/search/category-washing-machines/sony-x/']]);
$r=evazar_csmr_analyze_term(5);csmr_check('two live products with different category paths are blocked',($r['status']??'')==='SAMPLE_DISAGREEMENT');

// Wrong hierarchy/name and missing source URL are rejected.
csmr_seed_term(6,'ال جی','lg-other',1);$bad=[['title'=>'خانه','url'=>'/search/home/'],['title'=>'دسته اشتباه','url'=>'/search/other/'],['title'=>'ال جی','url'=>'/search/other/lg/']];$r=evazar_csmr_match_breadcrumbs(6,$bad);csmr_check('category parent chain mismatch is blocked',is_wp_error($r)&&$r->get_error_code()==='csmr_hierarchy_mismatch');
$r=evazar_csmr_match_breadcrumbs(6,[['title'=>'خانه','url'=>''],['title'=>'ال جی','url'=>'']]);csmr_check('title-only breadcrumb is rejected',is_wp_error($r));

// A duplicate source path cannot be assigned to a second term.
csmr_seed_term(7,'دستهٔ دیگر','other-category',0,['_evazar_dk_url'=>'/search/category-washing-machines/lg/','_evazar_dk_source_kind'=>'digikala_breadcrumb']);
$owner=evazar_csmr_source_path_owner_conflict(3,'/search/category-washing-machines/lg/');csmr_check('source path already owned by another category is blocked',is_wp_error($owner));
csmr_seed_term(10,'دسته با URL کامل','legacy-full-url',0,['_evazar_dk_url'=>'https://www.digikala.com/search/category-washing-machines/lg/','_evazar_dk_source_kind'=>'digikala_breadcrumb']);
$owner_full=evazar_csmr_source_path_owner_conflict(3,'/search/category-washing-machines/lg/');csmr_check('source ownership detects legacy absolute URLs after normalization',is_wp_error($owner_full));

// Verified but conflicting existing identity is never overwritten.
csmr_seed_term(8,'سونی','sony-old',2,['_evazar_dk_url'=>'/search/category-washing-machines/old/','_evazar_dk_source_verified'=>'1','_evazar_dk_source_kind'=>'digikala_breadcrumb','_evazar_dk_source_map_version'=>'2.9.84.16']);
csmr_seed_post(107,'500107',[1,2,8],[['title'=>'خانه','url'=>'/search/home/'],['title'=>'ماشین لباسشویی','url'=>'/search/category-washing-machines/'],['title'=>'سونی','url'=>'/search/category-washing-machines/sony/']]);csmr_seed_post(108,'500108',[1,2,8],[['title'=>'خانه','url'=>'/search/home/'],['title'=>'ماشین لباسشویی','url'=>'/search/category-washing-machines/'],['title'=>'سونی','url'=>'/search/category-washing-machines/sony/']]);
$r=evazar_csmr_analyze_term(8);csmr_check('verified metadata conflict is not auto-overwritten',($r['status']??'')==='VERIFIED_METADATA_CONFLICT');

// Legacy queue helpers should require complete explicit breadcrumbs and trusted source metadata.
csmr_check('queue breadcrumb validator accepts complete explicit source paths',evazar_queue_breadcrumbs_have_explicit_paths($crumbs));
csmr_check('queue breadcrumb validator rejects title-only paths',!evazar_queue_breadcrumbs_have_explicit_paths([['title'=>'ال جی','url'=>'']]));
$GLOBALS['csmr_meta'][3]=['_evazar_dk_source_verified'=>'1','_evazar_dk_source_kind'=>'digikala_breadcrumb','_evazar_dk_url'=>'/search/category-washing-machines/lg/','_evazar_dk_source_map_version'=>'2.9.84.29'];
csmr_check('queue term completeness recognizes trusted category provenance',evazar_queue_term_source_identity_complete(3,'evazar_category'));
$GLOBALS['csmr_meta'][3]['_evazar_dk_source_map_version']='guessed-old-version';
csmr_check('queue term completeness rejects untrusted legacy provenance',!evazar_queue_term_source_identity_complete(3,'evazar_category'));

// Derived landing routes should not be listed or repaired as source breadcrumbs.
csmr_seed_term(9,'ماشین لباسشویی ال جی','washing-machine-lg',2,['_evazar_dk_source_kind'=>'derived_brand_landing','_evazar_dk_generated_url'=>'/search/category-washing-machines/lg/']);
csmr_check('derived category+brand landing excluded from real-source repair',($r=evazar_csmr_analyze_term(9))['status']==='DERIVED_LANDING');

echo "\nRESULT: {$GLOBALS['csmr_pass']} passed, {$GLOBALS['csmr_fail']} failed\n";exit($GLOBALS['csmr_fail']?1:0);
