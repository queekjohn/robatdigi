#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');

const sourcePath = path.join(__dirname, '..', 'worker', 'digikala-worker.js');
const source = fs.readFileSync(sourcePath, 'utf8');
let mode = 'rate_limit';
let calls = [];
const product = {
  id: 123,
  title_fa: 'محصول آزمایشی',
  title_en: 'Test product',
  default_variant: { price: { selling_price: 100000, rrp_price: 120000 }, seller: { title: 'دیجی‌کالا' } },
  images: { main: { url: [] }, list: [] },
  specifications: [],
  rating: { count: 0 },
  category: { id: 9, title_fa: 'دسته آزمایشی' },
  brand: { id: 18, title_fa: 'برند آزمایشی', title_en: 'Sample', code: 'sample', url: { uri: '/brand/sample/' } },
};
function upstreamResponse(url) {
  const isV2 = url.includes('/v2/');
  if (mode === 'rate_limit') {
    return new Response(JSON.stringify({ message: 'rate limited' }), { status: 429, headers: { 'Content-Type': 'application/json' } });
  }
  if (mode === 'access_denied') {
    return new Response(JSON.stringify({ message: 'forbidden' }), { status: 403, headers: { 'Content-Type': 'application/json' } });
  }
  if (mode === 'timeout') {
    return new Response(JSON.stringify({ success: false, message: 'Upstream request timed out.' }), { status: 504, headers: { 'Content-Type': 'application/json', 'X-Evazar-Upstream-Error': 'TimeoutError', 'X-Evazar-Upstream-Status': '504' } });
  }
  if (mode === 'server_error') {
    return new Response(JSON.stringify({ message: 'server error' }), { status: 503, headers: { 'Content-Type': 'application/json' } });
  }
  if (mode === 'fallback_success') {
    if (isV2) return new Response(JSON.stringify({ message: 'not found on v2' }), { status: 404, headers: { 'Content-Type': 'application/json' } });
    return new Response(JSON.stringify({ data: { product } }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  }
  if (mode === 'not_found') {
    return new Response(JSON.stringify({ message: 'not found' }), { status: 404, headers: { 'Content-Type': 'application/json' } });
  }
  if (mode === 'invalid_json') {
    return new Response('{not-json', { status: 200, headers: { 'Content-Type': 'application/json' } });
  }
  throw new Error(`Unexpected mock mode: ${mode}`);
}
const context = vm.createContext({
  URL, Response, Request, Headers, AbortSignal, console,
  caches: { default: { match: async () => null, put: async () => {} } },
  fetch: async (url) => {
    const value = String(url);
    calls.push(value);
    assert.match(value, /^https:\/\/api\.digikala\.com\/v[12]\/product\/123\/$/);
    if (mode === 'timeout' && value.includes('/v2/')) {
      const error = new Error('The operation timed out');
      error.name = 'TimeoutError';
      throw error;
    }
    return upstreamResponse(value);
  },
});
vm.runInContext(source.replace('export default {', 'const WorkerDefault = {').replace('export class GeminiIdempotencyDO', 'class GeminiIdempotencyDO'), context, { filename: sourcePath });
const run = async () => vm.runInContext('fetchSingleProduct("123", {"Access-Control-Allow-Origin":"*"}, true, null)', context);
let passed = 0;
let failed = 0;
async function test(name, fn) {
  try { await fn(); passed++; console.log(`PASS: ${name}`); }
  catch (error) { failed++; console.error(`FAIL: ${name}\n${error.stack}`); }
}
async function reset(nextMode) { mode = nextMode; calls = []; }

(async () => {
  assert.match(source, /const DIGIKALA_WORKER_VERSION = '1\.13\.27'/);
  await test('upstream 429 is surfaced as source scope with retry guidance and no v1 amplification', async () => {
    await reset('rate_limit');
    const r = await run(); const body = await r.json();
    assert.equal(r.status, 429);
    assert.equal(r.headers.get('X-Evazar-Error-Scope'), 'source');
    assert.equal(r.headers.get('Retry-After'), '30');
    assert.equal(body.error, 'source_rate_limited');
    assert.equal(body.upstream_status_v2, 429);
    assert.equal(body.upstream_status_v1, 0);
    assert.match(body.message, /v1=not-attempted \(v2 rate limited\)/);
    assert.equal(calls.length, 1);
  });
  await test('upstream 403 is not followed by another API version', async () => {
    await reset('access_denied');
    const r = await run(); const body = await r.json();
    assert.equal(r.status, 502);
    assert.equal(body.error, 'source_request_rejected');
    assert.match(body.message, /v1=not-attempted \(v2 access denied \(403\)\)/);
    assert.equal(calls.length, 1);
  });
  await test('upstream timeout is not followed by another API version', async () => {
    await reset('timeout');
    const r = await run(); const body = await r.json();
    assert.equal(r.status, 503);
    assert.equal(r.headers.get('X-Evazar-Error-Scope'), 'source');
    assert.match(body.message, /v1=not-attempted \(v2 timeout\)/);
    assert.equal(calls.length, 1);
  });
  await test('upstream 5xx is not multiplied by a v1 fallback request', async () => {
    await reset('server_error');
    const r = await run(); const body = await r.json();
    assert.equal(r.status, 503);
    assert.equal(body.error, 'source_server_error');
    assert.match(body.message, /v1=not-attempted \(v2 server error \(503\)\)/);
    assert.equal(calls.length, 1);
  });
  await test('v2 404 still falls back to v1 when v1 may have the product', async () => {
    await reset('fallback_success');
    const r = await run(); const body = await r.json();
    assert.equal(r.status, 200);
    assert.equal(body.success, true);
    assert.equal(body.product.id, 123);
    assert.equal(calls.length, 2);
    assert.match(calls[0], /\/v2\//);
    assert.match(calls[1], /\/v1\//);
  });
  await test('both API versions returning 404 stays a product-specific 404', async () => {
    await reset('not_found');
    const r = await run(); const body = await r.json();
    assert.equal(r.status, 404);
    assert.equal(r.headers.get('X-Evazar-Error-Scope'), 'product');
    assert.equal(body.error, 'product_not_found');
    assert.equal(calls.length, 2);
  });
  await test('malformed upstream JSON is a source-scoped diagnostic', async () => {
    await reset('invalid_json');
    const r = await run(); const body = await r.json();
    assert.equal(r.status, 502);
    assert.equal(r.headers.get('X-Evazar-Error-Scope'), 'source');
    assert.equal(body.error, 'source_invalid_json');
    assert.equal(calls.length, 1);
  });
  console.log(`\nRESULT: ${passed} passed, ${failed} failed`);
  process.exitCode = failed ? 1 : 0;
})().catch((error) => { console.error(error.stack); process.exitCode = 1; });
