<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
define('ABSPATH', __DIR__ . '/');
define('MINUTE_IN_SECONDS', 60);
define('HOUR_IN_SECONDS', 3600);
define('DAY_IN_SECONDS', 86400);
$GLOBALS['test_options'] = [];
$GLOBALS['assertions'] = 0;
function add_action(...$args) {}
function add_filter(...$args) {}
function sanitize_key($value) { return strtolower(preg_replace('/[^a-z0-9_\-]/', '', (string) $value)); }
function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
function absint($value) { return abs((int) $value); }
function esc_url_raw($value) { return (string) $value; }
function wp_parse_url($url, $component = -1) { return parse_url($url, $component); }
function wp_generate_uuid4() { return '12345678-1234-4234-8234-123456789abc'; }
function get_option($key, $default = false) { return $GLOBALS['test_options'][$key] ?? $default; }
function update_option($key, $value, $autoload = null) { $GLOBALS['test_options'][$key] = $value; return true; }
function check($condition, $message) {
    $GLOBALS['assertions']++;
    if (!$condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
    echo "PASS: {$message}\n";
}
require __DIR__ . '/../importer.php';

function make_dkps($count, $start = 10000000) {
    $items = [];
    for ($i = 0; $i < $count; $i++) $items[] = 'dkp-' . ($start + $i);
    return $items;
}

foreach ([2, 30, 40, 50] as $size) {
    $input = make_dkps($size);
    $context = evazar_gemini_prepare_request_context([
        'purpose' => 'product_import_batch', 'batch_size' => $size, 'dkps' => $input,
    ]);
    check(count($context['dkps']) === $size, "context preserves all {$size} unique DKPs");
    check($context['batch_size'] === $size, "context retains declared batch size {$size}");
    check($context['dkps'] === array_map(static function ($value) { return preg_replace('/[^0-9]/', '', $value); }, $input), "context preserves DKP order for batch {$size}");
}

// The same 40/50 unique IDs must be declared to the independent Cloudflare Worker.
foreach ([2, 30, 40, 50] as $size) {
    $headers = evazar_gemini_request_policy_headers([
        'purpose' => 'product_import_batch', 'batch_size' => $size, 'dkps' => make_dkps($size),
    ]);
    check(($headers['X-EVazar-Batch-Size'] ?? '') === (string) $size, "Worker header declares batch size {$size}");
    check(($headers['X-EVazar-Batch-Count'] ?? '') === (string) $size, "Worker header declares all {$size} unique DKPs");
}

// Duplicate and malformed items before later valid IDs must not eat into the 50 unique-ID budget.
$messy = make_dkps(25);
$messy = array_merge($messy, array_slice(make_dkps(25), 0, 10)); // duplicates of IDs 1-10
$messy[] = '';
$messy[] = 'not-a-dkp';
$messy = array_merge($messy, make_dkps(25, 10000025));
$normalized = evazar_gemini_normalize_dkp_list($messy, 50);
check(count($normalized) === 50, 'duplicate/invalid values do not truncate a valid 50-product batch');
check($normalized[0] === '10000000' && $normalized[49] === '10000049', '50 unique DKPs remain in stable input order');
check(count(array_unique($normalized)) === 50, 'normalized DKP list is unique');
check(count(evazar_gemini_normalize_dkp_list(make_dkps(60), 50)) === 50, 'hard upper bound remains 50 DKPs');
check(evazar_gemini_normalize_dkp_list(make_dkps(5), 0) === [], 'zero cap returns an empty DKP list');

// Production logging uses the same normalization and can keep the entire 50-item batch.
$GLOBALS['test_options']['evz_gemini_ops_log'] = [];
$log_context = [
    'purpose' => 'product_import_batch',
    'batch_size' => 50,
    'batch_id' => 'batch-50-test',
    'dkps' => $messy,
    'source_fetch_waves' => 40,
    'source_fetch_requests' => 120,
    'source_fetch_responses' => 120,
    'source_fetch_fallback_requests' => 1,
    'source_fetch_transport_errors' => 0,
    'source_fetch_elapsed_ms' => 98765,
];
evazar_gemini_log_event('test', 'DKP cap regression test', '', 0, 0, $log_context);
$logs = $GLOBALS['test_options']['evz_gemini_ops_log'];
check(isset($logs[0]['dkps']) && count($logs[0]['dkps']) === 50, 'operations log records all 50 unique DKPs');
check($logs[0]['batch_size'] === 50, 'operations log records batch size 50');
check($logs[0]['dkps'][49] === '10000049', 'operations log includes the final DKP in a 50-item batch');
check(($logs[0]['source_fetch_waves'] ?? 0) === 40 && ($logs[0]['source_fetch_requests'] ?? 0) === 120, 'aggregated source wave and request metrics are retained in the operation log');
check(($logs[0]['source_fetch_responses'] ?? 0) === 120 && ($logs[0]['source_fetch_fallback_requests'] ?? 0) === 1 && ($logs[0]['source_fetch_transport_errors'] ?? 99) === 0, 'aggregated source response and fallback counters are retained');
check(($logs[0]['source_fetch_elapsed_ms'] ?? 0) === 98765, 'aggregated source preparation duration is retained');

// Static regression guard: neither request context nor event logging may retain a 30-item DKP slice.
$source = file_get_contents(__DIR__ . '/../importer.php');
check(strpos($source, "array_slice($" . "context['dkps'], 0, 30)") === false, 'old 30-DKP truncation is absent from importer');
check(strpos($source, 'function evazar_gemini_normalize_dkp_list') !== false, 'shared 50-DKP normalizer is present in production source');

$core_source = file_get_contents(__DIR__ . '/../evazar-core.php');
check(strpos($core_source, "array_slice($" . "event['dkps'], 0, 30)") === false, 'admin operations display has no stale 30-DKP truncation');
check(strpos($core_source, 'DKP / اعضای دسته') !== false && strpos($core_source, 'array_slice(array_map(static function') !== false && strpos($core_source, '0, 50)) : $event_dkp') !== false, 'compact admin cards retain all 50 DKPs in expandable details');
$worker_source = file_get_contents(__DIR__ . '/../worker/digikala-worker.js');
check(strpos($worker_source, "const DIGIKALA_WORKER_VERSION = '1.13.27'") !== false, 'embedded Worker source is version 1.13.27');
check(strpos($worker_source, 'declaredBatchSize > 50') !== false, 'embedded Worker accepts product batches up to 50');

fwrite(STDOUT, "\nRESULT: {$GLOBALS['assertions']} assertions passed.\n");
