<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
define('ABSPATH', __DIR__ . '/');
define('MINUTE_IN_SECONDS', 60);
define('HOUR_IN_SECONDS', 3600);
define('DAY_IN_SECONDS', 86400);
$GLOBALS['transients'] = [];
$GLOBALS['options'] = [];
$GLOBALS['fixed_rand'] = 999999;
$GLOBALS['assertions'] = 0;
function add_action(...$args) {}
function add_filter(...$args) {}
// Model WordPress site-local date formatting; the runtime's server timezone may differ.
function wp_timezone() { return new DateTimeZone('Europe/Berlin'); }
function wp_date($format, $timestamp = null, $timezone = null) {
    $timestamp = ($timestamp === null) ? time() : (int) $timestamp;
    $timezone = ($timezone instanceof DateTimeZone) ? $timezone : wp_timezone();
    return (new DateTimeImmutable('@' . $timestamp))->setTimezone($timezone)->format((string) $format);
}
function get_transient($k) { return $GLOBALS['transients'][$k]['value'] ?? false; }
function set_transient($k,$v,$ttl=0) { $GLOBALS['transients'][$k] = ['value'=>$v,'ttl'=>$ttl]; return true; }
function delete_transient($k) { unset($GLOBALS['transients'][$k]); return true; }
function get_option($k,$default=false) { return $GLOBALS['options'][$k] ?? $default; }
function update_option($k,$v,$autoload=null) { $GLOBALS['options'][$k]=$v; return true; }
function wp_rand($min=null,$max=null) { if ($GLOBALS['fixed_rand'] !== null) return max((int)$min,min((int)$max,(int)$GLOBALS['fixed_rand'])); return (int) floor(((int)$min+(int)$max)/2); }
function sanitize_key($v) { return strtolower(preg_replace('/[^a-z0-9_\-]/','',(string)$v)); }
function sanitize_text_field($v) { return trim(strip_tags((string)$v)); }
function absint($v) { return abs((int)$v); }
function wp_parse_url($url,$component=-1) { return parse_url($url,$component); }
function esc_url_raw($v) { return (string)$v; }
function wp_kses(...$args) { return (string)($args[0]??''); }
function wp_strip_all_tags($v) { return strip_tags((string)$v); }
function is_wp_error($v) { return $v instanceof WP_Error; }
class WP_Error { public $code; public $message; public $data=[]; function __construct($c='',$m='',$d=null){$this->code=$c;$this->message=$m;if($d!==null)$this->data=$d;} function add_data($d){$this->data=$d;} function get_error_code(){return $this->code;} function get_error_message(){return $this->message;} }
function check($condition, $message) { $GLOBALS['assertions']++; if (!$condition) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } echo "PASS: $message\n"; }
require __DIR__ . '/../importer.php';

// Real Unix timestamps must be converted exactly once to the configured WordPress timezone.
$timezone_test_timestamp = strtotime('2026-10-27 00:40:12 UTC');
$timezone_test_expected = (new DateTimeImmutable('@' . $timezone_test_timestamp))
    ->setTimezone(new DateTimeZone('Europe/Berlin'))->format('Y-m-d H:i:s');
check(evazar_gemini_local_datetime($timezone_test_timestamp) === $timezone_test_expected, 'Unix timestamp is rendered in WordPress timezone exactly once');
check(evazar_gemini_local_datetime($timezone_test_timestamp, 'H:i:s') === substr($timezone_test_expected, 11), 'time-only timestamp display uses the same WordPress timezone');
check(evazar_gemini_local_datetime(0) === '', 'zero timestamp is not rendered as a misleading date');

// 429 random jitter is exactly within the agreed 30–60 minute range.
$wait = evazar_gemini_worker_rate_limit_wait_seconds([], '{}');
check($wait >= 1800 && $wait <= 3600, '429 without provider retry hint gets 30–60 minute jitter');
$GLOBALS['fixed_rand'] = 0;
$wait = evazar_gemini_worker_rate_limit_wait_seconds([], '{}');
check($wait === 1800, '429 random policy respects the 30-minute lower bound');
$GLOBALS['fixed_rand'] = 999999;
$wait = evazar_gemini_worker_rate_limit_wait_seconds([], '{}');
check($wait === 3600, '429 random policy respects the 60-minute upper bound');
$GLOBALS['fixed_rand'] = 0;
$wait = evazar_gemini_worker_rate_limit_wait_seconds(['Retry-After' => '90'], '{}');
check($wait === 1800, 'a shorter provider retry hint cannot shorten the chosen 429 cooldown');
$GLOBALS['fixed_rand'] = 999999;

// A provider retry hint is never shortened, whether sent as a header or retryDelay.
$wait = evazar_gemini_worker_rate_limit_wait_seconds(['Retry-After' => '7200'], '{}');
check($wait === 7200, '429 honours Retry-After longer than one hour');
$wait = evazar_gemini_worker_rate_limit_wait_seconds([], '{"error":{"details":[{"retryDelay":"5400s"}]}}');
check($wait === 5400, '429 honours structured retryDelay longer than one hour');

// Confirm the parser is case-insensitive for header names.
$wait = evazar_gemini_provider_retry_after_seconds(['rEtRy-AfTeR' => '4800'], '{}');
check($wait === 4800, 'Retry-After header parsing is case-insensitive');

// Daily quota remains a separate long cooldown, not the 30–60 minute 429 policy.
check(evazar_is_gemini_quota_exhausted(429, '{"error":{"details":[{"@type":"type.googleapis.com/google.rpc.QuotaFailure","violations":[{"quotaId":"GenerateRequestsPerDayPerProjectPerModel"}]}]}}') === true, 'structured per-day quota is detected as daily quota');
check(evazar_is_gemini_quota_exhausted(429, '{"error":{"details":[{"@type":"type.googleapis.com/google.rpc.QuotaFailure","violations":[{"quotaId":"GenerateRequestsPerMinutePerProjectPerModel"}]}]}}') === false, 'per-minute quota is not misclassified as daily quota');

// Exponential 5xx backoff progresses through the agreed ranges for the same Worker.
$url = 'https://worker-a.example.workers.dev';
$expected = [600, 1200, 2400, 3600, 3600];
foreach ($expected as $i => $expectedMax) {
    $wait = evazar_gemini_worker_5xx_backoff_seconds($url, [], '{}');
    check($wait === $expectedMax, '5xx backoff stage ' . ($i + 1) . ' uses expected randomized range cap');
}
$wait = evazar_gemini_worker_5xx_backoff_seconds('https://worker-b.example.workers.dev', [], '{}');
check($wait === 600, 'another Worker starts with its own first-stage 5xx backoff');
$wait = evazar_gemini_worker_5xx_backoff_seconds($url, ['Retry-After' => '5400'], '{}');
check(evazar_gemini_worker_5xx_backoff_seconds('https://worker-c.example.workers.dev', ['Retry-After' => '60'], '{}') === 600, 'a shorter provider retry hint cannot shorten the 5xx backoff');
check($wait === 5400, '5xx backoff honours provider retry hint longer than jitter');
evazar_gemini_clear_worker_5xx_backoff($url);
$GLOBALS['fixed_rand'] = 0;
$wait = evazar_gemini_worker_5xx_backoff_seconds($url, [], '{}');
check($wait === 300, 'reset 5xx backoff respects the 5-minute first-stage lower bound');
evazar_gemini_clear_worker_5xx_backoff($url);
$GLOBALS['fixed_rand'] = 999999;
$wait = evazar_gemini_worker_5xx_backoff_seconds($url, [], '{}');
check($wait === 600, 'a sub-500 response reset starts the 5xx backoff sequence again');

// Worker-specific cooldown does not write the global rate-limit key.
$GLOBALS['transients'] = [];
$untilA = evazar_set_gemini_worker_rate_cooldown(2400, $url, 429, 'worker_rate_limit', 'test');
check($untilA >= time() + 2398, 'Worker cooldown is persisted for the selected Worker');
check(evazar_gemini_worker_rate_cooldown_until($url) === $untilA, 'selected Worker reads back its own cooldown');
check(evazar_gemini_rate_cooldown_until() === 0, 'Worker-specific cooldown does not create a global rate cooldown');
check(evazar_gemini_worker_rate_cooldown_until('https://worker-b.example.workers.dev') === 0, 'another Worker remains eligible');

// Static guards for the two key production paths, while testing the actual helper functions above.
$source = file_get_contents(__DIR__ . '/../importer.php');
$start = strpos($source, '} elseif ($http_status === 429');
$end = strpos($source, '} elseif ($http_status >= 400', $start ?: 0);
check($start !== false && $end !== false, 'idempotency-recovery 429 branch exists');
$recovery429 = substr($source, $start, $end - $start);
check(strpos($recovery429, 'evazar_set_gemini_worker_rate_cooldown') !== false, 'idempotency-recovery 429 uses per-Worker cooldown');
check(strpos($recovery429, 'evazar_set_gemini_rate_cooldown(') === false, 'idempotency-recovery 429 no longer sets legacy global cooldown');
check(strpos($source, 'if ($outcome_marker === \'retryable\')') !== false && strpos($source, 'evazar_gemini_worker_5xx_backoff_seconds($worker_url') !== false, '5xx paths use Worker-specific backoff');
check(strpos($source, 'if ($code < 500) evazar_gemini_clear_worker_5xx_backoff($worker_url);') !== false, 'a definitive non-5xx response resets the Worker 5xx streak');
check(strpos($source, 'evazar_set_gemini_worker_rate_cooldown($wait, $worker_url, $code, \'worker_unavailable\'') !== false, '5xx cooldown is persisted per Worker');
$worker = file_get_contents(__DIR__ . '/../worker/digikala-worker.js');
check(strpos($worker, "proxyHeaders['Retry-After'] = retryAfter") !== false, 'Worker continues forwarding Retry-After');
check(strpos($worker, "proxyHeaders['X-Evazar-Gemini-Outcome'] = 'retryable'") !== false, 'Worker marks confirmed upstream 5xx responses');
check(strpos($worker, "http_status: 429") !== false && strpos($worker, "status: 'retryable'") !== false, 'Worker retains the 429 idempotency response for Core recovery');

fwrite(STDOUT, "\nRESULT: {$GLOBALS['assertions']} assertions passed.\n");
