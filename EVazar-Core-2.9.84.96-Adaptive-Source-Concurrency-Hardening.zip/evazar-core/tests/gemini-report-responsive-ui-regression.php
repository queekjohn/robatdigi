<?php
/** Regression checks for compact responsive Gemini operation report. */
$root = dirname(__DIR__);
$core = file_get_contents($root . '/evazar-core.php');
$assertions = 0;
$failures = 0;
function evz_ui_check($name, $condition) {
    global $assertions, $failures;
    $assertions++;
    if (!$condition) {
        $failures++;
        fwrite(STDERR, "FAIL: {$name}\n");
    } else {
        echo "PASS: {$name}\n";
    }
}
$report_start = strpos($core, 'function evazar_gemini_ops_admin_page');
$report_end = strpos($core, '// ==========================================', $report_start + 30);
$report = $report_start !== false ? substr($core, $report_start, $report_end !== false ? $report_end - $report_start : null) : '';
evz_ui_check('plugin version bumped to 2.9.84.96', strpos($core, '* Version: 2.9.84.96') !== false);
evz_ui_check('responsive report cards are used', strpos($report, 'evz-gemini-report__grid') !== false && strpos($report, 'evz-gemini-card') !== false);
evz_ui_check('full details remain expandable', strpos($report, '<details class="evz-gemini-card__details">') !== false && strpos($report, 'جزئیات فنی و اطلاعات کامل') !== false);
evz_ui_check('main report no longer uses horizontally scrollable wide table wrapper', strpos($report, 'max-width:1200px;overflow-x:auto') === false && strpos($report, '<th>زمان (محلی وردپرس)</th>') === false);
evz_ui_check('long worker diagnostics wrap', strpos($report, 'overflow-wrap:anywhere') !== false && strpos($report, 'word-break:break-word') !== false);
evz_ui_check('mobile report becomes one column', strpos($report, '@media(max-width:782px)') !== false && strpos($report, 'grid-template-columns:minmax(0,1fr)') !== false);
evz_ui_check('error diagnostics include upstream and Worker version', strpos($report, 'وضعیت بالادستی v2') !== false && strpos($report, 'نسخه Worker') !== false);
evz_ui_check('queue metrics are available in expanded details', strpos($report, 'queue_run_success') !== false && strpos($report, 'queue_run_deferred') !== false);
evz_ui_check('settings-page compact event details avoid horizontal overflow', strpos($core, 'overflow-x:hidden; overflow-y:auto; overflow-wrap:anywhere; word-break:break-word;') !== false);

$inline_html_code_leak = false;
foreach (token_get_all($core) as $token) {
    if (is_array($token) && $token[0] === T_INLINE_HTML && strpos($token[1], 'if (!is_array($event)) continue;') !== false) {
        $inline_html_code_leak = true;
        break;
    }
}
evz_ui_check('report event loop code remains executable PHP, not raw HTML output', !$inline_html_code_leak);

if ($failures) {
    fwrite(STDERR, "{$failures}/{$assertions} failed\n");
    exit(1);
}
echo "{$assertions} assertions passed.\n";
