<?php
$core = file_get_contents(__DIR__ . '/../evazar-core.php');
$queue = file_get_contents(__DIR__ . '/../queue-manager.php');
$failures = 0;
function gbdd_check($label, $condition) {
    global $failures;
    echo ($condition ? "PASS" : "FAIL") . " - {$label}\n";
    if (!$condition) $failures++;
}
gbdd_check('Core version is 2.9.84.96', strpos($core, '* Version: 2.9.84.96') !== false);
gbdd_check('deferred batches create a dedicated operations event', strpos($queue, "evazar_gemini_log_event('queue_batch_deferred'") !== false);
gbdd_check('batch deferral event includes batch size and DKP identifiers', strpos($queue, '\'batch_size\' => min(50, count($entries))') !== false && strpos($queue, '\'dkps\' => array_slice($dkps, 0, 50)') !== false);
gbdd_check('batch deferral event includes error stage, code, HTTP and retry time', strpos($queue, "'error_stage' => 'batch_defer'") !== false && strpos($queue, "error_code") !== false && strpos($queue, 'HTTP:') !== false && strpos($queue, 'زمان تلاش مجدد:') !== false);
gbdd_check('uncertain parallel batches log once with the assigned worker', strpos($queue, 'evazar_queue_log_batch_deferred_event($chunk, $chunk_response, time() + 120') !== false && strpos($queue, '$assigned[$local_index]') !== false);
gbdd_check('uncertain serial batches log the sent chunk and assigned worker', strpos($queue, 'evazar_queue_log_batch_deferred_event($chunk, $responses, time() + 120') !== false && strpos($queue, '$assigned_worker_url') !== false);
gbdd_check('diagnostic redacts common credential values and Google API keys', strpos($queue, '[redacted-api-key]') !== false && strpos($queue, '[redacted]') !== false);
gbdd_check('operations report labels batch deferrals', strpos($core, "'queue_batch_deferred' => 'تعویق دسته Gemini'") !== false);

gbdd_check('parallel HTTP 413 diagnostics include exact request byte size and known limit', strpos($queue, '\'request_bytes\' => (int) ($request_sizes[$index] ?? 0)') !== false && strpos($queue, "['request_limit_bytes'] = 4194304") !== false);
gbdd_check('HTTP 413 response excerpt is sanitized and WordPress payload limit is distinguished', strpos($queue, 'evazar_queue_parallel_safe_response_excerpt') !== false && strpos($queue, 'wordpress_internal_payload_limit') !== false);
gbdd_check('deferred event includes request size, limit, endpoint code, and response excerpt', strpos($queue, 'اندازه درخواست:') !== false && strpos($queue, 'سقف بررسی‌شده:') !== false && strpos($queue, 'پاسخ سرور:') !== false);
if ($failures) exit(1);
echo "All Gemini batch deferral diagnostics regression checks passed.\n";
