<?php
/** Focused regression tests for randomized import-queue scheduling and cross-request run lock. */
if (!defined('ABSPATH')) define('ABSPATH', dirname(__DIR__) . '/');
if (!defined('MINUTE_IN_SECONDS')) define('MINUTE_IN_SECONDS', 60);

$GLOBALS['qrs_options'] = [];
$GLOBALS['qrs_events'] = [];
$GLOBALS['qrs_random_value'] = null;
$GLOBALS['qrs_token_counter'] = 0;
$GLOBALS['qrs_pass'] = 0;
$GLOBALS['qrs_fail'] = 0;

function add_action(...$args) {}
function add_filter(...$args) {}
if (!class_exists('WP_Error')) {
    class WP_Error {
        private $code; private $message; private $data;
        public function __construct($code, $message = '', $data = null) { $this->code = $code; $this->message = $message; $this->data = $data; }
        public function get_error_code() { return $this->code; }
        public function get_error_message($code = '') { return $this->message; }
        public function get_error_data($code = '') { return $this->data; }
    }
}
if (!function_exists('is_wp_error')) { function is_wp_error($value) { return $value instanceof WP_Error; } }
if (!function_exists('sanitize_key')) { function sanitize_key($value) { return strtolower(preg_replace('/[^a-z0-9_\-]/', '', (string)$value)); } }
if (!function_exists('absint')) { function absint($value) { return abs((int)$value); } }
function register_activation_hook(...$args) {}
function register_deactivation_hook(...$args) {}
function wp_cache_delete(...$args) { return true; }
function get_option($name, $default = false) {
    return array_key_exists($name, $GLOBALS['qrs_options']) ? $GLOBALS['qrs_options'][$name] : $default;
}
function update_option($name, $value, $autoload = null) {
    $old = $GLOBALS['qrs_options'][$name] ?? null;
    $GLOBALS['qrs_options'][$name] = $value;
    return $old !== $value;
}
function add_option($name, $value, $deprecated = '', $autoload = 'yes') {
    if (array_key_exists($name, $GLOBALS['qrs_options'])) return false;
    $GLOBALS['qrs_options'][$name] = $value;
    return true;
}
function delete_option($name) {
    if (!array_key_exists($name, $GLOBALS['qrs_options'])) return false;
    unset($GLOBALS['qrs_options'][$name]);
    return true;
}
function wp_rand($min, $max) {
    $v = $GLOBALS['qrs_random_value'];
    if ($v === null) return (int) $min;
    return max((int) $min, min((int) $max, (int) $v));
}
function wp_generate_password($length = 12, $special_chars = true, $extra_special_chars = false) {
    $GLOBALS['qrs_token_counter']++;
    return str_pad((string)$GLOBALS['qrs_token_counter'], (int)$length, 'x');
}
function wp_schedule_event($timestamp, $recurrence, $hook, $args = [], $wp_error = false) {
    $GLOBALS['qrs_events'][] = ['timestamp'=>(int)$timestamp, 'recurrence'=>$recurrence, 'hook'=>$hook, 'args'=>$args];
    return true;
}
function wp_schedule_single_event($timestamp, $hook, $args = [], $wp_error = false) {
    foreach ($GLOBALS['qrs_events'] as $event) {
        if ($event['hook'] === $hook && $event['timestamp'] === (int)$timestamp && empty($event['recurrence'])) return true;
    }
    $GLOBALS['qrs_events'][] = ['timestamp'=>(int)$timestamp, 'recurrence'=>'', 'hook'=>$hook, 'args'=>$args];
    return true;
}
function wp_next_scheduled($hook, $args = []) {
    $times = [];
    foreach ($GLOBALS['qrs_events'] as $event) if ($event['hook'] === $hook) $times[] = $event['timestamp'];
    return $times ? min($times) : false;
}
function wp_unschedule_event($timestamp, $hook, $args = [], $wp_error = false) {
    foreach ($GLOBALS['qrs_events'] as $i => $event) {
        if ($event['hook'] === $hook && $event['timestamp'] === (int)$timestamp) {
            unset($GLOBALS['qrs_events'][$i]);
            $GLOBALS['qrs_events'] = array_values($GLOBALS['qrs_events']);
            return true;
        }
    }
    return false;
}
class QrsWpdb {
    public $prefix = 'wp_';
    public $options = 'wp_options';
    private $prepared_args = [];
    public function prepare($query, ...$args) { $this->prepared_args = $args; return $query; }
    public function query($query) {
        if (stripos($query, 'DELETE FROM wp_options') === 0 && count($this->prepared_args) >= 2) {
            [$name, $value] = $this->prepared_args;
            if (($GLOBALS['qrs_options'][$name] ?? null) === $value) {
                unset($GLOBALS['qrs_options'][$name]);
                return 1;
            }
            return 0;
        }
        return false;
    }
}
$GLOBALS['wpdb'] = new QrsWpdb();

require_once dirname(__DIR__) . '/queue-manager.php';

function qrs_check($name, $passed) {
    echo ($passed ? 'PASS' : 'FAIL') . ' - ' . $name . "\n";
    if ($passed) $GLOBALS['qrs_pass']++; else $GLOBALS['qrs_fail']++;
}

qrs_check('default randomized interval lower bound is five minutes', evazar_queue_interval_min_minutes() === 5);
qrs_check('default randomized interval upper bound is ten minutes', evazar_queue_interval_max_minutes() === 10);
$queue_source_for_precision = file_get_contents(dirname(__DIR__) . '/queue-manager.php');
qrs_check('queue settings explain that interval timing has one-second granularity', strpos($queue_source_for_precision, 'با دقت یک ثانیه') !== false && strpos($queue_source_for_precision, 'evazar_queue_random_interval_seconds') !== false);

$GLOBALS['qrs_options']['evazar_queue_interval_min_minutes'] = 6;
$GLOBALS['qrs_options']['evazar_queue_interval_max_minutes'] = 9;
$GLOBALS['qrs_random_value'] = 8;
qrs_check('configured interval bounds are read from options', evazar_queue_interval_min_minutes() === 6 && evazar_queue_interval_max_minutes() === 9);
qrs_check('random interval selection stays within custom bounds', evazar_queue_random_interval_minutes() === 8);
$GLOBALS['qrs_options']['evazar_queue_interval_max_minutes'] = 3;
qrs_check('invalid max below min is clamped to min', evazar_queue_interval_max_minutes() === 6);

// New second-granularity behavior uses exact minute bounds converted to seconds.
$GLOBALS['qrs_options']['evazar_queue_interval_min_minutes'] = 5;
$GLOBALS['qrs_options']['evazar_queue_interval_max_minutes'] = 8;
$GLOBALS['qrs_random_value'] = 380;
qrs_check('second precision permits 6 minutes and 20 seconds within 5..8 minute bounds', evazar_queue_random_interval_seconds() === 380);
qrs_check('second precision formats 6 minutes and 20 seconds for logs', evazar_queue_format_interval_duration(380) === '6 دقیقه و 20 ثانیه');
$GLOBALS['qrs_random_value'] = 430;
qrs_check('second precision permits 7 minutes and 10 seconds within 5..8 minute bounds', evazar_queue_random_interval_seconds() === 430);
$GLOBALS['qrs_random_value'] = 299;
qrs_check('second precision clamps below configured lower endpoint', evazar_queue_random_interval_seconds() === 300);
$GLOBALS['qrs_random_value'] = 481;
qrs_check('second precision clamps above configured upper endpoint', evazar_queue_random_interval_seconds() === 480);
$GLOBALS['qrs_options']['evazar_queue_interval_min_minutes'] = 5;
$GLOBALS['qrs_options']['evazar_queue_interval_max_minutes'] = 5;
$GLOBALS['qrs_random_value'] = 315;
qrs_check('equal interval bounds remain an exact minute without hidden jitter', evazar_queue_random_interval_seconds() === 300);

$GLOBALS['qrs_options']['evazar_queue_interval_min_minutes'] = 5;
$GLOBALS['qrs_options']['evazar_queue_interval_max_minutes'] = 10;
$GLOBALS['qrs_random_value'] = 9 * 60;
$lock = evazar_queue_acquire_run_lock();
qrs_check('first request acquires persistent run lock', $lock !== '');
qrs_check('lock owner receives an initial heartbeat', (int) get_option(evazar_queue_run_lock_heartbeat_option_name($lock), 0) > 0);
qrs_check('second request cannot acquire overlapping run lock', evazar_queue_acquire_run_lock() === '');
$GLOBALS['qrs_options'][evazar_queue_run_lock_heartbeat_option_name($lock)] = time();
qrs_check('a heartbeat refresh is accepted only for the current owner', evazar_queue_heartbeat_run_lock($lock) && (int) get_option(evazar_queue_run_lock_heartbeat_option_name($lock), 0) >= time() - 1);
evazar_queue_release_run_lock($lock);
qrs_check('owning request releases the run lock and its heartbeat', get_option(evazar_queue_processing_lock_option_name(), '') === '' && get_option(evazar_queue_run_lock_heartbeat_option_name($lock), 0) === 0);

// A running queue older than the former 15-minute timestamp-only lease must survive if its heartbeat is fresh.
$active_old_lock = (time() - 20 * MINUTE_IN_SECONDS) . '|active-owner-token';
$GLOBALS['qrs_options'][evazar_queue_processing_lock_option_name()] = $active_old_lock;
$GLOBALS['qrs_options'][evazar_queue_run_lock_heartbeat_option_name($active_old_lock)] = time() - 10;
qrs_check('fresh heartbeat prevents takeover of an old but active run lock', evazar_queue_acquire_run_lock() === '');

// On CLI/unlimited PHP, stale locks use the longer 30-minute fallback; set age beyond the active lease.
$abandoned_lock = (time() - evazar_queue_run_lock_stale_after_seconds() - 60) . '|abandoned-token';
$GLOBALS['qrs_options'][evazar_queue_processing_lock_option_name()] = $abandoned_lock;
$GLOBALS['qrs_options'][evazar_queue_run_lock_heartbeat_option_name($abandoned_lock)] = time() - evazar_queue_run_lock_stale_after_seconds() - 60;
$recovered_lock = evazar_queue_acquire_run_lock();
qrs_check('abandoned lock is reclaimed only after its heartbeat lease expires', $recovered_lock !== '' && get_option(evazar_queue_processing_lock_option_name(), '') === $recovered_lock);
evazar_queue_release_run_lock($recovered_lock);

$lock = evazar_queue_acquire_run_lock();
$previous_due = time() - 12 * 60;
$GLOBALS['qrs_options']['evazar_queue_next_auto_run_at'] = $previous_due;
$run_timing = evazar_queue_begin_run_interval($lock, false);
$next = evazar_queue_next_auto_run_at();
$delta = $next - (int) ($run_timing['started_at'] ?? 0);
qrs_check('next auto time uses randomized exact seconds and preserves legacy minute option', get_option('evazar_queue_last_random_interval_minutes', 0) === 9 && get_option('evazar_queue_last_random_interval_seconds', 0) === 9 * 60 && (int) ($run_timing['interval_seconds'] ?? 0) === 9 * 60 && $delta === 9 * 60 && (int) ($run_timing['next_run_at'] ?? 0) === $next);
qrs_check('run start diagnostics capture 12-minute cron delay', (int) ($run_timing['start_lag_seconds'] ?? 0) >= 12 * 60 - 1 && (int) get_option('evazar_queue_last_run_start_lag_seconds', 0) >= 12 * 60 - 1);
$fixed_next = evazar_queue_next_auto_run_at();
sleep(1);
evazar_queue_finalize_auto_interval($lock);
qrs_check('finalizer records finish/duration without moving the start-based next run', evazar_queue_next_auto_run_at() === $fixed_next && (int) get_option('evazar_queue_last_run_finished_at', 0) > 0 && (int) get_option('evazar_queue_last_run_duration_seconds', -1) >= 1);
qrs_check('interval finalizer does nothing for a foreign lock token', (function() { $before=evazar_queue_next_auto_run_at(); evazar_queue_finalize_auto_interval('foreign-token'); return evazar_queue_next_auto_run_at() === $before; })());
evazar_queue_release_run_lock($lock);

$lock = evazar_queue_acquire_run_lock();
$manual_timing = evazar_queue_begin_run_interval($lock, true);
qrs_check('manual runs also establish the next safe automatic timestamp from their start using exact seconds', ($manual_timing['trigger'] ?? '') === 'manual' && evazar_queue_next_auto_run_at() === ((int)$manual_timing['started_at'] + (int)$manual_timing['interval_seconds']));
evazar_queue_release_run_lock($lock);

$GLOBALS['qrs_events'] = [];
$GLOBALS['qrs_random_value'] = 7 * 60 + 10;
evazar_queue_reschedule_cron();
$scheduled = wp_next_scheduled('evazar_process_import_queue');
qrs_check('reschedule creates the recurring safety-net event', $scheduled !== false);
qrs_check('reschedule migrates event schema to version four for second-granularity scheduling', get_option('evazar_queue_cron_schedule_version', 0) === 4);
qrs_check('reschedule selects exact randomized seconds and preserves legacy minute option', get_option('evazar_queue_last_random_interval_minutes', 0) === 7 && get_option('evazar_queue_last_random_interval_seconds', 0) === 7 * 60 + 10 && abs(($scheduled - time()) - (7 * 60 + 10)) <= 1);

// The initial schedule path must also use seconds precision, not just run-start and reschedule.
$GLOBALS['qrs_events'] = [];
$GLOBALS['qrs_options']['evazar_queue_interval_min_minutes'] = 5;
$GLOBALS['qrs_options']['evazar_queue_interval_max_minutes'] = 8;
$GLOBALS['qrs_random_value'] = 6 * 60 + 20;
delete_option('evazar_queue_next_auto_run_at');
delete_option('evazar_queue_last_random_interval_seconds');
evazar_queue_schedule_cron();
$initial_scheduled = wp_next_scheduled('evazar_process_import_queue');
qrs_check('initial cron schedule sets a 6m20s next run', $initial_scheduled !== false && abs(($initial_scheduled - time()) - 380) <= 1 && get_option('evazar_queue_last_random_interval_seconds', 0) === 380);
$GLOBALS['qrs_options']['evazar_queue_interval_min_minutes'] = 5;
$GLOBALS['qrs_options']['evazar_queue_interval_max_minutes'] = 10;

$GLOBALS['qrs_events'] = [];
$when = time() + 600;
evazar_queue_schedule_followup_at($when);
evazar_queue_schedule_followup_at($when + 120);
$followups = array_values(array_filter($GLOBALS['qrs_events'], function($e) { return $e['hook'] === 'evazar_process_import_queue_followup'; }));
qrs_check('follow-up scheduling keeps only one pending event', count($followups) === 1);

$custom = evazar_cron_add_schedule([]);
qrs_check('recurring safety tick uses the configured minimum bound', isset($custom['evazar_queue_custom_schedule']['interval']) && $custom['evazar_queue_custom_schedule']['interval'] === 300);

// Source-failure policy: global rate/access restrictions pause the run; transient source failures are item-scoped.
$source_429 = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'source rate limited', [
    'error_scope' => 'source', 'source_error_code' => 'source_rate_limited', 'retry_after_seconds' => 30,
    'code' => 'worker_upstream_source_rate_limited',
]);
$policy_429 = evazar_queue_upstream_source_failure_policy($source_429);
qrs_check('source 429 is marked run-wide and deferred at least 60 seconds without retry increment', ($policy_429['queue_error_code'] ?? '') === 'DIGIKALA_SOURCE_RATE_LIMITED' && ($policy_429['action'] ?? '') === 'defer_run' && (int)($policy_429['delay_seconds'] ?? 0) === 60);
$source_long_retry = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'source rate limited', [
    'error_scope' => 'source', 'source_error_code' => 'source_rate_limited', 'retry_after_seconds' => 9000,
    'code' => 'worker_upstream_source_rate_limited',
]);
$policy_long_retry = evazar_queue_upstream_source_failure_policy($source_long_retry);
qrs_check('source retry delay is capped at 15 minutes', (int)($policy_long_retry['delay_seconds'] ?? 0) === 900);
$source_forbidden = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'source forbidden', [
    'error_scope' => 'source', 'source_error_code' => 'source_request_rejected', 'upstream_status_v2' => 403, 'code' => 'worker_upstream_source_request_rejected',
]);
$policy_forbidden = evazar_queue_upstream_source_failure_policy($source_forbidden);
qrs_check('source access rejection remains run-wide and pauses longer than a transient network failure', (int)($policy_forbidden['delay_seconds'] ?? 0) === 300 && ($policy_forbidden['queue_error_code'] ?? '') === 'DIGIKALA_SOURCE_REJECTED' && ($policy_forbidden['action'] ?? '') === 'defer_run');
$source_product_rejected = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'bad product request', [
    'error_scope' => 'source', 'source_error_code' => 'source_request_rejected', 'upstream_status_v2' => 400, 'code' => 'worker_upstream_source_request_rejected',
]);
qrs_check('non-access 4xx rejection is item-scoped rather than queue-wide', (evazar_queue_upstream_source_failure_policy($source_product_rejected)['action'] ?? '') === 'defer_item');
$source_network = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'source timeout', [
    'error_scope' => 'source', 'source_error_code' => 'source_fetch_failed', 'code' => 'worker_upstream_source_fetch_failed',
]);
$policy_network = evazar_queue_upstream_source_failure_policy($source_network);
qrs_check('temporary source network failure defers only the affected product for 60 seconds', (int)($policy_network['delay_seconds'] ?? 0) === 60 && ($policy_network['queue_error_code'] ?? '') === 'DIGIKALA_SOURCE_UNAVAILABLE' && ($policy_network['action'] ?? '') === 'defer_item');
$product_404 = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'product not found', [
    'error_scope' => 'product', 'source_error_code' => 'product_not_found', 'code' => 'product_not_found',
]);
qrs_check('product-specific 404 does not pause the entire queue', evazar_queue_upstream_source_failure_policy($product_404) === []);
$worker_transport = new WP_Error('worker_transport_error', 'network to Worker failed', [
    'code' => 'worker_transport_error',
]);
qrs_check('Worker transport errors are not misclassified as Digikala source errors', evazar_queue_upstream_source_failure_policy($worker_transport) === []);
$gemini_error = new WP_Error('gemini_rate_limited', 'Gemini throttled', ['resume_at' => time() + 60]);
qrs_check('Gemini rate-limit handling remains separate from Digikala source policy', evazar_queue_upstream_source_failure_policy($gemini_error) === []);
$source_502 = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'upstream 502', [
    'error_scope' => 'source', 'source_error_code' => 'source_server_error',
    'upstream_status_v2' => 502, 'code' => 'worker_upstream_source_server_error',
]);
$policy_502 = evazar_queue_upstream_source_failure_policy($source_502);
qrs_check('single upstream 502 is item-scoped, not a whole-run stop', ($policy_502['action'] ?? '') === 'defer_item' && ($policy_502['queue_error_code'] ?? '') === 'DIGIKALA_SOURCE_UNAVAILABLE');
$source_worker_503_upstream_502 = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'Worker HTTP 503; Digikala v2 HTTP 502', [
    'error_scope' => 'source', 'source_error_code' => 'source_server_error',
    'http_code' => 503, 'upstream_status_v2' => 502, 'upstream_status_v1' => 0,
    'worker_version' => '1.13.27', 'code' => 'worker_upstream_source_server_error',
]);
$policy_worker_503_upstream_502 = evazar_queue_upstream_source_failure_policy($source_worker_503_upstream_502);
qrs_check('Worker HTTP 503 caused by upstream v2=502 is deferred for this product only', ($policy_worker_503_upstream_502['action'] ?? '') === 'defer_item' && ($policy_worker_503_upstream_502['queue_error_code'] ?? '') === 'DIGIKALA_SOURCE_UNAVAILABLE' && (int)($policy_worker_503_upstream_502['delay_seconds'] ?? 0) === 60);
$source_invalid_payload = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'bad payload', [
    'error_scope' => 'source', 'source_error_code' => 'source_product_payload_missing', 'code' => 'worker_upstream_source_product_payload_missing',
]);
qrs_check('invalid/missing product payload is item-scoped', (evazar_queue_upstream_source_failure_policy($source_invalid_payload)['action'] ?? '') === 'defer_item');
$queue_source = file_get_contents(dirname(__DIR__) . '/queue-manager.php');
qrs_check('queue has a per-item source deferral path keyed by current queue item id', strpos($queue_source, 'item_updated = $wpdb->update') !== false && strpos($queue_source, "'action'] ?? 'defer_item'") !== false);
qrs_check('queue circuit-breaks only after three consecutive transient source failures', strpos($queue_source, '$consecutive_source_failures >= 3') !== false && strpos($queue_source, 'array_slice($items, $item_index + 1)') !== false);
qrs_check('source 502 path no longer bulk-updates every claimed item', strpos($queue_source, "['status' => 'processing', 'claim_token' => " . '$claim_token') !== false && strpos($queue_source, "source_policy['action']") !== false);
$checkpoint_start = strpos($queue_source, 'if (is_array($result) && !empty($result[\'__evazar_ai_batch_checkpoint\'])');
$checkpoint_end = ($checkpoint_start === false) ? false : strpos($queue_source, 'if (is_wp_error($result))', $checkpoint_start);
$checkpoint_block = ($checkpoint_start !== false && $checkpoint_end !== false) ? substr($queue_source, $checkpoint_start, $checkpoint_end - $checkpoint_start) : '';
qrs_check('successful Gemini checkpoint applies the 300ms spacing before its early continue', strpos($checkpoint_block, 'usleep(300000)') !== false && strpos($checkpoint_block, 'usleep(300000)') < strpos($checkpoint_block, 'continue;'));
qrs_check('source queue cadence no longer labels the next interval as completion-based', strpos($queue_source, 'از پایان اجرای قبلی محاسبه می‌شود') === false && strpos($queue_source, 'از شروع اجرای قبلی محاسبه می‌شود') !== false);


// Automatic queue calls before the saved random not-before timestamp must not acquire the run lock.
$GLOBALS['qrs_events'] = [];
$GLOBALS['qrs_options']['evazar_import_queue_manual_paused'] = 'no';
$GLOBALS['qrs_options']['evazar_queue_next_auto_run_at'] = time() + 420;
$result = evazar_cron_worker_logic(false);
$scheduled_followup = wp_next_scheduled('evazar_process_import_queue_followup');
qrs_check('early automatic invocation exits without processing and schedules the not-before follow-up', is_array($result) && (int)($result['processed'] ?? -1) === 0 && $scheduled_followup >= $GLOBALS['qrs_options']['evazar_queue_next_auto_run_at'] - 1);
qrs_check('early automatic invocation does not acquire a queue-run lock', get_option(evazar_queue_processing_lock_option_name(), '') === '');

echo "\nRESULT: {$GLOBALS['qrs_pass']} passed, {$GLOBALS['qrs_fail']} failed\n";
exit($GLOBALS['qrs_fail'] ? 1 : 0);
