<?php
/** Regression tests for isolating missing Digikala source-category paths from the active import queue. */
error_reporting(E_ALL);
ini_set('display_errors', '1');
if (!defined('ABSPATH')) define('ABSPATH', dirname(__DIR__) . '/');
if (!defined('MINUTE_IN_SECONDS')) define('MINUTE_IN_SECONDS', 60);
if (!defined('HOUR_IN_SECONDS')) define('HOUR_IN_SECONDS', 3600);
if (!defined('DAY_IN_SECONDS')) define('DAY_IN_SECONDS', 86400);
$GLOBALS['qsc_options'] = [];
$GLOBALS['qsc_assertions'] = 0;
function add_action(...$args) {}
function add_filter(...$args) {}
function register_activation_hook(...$args) {}
function register_deactivation_hook(...$args) {}
function sanitize_key($value) { $value = strtolower((string) $value); return preg_replace('/[^a-z0-9_\-]/', '', $value); }
function sanitize_text_field($value) { return trim(strip_tags((string) $value)); }
function sanitize_textarea_field($value) { return trim(strip_tags((string) $value)); }
function absint($value) { return abs((int) $value); }
function get_option($name, $default = false) { return array_key_exists($name, $GLOBALS['qsc_options']) ? $GLOBALS['qsc_options'][$name] : $default; }
function update_option($name, $value, $autoload = null) { $GLOBALS['qsc_options'][$name] = $value; return true; }
function delete_transient($name) { return true; }
function current_time($type = 'mysql', $gmt = false) { return '2026-10-27 02:00:00'; }
if (!function_exists('wp_parse_url')) { function wp_parse_url($url) { return parse_url((string) $url); } }
if (!function_exists('trailingslashit')) { function trailingslashit($value) { return rtrim((string) $value, '/') . '/'; } }
$GLOBALS['qsc_posts'] = [];
$GLOBALS['qsc_post_meta'] = [];
function get_post($post_id) { return $GLOBALS['qsc_posts'][(int) $post_id] ?? null; }
function get_post_meta($post_id, $key, $single = true) { return $GLOBALS['qsc_post_meta'][(int) $post_id][$key] ?? ''; }
function get_post_thumbnail_id($post_id) { return 0; }
function wp_get_object_terms($post_id, $taxonomy, $args = []) { return []; }
function wp_update_post($data, $wp_error = false) { $id = (int) ($data['ID'] ?? 0); if (!isset($GLOBALS['qsc_posts'][$id])) return 0; foreach ($data as $key => $value) { if ($key !== 'ID') $GLOBALS['qsc_posts'][$id]->{$key} = $value; } return $id; }
function update_post_meta($post_id, $key, $value) { $GLOBALS['qsc_post_meta'][(int) $post_id][$key] = $value; return true; }
function check_qsc($name, $passed) {
    $GLOBALS['qsc_assertions']++;
    if (!$passed) { fwrite(STDERR, "FAIL: {$name}\n"); exit(1); }
    echo "PASS: {$name}\n";
}
if (!function_exists('is_wp_error')) {
    function is_wp_error($value) { return $value instanceof WP_Error; }
}
if (!class_exists('WP_Error')) {
    class WP_Error {
        private $code; private $message; private $data;
        public function __construct($code, $message = '', $data = null) { $this->code = $code; $this->message = $message; $this->data = $data; }
        public function get_error_code() { return $this->code; }
        public function get_error_message($code = '') { return $this->message; }
        public function get_error_data($code = '') { return ($code === '' || $code === $this->code) ? $this->data : null; }
    }
}
require_once __DIR__ . '/../importer.php';
require_once __DIR__ . '/../queue-manager.php';

$valid_items = evazar_collect_validated_product_category_source_items([
    ['title' => 'کالای دیجیتال', 'url' => 'https://www.digikala.com/search/electronic-devices/'],
], '');
check_qsc('explicit valid source category URLs pass the reusable preflight validator', is_array($valid_items) && count($valid_items) === 1 && $valid_items[0]['uri'] === '/search/electronic-devices/');
$missing_items = evazar_collect_validated_product_category_source_items([], '');
check_qsc('no category name or breadcrumbs fail preflight with source-missing code', is_wp_error($missing_items) && $missing_items->get_error_code() === 'PRODUCT_CATEGORY_SOURCE_MISSING');
$title_only_items = evazar_collect_validated_product_category_source_items([['title' => 'گوشی موبایل', 'url' => '']], 'گوشی موبایل');
check_qsc('title-only category with no explicit path fails preflight before any save', is_wp_error($title_only_items) && $title_only_items->get_error_code() === 'PRODUCT_CATEGORY_SOURCE_PATH_MISSING');
$importer_source = file_get_contents(__DIR__ . '/../importer.php');
$unlocked_start = strpos($importer_source, 'function evazar_core_process_import_unlocked');
$preflight_at = strpos($importer_source, '$source_category_preflight = evazar_collect_validated_product_category_source_items', $unlocked_start ?: 0);
$ai_at = strpos($importer_source, '// 3. هوش مصنوعی', $unlocked_start ?: 0);
$checkpoint_at = strpos($importer_source, "'__evazar_ai_batch_checkpoint' => true", $unlocked_start ?: 0);
$post_write_at = strpos($importer_source, 'wp_insert_post([', $unlocked_start ?: 0);
check_qsc('category preflight runs before Gemini, batch checkpoint, and new product insertion', $preflight_at !== false && $ai_at !== false && $checkpoint_at !== false && $post_write_at !== false && $preflight_at < $ai_at && $preflight_at < $checkpoint_at && $preflight_at < $post_write_at);
check_qsc('preflight error payload says no save occurred and retains quarantine routing metadata', strpos($importer_source, "'saved' => false") !== false && strpos($importer_source, "'quarantine_reason' => 'source_category_path_missing'") !== false && strpos($importer_source, "'validation_stage' => 'source_preflight'") !== false);

// Explicit admin action for an already-existing partial product is reversible and non-destructive.
$GLOBALS['qsc_posts'][8765] = (object) ['ID' => 8765, 'post_type' => 'evazar_product', 'post_status' => 'publish', 'post_content' => '', 'post_title' => 'Placeholder'];
$draft_result = evazar_queue_draft_quarantined_product(8765);
check_qsc('manual quarantine action can move an existing product to Draft without deleting it', is_array($draft_result) && !empty($draft_result['success']) && ($GLOBALS['qsc_posts'][8765]->post_status ?? '') === 'draft' && get_post(8765) !== null);
$legacy_saved_row = (object) ['error_log' => 'نیازمند بررسی دستی؛ جزئیات اصلی: اطلاعات کالا ذخیره شد، اما همگام‌سازی/تأیید دسته‌بندی ناموفق بود. مسیر دسته‌بندی مبدأ موجود نیست.'];
check_qsc('legacy post-save category failure is explicitly eligible for the manual Draft action', evazar_queue_quarantine_row_has_saved_partial_product($legacy_saved_row));
$preflight_row = (object) ['error_log' => 'نیازمند بررسی دستی؛ جزئیات اصلی: محصول پیش از ارسال به Gemini و پیش از هرگونه ذخیره‌سازی جدید/به‌روزرسانی متوقف شد؛ مسیر دسته‌بندی مبدأ قابل‌تأیید نیست.'];
check_qsc('new source preflight quarantine never offers Draft for an existing related product', !evazar_queue_quarantine_row_has_saved_partial_product($preflight_row));
check_qsc('unknown quarantine messages default to no destructive status action', !evazar_queue_quarantine_row_has_saved_partial_product((object) ['error_log' => 'خطای نامشخص در دریافت دسته‌بندی']));
$GLOBALS['qsc_posts'][8766] = (object) ['ID' => 8766, 'post_type' => 'post', 'post_status' => 'publish', 'post_content' => '', 'post_title' => 'Not an EVazar product'];
$wrong_type_draft = evazar_queue_draft_quarantined_product(8766);
check_qsc('manual quarantine draft action refuses a non-EVazar post type', is_wp_error($wrong_type_draft) && ($GLOBALS['qsc_posts'][8766]->post_status ?? '') === 'publish');

$missing_category = new WP_Error('PRODUCT_CATEGORY_SYNC_FAILED', 'دسته‌بندی مبدأ موجود نیست.', [
    'post_id' => 8765, 'category_error_code' => 'PRODUCT_CATEGORY_SOURCE_MISSING',
    'quarantine_reason' => 'source_category_path_missing',
]);
check_qsc('explicit missing source-category metadata is quarantined', evazar_queue_category_source_quarantine_reason($missing_category) === 'SOURCE_CATEGORY_PATH_MISSING');

$missing_path = new WP_Error('PRODUCT_CATEGORY_SYNC_FAILED', 'URL مبدأ دریافت نشد.', [
    'post_id' => 8766, 'category_error_code' => 'PRODUCT_CATEGORY_SOURCE_PATH_MISSING',
]);
check_qsc('explicit missing source category URL is quarantined', evazar_queue_category_source_quarantine_reason($missing_path) === 'SOURCE_CATEGORY_PATH_MISSING');

$db_sync_error = new WP_Error('PRODUCT_CATEGORY_SYNC_FAILED', 'خطای دیتابیس در همگام‌سازی دسته.', [
    'post_id' => 8767, 'category_error_code' => 'PRODUCT_CATEGORY_TERM_SYNC_FAILED',
]);
check_qsc('generic category database/term sync failures stay retryable and are not quarantined', evazar_queue_category_source_quarantine_reason($db_sync_error) === '');

$worker_502 = new WP_Error('EVAZAR_WORKER_PRODUCT_UNAVAILABLE', 'خطای 502.', ['error_scope' => 'source', 'source_error_code' => 'source_server_error', 'http_code' => 502]);
check_qsc('a Worker source 502 is not misclassified as missing category-path quarantine', evazar_queue_category_source_quarantine_reason($worker_502) === '');
check_qsc('automatic requeue is off by default', evazar_queue_category_quarantine_auto_retry_days() === 0);
$GLOBALS['qsc_options']['evazar_queue_category_quarantine_auto_retry_days'] = 7;
check_qsc('allowed automatic retry interval is honored', evazar_queue_category_quarantine_auto_retry_days() === 7);
$GLOBALS['qsc_options']['evazar_queue_category_quarantine_auto_retry_days'] = 5;
check_qsc('unsupported automatic retry interval is safely disabled', evazar_queue_category_quarantine_auto_retry_days() === 0);

$queue = file_get_contents(__DIR__ . '/../queue-manager.php');
$importer = file_get_contents(__DIR__ . '/../importer.php');
$core = file_get_contents(__DIR__ . '/../evazar-core.php');
check_qsc('only explicit source category path codes are wrapped with quarantine reason', strpos($importer, "'PRODUCT_CATEGORY_SOURCE_MISSING'") !== false && strpos($importer, "'PRODUCT_CATEGORY_SOURCE_PATH_MISSING'") !== false && strpos($importer, "'quarantine_reason' => \$missing_source_category_path ? 'source_category_path_missing' : ''") !== false);
check_qsc('queue migration is one-time and matches only the known missing-source-path legacy messages', strpos($queue, 'evazar_queue_category_path_quarantine_migration_v1') !== false && strpos($queue, 'اطلاعات مسیر مبدأ دسته‌بندی از دیجی‌کالا دریافت نشد') !== false && strpos($queue, 'URL معتبر مبدأ برای دسته‌بندی') !== false);
check_qsc('newly encountered source-path error moves current claimed row to quarantined and keeps the related saved product ID', strpos($queue, "'status' => 'quarantined'") !== false && strpos($queue, "'related_product_id' => \$related_product_id") !== false && strpos($queue, "'error_code' => \$category_quarantine_code") !== false);
check_qsc('quarantine retry only promotes the exact source-path reason and due rows', strpos($queue, "WHERE status='quarantined' AND error_code='SOURCE_CATEGORY_PATH_MISSING' AND next_attempt_at IS NOT NULL AND next_attempt_at <= %s") !== false);
check_qsc('automatic quarantine recheck resets the retry generation so old failures cannot prematurely exhaust retries', strpos($queue, "SET status='pending', retries=0, error_code=''") !== false);
check_qsc('legacy migration preserves any existing related product ID rather than overwriting it with zero', strpos($queue, "SET status='quarantined', error_code='SOURCE_CATEGORY_PATH_MISSING', related_product_id=0") === false);
check_qsc('all eight early queue return counters include quarantined rows', substr_count($queue, "'processed' => \$success_cnt + \$failed_cnt + \$deferred_cnt + \$quarantined_cnt,") === 8 && strpos($queue, "'processed' => \$success_cnt + \$failed_cnt + \$deferred_cnt,") === false);
check_qsc('quarantine, exclude, and requeue-excluded admin operations are implemented', strpos($queue, "case 'retry_quarantined_item':") !== false && strpos($queue, "case 'exclude_quarantined_item':") !== false && strpos($queue, "case 'requeue_excluded_item':") !== false);
check_qsc('queue UI exposes quarantine/excluded tabs and row actions', strpos($queue, 'قرنطینهٔ بررسی') !== false && strpos($queue, 'خارج‌شده از صف') !== false && strpos($queue, 'data-action="retry_quarantined_item"') !== false && strpos($queue, 'data-action="exclude_quarantined_item"') !== false && strpos($queue, 'data-action="requeue_excluded_item"') !== false);
check_qsc('queue UI exposes an explicit non-destructive Draft action only for linked source-path quarantine', strpos($queue, "case 'draft_quarantined_product':") !== false && strpos($queue, 'data-action="draft_quarantined_product"') !== false && strpos($queue, "(string) (\$item->error_code ?? '') === 'SOURCE_CATEGORY_PATH_MISSING'") !== false);
$endpoint_start = strpos($queue, 'function evazar_rest_existing_dkps');
$endpoint_end = strpos($queue, 'function evazar_rest_queue_ingest', $endpoint_start ?: 0);
$endpoint = ($endpoint_start !== false && $endpoint_end !== false) ? substr($queue, $endpoint_start, $endpoint_end - $endpoint_start) : '';
$reserved_start = strpos($endpoint, '$reserved_dkps =');
$reserved_end = strpos($endpoint, '));', $reserved_start ?: 0);
$reserved_block = ($reserved_start !== false && $reserved_end !== false) ? substr($endpoint, $reserved_start, $reserved_end - $reserved_start) : '';
check_qsc('quarantined and excluded DKPs are reserved from Harvester while failed rows stay retriable', $endpoint !== '' && strpos($reserved_block, '$quarantined_dkps') !== false && strpos($reserved_block, '$excluded_dkps') !== false && strpos($endpoint, "'quarantined_dkps' => \$quarantined_dkps") !== false && strpos($endpoint, "'excluded_dkps' => \$excluded_dkps") !== false && strpos($endpoint, "'quarantined' => count(\$quarantined_dkps)") !== false && strpos($endpoint, "'excluded' => count(\$excluded_dkps)") !== false && strpos($reserved_block, '$failed_dkps') === false);
check_qsc('automatic quarantine retry is configurable with default off', strpos($queue, "get_option('evazar_queue_category_quarantine_auto_retry_days', 0)") !== false && strpos($queue, 'evazar_queue_category_quarantine_auto_retry_days') !== false);
check_qsc('quarantined status and category source code appear in queue admin', strpos($queue, "'quarantined'") !== false && strpos($queue, 'SOURCE_CATEGORY_PATH_MISSING') !== false);
check_qsc('Draft endpoint validates that the quarantined attempt actually saved a partial product before changing post status', strpos($queue, '!evazar_queue_quarantine_row_has_saved_partial_product($row)') !== false);
check_qsc('Draft button is hidden for preflight-only quarantines that did not save/update the product', strpos($queue, '&& evazar_queue_quarantine_row_has_saved_partial_product($item)') !== false);
check_qsc('plugin version is 2.9.84.96', strpos($core, '* Version: 2.9.84.96') !== false);

fwrite(STDOUT, "\nRESULT: {$GLOBALS['qsc_assertions']} assertions passed.\n");
