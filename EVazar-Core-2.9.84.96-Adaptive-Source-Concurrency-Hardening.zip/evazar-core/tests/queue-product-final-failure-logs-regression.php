<?php
// Static regression checks for per-product final failure diagnostics.
$queue = file_get_contents(__DIR__ . '/../queue-manager.php');
$core = file_get_contents(__DIR__ . '/../evazar-core.php');
function check_qpfl($label, $ok) { if (!$ok) { fwrite(STDERR, "FAIL: $label\n"); exit(1); } echo "PASS: $label\n"; }
check_qpfl('failed finalization records a per-product event', strpos($queue, 'evazar_queue_log_final_product_failure($item, $err_code, $err_msg, $failure_saved)') !== false);
check_qpfl('failure event carries DKP, queue ID, stage, code and real reason', strpos($queue, '\'queue_item_id\' => $queue_id') !== false && strpos($queue, "'error_stage' => 'gemini_finalize'") !== false && strpos($queue, '\'diagnostic_detail\' => $detail') !== false);
check_qpfl('admin labels per-product final failure', strpos($core, "'queue_product_final_failure' => 'خطای نهایی محصول'") !== false);

$importer = file_get_contents(__DIR__ . '/../importer.php');
check_qpfl('final failures are mirrored to the 200-entry Import Logs file', strpos($queue, "evazar_import_log('error', \$message, \$dkp") !== false && strpos($queue, "'source' => 'queue_batch_final_failure'") !== false && strpos($importer, 'function evazar_import_log') !== false);
check_qpfl('pre-Gemini failures are mirrored to the same Import Logs file', strpos($queue, "'source' => 'queue_batch_pre_gemini_failure'") !== false);
