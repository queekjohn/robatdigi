<?php
/** Lightweight regression tests for brand ID selection. Run: php tests/brand-selector-regression.php */
define('ABSPATH', __DIR__ . '/');
$GLOBALS['brand_selector_terms'] = [
    10 => (object) ['term_id' => 10, 'name' => 'سالومون', 'slug' => 'salomon'],
    11 => (object) ['term_id' => 11, 'name' => 'سالومون', 'slug' => 'salomon-pc'],
    12 => (object) ['term_id' => 12, 'name' => 'سامسونگ', 'slug' => 'samsung'],
];
$GLOBALS['brand_selector_current'] = [];
$GLOBALS['brand_selector_written'] = null;
$GLOBALS['brand_selector_actions'] = [];
$GLOBALS['brand_selector_current_by_post'] = [];
$GLOBALS['brand_selector_post_meta'] = [];
$GLOBALS['brand_selector_fail_meta_key'] = '';
$GLOBALS['brand_selector_term_meta'] = [
    10 => ['_evazar_brand_en' => 'Salomon'],
    11 => ['_evazar_brand_en' => 'Salomon PC'],
    12 => ['_evazar_brand_en' => 'Samsung'],
];
function add_action(...$args) { $GLOBALS['brand_selector_actions'][] = $args; }
function add_filter(...$args) {}
function get_term($id, $taxonomy = '') { return $taxonomy === 'evazar_brand' ? ($GLOBALS['brand_selector_terms'][(int) $id] ?? null) : null; }
function get_term_meta($term_id, $key, $single = true) { return $GLOBALS['brand_selector_term_meta'][(int) $term_id][$key] ?? ''; }
function get_post_meta($post_id, $key, $single = true) { return $GLOBALS['brand_selector_post_meta'][(int) $post_id][$key] ?? ''; }
function update_post_meta($post_id, $key, $value) { if (($GLOBALS['brand_selector_fail_meta_key'] ?? '') === (string)$key) return false; $GLOBALS['brand_selector_post_meta'][(int) $post_id][$key] = $value; return true; }
function delete_post_meta($post_id, $key) { unset($GLOBALS['brand_selector_post_meta'][(int) $post_id][$key]); return true; }
function is_wp_error($value) { return false; }
function absint($value) { return abs((int) $value); }
function current_user_can($cap, ...$args) { return true; }
function wp_is_post_revision($id) { return false; }
function wp_is_post_autosave($id) { return false; }
function wp_unslash($value) { return $value; }
function sanitize_text_field($value) { return trim((string) $value); }
function sanitize_key($value) { return preg_replace('/[^a-z0-9_\-]/', '', strtolower((string) $value)); }
function esc_html($value) { return (string) $value; }
function esc_attr($value) { return (string) $value; }
function get_taxonomy($name) { return $name === 'evazar_brand' ? (object) ['cap' => (object) ['assign_terms' => 'assign_terms']] : null; }
function wp_verify_nonce($nonce, $action) { return $nonce === 'valid' && $action === 'evazar_brand_selector_save'; }
function wp_create_nonce($action) { return $action === 'evazar_brand_selector_save' ? 'valid' : 'other'; }
function get_post_type($post_id) { return 'evazar_product'; }
function wp_get_object_terms($post_id, $taxonomy, $args = []) { return $GLOBALS['brand_selector_current_by_post'][$post_id] ?? $GLOBALS['brand_selector_current']; }
function wp_set_object_terms($post_id, $terms, $taxonomy, $append = false) { $ids = array_values(array_map('intval', (array) $terms)); $GLOBALS['brand_selector_written'] = ['post_id' => $post_id, 'terms' => $ids, 'taxonomy' => $taxonomy, 'append' => $append]; $GLOBALS['brand_selector_current_by_post'][$post_id] = $ids; return ['ok']; }
class BrandSelectorTestRequest {
    private $params;
    public function __construct($params) { $this->params = $params; }
    public function has_param($name) { return array_key_exists($name, $this->params); }
    public function get_param($name) { return $this->params[$name] ?? null; }
}
require dirname(__DIR__) . '/brand-selector-admin.php';

$checks = 0;
function check($condition, $message) { global $checks; $checks++; if (!$condition) { fwrite(STDERR, "FAIL: $message\n"); exit(1); } echo "PASS: $message\n"; }

check(evazar_brand_selector_hide_native_flat_brand_field(true, 'evazar_brand', 'evazar_product') === false, 'native name-only quick/bulk brand input is disabled');
check(evazar_brand_selector_hide_native_flat_brand_field(true, 'evazar_category', 'evazar_product') === true, 'category quick/bulk editing is unchanged');
check(evazar_brand_selector_hide_native_flat_brand_field(true, 'evazar_brand', 'post') === true, 'other post types are unaffected');
ob_start();
evazar_brand_selector_bulk_edit_box('taxonomy-evazar_brand', 'evazar_product');
$bulk_box_markup = ob_get_clean();
check(strpos($bulk_box_markup, 'name="evazar_brand_selector_nonce"') !== false, 'bulk replacement picker includes the required save nonce');
check(strpos($bulk_box_markup, 'data-mode="replace"') !== false && strpos($bulk_box_markup, 'جایگزینی برند کالاهای انتخاب‌شده') !== false, 'bulk picker clearly declares replacement behavior');
$bulk_hook_registered = false;
foreach ($GLOBALS['brand_selector_actions'] as $registered_action) {
    if (($registered_action[0] ?? '') === 'bulk_edit_posts' && ($registered_action[1] ?? '') === 'evazar_brand_selector_finalize_bulk_edit' && ($registered_action[3] ?? 1) === 2) $bulk_hook_registered = true;
}
check($bulk_hook_registered, 'bulk selector also saves through WordPress bulk_edit_posts completion hook');
check(evazar_brand_selector_validate_term_ids(['10', '11', '10', '999', 'not-a-number']) === [10, 11], 'term IDs are deduplicated and invalid/missing terms are rejected');

ob_start();
evazar_brand_selector_render_selected_term($GLOBALS['brand_selector_terms'][11], 'evazar_brand_term_ids[]');
$rendered_selected = ob_get_clean();
check(strpos($rendered_selected, 'salomon-pc') !== false && strpos($rendered_selected, 'شناسه: 11') !== false, 'selected duplicate-name brand displays exact slug and term ID');

$_POST = [
    'evazar_brand_selector_nonce' => 'valid',
    'evazar_brand_selector_present' => '1',
    'evazar_brand_term_ids' => ['11', '10', '11', '999'],
];
$GLOBALS['brand_selector_written'] = null;
evazar_brand_selector_save_product_terms(50, (object) ['post_type' => 'evazar_product'], true);
check($GLOBALS['brand_selector_written']['terms'] === [11, 10], 'full editor replaces taxonomy by exact term IDs, including same-name terms');

$_POST = ['evazar_brand_selector_nonce' => 'valid', 'evazar_brand_selector_present' => '1'];
$GLOBALS['brand_selector_current_by_post'][54] = [10];
$GLOBALS['brand_selector_written'] = null;
evazar_brand_selector_save_product_terms(54, (object) ['post_type' => 'evazar_product'], true);
check($GLOBALS['brand_selector_written']['terms'] === [], 'full editor can explicitly clear all brands when every selection is removed');

$_POST = [
    'evazar_brand_selector_nonce' => 'valid',
    'evazar_quick_brand_term_ids' => ['11'],
];
$GLOBALS['brand_selector_current'] = [10];
$GLOBALS['brand_selector_written'] = null;
evazar_brand_selector_save_product_terms(51, (object) ['post_type' => 'evazar_product'], true);
check($GLOBALS['brand_selector_written']['terms'] === [10, 11], 'quick edit appends selected ID and preserves existing brand ID');

$_POST = [
    'evazar_brand_selector_nonce' => 'valid',
    'evazar_bulk_brand_term_ids' => ['11', '12', '11'],
];
$GLOBALS['brand_selector_current'] = [10];
$GLOBALS['brand_selector_written'] = null;
evazar_brand_selector_save_product_terms(52, (object) ['post_type' => 'evazar_product'], true);
check($GLOBALS['brand_selector_written']['terms'] === [11, 12], 'bulk edit replaces current brand assignments with selected unique IDs');
check($GLOBALS['brand_selector_written']['append'] === false, 'bulk replacement assigns the selected taxonomy term IDs directly');

$_POST = [
    'evazar_brand_selector_nonce' => 'valid',
    'evazar_bulk_brand_term_ids' => ['999', 'not-a-number'],
];
$GLOBALS['brand_selector_current'] = [10];
$GLOBALS['brand_selector_written'] = null;
evazar_brand_selector_save_product_terms(55, (object) ['post_type' => 'evazar_product'], true);
check($GLOBALS['brand_selector_written'] === null, 'empty or invalid bulk selection does not clear current brands');

$_POST = ['evazar_brand_selector_nonce' => 'valid'];
$GLOBALS['brand_selector_current'] = [10];
$GLOBALS['brand_selector_written'] = null;
evazar_brand_selector_save_product_terms(56, (object) ['post_type' => 'evazar_product'], true);
check($GLOBALS['brand_selector_written'] === null, 'bulk edit with no brand field leaves existing brand assignments untouched');

$_POST = ['evazar_brand_selector_nonce' => 'invalid', 'evazar_brand_selector_present' => '1', 'evazar_brand_term_ids' => ['11']];
$GLOBALS['brand_selector_written'] = null;
evazar_brand_selector_save_product_terms(53, (object) ['post_type' => 'evazar_product'], true);
check($GLOBALS['brand_selector_written'] === null, 'invalid nonce prevents taxonomy writes');

// Simulate WordPress' bulk_edit_posts completion payload when save_post did not apply the custom field.
$GLOBALS['brand_selector_written'] = null;
$GLOBALS['brand_selector_current'] = [10];
$_POST = [];
evazar_brand_selector_finalize_bulk_edit([60, 61], [
    'evazar_brand_selector_nonce' => 'valid',
    'evazar_bulk_brand_term_ids' => ['11'],
]);
check($GLOBALS['brand_selector_written']['post_id'] === 61 && $GLOBALS['brand_selector_written']['terms'] === [11], 'bulk completion hook applies selected brand IDs to every updated product even without save_post payload');
check($GLOBALS['brand_selector_written']['append'] === false, 'bulk completion hook replaces rather than appends brand IDs');
check(($GLOBALS['brand_selector_current_by_post'][60] ?? []) === [11] && ($GLOBALS['brand_selector_current_by_post'][61] ?? []) === [11], 'bulk completion hook applies the chosen brand to every updated product');

$GLOBALS['brand_selector_written'] = null;
evazar_brand_selector_finalize_bulk_edit([62], [
    'evazar_brand_selector_nonce' => 'valid',
]);
check($GLOBALS['brand_selector_written'] === null, 'bulk completion hook leaves assignments unchanged when no brand choice was submitted');

$GLOBALS['brand_selector_written'] = null;
evazar_brand_selector_finalize_bulk_edit([63], [
    'evazar_brand_selector_nonce' => 'invalid',
    'evazar_bulk_brand_term_ids' => ['11'],
]);
check($GLOBALS['brand_selector_written'] === null, 'bulk completion hook rejects an invalid nonce');

$GLOBALS['brand_selector_written'] = null;
$GLOBALS['brand_selector_current_by_post'][64] = [11];
evazar_brand_selector_finalize_bulk_edit([64], [
    'evazar_brand_selector_nonce' => 'valid',
    'evazar_bulk_brand_term_ids' => ['11'],
]);
check($GLOBALS['brand_selector_written'] === null, 'bulk completion hook avoids duplicate taxonomy writes when selected brand is already set');

// The selected taxonomy term is the authoritative display identity, not a stale product meta value.
$GLOBALS['brand_selector_current_by_post'][80] = [12];
$GLOBALS['brand_selector_post_meta'][80] = ['_evazar_brand' => 'سامسونگ قدیمی', '_evazar_brand_en' => 'Old Samsung'];
check(evazar_brand_selector_apply_term_ids(80, [11], 'replace', 'brand-meta-sync-single') === true, 'single-term replacement remains successful');
check(($GLOBALS['brand_selector_post_meta'][80]['_evazar_brand'] ?? '') === 'سالومون' && ($GLOBALS['brand_selector_post_meta'][80]['_evazar_brand_en'] ?? '') === 'Salomon PC', 'single-term replacement syncs Persian and English brand metadata from the exact selected term');

$GLOBALS['brand_selector_current_by_post'][81] = [11];
$GLOBALS['brand_selector_post_meta'][81] = ['_evazar_brand' => 'سالومون', '_evazar_brand_en' => 'Salomon PC'];
check(evazar_brand_selector_apply_term_ids(81, [], 'replace', 'brand-meta-sync-clear') === true, 'explicit no-brand replacement remains successful');
check(get_post_meta(81, '_evazar_brand', true) === '' && get_post_meta(81, '_evazar_brand_en', true) === '', 'clearing all assigned brands removes stale scalar brand metadata');

$GLOBALS['brand_selector_current_by_post'][82] = [10];
$GLOBALS['brand_selector_post_meta'][82] = ['_evazar_brand' => 'سالومون', '_evazar_brand_en' => 'Salomon'];
check(evazar_brand_selector_apply_term_ids(82, [10, 11], 'replace', 'brand-meta-sync-multi-primary') === true, 'multi-term replacement remains successful');
check(($GLOBALS['brand_selector_post_meta'][82]['_evazar_brand_en'] ?? '') === 'Salomon', 'append/multi-term assignment retains a primary term only when existing metadata uniquely identifies it');

$GLOBALS['brand_selector_current_by_post'][83] = [10];
$GLOBALS['brand_selector_post_meta'][83] = ['_evazar_brand' => 'سامسونگ قدیمی', '_evazar_brand_en' => 'Samsung'];
check(evazar_brand_selector_apply_term_ids(83, [10, 11], 'replace', 'brand-meta-sync-ambiguous') === true, 'ambiguous multi-term replacement remains successful');
check(get_post_meta(83, '_evazar_brand', true) === '' && get_post_meta(83, '_evazar_brand_en', true) === '', 'ambiguous multi-term assignment clears stale scalar metadata instead of showing the wrong brand');

$GLOBALS['brand_selector_current_by_post'][84] = [11];
$GLOBALS['brand_selector_post_meta'][84] = ['_evazar_brand' => 'برند اشتباه', '_evazar_brand_en' => 'Wrong Brand'];
check(evazar_brand_selector_apply_term_ids(84, [11], 'replace', 'brand-meta-sync-idempotent') === true, 'identical term assignment remains idempotent');
check(($GLOBALS['brand_selector_post_meta'][84]['_evazar_brand'] ?? '') === 'سالومون' && ($GLOBALS['brand_selector_post_meta'][84]['_evazar_brand_en'] ?? '') === 'Salomon PC', 'idempotent save still repairs stale metadata');

// A partial post-meta write must not leave the new term attached while its legacy alias remains stale.
$GLOBALS['brand_selector_current_by_post'][85] = [10];
$GLOBALS['brand_selector_post_meta'][85] = ['_evazar_brand' => 'سالومون', '_evazar_brand_en' => 'Salomon'];
$GLOBALS['brand_selector_fail_meta_key'] = '_evazar_brand_en';
$meta_failure_result = evazar_brand_selector_apply_term_ids(85, [12], 'replace', 'brand-meta-failure-rollback');
check($meta_failure_result === false, 'metadata verification failure is returned as an assignment failure');
check(($GLOBALS['brand_selector_current_by_post'][85] ?? []) === [10], 'taxonomy assignment is rolled back when canonical metadata sync fails');
check(($GLOBALS['brand_selector_post_meta'][85]['_evazar_brand'] ?? '') === 'سالومون' && ($GLOBALS['brand_selector_post_meta'][85]['_evazar_brand_en'] ?? '') === 'Salomon', 'partial metadata writes restore the prior Persian and English values');
$GLOBALS['brand_selector_fail_meta_key'] = '';

// When the relationship is already identical, metadata failure still must not be reported as success.
$GLOBALS['brand_selector_current_by_post'][86] = [12];
$GLOBALS['brand_selector_post_meta'][86] = ['_evazar_brand' => 'نام اشتباه', '_evazar_brand_en' => 'Wrong Alias'];
$GLOBALS['brand_selector_fail_meta_key'] = '_evazar_brand_en';
check(evazar_brand_selector_apply_term_ids(86, [12], 'replace', 'brand-meta-failure-idempotent') === false, 'idempotent assignment does not claim success when metadata repair fails');
check(($GLOBALS['brand_selector_post_meta'][86]['_evazar_brand'] ?? '') === 'نام اشتباه' && ($GLOBALS['brand_selector_post_meta'][86]['_evazar_brand_en'] ?? '') === 'Wrong Alias', 'failed idempotent repair restores the prior metadata snapshot');
$GLOBALS['brand_selector_fail_meta_key'] = '';

$source = file_get_contents(dirname(__DIR__) . '/brand-selector-admin.php');
check(strpos($source, 't.name LIKE %s OR t.slug LIKE %s') !== false, 'search covers both Persian name and English slug');
check(strpos($source, '$wpdb->prepare(') !== false, 'SQL search uses prepared statements');


// The shipped Quick Edit template is cloned by WordPress. Native DOM listeners must be
// attached to the live clone, not to the hidden template (covered by source invariant).
$admin_js = file_get_contents(dirname(__DIR__) . '/brand-selector-admin.js');
check(strpos($admin_js, "picker.closest('#inlineedit')") !== false, 'hidden quick-edit template is left uninitialized so the live clone receives native event listeners');
$shutdown_hook_registered = false;
$rest_hook_registered = false;
foreach ($GLOBALS['brand_selector_actions'] as $registered_action) {
    if (($registered_action[0] ?? '') === 'shutdown' && ($registered_action[1] ?? '') === 'evazar_brand_selector_finalize_posted_assignment') $shutdown_hook_registered = true;
    if (($registered_action[0] ?? '') === 'rest_after_insert_evazar_product' && ($registered_action[1] ?? '') === 'evazar_brand_selector_reconcile_rest_assignment') $rest_hook_registered = true;
}
check($shutdown_hook_registered, 'classic and Quick Edit selections are reconciled after WordPress completes the save flow');
check($rest_hook_registered, 'Gutenberg REST saves have a post-save taxonomy reconciliation hook');
$core_source = file_get_contents(dirname(__DIR__) . '/evazar-core.php');
check(strpos($core_source, "require_once plugin_dir_path(__FILE__) . 'brand-selector-admin.php';") < strpos($core_source, "if (is_admin()) {"), 'brand selector REST reconciliation module is loaded for Gutenberg REST requests as well as admin screens');

$GLOBALS['brand_selector_current_by_post'][70] = [10];
$GLOBALS['brand_selector_written'] = null;
check(evazar_brand_selector_apply_term_ids(70, ['11', '11', '999'], 'replace', 'test') === true, 'verified assignment writes unique valid term IDs');
check(($GLOBALS['brand_selector_current_by_post'][70] ?? []) === [11], 'verified assignment replaces the product brand relation by exact ID');

$GLOBALS['brand_selector_current_by_post'][71] = [10];
$_POST = ['post_ID' => '71', 'evazar_brand_selector_nonce' => 'valid', 'evazar_quick_brand_term_ids' => ['11']];
evazar_brand_selector_finalize_posted_assignment();
check(($GLOBALS['brand_selector_current_by_post'][71] ?? []) === [10, 11], 'late Quick Edit reconciliation appends selected brand IDs after core save');

$GLOBALS['brand_selector_current_by_post'][72] = [10];
$_POST = ['post_ID' => '72', 'evazar_brand_selector_nonce' => 'valid', 'evazar_brand_selector_present' => '1', 'evazar_brand_term_ids' => ['12']];
evazar_brand_selector_finalize_posted_assignment();
check(($GLOBALS['brand_selector_current_by_post'][72] ?? []) === [12], 'late full-editor reconciliation applies exact selected brand IDs');

$GLOBALS['brand_selector_current_by_post'][73] = [10];
$rest_request = new BrandSelectorTestRequest(['evazar_brand' => [12, 12, 999]]);
evazar_brand_selector_reconcile_rest_assignment((object)['ID' => 73], $rest_request, false);
check(($GLOBALS['brand_selector_current_by_post'][73] ?? []) === [12], 'Gutenberg REST reconciliation applies exact validated taxonomy term IDs');

$GLOBALS['brand_selector_current_by_post'][74] = [10];
$_POST = ['post_ID' => '74', 'evazar_brand_selector_nonce' => 'invalid', 'evazar_brand_selector_present' => '1', 'evazar_brand_term_ids' => ['12']];
evazar_brand_selector_finalize_posted_assignment();
check(($GLOBALS['brand_selector_current_by_post'][74] ?? []) === [10], 'late reconciliation refuses missing/invalid nonce');

echo "All {$checks} brand selector regression tests passed.\n";
