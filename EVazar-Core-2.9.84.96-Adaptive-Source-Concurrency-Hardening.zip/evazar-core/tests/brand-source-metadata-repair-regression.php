<?php
// Standalone test harness for the live-source metadata repair admin module.
error_reporting(E_ALL);
ini_set('display_errors', '1');
if (!defined('ABSPATH')) define('ABSPATH', __DIR__ . '/');
if (!defined('HOUR_IN_SECONDS')) define('HOUR_IN_SECONDS', 3600);
class WP_Error {
    private $code; private $message; private $data;
    public function __construct($code='', $message='', $data=null) {$this->code=$code;$this->message=$message;$this->data=$data;}
    public function get_error_code(){return $this->code;}
    public function get_error_message(){return $this->message;}
    public function get_error_data(){return $this->data;}
}
$GLOBALS['bsmr_terms']=[]; $GLOBALS['bsmr_meta']=[]; $GLOBALS['bsmr_posts']=[]; $GLOBALS['bsmr_posts_by_term']=[]; $GLOBALS['bsmr_relationships']=[]; $GLOBALS['bsmr_live']=[]; $GLOBALS['bsmr_transients']=[]; $GLOBALS['bsmr_worker_calls']=0; $GLOBALS['bsmr_fail_meta_key']=''; $GLOBALS['bsmr_options']=['evazar_brand_slug_redirects'=>[]];
function add_action(...$a){} function post_type_exists($v){return true;} function add_submenu_page(...$a){}
function is_wp_error($v){return $v instanceof WP_Error;} function absint($v){return abs((int)$v);} function sanitize_text_field($v){return trim(strip_tags((string)$v));}
function sanitize_title($v){$v=strtolower(trim((string)$v));return preg_replace('/[^a-z0-9_-]+/','-', $v);}
function get_current_user_id(){return 7;} function get_option($k,$d=false){return $GLOBALS['bsmr_options'][$k]??$d;}
function set_transient($k,$v,$e=0){$GLOBALS['bsmr_transients'][$k]=$v;return true;} function get_transient($k){return $GLOBALS['bsmr_transients'][$k]??false;} function delete_transient($k){unset($GLOBALS['bsmr_transients'][$k]);return true;}
function get_term($id,$tax=''){return $GLOBALS['bsmr_terms'][(int)$id]??null;}
function get_term_meta($id,$key,$single=true){return $GLOBALS['bsmr_meta'][(int)$id][$key]??'';}
function update_term_meta($id,$key,$value){if(($GLOBALS['bsmr_fail_meta_key']??'')===(string)$key)return false;$GLOBALS['bsmr_meta'][(int)$id][$key]=$value;return true;} function delete_term_meta($id,$key){unset($GLOBALS['bsmr_meta'][(int)$id][$key]);return true;}
function get_terms($args=[]){$tax=$args['taxonomy']??'evazar_brand';$out=[];foreach($GLOBALS['bsmr_terms'] as $id=>$t){if(($t->taxonomy??'evazar_brand')!==$tax)continue;if(isset($args['name'])&&$t->name!==$args['name'])continue;if(isset($args['parent'])&&(int)($t->parent??0)!==(int)$args['parent'])continue;$out[]=$t;}return $out;}
function get_posts($args=[]){$q=$args['tax_query'][0]['terms'][0]??0;return $GLOBALS['bsmr_posts_by_term'][(int)$q]??[];}
function get_post_meta($id,$key,$single=true){return $GLOBALS['bsmr_meta']['post'][(int)$id][$key]??'';}
function get_the_title($id){return $GLOBALS['bsmr_posts'][(int)$id]->post_title??('Product '.$id);}
function get_post($id){return $GLOBALS['bsmr_posts'][(int)$id]??null;}
function wp_get_object_terms($id,$tax,$args=[]){return $GLOBALS['bsmr_relationships'][(int)$id][$tax]??[];}
function evazar_normalize_digikala_brand_source_path($value){$value=trim((string)$value);if(preg_match('#^https?://#i',$value)){$p=parse_url($value);if(!in_array(strtolower($p['host']??''),['digikala.com','www.digikala.com'],true)||isset($p['query'])||isset($p['fragment'])||isset($p['port']))return ''; $value=$p['path']??'';} if(preg_match('#%(?:2f|5c)#i',$value))return ''; $value=rawurldecode($value);if(!preg_match('#^/(?:brand|brand-landing)/([\p{L}\p{M}\p{N}]+(?:[._-][\p{L}\p{M}\p{N}]+)*)/?$#iu',$value,$m))return '';return '/brand/'.(function_exists('mb_strtolower')?mb_strtolower($m[1],'UTF-8'):strtolower($m[1])).'/';}
function evazar_worker_auth_headers(){return ['X-Evazar-Internal-Token'=>'unit-test'];}
function evazar_primary_worker_request($path='', $query_args=[], $request_args=[], $method='GET', $purpose='default'){
    $GLOBALS['bsmr_worker_calls']++;$dkp=(string)($query_args['dkp']??'');$live=$GLOBALS['bsmr_live'][$dkp]??null;if(!$live)return new WP_Error('missing_live','no fake product');return ['response'=>['code'=>200],'body'=>json_encode(['success'=>true,'product'=>$live])];
}
function wp_remote_retrieve_response_code($r){return (int)($r['response']['code']??0);} function wp_remote_retrieve_body($r){return (string)($r['body']??'');}
function evazar_bsmr_seed_term($id,$name,$slug,$productCount=1,$meta=[]){$GLOBALS['bsmr_terms'][$id]=(object)['term_id'=>$id,'name'=>$name,'slug'=>$slug,'taxonomy'=>'evazar_brand','count'=>$productCount];$GLOBALS['bsmr_meta'][$id]=$meta;}
function evazar_bsmr_seed_product($postId,$termId,$dkp,$title='Sample'){$GLOBALS['bsmr_posts'][$postId]=(object)['ID'=>$postId,'post_type'=>'evazar_product','post_status'=>'publish','post_title'=>$title];$GLOBALS['bsmr_posts_by_term'][$termId][]=$postId;$GLOBALS['bsmr_meta']['post'][$postId]['_evazar_sku']=$dkp;$GLOBALS['bsmr_meta']['post'][$postId]['_evazar_dk_url']='https://www.digikala.com/product/dkp-'.$dkp.'/';$GLOBALS['bsmr_relationships'][$postId]['evazar_brand']=[$termId];}
function evazar_bsmr_live($dkp,$id,$code,$fa,$en,$slug){$path=(is_string($slug)&&strpos($slug,'/')===0)?$slug:'/brand/'.$slug.'/';$GLOBALS['bsmr_live'][(string)$dkp]=['brand'=>$fa,'brand_en'=>$en,'brand_source_path'=>$path,'brand_source_id'=>$id,'brand_source_code'=>$code];}
require_once dirname(__DIR__) . '/brand-source-metadata-repair.php';
$passed=0;$failed=0;function bsmr_check($label,$ok){global $passed,$failed;if($ok){$passed++;echo "PASS: $label\n";}else{$failed++;echo "FAIL: $label\n";}}

$complete=['_evazar_dk_brand_id'=>'39641','_evazar_dk_brand_code'=>'salomon-pc','_evazar_dk_slug'=>'salomon-pc','_evazar_dk_url'=>'/brand/salomon-pc/','_evazar_dk_source_map_version'=>'2.9.84.27','_evazar_dk_source_verified'=>'1'];
evazar_bsmr_seed_term(1,'سالومون','salomon-pc',1,$complete);
bsmr_check('complete verified brand metadata is recognized',evazar_bsmr_metadata_state(1)['complete']===true);
evazar_bsmr_seed_term(2,'سالومون','salomon',9,[]); evazar_bsmr_seed_product(102,2,'555102','Salomon sample A'); evazar_bsmr_live('555102','713','salomon','سالومون','Salomon','salomon');
$r=evazar_bsmr_analyze_term(2);
bsmr_check('same public/source slug with only one independent sample is not auto-approved',($r['status']??'')==='NEEDS_SECOND_SAMPLE' && !is_array(get_transient('evazar_bsmr_7_2')));
evazar_bsmr_seed_product(202,2,'555202','Salomon sample B'); evazar_bsmr_live('555202','713','salomon','سالومون','Salomon','salomon');
$r=evazar_bsmr_analyze_term(2);
bsmr_check('same public/source slug is READY only after two agreeing independent samples',($r['status']??'')==='READY' && ($r['source_id']??'')==='713' && ($r['samples']??0)===2);
bsmr_check('repair plan is stored server-side for the current user',is_array(get_transient('evazar_bsmr_7_2')));

// Carrera-style homonyms: an identical public slug must not allow mixed source identities to be merged.
evazar_bsmr_seed_term(27,'کاررا','carrera',2,[]);
evazar_bsmr_seed_product(222,27,'9299832','Carrera sample from base slug');
evazar_bsmr_seed_product(223,27,'9299833','Carrera sample from alternate slug');
evazar_bsmr_live('9299832','8801','carrera','کاررا','Carrera','carrera');
evazar_bsmr_live('9299833','8802','carrera-brand','کاررا','Carrera','carrera-brand');
$r=evazar_bsmr_analyze_term(27);
bsmr_check('same-slug Carrera term with conflicting independent source identities is blocked',($r['status']??'')==='SAMPLE_DISAGREEMENT' && !is_array(get_transient('evazar_bsmr_7_27')));

// A term whose public slug differs requires two separate samples, even when the first name matches.
evazar_bsmr_seed_term(3,'سالومون','old-salomon',2,[]);evazar_bsmr_seed_product(103,3,'555103','Sample one');evazar_bsmr_live('555103','714','salomon-legacy','سالومون','Salomon','salomon-legacy');
$r=evazar_bsmr_analyze_term(3);bsmr_check('mismatched public slug is not auto-ready with only one sample',($r['status']??'')==='NEEDS_SECOND_SAMPLE');
evazar_bsmr_seed_product(104,3,'555104','Sample two');evazar_bsmr_live('555104','714','salomon-legacy','سالومون','Salomon','salomon-legacy');
$r=evazar_bsmr_analyze_term(3);bsmr_check('two independent agreeing samples permit safe metadata-only repair',($r['status']??'')==='READY' && ($r['samples']??0)===2);

// Conflicting samples, name mismatch, and source identity ownership must fail closed.
evazar_bsmr_seed_term(4,'سالومون','old-salomon-two',2,[]);evazar_bsmr_seed_product(105,4,'555105','Sample A');evazar_bsmr_seed_product(106,4,'555106','Sample B');evazar_bsmr_live('555105','715','source-one','سالومون','Salomon','source-one');evazar_bsmr_live('555106','716','source-two','سالومون','Salomon','source-two');
$r=evazar_bsmr_analyze_term(4);bsmr_check('disagreeing source identities between samples are blocked',($r['status']??'')==='SAMPLE_DISAGREEMENT');
evazar_bsmr_seed_term(5,'سالومون تقلبی','fake-salomon-source',2,[]);evazar_bsmr_seed_product(107,5,'555107','Wrong name A');evazar_bsmr_seed_product(117,5,'555117','Wrong name B');evazar_bsmr_live('555107','717','fake-salomon-source','سالومون','Salomon','fake-salomon-source');evazar_bsmr_live('555117','717','fake-salomon-source','سالومون','Salomon','fake-salomon-source');
$r=evazar_bsmr_analyze_term(5);bsmr_check('Persian term-name mismatch is blocked',($r['status']??'')==='BRAND_NAME_MISMATCH');
evazar_bsmr_seed_term(6,'برند نمونه مالک','owner-test-slug',2,[]);evazar_bsmr_seed_term(7,'برند دیگر','other-brand',1,['_evazar_dk_brand_id'=>'718']);evazar_bsmr_seed_product(108,6,'555108','Source collision A');evazar_bsmr_seed_product(118,6,'555118','Source collision B');evazar_bsmr_live('555108','718','owner-test-slug','برند نمونه مالک','Owner Test','owner-test-slug');evazar_bsmr_live('555118','718','owner-test-slug','برند نمونه مالک','Owner Test','owner-test-slug');
$r=evazar_bsmr_analyze_term(6);bsmr_check('source ID already owned by another term is blocked',($r['status']??'')==='BSMR_SOURCE_ID_OWNED');

// Apply a valid plan and verify that only source metadata changes.
$GLOBALS['bsmr_terms'][2]->slug='salomon';$GLOBALS['bsmr_options']['evazar_brand_slug_redirects']=['salomon'=>999,'salomon-pc'=>1];
$beforeTerms=$GLOBALS['bsmr_terms'][2]->slug;$beforeRedirects=$GLOBALS['bsmr_options']['evazar_brand_slug_redirects'];
$r=evazar_bsmr_apply_candidate(2);
bsmr_check('safe repair writes and reads back complete verified source metadata',($r['status']??'')==='SAVED' && get_term_meta(2,'_evazar_dk_source_verified',true)==='1' && get_term_meta(2,'_evazar_dk_brand_id',true)==='713');
bsmr_check('metadata repair preserves public slug and redirect mappings',($GLOBALS['bsmr_terms'][2]->slug===$beforeTerms) && $GLOBALS['bsmr_options']['evazar_brand_slug_redirects']===$beforeRedirects);
bsmr_check('metadata repair preserves product-to-brand assignment',($GLOBALS['bsmr_relationships'][102]['evazar_brand']??[])===[2]);

// Test stale candidate rejection when a term changes after preview.
evazar_bsmr_seed_term(8,'سونی','old-sony',2,[]);evazar_bsmr_seed_product(109,8,'555109','Sony one');evazar_bsmr_seed_product(110,8,'555110','Sony two');evazar_bsmr_live('555109','801','sony','سونی','Sony','sony');evazar_bsmr_live('555110','801','sony','سونی','Sony','sony');
$r=evazar_bsmr_analyze_term(8);$GLOBALS['bsmr_terms'][8]->slug='changed-after-review';$apply=evazar_bsmr_apply_candidate(8);
bsmr_check('stale plan is rejected if public term changes after analysis',($r['status']??'')==='READY' && ($apply['status']??'')==='SKIPPED');

// A legacy marker can look complete while having originated from a version that guessed brand URLs.
evazar_bsmr_seed_term(11,'برند قدیمی','legacy-brand-path',2,['_evazar_dk_brand_id'=>'805','_evazar_dk_brand_code'=>'legacy-brand-path','_evazar_dk_slug'=>'legacy-brand-path','_evazar_dk_url'=>'/brand/legacy-brand-path/','_evazar_dk_source_verified'=>'1','_evazar_dk_source_map_version'=>'2.9.84.16']);
evazar_bsmr_seed_product(113,11,'555113','Legacy brand path sample A');evazar_bsmr_seed_product(116,11,'555116','Legacy brand path sample B');evazar_bsmr_live('555113','805','legacy-brand-path','برند قدیمی','Legacy Brand','legacy-brand-path');evazar_bsmr_live('555116','805','legacy-brand-path','برند قدیمی','Legacy Brand','legacy-brand-path');
$r=evazar_bsmr_analyze_term(11);
bsmr_check('old guessed-map provenance is not considered complete despite a stale verified marker',evazar_bsmr_metadata_state(11)['complete']===false && ($r['status']??'')==='READY');
$apply=evazar_bsmr_apply_candidate(11);
bsmr_check('legacy verified-looking metadata is upgraded only after live API recheck',($apply['status']??'')==='SAVED' && get_term_meta(11,'_evazar_dk_source_map_version',true)==='2.9.84.32-live-metadata-repair');

// An old guessed URL/code may be corrected only when two attached products independently prove the live identity.
evazar_bsmr_seed_term(12,'برند قدیمی دوم','old-guessed',2,['_evazar_dk_brand_id'=>'806','_evazar_dk_brand_code'=>'old-guessed','_evazar_dk_slug'=>'old-guessed','_evazar_dk_url'=>'/brand/old-guessed/','_evazar_dk_source_verified'=>'1','_evazar_dk_source_map_version'=>'2.9.84.16']);
evazar_bsmr_seed_product(114,12,'555114','Legacy sample A');evazar_bsmr_seed_product(115,12,'555115','Legacy sample B');evazar_bsmr_live('555114','806','actual-source','برند قدیمی دوم','Current Source','actual-source');evazar_bsmr_live('555115','806','actual-source','برند قدیمی دوم','Current Source','actual-source');
$r=evazar_bsmr_analyze_term(12);
bsmr_check('untrusted old guessed URL can be repaired after two live samples agree',($r['status']??'')==='READY' && ($r['samples']??0)===2);
$apply=evazar_bsmr_apply_candidate(12);
bsmr_check('old guessed URL is replaced in metadata only after live confirmation',($apply['status']??'')==='SAVED' && get_term_meta(12,'_evazar_dk_url',true)==='/brand/actual-source/' && get_term_meta(12,'_evazar_dk_source_verified',true)==='1');

// Live source identity must still match at the write step, not only during preview.
evazar_bsmr_seed_term(9,'سونی','sony-live-recheck',2,[]);evazar_bsmr_seed_product(111,9,'555111','Sony recheck A');evazar_bsmr_seed_product(129,9,'555129','Sony recheck B');evazar_bsmr_live('555111','802','sony-live-recheck','سونی','Sony','sony-live-recheck');evazar_bsmr_live('555129','802','sony-live-recheck','سونی','Sony','sony-live-recheck');
$r=evazar_bsmr_analyze_term(9);$GLOBALS['bsmr_live']['555111']['brand_source_id']='803';$apply=evazar_bsmr_apply_candidate(9);
bsmr_check('apply re-fetches source and rejects changed brand ID',($r['status']??'')==='READY' && ($apply['status']??'')==='SOURCE_CHANGED_AFTER_REVIEW' && get_term_meta(9,'_evazar_dk_brand_id',true)==='');

// A failed metadata write must not leave the term marked source-verified.
evazar_bsmr_seed_term(10,'برند خطای ذخیره','repair-write-failure',2,[]);evazar_bsmr_seed_product(112,10,'555112','Repair write fail A');evazar_bsmr_seed_product(130,10,'555130','Repair write fail B');evazar_bsmr_live('555112','804','repair-write-failure','برند خطای ذخیره','Repair Write Failure','repair-write-failure');evazar_bsmr_live('555130','804','repair-write-failure','برند خطای ذخیره','Repair Write Failure','repair-write-failure');
$r=evazar_bsmr_analyze_term(10);$GLOBALS['bsmr_fail_meta_key']='_evazar_dk_brand_code';$apply=evazar_bsmr_apply_candidate(10);$GLOBALS['bsmr_fail_meta_key']='';
bsmr_check('partial repair write fails closed with verification marker off',($r['status']??'')==='READY' && ($apply['status']??'')==='WRITE_FAILED' && get_term_meta(10,'_evazar_dk_source_verified',true)==='0');

// A source-verified distinct brand may keep a numeric local slug when the canonical public slug belongs to another known source ID.
evazar_bsmr_seed_term(20,'ال جی','lg',1,['_evazar_dk_brand_id'=>'18','_evazar_dk_brand_code'=>'lg','_evazar_dk_slug'=>'lg','_evazar_dk_url'=>'/brand/lg/','_evazar_dk_source_map_version'=>'2.9.84.29','_evazar_dk_source_verified'=>'1']);
evazar_bsmr_seed_term(21,'ال جی','lg-1',2,[]);
evazar_bsmr_seed_product(120,21,'555120','LG distinct sample A');evazar_bsmr_seed_product(121,21,'555121','LG distinct sample B');
evazar_bsmr_live('555120','999','lg-second','ال جی','LG','lg');evazar_bsmr_live('555121','999','lg-second','ال جی','LG','lg');
$r=evazar_bsmr_analyze_term(21);
bsmr_check('suffixed public slug is eligible only after two source samples agree and base has different verified ID',($r['status']??'')==='READY' && ($r['samples']??0)===2);
$apply=evazar_bsmr_apply_candidate(21);
bsmr_check('repair accepts known distinct-ID collision and records public-slug override without renaming term',($apply['status']??'')==='SAVED' && get_term_meta(21,'_evazar_dk_brand_id',true)==='999' && get_term_meta(21,'_evazar_dk_public_slug_override',true)==='1' && $GLOBALS['bsmr_terms'][21]->slug==='lg-1');
bsmr_check('new metadata provenance version recognizes repaired collision-suffixed brand as complete',evazar_bsmr_metadata_state(21)['complete']===true && evazar_bsmr_metadata_state(21)['source_map_version']==='2.9.84.32-live-metadata-repair');

// A numeric suffix is not, by itself, proof that its base term is another brand: unknown owners remain blocked.
evazar_bsmr_seed_term(22,'برند دستی','manual-x',1,[]);evazar_bsmr_seed_term(23,'برند دستی','manual-x-1',2,[]);
evazar_bsmr_seed_product(122,23,'555122','Manual base test A');evazar_bsmr_seed_product(123,23,'555123','Manual base test B');
evazar_bsmr_live('555122','1001','manual-x','برند دستی','Manual X','manual-x');evazar_bsmr_live('555123','1001','manual-x','برند دستی','Manual X','manual-x');
$r=evazar_bsmr_analyze_term(23);
bsmr_check('metadata repair blocks numeric suffix when base slug owner has unknown identity',($r['status']??'')==='BSMR_SOURCE_SLUG_OCCUPIED');

// A Persian URL returned from the product API is a valid source identity; landing-route aliases canonicalize to /brand/{slug}/.
evazar_bsmr_seed_term(24,'چرم آراهمراه','charm-arahamrah',3,[]);
evazar_bsmr_seed_product(124,24,'555124','Incomplete API brand payload');
evazar_bsmr_seed_product(125,24,'555125','Valid Persian brand payload A');
evazar_bsmr_seed_product(126,24,'555126','Valid Persian brand payload B');
$GLOBALS['bsmr_live']['555124']=['brand'=>'چرم آراهمراه','brand_en'=>'','brand_source_path'=>'','brand_source_id'=>0,'brand_source_code'=>''];
evazar_bsmr_live('555125','2204','charm-arahamrah','چرم آراهمراه','Charm Arah Hamrah','/brand/چرم-آراهمراه/');
evazar_bsmr_live('555126','2204','charm-arahamrah','چرم آراهمراه','Charm Arah Hamrah','/brand-landing/چرم-آراهمراه/');
$r=evazar_bsmr_analyze_term(24);
bsmr_check('repair skips incomplete first product payload and uses two agreeing Persian-brand samples',($r['status']??'')==='READY' && ($r['samples']??0)===2 && ($r['source_url']??'')==='/brand/چرم-آراهمراه/');
$apply=evazar_bsmr_apply_candidate(24);
bsmr_check('repair writes Persian source identity while preserving public English slug',($apply['status']??'')==='SAVED' && get_term_meta(24,'_evazar_dk_url',true)==='/brand/چرم-آراهمراه/' && $GLOBALS['bsmr_terms'][24]->slug==='charm-arahamrah');


// Digikala's j.one source slug includes a literal period, while WordPress public slug is j-one.
evazar_bsmr_seed_term(25,'جی وان','j-one',2,[]);
evazar_bsmr_seed_product(127,25,'555127','J One sample A');
evazar_bsmr_seed_product(128,25,'555128','J One sample B');
evazar_bsmr_live('555127','1025','j.one','جی وان','J.One','/brand/j.one/');
evazar_bsmr_live('555128','1025','j.one','جی وان','J.One','/brand-landing/j.one/');
$r=evazar_bsmr_analyze_term(25);
bsmr_check('dotted upstream source slug is accepted while public hyphen slug is preserved',($r['status']??'')==='READY' && ($r['samples']??0)===2 && ($r['source_url']??'')==='/brand/j.one/' && ($r['source_slug']??'')==='j.one');
$apply=evazar_bsmr_apply_candidate(25);
bsmr_check('dotted source slug metadata saves without changing public j-one slug',($apply['status']??'')==='SAVED' && get_term_meta(25,'_evazar_dk_url',true)==='/brand/j.one/' && get_term_meta(25,'_evazar_dk_slug',true)==='j.one' && $GLOBALS['bsmr_terms'][25]->slug==='j-one' && get_term_meta(25,'_evazar_dk_public_slug_override',true)==='0');

echo "\nRESULT: {$passed} passed, {$failed} failed\n";exit($failed?1:0);
