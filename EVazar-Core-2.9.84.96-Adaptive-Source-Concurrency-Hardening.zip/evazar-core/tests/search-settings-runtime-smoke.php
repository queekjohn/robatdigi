<?php
// Runtime smoke test for the WordPress admin Search Settings screen using small WP/database stubs.
if (!defined('ABSPATH')) define('ABSPATH', '/tmp/wordpress/');
if (!defined('EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION')) define('EVAZAR_PRODUCT_SEARCH_INDEX_DB_VERSION', '1.0.0');
if (!defined('EVAZAR_PRODUCT_INDEX_DB_VERSION')) define('EVAZAR_PRODUCT_INDEX_DB_VERSION', '1.3.0');
$GLOBALS['search_test_options'] = [
    'evazar_product_search_index_state' => 'ready',
    'evazar_product_search_index_backfill_last_run' => ['time' => 1790000000, 'synced' => 250, 'ready' => true],
    'evazar_search_indexed_enabled' => '1',
    'evazar_search_min_chars' => 2,
    'evazar_search_debounce_ms' => 250,
    'evazar_search_live_product_limit' => 5,
    'evazar_search_index_batch_size' => 250,
    'date_format' => 'Y-m-d',
    'time_format' => 'H:i',
];
function add_action(...$args) {}
function absint($value) { return abs((int)$value); }
function get_option($key, $default = false) { return $GLOBALS['search_test_options'][$key] ?? $default; }
function update_option($key, $value, $autoload = null) { $GLOBALS['search_test_options'][$key] = $value; return true; }
function register_setting(...$args) { $GLOBALS['registered_search_options'][] = $args; }
function current_user_can($cap) { return $cap === 'manage_options'; }
function wp_die($msg = '') { throw new RuntimeException((string)$msg); }
function wp_next_scheduled($hook) { return $hook === 'evazar_product_index_backfill' ? 1790000300 : false; }
function admin_url($path = '') { return 'https://example.test/wp-admin/' . ltrim($path, '/'); }
function wp_date($format, $timestamp = null) { return date($format, $timestamp ?: time()); }
function esc_html($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function esc_attr($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function esc_url($v) { return (string)$v; }
function selected($selected, $current = true, $echo = true) { $out = ((string)$selected === (string)$current) ? ' selected="selected"' : ''; if ($echo) echo $out; return $out; }
function checked($checked, $current = true, $echo = true) { $out = ((string)$checked === (string)$current || ($checked === true && $current === true)) ? ' checked="checked"' : ''; if ($echo) echo $out; return $out; }
function settings_fields($group) { echo '<input type="hidden" name="option_page" value="' . esc_attr($group) . '">'; }
function submit_button($text, $type = 'primary', $name = 'submit', $wrap = true) { echo '<button type="submit" name="' . esc_attr($name) . '">' . esc_html($text) . '</button>'; }
function wp_nonce_field($action) { echo '<input type="hidden" name="_wpnonce" value="test">'; }
function sanitize_key($v) { return preg_replace('/[^a-z0-9_\-]/', '', strtolower((string)$v)); }
function wp_unslash($v) { return $v; }
function number_format_i18n($v) { return number_format((float)$v); }
function evazar_product_search_index_documents_table() { return 'wp_evazar_product_search_index'; }
function evazar_product_search_index_terms_table() { return 'wp_evazar_product_search_terms'; }
function evazar_product_index_table() { return 'wp_evazar_product_index'; }
class SearchSettingsFakeWpdb {
    public $posts = 'wp_posts';
    public $postmeta = 'wp_postmeta';
    public $last_error = '';
    public function esc_like($v) { return (string)$v; }
    public function prepare($sql, ...$args) {
        foreach ($args as $arg) {
            $rep = is_numeric($arg) ? (string)$arg : "'" . str_replace("'", "''", (string)$arg) . "'";
            $sql = preg_replace('/%[sd]/', $rep, $sql, 1);
        }
        return $sql;
    }
    public function get_var($sql) {
        $this->last_error = '';
        if (strpos($sql, 'SHOW TABLES LIKE') !== false && preg_match("/LIKE '([^']+)'/", $sql, $m)) return $m[1];
        if (strpos($sql, 'SELECT MAX(updated_at)') !== false) return '2026-10-29 01:00:00';
        if (strpos($sql, 'COUNT(DISTINCT pm.post_id)') !== false) return 1;
        if (strpos($sql, 'FROM wp_evazar_product_search_terms') !== false) return 40000;
        if (strpos($sql, 'INNER JOIN wp_evazar_product_search_index') !== false) return 18000;
        if (strpos($sql, 'FROM wp_posts WHERE post_type=') !== false) return 20000;
        return 0;
    }
}
$wpdb = new SearchSettingsFakeWpdb();
$GLOBALS['wpdb'] = $wpdb;
require_once dirname(__DIR__) . '/search-settings.php';
evazar_search_settings_register();
$report = evazar_search_settings_get_index_status();
$state_failed_closed = ($report['state'] === 'building' && !empty($report['state_mismatch']) && get_option('evazar_product_search_index_state') === 'building');
$GLOBALS['search_test_options']['evazar_product_search_index_state'] = 'ready'; // Recreate mismatch for the rendered admin page.
ob_start();
evazar_search_settings_admin_page();
$html = ob_get_clean();
$checks = [
    'The settings group registers five options' => count($GLOBALS['registered_search_options'] ?? []) === 5,
    'Status derives complete index progress from database counts' => $report['tables_ready'] && !$report['db_error'] && $report['total'] === 20000 && $report['indexed'] === 18000 && $report['missing'] === 2000 && $report['percent'] === 90,
    'Stale ready status automatically fails closed to building' => $state_failed_closed,
    'Status detects recorded sync errors and scheduled execution' => $report['errors'] === 1 && $report['next_run'] === 1790000300,
    'Admin page renders status, progress and configurable controls' => strpos($html, 'تنظیمات جستجوی ایوازار') !== false && strpos($html, '90٪') !== false && strpos($html, 'evazar_search_min_chars') !== false && strpos($html, 'evazar_search_index_batch_size') !== false,
    'Admin page includes a nonce-protected non-destructive repair form' => strpos($html, 'evazar_search_index_run_batch') !== false && strpos($html, 'بررسی و ترمیم ایندکس') !== false,
];
$failed = 0;
foreach ($checks as $name => $ok) { echo ($ok ? 'PASS: ' : 'FAIL: ') . $name . "\n"; if (!$ok) $failed++; }
echo 'RESULT: ' . (count($checks) - $failed) . ' passed, ' . $failed . " failed\n";
exit($failed ? 1 : 0);
