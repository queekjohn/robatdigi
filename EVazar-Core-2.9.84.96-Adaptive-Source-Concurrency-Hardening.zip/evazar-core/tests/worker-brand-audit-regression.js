#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const sourcePath = path.join(__dirname, '..', 'worker', 'digikala-worker.js');
let responseMode = 'success';
let fetchCalls = [];
const upstreamProduct = {
  id: 123,
  title_fa: 'محصول آزمایشی',
  title_en: 'Sample Product',
  brand: { id: 18, code: 'lg', title_fa: 'ال‌جی', title_en: 'LG', url: { uri: '/brand/lg/' } },
  default_variant: { price: { selling_price: 100000, rrp_price: 120000 } },
  images: { main: { url: [] } },
};
const context = vm.createContext({
  URL, Response, Request, Headers, AbortSignal, console,
  caches: { default: { match: async () => null, put: async () => {} } },
  fetch: async (url, init = {}) => {
    const target = String(url);
    fetchCalls.push({ url: target, init });
    if (!/^https:\/\/api\.digikala\.com\/v[12]\/product\/123\/$/.test(target)) {
      throw new Error(`Unexpected mocked fetch URL: ${target}`);
    }
    if (responseMode === 'rate_limit') {
      return new Response(JSON.stringify({ message: 'rate limited' }), { status: 429, headers: { 'Content-Type': 'application/json' } });
    }
    if (responseMode === 'v2_404_then_v1_ok') {
      if (target.includes('/v2/')) return new Response(JSON.stringify({}), { status: 404, headers: { 'Content-Type': 'application/json' } });
      return new Response(JSON.stringify({ data: { product: upstreamProduct } }), { status: 200, headers: { 'Content-Type': 'application/json' } });
    }
    return new Response(JSON.stringify({ data: { product: upstreamProduct } }), { status: 200, headers: { 'Content-Type': 'application/json' } });
  }
});
const source = fs.readFileSync(sourcePath, 'utf8').replace('export default {', 'const WorkerDefault = {').replace('export class GeminiIdempotencyDO', 'class GeminiIdempotencyDO');
vm.runInContext(source, context, { filename: sourcePath });
const worker = vm.runInContext('WorkerDefault', context);
const TOKEN = 'unit-test-token';
const mkRequest = (method, body, token = TOKEN) => {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers['X-Evazar-Internal-Token'] = token;
  return new Request('https://worker.test/brand-audit/product', {
    method,
    headers,
    ...(body === undefined ? {} : { body: JSON.stringify(body) })
  });
};
let passed = 0;
let failed = 0;
async function test(name, fn) {
  try { await fn(); passed++; console.log(`PASS: ${name}`); }
  catch (error) { failed++; console.error(`FAIL: ${name}\n${error.stack}`); }
}
(async () => {
  assert.match(source, /const DIGIKALA_WORKER_VERSION = '1\.13\.27'/);
  await test('unauthenticated audit is rejected and not cached', async () => {
    fetchCalls = [];
    const r = await worker.fetch(mkRequest('POST', { dkp_id: '123' }, ''), { EVAZAR_INTERNAL_TOKEN: TOKEN }, null);
    assert.equal(r.status, 401);
    assert.equal(r.headers.get('Cache-Control'), 'no-store, no-cache, must-revalidate');
    assert.equal(r.headers.get('CDN-Cache-Control'), 'no-store');
    assert.equal(r.headers.get('X-Evazar-Worker-Version'), '1.13.27');
    assert.equal(fetchCalls.length, 0);
  });
  await test('valid token required before method handling', async () => {
    fetchCalls = [];
    const r = await worker.fetch(mkRequest('GET', undefined), { EVAZAR_INTERNAL_TOKEN: TOKEN }, null);
    assert.equal(r.status, 405);
    assert.equal(r.headers.get('Allow'), 'POST');
    assert.equal(fetchCalls.length, 0);
  });
  await test('invalid product IDs rejected before upstream access', async () => {
    fetchCalls = [];
    const r = await worker.fetch(mkRequest('POST', { dkp_id: 'https://evil.example/' }), { EVAZAR_INTERNAL_TOKEN: TOKEN }, null);
    assert.equal(r.status, 400);
    assert.equal((await r.json()).error, 'invalid_product_id');
    assert.equal(fetchCalls.length, 0);
  });
  await test('valid audit returns minimal source identity with no-store headers', async () => {
    responseMode = 'success'; fetchCalls = [];
    const r = await worker.fetch(mkRequest('POST', { dkp_id: '123' }), { EVAZAR_INTERNAL_TOKEN: TOKEN }, null);
    assert.equal(r.status, 200);
    assert.equal(r.headers.get('X-Evazar-Worker-Version'), '1.13.27');
    assert.equal(r.headers.get('Cache-Control'), 'no-store, no-cache, must-revalidate');
    assert.equal(r.headers.get('CDN-Cache-Control'), 'no-store');
    const json = await r.json();
    assert.equal(json.success, true);
    assert.equal(json.version, '1.13.27');
    assert.equal(json.data.product.brand.id, 18);
    assert.equal(json.data.product.brand.code, 'lg');
    assert.equal(json.data.product.brand.url.uri, '/brand/lg/');
    assert.deepEqual(Object.keys(json.data.product).sort(), ['brand', 'id', 'title_fa']);
    assert.deepEqual(Object.keys(json.data.product.brand).sort(), ['code', 'id', 'title_en', 'title_fa', 'url']);
    assert.equal(fetchCalls.length, 1);
    assert.equal(fetchCalls[0].url, 'https://api.digikala.com/v2/product/123/');
  });
  await test('429 rate-limit does not trigger legacy API fallback', async () => {
    responseMode = 'rate_limit'; fetchCalls = [];
    const r = await worker.fetch(mkRequest('POST', { dkp_id: '123' }), { EVAZAR_INTERNAL_TOKEN: TOKEN }, null);
    assert.equal(r.status, 429);
    assert.equal((await r.json()).error, 'digikala_rate_limited');
    assert.equal(fetchCalls.length, 1);
    assert.match(fetchCalls[0].url, /\/v2\/product\/123\/$/);
  });
  await test('fast v2 404 may fall back to v1 once', async () => {
    responseMode = 'v2_404_then_v1_ok'; fetchCalls = [];
    const r = await worker.fetch(mkRequest('POST', { dkp_id: '123' }), { EVAZAR_INTERNAL_TOKEN: TOKEN }, null);
    assert.equal(r.status, 200);
    const json = await r.json();
    assert.equal(json.source_api_version, 'v1');
    assert.equal(fetchCalls.length, 2);
    assert.match(fetchCalls[0].url, /\/v2\/product\/123\/$/);
    assert.match(fetchCalls[1].url, /\/v1\/product\/123\/$/);
  });
  console.log(`\nRESULT: ${passed} passed, ${failed} failed`);
  process.exitCode = failed ? 1 : 0;
})();
