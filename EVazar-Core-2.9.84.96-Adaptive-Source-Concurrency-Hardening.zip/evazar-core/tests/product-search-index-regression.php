<?php
// Standalone local regression tests for Core's normalized title-token search index.
if (!defined('ABSPATH')) define('ABSPATH', '/tmp/wordpress/');
if (!defined('DAY_IN_SECONDS')) define('DAY_IN_SECONDS', 86400);
$GLOBALS['test_options'] = [
    'evazar_product_search_index_db_version' => '1.0.0',
    'evazar_product_search_index_state' => 'ready',
];
function add_action(...$args) {}
function add_filter(...$args) {}
function wp_strip_all_tags($value) { return strip_tags((string)$value); }
if (!function_exists('mb_strtolower')) { function mb_strtolower($value, $encoding = null) { return strtolower((string)$value); } }
if (!function_exists('mb_strlen')) { function mb_strlen($value, $encoding = null) { return preg_match_all('/./us', (string)$value, $m); } }
if (!function_exists('mb_substr')) { function mb_substr($value, $start, $length = null, $encoding = null) { return substr((string)$value, $start, $length); } }
function absint($value) { return abs((int)$value); }
function sanitize_text_field($value) { return trim(strip_tags((string)$value)); }
function sanitize_key($value) { return preg_replace('/[^a-z0-9_\-]/', '', strtolower((string)$value)); }
function get_option($key, $default = false) { return $GLOBALS['test_options'][$key] ?? $default; }
function update_option($key, $value, $autoload = null) { $GLOBALS['test_options'][$key] = $value; return true; }
function get_post_meta($post_id, $key, $single = false) { return $GLOBALS['test_meta'][$post_id][$key] ?? ''; }
function update_post_meta($post_id, $key, $value) { $GLOBALS['test_meta'][$post_id][$key] = $value; return true; }
function delete_post_meta($post_id, $key) { unset($GLOBALS['test_meta'][$post_id][$key]); return true; }
function get_post_type($post_id) { return 'evazar_product'; }
function get_post($post_id) { return (object)['ID' => $post_id, 'post_title' => 'Test Product']; }

class ProductSearchFakeWpdb {
    public $prefix = 'wp_';
    public $posts = 'wp_posts';
    public $postmeta = 'wp_postmeta';
    public $last_error = '';
    public $result_rows = [];
    public $result_ids = [101, 102];
    public $last_sql = '';
    public $last_params = [];
    public function esc_like($text) { return addcslashes((string)$text, '_%\\'); }
    public function prepare($query, ...$args) { $this->last_sql = $query; $this->last_params = $args; return $query; }
    public function get_results($query) { $this->last_sql = $query; return $this->result_rows; }
    public function get_col($query) { $this->last_sql = $query; return $this->result_ids; }
    public function get_var($query) { $this->last_sql = $query; return 'wp_evazar_product_index'; }
}
$wpdb = new ProductSearchFakeWpdb();
$GLOBALS['wpdb'] = $wpdb;
require_once dirname(__DIR__) . '/product-index.php';

$passed = 0;
$failed = 0;
function check_result($condition, $name) {
    global $passed, $failed;
    if ($condition) { $passed++; echo "PASS: {$name}\n"; }
    else { $failed++; echo "FAIL: {$name}\n"; }
}

$runtime_defaults = evazar_product_search_runtime_settings();
check_result($runtime_defaults['indexed_enabled'] === true && $runtime_defaults['min_chars'] === 2 && $runtime_defaults['debounce_ms'] === 250 && $runtime_defaults['live_product_limit'] === 5 && $runtime_defaults['index_batch_size'] === 250, 'Search runtime settings expose safe defaults');
$GLOBALS['test_options']['evazar_search_min_chars'] = 4;
$GLOBALS['test_options']['evazar_search_debounce_ms'] = 750;
$GLOBALS['test_options']['evazar_search_live_product_limit'] = 8;
$GLOBALS['test_options']['evazar_search_index_batch_size'] = 500;
$runtime_custom = evazar_product_search_runtime_settings();
check_result($runtime_custom['min_chars'] === 4 && $runtime_custom['debounce_ms'] === 750 && $runtime_custom['live_product_limit'] === 8 && $runtime_custom['index_batch_size'] === 500, 'Search runtime settings honor validated configurable values');
$GLOBALS['test_options']['evazar_search_min_chars'] = 99;
$GLOBALS['test_options']['evazar_search_debounce_ms'] = 999;
$GLOBALS['test_options']['evazar_search_live_product_limit'] = 999;
$GLOBALS['test_options']['evazar_search_index_batch_size'] = 999;
$runtime_invalid = evazar_product_search_runtime_settings();
check_result($runtime_invalid['min_chars'] === 2 && $runtime_invalid['debounce_ms'] === 250 && $runtime_invalid['live_product_limit'] === 5 && $runtime_invalid['index_batch_size'] === 250, 'Invalid stored search settings fall back to safe defaults');
$GLOBALS['test_options']['evazar_search_indexed_enabled'] = '0';
$before_disabled_sql = $wpdb->last_sql;
check_result(evazar_product_search_index_search_ids('samsung', 12, 0, false) === null && $wpdb->last_sql === $before_disabled_sql, 'Disabling indexed search safely routes title searches to legacy fallback');
$GLOBALS['test_options']['evazar_search_indexed_enabled'] = '1';
$GLOBALS['test_options']['evazar_search_min_chars'] = 2;
$GLOBALS['test_options']['evazar_search_debounce_ms'] = 250;
$GLOBALS['test_options']['evazar_search_live_product_limit'] = 5;
$GLOBALS['test_options']['evazar_search_index_batch_size'] = 250;

$normalized = evazar_product_search_index_normalize_text("  سامسونگ‌ كالا ۱۲۳  ");
check_result($normalized === 'سامسونگ کالا 123', 'Persian/Arabic letters, ZWNJ, whitespace and Persian digits normalize consistently');
$tokens = evazar_product_search_index_tokenize('Galaxy S25 گوشی 15 Galaxy');
check_result($tokens === ['galaxy', 's25', 'گوشی', '15'], 'Title tokenization deduplicates terms and preserves model numbers');

$wpdb->result_rows = [
    (object)['product_id' => 10, 'normalized_title' => 'samsung galaxy 15 ultra', 'post_date' => '2026-10-01 00:00:00'],
    (object)['product_id' => 11, 'normalized_title' => 'samsung 15', 'post_date' => '2026-09-01 00:00:00'],
    (object)['product_id' => 12, 'normalized_title' => 'samsung galaxy 14', 'post_date' => '2026-09-02 00:00:00'], // simulated stale token row
    (object)['product_id' => 0, 'normalized_title' => 'samsung 15', 'post_date' => '2026-08-01 00:00:00'],
];
$ids = evazar_product_search_index_search_ids('Samsung 15', 12, 0, false);
check_result($ids === [10, 11], 'Search validates candidates against normalized title to suppress stale-token false positives');
check_result(strpos($wpdb->last_sql, 'INNER JOIN wp_evazar_product_search_index') !== false, 'Search joins the per-product document index');
check_result(strpos($wpdb->last_sql, 'INNER JOIN wp_evazar_product_search_terms t1') !== false, 'Multiword search uses indexed token joins');
check_result(strpos($wpdb->last_sql, 'LEFT JOIN wp_evazar_product_index pi') === false, 'Ordinary title search avoids an unnecessary join to the facet index');
check_result(strpos($wpdb->last_sql, "p.post_status='publish'") !== false, 'Search restricts results to published EVazar products');
check_result(strpos($wpdb->last_sql, 'LIMIT %d') !== false, 'SQL result count is bounded');

$wpdb->result_rows = [(object)['product_id' => 10, 'normalized_title' => 'samsung ultra', 'post_date' => '2026-10-01 00:00:00']];
$brand_ids = evazar_product_search_index_search_ids('samsung', 12, 45, true);
check_result($brand_ids === [10], 'Single-token indexed search returns validated product IDs');
check_result(strpos($wpdb->last_sql, 'pi.brand_id=%d') !== false && strpos($wpdb->last_sql, 'pi.stock_status=1') !== false, 'Brand and in-stock constraints use the Core product index');

$GLOBALS['test_options']['evazar_product_search_index_state'] = 'building';
$before_sql = $wpdb->last_sql;
$not_ready = evazar_product_search_index_search_ids('samsung', 12, 0, false);
check_result($not_ready === null && $wpdb->last_sql === $before_sql, 'Index-building state safely requests the legacy fallback without running indexed SQL');
$GLOBALS['test_options']['evazar_product_search_index_state'] = 'ready';

$wpdb->result_ids = [101, '102', 0, -4];
$identifier_ids = evazar_product_index_find_identifier_ids(['DKP-123', '123'], 12, true);
check_result($identifier_ids === [101, 102], 'Identifier index returns unique positive product IDs');
check_result(strpos($wpdb->last_sql, 'i.dkp IN') !== false && strpos($wpdb->last_sql, 'i.sku IN') !== false, 'Identifier lookup uses indexed DKP/SKU columns');
check_result(strpos($wpdb->last_sql, 'i.stock_status=1') !== false, 'Identifier lookup respects in-stock filter');

$source = file_get_contents(dirname(__DIR__) . '/product-index.php');
check_result(strpos($source, 'KEY token_product (token, product_id)') !== false, 'Search-token table has an index suitable for token-prefix lookups');
check_result(strpos($source, 'PRIMARY KEY  (product_id, token)') !== false, 'Search terms are unique per product to bound index size');
check_result(strpos($source, 'evazar_product_search_index_find_remaining_published_product()') !== false, 'Search index readiness uses a dedicated completeness probe');
check_result(strpos($source, "evazar_product_search_index_backfill_batch((int) (\$search_settings['index_batch_size'] ?? 250))") !== false, 'Search index backfill batch size uses the validated search setting');
check_result(strpos($source, 'evazar_product_search_index_sync($post_id)') !== false, 'Core product updates maintain the search index');
check_result(strpos($source, "add_action('before_delete_post'") !== false, 'Deleted products are removed from the search index');
check_result(strpos($source, 'pm_core_err') !== false, 'Index readiness accounts for canonical Core index failures');
$backfill_start = strpos($source, 'function evazar_product_search_index_backfill_batch(');
$backfill_end = strpos($source, "\nadd_action('evazar_product_index_backfill'", $backfill_start);
$backfill_fn = ($backfill_start !== false && $backfill_end !== false) ? substr($source, $backfill_start, $backfill_end - $backfill_start) : '';
check_result(strpos($backfill_fn, 'has_core_sync_error') !== false && strpos($backfill_fn, '!empty($row->has_core_sync_error)') !== false, 'Search backfill retries the canonical index when a current-version row still has a Core sync error');


$GLOBALS['test_options']['evazar_product_search_index_state'] = 'ready';
evazar_product_index_mark_sync_failure(777, 'product_row_replace_failed');
check_result(get_option('evazar_product_search_index_state') === 'building', 'A Core index sync failure disables the indexed-search fast path until backfill repairs canonical data');
$complete_helper_pos = strpos($source, 'function evazar_product_search_index_find_remaining_published_product()');
$verify_call_pos = strpos($source, '$verification = evazar_product_search_index_find_remaining_published_product();');
$ready_write_pos = strpos($source, 'update_option(\'evazar_product_search_index_state\', $ready ? \'ready\' : \'building\', false);');
check_result($complete_helper_pos !== false && $verify_call_pos !== false && $ready_write_pos !== false && $verify_call_pos > $ready_write_pos, 'Readiness is verified again after a provisional ready write to avoid stale completion decisions');
$failure_fn_start = strpos($source, 'function evazar_product_index_mark_sync_failure(');
$failure_fn_end = strpos($source, "\nfunction evazar_product_index_clear_sync_failure", $failure_fn_start);
$failure_fn = ($failure_fn_start !== false && $failure_fn_end !== false) ? substr($source, $failure_fn_start, $failure_fn_end - $failure_fn_start) : '';
$failure_marker_pos = strpos($failure_fn, 'update_post_meta($post_id, \'_evazar_product_index_sync_error\', $code);');
$failure_state_pos = strrpos($failure_fn, "update_option('evazar_product_search_index_state', 'building', false);");
check_result($failure_fn !== '' && $failure_marker_pos !== false && $failure_state_pos !== false && $failure_state_pos > $failure_marker_pos, 'Core failure marker is persisted before fail-closed state update');
$GLOBALS['test_options']['evazar_product_search_index_state'] = 'ready';

echo "RESULT: {$passed} passed, {$failed} failed\\n";
exit($failed ? 1 : 0);
