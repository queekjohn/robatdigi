<?php
if (!defined('ABSPATH')) define('ABSPATH', '/tmp/wordpress/');
if (!function_exists('add_action')) { function add_action(...$args) {} }
if (!function_exists('absint')) { function absint($value) { return abs((int)$value); } }
require_once dirname(__DIR__) . '/search-settings.php';
$root = dirname(__DIR__);
$settings = file_get_contents($root . '/search-settings.php');
$index = file_get_contents($root . '/product-index.php');
$main = file_get_contents($root . '/evazar-core.php');
$checks = [
 'Search settings submenu is registered under EVazar products' => strpos($settings, "add_submenu_page(") !== false && strpos($settings, "'edit.php?post_type=evazar_product'") !== false && strpos($settings, "'evazar-search-settings'") !== false,
 'Only administrators with manage_options may access the page/action' => strpos($settings, "current_user_can('manage_options')") !== false,
 'Index status reports published, indexed, missing and sync-error counts' => strpos($settings, "'total' => 0") !== false && strpos($settings, "'indexed' => 0") !== false && strpos($settings, "'missing' => 0") !== false && strpos($settings, "'errors' => 0") !== false,
 'Status detects stale ready flag using live indexed counts' => strpos($settings, '$data[\'indexed\'] < $data[\'total\']') !== false,
 'A stale ready flag is changed to building and backfill scheduling is ensured' => strpos($settings, "update_option('evazar_product_search_index_state', 'building', false);") !== false && strpos($settings, 'evazar_product_index_schedule_backfill()') !== false,
 'Manual batch action validates nonce and never truncates tables' => strpos($settings, "check_admin_referer('evazar_search_index_run_batch')") !== false && strpos($settings, 'TRUNCATE') === false && strpos($settings, 'DROP TABLE') === false,
 'Five settings are registered with sanitizers' => substr_count($settings, 'register_setting(\'evazar_search_settings_group\'') === 5,
 'Supported values are constrained to explicit safe choices' => strpos($settings, '[2, 3, 4]') !== false && strpos($settings, '[150, 250, 350, 500, 750]') !== false && strpos($settings, '[3, 5, 8]') !== false && strpos($settings, '[100, 250, 500]') !== false,
 'Sanitizers accept supported values and reject unsupported values' => evazar_search_sanitize_checkbox('0') === '0' && evazar_search_sanitize_checkbox('1') === '1' && evazar_search_sanitize_checkbox(['1']) === '0' && evazar_search_sanitize_min_chars(4) === 4 && evazar_search_sanitize_min_chars(99) === 2 && evazar_search_sanitize_min_chars(['4']) === 2 && evazar_search_sanitize_debounce(750) === 750 && evazar_search_sanitize_debounce(275) === 250 && evazar_search_sanitize_debounce(['750']) === 250 && evazar_search_sanitize_live_product_limit(8) === 8 && evazar_search_sanitize_live_product_limit(99) === 5 && evazar_search_sanitize_live_product_limit(['8']) === 5 && evazar_search_sanitize_batch_size(500) === 500 && evazar_search_sanitize_batch_size(77) === 250 && evazar_search_sanitize_batch_size(['500']) === 250,
 'Search index acceleration toggle has a Core runtime guard' => strpos($index, 'evazar_product_search_index_acceleration_enabled()') !== false && strpos($index, "get_option('evazar_search_indexed_enabled', '1')") !== false,
 'Core loads the admin settings file only in admin context' => strpos($main, "require_once plugin_dir_path(__FILE__) . 'search-settings.php';") !== false,
];
$failed = 0;
foreach ($checks as $name => $ok) { echo ($ok ? 'PASS: ' : 'FAIL: ') . $name . "\n"; if (!$ok) $failed++; }
echo 'RESULT: ' . (count($checks)-$failed) . ' passed, ' . $failed . " failed\n";
exit($failed ? 1 : 0);
