<?php
// Local isolated regression test for the manual brand registration helper (no WordPress/network required).
define('ABSPATH', '/wp-test/');
$GLOBALS['bsr_options'] = array('evazar_cf_worker_urls'=>'https://worker.example.workers.dev', 'evazar_cf_worker_url'=>'', 'evazar_cf_worker_token'=>'test-token', 'evazar_brand_slug_redirects'=>array());
$GLOBALS['bsr_terms'] = array();
$GLOBALS['bsr_meta'] = array();
$GLOBALS['bsr_worker_calls'] = array();
$GLOBALS['bsr_worker_body'] = array(
    'success'=>true, 'version'=>'1.13.22', 'source_api'=>'v1-brand-search',
    'identity'=>array('brand_id'=>'1266','brand_code'=>'carrera-brand','brand_fa'=>'کررا','brand_en'=>'Carrera','source_url'=>'/brand/carrera-brand/','source_slug'=>'carrera-brand','api_source_url'=>'/brand/carrera-brand/','url_confirmed'=>true,'code_confirmed'=>true),
);
function add_action(...$args) {}
$GLOBALS['bsr_submenus'] = array();
function add_submenu_page(...$args) {$GLOBALS['bsr_submenus'][] = $args;}
function add_management_page(...$args) {throw new Exception('Brand registration must not appear under Tools');}
function admin_url($path=''){return 'https://wp.example/wp-admin/' . ltrim((string)$path, '/');}
function add_query_arg($args, $url=''){if(!is_array($args))$args=array($args);return rtrim($url,'?') . (strpos($url,'?')===false?'?':'&') . http_build_query($args);}

function get_current_user_id(){return 77;}
function get_option($key,$default=false){return array_key_exists($key,$GLOBALS['bsr_options'])?$GLOBALS['bsr_options'][$key]:$default;}
function update_option($key,$value,$autoload=null){$GLOBALS['bsr_options'][$key]=$value;return true;}
function get_term_meta($id,$key,$single=true){return $GLOBALS['bsr_meta'][$id][$key]??'';}
function get_terms($args=array()){return $GLOBALS['bsr_terms'];}
function get_term_by($field,$value,$taxonomy){foreach($GLOBALS['bsr_terms'] as $term){if($field==='slug' && ($term->slug??'')===$value)return $term;}return false;}
function taxonomy_exists($tax){return $tax==='evazar_brand';}
function sanitize_title($s){return strtolower(trim(preg_replace('/[^a-z0-9._-]+/i','-',(string)$s),'-'));}
function sanitize_text_field($s){return trim(strip_tags((string)$s));}
function sanitize_key($s){return preg_replace('/[^a-z0-9_\-]/','',strtolower((string)$s));}
function absint($s){return abs((int)$s);}
function wp_json_encode($v){return json_encode($v);}
function evazar_worker_auth_headers(){return array('X-Evazar-Internal-Token'=>'test-token');}
function evazar_sanitize_primary_worker_urls($value){
    $urls=array();foreach(preg_split('/[\\r\\n,]+/',(string)$value) as $line){$line=trim($line);if($line==='')continue;$p=parse_url($line);if(!is_array($p)||strtolower($p['scheme']??'')!=='https'||empty($p['host'])||isset($p['user'])||isset($p['pass'])||isset($p['query'])||isset($p['fragment']))continue;$urls[]=rtrim($line,'/');}return implode("\n",array_values(array_unique($urls)));
}
function evazar_normalize_digikala_brand_source_path($value){
    $v=trim((string)$value);if($v==='')return ''; $path=$v;
    if(preg_match('#^https?://#i',$v)){$p=parse_url($v);if(!is_array($p)||!in_array(strtolower($p['host']??''),array('digikala.com','www.digikala.com'),true)||isset($p['user'])||isset($p['pass'])||isset($p['port'])||isset($p['query'])||isset($p['fragment']))return '';$path=$p['path']??'';}
    if(preg_match('#^/(?:brand|brand-landing)/([\p{L}\p{M}\p{N}]+(?:[._-][\p{L}\p{M}\p{N}]+)*)/?$#iu',$path,$m))return '/brand/'.strtolower($m[1]).'/';return '';
}
class WP_Error {private $code;private $message;public function __construct($c='',$m=''){ $this->code=$c;$this->message=$m;}public function get_error_code(){return $this->code;}public function get_error_message(){return $this->message;}}
function is_wp_error($v){return $v instanceof WP_Error;}
function wp_remote_retrieve_response_code($r){return (int)($r['code']??0);}
function wp_remote_retrieve_body($r){return (string)($r['body']??'');}
function evazar_primary_worker_request($path='',$query=array(),$args=array(),$method='GET',$purpose='default'){
    $GLOBALS['bsr_worker_calls'][]=array('path'=>$path,'query'=>$query,'args'=>$args,'method'=>$method,'purpose'=>$purpose);
    return array('code'=>200,'body'=>json_encode($GLOBALS['bsr_worker_body']));
}
require_once dirname(__DIR__) . '/brand-source-registration.php';
evazar_bsr_register_menu();
$passed=0;$failed=0;
function bsr_check($label,$ok){global $passed,$failed;if($ok){$passed++;echo "PASS: $label\n";}else{$failed++;fwrite(STDERR,"FAIL: $label\n");}}

// Menu placement regressions: brand registration must live under the EVazar custom product menu.
$menuSource=file_get_contents(dirname(__DIR__) . '/brand-source-registration.php');
bsr_check('registration tool is registered as a submenu of EVazar Core products',count($GLOBALS['bsr_submenus'])===1&&($GLOBALS['bsr_submenus'][0][0]??'')==='edit.php?post_type=evazar_product'&&($GLOBALS['bsr_submenus'][0][4]??'')==='evazar-brand-source-register');
bsr_check('registration tool no longer registers under WordPress Tools',strpos($menuSource,'add_management_page(')===false&&strpos($menuSource,"admin_url('tools.php")===false);
$registrationAdminUrl=evazar_bsr_admin_page_url();
bsr_check('registration page helper produces the correct admin.php?page URL',strpos($registrationAdminUrl,'/admin.php?page=evazar-brand-source-register')!==false);
bsr_check('registration preview and cancel links target the plugin admin page',strpos($menuSource,"admin_url('admin.php')")!==false&&strpos($menuSource,'evazar_bsr_admin_page_url')!==false);

$identity=evazar_bsr_fetch_identity_via_worker('https://www.digikala.com/brand/carrera-brand/');
bsr_check('valid URL produces explicit source identity from Worker response',!is_wp_error($identity)&&$identity['brand_id']==='1266'&&$identity['brand_code']==='carrera-brand'&&$identity['brand_fa']==='کررا'&&$identity['public_slug']==='carrera-brand');
$call=end($GLOBALS['bsr_worker_calls']);
bsr_check('Core makes a server-side POST to configured Worker route with internal token',($call['path']??'')==='brand-source/inspect'&&($call['method']??'')==='POST'&&($call['purpose']??'')==='brand_register'&&($call['args']['headers']['X-Evazar-Internal-Token']??'')==='test-token');
bsr_check('Worker request body contains the normalized explicit URL only',json_decode((string)($call['args']['body']??''),true)===array('source_url'=>'/brand/carrera-brand/'));
$before=count($GLOBALS['bsr_worker_calls']);$bad=evazar_bsr_fetch_identity_via_worker('https://example.com/brand/carrera-brand/');
bsr_check('foreign host is rejected before any Worker request',is_wp_error($bad)&&count($GLOBALS['bsr_worker_calls'])===$before);
$GLOBALS['bsr_options']['evazar_cf_worker_urls']='';$GLOBALS['bsr_options']['evazar_cf_worker_url']='';$noWorker=evazar_bsr_fetch_identity_via_worker('https://www.digikala.com/brand/carrera-brand/');
bsr_check('tool refuses to use image CDN or direct origin when main Worker is not configured',is_wp_error($noWorker)&&$noWorker->get_error_code()==='evazar_bsr_worker_unconfigured');
$GLOBALS['bsr_options']['evazar_cf_worker_urls']='not-a-valid-worker-url';$GLOBALS['bsr_options']['evazar_cf_worker_url']='';$before=count($GLOBALS['bsr_worker_calls']);
$invalidConfiguredWorker=evazar_bsr_fetch_identity_via_worker('https://www.digikala.com/brand/carrera-brand/');
bsr_check('invalid non-empty Worker pool fails closed and never dispatches through the image-host fallback',is_wp_error($invalidConfiguredWorker)&&$invalidConfiguredWorker->get_error_code()==='evazar_bsr_worker_unconfigured'&&count($GLOBALS['bsr_worker_calls'])===$before);
$GLOBALS['bsr_options']['evazar_cf_worker_urls']='https://worker.example.workers.dev';
$GLOBALS['bsr_worker_body']['identity']['source_url']='/brand/other-brand/';$mismatch=evazar_bsr_fetch_identity_via_worker('https://www.digikala.com/brand/carrera-brand/');
bsr_check('worker/source path mismatch is rejected',is_wp_error($mismatch)&&$mismatch->get_error_code()==='evazar_bsr_worker_identity_mismatch');
$GLOBALS['bsr_worker_body']['identity']['source_url']='/brand/carrera-brand/';
$GLOBALS['bsr_terms']=array();$check=evazar_bsr_check_conflicts($identity);
bsr_check('clean source ID, URL, public slug can be approved for creation',!is_wp_error($check));
$GLOBALS['bsr_terms']=array((object)array('term_id'=>900,'name'=>'Carrera old','slug'=>'old-carrera'));$GLOBALS['bsr_meta'][900]=array('_evazar_dk_brand_id'=>'1266');
$check=evazar_bsr_check_conflicts($identity);
bsr_check('existing source brand ID blocks duplicate term creation',is_wp_error($check)&&$check->get_error_code()==='evazar_bsr_source_id_exists');
$GLOBALS['bsr_terms']=array((object)array('term_id'=>901,'name'=>'Brand owner','slug'=>'carrera-brand'));$GLOBALS['bsr_meta'][901]=array('_evazar_dk_brand_id'=>'99','_evazar_dk_url'=>'/brand/other/');
$check=evazar_bsr_check_conflicts($identity);
bsr_check('occupied public slug blocks creation without mutating the current term',is_wp_error($check)&&$check->get_error_code()==='evazar_bsr_public_slug_exists'&&$GLOBALS['bsr_terms'][0]->slug==='carrera-brand');
$GLOBALS['bsr_terms']=array();$GLOBALS['bsr_meta']=array();$GLOBALS['bsr_options']['evazar_brand_slug_redirects']=array('carrera-brand'=>123);
$check=evazar_bsr_check_conflicts($identity);
bsr_check('redirect-reserved slug blocks creation without touching redirects',is_wp_error($check)&&$check->get_error_code()==='evazar_bsr_redirect_slug_reserved'&&$GLOBALS['bsr_options']['evazar_brand_slug_redirects']['carrera-brand']===123);
$source=file_get_contents(dirname(__DIR__) . '/brand-source-registration.php');
bsr_check('registration tool has no direct-origin request fallback',strpos($source,'wp_remote_get(')===false&&strpos($source,'wp_remote_post(')===false&&strpos($source,'wp_remote_request(')===false);
bsr_check('registration tool does not assign products, edit redirects, or directly call cache purge',strpos($source,'wp_set_object_terms(')===false&&strpos($source,'update_option(\'evazar_brand_slug_redirects\'')===false&&strpos($source,'evazar_purge')===false&&strpos($source,'cache-purge')===false);
bsr_check('successful registration enqueues the new brand for taxonomy SEO after metadata verification',strpos($source,'evazar_taxonomy_seo_enqueue_new_term($term_id, \'evazar_brand\', 0)')!==false);
bsr_check('confirmation compares API URL and URL/code confirmation evidence against preview',strpos($source,"'api_source_url','url_confirmed','code_confirmed','source_api'")!==false);
echo "\nRESULT: {$passed} passed, {$failed} failed\n";exit($failed?1:0);
