<?php
/** Regression checks for queue retry/cooldown messages using the WordPress site timezone exactly once. */
$root = dirname(__DIR__);
$queue = file_get_contents($root . '/queue-manager.php');
$core = file_get_contents($root . '/evazar-core.php');
$importer = file_get_contents($root . '/importer.php');
$assertions = 0;
$failures = 0;
function qlt_check($name, $condition) {
    global $assertions, $failures;
    $assertions++;
    if (!$condition) {
        $failures++;
        fwrite(STDERR, "FAIL: {$name}\n");
    } else {
        echo "PASS: {$name}\n";
    }
}
qlt_check('queue-manager has no raw date_i18n timestamp conversions', strpos($queue, "date_i18n('") === false);
qlt_check('retry and cooldown labels reuse the shared site-local datetime formatter', substr_count($queue, 'evazar_queue_local_datetime($resume_at)') >= 7);
qlt_check('queue statistics timestamp uses the same formatter with time-only format', strpos($queue, 'evazar_queue_local_datetime((int) $stats[\'generated_at\'], \'H:i:s\')') !== false);
qlt_check('queue formatter delegates to shared Gemini formatter when available', strpos($queue, 'evazar_gemini_local_datetime($timestamp, $format)') !== false);
qlt_check('queue formatter fallback uses wp_date with wp_timezone', strpos($queue, 'wp_date($format, $timestamp, $timezone)') !== false && strpos($queue, 'wp_timezone()') !== false);
qlt_check('shared Gemini formatter uses wp_date with wp_timezone', strpos($importer, 'wp_date((string) $format, $timestamp, $timezone)') !== false && strpos($importer, 'wp_timezone()') !== false);
qlt_check('importer formatter returns empty for non-positive timestamp rather than current/offset date', strpos($importer, 'if ($timestamp <= 0) return \'\';') !== false);
$importer_pos = strpos($core, "require_once plugin_dir_path(__FILE__) . 'importer.php';");
$queue_pos = strpos($core, "require_once plugin_dir_path(__FILE__) . 'queue-manager.php';");
qlt_check('importer formatter is loaded before queue-manager', $importer_pos !== false && $queue_pos !== false && $importer_pos < $queue_pos);
if ($failures) {
    fwrite(STDERR, "{$failures}/{$assertions} failed\n");
    exit(1);
}
echo "{$assertions} assertions passed.\n";
