<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
$GLOBALS['assertions'] = 0;
function check_setting_location($condition, $message) {
    $GLOBALS['assertions']++;
    if (!$condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
    echo "PASS: {$message}\n";
}
$core = file_get_contents(__DIR__ . '/../evazar-core.php');
$queue = file_get_contents(__DIR__ . '/../queue-manager.php');

check_setting_location(strpos($core, "add_settings_field('evazar_ai_product_batch_size'") === false, 'Gemini batch setting is no longer registered in the general AI settings page');
check_setting_location(strpos($core, 'function evazar_ai_product_batch_size_render') === false, 'the obsolete settings-page field renderer is removed');
check_setting_location(strpos($core, "register_setting('evazar_core_settings_group', 'evazar_ai_product_batch_size'") !== false, 'existing option registration and sanitizer remain available');

$queue_heading = strpos($queue, 'تنظیمات زمان‌بندی و سرعت پردازش صف');
$queue_field = strpos($queue, 'name="evazar_ai_product_batch_size"');
check_setting_location($queue_heading !== false && $queue_field !== false && $queue_field > $queue_heading, 'Gemini batch selector is rendered inside the import queue scheduling section');
check_setting_location(strpos($queue, 'id="evazar_ai_product_batch_size"') !== false, 'Gemini selector has a matching accessible label target');
check_setting_location(strpos($queue, '$gemini_batch_sizes = [2, 3, 4, 5, 6, 8, 10, 12, 15, 20, 25, 30, 40, 50]') !== false, 'queue selector preserves supported size choices including 40 and 50');
check_setting_location(strpos($queue, "isset(\$_POST['evazar_ai_product_batch_size'])") !== false, 'queue form save handler reads the moved setting');
check_setting_location(strpos($queue, 'evazar_sanitize_ai_product_batch_size($posted_batch_size)') !== false, 'queue form save handler uses the established batch-size sanitizer');
check_setting_location(strpos($queue, "update_option('evazar_ai_product_batch_size', \$gemini_batch_size, false)") !== false, 'queue form persists to the existing option without renaming it');
check_setting_location(strpos($queue, 'تعداد محصولات هر درخواست Gemini') !== false, 'queue page labels the setting clearly');

fwrite(STDOUT, "\nRESULT: {$GLOBALS['assertions']} assertions passed.\n");
