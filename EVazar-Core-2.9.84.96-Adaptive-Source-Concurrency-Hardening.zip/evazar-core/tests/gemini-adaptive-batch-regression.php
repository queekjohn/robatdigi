<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
define('ABSPATH', __DIR__ . '/');
$GLOBALS['adaptive_test_options'] = ['evazar_ai_product_batch_size' => 50];
$GLOBALS['adaptive_test_events'] = [];

function add_action(...$args) {}
function add_filter(...$args) {}
function absint($value) { return abs((int) $value); }
function get_option($key, $default = false) {
    $value = array_key_exists($key, $GLOBALS['adaptive_test_options']) ? $GLOBALS['adaptive_test_options'][$key] : $default;
    // Deterministically simulate another process replacing an expired lock after this reader observed it.
    if ($key === 'evazar_ai_product_batch_adaptive_lock' && !empty($GLOBALS['adaptive_test_replace_lock_after_read'])) {
        $GLOBALS['adaptive_test_replace_lock_after_read'] = false;
        $GLOBALS['adaptive_test_options'][$key] = (string) ($GLOBALS['adaptive_test_race_replacement'] ?? 'replacement-owner');
    }
    return $value;
}
function update_option($key, $value, $autoload = null) { $GLOBALS['adaptive_test_options'][$key] = $value; return true; }
function add_option($key, $value = '', $deprecated = '', $autoload = 'yes') {
    if (array_key_exists($key, $GLOBALS['adaptive_test_options'])) return false;
    $GLOBALS['adaptive_test_options'][$key] = $value;
    return true;
}
function delete_option($key) { unset($GLOBALS['adaptive_test_options'][$key]); return true; }
function sanitize_key($value) { return strtolower(preg_replace('/[^a-z0-9_\-]/', '', (string) $value)); }
function is_wp_error($value) { return $value instanceof WP_Error; }
function evazar_gemini_log_event($type, $message, $worker = '', $http = 0, $until = 0, $context = []) {
    $GLOBALS['adaptive_test_events'][] = compact('type', 'message', 'worker', 'http', 'until', 'context');
}
function evazar_get_gemini_worker_urls() {
    return [
        'https://a.example.workers.dev', 'https://b.example.workers.dev',
        'https://c.example.workers.dev', 'https://d.example.workers.dev',
        'https://e.example.workers.dev',
    ];
}
class WP_Error {
    private $code;
    private $message;
    private $data;
    function __construct($code = '', $message = '', $data = null) { $this->code = $code; $this->message = $message; $this->data = $data; }
    function get_error_code() { return $this->code; }
    function get_error_message() { return $this->message; }
    function get_error_data() { return $this->data; }
}

class AdaptiveTestWpdb {
    public $options = 'wp_options';
    function prepare($sql, ...$args) {
        foreach ($args as $arg) $sql = preg_replace('/%s/', "'" . addslashes((string) $arg) . "'", $sql, 1);
        return $sql;
    }
    function query($sql) {
        if (!preg_match("/DELETE FROM wp_options WHERE option_name = '([^']*)' AND option_value = '([^']*)'/", $sql, $m)) return false;
        $key = stripslashes($m[1]);
        $expected = stripslashes($m[2]);
        $actual = (string) ($GLOBALS['adaptive_test_options'][$key] ?? '');
        if ($actual !== $expected) return 0;
        unset($GLOBALS['adaptive_test_options'][$key]);
        return 1;
    }
}

function check_adaptive($condition, $message) {
    $GLOBALS['adaptive_test_assertions'] = ($GLOBALS['adaptive_test_assertions'] ?? 0) + 1;
    if (!$condition) { fwrite(STDERR, "FAIL: {$message}\n"); exit(1); }
    echo "PASS: {$message}\n";
}

require __DIR__ . '/../queue-manager.php';

check_adaptive(evazar_queue_product_batch_size() === 50, 'fresh adaptive state uses configured batch cap');
check_adaptive(evazar_queue_product_batch_parallelism() === 5, 'fresh adaptive state permits up to five configured Workers');
check_adaptive(evazar_queue_product_batch_adaptive_error_kind(new WP_Error('gemini_parallel_unavailable', 'Internal endpoint HTTP 503')) === '', 'internal endpoint HTTP 503 is not classified as Gemini upstream failure');
check_adaptive(evazar_queue_product_batch_adaptive_error_kind(new WP_Error('gemini_request_outcome_unknown', 'HTTP 503; result uncertain')) === '', 'uncertain HTTP 503 outcome does not trigger adaptive batch reduction');
check_adaptive(evazar_queue_product_batch_adaptive_error_kind(new WP_Error('gemini_worker_auth_failed', 'Worker authentication HTTP 503')) === '', 'authentication/Worker errors are excluded');
check_adaptive(evazar_queue_product_batch_adaptive_error_kind(new WP_Error('gemini_temporary_unavailable', 'Gemini upstream HTTP 503')) === 'upstream_5xx', 'confirmed Gemini upstream 503 is classified as transient');
check_adaptive(evazar_queue_product_batch_adaptive_error_kind(new WP_Error('gemini_temporary_unavailable', 'Gemini upstream HTTP 504')) === 'upstream_5xx', 'confirmed Gemini upstream 504 is classified as transient');
check_adaptive(evazar_queue_product_batch_adaptive_error_kind(new WP_Error('gemini_temporary_unavailable', 'Worker unavailable', ['status' => 503])) === '', 'status data without an explicit upstream HTTP diagnostic is insufficient');
check_adaptive(evazar_queue_product_batch_adaptive_error_kind(new WP_Error('gemini_temporary_unavailable', 'Gemini upstream HTTP 503', ['http_code' => 502])) === '', 'conflicting structured and diagnostic status codes are excluded');
check_adaptive(evazar_queue_product_batch_adaptive_error_kind(new WP_Error('gemini_temporary_unavailable', 'Gemini upstream HTTP 504', ['http_code' => 504])) === 'upstream_5xx', 'matching explicit upstream status and structured code are accepted');
check_adaptive(evazar_queue_product_batch_adaptive_error_kind(new WP_Error('gemini_temporary_unavailable', 'Gemini upstream HTTP 504', ['http_code' => 503])) === '', 'structured status mismatch is never interpreted as a different upstream error');
check_adaptive(evazar_queue_product_batch_adaptive_error_kind(new WP_Error('gemini_rate_limited', 'Gemini upstream HTTP 429')) === 'rate_limit', 'explicit Gemini upstream HTTP 429 is classified as rate pressure');
check_adaptive(evazar_queue_product_batch_adaptive_error_kind(new WP_Error('gemini_rate_limited', 'Gemini upstream HTTP 429', ['http_code' => 503])) === '', 'conflicting status prevents an incorrect 429 classification');
check_adaptive(evazar_queue_product_batch_adaptive_http_code(new WP_Error('gemini_temporary_unavailable', 'Gemini upstream HTTP 504')) === 504, 'adaptive diagnostics preserve the actual 5xx status');
$serialized_503 = evazar_queue_parallel_response_error_payload(new WP_Error('gemini_temporary_unavailable', 'Gemini upstream HTTP 503', ['http_code' => 503, 'resume_at' => 123, 'api_key' => 'must-not-leak']));
check_adaptive((int) ($serialized_503['data']['http_code'] ?? 0) === 503, 'internal parallel response serialization preserves the safe HTTP status marker');
check_adaptive(!array_key_exists('api_key', (array) ($serialized_503['data'] ?? [])), 'parallel error serialization does not leak unrelated error-data fields');

// A single upstream 5xx reduces only the next batch, not healthy-Worker concurrency.
evazar_queue_product_batch_adaptive_record_failure('upstream_5xx', 1, 1);
check_adaptive(evazar_queue_product_batch_size() === 40, 'first confirmed upstream 5xx reduces batch 50 to 40');
check_adaptive(evazar_queue_product_batch_parallelism() === 5, 'one isolated Worker failure preserves concurrency');

// A consecutive transient error reduces concurrency, while the batch size continues its global ladder.
evazar_queue_product_batch_adaptive_record_failure('upstream_5xx', 1, 1);
check_adaptive(evazar_queue_product_batch_size() === 30, 'second upstream 5xx reduces batch 40 to 30');
check_adaptive(evazar_queue_product_batch_parallelism() === 4, 'repeated upstream errors lower concurrency by one');

// Multiple errors in one parallel wave are recorded as one adaptive event, not one decrement per Worker.
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_adaptive_state'] = [
    'version' => 1, 'configured_batch_size' => 50, 'batch_size' => 50, 'concurrency' => 5,
    'success_streak' => 0, 'failure_streak' => 0, 'last_failure_kind' => '', 'updated_at' => time(),
];
$chunk1 = [['item' => (object) ['dkp' => '101'], 'checkpoint' => ['dkp' => '101']], ['item' => (object) ['dkp' => '102'], 'checkpoint' => ['dkp' => '102']]];
$chunk2 = [['item' => (object) ['dkp' => '201'], 'checkpoint' => ['dkp' => '201']], ['item' => (object) ['dkp' => '202'], 'checkpoint' => ['dkp' => '202']]];
$chunk3 = [['item' => (object) ['dkp' => '301'], 'checkpoint' => ['dkp' => '301']], ['item' => (object) ['dkp' => '302'], 'checkpoint' => ['dkp' => '302']]];
evazar_queue_product_batch_adaptive_observe_wave(
    [$chunk1, $chunk2, $chunk3],
    [
        new WP_Error('gemini_temporary_unavailable', 'Gemini upstream HTTP 503'),
        new WP_Error('gemini_temporary_unavailable', 'Gemini upstream HTTP 503'),
        ['301' => 'ok', '302' => 'ok'],
    ]
);
check_adaptive(evazar_queue_product_batch_size() === 40, 'two simultaneous 503s cause only one batch step per wave');
check_adaptive(evazar_queue_product_batch_parallelism() === 4, 'two simultaneous 503s lower global concurrency by one');
$last_event = end($GLOBALS['adaptive_test_events']);
check_adaptive(($last_event['type'] ?? '') === 'adaptive_batch_adjusted' && (int) ($last_event['context']['failure_count'] ?? 0) === 2, 'adaptive event logs the aggregate wave failure count');
check_adaptive((int) ($last_event['http'] ?? 0) === 503, 'adaptive event reports the actual upstream HTTP status');

// Repeated 429s reduce concurrency, never batch size (which would increase request volume).
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_adaptive_state'] = [
    'version' => 1, 'configured_batch_size' => 50, 'batch_size' => 20, 'concurrency' => 4,
    'success_streak' => 0, 'failure_streak' => 0, 'last_failure_kind' => '', 'updated_at' => time(),
];
evazar_queue_product_batch_adaptive_record_failure('rate_limit', 2, 4);
check_adaptive(evazar_queue_product_batch_size() === 20, '429 rate limit keeps batch size unchanged');
check_adaptive(evazar_queue_product_batch_parallelism() === 3, 'concurrent 429 rate limits reduce concurrency');

// Recovery happens after three consecutive clean requests; batch size rises by ten.
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_adaptive_state'] = [
    'version' => 1, 'configured_batch_size' => 50, 'batch_size' => 20, 'concurrency' => 3,
    'success_streak' => 0, 'failure_streak' => 0, 'last_failure_kind' => '', 'updated_at' => time(),
];
evazar_queue_product_batch_adaptive_record_successes(2);
check_adaptive(evazar_queue_product_batch_size() === 20, 'two successful requests do not recover capacity early');
evazar_queue_product_batch_adaptive_record_successes(1);
check_adaptive(evazar_queue_product_batch_size() === 30, 'three consecutive successes recover batch size by ten');
check_adaptive(evazar_queue_product_batch_parallelism() === 4, 'three consecutive successes recover concurrency by one');
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_adaptive_state']['batch_size'] = 40;
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_adaptive_state']['success_streak'] = 0;
evazar_queue_product_batch_adaptive_record_successes(3);
check_adaptive(evazar_queue_product_batch_size() === 50, 'recovery increases batch size by ten without exceeding configured cap');

// Verify the exact floor ladder and never exceed the manual cap.
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_adaptive_state'] = [
    'version' => 1, 'configured_batch_size' => 50, 'batch_size' => 50, 'concurrency' => 5,
    'success_streak' => 0, 'failure_streak' => 0, 'last_failure_kind' => '', 'updated_at' => time(),
];
$expected_sizes = [40, 30, 20, 10, 5, 5];
foreach ($expected_sizes as $expected) {
    evazar_queue_product_batch_adaptive_record_failure('upstream_5xx', 1, 1);
    check_adaptive(evazar_queue_product_batch_size() === $expected, 'adaptive batch ladder reaches expected size ' . $expected);
}
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_size'] = 20;
check_adaptive(evazar_queue_product_batch_size() === 20, 'manual batch-cap change resets adaptive batch to the new cap');
evazar_queue_product_batch_adaptive_record_failure('upstream_5xx', 1, 1);
check_adaptive(evazar_queue_product_batch_size() === 10, 'after cap change the new configuration is used for the next adaptive step');

// Only unsent parallel chunks are rebuilt after adaptive capacity changes.
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_size'] = 50;
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_adaptive_state'] = [
    'version' => 1, 'configured_batch_size' => 50, 'batch_size' => 40, 'concurrency' => 4,
    'success_streak' => 0, 'failure_streak' => 1, 'last_failure_kind' => 'upstream_5xx', 'updated_at' => time(),
];
$chunk50a = array_fill(0, 50, ['item' => (object) ['dkp' => '501'], 'checkpoint' => ['dkp' => '501']]);
$chunk50b = array_fill(0, 50, ['item' => (object) ['dkp' => '502'], 'checkpoint' => ['dkp' => '502']]);
$repartitioned = evazar_queue_product_batch_adaptive_repartition_chunks([$chunk50a, $chunk50b], 1);
check_adaptive(!empty($repartitioned['repartitioned']), 'oversized unsent parallel chunks are re-partitioned after a batch reduction');
check_adaptive(count($repartitioned['chunks']) === 3, 're-partition preserves the processed prefix and splits the unsent 50 products into two chunks');
check_adaptive(count($repartitioned['chunks'][0]) === 50 && count($repartitioned['chunks'][1]) === 40 && count($repartitioned['chunks'][2]) === 10, 're-partition never re-sends the processed prefix and does not exceed the effective cap');
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_adaptive_state'] = [
    'version' => 1, 'configured_batch_size' => 50, 'batch_size' => 50, 'concurrency' => 4,
    'success_streak' => 0, 'failure_streak' => 0, 'last_failure_kind' => '', 'updated_at' => time(),
];
$chunk40a = array_fill(0, 40, ['item' => (object) ['dkp' => '401'], 'checkpoint' => ['dkp' => '401']]);
$chunk10 = array_fill(0, 10, ['item' => (object) ['dkp' => '410'], 'checkpoint' => ['dkp' => '410']]);
$chunk40b = array_fill(0, 40, ['item' => (object) ['dkp' => '402'], 'checkpoint' => ['dkp' => '402']]);
$forced_repartition = evazar_queue_product_batch_adaptive_repartition_chunks([$chunk40a, $chunk40b, $chunk10], 1, true);
check_adaptive(!empty($forced_repartition['repartitioned']) && count($forced_repartition['chunks']) === 2, 'capacity recovery coalesces only the unsent tail after ten clean requests');
check_adaptive(count($forced_repartition['chunks'][0]) === 40 && count($forced_repartition['chunks'][1]) === 50, 'capacity recovery preserves the already-processed prefix and restores the larger next batch');

// Unknown/invalid responses break the success streak but do not reduce size or concurrency.
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_size'] = 50;
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_adaptive_state'] = [
    'version' => 1, 'configured_batch_size' => 50, 'batch_size' => 35, 'concurrency' => 3,
    'success_streak' => 7, 'failure_streak' => 0, 'last_failure_kind' => '', 'updated_at' => time(),
];
evazar_queue_product_batch_adaptive_observe_wave([$chunk1], [new WP_Error('gemini_parallel_unavailable', 'Internal HTTP 503')]);
check_adaptive(evazar_queue_product_batch_size() === 35, 'internal endpoint errors do not shrink adaptive batch');
check_adaptive(evazar_queue_product_batch_parallelism() === 3, 'internal endpoint errors do not reduce concurrency');
check_adaptive((int) get_option('evazar_ai_product_batch_adaptive_state', [])['success_streak'] === 0, 'non-adaptive errors reset the consecutive-success streak');

// Successful response validation must require every requested DKP and reject nested WP_Error values.
check_adaptive(evazar_queue_product_batch_adaptive_response_is_successful($chunk1, ['101' => 'ok', '102' => 'ok']), 'complete valid response map counts as a clean request');
check_adaptive(evazar_queue_product_batch_adaptive_response_is_successful([$chunk1[0]], ['101' => 'ok']), 'an explicitly permitted singleton retry can count as a clean request');
check_adaptive(!evazar_queue_product_batch_adaptive_response_is_successful($chunk1, ['101' => 'ok']), 'missing product result is not counted as success');
check_adaptive(!evazar_queue_product_batch_adaptive_response_is_successful($chunk1, ['101' => 'ok', '102' => new WP_Error('AI_BATCH_ITEM_FAILED', 'bad')]), 'nested product error is not counted as success');
check_adaptive(!evazar_queue_product_batch_adaptive_response_is_successful($chunk1, ['101' => 'ok', '102' => null]), 'non-string/empty product result is not counted as success');

// Guard the real integration points in the source files, in addition to isolated state-machine behavior.
$queue_source = file_get_contents(__DIR__ . '/../queue-manager.php');
$importer_source = file_get_contents(__DIR__ . '/../importer.php');
check_adaptive(is_string($queue_source) && strpos($queue_source, "['resume_at', 'request_id', 'retry_after', 'http_code']") !== false, 'parallel response error payload retains only the safe HTTP status needed by adaptation');
check_adaptive(is_string($queue_source) && strpos($queue_source, 'evazar_queue_product_batch_adaptive_observe_wave($wave_chunks, $wave_responses);') !== false, 'adaptive controller is connected to completed parallel waves');
check_adaptive(is_string($queue_source) && strpos($queue_source, 'evazar_queue_product_batch_adaptive_repartition_chunks(') !== false, 'unsent parallel chunks are repartitioned when adaptive capacity changes');
check_adaptive(is_string($queue_source) && strpos($queue_source, 'while ($batch_offset < count($process_entries))') !== false, 'serial request loop re-evaluates adaptive batch size for unsent work');
check_adaptive(is_string($queue_source) && strpos($queue_source, 'serial_remaining_entries = array_slice($process_entries, $batch_offset)') !== false, 'serial repartition uses only unsent entries');
check_adaptive(is_string($queue_source) && strpos($queue_source, 'evazar_queue_product_batch_adaptive_record_successes(1);') !== false, 'serial batch successes feed the recovery counter');
check_adaptive(is_string($importer_source) && substr_count($importer_source, "'http_code' => (int) \$code") >= 2, 'direct upstream 5xx errors preserve the actual HTTP code as structured error data');
check_adaptive(is_string($importer_source) && strpos($importer_source, "'Gemini پاسخ موقت HTTP ' . \$code . ' داد؛ این Worker") !== false, 'assigned-Worker diagnostic reports the actual upstream status instead of hardcoded 503');
check_adaptive(is_string($importer_source) && strpos($importer_source, 'HTTP 429) است؛ فقط همین Worker') !== false, 'confirmed upstream 429 carries an explicit HTTP marker for concurrency adaptation');
check_adaptive(is_string($importer_source) && strpos($importer_source, "'http_code' => 429") !== false, 'assigned upstream 429 preserves its status as structured error data');

// State updates should release their lock even after each mutation, without deleting a replacement owner's lock.
check_adaptive(!array_key_exists('evazar_ai_product_batch_adaptive_lock', $GLOBALS['adaptive_test_options']), 'adaptive state lock is released after updates');
check_adaptive(evazar_queue_product_batch_adaptive_lock_acquire(), 'adaptive lock can be reacquired for ownership-safety testing');
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_adaptive_lock'] = time() . ':replacement-owner';
evazar_queue_product_batch_adaptive_lock_release();
check_adaptive(get_option('evazar_ai_product_batch_adaptive_lock', '') === time() . ':replacement-owner', 'an old lock owner cannot delete a replacement lock');
delete_option('evazar_ai_product_batch_adaptive_lock');

// Stale-lock reclamation must not delete a replacement lock installed between read and compare-delete.
$stale_lock_value = (string) (time() - 60) . ':stale-owner';
$replacement_lock_value = (string) time() . ':concurrent-replacement';
$GLOBALS['adaptive_test_options']['evazar_ai_product_batch_adaptive_lock'] = $stale_lock_value;
$GLOBALS['adaptive_test_race_replacement'] = $replacement_lock_value;
$GLOBALS['adaptive_test_replace_lock_after_read'] = true;
$GLOBALS['wpdb'] = new AdaptiveTestWpdb();
$stale_reclaim_acquired = evazar_queue_product_batch_adaptive_lock_acquire();
check_adaptive(!$stale_reclaim_acquired, 'stale-lock reclamation does not claim a lock that another process replaced');
check_adaptive(get_option('evazar_ai_product_batch_adaptive_lock', '') === $replacement_lock_value, 'conditional stale-lock deletion preserves the concurrent replacement owner');
unset($GLOBALS['wpdb'], $GLOBALS['adaptive_test_race_replacement'], $GLOBALS['adaptive_test_replace_lock_after_read']);
delete_option('evazar_ai_product_batch_adaptive_lock');

$total = (int) $GLOBALS['adaptive_test_assertions'];
echo "\nRESULT: {$total} adaptive batch assertions passed.\n";
