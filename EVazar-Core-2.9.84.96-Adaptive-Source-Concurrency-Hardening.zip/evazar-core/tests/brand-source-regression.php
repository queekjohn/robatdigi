<?php
// Local regression harness for EVazar brand source parsing, persistence, and 301 mappings.
// Runs without a WordPress install; a small deterministic WordPress test double is used.
error_reporting(E_ALL);
ini_set('display_errors', '1');
define('ABSPATH', __DIR__ . '/');

class WP_Error {
    private $code; private $message; private $data;
    public function __construct($code = '', $message = '', $data = null) { $this->code=$code; $this->message=$message; $this->data=$data; }
    public function get_error_code() { return $this->code; }
    public function get_error_message() { return $this->message; }
    public function get_error_data() { return $this->data; }
}
class TestRedirect extends Exception { public $target; public $status; public function __construct($target, $status) { parent::__construct('redirect'); $this->target=$target; $this->status=$status; } }
$GLOBALS['test_terms'] = [];
$GLOBALS['test_term_meta'] = [];
$GLOBALS['test_post_meta'] = [];
$GLOBALS['test_fail_post_meta_key'] = '';
$GLOBALS['test_fail_term_meta_key'] = '';
$GLOBALS['test_object_terms'] = [];
$GLOBALS['test_fail_object_term_assignment'] = false;
$GLOBALS['test_suppress_object_term_assignment'] = false;
$GLOBALS['test_options'] = ['evazar_brand_slug_redirects' => []];
$GLOBALS['test_fail_update_option_key'] = '';
$GLOBALS['test_fail_wp_update_term_ids'] = [];
$GLOBALS['test_noop_wp_update_term_ids'] = [];
$GLOBALS['test_transients'] = [];
$GLOBALS['test_next_term_id'] = 100;
$GLOBALS['test_submenu_pages'] = [];
$GLOBALS['test_current_request'] = '';
function add_action(...$args) {} function add_filter(...$args) {} function remove_filter(...$args) {} function remove_action(...$args) {} function add_shortcode(...$args) {}
function register_activation_hook(...$args) {} function register_deactivation_hook(...$args) {}
function plugin_dir_path($file) { return dirname($file) . '/'; }
function wp_upload_dir() { return ['basedir' => sys_get_temp_dir() . '/evazar-brand-source-test-uploads']; }
function wp_mkdir_p($dir) { return is_dir($dir) || @mkdir($dir, 0775, true); }
function wp_parse_url($url, $component = -1) { return parse_url($url, $component); }
function sanitize_title($value) { $value = strtolower(trim((string)$value)); $value = preg_replace('/[^a-z0-9_-]+/', '-', $value); return trim($value, '-'); }
function sanitize_key($value) { return preg_replace('/[^a-z0-9_\-]/', '', strtolower((string)$value)); }
if (!function_exists('mb_stripos')) { function mb_stripos($haystack, $needle, $offset = 0, $encoding = null) { return stripos((string)$haystack, (string)$needle, (int)$offset); } }
if (!function_exists('mb_strpos')) { function mb_strpos($haystack, $needle, $offset = 0, $encoding = null) { return strpos((string)$haystack, (string)$needle, (int)$offset); } }
if (!function_exists('mb_strtolower')) { function mb_strtolower($value, $encoding = null) { return strtolower((string)$value); } }
function sanitize_text_field($value) { return trim(strip_tags((string)$value)); }
function wp_strip_all_tags($value) { return strip_tags((string)$value); }
function absint($value) { return abs((int)$value); }
function is_wp_error($value) { return $value instanceof WP_Error; }
function taxonomy_exists($taxonomy) { return in_array($taxonomy, ['evazar_brand', 'evazar_category'], true); }
function get_option($key, $default = false) { return array_key_exists($key, $GLOBALS['test_options']) ? $GLOBALS['test_options'][$key] : $default; }
function update_option($key, $value, $autoload = null) { if (($GLOBALS['test_fail_update_option_key'] ?? '') === $key) return false; $GLOBALS['test_options'][$key] = $value; return true; }
function get_transient($key) { return array_key_exists($key, $GLOBALS['test_transients']) ? $GLOBALS['test_transients'][$key] : false; }
function set_transient($key, $value, $expiration = 0) { $GLOBALS['test_transients'][$key] = $value; return true; }
function delete_transient($key) { unset($GLOBALS['test_transients'][$key]); return true; }
function get_term_meta($term_id, $key, $single = true) { return $GLOBALS['test_term_meta'][$term_id][$key] ?? ''; }
function update_term_meta($term_id, $key, $value) { if (($GLOBALS['test_fail_term_meta_key'] ?? '') === (string)$key) return false; $GLOBALS['test_term_meta'][$term_id][$key] = $value; return true; }
function delete_term_meta($term_id, $key) { unset($GLOBALS['test_term_meta'][$term_id][$key]); return true; }
function clean_term_cache(...$args) {}
function get_term($term_id, $taxonomy = '') { $term = $GLOBALS['test_terms'][(int)$term_id] ?? null; if ($term && $taxonomy !== '' && isset($term->taxonomy) && $term->taxonomy !== $taxonomy) return null; return $term; }
function get_term_by($field, $value, $taxonomy = '') {
    foreach ($GLOBALS['test_terms'] as $term) {
        if ($taxonomy !== '' && isset($term->taxonomy) && $term->taxonomy !== $taxonomy) continue;
        if (($field === 'slug' && $term->slug === (string)$value) || ($field === 'name' && $term->name === (string)$value) || ($field === 'id' && (int)$term->term_id === (int)$value) || ($field === 'term_id' && (int)$term->term_id === (int)$value)) return clone $term;
    }
    return false;
}
function wp_insert_term($name, $taxonomy, $args = []) {
    $slug = $args['slug'] ?? sanitize_title($name);
    if (get_term_by('slug', $slug, $taxonomy)) return new WP_Error('term_exists', 'term exists', get_term_by('slug', $slug, $taxonomy)->term_id);
    $id = ++$GLOBALS['test_next_term_id'];
    $GLOBALS['test_terms'][$id] = (object)['term_id'=>$id, 'name'=>$name, 'slug'=>$slug, 'taxonomy'=>$taxonomy, 'parent'=>absint($args['parent'] ?? 0), 'count'=>0, 'description'=>'Existing test content'];
    return ['term_id'=>$id];
}
function wp_update_term($term_id, $taxonomy, $args = []) {
    $term_id = (int)$term_id; if (in_array($term_id, $GLOBALS['test_fail_wp_update_term_ids'] ?? [], true)) return new WP_Error('forced_update_failure', 'test failure');
    if (in_array($term_id, $GLOBALS['test_noop_wp_update_term_ids'] ?? [], true)) return ['term_id'=>$term_id];
    if (!isset($GLOBALS['test_terms'][$term_id])) return new WP_Error('invalid_term', 'missing');
    if (isset($args['slug'])) {
        $other = get_term_by('slug', $args['slug'], $taxonomy);
        if ($other && (int)$other->term_id !== $term_id) return new WP_Error('duplicate_slug', 'duplicate');
        $GLOBALS['test_terms'][$term_id]->slug = $args['slug'];
    }
    if (isset($args['name'])) $GLOBALS['test_terms'][$term_id]->name = $args['name'];
    if (isset($args['parent'])) $GLOBALS['test_terms'][$term_id]->parent = absint($args['parent']);
    return ['term_id'=>$term_id];
}
function wp_set_object_terms($post_id, $terms, $taxonomy, $append = false) { if (!empty($GLOBALS['test_fail_object_term_assignment'])) return new WP_Error('test_assignment_failure', 'forced assignment failure'); if (empty($GLOBALS['test_suppress_object_term_assignment'])) $GLOBALS['test_object_terms'][$post_id][$taxonomy] = $terms; return $terms; }
function wp_get_object_terms($post_id, $taxonomy, $args = []) { return $GLOBALS['test_object_terms'][$post_id][$taxonomy] ?? []; }
function is_admin() { return false; }
function is_404() { return true; }
function trailingslashit($v) { return rtrim((string)$v, '/') . '/'; }
function untrailingslashit($v) { return rtrim((string)$v, '/'); }
function get_term_link($term, $taxonomy = '') { return 'https://evazar.test/brand/' . $term->slug . '/'; }
function wp_safe_redirect($target, $status = 302, $x = '') { throw new TestRedirect($target, $status); }
function wp_unslash($v) { return $v; }
function current_user_can(...$args) { return true; }
function check_admin_referer(...$args) { return true; }
function wp_die(...$args) { throw new RuntimeException('wp_die'); }
function esc_html($v) { return (string)$v; }
function esc_attr($v) { return (string)$v; }
function esc_url($v) { return (string)$v; }
function admin_url($v = '') { return 'https://evazar.test/wp-admin/' . $v; }
function number_format_i18n($n) { return number_format((int)$n); }
function get_terms($args = []) {
    $terms = array_values(array_filter($GLOBALS['test_terms'], static function($term) use ($args) {
        if (isset($args['taxonomy']) && isset($term->taxonomy) && $term->taxonomy !== $args['taxonomy']) return false;
        if (isset($args['name']) && (string)$term->name !== (string)$args['name']) return false;
        if (isset($args['parent']) && (int)($term->parent ?? 0) !== (int)$args['parent']) return false;
        foreach ((array)($args['meta_query'] ?? []) as $mq) {
            if (!is_array($mq) || empty($mq['key'])) continue;
            $actual = get_term_meta((int)$term->term_id, (string)$mq['key'], true);
            $compare = strtoupper((string)($mq['compare'] ?? '='));
            if ($compare === '=' && (string)$actual !== (string)($mq['value'] ?? '')) return false;
        }
        return true;
    }));
    if (isset($args['number']) && (int)$args['number'] > 0) $terms = array_slice($terms, 0, (int)$args['number']);
    return $terms;
}

function wp_nonce_field(...$args) { return ''; }
function post_type_exists($v) { return false; }
function add_submenu_page(...$args) { $GLOBALS['test_submenu_pages'][] = $args; }
function current_time($format) { return '2026-10-24 00:00:00'; }
function get_posts($args = []) { return []; }
function get_post_meta($post_id, $key, $single = true) { return $GLOBALS['test_post_meta'][(int)$post_id][$key] ?? ''; }
function update_post_meta($post_id, $key, $value) { if (($GLOBALS['test_fail_post_meta_key'] ?? '') === (string)$key) return false; $GLOBALS['test_post_meta'][(int)$post_id][$key] = $value; return true; }
function delete_post_meta($post_id, $key) { unset($GLOBALS['test_post_meta'][(int)$post_id][$key]); return true; }
function wp_remote_head(...$args) { return new WP_Error('network', 'no network in local test'); }
function is_wp_error_wrapper($v) { return is_wp_error($v); }
function get_edit_post_link(...$args) { return '#'; }
function remove_query_arg(...$args) { return '#'; }
function add_query_arg(...$args) { return '#'; }
function wp_nonce_url(...$args) { return '#'; }
function wp_remote_retrieve_response_code(...$args) { return 0; }
function nocache_headers() {}

// Include actual production importer helpers and Core redirect/admin functions.
require_once dirname(__DIR__) . '/importer.php';
require_once dirname(__DIR__) . '/product-index.php';
require_once dirname(__DIR__) . '/queue-manager.php';
require_once dirname(__DIR__) . '/taxonomy-seo-queue.php';
require_once dirname(__DIR__) . '/cache-purge.php';
require_once dirname(__DIR__) . '/evazar-core.php';
require_once dirname(__DIR__) . '/brand-redirect-admin.php';

$passed = 0; $failed = 0;
function check($label, $condition) {
    global $passed, $failed;
    if ($condition) { $passed++; echo "PASS: $label\n"; }
    else { $failed++; echo "FAIL: $label\n"; }
}

check('accepts exact relative source path', evazar_normalize_digikala_brand_source_path('/brand/SoNy/') === '/brand/sony/');
check('accepts official absolute source URL', evazar_normalize_digikala_brand_source_path('https://www.digikala.com/brand/Sony/') === '/brand/sony/');
check('accepts encoded path segment', evazar_normalize_digikala_brand_source_path('/brand/sony%2Dmobile/') === '/brand/sony-mobile/');
check('accepts Persian brand source path', evazar_normalize_digikala_brand_source_path('/brand/چرم-آراهمراه/') === '/brand/چرم-آراهمراه/');
check('accepts percent-encoded Persian brand source URL', evazar_normalize_digikala_brand_source_path('https://www.digikala.com/brand/%DA%86%D8%B1%D9%85-%D8%A2%D8%B1%D8%A7%D9%87%D9%85%D8%B1%D8%A7%D9%87/') === '/brand/چرم-آراهمراه/');
check('normalizes brand-landing route to the same source identity', evazar_normalize_digikala_brand_source_path('/brand-landing/anker/') === '/brand/anker/');
check('normalizes brand-landing absolute URL to the same source identity', evazar_normalize_digikala_brand_source_path('https://www.digikala.com/brand-landing/anker/') === '/brand/anker/');
check('accepts j.one source slug with dot without changing source identity', evazar_normalize_digikala_brand_source_path('https://www.digikala.com/brand/j.one') === '/brand/j.one/');
check('accepts brand-landing j.one alias and normalizes route only', evazar_normalize_digikala_brand_source_path('/brand-landing/j.one/') === '/brand/j.one/');
check('source page normalization accepts dotted brand path', evazar_normalize_digikala_source_path('/brand/j.one/') === '/brand/j.one/');
check('source page normalization accepts Unicode brand path', evazar_normalize_digikala_source_path('/brand/چرم-آراهمراه/') === '/brand/چرم-آراهمراه/');
check('source page normalization accepts explicit Digikala slug ending in hyphen', evazar_normalize_digikala_source_path('/search/category-men-sport-shoes-/') === '/search/category-men-sport-shoes-/');
$reebok_worker_breadcrumbs = [
    ['title' => 'مد و پوشاک', 'url' => '/main/apparel/'],
    ['title' => 'مردانه', 'url' => '/search/category-mens-apparel/'],
    ['title' => 'کفش مردانه', 'url' => '/search/category-men-shoes/'],
    ['title' => 'کفش ورزشی مردانه', 'url' => '/search/category-men-sport-shoes-/'],
];
$reebok_validated_breadcrumbs = evazar_collect_validated_product_category_source_items($reebok_worker_breadcrumbs, 'کفش ورزشی مردانه');
$reebok_last_breadcrumb = is_array($reebok_validated_breadcrumbs) ? end($reebok_validated_breadcrumbs) : [];
check('real dkp-22055693 Worker breadcrumb set passes Core preflight with source URL retained', !is_wp_error($reebok_validated_breadcrumbs) && count($reebok_validated_breadcrumbs) === 4 && ($reebok_last_breadcrumb['uri'] ?? '') === '/search/category-men-sport-shoes-/');
check('rejects non-Digikala host', evazar_normalize_digikala_brand_source_path('https://example.com/brand/sony/') === '');
check('rejects product URL', evazar_normalize_digikala_brand_source_path('https://www.digikala.com/product/dkp-123/') === '');
check('rejects query string', evazar_normalize_digikala_brand_source_path('https://www.digikala.com/brand/sony/?a=1') === '');
check('rejects traversal', evazar_normalize_digikala_brand_source_path('/brand/../sony/') === '');
check('rejects encoded traversal', evazar_normalize_digikala_brand_source_path('/brand/%2e%2e/sony/') === '');
check('rejects URL credentials', evazar_normalize_digikala_brand_source_path('https://user@www.digikala.com/brand/sony/') === '');
check('rejects URL port', evazar_normalize_digikala_brand_source_path('https://www.digikala.com:443/brand/sony/') === '');
check('rejects host suffix spoofing', evazar_normalize_digikala_brand_source_path('https://www.digikala.com.evil.example/brand/sony/') === '');
check('extracts nested explicit URL from brand object', evazar_extract_digikala_brand_source_path(['id'=>2, 'url'=>['uri'=>'https://www.digikala.com/brand/sony/']]) === '/brand/sony/');
check('does not guess source slug from name fields', evazar_extract_digikala_brand_source_path(['title_fa'=>'سونی','title_en'=>'Sony','code'=>'SONY']) === '');

// Import-path guards: missing source URL or a failed brand assignment must propagate as an import error.
$importer_source = file_get_contents(dirname(__DIR__) . '/importer.php');
$queue_source = file_get_contents(dirname(__DIR__) . '/queue-manager.php');
check('product import rejects missing explicit brand source URL', strpos($importer_source, 'PRODUCT_BRAND_SOURCE_URL_MISSING') !== false && strpos($importer_source, 'URL معتبر و صریح برند از دیجی‌کالا دریافت نشد') !== false);
check('product import propagates failed brand sync as WP_Error before success logging', strpos($importer_source, 'PRODUCT_BRAND_SYNC_FAILED') !== false && strpos($importer_source, 'if (is_wp_error($brand_sync) || $brand_sync !== true)') !== false);
check('importer does not write raw source brand labels before verified taxonomy assignment', strpos($importer_source, "update_post_meta(\$post_id, '_evazar_brand', \$brand_val)") === false && strpos($importer_source, "update_post_meta(\$post_id, '_evazar_brand_en', \$brand_en_val)") === false);
check('queue repair does not overwrite term-canonical display metadata with raw source labels', strpos($queue_source, "update_post_meta(\$post_id, '_evazar_brand', \$brand_fa)") === false && strpos($queue_source, "update_post_meta(\$post_id, '_evazar_brand_en', \$brand_en)") === false);
check('ordinary queue errors are persisted as pending with retry/backoff', strpos($queue_source, "'status' => 'pending'") !== false && strpos($queue_source, "'error_code' => sanitize_text_field(\$err_code)") !== false);
$worker_source = file_get_contents(dirname(__DIR__) . '/worker/digikala-worker.js');
check('Worker exposes explicit brand ID/code/path from upstream brand object', strpos($worker_source, 'brand_source_path: brandSourcePath') !== false && strpos($worker_source, 'brand_source_id: Number(p.brand.id)') !== false && strpos($worker_source, 'brand_source_code: p.brand.code.trim()') !== false);
check('category import fails closed when explicit source URLs are absent', strpos($importer_source, 'PRODUCT_CATEGORY_SOURCE_PATH_MISSING') !== false && strpos($importer_source, 'CATEGORY_SOURCE_METADATA_WRITE_FAILED') !== false);

$GLOBALS['test_terms'][7] = (object)['term_id'=>7, 'name'=>'نمونه برند', 'slug'=>'sample-brand', 'taxonomy'=>'evazar_brand', 'count'=>1];
$GLOBALS['test_term_meta'][7]['_evazar_brand_en'] = 'Sample Brand';
$GLOBALS['test_term_meta'][7]['_evazar_dk_url'] = '/brand/canonical-source/';
$GLOBALS['test_term_meta'][7]['_evazar_dk_slug'] = 'canonical-source';
$GLOBALS['test_term_meta'][7]['_evazar_dk_source_verified'] = '1';
$GLOBALS['test_term_meta'][7]['_evazar_dk_source_map_version'] = '2.9.84.11';
$GLOBALS['test_term_meta'][7]['_evazar_dk_brand_id'] = '77';
$GLOBALS['test_term_meta'][7]['_evazar_dk_brand_code'] = 'sample-brand';
evazar_sync_product_brand(500, 'نمونه برند', 'Sample Brand', '');
check('legacy import does not overwrite verified canonical source path', get_term_meta(7, '_evazar_dk_url', true) === '/brand/canonical-source/');
check('legacy import does not clear source verification', get_term_meta(7, '_evazar_dk_source_verified', true) === '1');
evazar_sync_product_brand(501, 'نمونه برند', 'Sample Brand', 'https://www.digikala.com/brand/actual-source/', 77, 'sample-brand');
check('explicit source path updates source metadata', get_term_meta(7, '_evazar_dk_url', true) === '/brand/actual-source/');
check('explicit source path stores its own slug', get_term_meta(7, '_evazar_dk_slug', true) === 'actual-source');
check('explicit source path is marked verified', get_term_meta(7, '_evazar_dk_source_verified', true) === '1');
check('explicit source path becomes the public WordPress slug', get_term(7, 'evazar_brand')->slug === 'actual-source');
check('old public slug receives a 301 mapping during import', (int) ($GLOBALS['test_options']['evazar_brand_slug_redirects']['sample-brand'] ?? 0) === 7);
check('source brand ID and code are persisted', get_term_meta(7, '_evazar_dk_brand_id', true) === '77' && get_term_meta(7, '_evazar_dk_brand_code', true) === 'sample-brand');

// Representative Digikala API shape from product digi.txt: brand.id/code/url.uri.
$GLOBALS['test_terms'][11] = (object)['term_id'=>11, 'name'=>'سامسونگ قدیمی', 'slug'=>'old-samsung-name', 'taxonomy'=>'evazar_brand', 'count'=>4];
$GLOBALS['test_term_meta'][11]['_evazar_brand_en'] = 'Old Samsung Name';
$GLOBALS['test_term_meta'][11]['_evazar_dk_brand_id'] = '18';
$GLOBALS['test_term_meta'][11]['_evazar_dk_brand_code'] = 'samsung';
$GLOBALS['test_term_meta'][11]['_evazar_dk_source_verified'] = '0';
$brand_sync_result = evazar_sync_product_brand(503, 'سامسونگ', 'Samsung', '/brand/Samsung/', 18, 'samsung');
check('successful brand synchronization returns explicit success', $brand_sync_result === true);
check('Digikala source URL is lowercased as the canonical public slug', get_term(11, 'evazar_brand')->slug === 'samsung');
check('legacy Samsung-like slug redirects directly to canonical source slug', (int) ($GLOBALS['test_options']['evazar_brand_slug_redirects']['old-samsung-name'] ?? 0) === 11);
check('API source ID/code/path are saved on the canonical term', get_term_meta(11, '_evazar_dk_brand_id', true) === '18' && get_term_meta(11, '_evazar_dk_brand_code', true) === 'samsung' && get_term_meta(11, '_evazar_dk_url', true) === '/brand/samsung/');
check('product remains attached to the same migrated term', ($GLOBALS['test_object_terms'][503]['evazar_brand'] ?? []) === [11]);
check('import syncs legacy Persian display metadata from the exact assigned term name', ($GLOBALS['test_post_meta'][503]['_evazar_brand'] ?? '') === 'سامسونگ قدیمی');
check('import syncs the English display/search alias from the assigned term metadata', ($GLOBALS['test_post_meta'][503]['_evazar_brand_en'] ?? '') === 'Samsung');

// A manually-created homonymous legacy term without source identity must not be renamed to a
// different Digikala brand merely because its English label matches.
$GLOBALS['test_terms'][31] = (object)['term_id'=>31, 'name'=>'سالومون', 'slug'=>'salomon', 'taxonomy'=>'evazar_brand', 'count'=>9];
$GLOBALS['test_term_meta'][31]['_evazar_brand_en'] = 'Salomon';
$homonym_result = evazar_sync_product_brand(709, 'سالومون', 'Salomon', '/brand/salomon-pc/', 39641, 'salomon-pc');
$homonym_canonical = get_term_by('slug', 'salomon-pc', 'evazar_brand');
check('manual same-name brand without source identity is not hijacked by another source slug', $homonym_result === true && get_term(31, 'evazar_brand')->slug === 'salomon' && $homonym_canonical && (int)$homonym_canonical->term_id !== 31);
check('homonymous manual brand metadata is not overwritten by another Digikala identity', get_term_meta(31, '_evazar_dk_brand_id', true) === '' && get_term_meta(31, '_evazar_dk_url', true) === '');
check('homonymous product is attached to the canonical source-slug term only', $homonym_canonical && ($GLOBALS['test_object_terms'][709]['evazar_brand'] ?? []) === [(int)$homonym_canonical->term_id] && empty($GLOBALS['test_options']['evazar_brand_slug_redirects']['salomon']));

// Assignment errors and silent no-op writes must not be reported as successful brand sync.
$GLOBALS['test_post_meta'][700] = ['_evazar_brand' => 'برند قبلی', '_evazar_brand_en' => 'Previous Brand'];
$GLOBALS['test_fail_object_term_assignment'] = true;
$assignment_error = evazar_sync_product_brand(700, 'سامسونگ', 'Samsung', '/brand/samsung/', 18, 'samsung');
check('WordPress brand-assignment error is returned to caller', is_wp_error($assignment_error) && $assignment_error->get_error_code() === 'PRODUCT_BRAND_ASSIGNMENT_WRITE_FAILED');
check('failed brand assignment leaves the product display metadata unchanged', ($GLOBALS['test_post_meta'][700]['_evazar_brand'] ?? '') === 'برند قبلی' && ($GLOBALS['test_post_meta'][700]['_evazar_brand_en'] ?? '') === 'Previous Brand');
$GLOBALS['test_fail_object_term_assignment'] = false;
$GLOBALS['test_post_meta'][703] = ['_evazar_brand' => 'نام قدیمی', '_evazar_brand_en' => 'Old Alias'];
$GLOBALS['test_object_terms'][703]['evazar_brand'] = [7];
$GLOBALS['test_fail_post_meta_key'] = '_evazar_brand';
$display_meta_error = evazar_sync_product_brand(703, 'سامسونگ', 'Samsung', '/brand/samsung/', 18, 'samsung');
check('failed canonical display metadata read-back is returned as a brand sync error', is_wp_error($display_meta_error) && $display_meta_error->get_error_code() === 'PRODUCT_BRAND_DISPLAY_META_SYNC_FAILED');
check('failed display metadata sync restores the previous exact brand relationship', ($GLOBALS['test_object_terms'][703]['evazar_brand'] ?? []) === [7]);
check('failed display metadata sync restores the previous Persian and English labels', ($GLOBALS['test_post_meta'][703]['_evazar_brand'] ?? '') === 'نام قدیمی' && ($GLOBALS['test_post_meta'][703]['_evazar_brand_en'] ?? '') === 'Old Alias');
$GLOBALS['test_fail_post_meta_key'] = '';
$GLOBALS['test_fail_term_meta_key'] = '_evazar_brand_en';
$english_meta_error = evazar_sync_product_brand(704, 'برند با خطای نام انگلیسی', 'Brand EN Failure', '/brand/en-meta-fail-test/', 9994, 'en-meta-fail-test');
check('failed English brand alias persistence is returned as a sync error', is_wp_error($english_meta_error) && $english_meta_error->get_error_code() === 'PRODUCT_BRAND_ENGLISH_META_WRITE_FAILED');
$GLOBALS['test_fail_term_meta_key'] = '';
$GLOBALS['test_post_meta'][705] = ['_evazar_brand' => 'برند قبلی', '_evazar_brand_en' => 'Previous English Alias'];
$no_english_sync = evazar_sync_product_brand(705, 'برند بدون نام انگلیسی', '', '/brand/no-english-alias-test/', 9995, 'no-english-alias-test');
check('assigned term name becomes canonical product metadata when the term has no English alias', $no_english_sync === true && ($GLOBALS['test_post_meta'][705]['_evazar_brand'] ?? '') === 'برند بدون نام انگلیسی');
check('stale English alias is removed when assigned term has no canonical English value', !isset($GLOBALS['test_post_meta'][705]['_evazar_brand_en']));
$GLOBALS['test_suppress_object_term_assignment'] = true;
$verification_error = evazar_sync_product_brand(701, 'سامسونگ', 'Samsung', '/brand/samsung/', 18, 'samsung');
check('silent assignment no-op fails final brand verification', is_wp_error($verification_error) && $verification_error->get_error_code() === 'PRODUCT_BRAND_ASSIGNMENT_UNVERIFIED');
$GLOBALS['test_suppress_object_term_assignment'] = false;

// When a canonical source slug is already owned by a different known source ID,
// preserve the owner and create/reuse a separately suffixed public slug for the incoming identity.
$GLOBALS['test_terms'][12] = (object)['term_id'=>12, 'name'=>'برند قدیمی مستقل', 'slug'=>'legacy-independent-brand', 'taxonomy'=>'evazar_brand', 'count'=>1];
$GLOBALS['test_term_meta'][12]['_evazar_brand_en'] = 'Independent Brand';
$GLOBALS['test_term_meta'][12]['_evazar_dk_brand_id'] = '900';
$GLOBALS['test_terms'][13] = (object)['term_id'=>13, 'name'=>'برند متعارض', 'slug'=>'source-owned-slug', 'taxonomy'=>'evazar_brand', 'count'=>1];
$GLOBALS['test_term_meta'][13]['_evazar_brand_en'] = 'Different Brand';
$GLOBALS['test_term_meta'][13]['_evazar_dk_brand_id'] = '901';
$GLOBALS['test_term_meta'][13]['_evazar_dk_url'] = '/brand/source-owned-slug/';
$GLOBALS['test_term_meta'][13]['_evazar_dk_source_verified'] = '1';
$collision_sync = evazar_sync_product_brand(505, 'برند قدیمی مستقل', 'Independent Brand', '/brand/source-owned-slug/', 900, 'independent-brand');
check('known different source ID keeps existing canonical owner unchanged', get_term(13, 'evazar_brand')->slug === 'source-owned-slug' && get_term_meta(13, '_evazar_dk_brand_id', true) === '901');
check('confirmed distinct brand is routed to a free numeric suffix', $collision_sync === true && get_term(12, 'evazar_brand')->slug === 'source-owned-slug-1');
check('product attaches to the independent suffixed brand only', ($GLOBALS['test_object_terms'][505]['evazar_brand'] ?? []) === [12]);
check('collision override is persisted separately from the source URL slug', get_term_meta(12, '_evazar_dk_slug', true) === 'source-owned-slug' && get_term_meta(12, '_evazar_dk_public_slug_override', true) === '1');
check('the occupied canonical slug does not get a redirect to the other identity', empty($GLOBALS['test_options']['evazar_brand_slug_redirects']['source-owned-slug']));

// A source-slug owner with no verified ID/URL remains UNKNOWN: do not guess same or different.
$GLOBALS['test_terms'][40] = (object)['term_id'=>40, 'name'=>'ال جی', 'slug'=>'lg', 'taxonomy'=>'evazar_brand', 'count'=>1];
$unknown_collision = evazar_sync_product_brand(5060, 'ال جی', 'LG', '/brand/lg/', 996, 'lg-second');
check('unknown manual canonical owner blocks automatic suffix creation', is_wp_error($unknown_collision) && $unknown_collision->get_error_code() === 'PRODUCT_BRAND_SOURCE_IDENTITY_UNKNOWN');
check('unknown manual owner is not renamed or assigned guessed metadata', get_term(40, 'evazar_brand')->slug === 'lg' && get_term_meta(40, '_evazar_dk_brand_id', true) === '' && empty($GLOBALS['test_object_terms'][5060]['evazar_brand']));
unset($GLOBALS['test_terms'][40]); // Real WordPress cannot contain duplicate slugs; remove this scenario before the next isolated case.

// If lg-1 is already occupied by another local term, next proven distinct identity receives lg-2.
$GLOBALS['test_terms'][41] = (object)['term_id'=>41, 'name'=>'ال جی', 'slug'=>'lg', 'taxonomy'=>'evazar_brand', 'count'=>1];
$GLOBALS['test_term_meta'][41]['_evazar_dk_brand_id'] = '18';
$GLOBALS['test_term_meta'][41]['_evazar_dk_brand_code'] = 'lg';
$GLOBALS['test_term_meta'][41]['_evazar_dk_url'] = '/brand/lg/';
$GLOBALS['test_term_meta'][41]['_evazar_dk_source_verified'] = '1';
$GLOBALS['test_terms'][42] = (object)['term_id'=>42, 'name'=>'برند مستقل دیگر', 'slug'=>'lg-1', 'taxonomy'=>'evazar_brand', 'count'=>1];
$second_collision = evazar_sync_product_brand(5061, 'ال جی', 'LG', '/brand/lg/', 997, 'lg-third');
$lg2 = get_term_by('slug', 'lg-2', 'evazar_brand');
check('a verified different source ID gets the next numeric slug when lg and lg-1 are occupied', $second_collision === true && $lg2 && get_term_meta($lg2->term_id, '_evazar_dk_brand_id', true) === '997');
check('separate LG import does not change existing lg or lg-1 terms', get_term(41, 'evazar_brand')->slug === 'lg' && get_term(42, 'evazar_brand')->slug === 'lg-1');
$before_lg_terms = count($GLOBALS['test_terms']);
$repeat_collision = evazar_sync_product_brand(5062, 'ال جی', 'LG', '/brand/lg/', 997, 'lg-third');
check('repeat import resolves the same source ID to its existing suffixed term', $repeat_collision === true && count($GLOBALS['test_terms']) === $before_lg_terms && ($GLOBALS['test_object_terms'][5062]['evazar_brand'] ?? []) === [(int)$lg2->term_id]);

// Pending source-ID marker makes a partial metadata failure retry-safe without duplicate suffixes.
$GLOBALS['test_terms'][50] = (object)['term_id'=>50, 'name'=>'برند پایه آزمون بازیابی', 'slug'=>'retry-lg', 'taxonomy'=>'evazar_brand', 'count'=>1];
$GLOBALS['test_term_meta'][50]['_evazar_dk_brand_id'] = '180';
$GLOBALS['test_term_meta'][50]['_evazar_dk_brand_url'] = '/brand/retry-lg/';
$GLOBALS['test_term_meta'][50]['_evazar_dk_source_verified'] = '1';
$GLOBALS['test_fail_term_meta_key'] = '_evazar_dk_brand_id';
$partial_import = evazar_sync_product_brand(5063, 'برند پایه آزمون بازیابی', 'Retry LG', '/brand/retry-lg/', 998, 'retry-lg-new');
$GLOBALS['test_fail_term_meta_key'] = '';
$retry_term = get_term_by('slug', 'retry-lg-1', 'evazar_brand');
check('partial source-meta failure leaves a pending source-ID recovery marker', is_wp_error($partial_import) && $retry_term && get_term_meta($retry_term->term_id, '_evazar_dk_brand_source_id_pending', true) === '998' && get_term_meta($retry_term->term_id, '_evazar_dk_source_verified', true) === '0');
$retry_count = count($GLOBALS['test_terms']);
$retried_import = evazar_sync_product_brand(5064, 'برند پایه آزمون بازیابی', 'Retry LG', '/brand/retry-lg/', 998, 'retry-lg-new');
check('retry resolves the pending source ID instead of creating another numeric suffix', $retried_import === true && count($GLOBALS['test_terms']) === $retry_count && get_term_meta($retry_term->term_id, '_evazar_dk_brand_id', true) === '998' && get_term_meta($retry_term->term_id, '_evazar_dk_brand_source_id_pending', true) === '');

// A legacy title-derived URL must not be used as a source for brand SEO.
$GLOBALS['test_terms'][9] = (object)['term_id'=>9, 'name'=>'برند حدسی', 'slug'=>'guessed-brand', 'taxonomy'=>'evazar_brand', 'count'=>0];
$GLOBALS['test_term_meta'][9]['_evazar_brand_en'] = 'Guessed Brand';
$GLOBALS['test_term_meta'][9]['_evazar_dk_url'] = '/brand/guessed-brand/';
$GLOBALS['test_term_meta'][9]['_evazar_dk_slug'] = 'guessed-brand';
$GLOBALS['test_term_meta'][9]['_evazar_dk_source_verified'] = '0';
$GLOBALS['test_term_meta'][9]['_evazar_dk_source_map_version'] = '2.9.19';
check('resolver refuses legacy title-derived brand URL', evazar_resolve_term_source_path(9, 'evazar_brand', 'brand', 'Guessed Brand') === '');
$GLOBALS['test_term_meta'][10] = [];
$GLOBALS['test_terms'][10] = (object)['term_id'=>10, 'name'=>'برند جدید بدون مسیر', 'slug'=>'new-brand-without-path', 'taxonomy'=>'evazar_brand', 'count'=>0];
evazar_sync_product_brand(502, 'برند جدید بدون مسیر', 'New Brand Without Path', '');
check('import without explicit source does not fabricate source URL', get_term_meta(10, '_evazar_dk_url', true) === '');
check('import without explicit source marks source unverified', get_term_meta(10, '_evazar_dk_source_verified', true) === '0');
check('missing source path does not fabricate a candidate Digikala slug', get_term_meta(10, '_evazar_dk_slug', true) === '');
evazar_sync_product_brand(504, 'برند تازه بدون URL', 'Unverified Brand Without URL', '', 9901, 'unverified-code');
check('new brand without source URL does not create a guessed public term', get_term_by('slug', 'unverified-brand-without-url', 'evazar_brand') === false);
check('new brand without source URL is not attached to product', empty($GLOBALS['test_object_terms'][504]['evazar_brand']));
$GLOBALS['test_terms'][14] = (object)['term_id'=>14, 'name'=>'برند بدون مبدأ', 'slug'=>'brand-without-source', 'taxonomy'=>'evazar_brand', 'count'=>1];
$GLOBALS['test_term_meta'][14]['_evazar_brand_en'] = 'Brand Without Source';
evazar_sync_product_brand(506, 'برند بدون مبدأ', 'Brand Without Source', '', 9902, 'brand-without-source');
check('source ID without explicit URL cannot claim a title-matched legacy term without matching stored identity', empty($GLOBALS['test_object_terms'][506]['evazar_brand']));
check('unverified title match does not get a speculative source ID written', get_term_meta(14, '_evazar_dk_brand_id', true) === '');
$GLOBALS['test_term_meta'][9]['_evazar_dk_source_verified'] = '1';
check('resolver accepts explicitly recorded brand source path', evazar_resolve_term_source_path(9, 'evazar_brand', 'brand', 'Guessed Brand') === '/brand/guessed-brand/');

// Redirect map must be durable before a canonical slug change is allowed.
$GLOBALS['test_terms'][21] = (object)['term_id'=>21, 'name'=>'ثبت ناموفق ریدایرکت', 'slug'=>'redirect-save-failure', 'taxonomy'=>'evazar_brand', 'count'=>1];
$GLOBALS['test_fail_update_option_key'] = 'evazar_brand_slug_redirects';
check('failed redirect-map persistence prevents public slug mutation', evazar_brand_move_term_to_source_slug(21, 'redirect-save-failure-new') === false && get_term(21, 'evazar_brand')->slug === 'redirect-save-failure');
check('failed redirect-map persistence leaves no unverified redirect entry', empty($GLOBALS['test_options']['evazar_brand_slug_redirects']['redirect-save-failure']));
$GLOBALS['test_fail_update_option_key'] = '';

// If the term update fails after the pre-write, roll the redirect map back.
$GLOBALS['test_terms'][22] = (object)['term_id'=>22, 'name'=>'تغییر نامک ناموفق', 'slug'=>'term-update-failure', 'taxonomy'=>'evazar_brand', 'count'=>1];
$GLOBALS['test_fail_wp_update_term_ids'] = [22];
check('failed term update does not report a successful slug migration', evazar_brand_move_term_to_source_slug(22, 'term-update-failure-new') === false && get_term(22, 'evazar_brand')->slug === 'term-update-failure');
check('failed term update rolls back the prewritten redirect mapping', empty($GLOBALS['test_options']['evazar_brand_slug_redirects']['term-update-failure']));
$GLOBALS['test_fail_wp_update_term_ids'] = [];
$GLOBALS['test_noop_wp_update_term_ids'] = [];

// Verify that a nominally successful term update really persisted the requested slug.
$GLOBALS['test_terms'][23] = (object)['term_id'=>23, 'name'=>'عدم ثبت نامک', 'slug'=>'term-update-noop', 'taxonomy'=>'evazar_brand', 'count'=>1];
$GLOBALS['test_noop_wp_update_term_ids'] = [23];
check('slug migration fails closed when WordPress reports success but slug does not change', evazar_brand_move_term_to_source_slug(23, 'term-update-noop-new') === false && get_term(23, 'evazar_brand')->slug === 'term-update-noop');
check('unapplied slug change removes the prewritten redirect mapping', empty($GLOBALS['test_options']['evazar_brand_slug_redirects']['term-update-noop']));
$GLOBALS['test_noop_wp_update_term_ids'] = [];

// Old slug A -> term 7 (current slug sample-brand); the redirect must resolve directly to the current URL.
$GLOBALS['test_options']['evazar_brand_slug_redirects'] = ['old-sample-brand' => 7];
$_SERVER['REQUEST_URI'] = '/brand/old-sample-brand/page/2/?source=test';
try { evazar_handle_brand_slug_redirect(); check('redirect handler invokes permanent redirect', false); }
catch (TestRedirect $r) {
    check('redirect uses HTTP 301', $r->status === 301);
    check('redirect goes directly to current term and preserves pagination/query', $r->target === 'https://evazar.test/brand/actual-source/page/2/?source=test');
}
// A stale mapping must not take over a slug now occupied by another term.
$GLOBALS['test_terms'][8] = (object)['term_id'=>8, 'name'=>'دوم', 'slug'=>'claimed-slug', 'taxonomy'=>'evazar_brand', 'count'=>0];
$GLOBALS['test_options']['evazar_brand_slug_redirects']['claimed-slug'] = 7;
$_SERVER['REQUEST_URI'] = '/brand/claimed-slug/';
try { evazar_handle_brand_slug_redirect(); check('occupied slug does not redirect', true); }
catch (TestRedirect $r) { check('occupied slug does not redirect', false); }

// The old manual Brand Tools page is intentionally removed; import-time brand sync and 301s remain.
$GLOBALS['test_submenu_pages'] = [];
evazar_core_add_admin_menu();
evazar_brand_redirect_admin_register_menu();
$registered_menu_slugs = array_values(array_map(static function ($args) { return (string) ($args[4] ?? ''); }, $GLOBALS['test_submenu_pages']));
check('manual Brand Tools admin page is not registered', !in_array('evazar-brand-tools', $registered_menu_slugs, true));
check('manual Brand Tools handler is fully removed', !function_exists('evazar_brand_tools_page'));
check('affiliate settings menu remains registered', in_array('evazar-affiliate-settings', $registered_menu_slugs, true));
check('Gemini operations menu remains registered', in_array('evazar-gemini-ops', $registered_menu_slugs, true));
check('brand redirect management menu is registered', in_array('evazar-brand-redirects', $registered_menu_slugs, true));

// Brand redirect admin cleanup must validate the page snapshot and remove only selected map keys.
$selection_check = evazar_brand_redirect_admin_validate_selection([
    'old-salomon' => '91',
    'old-valid' => '7',
    'not-in-map' => '7',
    'old-wrong-target' => '999',
    'malformed' => ['array-value'],
], ['old-salomon' => 90, 'old-valid' => 7, 'old-wrong-target' => 8]);
check('redirect cleanup accepts only selected keys whose current target IDs still match', $selection_check['valid'] === ['old-valid' => 7] && $selection_check['skipped'] === 4);
$redirect_map_before_cleanup = [
    'old-valid' => 7,
    'old-valid-duplicate' => 7,
    'unrelated-history' => 45,
    'salomon-pc' => 302,
];
$redirect_map_after_cleanup = evazar_brand_redirect_admin_remove_selected_entries($redirect_map_before_cleanup, ['old-valid' => 7]);
check('redirect cleanup deletes only explicitly selected old-slug mappings', !isset($redirect_map_after_cleanup['old-valid']) && isset($redirect_map_after_cleanup['old-valid-duplicate'], $redirect_map_after_cleanup['unrelated-history'], $redirect_map_after_cleanup['salomon-pc']));
check('empty redirect cleanup selection leaves the full map intact', evazar_brand_redirect_admin_remove_selected_entries($redirect_map_before_cleanup, []) === $redirect_map_before_cleanup);
$salomon_before_cleanup = ['salomon' => 222, 'salomon-pc' => 333, 'another-history' => 44];
$salomon_after_cleanup = evazar_brand_redirect_admin_remove_selected_entries($salomon_before_cleanup, ['salomon' => 222]);
check('removing salomon redirect leaves salomon-pc and unrelated redirects intact', !isset($salomon_after_cleanup['salomon']) && ($salomon_after_cleanup['salomon-pc'] ?? 0) === 333 && ($salomon_after_cleanup['another-history'] ?? 0) === 44);
$redirect_admin_source = file_get_contents(dirname(__DIR__) . '/brand-redirect-admin.php');
check('brand redirect admin contains no cache-purge or product/term mutation calls', !preg_match('/(?:evazar_lscache_purge|wp_update_term\s*\(|wp_set_object_terms\s*\(|update_term_meta\s*\(|delete_term\s*\()/i', $redirect_admin_source));

// Batch-50 release regressions: exercise the real Core partitioner and migration.
check('product batch sanitizer permits 50', evazar_sanitize_ai_product_batch_size(50) === 50);
check('product batch sanitizer caps larger values at 50', evazar_sanitize_ai_product_batch_size(99) === 50);
evazar_migrate_product_batch_size_30();
check('batch-30 one-time migration selects 30', get_option('evazar_ai_product_batch_size') === 30);
foreach ([50 => [50], 51 => [49, 2], 100 => [50, 50], 125 => [50, 50, 25]] as $input_count => $expected_sizes) {
    $entries = [];
    for ($id = 1; $id <= $input_count; $id++) $entries[] = ['id' => $id, 'item' => (object) ['id' => $id]];
    $partition = evazar_queue_partition_product_batches($entries, 50);
    $chunks = (array) ($partition['chunks'] ?? []);
    $sizes = array_map('count', $chunks);
    $flattened_ids = [];
    foreach ($chunks as $chunk) foreach ($chunk as $entry) $flattened_ids[] = (int) ($entry['id'] ?? 0);
    foreach ((array) ($partition['unpaired'] ?? []) as $entry) $flattened_ids[] = (int) ($entry['id'] ?? 0);
    sort($flattened_ids);
    $expected_ids = range(1, $input_count);
    check('partition ' . $input_count . ' items keeps expected chunks and no loss/duplication', $sizes === $expected_sizes && $flattened_ids === $expected_ids);
}

// Exhaustively exercise every queue length 2–250 against each supported batch size 2–50.
$partition_exhaustive_ok = true;
for ($max_size = 2; $max_size <= 50 && $partition_exhaustive_ok; $max_size++) {
    for ($input_count = 2; $input_count <= 250; $input_count++) {
        $entries = [];
        for ($id = 1; $id <= $input_count; $id++) $entries[] = ['id' => $id, 'item' => (object) ['id' => $id]];
        $partition = evazar_queue_partition_product_batches($entries, $max_size);
        $chunks = (array) ($partition['chunks'] ?? []);
        $unpaired = (array) ($partition['unpaired'] ?? []);
        $flattened_ids = [];
        foreach ($chunks as $chunk) {
            $chunk_count = count($chunk);
            if ($chunk_count < 2 || $chunk_count > $max_size) { $partition_exhaustive_ok = false; break; }
            foreach ($chunk as $entry) $flattened_ids[] = (int) ($entry['id'] ?? 0);
        }
        foreach ($unpaired as $entry) $flattened_ids[] = (int) ($entry['id'] ?? 0);
        sort($flattened_ids);
        if ($flattened_ids !== range(1, $input_count)) { $partition_exhaustive_ok = false; break; }
    }
}
check('exhaustive queue partition lengths 2–250 and batch sizes 2–50 preserve every item without invalid chunks', $partition_exhaustive_ok);

// Dynamic per-run ceiling: one batch per eligible Gemini Worker, up to five Workers / 150 products.
$GLOBALS['test_options']['evazar_ai_enabled'] = 'yes';
$GLOBALS['test_options']['evazar_ai_engine_mode'] = 'gemini_only';
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 150;
$GLOBALS['test_options']['evazar_queue_capacity_150_migrated'] = '';
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 75;
evazar_migrate_queue_capacity_150();
check('150-cap migration raises the previous legacy ceiling of 75', get_option('evazar_queue_max_products_per_run') === 150);
check('150-cap migration updates the legacy compatibility option', get_option('evazar_queue_batch_size') === 150);
$GLOBALS['test_options']['evazar_queue_capacity_150_migrated'] = '';
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 40;
evazar_migrate_queue_capacity_150();
check('150-cap migration preserves an intentional custom cap below 75', get_option('evazar_queue_max_products_per_run') === 40);

// Correct the stale saved outer cap of 15 without overwriting other intentional limits.
$GLOBALS['test_options']['evazar_queue_dynamic_ceiling_150_migrated'] = '';
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 15;
$GLOBALS['test_options']['evazar_queue_batch_size'] = 15;
evazar_migrate_legacy_queue_ceiling_15();
check('legacy queue ceiling 15 migrates to 150 so Worker-scaled capacity is not capped at 15', get_option('evazar_queue_max_products_per_run') === 150);
check('legacy queue compatibility option is synchronized to 150', get_option('evazar_queue_batch_size') === 150);
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 40;
evazar_migrate_legacy_queue_ceiling_15();
check('one-time migration does not overwrite a later custom manual ceiling', get_option('evazar_queue_max_products_per_run') === 40);
$GLOBALS['test_options']['evazar_queue_dynamic_ceiling_150_migrated'] = '';
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 40;
evazar_migrate_legacy_queue_ceiling_15();
check('first-time migration preserves a custom cap other than the legacy value 15', get_option('evazar_queue_max_products_per_run') === 40);

// Batch-50 and 250-cap upgrade migrations must promote the old defaults while preserving lower custom settings.
$GLOBALS['test_options']['evazar_product_batch_size_50_migrated'] = '';
$GLOBALS['test_options']['evazar_ai_product_batch_size'] = 30;
evazar_migrate_product_batch_size_50();
check('batch-size migration promotes old default 30 to 50', get_option('evazar_ai_product_batch_size') === 50);
$GLOBALS['test_options']['evazar_product_batch_size_50_migrated'] = '';
$GLOBALS['test_options']['evazar_ai_product_batch_size'] = 20;
evazar_migrate_product_batch_size_50();
check('batch-size migration preserves intentional lower custom value', get_option('evazar_ai_product_batch_size') === 20);
$GLOBALS['test_options']['evazar_queue_capacity_250_migrated'] = '';
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 150;
evazar_migrate_queue_capacity_250();
check('250-cap migration promotes prior default 150 to 250', get_option('evazar_queue_max_products_per_run') === 250);
$GLOBALS['test_options']['evazar_queue_capacity_250_migrated'] = '';
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 80;
evazar_migrate_queue_capacity_250();
check('250-cap migration preserves intentional lower manual cap', get_option('evazar_queue_max_products_per_run') === 80);

$make_workers = static function($n) {
    $urls = [];
    for ($i = 1; $i <= $n; $i++) $urls[] = 'https://gemini-worker-' . $i . '.example.workers.dev';
    return implode("\n", $urls);
};
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 150;
$GLOBALS['test_options']['evazar_ai_product_batch_size'] = 20;
$GLOBALS['test_options']['evazar_gemini_worker_urls'] = $make_workers(2);
check('dynamic ceiling: 2 configured Workers × 20 products = 40', evazar_queue_effective_run_limit(150) === 40);
check('dynamic claim capacity: 2 eligible Workers × 20 products = 40', evazar_queue_adaptive_claim_capacity(150, 2, 20, true, 5) === 40);
$actual_two_worker_capacity = evazar_queue_current_processing_capacity();
$expected_two_worker_capacity = (evazar_queue_product_batch_parallel_enabled() && evazar_queue_parallel_transport_available()) ? 40 : 20;
check('live queue capacity matches 2×20 with only the documented transport guard', $actual_two_worker_capacity === $expected_two_worker_capacity);
$GLOBALS['test_options']['evazar_ai_product_batch_size'] = 30;
$GLOBALS['test_options']['evazar_gemini_worker_urls'] = $make_workers(4);
check('dynamic ceiling: 4 configured Workers × 30 products = 120', evazar_queue_effective_run_limit(150) === 120);
check('dynamic claim capacity: 4 eligible Workers × 30 products = 120', evazar_queue_adaptive_claim_capacity(150, 4, 30, true, 5) === 120);
$actual_four_worker_capacity = evazar_queue_current_processing_capacity();
$expected_four_worker_capacity = (evazar_queue_product_batch_parallel_enabled() && evazar_queue_parallel_transport_available()) ? 120 : 30;
check('live queue capacity matches 4×30 with only the documented transport guard', $actual_four_worker_capacity === $expected_four_worker_capacity);
// Exact current configuration reported by the site: 4 Workers × 40 products, with queue cap 250.
$GLOBALS['test_options']['evazar_ai_product_batch_size'] = 40;
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 250;
check('four Worker × 40-product plan calculates 160 queue slots', evazar_queue_effective_run_limit(250) === 160);
check('four eligible Workers × 40 products claim exactly 160 items', evazar_queue_adaptive_claim_capacity(250, 4, 40, true, 5) === 160);
$actual_four_by_forty_capacity = evazar_queue_current_processing_capacity();
$expected_four_by_forty_capacity = (evazar_queue_product_batch_parallel_enabled() && evazar_queue_parallel_transport_available()) ? 160 : 40;
check('live queue capacity for 4×40 is 160 with parallel transport, otherwise safely one 40-item batch', $actual_four_by_forty_capacity === $expected_four_by_forty_capacity);
check('three eligible Workers reduce a four-Worker 40-product plan to 120', evazar_queue_adaptive_claim_capacity(250, 3, 40, true, 5) === 120);
// Restore the older test setup so subsequent assertions remain independent.
$GLOBALS['test_options']['evazar_ai_product_batch_size'] = 30;
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 150;
check('three eligible Workers reduce a four-Worker 30-product plan to 90', evazar_queue_adaptive_claim_capacity(120, 3, 30, true, 5) === 90);
$blocked_worker = 'https://gemini-worker-4.example.workers.dev';
$GLOBALS['test_transients'][evazar_gemini_quota_worker_key($blocked_worker)] = time() + 3600;
$actual_three_eligible_capacity = evazar_queue_current_processing_capacity();
$expected_three_eligible_capacity = (evazar_queue_product_batch_parallel_enabled() && evazar_queue_parallel_transport_available()) ? 90 : 30;
check('a Worker in daily-quota cooldown is excluded from live capacity', $actual_three_eligible_capacity === $expected_three_eligible_capacity);
unset($GLOBALS['test_transients'][evazar_gemini_quota_worker_key($blocked_worker)]);
check('parallelism configured to two limits four eligible Workers to 60', evazar_queue_adaptive_claim_capacity(150, 4, 30, true, 2) === 60);
$GLOBALS['test_options']['evazar_gemini_worker_urls'] = $make_workers(5);
check('five Workers × 30 products reaches but never exceeds technical maximum 150', evazar_queue_effective_run_limit(150) === 150 && evazar_queue_adaptive_claim_capacity(150, 5, 30, true, 5) === 150);
$GLOBALS['test_options']['evazar_gemini_worker_urls'] = $make_workers(4);
$GLOBALS['test_options']['evazar_ai_product_batch_size'] = 30;
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 80;
check('manual queue safety cap can lower four-Worker dynamic capacity', evazar_queue_effective_run_limit(80) === 80);
$GLOBALS['test_options']['evazar_ai_product_batch_size'] = 50;
$GLOBALS['test_options']['evazar_gemini_worker_urls'] = $make_workers(5);
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 250;
check('five Workers × 50 products reaches new 250-product technical ceiling', evazar_queue_effective_run_limit(250) === 250 && evazar_queue_adaptive_claim_capacity(250, 5, 50, true, 5) === 250);
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 150;
check('manual legacy queue cap of 150 still safely limits five 50-product Workers', evazar_queue_effective_run_limit(150) === 150);
$GLOBALS['test_options']['evazar_queue_max_products_per_run'] = 250;

// Category source-metadata integrity: these tests exercise the production category sync/helpers.
$GLOBALS['test_terms'][201] = (object)['term_id'=>201, 'name'=>'ورزشی', 'slug'=>'sports', 'taxonomy'=>'evazar_category', 'parent'=>0, 'count'=>1];
$GLOBALS['test_term_meta'][201]['_evazar_dk_url'] = '/search/sport/';
$GLOBALS['test_term_meta'][201]['_evazar_dk_slug'] = 'sport';
$GLOBALS['test_term_meta'][201]['_evazar_dk_source_kind'] = 'digikala_breadcrumb';
$GLOBALS['test_term_meta'][201]['_evazar_dk_source_verified'] = '1';
$GLOBALS['test_term_meta'][201]['_evazar_dk_source_map_version'] = '2.9.84.27';
$GLOBALS['test_terms'][202] = (object)['term_id'=>202, 'name'=>'ورزشی', 'slug'=>'fitness', 'taxonomy'=>'evazar_category', 'parent'=>0, 'count'=>1];
$GLOBALS['test_term_meta'][202]['_evazar_dk_url'] = '/search/fitness/';
$GLOBALS['test_term_meta'][202]['_evazar_dk_slug'] = 'fitness';
$GLOBALS['test_term_meta'][202]['_evazar_dk_source_kind'] = 'digikala_breadcrumb';
$GLOBALS['test_term_meta'][202]['_evazar_dk_source_verified'] = '1';
$GLOBALS['test_term_meta'][202]['_evazar_dk_source_map_version'] = '2.9.84.27';
$cat_sync = evazar_sync_product_categories(9001, [['title'=>'ورزشی','url'=>['uri'=>'/search/sport/']]], 'ورزشی', '', '');
check('category import resolves by exact source path despite same-name category on another path', $cat_sync === 1 && ($GLOBALS['test_object_terms'][9001]['evazar_category'] ?? []) === [201]);
check('category breadcrumb source URL is persisted and verified with marker written last', get_term_meta(201, '_evazar_dk_url', true) === '/search/sport/' && get_term_meta(201, '_evazar_dk_source_kind', true) === 'digikala_breadcrumb' && get_term_meta(201, '_evazar_dk_source_verified', true) === '1' && get_term_meta(201, '_evazar_dk_source_map_version', true) === '2.9.84.29');
$reebok_full_sync = evazar_sync_product_categories(22055693, $reebok_worker_breadcrumbs, 'کفش ورزشی مردانه', '', '');
$reebok_assigned_ids = $GLOBALS['test_object_terms'][22055693]['evazar_category'] ?? [];
$reebok_final_id = !empty($reebok_assigned_ids) ? (int) end($reebok_assigned_ids) : 0;
$reebok_final_term = $reebok_final_id ? get_term($reebok_final_id, 'evazar_category') : false;
check('full category sync assigns all four exact Worker breadcrumbs for dkp-22055693', $reebok_full_sync === 4 && count($reebok_assigned_ids) === 4);
check('full category sync persists and verifies exact trailing-hyphen source URL', $reebok_final_term && get_term_meta($reebok_final_id, '_evazar_dk_url', true) === '/search/category-men-sport-shoes-/' && get_term_meta($reebok_final_id, '_evazar_dk_source_verified', true) === '1');
check('full category sync preserves breadcrumb parent hierarchy', $reebok_final_term && (int) $reebok_final_term->parent === (int) $reebok_assigned_ids[2]);

$category_name_fallback = evazar_category_find_term_by_name_parent('ورزشی', 0, '/search/yoga/', false, 'evazar_category');
check('same-name category with a conflicting verified source path is never selected by name fallback', empty($category_name_fallback['term']) && !empty($category_name_fallback['conflict']));
$preserve_verified_path = evazar_persist_category_source_metadata(201, '/search/yoga/', 'digikala_breadcrumb');
check('verified category path conflict blocks overwrite', is_wp_error($preserve_verified_path) && get_term_meta(201, '_evazar_dk_url', true) === '/search/sport/');

// Existing synthetic category+brand child should store its generated route separately, not as source identity.
$GLOBALS['test_terms'][204] = (object)['term_id'=>204, 'name'=>'ورزشی سالومون', 'slug'=>'sports-salomon', 'taxonomy'=>'evazar_category', 'parent'=>201, 'count'=>0];
$GLOBALS['test_term_meta'][204]['_evazar_dk_generated_url'] = '/search/sport/salomon/';
$GLOBALS['test_term_meta'][204]['_evazar_dk_source_kind'] = 'derived_brand_landing';
$GLOBALS['test_term_meta'][204]['_evazar_dk_source_map_version'] = '2.9.84.27-derived';
$GLOBALS['test_term_meta'][204]['_evazar_dk_url'] = '/search/sport/salomon/'; // Simulate a legacy polluted field.
$GLOBALS['test_term_meta'][204]['_evazar_dk_slug'] = 'salomon';
$GLOBALS['test_term_meta'][204]['_evazar_dk_source_verified'] = '1'; // Simulate the old incorrect trust marker.
$generated_sync = evazar_sync_product_categories(9003, [['title'=>'ورزشی','url'=>['uri'=>'/search/sport/']]], 'ورزشی', 'سالومون', 'Salomon');
check('generated category+brand URL is kept separate from verified category identity', is_numeric($generated_sync) && get_term_meta(204, '_evazar_dk_generated_url', true) === '/search/sport/salomon/' && get_term_meta(204, '_evazar_dk_url', true) === '' && get_term_meta(204, '_evazar_dk_slug', true) === '' && get_term_meta(204, '_evazar_dk_source_verified', true) === '0' && get_term_meta(204, '_evazar_dk_source_kind', true) === 'derived_brand_landing');

$GLOBALS['test_terms'][203] = (object)['term_id'=>203, 'name'=>'لوازم جانبی', 'slug'=>'accessories', 'taxonomy'=>'evazar_category', 'parent'=>0, 'count'=>1];
$GLOBALS['test_term_meta'][203]['_evazar_dk_url'] = '/search/accessories/';
$GLOBALS['test_term_meta'][203]['_evazar_dk_slug'] = 'accessories';
$GLOBALS['test_term_meta'][203]['_evazar_dk_source_kind'] = 'digikala_breadcrumb';
$GLOBALS['test_term_meta'][203]['_evazar_dk_source_verified'] = '1';
$GLOBALS['test_fail_object_term_assignment'] = true;
$cat_sync_failed = evazar_sync_product_categories(9004, [['title'=>'لوازم جانبی','url'=>['uri'=>'/search/accessories/']]], 'لوازم جانبی', '', '');
$GLOBALS['test_fail_object_term_assignment'] = false;
check('category relationship write failure is returned to importer as WP_Error', is_wp_error($cat_sync_failed) && $cat_sync_failed->get_error_code() === 'PRODUCT_CATEGORY_ASSIGNMENT_WRITE_FAILED');


$before_category_count = count(array_filter($GLOBALS['test_terms'], static function($t) { return ($t->taxonomy ?? '') === 'evazar_category'; }));
$missing_category_path = evazar_sync_product_categories(9005, [['title'=>'دسته بدون URL','url'=>'']], 'دسته بدون URL', '', '');
$after_category_count = count(array_filter($GLOBALS['test_terms'], static function($t) { return ($t->taxonomy ?? '') === 'evazar_category'; }));
check('category import rejects title-only breadcrumbs without creating an unverified term', is_wp_error($missing_category_path) && $missing_category_path->get_error_code() === 'PRODUCT_CATEGORY_SOURCE_PATH_MISSING' && $before_category_count === $after_category_count);

$GLOBALS['test_terms'][205] = (object)['term_id'=>205, 'name'=>'مسیر تازه', 'slug'=>'new-path', 'taxonomy'=>'evazar_category', 'parent'=>0, 'count'=>0];
$GLOBALS['test_fail_term_meta_key'] = '_evazar_dk_slug';
$category_meta_failed = evazar_persist_category_source_metadata(205, '/search/new-path/', 'digikala_breadcrumb');
$GLOBALS['test_fail_term_meta_key'] = '';
check('category metadata partial-write failure never leaves a verified marker', is_wp_error($category_meta_failed) && get_term_meta(205, '_evazar_dk_source_verified', true) === '0');

$GLOBALS['test_terms'][30] = (object)['term_id'=>30, 'name'=>'برند شکست ذخیره', 'slug'=>'brand-write-failure', 'taxonomy'=>'evazar_brand', 'parent'=>0, 'count'=>0];
$GLOBALS['test_term_meta'][30]['_evazar_dk_brand_id'] = '93006';
$GLOBALS['test_fail_term_meta_key'] = '_evazar_dk_brand_code';
$brand_meta_failed = evazar_sync_product_brand(9006, 'برند شکست ذخیره', 'Brand Write Failure', '/brand/brand-write-failure/', 93006, 'brand-write-failure');
$GLOBALS['test_fail_term_meta_key'] = '';
check('brand metadata partial-write failure returns WP_Error and leaves verified marker off', is_wp_error($brand_meta_failed) && get_term_meta(30, '_evazar_dk_source_verified', true) === '0');

$GLOBALS['test_terms'][32] = (object)['term_id'=>32, 'name'=>'برند دارای هویت قبلی', 'slug'=>'brand-known-source', 'taxonomy'=>'evazar_brand', 'parent'=>0, 'count'=>1];
$GLOBALS['test_term_meta'][32]['_evazar_dk_brand_id'] = '93007';
$GLOBALS['test_term_meta'][32]['_evazar_dk_brand_code'] = 'brand-known-source';
$GLOBALS['test_term_meta'][32]['_evazar_dk_url'] = '/brand/brand-known-source/';
$GLOBALS['test_term_meta'][32]['_evazar_dk_slug'] = 'brand-known-source';
$GLOBALS['test_term_meta'][32]['_evazar_dk_source_verified'] = '1';
$GLOBALS['test_fail_term_meta_key'] = '_evazar_dk_brand_code';
$brand_existing_meta_failed = evazar_sync_product_brand(9007, 'برند دارای هویت قبلی', 'Brand Known Source', '/brand/brand-known-source/', 93007, 'brand-known-source-v2');
$GLOBALS['test_fail_term_meta_key'] = '';
check('brand verification is withdrawn before updating an existing source tuple', is_wp_error($brand_existing_meta_failed) && get_term_meta(32, '_evazar_dk_source_verified', true) === '0');

 echo "\nRESULT: {$passed} passed, {$failed} failed\n";
exit($failed ? 1 : 0);
