<?php
/**
 * Focused regression tests for cross-queue isolation and taxonomy source retry safety.
 * This test uses WordPress/DB stubs for atomic option leases and ownership-guarded updates,
 * plus static contract checks for product/taxonomy shared Worker routing.
 */
error_reporting(E_ALL);
ini_set('display_errors', '1');
if (!defined('ABSPATH')) define('ABSPATH', dirname(__DIR__) . '/');
if (!defined('MINUTE_IN_SECONDS')) define('MINUTE_IN_SECONDS', 60);
if (!defined('HOUR_IN_SECONDS')) define('HOUR_IN_SECONDS', 3600);
if (!defined('ARRAY_A')) define('ARRAY_A', 'ARRAY_A');
$GLOBALS['tq_options'] = [];
$GLOBALS['tq_last_prepare'] = [];
$GLOBALS['tq_update_result'] = 1;
$GLOBALS['tq_update_calls'] = [];
$GLOBALS['tq_owned_id'] = 0;
$GLOBALS['tq_pass'] = 0;
$GLOBALS['tq_fail'] = 0;
$GLOBALS['tq_password_counter'] = 0;
function add_action(...$args) {}
function add_filter(...$args) {}
function absint($v) { return abs((int) $v); }
function sanitize_key($v) { return preg_replace('/[^a-z0-9_\-]/', '', strtolower((string) $v)); }
function sanitize_text_field($v) { return trim(strip_tags((string) $v)); }
function get_option($k, $default = false) { return array_key_exists($k, $GLOBALS['tq_options']) ? $GLOBALS['tq_options'][$k] : $default; }
function add_option($k, $v, $deprecated = '', $autoload = 'yes') { if (array_key_exists($k, $GLOBALS['tq_options'])) return false; $GLOBALS['tq_options'][$k] = $v; return true; }
function update_option($k, $v, $autoload = null) { $old = $GLOBALS['tq_options'][$k] ?? null; $GLOBALS['tq_options'][$k] = $v; return $old !== $v; }
function delete_option($k) { if (!array_key_exists($k, $GLOBALS['tq_options'])) return false; unset($GLOBALS['tq_options'][$k]); return true; }
function wp_cache_delete(...$args) { return true; }
function wp_generate_password($length = 12, $special = true, $extra = false) { $GLOBALS['tq_password_counter']++; return str_pad('tok' . $GLOBALS['tq_password_counter'], (int) $length, 'x'); }
function current_time($type = 'mysql', $gmt = false) { return gmdate('Y-m-d H:i:s'); }
function mb_substr($value, $start, $length = null, $encoding = null) { return $length === null ? substr((string) $value, $start) : substr((string) $value, $start, $length); }
function evazar_gemini_log_event(...$args) { return true; }

class TqIsolationFakeDb {
    public $prefix = 'wp_';
    public $options = 'wp_options';
    public $last_args = [];
    public $updates = [];
    public function prepare($query, ...$args) { $this->last_args = $args; return $query; }
    public function query($query) {
        if (stripos($query, 'DELETE FROM wp_options') === 0 && count($this->last_args) >= 2) {
            [$name, $value] = $this->last_args;
            if (($GLOBALS['tq_options'][$name] ?? null) === $value) { unset($GLOBALS['tq_options'][$name]); return 1; }
            return 0;
        }
        return false;
    }
    public function get_var($query) { return (int) $GLOBALS['tq_owned_id']; }
    public function update($table, $data, $where) {
        $this->updates[] = ['table' => $table, 'data' => $data, 'where' => $where];
        return $GLOBALS['tq_update_result'];
    }
}
$GLOBALS['wpdb'] = new TqIsolationFakeDb();
require dirname(__DIR__) . '/taxonomy-seo-queue.php';

function tq_check($label, $ok) {
    echo ($ok ? 'PASS' : 'FAIL') . ' - ' . $label . "\n";
    if ($ok) $GLOBALS['tq_pass']++; else $GLOBALS['tq_fail']++;
}

// Type-specific database leases: category and brand can coexist, same type cannot overlap.
$cat_key = evazar_taxonomy_seo_run_lock_option_name('category');
$brand_key = evazar_taxonomy_seo_run_lock_option_name('brand');
tq_check('category and brand use distinct persistent run-lock keys', $cat_key !== $brand_key);
$cat_lock = evazar_taxonomy_seo_run_lock_acquire('category');
$brand_lock = evazar_taxonomy_seo_run_lock_acquire('brand');
tq_check('category and brand runs can acquire their independent locks concurrently', $cat_lock !== '' && $brand_lock !== '');
tq_check('a second category run is blocked while the first category lock is live', evazar_taxonomy_seo_run_lock_acquire('category') === '');
tq_check('a second brand run is blocked while the first brand lock is live', evazar_taxonomy_seo_run_lock_acquire('brand') === '');
tq_check('lock ownership and heartbeat are tied to the exact run token', evazar_taxonomy_seo_run_lock_is_owned('category', $cat_lock) && evazar_taxonomy_seo_run_lock_heartbeat('category', $cat_lock) && get_option(evazar_taxonomy_seo_run_lock_heartbeat_option_name($cat_lock), 0) > 0);
tq_check('releasing category lock does not release or overwrite brand lock', evazar_taxonomy_seo_run_lock_release('category', $cat_lock) && evazar_taxonomy_seo_run_lock_is_owned('brand', $brand_lock));
tq_check('brand lock can subsequently be released independently', evazar_taxonomy_seo_run_lock_release('brand', $brand_lock) && !evazar_taxonomy_seo_run_lock_is_active('brand'));

// A stale lock is deleted only with the exact observed option value, then atomically replaced.
$old_token = (time() - 2000) . '|stale-taxonomy-token';
$GLOBALS['tq_options'][$cat_key] = $old_token;
$GLOBALS['tq_options'][evazar_taxonomy_seo_run_lock_heartbeat_option_name($old_token)] = time() - 2000;
$new_cat_lock = evazar_taxonomy_seo_run_lock_acquire('category');
tq_check('expired taxonomy run lock is reclaimed and replaced with a new owner token', $new_cat_lock !== '' && $new_cat_lock !== $old_token && evazar_taxonomy_seo_run_lock_is_owned('category', $new_cat_lock));
evazar_taxonomy_seo_run_lock_release('category', $new_cat_lock);

// Queue completion must require the row's exact term type, processing state and batch token.
$row = ['id' => 42, 'term_type' => 'category'];
$GLOBALS['tq_update_result'] = 0;
tq_check('zero-row taxonomy finish is not reported as success', evazar_taxonomy_seo_queue_finish($row, 'batch-a', 'done', 'test') === false);
$last = end($GLOBALS['wpdb']->updates);
tq_check('taxonomy finish is conditional on processing state and exact batch token', ($last['where']['status'] ?? '') === 'processing' && ($last['where']['batch_token'] ?? '') === 'batch-a' && ($last['where']['term_type'] ?? '') === 'category');
$GLOBALS['tq_update_result'] = 1;
tq_check('one-row ownership-matched taxonomy finish returns success', evazar_taxonomy_seo_queue_finish($row, 'batch-a', 'done', 'test') === true);
$GLOBALS['tq_owned_id'] = 42;
tq_check('row ownership check accepts only the matching queue row id', evazar_taxonomy_seo_queue_row_is_owned($row, 'batch-a'));
$GLOBALS['tq_owned_id'] = 0;
tq_check('row ownership check rejects a row whose batch claim is no longer owned', !evazar_taxonomy_seo_queue_row_is_owned($row, 'batch-a'));

$root = dirname(__DIR__);
$tax = file_get_contents($root . '/taxonomy-seo-queue.php');
$imp = file_get_contents($root . '/importer.php');
$qm = file_get_contents($root . '/queue-manager.php');
$core = file_get_contents($root . '/evazar-core.php');

// Verify queue boundaries and processing semantics without relying on docs or event labels.
tq_check('Core version is bumped to 2.9.84.96', strpos($core, '* Version: 2.9.84.96') !== false);
tq_check('category and brand remain separate scheduler hooks', strpos($tax, "'evazar_process_taxonomy_category_seo_queue' => 35") !== false && strpos($tax, "'evazar_process_taxonomy_brand_seo_queue' => 65") !== false);
tq_check('taxonomy rows are selected and claimed with term_type isolation', substr_count($tax, 'WHERE term_type=%s') >= 4);
tq_check('same-type run lock is acquired before locked queue processing', strpos($tax, '$run_lock = evazar_taxonomy_seo_run_lock_acquire($type)') < strpos($tax, 'evazar_taxonomy_seo_process_queue_batch_locked($type, $run_lock, $metrics)'));
tq_check('stale taxonomy rows are recovered only after acquiring the per-type run lock', strpos($tax, 'evazar_taxonomy_seo_run_lock_is_owned($type, $run_lock)') < strpos($tax, "SET status='retry',batch_token=''"));
tq_check('recent same-type processing claims block a new taxonomy Claim', strpos($tax, 'if ($processing_count > 0)') !== false && strpos($tax, '$ids = array_map') > strpos($tax, 'if ($processing_count > 0)'));
tq_check('source preparation and term saving remain sequential and bounded', strpos($tax, 'foreach ($rows as $row)') !== false && strpos($tax, 'foreach ($prepared as $entry)') !== false);
tq_check('taxonomy category/brand source requests use shared import_source Worker purpose', substr_count($imp, "'GET', 'import_source'") >= 3);
tq_check('taxonomy source fetch has ready/retry/no_content states', strpos($imp, "\$state = 'ready'") !== false && strpos($imp, "\$state = 'retry'") !== false && strpos($imp, "\$state = 'no_content'") !== false && strpos($tax, "\$source_state === 'retry'") !== false);
tq_check('temporary source/transport/Worker errors are retryable rather than terminal no-source skips', strpos($imp, "'worker_pool_busy'") !== false && strpos($imp, "'worker_pool_transport_errors'") !== false && strpos($tax, "'error_source_temporary'") !== false && strpos($tax, "'taxonomy_source_temporary_failure'") !== false);
tq_check('only the no_content branch reaches skipped_no_source terminal state after retry handling', strpos($tax, "evazar_taxonomy_seo_mark_preflight_status(\$term_id, 'skipped_no_source'") !== false && strpos($tax, "if (\$source_state === 'retry')") < strpos($tax, "evazar_taxonomy_seo_mark_preflight_status(\$term_id, 'skipped_no_source'"));
tq_check('taxonomy output save is guarded by both row Claim and per-type run ownership', substr_count($tax, 'evazar_taxonomy_seo_queue_row_is_owned($row, $batch_token)') >= 2 && substr_count($tax, 'evazar_taxonomy_seo_run_lock_is_owned($type, $run_lock)') >= 2);
tq_check('finish update treats zero affected rows as lost ownership', strpos($tax, 'return ($update === 1);') !== false);

// Shared source Worker lease must cover serial taxonomy dispatch and full product cURL-multi waves.
tq_check('serial source Worker dispatcher acquires and releases the shared per-Worker lease', strpos($imp, 'evazar_primary_worker_acquire_request_lock($base, $lock_timeout)') !== false && strpos($imp, 'evazar_primary_worker_release_request_lock($base, $worker_lock)') !== false);
tq_check('product parallel source selector atomically acquires the same shared Worker lease', strpos($qm, 'evazar_primary_worker_acquire_request_lock($url, 25)') !== false && strpos($qm, 'evazar_primary_worker_request_lock_info($url, 25)') !== false);
tq_check('product parallel source wave releases each Worker lease only after a positive HTTP response', strpos($qm, 'isset($response_object->status_code)') !== false && strpos($qm, '(int) $response_object->status_code > 0') !== false && strpos($qm, 'evazar_queue_release_product_source_worker_locks([$request_meta])') !== false && strpos($qm, 'The multi transport outcome is ambiguous') !== false);
tq_check('product claimed tail records shared Worker contention distinctly', strpos($qm, "'worker_pool_busy' ? 'PRIMARY_WORKERS_BUSY'") !== false);
tq_check('serial product import fallback defers the claimed run on busy shared Workers without retry inflation', strpos($qm, '$diag_code === \'worker_pool_busy\'') !== false && strpos($qm, "'action' => 'defer_run'") !== false && strpos($qm, '\'queue_error_code\' => $queue_code') !== false);
tq_check('live stock synchronization treats leased source Workers as temporary capacity deferral', strpos($imp, "'worker_pool_busy'") !== false && strpos($imp, 'busy_skipped') !== false && strpos($imp, 'sync_status' . "' => 'deferred'") !== false);
tq_check('taxonomy path reuses per-Gemini-Worker locks rather than creating a separate Gemini pool', strpos($imp, 'evazar_acquire_gemini_worker_lock($worker_url, $timeout)') !== false && strpos($imp, 'evazar_release_gemini_worker_lock($worker_url, $worker_lock)') !== false);
tq_check('product queue retains its own queue run-lock and claim-recovery logic', strpos($qm, 'evazar_queue_acquire_run_lock') !== false && strpos($qm, 'evazar_queue_recover_stale_processing_claims') !== false);

printf("RESULT: %d passed, %d failed\n", $GLOBALS['tq_pass'], $GLOBALS['tq_fail']);
exit($GLOBALS['tq_fail'] > 0 ? 1 : 0);
