<?php
$core = file_get_contents(__DIR__ . '/../evazar-core.php');
$importer = file_get_contents(__DIR__ . '/../importer.php');
$queue = file_get_contents(__DIR__ . '/../queue-manager.php');
$failures = 0;
function gbjd_check($label, $condition) {
    global $failures;
    echo ($condition ? "PASS" : "FAIL") . " - {$label}\n";
    if (!$condition) $failures++;
}
gbjd_check('Core version is 2.9.84.96', strpos($core, '* Version: 2.9.84.96') !== false);
gbjd_check('product batch requests enforce application/json', strpos($importer, "\$gemini_body['generationConfig']['responseMimeType'] = 'application/json'") !== false);
gbjd_check('product batch requests include responseSchema with required items', strpos($importer, "'required' => ['items']") !== false && strpos($importer, "'required' => ['dkp', 'review', 'pros', 'meta_description', 'focus_keyword']") !== false);
gbjd_check('invalid JSON decode stage and exact error are retained', strpos($importer, "\$GLOBALS['evazar_batch_json_decode_diagnostic']") !== false && strpos($importer, 'json_last_error_msg()') !== false);
gbjd_check('invalid-output deferral rotates idempotency identity without incrementing retries', strpos($importer, "'queue_error_code' => sanitize_key((string) (\$entry['item']->error_code ?? ''))") !== false && strpos($importer, "'next_attempt_at' => sanitize_text_field((string) (\$entry['item']->next_attempt_at ?? ''))") !== false);
gbjd_check('bounded raw model output diagnostics are stored separately with per-DKP reasons', strpos($importer, "evz_gemini_batch_json_diagnostics") !== false && strpos($importer, '$limit = 64000') !== false && strpos($importer, 'array_slice($items, 0, 20)') !== false && strpos($importer, "'validation_details' => \$validation_details") !== false && strpos($importer, "'review_not_string'") !== false && strpos($importer, "'duplicate_dkp'") !== false);
gbjd_check('diagnostic capture does not store prompt or request body', strpos($importer, "'response_text' => (string) \$batch_response") !== false && strpos($importer, "'user_prompt' =>") === false);
gbjd_check('diagnostics are visible in Gemini admin page', strpos($core, 'پاسخ خام دسته‌های دارای خطای JSON') !== false && strpos($core, 'علت اعتبارسنجی هر محصول') !== false && strpos($core, "get_option('evz_gemini_batch_json_diagnostics'") !== false);
gbjd_check('parallel invalid JSON defers chunk without finalizing product failures', strpos($queue, "in_array(strtoupper((string) \$code), ['AI_BATCH_OUTPUT_INVALID', 'AI_BATCH_INVALID_JSON'], true)") !== false && strpos($queue, "'batch_json_invalid_deferred'") !== false);
gbjd_check('serial invalid JSON defers chunk and continues to next chunk', strpos($queue, "in_array(\$responses->get_error_code(), ['AI_BATCH_OUTPUT_INVALID', 'AI_BATCH_INVALID_JSON'], true)") !== false && strpos($queue, 'evazar_queue_defer_batched_items($chunk, $responses, $claim_token);') !== false);
gbjd_check('defer queue code distinguishes malformed batch JSON', strpos($queue, "'AI_BATCH_OUTPUT_INVALID' => 'GEMINI_BATCH_JSON_INVALID'") !== false);
gbjd_check('lowercase parallel REST error codes still map to the JSON-specific queue status', strpos($queue, '$queue_code_map[$err_code] ?? ($queue_code_map[strtoupper($err_code)]') !== false);
$defer_start = strpos($queue, 'function evazar_queue_defer_batched_items');
$defer_end = strpos($queue, '/** Finalize one resumed batch product', $defer_start ?: 0);
$defer_body = ($defer_start !== false && $defer_end !== false) ? substr($queue, $defer_start, $defer_end - $defer_start) : '';
gbjd_check('defer helper returns rows to pending with a future retry time and never increments retries', $defer_body !== '' && strpos($defer_body, "'status' => 'pending'") !== false && strpos($defer_body, "'next_attempt_at' => \$resume_mysql") !== false && strpos($defer_body, "'retries' =>") === false);
if ($failures) exit(1);
echo "All Gemini batch JSON diagnostics regression checks passed.\n";
