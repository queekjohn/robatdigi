# EVazar Core 2.9.84.86 — Safer Bulk Requeue from Review Quarantine

- Hardens the quarantine bulk action by requiring a verified one-column, non-prefix UNIQUE index on `dkp` in both the active queue and the capacity-intake table; a composite or same-named wrong-column index fails closed.
- Moves eligible numeric-DKP quarantine entries into the existing durable capacity-intake table as explicit `qretry` work, instead of mass-setting every row to `pending` and bypassing the active queue capacity.
- Capacity promotion activates these explicit quarantine retries only when a slot is free; the same queue row, related product ID, and historical error text are retained. Other intake modes still cannot bypass quarantine or exclusion decisions.
- Existing `rewrite` intake intent is preserved via `qrewrite`; the `mode` column already has enough width.
- Rows whose DKP is not strictly numeric remain visible in quarantine for manual review rather than silently entering automation.
- Review counts exclude quarantined rows already staged for retry, and the button is disabled when no eligible numeric DKP remains.
- Uses the existing admin AJAX nonce and `manage_options` guard.
- Worker 1.13.27, cache files, Gemini prompts/API logic, and importer preflight validation are unchanged.
