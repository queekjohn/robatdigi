# EVazar Core 2.9.84.18 — Brand Tools Integrity Recheck

## Scope
- Based directly on Core 2.9.84.17 with embedded Worker 1.13.18.
- No change to product-batch size (2–30), dynamic queue capacity formula (eligible Workers × products/request), queue pause, Gemini model, cooldown rules, or retry policy.
- No change to Theme, `cache-purge.php`, `taxonomy-seo-queue.php`, price/stock jobs, or Worker JavaScript.

## Fixes
- Brand Tools no longer lets a typed slug override a previously verified Digikala brand source URL when no replacement source URL is supplied. The stored verified source path remains canonical; the admin notice explains why the typed slug was ignored.
- Brand Tools rename rejects a destination slug with an existing redirect mapping owned by another term.
- Brand Tools create rejects a source slug that already has a redirect mapping, preventing stale 301 mappings from silently pointing to a different brand after slug reuse.
- Regression tests cover the above cases.

## Validation
- Local WordPress test-double regression suite: 81 passed, 0 failed.
- Worker regression suite: 23 passed, 0 failed.
- Gemini cooldown suite: 32 assertions passed.
- PHP syntax: all 9 PHP files passed.
- Worker JavaScript syntax: passed.
- Embedded Worker SHA-256 matches standalone Worker 1.13.18 package.
- `cache-purge.php` hash is unchanged from Core 2.9.84.14 baseline.

## Limits
- No live site installation, real Gemini request, or production redirect test has been run.
- Historical brand paths remain subject to the separate verified-source migration/audit; this release does not mass-rewrite old brand terms.
