# EVazar Core 2.9.84.60 — Gemini Report PHP Context Fix

- Fixes a missing PHP context transition in the compact Gemini report event loop that caused PHP statements to be printed as raw page text and event-card values to be stale or repeated.
- Keeps the compact responsive cards, expandable diagnostics, report filtering, and queue/Worker/cache behavior unchanged.
- Adds a tokenizer regression check that rejects report executable statements inside `T_INLINE_HTML`.
- Bumps the plugin version to 2.9.84.60.
