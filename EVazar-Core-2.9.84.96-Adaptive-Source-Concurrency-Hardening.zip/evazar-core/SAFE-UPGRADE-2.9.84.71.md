# Safe upgrade — EVazar Core 2.9.84.71

1. Back up the site files and database before replacing Core.
2. Install only `EVazar Core 2.9.84.71`; no Worker deployment is required.
3. Open **ایوازار → گزارش عملیاتی Gemini** and inspect the new **تعویق دسته Gemini** event after a batch is deferred.
4. Expand **جزئیات فنی و اطلاعات کامل** to see batch size, DKP list (when available), error code, HTTP status (when known), worker host (when supplied), redacted error detail, and retry time.
5. This release changes diagnostics only. Queue behavior, batch size, retry/cooldown rules, and cache code are unchanged. Local tests do not imply a live API test.
