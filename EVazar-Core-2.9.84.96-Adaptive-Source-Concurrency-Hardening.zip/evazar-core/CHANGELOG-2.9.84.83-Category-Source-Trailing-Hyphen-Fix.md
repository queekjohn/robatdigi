# EVazar Core 2.9.84.83 — Digikala Category Source Trailing-Hyphen Fix

- Fixes Core source-path validation for explicit Digikala category slugs ending in a hyphen, including `/search/category-men-sport-shoes-/`.
- The path remains the exact source path provided by Digikala; no URL is guessed from a category name.
- Keeps pre-Gemini source-path validation enabled. A truly missing/invalid source path remains quarantined before Gemini or product writes.
- Production runtime changes are limited to `importer.php` validation and the plugin version header in `evazar-core.php`.
- `worker/digikala-worker.js`, `cache-purge.php`, Gemini settings/prompts, queue scheduling, price/stock behavior and product-save logic are unchanged.
