# EVazar Core 2.9.84.28 — Brand Source Identity and Slug Collision QA

## Change summary
- Brand source identity is based primarily on the Digikala source brand ID. If IDs differ, brands are distinct even when the source slug/URL collides.
- If the source-slug owner has a verified different identity, the incoming brand gets an available local public slug (`lg-1`, `lg-2`, …). The pre-existing owner and its product relationships are not taken over.
- Source URL and source slug metadata remain the actual Digikala identity; the local public-slug override is stored in separate metadata.
- If a source slug is owned by a manual/legacy term whose identity is unknown, import fails closed. It does not invent a collision or assign guessed metadata; the legacy term must first be reviewed/repaired.
- A pending source-ID marker supports safe retry after partial writes; successful verification clears it.
- The legacy metadata repair tool now accepts collision-suffixed public slugs only when live source checks establish the distinct identity and the base-slug owner is verified as different. Apply re-fetches source data and only writes metadata.
- Category source identity/metadata behavior is unchanged and continues using exact normalized Digikala breadcrumb/source paths.

## Local regression results
- Brand source/import regression: **112 passed, 0 failed**.
- Old brand metadata repair regression: **22 passed, 0 failed**.
- Brand selector/edit regression: **24 passed, 0 failed**.
- Worker/source JavaScript integration regression: **23 passed, 0 failed** (mocked network only).
- Gemini cooldown/recovery regression: **32 assertions passed**.
- PHP syntax: **14 PHP files passed**.
- JavaScript syntax: **4 JavaScript files passed**.
- ZIP archive integrity: checked with `unzip -t`.
- Embedded Worker source compared byte-for-byte with standalone Worker 1.13.18: identical; SHA-256 `06ad1344f83ed701bf7d5f922b297485d4c2ca5c61e56057d325fd46f10f9601`.

## Scope / unchanged files
Compared with Core 2.9.84.27, production changes are limited to:
- `evazar-core.php`: plugin version header 2.9.84.27 → 2.9.84.28.
- `importer.php`: brand source identity resolution, public-slug collision handling, and pending-ID retry marker.
- `brand-source-metadata-repair.php`: metadata-only repair validation/provenance for independently identified collision-suffixed brands.
- Changelog, upgrade note, and regression tests.

`cache-purge.php`, `queue-manager.php`, `product-index.php`, `taxonomy-seo-queue.php`, and `worker/digikala-worker.js` are byte-identical to the 2.9.84.27 baseline. No live cache, database, product assignments, terms, redirects, or Cloudflare configuration was changed during this QA.

## Important limits
- These are local tests with WordPress function stubs and mocked Worker network responses. This ZIP has **not** been deployed to the production EVazar database in this session.
- For an exact canonical slug owned by an unverified/manual term, the safe behavior is to stop import and require source metadata repair; it will not automatically use `lg-1` based on an unproven assumption.
- Take a current database backup and pause the product-import queue for the initial verification. Verify a confirmed distinct-ID collision and an unknown/manual slug owner before resuming normal imports.
