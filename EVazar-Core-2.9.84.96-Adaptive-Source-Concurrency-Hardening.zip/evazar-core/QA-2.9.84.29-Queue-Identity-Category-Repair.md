# EVazar Core 2.9.84.29 — Queue Taxonomy Identity and Category Metadata Repair QA

Date: 2026-10-25
Base package: EVazar Core 2.9.84.28

## Scope
- Harden the existing-products “همگام‌سازی دسته‌ها و برندها” action so it uses explicit source identity and does not treat name-only matches or malformed results as success.
- Align direct Digikala API fallback product payload with Worker payload by exposing `brand_source_path`, `brand_source_id`, and `brand_source_code`.
- Add admin-only metadata-only repair for old `evazar_category` source metadata.
- Update trusted metadata provenance version checks to `2.9.84.29`.

## Key behavior
- Existing item sync requests a fresh Worker product when stored taxonomy identity is missing/unverified/ambiguous. It does not allow direct-API fallback for this synchronization path; the source must be confirmed by the configured Worker.
- Category source paths are required and validated. Title-only crumbs or missing source data are counted as failures, not skipped successes.
- Category sync only counts success when the function returns a positive numeric term count. `WP_Error`, `false`, `null`, nonnumeric results, zero, or negative counts are failures.
- Brand assignment in existing-item sync requires the explicit source URL, Digikala ID, and source code; failed assignment is counted and logged, and display-name metadata is not overwritten on failure.
- Category metadata repair is available under Products → “ترمیم متادیتای دسته‌ها”. It lists incomplete/invalid source metadata, fetches current source breadcrumbs through the Core fetch helper, checks the full WordPress ancestor chain, source-path uniqueness, and independent product sample agreement, then writes only source metadata for rows explicitly marked READY.
- The repair tool requires `manage_options`, a valid nonce, the Core queue paused, an existing queue table, and zero `processing` rows. It re-fetches source samples during apply and rejects stale term/product/source snapshots.
- The category repair deliberately skips `derived_brand_landing` terms and does not change term name, public slug, parent, product assignments, redirect mappings, product index, cache, or Worker deployment.

## Regression results
- Queue taxonomy identity sync runtime harness: **9 passed, 0 failed**.
- Category source metadata repair: **16 passed, 0 failed**.
- Core brand/source/import regression: **112 passed, 0 failed**.
- Brand source metadata repair regression: **22 passed, 0 failed**.
- Brand selector regression: **24 passed, 0 failed**.
- Worker JavaScript/source regression: **23 passed, 0 failed**.
- Gemini cooldown/recovery regression: **32 assertions passed**.
- PHP syntax: **17/17 files passed `php -l`**.
- JavaScript syntax: `node --check` passed for the Worker, brand selector scripts, and extracted category-repair inline script.
- ZIP integrity: checked with `unzip -t`.

## Change-scope verification against Core 2.9.84.28
Changed/added:
- `evazar-core.php` — version header and admin loader for category repair tool.
- `importer.php` — category/brand provenance version and direct API fallback identity fields.
- `queue-manager.php` — provenance checks and hardened existing-item sync action.
- `brand-source-metadata-repair.php` — recognizes new provenance version.
- Added `category-source-metadata-repair.php`.
- Added `tests/queue-taxonomy-identity-sync-regression.php`; updated regression assertions to expect the new provenance version; added a changelog.

Verified byte-identical:
- `cache-purge.php` — SHA-256 `8cea2666c9a3...`
- `product-index.php` — SHA-256 `73794a104b62...`
- `taxonomy-seo-queue.php` — SHA-256 `0d959750ca5f...`
- `worker/digikala-worker.js` — SHA-256 `06ad1344f83e...`

The embedded Worker and standalone Worker 1.13.18 both hash to the same SHA-256:
`06ad1344f83ed701bf7d5f922b297485d4c2ca5c61e56057d325fd46f10f9601`

## Limits
- All tests use local WordPress stubs and/or mocked network responses; no live EVazar database or live Cloudflare deployment was accessed.
- The existing-item sync action keeps its previous bounded scope: the first 200 products by ascending post ID per invocation. This release does not turn it into a full-catalog scan in one request.
- Legacy categories without usable published product samples, or with conflicting verified identity, remain blocked for manual review rather than receiving guessed metadata.
