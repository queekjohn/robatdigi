# EVazar Core 2.9.84.92 — Taxonomy Source 502 Classification

## Problem addressed

The deployed Digikala Worker 1.13.27 exposes upstream diagnostics on taxonomy source-page and legacy taxonomy API responses, but some of those paths do not add `X-Evazar-Error-Scope: source`. Core previously interpreted any unscoped HTTP 502 as a Worker failure, cooled down that endpoint, and failed over to additional Worker URLs. A shared Digikala upstream failure could therefore cool down several healthy Worker deployments and end as `worker_pool_exhausted_http_errors`.

## Changes

- For `import_source` requests only, Core now recognizes the signed diagnostic header shape emitted by Worker 1.13.27: Worker version plus source-page diagnostics, or Worker version plus an upstream status from an allowlisted Digikala host.
- Such responses are classified as source-scoped failures, returned without retrying the same request through every Worker, and do not place healthy Workers into Worker cooldown.
- Responses that lack source provenance (including bare Cloudflare/Worker 502 responses) retain the existing Worker-failure handling and pool failover.
- Diagnostics now retain source upstream HTTP status/host/error, source path, fetch duration, response type, content status, redirect count/final path, and Worker version without logging response bodies or secrets.
- No changes are made to the deployed or embedded Cloudflare Worker. Existing five Worker deployments remain on 1.13.27.

## Preserved behavior

- The 2.9.84.91 Worker lease timeout safety remains unchanged.
- Gemini behavior, prompts/models, product parsing and persistence, category/brand identity rules, theme, and cache logic remain unchanged.
