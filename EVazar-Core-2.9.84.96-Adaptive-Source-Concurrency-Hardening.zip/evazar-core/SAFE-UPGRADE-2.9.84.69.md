# Safe upgrade — EVazar Core 2.9.84.69

1. Back up the current EVazar Core plugin and database before replacing the plugin ZIP.
2. Install Core 2.9.84.69 only; no Worker deployment is required for this change.
3. Open EVazar Products → Gemini operations report and inspect the section “پاسخ خام دسته‌های دارای خطای JSON” after the next invalid batch response.
4. Verify the affected queue rows return to `pending`, `retries` does not increase for invalid batch JSON, and other chunks continue.
5. The diagnostics retain at most 20 samples, with at most 12,000 bytes of model output per sample. Review access should remain limited to site administrators. Invalid-output deferrals rotate the request identity through the updated queue error code and retry time, without changing the retry counter.
