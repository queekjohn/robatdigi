# EVazar Core 2.9.84.22 — Require Verified Brand Assignment

## Changes
- Product import now requires an explicit, valid Digikala brand source URL whenever the incoming product has a brand. Missing/invalid source URL returns `PRODUCT_BRAND_SOURCE_URL_MISSING`, logs the product/DKP context, and prevents success status.
- Brand synchronization returns explicit success only after WordPress accepts the assignment and a follow-up `wp_get_object_terms()` confirms the exact term ID is attached.
- Taxonomy absence, invalid/missing source identity, slug conflict/migration verification failure, assignment write errors, and silent assignment no-ops return `WP_Error`; import logs the error and returns a `WP_Error` before index sync/success logging.
- Existing queue error handling returns these products to `pending` with a retry/backoff and recorded error.
- Preserves source-derived slug behavior, direct 301 mapping semantics, and independent brand URLs such as `/brand/salomon/` and `/brand/salomon-pc/`.
- No cache, queue-manager, Worker, Theme, or database schema code was changed.

## Validation
- Brand/source/queue regression harness: 80 passed, 0 failed.
- PHP syntax and ZIP integrity checked locally.
- Queue finalization source confirms ordinary `WP_Error` results are set back to `pending`, retry count increases, and error code/message are stored.

## Limits
- Local source tests only; not installed on or tested against the live WordPress database/site.
