# EVazar Core 2.9.84.20 — Remove Manual Brand Tools

## Change
- Removed the "ابزار برندها" admin submenu from the EVazar Products menu.
- Removed the `evazar_brand_tools_page()` handler and its manual search, rename, metadata-edit, and brand-create forms/actions from Core.

## Deliberately retained
- Import-time brand identity matching from Digikala's explicit `brand.id`, `brand.code`, and `brand.url.uri` fields.
- Canonical public brand-slug migration during product import when the source URL is explicit and verified.
- Existing direct 301 redirect handler and the `evazar_brand_slug_redirects` map, including pagination/query preservation and collision guards. These are still used by automatic source-slug migration and must not be removed with the admin UI.
- Gemini configuration/queue capacity, product batch size 30, worker-scaled queue planning, cooldown/recovery, queue pause, and taxonomy SEO batch size 5.

## Scope/safety
- Based on Core 2.9.84.19 with embedded Worker 1.13.18.
- No changes to importer.php, queue-manager.php, taxonomy-seo-queue.php, product-index.php, cache-purge.php, or Worker JavaScript.
- No changes to Theme or cache behavior.
- Existing brand terms, products, metadata, and redirect options are not migrated or deleted by this release; this is a code/UI removal only.
