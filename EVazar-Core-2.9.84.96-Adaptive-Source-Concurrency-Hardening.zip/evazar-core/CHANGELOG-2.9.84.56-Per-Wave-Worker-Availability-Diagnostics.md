# EVazar Core 2.9.84.56 — Per-Wave Primary Worker Availability Diagnostics

- Added per-wave snapshots of the configured primary Worker pool: eligible, cooling down, and daily-budget-exhausted Workers.
- Consolidated the full wave-by-wave selection trace into the existing `batch_dispatch_wave` summary; no new operation-log row is emitted per source wave.
- Each wave trace includes input count, eligible/configured count, actual selected count, selected Worker hosts, selection reason, and the post-wave pool snapshot.
- Added cumulative per-Worker counts for waves eligible, cooldown, daily budget, actual requests, plus last known state/reason/HTTP code.
- Distinguished genuine queue tails, pool cooldown/daily-budget exclusions, and reservation/selection races.
- Stopped repeating identical Worker selection/reservation checks for remaining products once no further distinct Worker can be reserved in the current wave. Unassigned items remain available for later queue handling.
- No changes to Gemini batch sizing, source Worker routing, Worker code, or cache behavior.
