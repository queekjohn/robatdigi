# EVazar Core 2.9.84.75 — Adaptive Gemini Batch Deep Review Fixes

- Retained the adaptive Gemini batch-size and concurrency controller from 2.9.84.74.
- Fixed an important queue-run integration gap: after an adaptive batch-size change, only the unsent tail is repartitioned immediately in the current run. Already dispatched or processed chunks are never re-sent. This applies to parallel waves and serial fallback.
- Successful, explicitly allowed singleton retries can now contribute to recovery streaks if their one expected response is present and valid.
- Strengthened the adaptive option lock with owner tokens so an expired/stale owner cannot remove a replacement request's lock. Legacy timestamp-only stale locks remain readable for expiry.
- Preserved the safe `http_code` field through internal parallel error serialization so diagnostics and adaptation retain the original upstream status without forwarding unrelated error data.
- Extended focused local regression coverage for parallel tail repartitioning, recovery coalescing, serial dynamic repartition integration, HTTP-status serialization, lock ownership, and singleton success validation.
- No changes to Cloudflare Worker source, source-fetch/cache logic, or cache purge code.
