# EVazar Core 2.9.84.89 — Queue Claim Recovery Safety

## Changes
- Queue run locks now have owner-specific heartbeats. Active queue runs refresh their heartbeat at item, serial-batch, and parallel-wave checkpoints, so a lock's original start time alone no longer allows a healthy long-running request to be replaced.
- On every successfully locked queue run, stale `processing` claims are examined before quota, worker-availability, or mode early exits. Recovery remains compare-and-set by queue row ID, claim token, and original claim timestamp; recovered rows receive a bounded exponential retry delay rather than being deleted.
- Before claiming a new batch, the queue counts any `processing` rows that remain after safe recovery. If even one previous claim remains, the run logs `queue_prior_claims_blocked` and takes no additional rows. This prevents one interrupted 200-item run plus a new 200-item run from accumulating as 400 processing rows.
- The claim-recovery threshold is conservatively derived from PHP's execution limit with a minimum 10-minute lease (15 minutes when PHP reports no time limit). Recent or possibly active claims are not retried early.
- Batch shutdown summaries now record `interrupted` when rows still owned by that claim remain in `processing`, making hard-to-diagnose incomplete runs more visible.
- Existing Gemini chunk sizes, Worker routing, product import/storage logic, cache behavior, and search-index behavior are unchanged.

## Validation
- Added `tests/queue-claim-recovery-regression.php` for the exact 200 + next-run scenario and mixed stale/recent 400-claim scenario.
- Full PHP regression suite: 27 test scripts passed, 0 failed.
- Focused queue recovery test: 14 assertions passed.
- Queue randomized-interval/run-lock regression: 47 assertions passed.
- PHP syntax checks and final ZIP integrity are verified separately in the test report.
