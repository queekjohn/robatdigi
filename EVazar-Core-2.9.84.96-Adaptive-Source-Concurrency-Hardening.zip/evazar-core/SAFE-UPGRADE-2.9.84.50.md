# Safe upgrade — EVazar Core 2.9.84.50

1. Back up the currently installed EVazar Core plugin.
2. Install `EVazar-Core-2.9.84.50-Grouped-Source-Fetch-Logs.zip`.
3. No Cloudflare Worker redeploy is required; keep the current Worker version.
4. Source fetch remains capped at three parallel requests per wave. The Gemini operation report no longer records a separate row for every source wave.
5. After preparation completes, the existing `batch_dispatch_wave` log includes a compact summary of total source waves, requests, responses, fallback count, and total preparation duration, alongside the Worker assignment.
6. Old per-wave rows are hidden from the two Gemini report views but are not deleted from the stored history. Exceptional transport errors and individual product/source errors remain logged as needed.
7. Queue claims, retry behavior, concurrency, Gemini batch size, cache behavior, and Worker routing are unchanged.

Local regression checks do not replace a live installation check.
