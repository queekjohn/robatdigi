# EVazar Core 2.9.84.17 — Gemini Worker-Scaled Queue Capacity

## Changes
- In Gemini-only batch mode, derive the queue-run ceiling from the per-Worker product batch size multiplied by the currently eligible distinct Gemini Worker count, subject to the manual safety ceiling and a technical maximum of 150 products (up to five Workers × 30 products).
- Examples: two eligible Workers × 20 products/request = 40 products/run; four eligible Workers × 30 = 120; five eligible Workers × 30 = 150.
- Workers in daily-quota cooldown, rate-limit cooldown, or an active Worker lock do not increase the eligible capacity.
- Keep active-queue admission capacity aligned with dispatch behavior; if parallel cURL transport is unavailable, admission and dispatch are limited to one product batch.
- Raise the admin safety-ceiling maximum from 75 to 150. A one-time migration promotes a legacy ceiling of 75 to 150, while intentionally configured values below 75 are preserved. The actual run capacity remains dynamically computed and may be below the manual ceiling.
- Preserve the legacy execution ceiling of 75 for non-Gemini-batch queue processing.
- Update the AI and queue settings copy to describe the dynamic Worker × batch formula.

## Compatibility and scope
- Base: Core 2.9.84.16 with embedded Worker 1.13.18.
- Worker JavaScript is unchanged; its existing per-request product maximum remains 30 and taxonomy SEO maximum remains 5.
- Existing product batch-size setting remains the per-Worker request size (2–30). It is not a daily Google API quota counter.
- No Theme, cache, `cache-purge.php`, price/stock synchronization, Gemini model, timeout, or cooldown-policy changes.

## Safety notes
- Capacity can be lower than the formula if a manual safety ceiling is below it, a Worker is cooling down/busy, parallel transport is unavailable, or the PHP runtime guard requires a single-batch run.
- Local tests use deterministic WordPress/API doubles. They validate capacity planning and queue behavior, not live Cloudflare/Gemini performance.
