# Safe upgrade — EVazar Core 2.9.84.90

1. Take a fresh database backup and a copy of the currently installed EVazar Core plugin.
2. Install/replace **EVazar Core only** with this release. Do not update the Theme or Cloudflare Worker for this change.
3. Do not manually reset product `processing` rows or taxonomy queue rows during the upgrade. The new ownership and stale-claim logic is intended to determine which claims are recoverable.
4. Keep the existing Cron configuration. This release does not require a new Worker URL, token, queue table, or destructive migration.
5. After installation, inspect the first category and brand queue runs for `taxonomy_queue_run_summary`, `taxonomy_source_temporary_failure`, and `taxonomy_queue_run_locked` events. For product imports, inspect `batch_dispatch_wave`, `queue_batch_run_summary`, and `queue_source_pool_deferred` as applicable.
6. If a queue is deferred because all shared Workers are busy, allow its normal retry schedule to run. Do not manually start overlapping runs or bulk-reset `processing` statuses.

## Scope guarantee

This release does not change product content generation, product persistence rules, category/brand prompt text, brand/category identity mapping, public URLs, or cache behavior. Product queue claim and run-lock code is retained; the changes are limited to cross-queue Worker leases, category/brand queue ownership/recovery, transient source classification, and diagnostics.

## Validation boundary

The package is validated with local automated PHP/JavaScript regression tests and PHP syntax checks. It has **not** been installed or exercised on the live evazar.ir database/server as part of this build.
