# QA — EVazar Core 2.9.84.79

## Finding corrected
A concurrent canonical index failure could set the search index state to `building` after the backfill completeness query but before its final `ready` write. The backfill then could overwrite the failure state using a stale result. The failure marker is now persisted before its state write; readiness is verified again after the provisional `ready` write. A failed second probe or a remaining product keeps the index in `building`.

## Local validation
- Core and Theme PHP regression scripts: 25 passed, 0 failed.
- PHP syntax: 49/49 passed.
- JavaScript syntax: 11/11 passed.
- Worker JavaScript regression scripts: 3 passed (54 checks total).
- Core product-search index regression now includes checks for the second readiness probe and failure-marker ordering.
- ZIP integrity checked.
- The Worker, importer, and `cache-purge.php` remain byte-identical to Core 2.9.84.76.

## Not verified
No production database, live search latency, or live backfill run was available. A full-text WordPress fallback remains for short indexed result sets; the new fast path chiefly accelerates title-token/prefix matches.
