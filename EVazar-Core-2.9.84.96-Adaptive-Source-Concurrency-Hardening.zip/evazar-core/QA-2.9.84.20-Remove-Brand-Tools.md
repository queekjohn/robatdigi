# QA — EVazar Core 2.9.84.20 Remove Manual Brand Tools

## Test results
- Core brand/queue regression harness: 71 passed, 0 failed.
- Worker static/integration regression: 23 passed, 0 failed.
- Gemini cooldown/recovery regression: 32 assertions passed.
- PHP syntax: all 9 PHP files passed `php -l`.
- Worker JavaScript syntax: passed `node --check`.
- ZIP integrity: passed `unzip -t`.

## Removal checks
- `evazar-brand-tools` is not registered as an admin submenu.
- `evazar_brand_tools_page()` does not exist in the plugin runtime.
- Manual create/rename/search and `evazar_brand_action` handlers were removed from executable PHP.
- Affiliate settings and Gemini operations menu entries still register.

## Brand functionality preserved
- Explicit Digikala brand source extraction/persistence during import.
- Source ID/code identity matching and automatic canonical slug movement.
- 301 redirect map/handler, including old-slug collision guard and pagination/query preservation.

## Diff scope against Core 2.9.84.19
Only these existing files changed:
- `evazar-core.php`: version 2.9.84.19 → 2.9.84.20; remove Brand Tools submenu and handler.
- `tests/brand-source-regression.php`: remove tests for deleted admin forms and replace them with checks that the menu/handler are absent while affiliate/Gemini menus remain.

All production files other than `evazar-core.php` are byte-identical to the Core 2.9.84.19 baseline. In particular `cache-purge.php`, `importer.php`, `queue-manager.php`, `taxonomy-seo-queue.php`, `product-index.php`, and embedded `worker/digikala-worker.js` are unchanged.

## Limits
- Local test doubles and syntax checks only; not installed on the live EVazar site.
- No production DB values or historical brands were changed.
