# Safe Upgrade — EVazar Core 2.9.84.46 / Worker 1.13.25

1. Publish `EVazar-Worker-1.13.25-Source-RateLimit-Guard.zip` to each of the four active Cloudflare Worker endpoints, preserving each endpoint's existing secrets, bindings, routes and environment settings.
2. Verify each endpoint reports Worker version `1.13.25` in `X-Evazar-Worker-Version` or its version JSON field.
3. Install `EVazar-Core-2.9.84.46-Source-RateLimit-Diagnostics.zip` in WordPress.
4. Resume with a small import run first. If Digikala rejects or times out a request, the log should now show the upstream error code and v2/v1 status. The queue will stop the current run and defer still-unsubmitted products instead of continuing to call the source.
5. A source 429 uses at least a 60-second not-before time (and honors the Worker retry hint up to 15 minutes); the normal 5–10 minute queue scheduler may delay the next run further.

This release does not perform a direct Digikala fallback and does not modify cache code/settings. Tests are local; check the deployed Worker version and first real source diagnostic after rollout.
