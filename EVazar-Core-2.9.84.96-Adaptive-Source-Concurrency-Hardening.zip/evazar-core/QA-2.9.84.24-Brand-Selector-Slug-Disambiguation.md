# QA — EVazar Core 2.9.84.24 Brand Selector Slug Disambiguation

## Scope
- Brand selection UI only: brand term search/assignment controls and the brand term admin list.
- No edits to importer, queue manager, LiteSpeed cache-purge files, product index, or Cloudflare Worker.

## Behavior implemented
- Search searches both `evazar_brand` term name and slug, returning term ID, name, and slug.
- Search result and selected-choice labels display Persian name, English slug, and numeric term ID.
- Classic product edit saves exact term IDs and replaces the brand assignment only when the editor explicitly submits the brand picker.
- Quick Edit and Bulk Edit hide WordPress's ambiguous flat-taxonomy name field and append selected term IDs while preserving current assignments.
- Gutenberg product editing receives an ID-based sidebar selector; native taxonomy panel is removed when the editor store exposes the panel-removal action.
- The brand terms list displays each term's slug beneath its name.

## Local checks
- Brand selector regression harness: 12 passed, 0 failed.
- Existing Core brand/source regression suite: 89 passed, 0 failed.
- Existing Worker JavaScript regression suite: 23 passed, 0 failed.
- Existing Gemini cooldown/recovery suite: 32 assertions passed.
- PHP syntax: all 12 PHP files passed `php -l`.
- JavaScript syntax: admin selector, block editor selector, and Worker regression script passed `node --check`.
- ZIP archive integrity: passed (`unzip -t`).
- Production files other than `evazar-core.php` and the new brand selector modules are byte-identical to Core 2.9.84.23. The changes in `evazar-core.php` are limited to version/bootstrap registration and disabling the native name-only quick/bulk brand field.

## Runtime limitation
- Tests use local WordPress-function stubs; no live WordPress admin session or production database was available here. Install first on staging or with a current database backup and verify classic/Gutenberg editor and Quick/Bulk Edit behavior on the live EVazar version before relying on it.
