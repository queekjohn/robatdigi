# QA — EVazar Core 2.9.84.15 / Worker 1.13.17

## Test results
- PHP syntax check: all 9 PHP files passed
- `php tests/brand-source-regression.php`: 53 assertions passed, 0 failed
- `node tests/brand-source-regression.js`: 17 assertions passed, 0 failed
- `php tests/QA-2.9.84.13-Gemini-Cooldown-Local-Test.php`: 32 assertions passed

## Source fixture verified
The supplied `product digi.txt` JSON has:
- `data.product.brand.id = 18`
- `data.product.brand.code = "samsung"`
- `data.product.brand.title_en = "Samsung"`
- `data.product.brand.url.uri = "/brand/samsung/"`

Worker regression tests exercise this exact field shape and assert the normalized path `/brand/samsung/` plus source ID/code.

## Brand migration regression coverage
- Source URL slug takes precedence over `brand_en` slug.
- Case differences normalize to lowercase (`/brand/Samsung/` -> `samsung`).
- Existing term is migrated in place when the stored Digikala brand ID confirms identity.
- Old public slug gets a direct 301 mapping.
- Brand association remains on the same migrated term.
- Conflicting term identity/redirect mappings are not overwritten.
- If another term owns the canonical source slug, migration aborts without attaching the product or falsely verifying the old term.
- If source URL is absent, a supplied source ID cannot claim an unverified title-matched term unless its stored source ID matches.
- Missing source URL does not create a guessed new public term or a guessed source slug.
- Brand Tools create/rename use the explicit source URL slug when a valid source URL is supplied.

## Non-claims
These are local regression tests and a test against the supplied JSON fixture. They do not prove the deployed Worker has been updated or that all existing database terms have been migrated. The existing historical audit reported source paths as unverified; those records must be revalidated before mass migration.

## Baseline compatibility correction
- This package is based directly on Core 2.9.84.14 with Worker 1.13.13.3.
- Worker automatic Gemini product batch maximum remains **15**; taxonomy SEO batch maximum remains **5**. The unrelated changes to 10 and 50 from the intermediate 1.13.16 package are deliberately excluded.
