# EVazar Core 2.9.84.24 — Brand Selector Slug Disambiguation

- Brand search in EVazar product editing now displays the Persian name, public slug, and term ID together.
- Search matches both term names and slugs, so an editor can search `salomon` or `salomon-pc` and choose the exact brand.
- Classic product editing uses a selector keyed by term IDs, allowing exact replacement without relying on duplicate names.
- WordPress Quick Edit and Bulk Edit use a custom ID-based selector; chosen terms are appended while existing brand assignments remain intact, matching the non-destructive behavior expected from native bulk editing.
- The native name-only Quick/Bulk Edit taxonomy path is disabled for `evazar_brand` to avoid ambiguous assignment of duplicate-name terms.
- The brand taxonomy list screen shows the public slug under each brand name.
- Gutenberg product editing uses an ID-based sidebar panel and removes the native brand taxonomy panel when the editor supports that action.

No cache files, importer, queue manager, Worker source, redirect map, brand terms, or product assignments are changed by the release itself. Existing product-term assignments change only when an editor explicitly saves a brand selection.
