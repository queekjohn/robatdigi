# QA — EVazar Core 2.9.84.19 Gemini Queue Cap Migration

## Scope
- Based on Core 2.9.84.18 with embedded Worker 1.13.18 unchanged.
- Adds one-shot migration from the exact stale outer queue cap `15` to `150`; preserves any other current manual value.

## Required verification
- When saved cap is 15, outer cap and legacy compatibility option become 150.
- With four eligible Workers and 30 products/request, theoretical cap becomes 120, subject to parallel transport, runtime, cooldown, and Worker eligibility guards.
- Other saved caps (e.g. 40) remain 40.
- The migration marker prevents later overwriting a user-selected lower cap.
- `cache-purge.php` and embedded Worker are unchanged from 2.9.84.18.

Live WordPress/Gemini execution must still be verified after deployment; local tests do not prove production concurrency or available Gemini quota.
