# Safe Upgrade — EVazar Core 2.9.84.36

1. Replace the existing EVazar Core plugin with `EVazar-Core-2.9.84.36.zip`.
2. Keep Cloudflare Worker 1.13.23; this release does not change Worker code or deployment requirements.
3. The “ثبت برند از لینک دیجی‌کالا” page now appears under the EVazar Core custom product menu (`کالاهای ایوازار`), alongside Core's existing admin submenu items.
4. The preview and cancel/restart navigation return to `admin.php?page=evazar-brand-source-register`.

No changes to brand-source identity logic, product assignments, import queues, redirect mappings, cache-purge implementation, product index, pricing/stock, or Worker code.
