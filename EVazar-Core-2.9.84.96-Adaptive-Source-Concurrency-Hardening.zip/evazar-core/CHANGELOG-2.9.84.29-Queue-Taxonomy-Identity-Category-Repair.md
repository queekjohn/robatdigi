# EVazar Core 2.9.84.29 — Source-Identity Queue Sync and Category Metadata Repair

## Changes
- Hardened the existing-products “همگام‌سازی دسته‌ها و برندها” operation to use explicit source identity from a fresh Worker response whenever existing taxonomy identity is missing, stale, unverified, or ambiguous.
- Category synchronization now requires explicit, validated source URLs on real breadcrumb entries. Missing source identity is reported as a failure rather than being silently treated as success.
- Category sync results must be a positive numeric term count. `WP_Error`, `false`, `null`, nonnumeric values, and zero/negative counts are failures; this prevents PHP's truthy `WP_Error` behavior from inflating success counts.
- Brand sync no longer falls back to a name-only mapping in the existing-products sync action. It requires a source URL, source ID, and source code and treats failed/unconfirmed term assignment as failure.
- The direct Digikala API fallback payload now exposes `brand_source_path`, `brand_source_id`, and `brand_source_code`, keeping its payload contract aligned with the Worker response.
- Added an admin-only “ترمیم متادیتای دسته‌ها” tool. It analyzes incomplete category source metadata against fresh product breadcrumbs, checks the full WordPress parent chain, source-path ownership, and up to two independent product samples, then writes only verified source metadata for explicitly READY candidates.
- Category repair requires the import queue to be paused with zero `processing` items. Apply re-fetches samples and checks term/product snapshots before writing. It does not change category names, slugs, parents, product assignments, redirect maps, cache, or Worker configuration.
- Updated brand metadata repair/queue provenance checks to recognize the new `2.9.84.29` verified metadata version.

## Deliberately unchanged
- `cache-purge.php`
- `product-index.php`
- `taxonomy-seo-queue.php`
- `worker/digikala-worker.js` — embedded Worker remains byte-identical to standalone Worker 1.13.18.

## Safety notes
- The existing-products sync action still processes the first 200 products by ascending post ID per invocation, matching the prior bounded scope; this release does not turn it into an unbounded full-catalog run.
- Category repair is metadata-only and deliberately excludes `derived_brand_landing` terms. Categories without enough live product samples or with identity conflicts remain blocked for manual review.
- Local tests use WordPress stubs/mocked network responses. No live production database or Cloudflare Worker deployment was changed by this package.
