# EVazar Core 2.9.84.23 — Brand Redirect Admin Cleanup

- Adds a dedicated `محصولات → ریدایرکت برندها` admin screen to inspect the saved `evazar_brand_slug_redirects` map.
- Shows old brand slug, mapped target term ID/name/current slug, and whether the target is missing or the old slug is currently owned by a different brand.
- Supports search, paged selection, downloading the exact raw option as a JSON backup, and deletion of only selected redirect-map keys.
- Requires `manage_options`, a WordPress nonce, an explicit backup confirmation, and a target-ID snapshot check so stale forms cannot silently remove changed mappings.
- The delete action changes only the `evazar_brand_slug_redirects` option. It does not delete or rename brands, reassign products, alter source metadata, flush rewrite rules, or touch cache/Worker code.
- Based on Core 2.9.84.22. Existing import/brand-assignment behavior is otherwise preserved.
