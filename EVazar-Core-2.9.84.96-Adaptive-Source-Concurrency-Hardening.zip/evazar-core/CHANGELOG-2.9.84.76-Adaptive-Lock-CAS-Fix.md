# EVazar Core 2.9.84.76 — Adaptive Lock Compare-and-Swap Fix

- Fixed a stale-lock reclamation race found during final QA of 2.9.84.75. The lock is now removed only when a single conditional database delete confirms both the option name and the exact stale value still match.
- Invalidates the relevant WordPress option caches after successful conditional deletion.
- Adds a deterministic regression test simulating a concurrent replacement between stale-lock read and reclamation; the replacement owner must survive.
- Keeps the 2.9.84.75 adaptive Batch behavior, including immediate unsent-tail repartitioning, 5xx discrimination, gradual recovery, and concurrency control.
- No changes to Cloudflare Worker source, cache-purge code, source-fetch routing, or cache behavior.
