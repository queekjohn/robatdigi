# EVazar Core 2.9.84.68 — Queue failures in Import Logs

- Root cause: queue/Gemini per-product failures were written to the separate `evz_gemini_ops_log` option, while the 200-row Import Logs table reads the file-backed `evazar_import_log()` log.
- Mirror pre-Gemini and final queue failure events into the same file-backed Import Logs log, including DKP, stage/code, and bounded error detail.
- Keep the operational Gemini log intact; no queue execution, retry, or success behavior changed.
