# EVazar Core 2.9.84.94 — Product Source Header Normalization

## Fixed

- Normalize HTTP response header values from WordPress Requests and `Requests::request_multiple()` before classification or logging. Scalar values, array-valued headers, and nested array values are handled without PHP's `Array to string conversion` or the misleading literal `Array`.
- Apply the same normalization in the serial primary-Worker dispatcher, parallel product-source prefetch conversion, and item-scoped source diagnostics.
- Treat the Worker's explicit `X-Evazar-Error-Scope` as authoritative after normalization. If that header is missing or unusable, infer `source` only from the narrow Worker product-source JSON contract: HTTP error, `success=false`, an `error` beginning with `source_`, a Worker version, and explicit v1/v2 upstream status or error diagnostics.
- Preserve genuine Worker/runtime failures and explicit `worker` scope as Worker failures; they continue through the existing failover/cooldown path. Product-scoped 404 behavior is unchanged.
- A product response such as Worker HTTP 503 + `source_server_error` + upstream v2 HTTP 502 is now kept as an item-local source failure. It no longer becomes `worker_http_503`, does not falsely cool down a healthy Worker, and is not needlessly replayed against another Worker.
- Preserve the correct Worker version, source scope, source error code, and v1/v2 upstream diagnostics in pre-Gemini logs. Worker HTTP 503 and upstream v2 HTTP 502 remain separate fields.

## Preserved

- The 2.9.84.91 shared Worker lease timeout safety, 2.9.84.92 source-vs-Worker 502 classification, and 2.9.84.93 taxonomy API SEO-description fallback remain intact.
- Worker 1.13.27 and its embedded copy are unchanged; no Cloudflare Worker deployment is required.
- Product payload parsing, product persistence, retry-count policy, Gemini model/prompts, taxonomy source extraction, taxonomy identity validation, Theme, and cache behavior are unchanged.
