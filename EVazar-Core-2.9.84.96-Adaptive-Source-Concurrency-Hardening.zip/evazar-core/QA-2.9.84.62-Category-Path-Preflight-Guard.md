# QA — EVazar Core 2.9.84.62

## Regression results
- 16 PHP regression suites passed: 549 assertions/checks total.
- 3 JavaScript regression suites passed: 54 assertions/checks total.
- Syntax checks passed for all 28 PHP files and 6 JavaScript files.
- ZIP integrity was rechecked after packaging.

## Focused cases
- Source category path is validated before AI batch checkpoint, Gemini request preparation, and any product post/meta write.
- Missing source breadcrumbs and title-only categories return the exact quarantine-classified `PRODUCT_CATEGORY_SYNC_FAILED` WP_Error with `saved=false`.
- Valid explicit Digikala category URLs pass preflight.
- Final category sync reuses the same validator to prevent preflight/sync rule drift.
- Generic term/database sync failures remain retryable and are not mislabeled as missing source path.
- The existing post ID is preserved as a related reference when the DKP already exists; the preflight itself does not mutate that post.
- An explicit administrator action can move a linked product from a source-path quarantine row to Draft; the product and metadata are not deleted. The action rejects non-`evazar_product` post types and non-matching queue rows.
- Existing quarantine retry/exclusion, Harvester reservation, and queue scheduling logic remain covered by the full regression suite.

## Scope boundaries
- No Cloudflare Worker code was changed.
- No cache-specific code or purge rules were changed.
- Tests use local WordPress stubs and synthetic product payloads; no live production DB, Digikala API, Gemini API, or Cloudflare Worker was exercised.
- Existing partial products are not automatically changed; the quarantine page now provides a manual Draft action so an administrator can safely take those already-created records out of public view without deleting them.
