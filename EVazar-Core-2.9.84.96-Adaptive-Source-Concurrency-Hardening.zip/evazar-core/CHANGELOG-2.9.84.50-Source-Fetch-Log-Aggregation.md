# EVazar Core 2.9.84.50 — Aggregate source-fetch diagnostics

- Keeps bounded three-product parallel source fetches unchanged.
- Stops emitting one Gemini operation-log row for every source-fetch wave.
- Aggregates source wave/request/response/fallback/transport metrics per queue run.
- Attaches the single source-preparation summary to the existing `batch_dispatch_wave` event, after product preparation finishes and immediately before Gemini Worker assignment/dispatch.
- Hides historical `queue_source_parallel_wave` records from both Gemini report views without deleting the stored operation-log records.
- Preserves exceptional PHP error-log reporting for cURL-multi transport exceptions and preserves item-level product/source error logs.
- Adds structured source-fetch metrics to the existing operation-log record.
- No Worker, queue ownership, retry policy, product processing, cache behavior, or dispatch assignment logic changed.

Local PHP/JS syntax and regression tests are required before deployment; live WordPress/Gemini operation remains unverified until installed.
