# EVazar Core 2.9.84.28 — Source identity and public slug collision handling

## Brand import
- Brand identity resolution now distinguishes `same`, `conflict`, and `unknown` source identity. A matching source ID is the strongest key; if the same ID moves to a new source URL, that remains the same brand. Different source IDs represent separate brands even if a source URL/slug collides. Without an ID, only a verified source URL can prove a match or conflict.
- A matching name or source slug alone is not enough to claim a term when its source identity is unknown. Import fails closed until the existing term's metadata has been safely repaired.
- If an existing canonical slug is owned by a confirmed different Digikala brand ID (or a different verified source URL when no source ID is available), the existing term is preserved and the incoming brand is created/located at a unique public slug such as `lg-1`, `lg-2`, etc.
- Repeated imports resolve the independent term by source ID and preserve its local numeric suffix. The source URL/slug metadata still records the actual Digikala URL; `_evazar_dk_public_slug_override` and its reason indicate that the local public slug differs because of a collision.
- No redirect is created from the occupied source slug to the new brand. If an existing source-ID term must move to a collision suffix, its prior public slug gets a direct redirect only when redirect-map and term changes can be verified safely.

## Old brand metadata repair
- Supports the new trusted metadata map versions.
- When the public slug is a numeric collision suffix, metadata repair permits it only if source ID/URL checks prove the term is distinct from the source-slug owner. An unknown/manual owner remains protected.
- Repair remains metadata-only and rechecks the source live before committing.

## Categories
- Existing category identity behavior remains based on the exact normalized Digikala breadcrumb/source path. Same-name categories with different source paths stay separate; slug collisions use the category resolver's existing deterministic suffix logic.
- Category metadata persistence, parent hierarchy, assignment, SEO, and queue semantics are unchanged.

## Deliberately unchanged
- LiteSpeed/cache-purge code, Product Index, product import queue manager, Cloudflare Worker source, Gemini model/cooldown logic, and product pricing/stock behavior.
- A pending source-ID marker is persisted before assignment/identity writes and cleared after the verified tuple succeeds. This lets retries recover the same term by source ID after a partial write instead of creating duplicate suffixed terms.
