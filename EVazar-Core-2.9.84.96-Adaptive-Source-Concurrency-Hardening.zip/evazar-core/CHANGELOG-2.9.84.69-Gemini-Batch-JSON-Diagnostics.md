# EVazar Core 2.9.84.69 — Gemini Batch JSON Diagnostics and Safe Deferral

- Adds Gemini `responseSchema` for product-batch output alongside `responseMimeType: application/json` to constrain the generated structure.
- Saves up to 20 bounded diagnostics for invalid/partial product-batch output, including the model output (up to 12,000 bytes), model, HTTP status, `finishReason`, batch/request IDs, DKPs, parser error, validation error, byte count, and output hash.
- Displays these diagnostics in the existing Gemini operations admin page. Prompts, API keys, Worker secrets, and full request bodies are not stored.
- Fixes serial and parallel queue paths so a malformed batch response defers only the affected chunk without incrementing product retries or converting the whole chunk into final product failures; later chunks continue where possible. The idempotency identity also rotates from the deferred queue state, preventing replay of the same cached malformed response.
- Does not change cache behavior, Worker code, product-source fetching, or price/stock updates.
