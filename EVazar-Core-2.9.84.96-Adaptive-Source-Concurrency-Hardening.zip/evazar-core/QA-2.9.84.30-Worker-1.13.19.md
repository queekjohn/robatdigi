# Final QA — EVazar Core 2.9.84.30 / Cloudflare Worker 1.13.19

Date: 2026-10-25

## Release identity
- Base: EVazar Core 2.9.84.29 (Queue Taxonomy Identity and Category Metadata Repair).
- New Core plugin header: 2.9.84.30.
- Embedded Worker and standalone Worker: 1.13.19.
- Embedded and standalone Worker SHA-256:
  `11371673821d0238cd7ec438a9be768dfcdeba89692b2755229d2dc106d391bd`
- The two Worker source files are byte-for-byte identical.

## Version 1.13.19 compatibility changes
- Preserves Worker 1.13.18's product/source extraction, explicit brand source ID/code/path passthrough, 30-product Gemini batch maximum, and other established routes.
- Adds authenticated read-only `POST /brand-audit/product` before the generic product/cache route.
- Audit request requires `X-Evazar-Internal-Token` matching the existing `EVAZAR_INTERNAL_TOKEN` Secret.
- Audit API accepts numeric `dkp_id` only, has no arbitrary URL field, returns a minimal product + brand identity payload, and sets `Cache-Control: no-store` and `CDN-Cache-Control: no-store`.
- Audit route uses 8-second per-hop upstream timeout; existing fetch callers retain the previous 12-second default.
- On explicit 401/403/429 or timeout, the audit route avoids a v1 retry. On other quick v2 failures it tries v1 once.

## Tests run on the actual packaged source
- Core brand/source/import regression: **112 passed, 0 failed**.
- Brand source metadata repair: **22 passed, 0 failed**.
- Category source metadata repair: **16 passed, 0 failed**.
- Existing-products queue taxonomy identity sync: **9 passed, 0 failed**.
- Brand selector and bulk replacement: **24 passed, 0 failed**.
- Existing Worker/source regression: **23 passed, 0 failed** (updated to expect Worker 1.13.19).
- New authenticated Worker audit endpoint regression: **6 passed, 0 failed**.
- Gemini cooldown/recovery regression: **32 assertions passed**.
- PHP syntax: **17/17 files passed `php -l`**.
- JavaScript syntax checks passed for Worker, both brand selector scripts, Worker source test, and Worker audit endpoint test.
- Core ZIP and standalone Worker ZIP: archive integrity passed with `unzip -t`.
- Re-extracted final ZIPs confirmed that the embedded and standalone Worker files are byte-identical and both report 1.13.19.

## Scope against Core 2.9.84.29
Runtime changes are limited to:
- `evazar-core.php`: plugin version header 2.9.84.29 → 2.9.84.30.
- `worker/digikala-worker.js`: Worker 1.13.18 replaced with exact standalone Worker 1.13.19.

Regression tests and release/deploy documentation were updated/added. The following production files are byte-identical to Core 2.9.84.29: `cache-purge.php`, `importer.php`, `queue-manager.php`, `product-index.php`, `taxonomy-seo-queue.php`, `brand-source-metadata-repair.php`, `category-source-metadata-repair.php`, `brand-selector-admin.php`, `brand-selector-editor.js`, and `brand-selector-admin.js`.

## Deployment constraints / limitations
- Local tests use WordPress stubs and mocked network responses. No live EVazar database, Cloudflare account, or live Digikala request was accessed.
- Deploy Worker 1.13.19 to the active primary Worker URLs before updating Core. Core ZIP installation does not deploy the Worker to Cloudflare.
- Preserve the currently configured `EVAZAR_INTERNAL_TOKEN`, all API keys, Secrets, and bindings.
- No database migration is introduced by this version-only Worker package update. No cache purge or cache configuration change is required.
