# EVazar Core 2.9.84.30 — Embedded Worker 1.13.19

- Based on Core 2.9.84.29, preserving its source-identity queue sync and category metadata repair.
- Updates only the embedded `worker/digikala-worker.js` to the exact standalone Worker 1.13.19 source.
- Worker 1.13.19 adds the authenticated, read-only `POST /brand-audit/product` route; existing product, image, price/stock, source-page, Gemini, and cache behavior remain unchanged by the Worker release notes and regression checks.
- Updates the existing Worker contract test to expect response version 1.13.19 and adds dedicated audit endpoint regression tests.
- No database schema migration is required. No cache, importer, queue, product-index, or taxonomy SEO runtime file is changed in this release.
