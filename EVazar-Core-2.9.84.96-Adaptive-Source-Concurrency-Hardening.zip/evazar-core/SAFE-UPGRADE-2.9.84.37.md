# Safe Upgrade — EVazar Core 2.9.84.37

1. Back up the existing EVazar Core plugin ZIP and database before installation.
2. Install `EVazar-Core-2.9.84.37.zip` over the existing EVazar Core plugin.
3. Open Products → EVazar Queue (the queue administration page) once. `admin_init` migrates old queue cron schedule version 2 to version 3 and selects the first randomized delay.
4. In the queue timing settings, verify the defaults: minimum 5 minutes, maximum 10 minutes. Adjust and save if needed.
5. Confirm the pause/resume buttons and manual queue button still appear and work as expected.

The Cloudflare Worker does not need an update for this feature. It remains at 1.13.23 and is embedded byte-for-byte unchanged.

Note: WP-Cron execution depends on site traffic or a configured system cron. Random timing defines the not-before timestamp; it cannot guarantee that WordPress will execute at the exact second.
