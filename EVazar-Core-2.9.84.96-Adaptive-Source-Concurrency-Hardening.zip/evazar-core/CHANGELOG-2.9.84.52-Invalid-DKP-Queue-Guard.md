# EVazar Core 2.9.84.52 — Invalid DKP Queue Guard

- Diagnosed the 120-claimed / 45-source-request / 75-pre-Gemini-error pattern as strongly consistent with legacy queue rows whose DKP normalizes to an empty string.
- Adds a non-destructive quarantine for pending queue rows with blank/non-numeric DKP: moves them to `failed` with `INVALID_DKP`, clears any claim lease, sets no next retry, and does not increment retries. No row or product data is deleted.
- Adds the valid-DKP condition to eligible counts and the atomic claim SQL so malformed records cannot consume a batch slot even if more than the quarantine limit exists.
- Excludes non-numeric DKPs from automatic legacy-failed retry to prevent an invalid row from repeatedly reclaiming capacity.
- Adds an explicit terminal handler for runtime `invalid` DKP errors and surfaces the quarantine count in claim and end-of-run diagnostics.
- No Worker, Gemini prompt, cache, or source-fetch concurrency changes.
