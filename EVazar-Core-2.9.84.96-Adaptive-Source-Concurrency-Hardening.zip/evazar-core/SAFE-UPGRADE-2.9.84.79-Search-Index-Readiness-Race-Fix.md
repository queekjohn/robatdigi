# Safe upgrade — EVazar Core 2.9.84.79

1. Keep a current database and plugin backup before replacing the Core folder.
2. Keep the plugin directory name `evazar-core/` unchanged.
3. Theme 1.13.29 is the compatible companion for the indexed live-search path.
4. Existing Core search-index tables are reused; this patch adds no schema migration. If an index error occurs, the search fast path remains disabled until scheduled backfill verifies completeness.
5. No Cloudflare Worker deployment is required. Worker and cache-purge code are unchanged.
