# EVazar Core 2.9.84.93 — Taxonomy API SEO Description Fallback

## Fixed

- Category/brand SEO preflight now extracts usable taxonomy source text from the fields actually returned by Digikala's discovery API when full `seo.content` and `category_brand.description` are empty.
- Page-level `data.seo.description` is combined with explicit `data.category.description` and/or `data.brand.description` fields. Nested category/brand SEO descriptions are also recognized.
- Existing full editorial fields retain precedence. Exact category/brand identity validation (`data.category.code` and `data.brand.code`) remains mandatory and unchanged.
- HTML descriptions are converted to readable text, HTML entities are decoded, paragraph/list boundaries are preserved, duplicate/nested fragments are removed, and combined source text is capped at 18,000 characters.
- A usable discovery API response now completes the source fetch directly; the broken public `/search/` HTML fallback is not requested for this response shape.

## Preserved

- Worker 1.13.27 and its embedded copy are unchanged; no Cloudflare Worker deployment is required.
- The 2.9.84.91 shared Worker lease timeout safety and 2.9.84.92 source-vs-Worker 502 classification remain intact.
- Product import, Gemini model/prompts, taxonomy term identity, taxonomy queue locking, Theme, and cache behavior are unchanged.
