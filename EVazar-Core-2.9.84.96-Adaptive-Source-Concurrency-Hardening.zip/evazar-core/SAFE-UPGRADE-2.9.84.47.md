# Safe Upgrade — EVazar Core 2.9.84.47

1. Back up the currently installed EVazar Core plugin.
2. Install `EVazar-Core-2.9.84.47-Product-Scoped-Source-Failures.zip` in WordPress.
3. No Worker deployment is required for this Core-only behavior change; keep the current Worker 1.13.25 deployed.
4. A transient source 502/503/timeout/invalid-payload error should put only its current product back into `pending`, with a retry-not-before timestamp and unchanged retry counter.
5. Remaining products should continue. If three transient source failures happen consecutively, only not-yet-visited products in that claimed run are deferred; already prepared Gemini batch items continue.
6. Source 429 and explicit upstream 401/403 access rejection still pause the current claimed run as a safety measure; ambiguous non-access 4xx failures are item-scoped.
7. Check logs for `queue_source_item_deferred` and `queue_source_circuit_open` after a source error.

Local tests do not certify behavior on the live site; verify one small queue run after deployment.
