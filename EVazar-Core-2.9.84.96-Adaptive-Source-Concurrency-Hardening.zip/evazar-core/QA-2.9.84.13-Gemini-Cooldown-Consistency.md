# EVazar Core 2.9.84.13 — Local QA Report

Date: 2026-10-25
Base package: `EVazar-Core-2.9.84.12-Import-Queue-Pause`

## Result

**32/32 targeted behavioral/static assertions passed** using `tests/QA-2.9.84.13-Gemini-Cooldown-Local-Test.php` with WordPress function stubs and the actual `importer.php` source.

Coverage includes:

1. Non-daily 429 jitter is bounded between 1,800 and 3,600 seconds.
2. Header `Retry-After` and body `retryDelay` values longer than the random cooldown are not shortened.
3. `Retry-After` header parsing is case-insensitive.
4. Structured per-day quota is detected separately from per-minute quota.
5. 5xx backoff progresses through the 5–10, 10–20, 20–40, then 30–60 minute stages, independently per Worker.
6. Provider retry hints longer than the backoff are honored.
7. The 5xx streak resets after a definitive non-5xx response.
8. A Worker-specific cooldown does not itself set the global cooldown; another Worker remains eligible.
9. Idempotency-recovery 429 uses the per-Worker cooldown helper and no longer invokes the legacy global setter.
10. Worker code still forwards `Retry-After`, marks confirmed upstream 5xx, and retains retryable 429 responses for status recovery.

## Static validation

- `php -l`: all 9 PHP files in the plugin (including the packaged local test harness) passed.
- `node --check`: bundled `worker/digikala-worker.js` passed JavaScript syntax validation.
- `unzip -t`: final ZIP integrity checked after packaging.
- File comparison against 2.9.84.12 confirms no cache-related source file changed.

These are local checks, not an integration test against the live WordPress database, Gemini API, or Cloudflare environment. The actual runtime behavior of the Durable Object still depends on whether `EVAZAR_GEMINI_IDEMPOTENCY` is bound in the deployed Worker.
