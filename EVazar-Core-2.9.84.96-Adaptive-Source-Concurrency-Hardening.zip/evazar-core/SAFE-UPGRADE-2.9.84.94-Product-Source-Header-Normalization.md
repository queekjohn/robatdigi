# Safe upgrade — EVazar Core 2.9.84.94

1. Back up the database and the currently installed EVazar Core plugin.
2. Replace **EVazar Core only** with this release.
3. Keep the five deployed primary Cloudflare Workers on version **1.13.27**; no Worker deployment or secret change is required.
4. Keep current Worker URLs, Gemini settings, queue settings, and WP-Cron configuration unchanged.
5. Do not manually clear Worker request leases or cooldown transients.
6. After upgrade, monitor a small product batch and review any pre-Gemini source errors. For an upstream source failure, the log should retain `error_scope=source`, `source_server_error`, the exact upstream status, and Worker version. A source failure must not create a Worker cooldown.
7. If a response is a genuine Worker/runtime failure without source provenance, it must continue to use the existing Worker failover behavior.

## Scope

Core-only HTTP-header normalization and product-source failure classification correction. This release does not change Worker code, products, Gemini prompts/models, Theme, cache logic, or taxonomy identity rules.

## Validation boundary

All automated tests and syntax checks are local. This package has not been installed on live evazar.ir and has not been validated against the production cPanel database or live Cloudflare/Digikala requests.
