# EVazar Core 2.9.84.43 — Gemini DKP Context Cap Fix

- Fixes a stale 30-DKP truncation in Gemini request-context preparation; requests configured for 40 or 50 products now retain the full batch.
- Fixes the same stale 30-DKP truncation in operations logs; diagnostics can preserve up to 50 unique product IDs.
- Normalizes and deduplicates DKPs before applying the 50-item cap, so early duplicate/invalid values do not discard later valid IDs.
- Does not change Gemini prompts, model, Worker routing, product queue timing, cache behavior, or the Worker implementation.

## Verification

- Added `tests/gemini-product-batch-context-regression.php`; all 22 assertions passed, covering 2, 30, 40 and 50 DKPs, duplicate/invalid entries, the 50-item cap, and 50-ID logging.
- Local validation passed: 21 PHP files linted; all 9 PHP regression scripts passed (331 checks); both JavaScript regression scripts passed (47 checks).
- This is local/mock verification only; the live WordPress site, Cloudflare Workers, and Google Gemini API were not called.
