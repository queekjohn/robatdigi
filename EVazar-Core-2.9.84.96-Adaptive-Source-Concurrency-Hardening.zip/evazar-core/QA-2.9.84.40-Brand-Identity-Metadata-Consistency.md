# QA — Core 2.9.84.40 Brand Identity / Metadata Consistency

## Scope
- Canonical `_evazar_brand` and `_evazar_brand_en` synchronization from the exact assigned `evazar_brand` term.
- Import and existing-product repair paths.
- Failed taxonomy assignment must not overwrite product display metadata.
- Cache/Worker source files remain unchanged.

## Tests
- `tests/brand-selector-regression.php`: 49 assertions; exact term ID assignment, failed metadata-write detection, metadata restoration, and rollback of the taxonomy assignment.
- `tests/brand-source-regression.php`: 131 assertions; source identity/slug behavior, canonical product metadata read-back, failed-assignment preservation, and rollback after a display-meta failure.
- `tests/brand-source-metadata-repair-regression.php`: 26 assertions.
- `tests/brand-source-registration-regression.php`: 19 assertions.
- `tests/queue-taxonomy-identity-sync-regression.php`: 12 assertions; existing-product repair status handling and no post-sync overwrite of canonical metadata.
- Full Core test directory: all 8 PHP test scripts passed (plus 32 Gemini cooldown assertions, 16 category metadata-repair assertions, and 18 queue-interval assertions).
- All PHP files in Core + Theme passed `php -l`.

These are local PHP regression tests/stubs. They are not a live WordPress database/browser integration test, and they cannot prove the live site's DB writes or actual permalink routing without a staging/live smoke test.
