# EVazar Core 2.9.84.35 — Brand Registration Guard

- Fail closed when the configured primary Worker list is syntactically non-empty but contains no valid HTTPS Worker URL. This prevents the shared Worker dispatcher from falling through to the legacy image-host fallback for this admin-only brand-registration route.
- During the final create confirmation, compare the source API URL and the URL/code confirmation evidence with the preview snapshot. If the evidence changes or weakens, stop and require a fresh preview.
- No changes to product assignment, redirect maps, cache implementation, product index, import queues, pricing/stock, or Gemini logic beyond the previously reviewed 2.9.84.34 source-provenance registration fix.
- Embedded Worker remains version 1.13.23 and must be byte-identical to the standalone Worker 1.13.23 deployment package.

QA note: the registration regression harness adds explicit checks that an invalid-but-non-empty Worker pool fails before dispatch and that confirmation evidence fields are compared to the preview. See `QA-2.9.84.35-Deep-Review.md`.
