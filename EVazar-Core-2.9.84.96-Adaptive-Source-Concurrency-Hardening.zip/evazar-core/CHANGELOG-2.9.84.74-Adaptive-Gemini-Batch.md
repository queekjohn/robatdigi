# EVazar Core 2.9.84.74 — Adaptive Gemini Batch

- Added persistent adaptive batch sizing for confirmed Gemini upstream 5xx failures: 50 → 40 → 30 → 20 → 10 → 5 (respecting lower manual caps).
- Batch recovery is gradual: every ten consecutive clean batch requests increases the effective batch by five, up to the admin-configured cap.
- Adaptive concurrency drops only for multiple failures in a wave or repeated consecutive transient failures; one isolated Worker failure does not automatically throttle healthy peers.
- Concurrent/repeated 429 rate-limit failures can lower concurrency, but do not shrink batch size (which would increase request volume).
- Only explicit upstream HTTP codes with matching structured diagnostic status are classified. Internal endpoint/transport errors, authentication/configuration errors, malformed output, and uncertain request outcomes do not trigger 5xx batch reduction. These errors break the clean-success streak.
- Added a structured `adaptive_batch_adjusted` event with previous/effective batch size and concurrency; added its Persian label to the operations report.
- Queue capacity preview now shows the effective adaptive batch/concurrency separately from the administrator's configured ceiling.
- No changes to Cloudflare Worker code, source-fetch/caching logic, or cache purge code.
