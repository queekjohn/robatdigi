# EVazar Core 2.9.84.12 — Local QA Report

Date: 2026-10-24
Base package: EVazar Core 2.9.84.11 — Brand Source Redirect

## Result
**18/18 local behavioral tests passed.** All PHP files in the plugin passed `php -l`; the package ZIP passed integrity checking.

## Behavioral checks run against the actual `queue-manager.php`
1. Queue is active by default when the pause option is absent.
2. Admin pause action persists `evazar_import_queue_manual_paused=yes`.
3. Pause removes outstanding one-off queue follow-ups.
4. Pause leaves the recurring queue Cron registered as a safety net.
5. Automatic queue worker returns before accessing the DB or claiming products while paused.
6. Manual queue worker also returns before accessing the DB while paused.
7. Follow-up scheduler does not query/schedule queue work while paused.
8. Claim-release helper returns the reported number of still-claimed rows.
9. Claim-release SQL returns matching `processing` rows to `pending` and clears the claim lock.
10. Resume clears the persistent pause state.
11. Resume schedules a prompt follow-up.
12. “Run queue now” admin action is rejected while paused.
13. Signed parallel child endpoint refuses to start a new Gemini batch when the pause flag is active.
14. Parent queue recognizes the child endpoint’s pause response as a pause condition.
15. Dashboard contains the stop button.
16. Dashboard contains the resume button.
17. Non-AJAX POST fallback routes resume correctly.
18. AJAX action dispatcher includes both pause and resume actions.

The dashboard button markup, AJAX action routing and non-AJAX POST fallback were checked both through local static assertions and the behavioral harness. The existing AJAX handler performs the action under the established nonce and `manage_options` capability check.

## Scope verification
Compared with the 2.9.84.11 base archive, the code changes are limited to:
- `evazar-core/queue-manager.php`
- plugin header version in `evazar-core/evazar-core.php`
- this release's changelog and QA note

No cache-related file was modified. No production site, live database, or live Worker request was used for these tests; the behavioral harness provides local WordPress-function stubs and includes the actual queue manager source. Therefore this confirms local logic, not the final runtime behavior on the production host.
