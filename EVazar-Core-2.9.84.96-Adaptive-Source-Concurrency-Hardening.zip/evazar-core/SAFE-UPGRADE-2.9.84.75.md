# Safe upgrade — EVazar Core 2.9.84.75

1. Back up the current `evazar-core/` plugin folder and the WordPress database.
2. Replace the existing `evazar-core/` plugin folder with the folder in this ZIP; keep the folder name unchanged.
3. No database schema migration is required. A non-autoloaded WordPress option stores adaptive batch state; its short-lived lock is protected with an owner token.
4. Do not redeploy Cloudflare Workers for this release; Worker source is unchanged.
5. The configured Gemini batch size remains the administrator's maximum. Following a confirmed upstream Gemini 5xx, unsent chunks are immediately repartitioned to the smaller effective batch in the same queue run. Already-dispatched chunks are never re-sent. The effective size recovers gradually after successful requests.
6. Check the operations log for `تنظیم تطبیقی ظرفیت Gemini` to inspect reductions, recovery, and repartitioning of unsent work. Internal endpoint errors and uncertain outcomes do not trigger upstream-5xx adaptation.
7. Local syntax, regression, and package-integrity tests are included. Live Gemini requests, production queue behavior, and hosting/database contention were not exercised here.
