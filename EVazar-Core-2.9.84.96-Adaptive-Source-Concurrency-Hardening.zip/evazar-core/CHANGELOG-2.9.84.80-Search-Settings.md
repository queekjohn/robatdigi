# EVazar Core 2.9.84.80 — Search Settings

- Added a dedicated `تنظیمات جستجو` admin submenu with live index readiness/progress counts, errors, last/next run, and a safe one-batch repair action.
- Added validated settings for indexed-search acceleration, minimum query length, live-search debounce, visible product card count, and search-index batch size.
- Index batches are configurable independently from the existing fixed 250-row stock/facet index batch.
- No destructive table rebuild, cache purge, importer/Worker change, or change to archive filters.
