# EVazar Core 2.9.84.59 — Gemini Report UI Refresh

- Replaces the 12-column horizontally scrollable Gemini operations table with responsive, compact event cards.
- Shows a concise status, event type, timestamp, target, short message, and useful metadata in the main view.
- Moves full diagnostics into an expandable details section, including request IDs, DKP values, HTTP/upstream statuses, Worker versions, queue counters, and per-wave summaries where available.
- Adds responsive grid layout and aggressive safe wrapping for long Worker hosts and diagnostics so the report does not require horizontal scrolling.
- Makes the Worker status table fixed-layout and wraps host names.
- Improves the recent event list on the settings page to wrap long messages without horizontal overflow.
- No queue, Worker, Gemini dispatch, or cache processing behavior changed.
