# Core 2.9.84.14 — Worker recovery diagnostics

- Bundles Worker 1.13.13.3: existing brand-source path handoff plus classified uncertain Gemini outcome diagnostics.
- Core importer cooldown behavior from 2.9.84.13 retained.
- Cache-related Core files unchanged; Worker cache/batch behavior preserved from 1.13.13.2.
