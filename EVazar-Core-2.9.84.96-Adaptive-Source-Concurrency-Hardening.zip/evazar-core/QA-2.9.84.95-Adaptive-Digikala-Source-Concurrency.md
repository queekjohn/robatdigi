# QA — EVazar Core 2.9.84.95

## Behavior verified
- Five configured primary Workers start at concurrency 2.
- Three consecutive fully successful source waves promote 2→3, then 3→4, then 4→5.
- A confirmed Digikala source 5xx/429 signal drops the cap by one immediately and clears the success streak.
- Worker/runtime errors and product-level 404s are neutral to this controller.
- The adaptive controller uses a persistent option and is separate from Gemini adaptive batching.
- Queue diagnostics report current concurrency and the 3-wave promotion progress.
- Existing Worker cooldown, failover, product-scoped errors, source cache, and queue-tail handling remain covered by regression tests.

## Test results
- `tests/product-source-parallel-fetch-regression.php`: 100 assertions passed.
- All 28 PHP regression/smoke tests in `tests/*.php`: passed.
- PHP syntax checks: passed for modified PHP files.

## Deployment scope
- Core only. Cloudflare Worker 1.13.27 remains unchanged.
- Not deployed to the live site by this package build.
