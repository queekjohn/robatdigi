# QA — EVazar Core 2.9.84.91 Worker Lease Timeout Safety

## Change under test

The shared primary Digikala Worker lease is now retained when the client-side outcome is uncertain. Serial dispatch releases only after a valid HTTP response with a positive status. Parallel dispatch releases each per-Worker lease only when that item's response has a positive HTTP status. A thrown multi-transport exception or missing/unreadable response retains the affected leases. The minimum stale lease window is 180 seconds, extended by the configured request timeout (`max(180, timeout + 150)`).

## Regression coverage

- Serial timeout returns `WP_Error` while preserving the exact Worker lease.
- A subsequent dispatcher sees the retained lease as busy and sends no second request to that Worker.
- A real HTTP response releases the serial lease; the same applies to HTTP error responses in parallel mode.
- The stale lease is not reclaimed before the conservative timeout window and is reclaimable after expiry.
- A thrown parallel transport exception retains all uncertain leases; a subsequent wave does not reuse those Workers.
- Partial parallel results release only Workers with a positive HTTP status; a missing result retains only its own lease.
- Existing exact-token release behavior prevents an old owner from deleting a replacement lease.

## Automated validation results

- PHP regression scripts: 28 executed, 0 failures.
- JavaScript regression scripts: 4 executed, 0 failures.
- PHP syntax: 41 PHP files checked, 0 syntax errors.
- `node --check worker/digikala-worker.js`: passed.
- ZIP integrity: checked after package creation.
- 748 assertions were explicitly counted by the 23 PHP test scripts that emit machine-readable assertion totals; the remaining five PHP scripts also exited successfully.
- Focused serial Worker lease regression: 21 assertions passed.
- Focused parallel product-source regression: 83 assertions passed.
- Taxonomy queue isolation regression: 34 assertions passed.

## Worker parity

The embedded `worker/digikala-worker.js` remains byte-identical to the supplied standalone Cloudflare Worker 1.13.27 file. SHA-256:

`0fc82e8cdd7886739c4560ae81d2f4fb1affaf6f8a6adf39386cf1e668909074`

No Cloudflare Worker deployment is required for this Core-only correction.

## Validation boundary

All tests ran locally with PHP CLI and Node.js. This package was not installed on the live evazar.ir server and was not tested against the live cPanel HTTP stack, live WordPress database, Cloudflare network, or Gemini endpoints. Production behavior should be observed after installation through normal queue logs; do not manually clear the temporary Worker lease options.
