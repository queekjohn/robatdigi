# QA — EVazar Core 2.9.84.87 Brand Repair Two-Sample Guard

## Change
The live source-metadata repair previously requested a second product sample only when the public term slug differed from the first source slug. That left same-slug homonyms under-verified. It now requires two distinct attached published products for every repair candidate and compares explicit source ID, source code, source URL/path, source slug, and Persian brand name.

## Regression coverage
- Matching public/source slug with only one sample is blocked (`NEEDS_SECOND_SAMPLE`).
- Matching public/source slug with two agreeing samples becomes `READY` and records both samples.
- Carrera-style same-name/same-public-slug terms whose attached products resolve to `/brand/carrera/` and `/brand/carrera-brand/` are blocked as `SAMPLE_DISAGREEMENT`; no reusable approval transient is created.
- Existing different-slug conflicts, name mismatch, source-ID ownership conflicts, stale-plan checks, live re-checks, write-failure checks, and metadata-only invariants remain covered.

## Validation on the final ZIP after extraction
- PHP regression scripts: 26/26 passed.
- JavaScript regression scripts: 4/4 passed.
- PHP syntax: all 39 PHP files passed.
- JavaScript syntax: all 7 JavaScript files passed `node --check`.
- Brand source metadata repair regression: 28/28 checks passed.
- ZIP integrity: passed; top-level directory is `evazar-core/`; plugin header is version 2.9.84.87.
- `cache-purge.php`, `importer.php`, `queue-manager.php`, `product-index.php`, `taxonomy-seo-queue.php`, and `worker/digikala-worker.js` are byte-identical to Core 2.9.84.86.

## Scope
Runtime changes are limited to the plugin version header and `brand-source-metadata-repair.php`. Tests and release notes were updated. No cache, product import, queue logic, Worker source, public brand slugs, product assignments, or redirects were changed.

## Production boundary
Tests use local WordPress stubs and mocked Worker responses. This ZIP has not been installed against the live EVazar database; live Carrera repair must still be analyzed in the admin screen before any metadata write is applied.
