# EVazar Core 2.9.84.38

## Brand assignment reliability
- Fixed Quick Edit's cloned hidden template lifecycle: the original hidden `#inlineedit` selector is no longer initialized with native DOM handlers before WordPress clones it. The visible clone is initialized by the existing mutation observer.
- Added one shared term-ID assignment routine with capability checks, duplicate/invalid-ID filtering, read-before-write, and read-after-write verification.
- Classic product edit and Quick Edit selections are reconciled at late shutdown after WordPress finishes its regular save path. Quick Edit remains additive; full edit remains explicit replacement.
- Added a `rest_after_insert_evazar_product` reconciliation path for Gutenberg's REST saves.
- Loaded the selector module on REST requests too; only the late form-post reconciler is registered for admin requests, while the REST reconciliation hook remains available to the REST controller.
- Preserved bulk edit's replacement semantics and no-selection no-op.
- Bumped admin CSS/JavaScript cache-busting versions to 2.9.84.38.

## Randomized import timing review
- No production code in `queue-manager.php` changed in this release. The 5–10 minute default, configurable 1–60 minute bounds, completion-to-next-run timestamp, lock, retry gating and Cron migration remain unchanged.
- Added a regression proving automatic calls before `evazar_queue_next_auto_run_at` do not acquire the run lock and schedule only the not-before follow-up.

## Scope exclusions
No changes to `cache-purge.php`, `product-index.php`, `importer.php`, `queue-manager.php`, the embedded/standalone Worker, pricing/stock sync, or brand source registration logic.
