# EVazar Core 2.9.84.95 — Adaptive Digikala Source Concurrency

- Added a persistent adaptive controller for parallel product-source fetches through the configured Cloudflare Workers.
- Starts at 2 concurrent products, then increases to 3, 4, and 5 after three consecutive clean source-fetch waves at each level.
- A confirmed Digikala-origin `source_server_error`, `source_rate_limited`, `source_fetch_failed`, or upstream HTTP 429/5xx immediately lowers concurrency by one level and resets the success streak.
- Worker/runtime failures, transport failures, product 404s, malformed payloads, and Gemini outcomes do not count as Digikala overload signals.
- The adaptive state is persisted in `evazar_source_fetch_adaptive_state` and is independent of Gemini adaptive batching and Worker cooldown/failover behavior.
- Added current concurrency and promotion progress to queue diagnostics and the source-wave summary.
- Cloudflare Worker 1.13.27 is unchanged. No direct Digikala fallback was added.
