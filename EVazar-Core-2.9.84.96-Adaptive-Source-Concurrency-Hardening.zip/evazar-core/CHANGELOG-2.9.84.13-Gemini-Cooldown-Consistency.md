# EVazar Core 2.9.84.13 — Gemini Cooldown Consistency

Base: `EVazar-Core-2.9.84.12-Import-Queue-Pause`

## Changes

- Unified normal-send and idempotency-recovery handling for non-daily Gemini HTTP 429 responses. Both paths now cool down only the Worker that returned the error; recovery no longer writes the legacy global rate-limit cooldown.
- Added randomized 30–60 minute cooldowns for non-daily/ambiguous 429 responses. A valid provider `Retry-After` or `retryDelay` that is longer than the jitter is always honored.
- Kept structured daily-quota detection separate; a confirmed daily quota still cools the Worker until Google's next quota reset.
- Added per-Worker randomized exponential backoff for HTTP 5xx: 5–10 minutes on the first occurrence, 10–20 minutes on the second, 20–40 minutes on the third, and 30–60 minutes on subsequent occurrences. Longer provider retry hints take precedence.
- Reset the 5xx streak after a definitive sub-500 HTTP response.
- For an unmarked 5xx, cool down that Worker but do not fail over the same request because the upstream outcome may be uncertain. Confirmed upstream 5xx responses can rotate to another eligible Worker.
- Kept 400/401/403/404 responses terminal instead of blindly retrying them.

## Scope

Changed runtime files: `importer.php` and the plugin header version in `evazar-core.php`.

The bundled Worker remains `1.13.13.2`. It was reviewed but not modified: it already forwards `Retry-After`, marks confirmed upstream 5xx responses with `X-Evazar-Gemini-Outcome: retryable`, and stores retryable 429/5xx responses when the Durable Object binding is configured.

No cache-related file was changed. No production site, live database, Gemini request, or Cloudflare Worker deployment was used during local development or QA.
