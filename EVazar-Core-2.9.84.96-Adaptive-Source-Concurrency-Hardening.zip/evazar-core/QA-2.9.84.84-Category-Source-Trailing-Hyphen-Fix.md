# QA — EVazar Core 2.9.84.84 / Worker 1.13.27

## Findings addressed

1. The live response for DKP `22055693` provides the exact breadcrumb route `/search/category-men-sport-shoes-/`. Core 2.9.84.82 rejected this route and stopped import before Gemini or product writes.
2. Core 2.9.84.83 allowed the route in its source-path normalizer, but the embedded Worker 1.13.26 still rejected the same path in `validateDigikalaSourcePagePath()`. That could block the exact-page HTML fallback used by taxonomy SEO source fetching.
3. Core 2.9.84.84 retains the Core path fix and embeds Worker 1.13.27, whose source-page validator now accepts one explicit terminal hyphen and matches Core's segment grammar more closely.

## Validation performed on the packaged source

- All 29 regression scripts passed with 0 failures.
- Core/brand/category regression includes a full four-breadcrumb sync for DKP `22055693`: all four terms assigned, final source URL preserved exactly, source verification marker set, and parent hierarchy preserved.
- Worker integration test requests `source_page=/search/category-men-sport-shoes-/` and confirms the mock upstream HTML is reached and the response is not rejected as HTTP 400.
- Worker validator rejects duplicate trailing hyphens, repeated separators, product paths, encoded slashes, traversal paths, and unsupported routes.
- PHP syntax: 38/38 files passed `php -l`.
- JavaScript syntax: 7/7 files passed `node --check`.
- Core ZIP and standalone Worker ZIP integrity checked after packaging.
- Embedded Core Worker and standalone Worker source compared byte-for-byte.
- Core `cache-purge.php` is byte-identical to the 2.9.84.83 baseline.

## Scope

Production changes are limited to the Core version header, `importer.php` source-path validator (carried forward from 2.9.84.83), and `worker/digikala-worker.js` version/path validator. Test fixtures and release notes were updated. Cache, queue, Gemini runtime, pricing, and stock code are unchanged.

## Boundaries

All tests are local regression tests with mocked WordPress/network dependencies. They do not prove the live Cloudflare deployment, live upstream HTML response, live WordPress database writes, or successful Gemini generation. Deploy Worker 1.13.27 separately before production validation; the Core plugin ZIP does not publish a Worker to Cloudflare.
