# EVazar Core 2.9.84.27 — Brand and Category Source Metadata Integrity

## Product-import behavior
- Brand identity is accepted as verified only when the Worker returns an explicit Digikala brand URL, source ID and source code. A guessed path based only on Persian/English labels is never promoted to verified source identity.
- For existing brand terms, a matching English-derived legacy slug/name is not sufficient to migrate a term to a different source slug. A stored matching Digikala source ID or an already verified exact source URL is required. If neither exists, Core leaves the ambiguous manual term alone and resolves/creates the source-slug term only when safe.
- Before updating any brand identity metadata, Core resets and reads back `_evazar_dk_source_verified=0`. ID, code, slug, URL and map version are then written and read back; the marker is set to `1` only as the final successful write.
- Category resolution uses the exact Digikala breadcrumb URL before name fallback. A same-name category with a different recorded source path is not silently reused.
- Real category breadcrumb metadata writes are read back before `_evazar_dk_source_verified=1`; generated category+brand landings use `_evazar_dk_generated_url` and are not treated as verified Digikala breadcrumb identity.
- A product whose category path or category relationship cannot be verified does not finalize as a successful import. Core returns a `WP_Error`, logs the failure and lets the existing import queue retry it as pending/backoff.

## Legacy brand metadata repair
- Adds **Products → ترمیم متادیتای برندها** for administrator-only review of brands with missing or untrusted source metadata.
- The tool treats older/unrecognized source map versions as untrusted even when their old verification marker is `1`; legacy paths potentially guessed by older Core versions are rechecked against live product data.
- Uses the configured authenticated Core-to-Worker pool with `fresh=1`; requires live source ID, code, Persian name and explicit brand URL.
- If public slug equals the live source slug, one currently attached published product can support the review. If the slugs differ, two independent attached products must agree on ID, code, URL, slug and Persian identity.
- At APPLY time, Core re-fetches every sample again and compares the live identity with the approved preview. A changed or unavailable source, changed term/sample relationship, source ID/URL/slug collision, name mismatch or failed read-back prevents the metadata write from being reported as successful.
- The repair writes source metadata only. It never changes public term name/slug, product assignments, 301 mappings, schema, cache or Worker code. The verification marker is written last.

## Worker contract
- The bundled Worker remains **1.13.18**, byte-identical to the standalone Worker 1.13.18 release.
- It already emits `brand_source_path`, `brand_source_id` and `brand_source_code` only from the explicit upstream `p.brand.url`, `p.brand.id` and `p.brand.code` fields. No guessed brand path was introduced by this release.

## Local validation
- Brand/source importer regression: 104 passed, 0 failed.
- Legacy brand metadata repair regression: 18 passed, 0 failed.
- Brand selector regression: 24 passed, 0 failed.
- Worker/source JavaScript regression: 23 passed, 0 failed.
- Gemini cooldown/recovery suite: 32 assertions passed.
- PHP syntax: all 14 PHP files passed `php -l`.
- `node --check`: bundled Worker and inline repair admin JavaScript passed.
- ZIP integrity and production-file diff checked. `cache-purge.php`, `queue-manager.php`, `product-index.php` and the bundled Worker are byte-identical to Core 2.9.84.26.

## Limits
- Tests use local WordPress stubs and mocked Worker responses. No live EVazar database, cPanel or Cloudflare Worker was changed or called in this build session.
- The backfill tool must be run against the live site with the Core import queue manually paused and zero products in `processing`. Only rows marked “آماده ثبت امن” should be applied; conflicts/no-sample/source errors require manual review.
