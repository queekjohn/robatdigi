# QA — EVazar Core 2.9.84.46 / Worker 1.13.25

## Source/Worker coverage
- Worker 429 test verifies source scope, retry guidance, v2 status preservation, and no v1 fallback request.
- Worker 403, timeout, and 5xx cases verify that a second upstream API request is not made.
- v2 404 still tries v1 once; both APIs returning 404 remain a product-specific 404.
- Malformed upstream JSON remains a source-scoped error.
- Core test verifies source-scoped 429 does not trigger Worker cooldown/failover, and records `source_rate_limited`, v2/v1 status, Worker version, and Retry-After.
- Queue policy tests verify 429/network failures defer claimed rows without increasing retry counts; product-specific 404, Worker transport failures, and Gemini errors do not enter the source-backoff path.

## Scope
Local tests use mocked HTTP and WordPress stubs. No live Cloudflare deployment, Digikala request, or Gemini API call was performed. Cache logic and settings were not changed.
