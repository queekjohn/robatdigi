# EVazar Core 2.9.84.66

- Polished import-log action buttons with inline SVG icons so icon rendering does not depend on Dashicons.
- Kept icons visible during refresh/clear loading states.
- Added a top-of-section log count synchronized after AJAX refresh/clear, matching the count shown below the table.
- Updated section heading to 200 recent import events.
