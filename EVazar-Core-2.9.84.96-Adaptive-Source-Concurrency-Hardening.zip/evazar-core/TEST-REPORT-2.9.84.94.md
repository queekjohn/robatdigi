# EVazar Core 2.9.84.94 — Product Source Header Normalization

## Summary

This release fixes product-source diagnostics when WordPress Requests returns response header values as arrays, especially through `Requests::request_multiple()`.

The observed production event for DKP `22027358` reported:
- Worker HTTP status: `503`
- Upstream Digikala v2 status: `502`
- Upstream v1: not attempted
- Worker JSON error: `source_server_error`
- Incorrect diagnostic output: Worker version rendered as `Array`; source scope was lost.

Core now normalizes scalar, array, nested-array, and Requests header-object values before classification or logging. It uses the explicit `X-Evazar-Error-Scope` header when available. If that header is missing or malformed, it narrowly infers a source failure only from an HTTP error plus the documented Worker JSON shape (`success=false`, `error` prefixed `source_`, Worker version, and upstream v1/v2 status or error diagnostics).

## Correct expected handling for the reported case

For Worker HTTP `503` + `source_server_error` + upstream v2 `502`:
- preserve Worker version as `1.13.27`;
- preserve `error_scope=source` and source error code;
- preserve Worker HTTP `503` separately from upstream HTTP `502`;
- do not label it `worker_http_503`;
- do not put the responding Worker into Worker cooldown;
- do not retry the same failed source request on another Worker;
- defer only the affected product for the normal 60-second source retry interval, without incrementing the retry counter;
- continue processing other products, subject to the existing three-consecutive-source-failure circuit breaker.

A genuine Worker/runtime error without source provenance still follows the existing failover and cooldown path. Product-specific 404 and source 429 semantics are unchanged.

## Files changed

Runtime changes are limited to:
- `importer.php`
- `queue-manager.php`
- `evazar-core.php` (version only)

Regression tests and release notes were updated. The embedded Worker file is unchanged.

## Test results

- PHP regression scripts: **28 passed, 0 failed**
- JavaScript regression scripts: **4 passed, 0 failed**
- PHP syntax checks: **41 files passed**
- JavaScript syntax checks (`node --check`): **7 files passed**
- Focused serial Worker diagnostics: **50 assertions passed**
- Focused parallel product-source diagnostics: **91 assertions passed**
- Queue retry-policy regression: **48 assertions passed**
- Pre-Gemini error event regression: **20 assertions passed**

Additional checks:
- ZIP integrity validated after packaging.
- Final ZIP re-extracted to a clean directory and focused tests/syntax checks rerun.
- Embedded Worker SHA-256 is unchanged and matches the standalone Worker 1.13.27 file:
  `0fc82e8cdd7886739c4560ae81d2f4fb1affaf6f8a6adf39386cf1e668909074`

## Validation boundary

Local PHP runtime: **8.4.24**. Tests use WordPress/Requests stubs and synthetic HTTP responses. They validate Core's header parsing, error classification, queue policy, diagnostics, and regression behavior; they do not prove the availability of the Digikala upstream API or the production Cloudflare network. Production server PHP is known to be 8.3, so live cPanel/database/Cloudflare/Digikala validation remains necessary after installation.

## Upgrade notes

Install Core **2.9.84.94** only after taking a database and plugin backup. Keep all five deployed primary Workers at **1.13.27**. No Worker redeployment, token changes, queue setting changes, Gemini changes, Theme changes, cache changes, or Cron changes are required.
