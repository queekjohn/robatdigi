# QA — EVazar Core 2.9.84.16 / Worker 1.13.18

## Scope
- Raise automatic Gemini product batch size from 15 to 30 end-to-end.
- Keep taxonomy SEO batch ceiling at 5, outer queue-run cap at 75, and Worker concurrency setting cap at 5.
- Keep the source-URL-based brand slug logic and 301 redirect mapping from Core 2.9.84.15 / Worker 1.13.17.
- No cache code, purge logic, cache settings, price/stock updater, or Theme files changed.

## Local validation results
- PHP syntax: **9/9 plugin PHP files passed** `php -l`.
- Worker regression: **23 passed, 0 failed**. Includes acceptance of a 30-item product batch, rejection of 31 before upstream call, and taxonomy SEO maximum 5.
- Core brand + batch regression: **61 passed, 0 failed**. Includes brand-source/slug behavior, conflict handling, migration to 30, and exhaustive queue partition combinations for queue lengths 2–150 and batch sizes 2–30, with no item loss/duplication and no invalid chunk sizes.
- Gemini cooldown regression: **32 assertions passed**.
- JavaScript syntax checks passed for the standalone Worker, Worker embedded in Core, and Worker regression test.
- Standalone Worker and embedded Worker are byte-identical.
- `cache-purge.php` is byte-identical to the baseline package.
- ZIP integrity checks passed for the Core and Worker archives.
- Runtime file diff is limited to `evazar-core.php`, `importer.php`, `queue-manager.php`, and `worker/digikala-worker.js`; the other modified or added files are regression tests and release/QA documentation.

## Operational behavior
- A queue run remains capped at 75 products. With batch size 30, a 75-item run partitions into 30 + 30 + 15, subject to eligible Workers, cURL-multi support, and PHP runtime.
- When parallel transport is unavailable or PHP runtime cannot be extended sufficiently, the run is capped at one batch of up to 30.
- The one-time Core migration sets `evazar_ai_product_batch_size` to 30; the administrator may subsequently lower it to 15 or another supported size (2–30).
- Taxonomy SEO batching remains 2–5 items; the default Gemini timeout is unchanged.

## Production limitation
No live Gemini request was sent during local QA. After deploying Worker 1.13.18 to every configured Worker and then Core 2.9.84.16, run one controlled 30-product batch and check latency, output completeness, and `batch_partial_output_invalid`, `batch_output_invalid`, timeout, and retry events. If these rise materially, lower the batch size to 15 in settings.
