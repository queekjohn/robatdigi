# EVazar Core 2.9.84.78 — Search Index Fail-Closed Fix

- A failure in the canonical product/facet index now moves the live-search index state to `building` immediately.
- This prevents the indexed fast path from using stale brand/stock/DKP/SKU data after a failed Core index sync.
- Existing scheduled backfill can repair the affected product and only return search to `ready` after completeness checks pass.
- No Worker or cache-purge code changed.
