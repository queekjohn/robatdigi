# Safe upgrade — EVazar Core 2.9.84.80 + Theme 1.13.30

1. Take the usual backup before installing updates.
2. Install Core 2.9.84.80 first, then Theme 1.13.30.
3. In WordPress admin open Products (`کالاهای ایوازار`) → `تنظیمات جستجو`.
4. Check index state, indexed/remaining counts, sync errors, last background run and next scheduled run.
5. Keep defaults initially: indexed search enabled, minimum 2 characters, 250 ms debounce, 5 live product cards, and 250 search-index rows per batch.
6. Use `بررسی و ترمیم ایندکس (یک نوبت)` only if the status indicates a mismatch or stuck building state. It does not delete or truncate the index tables; cron continues the background pass.
7. If index counts do not converge, errors stay nonzero, or results differ, disable `استفاده از ایندکس اختصاصی جستجو` to fall back to the legacy WP_Query path while diagnosing.

No Worker deployment, cache purge, or archive-filter change is required. The live database and production response time still need verification after installation.
