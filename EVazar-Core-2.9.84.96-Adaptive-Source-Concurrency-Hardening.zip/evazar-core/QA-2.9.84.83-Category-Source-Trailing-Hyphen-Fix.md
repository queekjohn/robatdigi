# QA — EVazar Core 2.9.84.83

## Finding
The live Worker response for DKP 22055693 includes `/search/category-men-sport-shoes-/`. Core 2.9.84.82's strict source-path regex rejected the final hyphen, normalized the valid explicit path to an empty string, and quarantined the item.

## Fix
Allow one terminal hyphen in each public Digikala source-path segment. This does not synthesize/guess a URL and retains the route, traversal, hostname and path validation checks.

## Required regression coverage
- The exact Digikala route `/search/category-men-sport-shoes-/` normalizes without changing source identity.
- The full four-breadcrumb Worker response from DKP 22055693 passes Core source preflight and preserves the final URL.
- Title-only breadcrumbs remain blocked by the source-preflight regression suite.

## Scope
- Runtime production changes: `importer.php` and version header `evazar-core.php` only.
- Worker, `cache-purge.php`, Gemini flow, queue logic and product writes are otherwise unchanged.
- Test suites are local regression checks; after install, validate by retrying just DKP 22055693 through single-product import.
