# EVazar Core 2.9.84.84 — Category Source Trailing-Hyphen Fix

- Keeps the Core 2.9.84.83 fix that accepts Digikala category source paths ending in one explicit hyphen, including `/search/category-men-sport-shoes-/`.
- Updates the embedded Worker to 1.13.27 so its exact `source_page` proxy accepts the same valid route grammar; Worker 1.13.26 otherwise rejected that route before fetching the source HTML.
- Keeps the source-page allowlist (`search`, `brand`, `brand-landing`, `main`), path traversal checks, encoded slash/backslash rejection, and strict segment grammar. Multiple trailing hyphens and repeated separators remain invalid.
- Does not derive or guess source URLs from category titles.
- No changes to cache-purge logic/configuration, Gemini prompts/model/settings, queue scheduling/claim logic, price/stock processing, or product-save logic.
- Cloudflare Worker deployment remains separate from WordPress Core installation.
