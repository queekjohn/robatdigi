# EVazar Core 2.9.84.33 / Cloudflare Worker 1.13.22 — QA
Date: 2026-10-25

## Added
- Permanent Core admin tool: **Tools → ثبت برند از لینک دیجی‌کالا**.
- The administrator submits a brand URL and sees a source-identity preview before saving.
- A separate confirmation re-fetches the identity from Worker and rejects any changes between preview and creation.
- Creates a new `evazar_brand` term and writes/read-backs source ID, code, source URL, source slug, English name, provenance, and verification marker.
- Stops on an existing source ID, existing source URL, occupied public slug, or redirect-reserved slug.
- No product assignment or edits to existing terms, redirects, product cache, or cache-purge logic.
- Core has no direct Digikala request fallback in this tool. Requests go from the WordPress server through `evazar_primary_worker_request()` and the configured authenticated primary Worker pool.
- Added authenticated, no-store Worker route `POST /brand-source/inspect`, which calls only the fixed Digikala `/v1/brands/{slug}/search/` endpoint and returns explicit API identity fields. If the API URL explicitly conflicts with the submitted URL, it rejects even when the codes match.

## Local verification
- Worker brand/source regression: 41 passed, 0 failed.
- Worker authenticated brand-audit regression: 6 passed, 0 failed.
- Core brand-source regression: 120 passed, 0 failed.
- Brand metadata repair regression: 26 passed, 0 failed.
- Category metadata repair regression: 16 passed, 0 failed.
- Queue taxonomy identity sync regression: 9 passed, 0 failed.
- Brand selector regression: 24 passed, 0 failed.
- Gemini cooldown/recovery regression: 32 assertions passed.
- PHP syntax checks and JavaScript syntax checks passed.
- Core-embedded and standalone Worker JS are byte-identical; ZIP integrity checks passed.
- `cache-purge.php`, `product-index.php`, and `queue-manager.php` were preserved byte-for-byte from Core 2.9.84.32.

## Limits
The source/API behavior tests use mocked network responses. No live WordPress database or Cloudflare account was accessed during packaging, so the real API response for a given brand URL must be confirmed by the preview after deploying Worker 1.13.22 to every configured primary Worker.
