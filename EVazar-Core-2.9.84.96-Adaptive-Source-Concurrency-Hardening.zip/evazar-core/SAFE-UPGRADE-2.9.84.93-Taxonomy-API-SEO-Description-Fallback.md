# Safe upgrade — EVazar Core 2.9.84.93

1. Back up the database and the currently installed EVazar Core plugin.
2. Replace **EVazar Core only** with this release.
3. Keep all five deployed Cloudflare Workers on version **1.13.27**; no Worker deployment or secret change is required.
4. Keep current queue, Gemini, Worker URL, and WP-Cron settings unchanged.
5. Do not manually clear Worker request leases or cooldown transients.
6. After upgrade, retry the affected category/brand SEO item. Its exact category+brand discovery API response should provide page SEO description plus brand description and avoid the public `/search/` HTML fallback when those fields are present.
7. Confirm the generated content uses the exact requested category and brand. A mismatching or incomplete API identity must still be rejected.

## Scope

Core-only taxonomy source extraction correction. It does not change Worker code, products, Gemini prompts/models, Theme, cache logic, or taxonomy identity rules.

## Validation boundary

All automated tests and syntax checks are local. This package has not been installed on live evazar.ir and has not been validated against the production cPanel database or a live Cloudflare/Digikala request.
