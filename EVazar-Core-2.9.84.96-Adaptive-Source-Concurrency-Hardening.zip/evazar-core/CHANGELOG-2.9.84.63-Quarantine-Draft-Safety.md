# EVazar Core 2.9.84.63 — Quarantine Draft Safety

- Prevents the manual Draft action from appearing or executing for new category-path preflight failures that did not write product data.
- Preserves Draft action only for legacy post-save category-sync failures explicitly recorded as `اطلاعات کالا ذخیره شد، اما همگام‌سازی/تأیید دسته‌بندی ناموفق بود`.
- Labels an existing product linked by DKP lookup as a related product when this attempt did not save/update it.
- Requires the quarantine audit note update to affect exactly one row before reporting action success.
- No changes to source preflight, queue execution, Worker, or cache logic.
