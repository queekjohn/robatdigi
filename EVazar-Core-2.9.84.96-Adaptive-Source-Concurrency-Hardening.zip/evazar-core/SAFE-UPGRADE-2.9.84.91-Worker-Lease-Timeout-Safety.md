# Safe upgrade — EVazar Core 2.9.84.91

1. Take a fresh database backup and a copy of the currently installed EVazar Core plugin.
2. Install/replace **EVazar Core only** with this release. Do not update the Theme or Cloudflare Worker.
3. Keep all five deployed primary Cloudflare Workers on the existing version 1.13.27. The embedded Worker file is unchanged.
4. Keep the existing WP-Cron/cPanel schedule and all Worker/Gemini settings. No database migration, new token, URL, or manual queue reset is required.
5. After installation, inspect product import logs for temporary Worker-pool deferrals and allow normal retries. A Worker with an uncertain timeout may remain unavailable for up to 180 seconds (or longer when the configured HTTP timeout requires it).
6. Do not manually delete `evz_primary_worker_inflight_*` options during normal operation. They are token-owned safety leases and expire automatically after the conservative stale window.

## Scope guarantee

This update changes only primary Worker lease release behavior after uncertain transport outcomes and the stale lease window. It does not change product content generation, Gemini prompts/models, category/brand identity mapping, public URLs, theme, or cache logic.

## Validation boundary

Local automated regression tests and syntax checks are run for this package. It has not been installed or exercised against the live evazar.ir database, cPanel HTTP stack, deployed Cloudflare Workers, or live Gemini endpoints as part of this build.
