(function () {
  'use strict';
  const cfg = window.EvazarBrandSelector || {};
  const labels = cfg.labels || {};

  function escapeText(value) {
    return String(value == null ? '' : value);
  }

  function requestTerms(params) {
    const search = new URLSearchParams(Object.assign({
      action: 'evazar_brand_selector_search',
      nonce: cfg.nonce || ''
    }, params || {}));
    return fetch((cfg.ajaxUrl || window.ajaxurl || '') + '?' + search.toString(), {
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    }).then(function (response) {
      if (!response.ok) throw new Error('http_' + response.status);
      return response.json();
    }).then(function (payload) {
      if (!payload || !payload.success || !Array.isArray(payload.data)) throw new Error('invalid_response');
      return payload.data;
    });
  }

  function buildSelectedItem(term, inputName) {
    const item = document.createElement('div');
    item.className = 'evazar-brand-picker-selected-item';
    item.setAttribute('data-term-id', String(term.id));

    const label = document.createElement('span');
    label.className = 'evazar-brand-picker-selected-label';
    const strong = document.createElement('strong');
    strong.textContent = escapeText(term.name);
    const small = document.createElement('small');
    small.textContent = (labels.slug || 'نامک: ') + escapeText(term.slug) + ' · ' + (labels.id || 'شناسه: ') + String(term.id);
    label.appendChild(strong);
    label.appendChild(small);

    const remove = document.createElement('button');
    remove.type = 'button';
    remove.className = 'button-link evazar-brand-picker-remove';
    remove.setAttribute('aria-label', 'حذف انتخاب ' + escapeText(term.name));
    remove.textContent = '×';

    const hidden = document.createElement('input');
    hidden.type = 'hidden';
    hidden.name = inputName;
    hidden.value = String(term.id);

    item.appendChild(label);
    item.appendChild(remove);
    item.appendChild(hidden);
    return item;
  }

  function hasTerm(selectedContainer, id) {
    return !!selectedContainer.querySelector('.evazar-brand-picker-selected-item[data-term-id="' + String(id).replace(/[^0-9]/g, '') + '"]');
  }

  function initPicker(picker) {
    if (!picker || picker.dataset.evaInitialized === '1') return;
    // Do not attach native addEventListener handlers to WordPress' hidden template:
    // WP clones this row for Quick Edit, and native listeners are not copied by jQuery clone().
    // The cloned row is outside #inlineedit; MutationObserver initializes that live instance.
    if (picker.closest && picker.closest('#inlineedit')) return;
    const input = picker.querySelector('.evazar-brand-picker-search');
    const results = picker.querySelector('.evazar-brand-picker-results');
    const selected = picker.querySelector('.evazar-brand-picker-selected');
    const inputName = picker.getAttribute('data-input-name') || 'evazar_brand_term_ids[]';
    if (!input || !results || !selected) return;
    picker.dataset.evaInitialized = '1';
    let serial = 0;
    let timer = null;

    selected.addEventListener('click', function (event) {
      const button = event.target.closest('.evazar-brand-picker-remove');
      if (button) {
        const item = button.closest('.evazar-brand-picker-selected-item');
        if (item) item.remove();
      }
    });

    function showMessage(message) {
      results.textContent = '';
      const p = document.createElement('p');
      p.className = 'evazar-brand-picker-message';
      p.textContent = message;
      results.appendChild(p);
    }

    function renderResults(terms) {
      results.textContent = '';
      if (!terms.length) {
        showMessage(labels.noResults || 'نتیجه‌ای پیدا نشد.');
        return;
      }
      terms.forEach(function (term) {
        if (!term || !term.id || hasTerm(selected, term.id)) return;
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'evazar-brand-picker-result';
        button.setAttribute('role', 'option');
        button.setAttribute('data-term-id', String(term.id));
        const name = document.createElement('strong');
        name.textContent = escapeText(term.name);
        const small = document.createElement('small');
        small.textContent = (labels.slug || 'نامک: ') + escapeText(term.slug) + ' · ' + (labels.id || 'شناسه: ') + String(term.id);
        button.appendChild(name);
        button.appendChild(small);
        button.addEventListener('click', function () {
          if (!hasTerm(selected, term.id)) {
            selected.appendChild(buildSelectedItem(term, inputName));
          }
          button.remove();
          input.value = '';
          input.focus();
        });
        results.appendChild(button);
      });
      if (!results.querySelector('button')) showMessage(labels.noResults || 'نتیجه‌ای پیدا نشد.');
    }

    input.addEventListener('input', function () {
      const query = input.value.trim();
      serial++;
      const thisSerial = serial;
      if (timer) window.clearTimeout(timer);
      if (!query) {
        results.textContent = '';
        return;
      }
      showMessage(labels.searching || 'در حال جست‌وجو…');
      timer = window.setTimeout(function () {
        requestTerms({ q: query }).then(function (terms) {
          if (thisSerial !== serial) return;
          renderResults(terms);
        }).catch(function () {
          if (thisSerial !== serial) return;
          showMessage('جست‌وجوی برند انجام نشد؛ دوباره تلاش کن.');
        });
      }, 220);
    });
  }

  function addSlugBelowBrandName() {
    const table = document.querySelector('.wp-list-table');
    if (!table) return;
    table.querySelectorAll('tbody tr').forEach(function (row) {
      const nameCell = row.querySelector('td.column-name');
      const slugCell = row.querySelector('td.column-slug');
      if (!nameCell || !slugCell || nameCell.querySelector('.evazar-term-slug-under-name')) return;
      const slug = slugCell.textContent.trim();
      if (!slug || slug === '—' || slug === '-') return;
      const note = document.createElement('small');
      note.className = 'evazar-term-slug-under-name';
      note.textContent = 'نامک: ' + slug;
      const titleLink = nameCell.querySelector('a.row-title') || nameCell.querySelector('strong a') || nameCell.querySelector('a');
      if (titleLink) titleLink.insertAdjacentElement('afterend', note);
      else nameCell.appendChild(note);
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.evazar-brand-picker').forEach(initPicker);
    // The quick/bulk edit templates are generated in the hidden inline-edit row; initialize lazily too.
    const observer = new MutationObserver(function () {
      document.querySelectorAll('.evazar-brand-picker').forEach(initPicker);
    });
    observer.observe(document.body, { childList: true, subtree: true });
    if (document.body.classList.contains('taxonomy-evazar_brand') || document.querySelector('body.edit-tags-php')) {
      addSlugBelowBrandName();
    }
  });
})();
