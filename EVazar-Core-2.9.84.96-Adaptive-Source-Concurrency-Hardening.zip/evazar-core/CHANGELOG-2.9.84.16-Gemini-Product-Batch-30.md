# EVazar Core 2.9.84.16 — Gemini product batch size 30

## Changes
- Raises the automatic Gemini product batch ceiling from 15 to 30 end-to-end across settings, request validation, context propagation, queue chunking, adaptive capacity, signed parallel dispatch, headers, logs, and the embedded Cloudflare Worker.
- Adds a one-time migration that sets `evazar_ai_product_batch_size` to 30; the setting can subsequently be lowered in the admin UI (supported range 2–30).
- Updates the related admin guidance to describe 30-item requests and the unchanged 75-product outer queue cap accurately.
- Keeps the existing source-URL-based brand slug behavior and 301 mappings from Core 2.9.84.15 / Worker 1.13.17.

## Preserved limits and exclusions
- Outer queue-run cap remains 75 products.
- Worker parallelism setting remains capped at five Workers; at batch size 30, a 75-product run normally partitions into `30 + 30 + 15` and therefore uses at most three concurrent product batches.
- If cURL-multi is unavailable or PHP cannot extend runtime sufficiently, the safety cap remains one batch, now up to 30 products.
- Gemini taxonomy SEO batch size remains 2–5 items.
- The default Gemini API timeout remains unchanged.
- No cache code, cache rules, cache purge logic, price/stock sync logic, or Theme files were changed.

## Risk / validation notes
- A larger request can take longer and may return incomplete output. Existing Core validation salvages valid per-product outputs and requeues missing/invalid products; if no item is valid, the whole batch is requeued. It does not create immediate singleton Gemini requests as a fallback.
- Local tests cannot establish live Gemini latency or completion rate. After deploying Worker 1.13.18 to every configured Worker, then Core 2.9.84.16, run one controlled 30-product request and inspect `batch_partial_output_invalid`, `batch_output_invalid`, timeout, and retry events. If these rise materially, set the batch size to 15 in settings.

## Compatibility baseline
Built from Core 2.9.84.15 / Worker 1.13.17. Product batch limit changes from 15 to 30; taxonomy SEO limit remains 5.
