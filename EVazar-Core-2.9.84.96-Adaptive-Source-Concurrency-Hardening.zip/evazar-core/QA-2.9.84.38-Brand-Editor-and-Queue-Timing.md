# QA — EVazar Core 2.9.84.38

## Code review findings addressed
1. **Quick Edit UI lifecycle:** previous code initialized the brand picker while it lived inside WordPress's hidden `#inlineedit` template. The picker uses native `addEventListener`, which isn't cloned with jQuery's event-data cloning; the `data-eva-initialized` flag was cloned too, preventing reinitialization. The hidden template is now skipped so the live Quick Edit clone is initialized.
2. **Classic/Quick Edit persistence:** assignment is centralized in an exact-ID helper that checks post type, per-post edit permission, taxonomy assignment permission, term existence, and persisted IDs. A nonce-validated shutdown reconciliation runs after WordPress finishes its normal save pipeline, so later core taxonomy handling cannot silently undo the selected brand. Quick Edit adds; full edit replaces; an explicit empty selection in full edit clears.
3. **Gutenberg REST:** the selector module was previously required only inside `is_admin()`, but REST API requests can run with `is_admin() === false`. The module is now loaded for REST requests, and a post-save REST hook verifies/reconciles the exact taxonomy IDs submitted by the editor.
4. **Randomized cadence:** no queue-manager production code changed. A new test checks early automatic invocation is gated by `evazar_queue_next_auto_run_at` and cannot take the run lock before the not-before timestamp.

## Regression results
- Brand selector/save lifecycle: **34 passed, 0 failed**.
- Random interval/lock/Cron schedule: **18 passed, 0 failed**.
- Brand source regression: **120 passed, 0 failed**.
- Brand registration: **19 passed, 0 failed**.
- Brand metadata repair: **26 passed, 0 failed**.
- Category metadata repair: **16 passed, 0 failed**.
- Queue taxonomy identity sync: **11 passed, 0 failed**.
- Gemini cooldown/recovery: **32 assertions passed**.
- PHP syntax: **20 files passed `php -l`**.
- JavaScript syntax: `node --check` passed for all 5 JavaScript files.

## Protected-file comparison against Core 2.9.84.37
Byte-identical: `cache-purge.php`, `product-index.php`, `importer.php`, `queue-manager.php`, `worker/digikala-worker.js`.

The Worker is unchanged; standalone Worker **1.13.23** remains appropriate and matches the embedded Worker SHA-256 `1a627ffc7011f3ada8419366d7493b8bc4df57204bdbb9feb6b107ab1256ecfb`.

## Limitations
All tests are local regression/stub tests, not a live WordPress browser/database integration test. No production database, browser session, WP-Cron runner, Digikala API, or live Worker was accessed. Validate with one product in Quick Edit and one in the full editor after deployment; reload both products and confirm the `evazar_brand` relationship by term ID.
