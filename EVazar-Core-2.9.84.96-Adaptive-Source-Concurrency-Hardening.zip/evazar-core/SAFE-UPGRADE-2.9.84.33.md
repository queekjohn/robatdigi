# Safe Upgrade — EVazar Core 2.9.84.33

## Required deployment order
1. Deploy Worker 1.13.22's `digikala-worker.js` to every configured primary Digikala Worker. Keep `EVAZAR_INTERNAL_TOKEN` set and equal to Core's `evazar_cf_worker_token`.
2. Install/upgrade the `evazar-core` plugin from the Core release ZIP.
3. Open WordPress Tools → ثبت برند از لینک دیجی‌کالا. Preview the live identity, review the returned fields, and confirm registration.

## Behavior and scope
- Reads the URL in Core's admin-post handler and submits it to the configured Worker pool using the server-side `evazar_primary_worker_request()` helper.
- No browser-side Worker calls and no direct Core-to-Digikala fallback.
- Source identity is fetched fresh through the authenticated Worker endpoint; the identity is fetched again at confirmation and must match the preview.
- Creates only a new `evazar_brand` term and its verified source metadata.
- Duplicate IDs, URLs, occupied public slugs and redirect-reserved slugs block creation.
- Does not assign any product, modify existing taxonomy terms, change redirects, or run any cache/purge operation.
- `cache-purge.php`, `product-index.php`, `queue-manager.php` and `taxonomy-seo-queue.php` are byte-identical to Core 2.9.84.32.
