(function (wp) {
  'use strict';
  if (!wp || !wp.plugins || !wp.element || !wp.components || !wp.data) return;
  const h = wp.element.createElement;
  const useState = wp.element.useState;
  const useEffect = wp.element.useEffect;
  const Panel = (wp.editPost && wp.editPost.PluginDocumentSettingPanel) || (wp.editor && wp.editor.PluginDocumentSettingPanel);
  if (!Panel) return;
  const cfg = window.EvazarBrandSelectorEditor || {};
  const { TextControl, Button, Spinner, Notice } = wp.components;

  function requestTerms(params) {
    const search = new URLSearchParams(Object.assign({
      action: 'evazar_brand_selector_search',
      nonce: cfg.nonce || ''
    }, params || {}));
    return fetch((cfg.ajaxUrl || window.ajaxurl || '') + '?' + search.toString(), {
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'XMLHttpRequest' }
    }).then(function (response) {
      if (!response.ok) throw new Error('http_' + response.status);
      return response.json();
    }).then(function (payload) {
      if (!payload || !payload.success || !Array.isArray(payload.data)) throw new Error('invalid_response');
      return payload.data;
    });
  }

  function BrandSelectorPanel() {
    const current = wp.data.useSelect(function (select) {
      const raw = select('core/editor').getEditedPostAttribute('evazar_brand') || [];
      return Array.isArray(raw) ? raw.map(Number).filter(function (id) { return id > 0; }) : [];
    }, []);
    const editPost = wp.data.useDispatch('core/editor').editPost;
    const [query, setQuery] = useState('');
    const [results, setResults] = useState([]);
    const [known, setKnown] = useState({});
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const idsKey = current.join(',');

    useEffect(function () {
      const dispatcher = wp.data.dispatch('core/edit-post');
      if (dispatcher && typeof dispatcher.removeEditorPanel === 'function') {
        dispatcher.removeEditorPanel('taxonomy-panel-evazar_brand');
      }
    }, []);

    useEffect(function () {
      if (!idsKey) return;
      let cancelled = false;
      const missing = current.filter(function (id) { return !known[id]; });
      if (!missing.length) return;
      requestTerms({ ids: missing.join(',') }).then(function (terms) {
        if (cancelled) return;
        setKnown(function (old) {
          const next = Object.assign({}, old);
          terms.forEach(function (term) { next[term.id] = term; });
          return next;
        });
      }).catch(function () {});
      return function () { cancelled = true; };
    }, [idsKey]);

    useEffect(function () {
      const q = query.trim();
      if (!q) {
        setResults([]);
        setLoading(false);
        setError('');
        return;
      }
      let cancelled = false;
      const timer = window.setTimeout(function () {
        setLoading(true);
        setError('');
        requestTerms({ q: q }).then(function (terms) {
          if (cancelled) return;
          setResults(terms);
          setKnown(function (old) {
            const next = Object.assign({}, old);
            terms.forEach(function (term) { next[term.id] = term; });
            return next;
          });
        }).catch(function () {
          if (cancelled) return;
          setResults([]);
          setError('جست‌وجوی برند ناموفق بود؛ دوباره تلاش کن.');
        }).finally(function () {
          if (!cancelled) setLoading(false);
        });
      }, 220);
      return function () {
        cancelled = true;
        window.clearTimeout(timer);
      };
    }, [query]);

    function addTerm(term) {
      if (current.indexOf(Number(term.id)) !== -1) return;
      editPost({ evazar_brand: current.concat([Number(term.id)]) });
      setKnown(function (old) { const next = Object.assign({}, old); next[term.id] = term; return next; });
    }

    function removeTerm(id) {
      editPost({ evazar_brand: current.filter(function (termId) { return Number(termId) !== Number(id); }) });
    }

    return h(Panel, { name: 'evazar-brand-selector-panel', title: 'برند کالا (نام و نامک)' },
      h('p', null, 'جست‌وجو با نام فارسی یا نامک انگلیسی؛ هر انتخاب با شناسهٔ واقعی برند ذخیره می‌شود.'),
      h(TextControl, {
        label: 'جست‌وجوی برند',
        value: query,
        onChange: setQuery,
        placeholder: 'مثلاً سالومون یا salomon-pc'
      }),
      loading ? h(Spinner, null) : null,
      error ? h(Notice, { status: 'error', isDismissible: false }, error) : null,
      current.length ? h('div', { className: 'evazar-brand-editor-selected' },
        current.map(function (id) {
          const term = known[id];
          return h('div', { key: id, className: 'evazar-brand-editor-selected-item' },
            h('div', null,
              h('strong', null, term ? term.name : ('برند #' + id)),
              h('small', null, term ? ('نامک: ' + term.slug + ' · شناسه: ' + id) : ('شناسه: ' + id))
            ),
            h(Button, { isDestructive: true, variant: 'tertiary', onClick: function () { removeTerm(id); } }, 'حذف')
          );
        })
      ) : h('p', null, 'برای این کالا هنوز برندی انتخاب نشده است.'),
      results.length ? h('div', { className: 'evazar-brand-editor-results' },
        results.map(function (term) {
          const chosen = current.indexOf(Number(term.id)) !== -1;
          return h(Button, {
            key: term.id,
            variant: chosen ? 'secondary' : 'tertiary',
            disabled: chosen,
            onClick: function () { addTerm(term); }
          }, h('span', { className: 'evazar-brand-editor-result' },
            h('strong', null, term.name),
            h('small', null, 'نامک: ' + term.slug + ' · شناسه: ' + term.id)
          ));
        })
      ) : (query.trim() && !loading && !error ? h('p', null, 'نتیجه‌ای پیدا نشد.') : null)
    );
  }

  wp.plugins.registerPlugin('evazar-brand-selector', { render: BrandSelectorPanel });
})(window.wp);
