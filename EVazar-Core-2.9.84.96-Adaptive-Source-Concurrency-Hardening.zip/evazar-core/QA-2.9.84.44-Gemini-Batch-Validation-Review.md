# QA — EVazar Core 2.9.84.44 / Worker 1.13.24

## Review findings
- Core request-context preparation previously truncated the DKP array to 30 while preserving the configured batch_size; 2.9.84.43 fixes this root cause by normalizing/deduplicating up to 50.
- This follow-up fixes the remaining display-only 30-DKP limit in the admin Gemini operations table.
- Worker source 1.13.23 has a hard maximum of 30 and rejects larger batches. Worker source 1.13.24 supports 2–50 products. Deploying/upgrading the WordPress plugin does not publish code to Cloudflare; all active endpoints must actually report 1.13.24 or later for 40-product requests.
- Core's Worker request headers are checked for identical declared batch size and unique-DKP count at 2, 30, 40 and 50.
- A focused queue regression test covers the reported configuration: four eligible Workers × 40 products calculates 160 slots when parallel transport is available; without cURL-multi transport the queue intentionally falls back to one 40-product batch. The configured queue cap, Worker eligibility/cooldowns, and server execution constraints still apply.

## Local verification
- PHP syntax: all 21 PHP files passed.
- PHP regression scripts: all 9 passed, 347 assertions combined.
- JavaScript regression scripts: both passed, 47 checks combined; includes Worker integration checks that accept 50 and reject 51 before calling upstream Gemini.
- Embedded Worker file is byte-identical to the standalone 1.13.24 Worker ZIP source.

## Not verified
No live WordPress site, active Cloudflare deployment, actual Worker URLs, production queue, or real Google Gemini API request was exercised.
