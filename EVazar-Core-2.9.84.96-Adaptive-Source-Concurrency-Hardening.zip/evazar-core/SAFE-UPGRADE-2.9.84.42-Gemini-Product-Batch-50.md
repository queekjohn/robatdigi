# Safe upgrade — Core 2.9.84.42 / Worker 1.13.24

1. Deploy Worker 1.13.24 to every Gemini Worker URL configured in EVazar Core before installing Core 2.9.84.42. Core may send up to 50 products per request, which older Worker versions reject.
2. Replace the existing `evazar-core` plugin folder/plugin ZIP with Core 2.9.84.42.
3. On the first WordPress `init`, the new one-time migrations promote a saved batch size of 30 to 50 and the old outer queue cap of 150 to 250. Deliberately lower batch sizes and queue caps are preserved.
4. Confirm the admin setting shows 50 products/request and the outer queue cap is 250 (unless you intentionally set a lower cap).
5. Run a controlled test with 50 products and inspect Gemini logs for declared batch size, output completeness, retries, and quota errors before allowing full queue processing.
6. Taxonomy SEO request limits remain unchanged at five items. No Theme or cache changes are included.
