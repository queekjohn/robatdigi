# QA — EVazar Core 2.9.84.61

## Scope
Randomized automatic queue interval changed from whole-minute selection to whole-second selection inside the configured whole-minute bounds. Existing min/max settings remain compatible.

## Checks
- Inclusive bounds use `min_minutes * 60` and `max_minutes * 60`.
- Tests cover 6m20s and 7m10s outcomes in a 5–8 minute range, lower/upper clamping, and equal bounds.
- Queue-start, first schedule, reschedule, and follow-up gating all use the authoritative second-based timestamp.
- Legacy `evazar_queue_last_random_interval_minutes` remains available; exact seconds are available in `evazar_queue_last_random_interval_seconds` and run diagnostics.
- No Worker, cache, product-import, or Gemini batching code paths changed.
