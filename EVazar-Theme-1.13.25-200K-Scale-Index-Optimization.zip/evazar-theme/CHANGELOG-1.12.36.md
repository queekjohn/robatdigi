# EVazar Theme 1.12.36

- Diagnostic-only patch: fixed JavaScript quoting for the LCP report transport URL in the head observer.
- No visual, layout, or production behavior changes outside the diagnostic URL.
