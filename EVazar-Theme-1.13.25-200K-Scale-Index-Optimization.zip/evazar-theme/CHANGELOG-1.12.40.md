# EVazar Theme 1.12.40

- Product gallery and fullscreen lightbox now use double-buffered image crossfade transitions.
- The next image is fully loaded and decoded before becoming visible, eliminating the visible jump/flash during image changes.
- Product-page image recovery is now presentation-only: Core owns CDN failover, while Theme owns the final placeholder.
- Removed the duplicate browser retry to `evazar_retry=1` that could race with Core failover and delay recovery on mobile.
- Desktop hover zoom follows whichever gallery image is currently active.
