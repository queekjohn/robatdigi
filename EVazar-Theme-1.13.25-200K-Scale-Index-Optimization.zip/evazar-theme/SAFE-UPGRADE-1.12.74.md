# Safe upgrade — EVazar Theme 1.12.74

1. Back up the current theme folder; retain the required folder name `evazar-theme`.
2. Test product cards, galleries, lazy loading, responsive `srcset`, and CDN-to-direct failover on staging.
3. When Core is active its helper is canonical; the theme implementation is a fallback. Both now share the same resize-operator parsing.
