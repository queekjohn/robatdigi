# Safe upgrade — EVazar Theme 1.13.17

- Keep the theme folder name exactly `evazar-theme`.
- Install with EVazar Core 2.9.37 or newer that supports the optional related-product offset argument. Core 2.9.36 remains compatible with existing product pages, but its helper does not expose offset pagination; full scroll-loading therefore requires Core 2.9.37.
- Cloudflare Worker deployment is not required.
- The related-products endpoint is separate from archive filters and validates a WordPress nonce, published product ID, and a fixed 12-item batch size.
- Product records, taxonomy terms, prices, stock, affiliate links, gallery behavior, and import queues are not migrated or rewritten.
- Before production installation, back up the current theme and Core folder. Then replace the existing `evazar-theme/` and `evazar-core/` folders rather than creating version-suffixed directories. Clear page cache after installation.
- After install, test one product on desktop and mobile: initial cards render, scroll adds further cards without a page refresh, no duplicates appear, and the list stops or exposes a retry control when the network request fails.
