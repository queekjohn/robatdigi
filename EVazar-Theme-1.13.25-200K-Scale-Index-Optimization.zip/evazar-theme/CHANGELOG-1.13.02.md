# EVazar Theme 1.13.02

- Fixed the desktop Special Offers viewport: navigation gutters now live on the wrapper instead of scrolling with the cards.
- Desktop rail width fits a whole number of 205px cards and 12px gaps, preventing fractional product cards at the visible edge.
- Navigation advances by the number of fully visible cards (up to six), avoiding skipped products when the viewport can fit fewer than six.
- The Next arrow is positioned beside the actual rail edge when the rail is fitted narrower than its wrapper.
- Changes are scoped to the desktop Special Offers carousel; mobile behavior and other homepage carousels retain their existing path.
