# Changelog 1.12.6

## Related Products — Display Fix
- Preserved the theme options for show/hide, count, and hide-out-of-stock.
- Removed the fragile availability meta constraint from the main candidate WP_Query.
- Applied the availability rule after fetching candidates, with legacy-product compatibility.
- Added category, brand, branch, and newest-product pools with lightweight scoring.
- Prevented the section from disappearing because an older product is missing availability metadata.
