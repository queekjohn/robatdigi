# EVazar Theme 1.13.16

- Displays imported product specifications grouped under source section headings when `_evazar_spec_groups` is available.
- Preserves existing collapsible feature limit and counts feature rows only, not group headings.
- Falls back to the previous flat feature renderer for older products and manually edited feature text.
- Adds compact RTL group-heading styles in product-page.css.
