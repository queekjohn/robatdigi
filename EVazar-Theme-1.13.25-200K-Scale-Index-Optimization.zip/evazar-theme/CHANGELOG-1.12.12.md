# EVazar Theme 1.12.12

- Removed the external Digikala affiliate-logo image request from the global header to eliminate an unnecessary third-party network dependency.
- Kept the affiliate badge text intact.
- Added defensive above-the-fold visibility rules for the homepage hero so the primary H1/content remains paintable and cannot be hidden by a generic opacity/visibility rule or animation.
- Updated the theme package version to 1.12.12.
