# EVazar Theme 1.12.38

## LCP / Hero font stability

- Removed the temporary LCP diagnostic instrumentation from the production theme.
- Added a dedicated `VazirmatnLCP` font face for the homepage Hero H1 with `font-display: block`.
- Applied the dedicated font only to the Hero H1 when the active theme font is Vazirmatn, preventing late font-swap on the primary LCP text element.
- Preserved the existing 1.12.25+ homepage deal-card spacing fix (no restoration of 360×360 intrinsic image hints).
- No changes to homepage card layout, product rendering, affiliate behavior, or non-homepage functionality.
