# EVazar Theme 1.13.05

- Fixed the Special Offers carousel shrinking from six cards to five after the load-time viewport measurement.
- Expanded the red Special Offers showcase by 78px symmetrically on wide desktop viewports so six 205px cards, five 12px gaps, 2px rail paddings on both sides, and the existing arrow gutters fit together.
- Capped the desktop viewport fitting calculation at six cards. Other carousels and mobile layout are unchanged.
