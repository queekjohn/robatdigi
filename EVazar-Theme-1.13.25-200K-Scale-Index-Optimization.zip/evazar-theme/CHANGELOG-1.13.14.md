# EVazar Theme 1.13.14 — Legacy archive query redirects

- Adds a permanent 301 redirect from `/?post_type=evazar_product` to `/product/`.
- The redirect only matches the site root with the exact `post_type=evazar_product` parameter; unrelated URLs and query parameters are not globally redirected.
- Preserves other query parameters if they accompany the legacy archive parameter.
- Retains the existing 1.13.13 legacy offers redirects to `/offers/` and matching paginated offers pages.
- No Core plugin, database, product data, or Worker changes.

Validation: PHP syntax and ZIP integrity checked; live WordPress/browser behavior still needs verification after installation.
