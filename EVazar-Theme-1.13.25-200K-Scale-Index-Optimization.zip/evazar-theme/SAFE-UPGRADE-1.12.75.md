# Safe Upgrade — EVazar Theme 1.12.75

1. Back up the current `evazar-theme` folder and database before replacement.
2. Install this ZIP with the internal folder name `evazar-theme`. No schema change or database migration is required.
3. Clear page, object and CDN caches so the `style.css` version `1.12.75` forces fresh search assets and the `evz_srch_v20_` cache namespace bypasses prior AJAX responses.
4. Test a short title fragment, two title words in reversed order, DKP with and without `DKP-` (including a space after DKP), Persian/Arabic digits, an internal product ID, an alphabetic exact SKU, the stock-only toggle, arrow/Enter navigation, and mobile plus desktop inputs.
5. Confirm the AJAX dropdown shows product cards (image/title/code/price), not only keyword suggestions. Test a result without an image, a known CDN image that fails once (expect one direct-source retry), and a product with unavailable price.
6. Confirm the full results page returns only products when searched from the EVazar product search form and that a code search cannot bypass publish/password predicates.
7. If search returns a PHP/JS error, returns non-product content, or causes noticeable database load, restore the previous theme ZIP.

Search behavior changes are contained in the theme. Core and Worker updates are not required for this search release. Full live WordPress/MariaDB integration and real-browser testing were not available during package preparation.
