# EVazar Theme 1.13.22 — Homepage zero-price display fix

- Added a theme-side product price-state helper aligned with EVazar Core: `explicit_unavailable` renders as «ناموجود»; a positive valid price renders normally; zero/missing/invalid price without an explicit unavailable signal renders as «قیمت نامشخص».
- Applied this rule to all six homepage product-rendering paths, including the deals rail, newest-product cards, category tabs, and product shelves.
- Suppressed old-price, discount, price-drop, and savings displays when the current price is not valid, preventing misleading discount/savings presentation for unavailable products.
- No Core/Worker code, product metadata, database schema, query settings, or availability records were changed.
