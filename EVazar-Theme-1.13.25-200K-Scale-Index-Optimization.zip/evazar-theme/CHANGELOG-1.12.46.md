# EVazar Theme 1.12.46

- Replaced the local/handcraft category icon with a cleaner woven-basket style icon everywhere `evazar_get_category_icon()` maps those categories.
- Replaced category-directory accordion chevrons with a minimal CSS plus/minus control.
- No changes to image loading, image failover, gallery, lightbox, or product-page logic.
