# EVazar Theme 1.12.43

- Removed the duplicate category icon from the submenu panel header on desktop as well as mobile; the primary icon in the category sidebar remains.
- No image, Failover, gallery, Lightbox, product-page, or other UX logic was changed.
