# EVazar Theme 1.13.07 — Special Offers Width and Spacing

- Removed the 78px desktop-only width expansion that made the red Special Offers block wider than the other homepage elements.
- Reduced desktop Special Offers card gap from 12px to 4px.
- Reduced only desktop special-offer product-card width from 205px to 198px, allowing six complete cards to fit in the existing container while keeping the original arrow gutters.
- Preserved the 24px desktop wrapper gutters and 38px vertically centered arrows to avoid covering product cards.
- Changes apply only at widths of 769px and above; mobile card width, mobile scrolling, image loading, product gallery, other carousels, importer, and structured-data code are untouched.

## Layout arithmetic

Six cards: 6 × 198px + 5 × 4px gap + 4px total rail padding = 1212px.
Available rail width in the 1520px max-width shared container: 1216px.
The viewport-fit script therefore computes six whole cards without widening the red showcase.

## Validation

- CSS override is desktop-only and scoped to `.home-deals-section` descendants via the `.deals-*` selectors.
- Mobile rules for widths up to 768px are unchanged.
- JavaScript/navigation code and image-related files are unchanged.
- Package ZIP integrity and source-diff checks performed.
- Not live-tested on production; verify desktop widths after install and clear theme/page cache.
