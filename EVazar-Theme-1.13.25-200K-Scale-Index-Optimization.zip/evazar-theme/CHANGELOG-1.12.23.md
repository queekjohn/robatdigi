# EVazar Theme 1.12.23

- Isolated homepage deal-card geometry test based directly on 1.12.21.
- Restored full thumbnail image sizing (`width/height: 100%`, `max-width/max-height: 100%`) without cropping; this removes the artificial 90% inset.
- Removed forced two-line title height so short titles do not reserve unused vertical space.
- No changes to PHP logic, JavaScript, image loading priority, affiliate behavior, importer, search, product data, or LCP strategy.
