# EVazar Theme 1.12.90 — Special Offers card alignment on desktop and mobile

- Extends card-alignment snapping for the homepage Special Offers carousel to desktop as well as mobile.
- Desktop snap is applied to the scrolling `.deals-slider-rail`; mobile snap is applied to `.deals-showcase-box`, which becomes the actual scroll container when the rail/wrapper use `display: contents`.
- The final card uses end alignment to reduce the chance of a clipped final card at the scroll boundary.
- No product-gallery code or unrelated carousel styles were changed.
- Static source/package checks performed; live desktop/mobile browser verification remains necessary.
