# EVazar Theme 1.12.82

- Added low-priority preloading for only the immediately previous and next full-size product gallery images after the current image is ready.
- Reuses the same image URLs and browser cache for the product gallery and fullscreen lightbox.
- Failed preload requests are removed from the small in-memory cache so transient failures can retry.
- No markup, styling, swipe, gallery transition, image recovery, or lightbox navigation behavior intentionally changed.
