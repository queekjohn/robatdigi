# EVazar Theme 1.12.81

- Hide the header quick-navigation bar (categories, popular brands, special offers) on mobile single-product pages only.
- Keep the bar visible on desktop and on all other page types.
- CSS-only, scoped to `body.single-evazar_product` at viewport widths up to 768px; no product gallery or image-loading logic changed.
