# EVazar Theme 1.12.1

## Floating back-to-top button
- Converted the footer back-to-top control into a floating fixed button so it remains accessible while scrolling.
- On mobile single-product pages, the button is positioned above the sticky mobile buy bar and respects the device safe-area inset.
- Kept the existing smooth-scroll behavior and added an accessible label/title.
- Bumped the theme version to 1.12.1 for deterministic cache invalidation.
