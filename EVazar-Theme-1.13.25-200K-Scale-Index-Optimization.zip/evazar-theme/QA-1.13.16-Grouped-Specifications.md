# QA — EVazar Theme 1.13.16 (Grouped Specifications)

## Changes

- Reads group headings and specification rows from `_evazar_spec_groups`.
- Renders headings in the existing product features box without changing the existing feature-row limit.
- Keeps group headings out of the visible-feature count and the “view more” count.
- Falls back to the prior flat `_evazar_key_features` parser when grouped metadata is absent or invalid.

## Validations performed

- PHP syntax check across Theme PHP files passed.
- Theme getter test passed for grouped JSON, display order, rows under their headings, and fallback for an older ungrouped product.
- Template/CSS selectors and the “view more” selector were checked for group-heading compatibility.

## Not yet verified

Actual browser layout, responsive breakpoints, and the live site CSS cache have not been tested. Review one re-imported product on desktop and mobile after deployment.
