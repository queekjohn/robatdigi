# EVazar Theme 1.12.78 — ICO Favicon Upload Support

- Added a theme-level WordPress MIME allowlist entry for `.ico` files so administrators can upload favicon files through Media Library.
- Added a narrow file-type detection fallback for `.ico` uploads that checks the standard ICO header before assigning the `image/x-icon` MIME type.
- No changes to search, related products, archive filters, infinite scroll, gallery, or frontend rendering.

## Validation

- PHP syntax lint: pending package build validation.
- ICO validation is limited to files with the expected ICO header; this does not disable WordPress upload security globally.
