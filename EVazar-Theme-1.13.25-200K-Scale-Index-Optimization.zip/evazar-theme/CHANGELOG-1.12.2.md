# EVazar Theme 1.12.2

## Smart floating back-to-top button
- Moved the floating back-to-top button to the left side on desktop and mobile.
- Kept the button hidden until the user scrolls more than 400px down the page.
- Uses a lightweight passive scroll listener with `requestAnimationFrame` to avoid unnecessary work during scrolling.
- Preserved the existing mobile sticky-buybar spacing, safe-area handling, responsive sizing, and smooth-scroll behavior.
- Bumped the theme version to 1.12.2 for deterministic cache invalidation.
