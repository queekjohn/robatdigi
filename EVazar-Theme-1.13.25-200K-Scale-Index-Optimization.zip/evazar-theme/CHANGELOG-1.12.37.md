# EVazar Theme 1.12.37

## LCP diagnostic refinement
- Keeps the v1.12.36 head-installed LCP observer.
- Adds direct `performance.getEntriesByType("largest-contentful-paint")` inspection.
- Adds `PerformanceObserver.takeRecords()` inspection before the final report.
- No production CSS/layout/feature changes.
