# EVazar Theme 1.12.66

- Enabled infinite scroll on the main `/product/` product archive as well as existing brand/category archives.
- Numbered pagination is visually hidden only after the infinite-scroll controller initializes; its links remain available to JavaScript.
- Increased the prefetch distance so the next batch starts loading before the visitor reaches the bottom.
- Kept the loader as the only visible loading indicator and removed visible pagination counts from infinite-scroll archives.
- Newly appended product images use asynchronous decoding; the first four images in each fetched batch are eager-loaded for faster perceived rendering, with the rest lazy-loaded.
- No gallery, lightbox, product-detail, or price-drop code changed.
