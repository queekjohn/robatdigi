# EVazar Theme 1.12.10

- Fixed excessive top/bottom white space inside archive product cards caused by forcing responsive product images to a square 360x360 intrinsic ratio.
- Responsive `srcset`/`sizes` image optimization is preserved.
- Archive product images are passed to the responsive renderer at their original URL, avoiding an unnecessary pre-transform step.
- Card layout reservation remains controlled by the existing `.card-thumb-wrap` `aspect-ratio: 1`.
