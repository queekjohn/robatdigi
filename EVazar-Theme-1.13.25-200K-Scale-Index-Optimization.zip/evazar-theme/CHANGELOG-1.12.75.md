# EVazar Theme 1.12.75 — Product-first AJAX Search

- AJAX dropdown now returns and renders up to five real EVazar product cards with thumbnail, title, code, price and availability instead of displaying only phrase suggestions.
- Search ranking prioritizes exact DKP/SKU/internal ID matches, then exact/prefix/substring title matches, then title token coverage. Results are bounded to a small set of candidates.
- Supports partial title fragments and order-independent multiword search through WordPress search, numeric internal IDs, DKP with or without `DKP-` (including a space after the prefix), Persian/Arabic digits, separator variants, and exact alphabetic SKU values.
- Main product search adds identifier conditions inside WordPress' `posts_search` predicate rather than appending an ungrouped `OR` to the whole SQL `WHERE`; it preserves the anonymous-user `post_password` predicate and leaves non-product searches alone.
- AJAX request length is capped at 80 Unicode characters. Candidate queries skip unnecessary `found_rows` and unused post-term cache priming. Result cache uses `evz_srch_v20_` with a 60-second TTL to invalidate older results.
- Desktop/mobile requests have independent debounce/abort/stale-response tracking. Keyboard navigation targets product cards, and text highlighting escapes every original text segment before adding `<mark>` tags.
- “Did you mean?” can display when no product/category/brand result exists.
- AJAX product images include a direct-source fallback only for the known EVazar image CDN or Digikala image host. The direct URL is tried once after a CDN error, then a placeholder is shown.
- Existing categories, brands, recent/popular searches, stock-only filter and “view all results” link are retained.

## Validation

PHP lint passed for all 12 theme PHP files; Node syntax checks passed for all 4 theme JavaScript files. Focused tests covered the search SQL predicate for DKP, numeric internal ID, alphabetic SKU, non-product queries, and preserving the anonymous `post_password` condition. Static contracts for the AJAX action/nonce/products payload and image-fallback retry passed. A focused test also verified safe title highlighting with HTML-like text.

Full WordPress/MariaDB runtime and real browser/load testing were not available in this build environment. This release changes the theme's search paths only; no core, Worker or database migration is required.
