# Evazar Theme 1.12.72 — Search/Core reconciliation

- Fixed full-page product-code searching against Product Index: wildcard matching now uses `LIKE` rather than `=` with percent characters.
- Normalized Persian/Arabic digits and DKP prefix for the main site search.
- Full-page search also matches an exact numeric internal EVazar product ID while keeping the result constrained to published `evazar_product` posts.
- Live AJAX search now removes the `DKP-` prefix correctly, so the SKU/DKP fallback can match stored numeric codes.
- Live AJAX search performs exact ID and exact DKP metadata lookups in addition to title search, respects the existing in-stock filter, and prioritizes identity matches.
- If a code/ID lookup resolves a product but ordinary title suggestions are empty, the matched product title is shown as a searchable suggestion.
- Search transient namespace advanced to `evz_srch_v18_` to avoid serving results cached before these changes.
