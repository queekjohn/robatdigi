# EVazar Theme 1.12.50

- Mobile archive product cards: compacted the price-drop badge.
- Mobile label is now «افت قیمت» instead of the longer «افت قیمت امروز».
- Removed the emoji/icon from the mobile label while keeping the existing down-arrow SVG.
- Reduced mobile badge padding/font size so the product image remains more visible when a discount badge is also present.
- Desktop badge appearance remains unchanged.
- No JavaScript or layout logic added; infinite/AJAX-injected product cards inherit the same CSS automatically.
