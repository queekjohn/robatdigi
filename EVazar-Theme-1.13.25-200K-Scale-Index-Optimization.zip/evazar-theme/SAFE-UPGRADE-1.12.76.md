# Safe Upgrade — 1.12.76

This is a theme-only search enhancement release. It does not require a database schema migration and does not change the EVazar Core or Cloudflare Worker packages.

## Changes
- Restores independent AJAX display of product, category, brand, related query and high-confidence spelling-correction results.
- Uses cached term indexes and a bounded (maximum 2,500 entries) spelling lexicon; product titles are read only during lexicon cache construction, with a six-hour cache.
- No automatic rewriting of the user's query: spelling correction is applied only after the visitor clicks the suggested phrase.
- Popular queries are intentionally excluded from the spell-correction dictionary so typos do not get learned as correct spelling.

## Rollback
Replace the theme folder with the previous `evazar-theme` backup. No database migration rollback is required.

## Validation limitation
Syntax and focused helper tests passed in the build environment. A live WordPress/MariaDB/browser test was not available and is still recommended; take a backup before production deployment.
