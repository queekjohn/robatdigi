# EVazar Theme 1.13.12 — Offers Archive

- Added clean standalone discount archive at `/offers/`.
- Added pagination rewrite support at `/offers/page/{n}/`.
- Reuses existing `_evazar_discount_percent` filtering and archive template; no custom product query or database changes.
- Updated homepage deal links, quick navigation, breadcrumbs, and settings default to `/offers/`.
- Existing `/product/?on_sale=1` links remain supported.
- Rewrite rules are flushed once using a versioned option.
