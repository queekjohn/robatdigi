EVazar Theme 1.12.68

- Added timeout, cancellation, generation guards, one bounded automatic retry for transient network/timeout/server errors, and a manual retry path for archive infinite scroll.
- Re-checks the sentinel after products are appended or filters replace archive content.
- Keeps appended product images lazy-loaded.
- Added a lightweight AJAX response for infinite-scroll requests, skipping filter HTML and smart-filter recomputation while preserving normal filter responses.
- Added a unique product ID tie-breaker to archive sorting to make pagination deterministic for equal sort values.
- Restores numbered pagination when infinite-scroll loading fails.
- Repaired literal escaped newlines in archive-filters.css that caused a CSS declaration parse error.
