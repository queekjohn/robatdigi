# EVazar Theme 1.13.08 — Special Offers Navigation Overlay and Balanced Spacing

## Changes
- Removed the 24px left/right gutters previously reserved for navigation buttons in the desktop Special Offers carousel.
- Navigation buttons now overlay the first and last product cards, aligned to the rail's 8px inner padding and remaining vertically centered.
- Restored a balanced 12px gap between desktop product cards; reduced the desktop card width to 190px and set rail side padding to 8px.
- Six-card width budget: 6 × 198px + 5 × 12px + 2 × 8px = 1264px. The parent showcase width is not expanded.
- Kept mobile layout behavior and all other homepage carousels unchanged.
- Updated the desktop layout routine to compute both arrow positions from the actual rail bounds. Inline desktop positioning is cleared when switching to mobile.

## Validation
- Theme ZIP archive integrity and root folder verified (`evazar-theme/`).
- JavaScript syntax validated with `node --check`.
- Confirmed the patch touches only Special Offers CSS, the Special Offers navigation/layout JavaScript, the theme version header, and this changelog relative to 1.13.07.
- Static arithmetic verifies six 190px cards, five 12px gaps and two 8px insets occupy 1216px.

## Scope
No image loading, lazy loading, CDN, product gallery, importer, archive filter, product data, Core plugin or Worker code changed. These are source/package checks; a live browser test on the production site is still required to verify actual viewport behavior.
