# EVazar Theme 1.12.83

- Prevent mobile product-gallery switching from waiting indefinitely on a detached image preload. After a bounded wait, the real gallery image is activated so core recovery can handle CDN/origin failures.
- Expire stalled adjacent-image preload entries and retry only adjacent images after the browser reports connectivity restored.
- No intended changes to gallery markup, CSS, swipe controls, lightbox layout, archive behavior, or product data.
