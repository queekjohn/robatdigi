# Safe upgrade — EVazar Theme 1.13.19

- Replace the existing `evazar-theme/` folder with the folder from this ZIP; do not rename the folder.
- This release makes the “لوازم خانگی برقی” icon use the same filled `currentColor` style as other category icons. Default color follows the theme text color (light theme `#334155`); hover/active follows the theme primary (`#ef394e`).
- The prior 1.13.17 related-products infinite-scroll changes are preserved. No database migration, plugin/core change, Worker deployment, or settings change is required for this icon-only update.
