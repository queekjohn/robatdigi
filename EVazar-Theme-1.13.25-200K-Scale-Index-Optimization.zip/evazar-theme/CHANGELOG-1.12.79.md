# EVazar Theme 1.12.79 — Favicon Output Fix

- The custom Favicon setting now outputs explicit `rel=icon` markup with an appropriate MIME type for ICO, PNG, and SVG URLs.
- When a custom theme favicon is configured, WordPress core Site Icon output is removed for that request so it cannot compete with the selected favicon.
- No search, related-products, gallery, archive-filter, or infinite-scroll code was changed.
- Browser/CDN cache may still need to be refreshed after changing the favicon.
