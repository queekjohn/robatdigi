# EVazar Theme 1.12.11

- Homepage product images no longer receive `loading="eager"` or `fetchpriority="high"`.
- Keeps the responsive image (`srcset`/`sizes`) optimization from 1.12.9/1.12.10.
- Prevents below-hero product imagery from being incorrectly prioritized as the homepage LCP candidate.
- No changes to product/category/brand archive image loading behavior.
