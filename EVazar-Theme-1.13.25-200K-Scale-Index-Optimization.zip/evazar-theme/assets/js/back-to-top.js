/**
 * Evazar — lightweight global back-to-top control.
 * The button is available on every front-end page and only becomes visible
 * after the user has scrolled beyond the configured threshold.
 */
document.addEventListener('DOMContentLoaded', function () {
    'use strict';

    var btn = document.querySelector('.btn-scroll-top');
    if (!btn) return;

    var SCROLL_THRESHOLD = 400;
    var ticking = false;
    var raf = window.requestAnimationFrame || function (callback) {
        return window.setTimeout(callback, 16);
    };

    function updateBackToTop() {
        var y = window.scrollY || window.pageYOffset || document.documentElement.scrollTop || 0;
        btn.classList.toggle('is-visible', y > SCROLL_THRESHOLD);
        ticking = false;
    }

    function onScroll() {
        if (ticking) return;
        ticking = true;
        raf(updateBackToTop);
    }

    window.addEventListener('scroll', onScroll, { passive: true });

    btn.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });

    updateBackToTop();
});
