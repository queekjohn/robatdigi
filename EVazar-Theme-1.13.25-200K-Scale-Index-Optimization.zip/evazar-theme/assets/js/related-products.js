(function () {
    'use strict';

    function initRelatedProducts() {
        const vars = window.evazar_related_products_vars;
        const section = document.querySelector('.single-related-section[data-related-offset]');
        if (!vars || !section) return;

        const grid = section.querySelector('[data-related-grid]');
        const sentinel = section.querySelector('[data-related-sentinel]');
        const status = section.querySelector('[data-related-status]');
        const retryButton = section.querySelector('[data-related-retry]');
        if (!grid || !sentinel || !status || !retryButton) return;

        let offset = Number.parseInt(section.dataset.relatedOffset || '0', 10) || 0;
        let hasMore = section.dataset.relatedHasMore === '1';
        let loading = false;
        let observer = null;
        let retryImmediately = false;
        const batchSize = Math.max(1, Math.min(12, Number.parseInt(vars.batch_size || '12', 10) || 12));
        const seen = new Set();

        grid.querySelectorAll('[data-related-product-id]').forEach(function (card) {
            const id = card.getAttribute('data-related-product-id');
            if (id) seen.add(id);
        });

        function setStatus(message, busy) {
            status.textContent = message || '';
            status.setAttribute('aria-busy', busy ? 'true' : 'false');
        }

        function stop(message) {
            hasMore = false;
            section.dataset.relatedHasMore = '0';
            if (observer) observer.disconnect();
            retryButton.hidden = true;
            setStatus(message || '', false);
        }

        async function loadNext() {
            if (loading || !hasMore) return;
            loading = true;
            retryImmediately = false;
            retryButton.hidden = true;
            setStatus('در حال بارگذاری کالاهای بیشتر…', true);

            try {
                const body = new URLSearchParams();
                body.set('action', 'evazar_related_products_load_more');
                body.set('nonce', String(vars.nonce || ''));
                body.set('product_id', String(vars.product_id || ''));
                body.set('offset', String(offset));

                const response = await fetch(String(vars.ajax_url || ''), {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: body.toString()
                });
                let payload;
                try {
                    payload = await response.json();
                } catch (parseError) {
                    if (!response.ok) throw new Error('HTTP ' + response.status);
                    throw parseError;
                }
                if (payload && payload.success !== true && payload.data && payload.data.code === 'core_offset_unavailable') {
                    stop(payload.data.message || 'برای بارگذاری پیوسته، نسخه جدید هسته ایوازار لازم است.');
                    return;
                }
                if (!response.ok) throw new Error('HTTP ' + response.status);
                if (!payload || payload.success !== true || !payload.data) {
                    throw new Error('Invalid related-products response');
                }

                const data = payload.data;
                const template = document.createElement('template');
                template.innerHTML = String(data.html || '').trim();
                const cards = Array.from(template.content.querySelectorAll('[data-related-product-id]'));
                let appended = 0;
                cards.forEach(function (card) {
                    const id = card.getAttribute('data-related-product-id');
                    if (!id || seen.has(id)) return;
                    seen.add(id);
                    grid.appendChild(card);
                    appended += 1;
                });

                const nextOffset = Number.parseInt(data.next_offset, 10);
                if (Number.isFinite(nextOffset) && nextOffset >= offset) offset = nextOffset;
                else offset += Number.parseInt(data.count || '0', 10) || 0;

                hasMore = data.has_more === true;
                section.dataset.relatedOffset = String(offset);
                section.dataset.relatedHasMore = hasMore ? '1' : '0';
                retryButton.hidden = true;

                if (!hasMore) {
                    stop(appended === 0 && offset === 0 ? 'کالای مرتبط دیگری پیدا نشد.' : 'به انتهای فهرست محصولات پیشنهادی رسیدید.');
                } else {
                    setStatus('', false);
                    // If a response contained only IDs already rendered, advance again instead
                    // of waiting for another IntersectionObserver crossing that may never occur.
                    retryImmediately = appended === 0 && Number(data.count || 0) > 0;
                }
            } catch (error) {
                setStatus('بارگذاری محصولات با مشکل روبه‌رو شد.', false);
                retryButton.hidden = false;
            } finally {
                loading = false;
                if (retryImmediately && hasMore) {
                    Promise.resolve().then(loadNext);
                }
            }
        }

        retryButton.addEventListener('click', loadNext);

        if (!hasMore) {
            stop('');
            return;
        }

        if ('IntersectionObserver' in window) {
            observer = new IntersectionObserver(function (entries) {
                if (entries.some(function (entry) { return entry.isIntersecting; })) loadNext();
            }, { root: null, rootMargin: '900px 0px', threshold: 0 });
            observer.observe(sentinel);
        } else {
            // Lightweight fallback for older browsers; the request guard prevents parallel calls.
            let ticking = false;
            const onScroll = function () {
                if (ticking || !hasMore) return;
                ticking = true;
                window.requestAnimationFrame(function () {
                    ticking = false;
                    if (sentinel.getBoundingClientRect().top < window.innerHeight + 900) loadNext();
                });
            };
            window.addEventListener('scroll', onScroll, { passive: true });
            window.addEventListener('resize', onScroll, { passive: true });
            onScroll();
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initRelatedProducts, { once: true });
    } else {
        initRelatedProducts();
    }
})();
