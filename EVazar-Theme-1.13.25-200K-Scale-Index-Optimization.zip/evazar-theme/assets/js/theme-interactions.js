/**
 * اسکریپت تعاملی و ناوبری ارگونومیک پوسته ایوازار (Evazar Theme Interactions)
 * ناوبری روان با دکمه‌های اسکرول (Prev / Next) و چرخ ماوس بدون تداخل لمسی در دسکتاپ
 * کلیک ۱۰۰٪ آنی، بومی و بدون هرگونه وقفه روی تمامی لینک‌ها و کارت‌ها
 */
document.addEventListener('DOMContentLoaded', function () {
    'use strict';


    // دکمه بازگشت به بالا در back-to-top.js مدیریت می‌شود.

    function bootInteractions() {
    // ۱. ناوبری دکمه‌ای و چرخ ماوس برای نوار زیردسته‌ها
    initRailNavigation({
        containerSelector: '.archive-subcats-bar .subcats-scroll-wrapper',
        sliderSelector: '.archive-subcats-bar .subcats-chips-wrapper',
        prevBtnSelector: '.archive-subcats-bar .subcats-btn-prev',
        nextBtnSelector: '.archive-subcats-bar .subcats-btn-next',
        step: 260
    });

    // ۲. ناوبری دکمه‌ای و چرخ ماوس برای ریل برندهای صفحه اصلی
    initRailNavigation({
        containerSelector: '.home-brands-section .home-brands-scroll-wrap',
        sliderSelector: '.home-brands-section .home-brands-rail',
        prevBtnSelector: '.home-brands-section .brands-nav-prev',
        nextBtnSelector: '.home-brands-section .brands-nav-next',
        step: 280
    });

    // ۳. ناوبری دکمه‌ای و چرخ ماوس برای بخش محصولات تخفیف شگفت‌انگیز صفحه اصلی
    initRailNavigation({
        containerSelector: '.home-deals-section .deals-slider-wrapper',
        sliderSelector: '.home-deals-section .deals-slider-rail',
        prevBtnSelector: '.home-deals-section .deals-nav-prev',
        nextBtnSelector: '.home-deals-section .deals-nav-next',
        step: 280
    });

    // ۴. ناوبری دکمه‌ای و چرخ ماوس برای قفسه‌های موضوعی و جدیدترین‌های صفحه اصلی (Shelves & Latest)
    var shelfWraps = document.querySelectorAll('.home-category-shelf-section .shelf-slider-wrap, .home-latest-products-section .shelf-slider-wrap');
    if (shelfWraps.length) {
        shelfWraps.forEach(function (wrap) {
            var rail = wrap.querySelector('.shelf-slider-rail');
            var prev = wrap.querySelector('.shelf-nav-prev');
            var next = wrap.querySelector('.shelf-nav-next');
            if (rail) {
                initRailElement(rail, wrap, prev, next, 270);
            }
        });
    }

    // ۴-الف: ناوبری اسلایدر ریل برای تب‌های دسته‌بندی صفحه اصلی (Cat Tabs Rails)
    var catTabWraps = document.querySelectorAll('.cat-tabs-section .cat-tab-slider-wrap');
    if (catTabWraps.length) {
        catTabWraps.forEach(function (wrap) {
            var rail = wrap.querySelector('.cat-tab-slider-rail');
            var prev = wrap.querySelector('.cat-tab-nav-prev');
            var next = wrap.querySelector('.cat-tab-nav-next');
            if (rail) {
                initRailElement(rail, wrap, prev, next, 270);
            }
        });
    }

    // ۵. تعویض آنی و بدون پرش تب‌های دسته‌بندی در صفحه اصلی (Tabs)
    initCategoryTabs();

    function initCategoryTabs() {
        var tabBtns = document.querySelectorAll('.cat-tabs-section .cat-tab-btn');
        if (!tabBtns.length) return;

        tabBtns.forEach(function (btn) {
            btn.addEventListener('click', function (e) {
                e.preventDefault();
                var targetId = this.getAttribute('data-tab');
                var container = this.closest('.cat-tabs-section');
                if (!container) return;

                container.querySelectorAll('.cat-tab-btn').forEach(function (b) {
                    b.classList.remove('is-active');
                });
                this.classList.add('is-active');

                container.querySelectorAll('.cat-tab-panel').forEach(function (p) {
                    p.classList.remove('is-active');
                });
                var targetPanel = container.querySelector('#' + targetId);
                if (targetPanel) {
                    targetPanel.classList.add('is-active');
                    var activeRail = targetPanel.querySelector('.cat-tab-slider-rail');
                    if (activeRail && activeRail._updateButtons) {
                        setTimeout(activeRail._updateButtons, 60);
                    }
                }

                var catUrl = this.getAttribute('data-url');
                var viewAllLink = container.querySelector('.section-view-all-link');
                if (viewAllLink && catUrl) {
                    viewAllLink.href = catUrl;
                    var catName = this.querySelector('.cat-tab-name');
                    if (catName) {
                        viewAllLink.textContent = 'مشاهده همه کالاهای ' + catName.textContent.trim() + ' ←';
                    }
                }
            });
        });
    }

    }

    // این اسکریپت فقط بعد از اولین فرصت idle اجرا شود؛ HTML/CSS بالای صفحه
    // نباید برای محاسبه overflow ریل‌های پایین صفحه منتظر JavaScript بماند.
    function scheduleBoot() {
        var run = function () {
            if (window.requestIdleCallback) {
                window.requestIdleCallback(bootInteractions, { timeout: 1800 });
            } else {
                window.setTimeout(bootInteractions, 800);
            }
        };
        if (document.readyState === 'complete') {
            run();
        } else {
            window.addEventListener('load', run, { once: true });
        }
    }

    scheduleBoot();

    function initRailElement(slider, container, prevBtn, nextBtn, step) {
        if (!slider) return;
        step = step || 260;
        slider._updateButtons = updateButtons;


        // Special Offers pages are aligned to card edges. On desktop the
        // viewport is sized to whole cards, so page by the number of fully
        // visible cards (up to six) instead of skipping an item when only five
        // cards physically fit. Other rails keep their previous behavior.
        function navigateDealsByCards(direction) {
            var cards = Array.prototype.slice.call(slider.children).filter(function (el) {
                return el.getBoundingClientRect().width > 0;
            });
            if (!cards.length) {
                slider.scrollBy({ left: direction * step, behavior: 'smooth' });
                return;
            }

            var railRect = slider.getBoundingClientRect();
            var styles = window.getComputedStyle(slider);
            var paddingRight = parseFloat(styles.paddingRight) || 0;
            var rightEdge = railRect.right - paddingRight;
            var anchorIndex = 0;
            var smallestDistance = Infinity;

            // Find the card aligned to (or closest to) the rail's right content edge.
            cards.forEach(function (card, index) {
                var rect = card.getBoundingClientRect();
                var distance = Math.abs(rect.right - rightEdge);
                if (distance < smallestDistance) {
                    smallestDistance = distance;
                    anchorIndex = index;
                }
            });

            var cardWidth = cards[0].offsetWidth;
            var gap = parseFloat(styles.columnGap || styles.gap || '0') || 0;
            var paddingLeft = parseFloat(styles.paddingLeft) || 0;
            var contentWidth = Math.max(0, slider.clientWidth - paddingLeft - paddingRight);
            var visibleWholeCards = cardWidth > 0
                ? Math.max(1, Math.floor((contentWidth + gap + 0.5) / (cardWidth + gap)))
                : 1;
            var pageSize = Math.min(6, visibleWholeCards);

            // Card indexes increase from right to left in this RTL rail.
            // direction: -1 = Next (move left), +1 = Prev (move right).
            var requestedIndex = anchorIndex - (direction * pageSize);
            var maxScroll = Math.max(0, slider.scrollWidth - slider.clientWidth);

            // When the next full page reaches the end, align to the true endpoint
            // so the final page contains complete cards, not a clipped last item.
            if (direction < 0 && requestedIndex + visibleWholeCards >= cards.length) {
                slider.scrollTo({ left: -maxScroll, behavior: 'smooth' });
                return;
            }
            if (direction > 0 && requestedIndex <= 0) {
                var startDelta = -slider.scrollLeft;
                if (Math.abs(startDelta) > 1) {
                    slider.scrollBy({ left: startDelta, behavior: 'smooth' });
                }
                return;
            }

            var targetIndex = Math.max(0, Math.min(cards.length - 1, requestedIndex));
            var targetRect = cards[targetIndex].getBoundingClientRect();
            var delta = targetRect.right - rightEdge;
            if (Math.abs(delta) > 1) {
                slider.scrollBy({ left: delta, behavior: 'smooth' });
            }
        }

        // Preserve the established six-card step for shelves and category-tab rails.
        // The card-edge alignment routine above is intentionally limited to Special Offers.
        function getNavigationStep() {
            if (slider.matches('.deals-slider-rail, .shelf-slider-rail, .cat-tab-slider-rail')) {
                var cards = Array.prototype.slice.call(slider.children).filter(function (el) {
                    return el.getBoundingClientRect().width > 0;
                });
                if (cards.length) {
                    var styles = window.getComputedStyle(slider);
                    var gap = parseFloat(styles.columnGap || styles.gap || '0') || 0;
                    var pageCount = Math.min(6, cards.length);
                    var distance = 0;
                    for (var i = 0; i < pageCount; i++) {
                        distance += cards[i].getBoundingClientRect().width;
                        if (i < pageCount - 1) distance += gap;
                    }
                    if (distance > 0) return Math.round(distance);
                }
            }
            return step;
        }

        function syncDealsViewportLayout() {
            if (!slider.matches('.deals-slider-rail')) return;

            var isDesktop = window.matchMedia('(min-width: 769px)').matches;
            if (!isDesktop) {
                // Preserve the existing mobile layout (the showcase itself scrolls on mobile).
                slider.style.width = '';
                slider.style.flex = '';
                if (prevBtn) prevBtn.style.right = '';
                if (nextBtn) nextBtn.style.left = '';
                return;
            }

            var cards = Array.prototype.slice.call(slider.children).filter(function (el) {
                return el.getBoundingClientRect().width > 0;
            });
            if (!cards.length || !container) return;

            var railStyle = window.getComputedStyle(slider);
            var wrapperStyle = window.getComputedStyle(container);
            var railPadding = (parseFloat(railStyle.paddingLeft) || 0) + (parseFloat(railStyle.paddingRight) || 0);
            var wrapperPadding = (parseFloat(wrapperStyle.paddingLeft) || 0) + (parseFloat(wrapperStyle.paddingRight) || 0);
            var availableWidth = Math.max(0, container.clientWidth - wrapperPadding);
            var cardWidth = cards[0].offsetWidth;
            var gap = parseFloat(railStyle.columnGap || railStyle.gap || '0') || 0;
            if (!cardWidth || !availableWidth) return;

            // Fit a whole number of cards + gaps into the desktop viewport so
            // navigation cannot leave a fractional product clipped at either edge.
            var availableContentWidth = Math.max(0, availableWidth - railPadding);
            var wholeCardSlots = Math.max(1, Math.floor((availableContentWidth + gap + 0.5) / (cardWidth + gap)));

            // The desktop design targets six products per view. Never let the
            // load-time measurement grow the viewport beyond six cards, and use
            // the widened showcase gutter to make six whole cards fit on wide screens.
            var visibleCount = Math.min(6, wholeCardSlots);
            if (cards.length > visibleCount) {
                var exactRailWidth = (visibleCount * cardWidth) + ((visibleCount - 1) * gap) + railPadding;
                slider.style.width = exactRailWidth + 'px';
                slider.style.flex = '0 0 ' + exactRailWidth + 'px';
            } else {
                // If every product fits, retain the original full-width rail.
                slider.style.width = '';
                slider.style.flex = '';
            }

            // Overlay both navigation buttons on the outer product cards instead
            // of reserving blank side gutters. Align each button to the rail's
            // padded edge, even when fewer than six cards fit at this viewport.
            var railRect = slider.getBoundingClientRect();
            var wrapperRect = container.getBoundingClientRect();
            var leftInset = parseFloat(railStyle.paddingLeft) || 8;
            var rightInset = parseFloat(railStyle.paddingRight) || 8;
            if (nextBtn) {
                nextBtn.style.left = Math.max(0, railRect.left - wrapperRect.left + leftInset) + 'px';
            }
            if (prevBtn) {
                prevBtn.style.right = Math.max(0, wrapperRect.right - railRect.right + rightInset) + 'px';
            }
        }

        function navigateRail(direction) {
            if (slider.matches('.deals-slider-rail')) {
                navigateDealsByCards(direction);
            } else {
                // Keep the previous six-card behavior for every non-deals rail.
                slider.scrollBy({ left: direction * getNavigationStep(), behavior: 'smooth' });
            }
            setTimeout(updateButtons, 350);
        }

        if (prevBtn) {
            prevBtn.addEventListener('click', function (e) {
                e.preventDefault();
                navigateRail(1);
            });
        }

        if (nextBtn) {
            nextBtn.addEventListener('click', function (e) {
                e.preventDefault();
                navigateRail(-1);
            });
        }

        function updateButtons() {
            if (!prevBtn && !nextBtn) return;
            var isOverflowing = slider.scrollWidth > (slider.clientWidth + 4);
            if (!isOverflowing) {
                if (prevBtn) prevBtn.style.display = 'none';
                if (nextBtn) nextBtn.style.display = 'none';
                if (container) container.classList.remove('can-scroll-prev', 'can-scroll-next');
                return;
            }

            var maxScroll = slider.scrollWidth - slider.clientWidth;
            var currentScroll = Math.abs(slider.scrollLeft);

            var atStart = currentScroll <= 4;
            var atEnd = currentScroll >= (maxScroll - 6);

            if (prevBtn) {
                prevBtn.style.display = 'flex';
                prevBtn.disabled = atStart;
                prevBtn.classList.toggle('is-disabled', atStart);
            }
            if (nextBtn) {
                nextBtn.style.display = 'flex';
                nextBtn.disabled = atEnd;
                nextBtn.classList.toggle('is-disabled', atEnd);
            }

            if (container) {
                container.classList.toggle('can-scroll-prev', !atStart);
                container.classList.toggle('can-scroll-next', !atEnd);
            }
        }

        if (slider.matches('.deals-slider-rail')) {
            syncDealsViewportLayout();
            window.addEventListener('resize', function () {
                syncDealsViewportLayout();
                updateButtons();
            });
        }

        slider.addEventListener('scroll', updateButtons, { passive: true });
        window.addEventListener('resize', updateButtons);
        setTimeout(updateButtons, 120);
    }

    function initRailNavigation(config) {
        var slider = document.querySelector(config.sliderSelector);
        if (!slider) return;

        var container = document.querySelector(config.containerSelector) || slider.parentElement;
        var prevBtn = container ? container.querySelector(config.prevBtnSelector) : document.querySelector(config.prevBtnSelector);
        var nextBtn = container ? container.querySelector(config.nextBtnSelector) : document.querySelector(config.nextBtnSelector);
        var step = config.step || 250;

        initRailElement(slider, container, prevBtn, nextBtn, step);
    }
});
