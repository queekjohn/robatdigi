# EVazar Theme 1.13.13 — Legacy offers 301 redirect

- Adds a permanent 301 redirect from legacy sale URLs (`/?on_sale=1`, `/product/?on_sale=1`, and paginated `/product/page/N/?on_sale=1`) to the clean `/offers/` archive and matching `/offers/page/N/` page.
- Preserves other query parameters such as filters/sorting while removing the legacy `on_sale` and `paged` parameters.
- Ordinary `/product/` archive requests without `on_sale=1` are unchanged.
- No Core plugin, database, product data, or Worker changes.

Validation: PHP syntax and ZIP integrity checked; live WordPress/browser behavior still needs verification after installation.
