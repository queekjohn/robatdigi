# EVazar Theme 1.12.73

- Aligned the theme fallback `evazar_cdn_image_url()` implementation with Core 2.9.0 so the active function's `x-oss-process` sizing behavior is consistent.
- The URL helper respects `evazar_image_direct_mode` and directs new image markup to the original Digikala image host while direct mode is active.
- Kept the page-wide image failover script, gallery behavior, lazy loading, and other product UI code unchanged.
- No theme search, archive infinite-scroll, gallery layout, or product price-display logic was otherwise changed in this version.
