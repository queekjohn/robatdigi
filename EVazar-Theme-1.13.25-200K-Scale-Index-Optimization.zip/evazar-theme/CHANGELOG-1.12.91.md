# EVazar Theme 1.12.91 — Desktop Special Offers navigation

- Inspected the 1.12.90 carousel CSS and JavaScript. The desktop Special Offers rail used mandatory CSS scroll snapping while the navigation buttons also paged by six cards; those behaviors can compete over the final resting position.
- Disabled scroll snapping only on `.home-deals-section .deals-slider-rail` at desktop widths (769px and above), leaving the six-card navigation calculation unchanged.
- Preserved the mobile scroll-snap rules and did not modify product gallery code or other homepage carousels.
- Static package and syntax checks are required; live-site/browser verification has not been performed.
