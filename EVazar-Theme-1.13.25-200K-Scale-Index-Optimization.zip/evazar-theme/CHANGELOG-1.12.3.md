# Changelog 1.12.3

## Back-to-top visibility fix
- Fixed the back-to-top button not appearing on product and other non-home/archive pages.
- Added a dedicated lightweight `back-to-top.js` asset loaded globally.
- Removed the back-to-top logic from the archive/home interaction bundle to avoid unnecessary coupling.
- Preserved the 400px scroll threshold, left-side positioning, mobile sticky-buybar spacing, safe-area handling, and smooth scrolling.
