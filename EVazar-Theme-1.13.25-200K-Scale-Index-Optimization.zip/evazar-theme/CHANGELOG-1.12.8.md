# Changelog 1.12.8

## Related Products — Core Product Index Engine
- انتخاب محصولات مرتبط از Theme خارج شد و به EVazar Core منتقل شد.
- Theme فقط تنظیمات نمایش/تعداد/عدم‌نمایش ناموجودها و رندر کارت‌ها را مدیریت می‌کند.
- منطق رتبه‌بندی Core: دسته/زیرشاخه + برند > دسته/زیرشاخه > دسته مشترک > شاخه مرتبط > برند > جدیدترین.
- فیلتر موجودی از `stock_status` هسته استفاده می‌کند.
- Queryهای per-candidate روی postmeta و taxonomy برای Related Products حذف شدند.
