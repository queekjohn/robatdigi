# EVazar Theme 1.12.14

- Fixed the homepage render path for LCP by inlining critical above-the-fold CSS for the top notice, header and homepage hero.
- Converted homepage theme stylesheets (local fonts, main theme CSS, search CSS and front-page CSS) to non-blocking preload-to-stylesheet loading with a `<noscript>` fallback.
- Kept the existing full stylesheets and their cascade intact so the visual design and below-the-fold components continue to use the original CSS.
- Removed the extra homepage logo `<h1>` and replaced it with a styled non-heading element so the hero remains the sole primary homepage H1.
- Kept affiliate/product/import logic unchanged.
