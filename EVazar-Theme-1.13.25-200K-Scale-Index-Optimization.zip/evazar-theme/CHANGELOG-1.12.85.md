# EVazar Theme 1.12.85 — preserve visible image during slow gallery transitions

## Audit finding and fix
A second-pass audit found that 1.12.84 could time out and crossfade to a buffer layer before that image had loaded, temporarily hiding the previous valid image behind a blank layer.

The crossfade now keeps the current visible image in place while the selected image is pending. It reveals the selected image only after it has real intrinsic dimensions, including when it loads after a timeout or after Core recovery. Transition tokens prevent a late response from overriding a newer thumbnail selection, and late-load listeners are removed when superseded to avoid accumulating handlers.

## Scope
Only `single-evazar_product.php`, the `style.css` version header, and this changelog changed from 1.12.84. No gallery markup, CSS rules, touch gestures, archive filters, product data, or importer behavior changed.

## Validation
PHP syntax, extracted inline JavaScript syntax, ZIP integrity, and package root were checked. Static checks do not replace a live browser test on evazar.ir.
