# EVazar Theme 1.12.0

## CSS / performance optimization
- Split the monolithic `style.css` into page-scoped styles for single product, archive/search, front page, about, brand directory, and 404 pages.
- Added conditional enqueueing so page-specific CSS is sent only on the pages that use it.
- Removed only legacy CSS selectors proven absent from the theme PHP/JS source, while preserving WordPress/runtime state classes and classes generated dynamically from options.
- Kept the existing visual CSS declarations intact; this release is an organization/loading optimization rather than a redesign.
- `theme-interactions.js` is now loaded only where its homepage/archive interactions are used.
- Search CSS/JS is loaded only when the header search feature is enabled.
- Preserved the 1.11.1 duplicate mobile search fix for the 769–991px range.
- Bumped theme version to 1.12.0 for deterministic cache invalidation.
