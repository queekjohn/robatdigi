<?php
/**
 * Template Name: صفحه تکی کالا ایوازار
 */
get_header(); 

// دریافت دیتاهای کالا از افزونه evazar-core
$post_id = get_the_ID();
$dk_url = get_post_meta($post_id, '_evazar_dk_url', true);
$en_title = get_post_meta($post_id, '_evazar_en_title', true);
$old_price = get_post_meta($post_id, '_evazar_old_price', true);
$current_price = get_post_meta($post_id, '_evazar_current_price', true);
// وضعیت ذخیره‌شده موجودی؛ اگر هنوز متا ساخته نشده باشد، برای سازگاری با محصولات قدیمی از وجود قیمت استفاده می‌کنیم.
$stored_available_meta = get_post_meta($post_id, '_evazar_is_available', true);
$product_available = ($stored_available_meta === '') ? ((float)$current_price > 0) : in_array((string)$stored_available_meta, ['1', 'yes', 'true'], true);
$discount_percent = get_post_meta($post_id, '_evazar_discount_percent', true);
$rating = get_post_meta($post_id, '_evazar_rating', true);
$rating_count = get_post_meta($post_id, '_evazar_rating_count', true);
$satisfaction = get_post_meta($post_id, '_evazar_satisfaction', true);
$sku = get_post_meta($post_id, '_sku', true) ?: get_post_meta($post_id, '_evazar_sku', true);
if (empty($sku) && !empty($dk_url) && preg_match('/dkp-(\d+)/i', $dk_url, $m_dkp)) {
    $sku = $m_dkp[1];
}
$brand = get_post_meta($post_id, '_evazar_brand', true);
$brand_en = get_post_meta($post_id, '_evazar_brand_en', true);

// ثبت بازدید در سمت کلاینت انجام می‌شود تا رندر صفحه باعث Write دیتابیس نشود.

// اطلاعات تکمیلی فروشنده از متادیتا (استعلام بلادرنگ به صورت ایجکس غیرمسدودکننده در کلاینت انجام می‌شود)
if (empty($seller_name)) {
    $seller_name = get_post_meta($post_id, '_evazar_seller_name', true) ?: 'دیجی‌کالا';
}
if (empty($seller_rate_text)) {
    $seller_rate_text = get_post_meta($post_id, '_evazar_seller_rate_text', true);
// متادیتای قدیمی ممکن است خودش شامل «فروشنده: نام» باشد؛ این متن دیگر نباید تکرار شود.
if ($seller_rate_text && preg_match('/^\s*فروشنده\s*[:：]/u', $seller_rate_text)) {
    $seller_rate_text = '';
}
}

// خواندن تنظیمات اختصاصی برگه تکی محصول
$opt_zoom             = get_option('evazar_opt_product_zoom', '1');
$opt_lightbox         = get_option('evazar_opt_product_lightbox', '1');
$opt_show_discount    = get_option('evazar_opt_product_show_discount', '1');
$opt_show_ratings     = get_option('evazar_opt_product_show_ratings', '1');
$opt_show_sku         = get_option('evazar_opt_product_show_sku', '1');
$opt_show_features    = get_option('evazar_opt_product_show_features', '1');
$opt_show_ai          = get_option('evazar_opt_product_show_ai', '1');
$opt_seller_name      = get_option('evazar_opt_product_seller_name', 'دیجی‌کالا');
$opt_show_seller      = get_option('evazar_opt_product_show_seller', '1');
$opt_buybox_guarantee_header = get_option('evazar_opt_buybox_guarantee_header', 'قیمت و موجودی به‌روز از دیجی‌کالا');
$opt_buybox_feature_1        = get_option('evazar_opt_buybox_feature_1', 'قیمت و وضعیت موجودی به‌صورت آنلاین بررسی می‌شود');
$opt_buybox_feature_2        = get_option('evazar_opt_buybox_feature_2', 'برای خرید به سایت فروشنده منتقل می‌شوید');
$opt_buybox_feature_3        = get_option('evazar_opt_buybox_feature_3', 'پرداخت، ارسال و مرجوعی توسط فروشنده انجام می‌شود');
$opt_product_trust_badge_1 = get_option('evazar_opt_product_trust_badge_1', 'اطلاعات قیمت و موجودی به‌روز');
$opt_product_trust_badge_2 = get_option('evazar_opt_product_trust_badge_2', 'خرید در سایت فروشنده');
$opt_product_trust_badge_3 = get_option('evazar_opt_product_trust_badge_3', 'ارسال و مرجوعی طبق شرایط فروشنده');
$opt_buybox_price_label      = get_option('evazar_opt_buybox_price_label', 'قیمت رسمی در دیجی‌کالا:');
$opt_btn_title        = get_option('evazar_opt_product_btn_title', 'مشاهده قیمت و خرید در دیجی‌کالا');
$opt_btn_subtitle     = get_option('evazar_opt_product_btn_subtitle', 'برای ادامه خرید به سایت دیجی‌کالا منتقل می‌شوید');
$opt_guarantee_text   = get_option('evazar_opt_product_guarantee_text', 'ایوازار فروشنده کالا نیست؛ برای خرید، شما به سایت دیجی‌کالا منتقل می‌شوید و پرداخت و ارسال در همان سایت انجام می‌شود.');
$opt_show_related     = get_option('evazar_opt_product_show_related', '1');
$opt_related_count    = intval(get_option('evazar_opt_product_related_count', 4));

// استخراج دسته‌بندی‌ها و ساخت سلسله‌مراتب دقیق بردکرامب (Zero Fail Breadcrumb)
$breadcrumbs = [];

// ۱. ابتدا بررسی ترم‌های اختصاص‌یافته به کالا در تاکسونومی evazar_category
$product_terms = get_the_terms($post_id, 'evazar_category');

// در فرانت‌اند هیچ Sync/Repair دیتابیسی انجام نمی‌شود؛ فقط داده‌های موجود خوانده می‌شوند.

// ساخت زنجیره کامل والد تا فرزند نهایی
if (!empty($product_terms) && !is_wp_error($product_terms)) {
    // پیدا کردن عمیق‌ترین دسته‌بندی (برگ نهایی)
    $deepest_term = null;
    $max_depth = -1;

    foreach ($product_terms as $t) {
        $ancestors = get_ancestors($t->term_id, 'evazar_category');
        $depth = count($ancestors);
        if ($depth > $max_depth) {
            $max_depth = $depth;
            $deepest_term = $t;
        }
    }

    if ($deepest_term) {
        $ancestor_ids = array_reverse(get_ancestors($deepest_term->term_id, 'evazar_category'));
        foreach ($ancestor_ids as $anc_id) {
            $anc = get_term($anc_id, 'evazar_category');
            if ($anc && !is_wp_error($anc)) {
                $breadcrumbs[] = [
                    'title' => $anc->name,
                    'url'   => get_term_link($anc)
                ];
            }
        }
        $breadcrumbs[] = [
            'title' => $deepest_term->name,
            'url'   => get_term_link($deepest_term)
        ];
    }
}

// اگر دسته‌ای در ترم‌ها پیدا نشد، از اطلاعات ذخیره‌شده در متادیتا استفاده کن
if (empty($breadcrumbs)) {
    $bc_meta = get_post_meta($post_id, '_evazar_breadcrumbs', true);
    if (!empty($bc_meta)) {
        $decoded = is_array($bc_meta) ? $bc_meta : json_decode($bc_meta, true);
        if (is_array($decoded) && !empty($decoded)) {
            foreach ($decoded as $item) {
                $item_title = is_array($item) ? ($item['title'] ?? '') : (string)$item;
                $item_url   = is_array($item) ? ($item['url'] ?? '') : '';
                $item_title = trim($item_title);

                if (empty($item_title) || $item_title === 'دیجی‌کالا' || stripos($item_title, 'dkp-') === 0) {
                    continue;
                }
                if ($brand && mb_strtolower($item_title) === mb_strtolower($brand)) {
                    continue;
                }
                if (strpos($item_url, '/product/') !== false || $item_title === get_the_title($post_id)) {
                    continue;
                }

                if (empty($item_url) || strpos($item_url, 'digikala.com') !== false) {
                    $term_obj = get_term_by('name', $item_title, 'evazar_category');
                    if ($term_obj && !is_wp_error($term_obj)) {
                        $item_url = get_term_link($term_obj);
                    } else {
                        $item_url = home_url('/product-category/' . sanitize_title($item_title));
                    }
                }

                $breadcrumbs[] = [
                    'title' => $item_title,
                    'url'   => $item_url
                ];
            }
        }
    }
}

// اگر هنوز خالی است، دسته پیش‌فرض متادیتا
if (empty($breadcrumbs)) {
    $cat_name = get_post_meta($post_id, '_evazar_category', true);
    if (!empty($cat_name) && $cat_name !== 'عمومی' && $cat_name !== 'دسته‌بندی نشده') {
        $term_obj = get_term_by('name', $cat_name, 'evazar_category');
        $cat_url = ($term_obj && !is_wp_error($term_obj)) ? get_term_link($term_obj) : home_url('/product-category/' . sanitize_title($cat_name));
        $breadcrumbs[] = [
            'title' => $cat_name,
            'url'   => $cat_url
        ];
    }
}

// تضمین وجود زیردسته لندینگ برند + دسته در انتهای بردکرامب
if (!empty($breadcrumbs) && !empty($brand) && !in_array($brand, ['متفرقه', 'دیجی‌کالا', 'دیجیکالا', 'عمومی'])) {
    $last_bc = end($breadcrumbs);
    if (!empty($last_bc['title']) && mb_stripos($last_bc['title'], $brand) === false) {
        $subcat_title = $last_bc['title'] . ' ' . $brand;
        $term_sub = get_term_by('name', $subcat_title, 'evazar_category');
        $sub_link = ($term_sub && !is_wp_error($term_sub)) ? get_term_link($term_sub) : home_url('/product-category/' . sanitize_title($subcat_title));
        $breadcrumbs[] = [
            'title' => $subcat_title,
            'url'   => $sub_link
        ];
    }
}

$key_feature_groups = function_exists('evazar_get_key_feature_groups')
    ? evazar_get_key_feature_groups($post_id)
    : [['title' => '', 'features' => evazar_get_key_features($post_id)]];
$key_features = [];
foreach ($key_feature_groups as $feature_group) {
    if (!empty($feature_group['features']) && is_array($feature_group['features'])) {
        $key_features = array_merge($key_features, $feature_group['features']);
    }
}
$pros = evazar_get_multiline_meta($post_id, '_evazar_pros');
$cons = evazar_get_multiline_meta($post_id, '_evazar_cons');

// دریافت لینک دیپ‌لینک اختصاصی
// لینک داخلی انتقال: ثبت کلیک + صفحه انتقال ۲ ثانیه‌ای + سپس لینک افیلیت
$affiliate_link = function_exists('evazar_get_affiliate_redirect_url') ? evazar_get_affiliate_redirect_url($post_id) : (function_exists('evazar_get_final_affiliate_link') ? evazar_get_final_affiliate_link($post_id) : $dk_url);

// تصویر شاخص بر پایه معماری Zero Host Storage (مستقیماً از CDN یا کش کلودفلر)
$thumbnail_source_url = get_post_meta($post_id, '_evazar_main_image', true);
if (!$thumbnail_source_url) {
    $thumbnail_source_url = get_the_post_thumbnail_url($post_id, 'large');
}
if (!$thumbnail_source_url) {
    $thumbnail_source_url = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect fill="%23f8fafc" width="600" height="600"/><text fill="%2394a3b8" font-family="sans-serif" font-size="20" dy="8" font-weight="bold" x="50%" y="50%" text-anchor="middle">تصویر کالا</text></svg>';
}
$thumbnail_url = $thumbnail_source_url;
if (function_exists('evazar_cdn_image_url') && strpos($thumbnail_url, 'data:image') === false) {
    $thumbnail_url = evazar_cdn_image_url($thumbnail_source_url, 800);
}
$thumbnail_srcset = (function_exists('evazar_cdn_image_srcset') && strpos($thumbnail_source_url, 'data:image') === false)
    ? evazar_cdn_image_srcset($thumbnail_source_url, [360, 600, 800])
    : '';

// گالری تصاویر (پشتیبانی هوشمند از آرایه JSON و تفکیک امن متنی با حفظ پارامترهای ابعاد عکس دیجی‌کالا)
$gallery_raw = get_post_meta($post_id, '_evazar_gallery', true);
$gallery_images = [];

if (!empty($gallery_raw)) {
    if (is_array($gallery_raw)) {
        $raw_list = $gallery_raw;
    } else {
        $decoded = json_decode($gallery_raw, true);
        if (is_array($decoded)) {
            $raw_list = $decoded;
        } else {
            $raw_list = preg_split('/,(?=https?:\/\/)/i', $gallery_raw);
        }
    }

    if (!empty($raw_list) && is_array($raw_list)) {
        foreach ($raw_list as $img_item) {
            $img_item = trim((string)$img_item);
            if (empty($img_item) || !filter_var($img_item, FILTER_VALIDATE_URL)) {
                continue;
            }
            if (function_exists('evazar_cdn_image_url')) {
                // تمام تصاویر گالری که با کلیک در نمای اصلی نمایش داده می‌شوند،
                // حداکثر نسخه 800px را دریافت کنند؛ هرگز URL اصلی و حجیم لود نشود.
                $img_item = evazar_cdn_image_url($img_item, 800);
            }
            if (!in_array($img_item, $gallery_images)) {
                $gallery_images[] = $img_item;
            }
        }
    }
}

// قرار دادن تصویر اصلی در ابتدای گالری
if (!empty($thumbnail_url) && strpos($thumbnail_url, 'data:image') === false) {
    if (!in_array($thumbnail_url, $gallery_images)) {
        array_unshift($gallery_images, $thumbnail_url);
    }
}
?>

<!-- PRODUCT CONTENT -->
<div class="evazar-container">
    
    <!-- TOP BREADCRUMBS -->
    <nav class="evazar-top-breadcrumbs" aria-label="موقعیت فعلی در سایت">
        <ol itemscope itemtype="https://schema.org/BreadcrumbList">
            <li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                <a itemprop="item" href="<?php echo esc_url(home_url('/')); ?>"><span itemprop="name">ایوازار</span></a>
                <meta itemprop="position" content="1" />
            </li>
            <?php 
            $pos = 2;
            $clean_breadcrumbs = [];
            $prod_title = get_the_title($post_id);
            if (!empty($breadcrumbs)) {
                foreach ($breadcrumbs as $bc) {
                    $bc_title = is_array($bc) ? ($bc['title'] ?? '') : (string)$bc;
                    $bc_url   = is_array($bc) ? ($bc['url'] ?? '') : '';
                    $bc_title = trim($bc_title);
                    if (empty($bc_title) || $bc_title === 'دیجی‌کالا' || stripos($bc_title, 'dkp-') === 0) continue;
                    if ($bc_title === $prod_title || strpos($bc_url, '/product/') !== false) continue;
                    if (empty($bc_url)) {
                        $term_obj = get_term_by('name', $bc_title, 'evazar_category');
                        $bc_url = ($term_obj && !is_wp_error($term_obj)) ? get_term_link($term_obj) : home_url('/product-category/' . sanitize_title($bc_title));
                    }
                    $clean_breadcrumbs[] = [
                        'title' => $bc_title,
                        'url'   => $bc_url
                    ];
                }
            }

            $total_bc = count($clean_breadcrumbs);
            if ($total_bc > 0) {
                foreach ($clean_breadcrumbs as $idx => $bc) {
                    $is_last = ($idx === $total_bc - 1);
                    echo '<li class="breadcrumb-sep">/</li>';
                    if ($is_last) {
                        echo '<li class="current-item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
                        echo '<a itemprop="item" href="' . esc_url($bc['url']) . '"><span itemprop="name">' . esc_html($bc['title']) . '</span></a>';
                        echo '<meta itemprop="position" content="' . $pos++ . '" />';
                        echo '</li>';
                    } else {
                        echo '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
                        echo '<a itemprop="item" href="' . esc_url($bc['url']) . '"><span itemprop="name">' . esc_html($bc['title']) . '</span></a>';
                        echo '<meta itemprop="position" content="' . $pos++ . '" />';
                        echo '</li>';
                    }
                }
            } elseif (!empty($brand)) {
                $brand_url = home_url('/brand/' . sanitize_title($brand_en ? $brand_en : $brand));
                echo '<li class="breadcrumb-sep">/</li>';
                echo '<li class="current-item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
                echo '<a itemprop="item" href="' . esc_url($brand_url) . '"><span itemprop="name">' . esc_html($brand) . '</span></a>';
                echo '<meta itemprop="position" content="' . $pos++ . '" />';
                echo '</li>';
            }
            ?>
        </ol>
    </nav>

    <!-- 3-COL PRODUCT TOP -->
    <div class="product-grid-top">
        
        <!-- 1. GALLERY -->
        <div class="gallery-col">
            <div class="gallery-main-wrap" id="evazar-gallery-main">
                <?php 
                $g_clean_badge = function_exists('evazar_get_clean_discount_badge') 
                    ? evazar_get_clean_discount_badge($discount_percent, $old_price, $current_price) 
                    : '';
                if (!empty($g_clean_badge) && $opt_show_discount === '1'): 
                ?>
                    <div class="badge-onsale">
                        <span class="badge-text"><?php echo esc_html($g_clean_badge . ' تخفیف'); ?></span>
                        <span class="badge-fire-icon">🔥</span>
                    </div>
                <?php endif; ?>

                <div class="gallery-img-container" id="evazar-zoom-container" title="مشاهده بزرگ‌تر و تمام‌صفحه">
                    <img src="<?php echo esc_url($thumbnail_url); ?>"<?php echo $thumbnail_srcset ? ' srcset="' . esc_attr($thumbnail_srcset) . '" sizes="(max-width: 600px) 100vw, 800px"' : ''; ?> id="evazar-main-img" class="gallery-main-img gallery-main-img-active" alt="<?php echo esc_attr(get_the_title()); ?>" data-index="0" width="800" height="800" loading="eager" fetchpriority="high" decoding="async" referrerpolicy="no-referrer">
                    <img id="evazar-main-img-buffer" class="gallery-main-img gallery-main-img-buffer" alt="" aria-hidden="true" width="800" height="800" decoding="async">
                </div>
            </div>

            <?php if (!empty($gallery_images) && count($gallery_images) > 1): ?>
                <div class="gallery-thumbs-wrapper">
                    <button type="button" class="gallery-thumb-arrow thumb-arrow-prev" id="thumb-arrow-prev" aria-label="قبلی">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
                    </button>
                    <div class="gallery-thumbs-track" id="evazar-gallery-thumbs">
                        <?php foreach ($gallery_images as $idx => $g_img): ?>
                            <div class="gallery-thumb-item <?php echo $idx === 0 ? 'active' : ''; ?>" data-src="<?php echo esc_url($g_img); ?>" data-index="<?php echo $idx; ?>">
                                <img src="<?php echo esc_url(function_exists('evazar_cdn_image_url') ? evazar_cdn_image_url($g_img, 160) : $g_img); ?>" data-src="<?php echo esc_url(function_exists('evazar_cdn_image_url') ? evazar_cdn_image_url($g_img, 160) : $g_img); ?>" alt="تصویر شماره <?php echo $idx + 1; ?>" width="160" height="160" loading="lazy" decoding="async" referrerpolicy="no-referrer">
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button type="button" class="gallery-thumb-arrow thumb-arrow-next" id="thumb-arrow-next" aria-label="بعدی">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
                    </button>
                </div>
            <?php endif; ?>
        </div>

        <!-- 2. CENTER INFO -->
        <div class="info-col">

            <?php if ($brand): ?>
            <div class="evazar-floating-brand">
                <a href="<?php echo esc_url(home_url('/brand/' . sanitize_title($brand_en ? $brand_en : $brand))); ?>"><?php echo esc_html($brand); ?></a>
                <?php if (!empty($breadcrumbs)): 
                    $last_cat = end($breadcrumbs);
                    if (!empty($last_cat['title'])): 
                        $brand_cat_name = (mb_stripos($last_cat['title'], $brand) === false && !in_array($brand, ['متفرقه', 'دیجی‌کالا', 'دیجیکالا', 'عمومی'])) ? ($last_cat['title'] . ' ' . $brand) : $last_cat['title'];
                        $sub_term = get_term_by('name', $brand_cat_name, 'evazar_category');
                        $sub_url = ($sub_term && !is_wp_error($sub_term)) ? get_term_link($sub_term) : $last_cat['url'];
                    ?>
                        <span class="sep">/</span>
                        <a href="<?php echo esc_url($sub_url); ?>"><?php echo esc_html($brand_cat_name); ?></a>
                <?php endif; endif; ?>
            </div>
            <?php endif; ?>

            <h1 class="product-title"><?php the_title(); ?></h1>
            <?php if ($en_title): ?>
                <div class="product-subtitle"><?php echo esc_html($en_title); ?></div>
            <?php endif; ?>

            <div class="meta-ratings">
                <?php if ($opt_show_sku === '1' && $sku): ?>
                    <div class="sku-chip">کد کالا: <?php echo esc_html($sku); ?></div>
                <?php endif; ?>
                <?php if ($opt_show_ratings === '1'): ?>
                    <?php if ($rating && floatval($rating) > 0 && !empty($rating_count) && intval($rating_count) > 0): ?>
                        <div class="rating-chip" dir="rtl">
                            <span class="rating-star">★</span>
                            <span class="rating-val"><?php echo esc_html(evazar_to_fa_num($rating)); ?></span>
                            <span class="rating-count">(امتیاز <?php echo esc_html(evazar_to_fa_num($rating_count)); ?> خریدار)</span>
                        </div>
                    <?php endif; ?>
                    <?php if ($satisfaction && intval($satisfaction) > 0 && !empty($rating_count) && intval($rating_count) > 0): ?>
                        <div class="satisfaction-chip"><?php echo esc_html(evazar_to_fa_num($satisfaction)); ?>٪ رضایت خریداران</div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>


            <?php if ($opt_show_features === '1' && !empty($key_features)): 
                $feat_count = count($key_features);
                $feat_limit = intval(get_option('evazar_opt_single_features_limit', 5));
                if ($feat_limit < 1) { $feat_limit = 5; }
                $has_feat_more = ($feat_count > $feat_limit);
            ?>
                <div class="features-box <?php echo $has_feat_more ? 'has-features-collapse' : ''; ?>" id="evazar-features-box">
                    <h4>ویژگی‌های برجسته کالا:</h4>
                    <ul class="features-list">
                        <?php $feature_index = 0; ?>
                        <?php foreach ($key_feature_groups as $feature_group):
                            $group_features = (!empty($feature_group['features']) && is_array($feature_group['features'])) ? $feature_group['features'] : [];
                            if (empty($group_features)) continue;
                            $group_title = isset($feature_group['title']) ? trim((string) $feature_group['title']) : '';
                            $group_is_extra = ($has_feat_more && $feature_index >= $feat_limit);
                        ?>
                            <?php if ($group_title !== ''): ?>
                                <li class="features-group-title <?php echo $group_is_extra ? 'feature-item-extra' : ''; ?>"><?php echo esc_html($group_title); ?></li>
                            <?php endif; ?>
                            <?php foreach ($group_features as $feat):
                                $is_extra = ($has_feat_more && $feature_index >= $feat_limit);
                            ?>
                                <li class="<?php echo $is_extra ? 'feature-item-extra' : ''; ?>" data-feature-item="1">
                                    <?php if (!empty($feat['label'])): ?>
                                        <span class="feat-label"><?php echo esc_html($feat['label']); ?>:</span>
                                    <?php endif; ?>
                                    <span class="feat-val"><bdi><?php echo esc_html(evazar_to_fa_num($feat['value'])); ?></bdi></span>
                                </li>
                            <?php $feature_index++; endforeach; ?>
                        <?php endforeach; ?>
                    </ul>
                    <?php if ($has_feat_more): ?>
                    <button type="button" class="features-toggle-btn" aria-expanded="false">
                        <span class="feat-btn-text">+ مشاهده بیشتر (<?php echo esc_html(evazar_to_fa_num($feat_count - $feat_limit)); ?> ویژگی دیگر)</span>
                        <svg class="feat-btn-icon" viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"></polyline></svg>
                    </button>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- MOBLAK 3 TRUST BADGES (انتقال استراتژیک به انتهای مشخصات کالا در ستون وسط) -->
            <div class="info-trust-row">
                <?php if (!empty($opt_product_trust_badge_1)): ?>
                <div class="trust-badge-item">
                    <svg class="trust-icon" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>
                    <span><?php echo esc_html($opt_product_trust_badge_1); ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($opt_product_trust_badge_2)): ?>
                <div class="trust-badge-item">
                    <svg class="trust-icon" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M20 8h-3V4H1v13h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4zM6 18.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5zm13.5-9l1.96 2.5H17V9.5h2.5zm-1 9c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5 1.5 1.5 1.5z"/></svg>
                    <span><?php echo esc_html($opt_product_trust_badge_2); ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($opt_product_trust_badge_3)): ?>
                <div class="trust-badge-item">
                    <svg class="trust-icon" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12.5 8c-2.65 0-5.05.99-6.9 2.6L2 7v9h9l-3.62-3.62c1.39-1.16 3.16-1.88 5.12-1.88 3.54 0 6.55 2.31 7.6 5.5l2.37-.78C21.08 11.03 17.15 8 12.5 8z"/></svg>
                    <span><?php echo esc_html($opt_product_trust_badge_3); ?></span>
                </div>
                <?php endif; ?>
            </div>

        </div> <!-- /.info-col (ستون ۲: عنوان، امتیاز، توضیحات و مشخصات کالا) -->

        <!-- 3. BUYBOX COLUMN (ستون ۳: باکس خرید، قیمت، فروشنده و اعتمادسازی) -->
        <div class="buybox-col">
            <div class="product-integrated-buybox buybox-plan-4">
                <?php if (!empty($opt_buybox_guarantee_header)): ?>
                <div class="buybox-guarantee-topbar">
                    <?php echo esc_html($opt_buybox_guarantee_header); ?>
                </div>
                <?php endif; ?>

                <?php 
                if (get_option('evazar_opt_show_price_drop_badge', '1') === '1' && function_exists('evazar_get_price_drop_info')):
                    $drop_hours = intval(get_option('evazar_opt_price_drop_hours', 48));
                    $drop_info = evazar_get_price_drop_info($post_id, $drop_hours);
                    if ($drop_info):
                        $drop_text = get_option('evazar_opt_price_drop_badge_text', 'کاهش قیمت');
                        $drop_diff_formatted = evazar_format_price($drop_info['diff']);
                ?>
                    <div class="price-drop-hero-banner">
                        <div class="price-drop-hero-content">
                            <div class="price-drop-hero-text">
                                <strong><?php echo esc_html($drop_text); ?> ویژه:</strong> این کالا در <?php echo esc_html(evazar_to_fa_num($drop_hours)); ?> ساعت اخیر ارزان‌تر شده است!
                            </div>
                        </div>
                        <div class="price-drop-hero-amount">
                            <span><?php echo esc_html($drop_diff_formatted); ?></span> تومان افت قیمت
                        </div>
                    </div>
                <?php 
                    endif;
                endif;
                ?>

                <div class="buybox-top-row">
                    <?php if ($opt_show_seller === '1'): ?>
                    <div class="seller-badge-row">
                        <div class="seller-brand">
                            <div class="seller-logo">DK</div>
                            <div class="seller-details-wrap">
                                <div class="seller-name-row">
                                    <div class="seller-name" id="evazar-seller-name">فروشنده: <?php echo esc_html($seller_name); ?></div>
                                </div>
                                <div class="seller-sub-meta">
                                    <span class="seller-rate" id="evazar-seller-rate"><?php echo esc_html($seller_rate_text); ?></span>
                                    <span class="verified-badge">
                                        <svg viewBox="0 0 24 24" width="12" height="12" fill="currentColor" style="flex-shrink: 0;"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
                                        <span>اطلاعات به‌روز از دیجی‌کالا</span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php 
                    $clean_old_num = floatval(str_replace([',', ' ', '،'], '', function_exists('evazar_to_en_num') ? evazar_to_en_num((string)$old_price) : (string)$old_price));
                    $clean_cur_num = floatval(str_replace([',', ' ', '،'], '', function_exists('evazar_to_en_num') ? evazar_to_en_num((string)$current_price) : (string)$current_price));
                    $has_real_discount = ($product_available && $clean_old_num > 0 && $clean_cur_num > 0 && $clean_old_num > $clean_cur_num);
                    $b_clean_badge = function_exists('evazar_get_clean_discount_badge') 
                        ? evazar_get_clean_discount_badge($discount_percent, $old_price, $current_price) 
                        : '';
                    ?>
                    <div class="price-container">
                        <div class="price-head" style="<?php echo ($has_real_discount && !empty($b_clean_badge)) ? '' : 'display: none;'; ?>">
                            <span><?php echo esc_html($opt_buybox_price_label ?: 'قیمت رسمی در دیجی‌کالا:'); ?></span>
                            <div class="price-discount-wrap">
                                <?php if ($has_real_discount && !empty($b_clean_badge) && $opt_show_discount === '1'): ?>
                                    <div class="discount-pill" id="evazar-discount-pill"><?php echo esc_html($b_clean_badge); ?></div>
                                <?php else: ?>
                                    <div class="discount-pill" id="evazar-discount-pill" style="display: none;"></div>
                                <?php endif; ?>
                                <?php if ($has_real_discount): ?>
                                    <div class="old-price-line" id="evazar-old-price-line"><?php echo evazar_format_price($old_price); ?> تومان</div>
                                <?php else: ?>
                                    <div class="old-price-line" id="evazar-old-price-line" style="display: none;"></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="main-price-row">
                            <span class="price-static-label"><?php echo esc_html($opt_buybox_price_label ?: 'قیمت:'); ?></span>
                            <div class="main-price-figure">
                                <div class="main-price-val" id="evazar-main-price-val"><?php echo ($product_available && $current_price) ? evazar_format_price($current_price) : 'ناموجود'; ?></div>
                                <div class="main-price-unit" id="evazar-main-price-unit" style="<?php echo ($product_available && $current_price) ? '' : 'display: none;'; ?>">تومان</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- 3 CHECKLIST GUARANTEE ITEMS (چک‌لیست اعتمادسازی با تیک سبز) -->
                <?php if (!empty($opt_buybox_feature_1) || !empty($opt_buybox_feature_2) || !empty($opt_buybox_feature_3)): ?>
                <ul class="buybox-checklist">
                    <?php if (!empty($opt_buybox_feature_1)): ?>
                        <li><span class="chk-icon">✓</span> <span><?php echo esc_html($opt_buybox_feature_1); ?></span></li>
                    <?php endif; ?>
                    <?php if (!empty($opt_buybox_feature_2)): ?>
                        <li><span class="chk-icon">✓</span> <span><?php echo esc_html($opt_buybox_feature_2); ?></span></li>
                    <?php endif; ?>
                    <?php if (!empty($opt_buybox_feature_3)): ?>
                        <li><span class="chk-icon">✓</span> <span><?php echo esc_html($opt_buybox_feature_3); ?></span></li>
                    <?php endif; ?>
                </ul>
                <?php endif; ?>

                <!-- AFFILIATE CTA BUTTON -->
                <div class="buybox-action-wrap">
                    <a href="<?php echo esc_url($affiliate_link); ?>" rel="nofollow sponsored" class="btn-affiliate-cta">
                        <span><?php echo esc_html($opt_btn_title ?: 'اتصال مستقیم به دیجی‌کالا'); ?></span>
                        <?php if ($opt_btn_subtitle): ?>
                            <span class="btn-sub"><?php echo esc_html($opt_btn_subtitle); ?></span>
                        <?php endif; ?>
                    </a>

                    <?php if ($opt_guarantee_text): ?>
                    <div class="affiliate-guarantee-note">
                        <?php echo esc_html($opt_guarantee_text); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- MOBLAK 3 TRUST BADGES FOR MOBILE (نمایش زیر کادر قیمت و فروشنده در موبایل) -->
            <div class="info-trust-row buybox-mobile-trust-badges">
                <?php if (!empty($opt_product_trust_badge_1)): ?>
                <div class="trust-badge-item">
                    <svg class="trust-icon" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>
                    <span><?php echo esc_html($opt_product_trust_badge_1); ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($opt_product_trust_badge_2)): ?>
                <div class="trust-badge-item">
                    <svg class="trust-icon" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M20 8h-3V4H1v13h2c0 1.66 1.34 3 3 3s3-1.34 3-3h6c0 1.66 1.34 3 3 3s3-1.34 3-3h2v-5l-3-4zM6 18.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5 1.5 1.5 1.5zm13.5-9l1.96 2.5H17V9.5h2.5zm-1 9c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5 1.5 1.5 1.5z"/></svg>
                    <span><?php echo esc_html($opt_product_trust_badge_2); ?></span>
                </div>
                <?php endif; ?>
                <?php if (!empty($opt_product_trust_badge_3)): ?>
                <div class="trust-badge-item">
                    <svg class="trust-icon" viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M12.5 8c-2.65 0-5.05.99-6.9 2.6L2 7v9h9l-3.62-3.62c1.39-1.16 3.16-1.88 5.12-1.88 3.54 0 6.55 2.31 7.6 5.5l2.37-.78C21.08 11.03 17.15 8 12.5 8z"/></svg>
                    <span><?php echo esc_html($opt_product_trust_badge_3); ?></span>
                </div>
                <?php endif; ?>
            </div>

        </div> <!-- /.buybox-col (ستون ۳: بای‌باکس مستقل) -->

    </div> <!-- /.product-grid-top (چیدمان ۳ ستونه اختصاصی) -->

    <!-- 2-COL PRODUCT BOTTOM -->
    <div class="product-grid-bottom">
        <div class="main-content-card">
            <div class="content-tabs">
                <div class="tab-item active">نقد و بررسی تخصصی</div>
            </div>
            <div class="tab-pane active review-article">
                <?php 
                $article_body = get_the_content();
                echo evazar_render_readmore(apply_filters('the_content', $article_body), 'product');
                ?>

                <?php if ($opt_show_ai === '1' && !empty($pros)): ?>
                <div class="product-pros-cons-accent">
                    <div class="accent-box accent-pros">
                        <h4 class="accent-head">
                            <span class="accent-badge-icon">✓</span>
                            <span>ویژگی‌ها و نقاط قوت کلیدی کالا</span>
                        </h4>
                        <ul class="accent-list">
                            <?php foreach($pros as $pro): ?>
                                <li><?php echo esc_html(evazar_to_fa_num($pro)); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- SIDEBAR -->
        <div class="sidebar-col">
            <div class="sidebar-card">
                <h3 style="color:#0f172a; font-size:0.9rem;">چرا خرید از طریق ایوازار؟</h3>
                <p style="font-size:0.8rem; color:var(--text-main); line-height:1.6;">
                    ایوازار اطلاعات و قیمت کالاها را از منابع فروشنده جمع‌آوری و تحلیل می‌کند. برای خرید، شما مستقیماً به سایت فروشنده منتقل می‌شوید و پرداخت و ارسال همان‌جا انجام می‌شود.
                </p>
            </div>
        </div>
    </div>

    <?php
    // محصولات مرتبط توسط EVazar Core و Product Index انتخاب می‌شوند.
    // Theme فقط تنظیمات و رندر کارت‌ها را مدیریت می‌کند.
    $show_related_flag = ($opt_show_related !== '0');
    if ($show_related_flag):
        $related_count = max(1, min(50, intval($opt_related_count)));
        $opt_related_hide_outofstock = get_option('evazar_opt_related_hide_outofstock', '1');
        $selected_ids = function_exists('evazar_get_related_product_ids')
            ? evazar_get_related_product_ids(
                $post_id,
                $related_count,
                $opt_related_hide_outofstock === '1'
            )
            : [];

        $related_query = null;
        if (!empty($selected_ids)) {
            $related_query = new WP_Query([
                'post_type'           => 'evazar_product',
                'posts_per_page'      => count($selected_ids),
                'post__in'            => array_values(array_unique(array_map('intval', $selected_ids))),
                'orderby'             => 'post__in',
                'post_status'         => 'publish',
                'suppress_filters'    => true,
                'ignore_sticky_posts' => true,
                'no_found_rows'       => true,
            ]);
        }

        if ($related_query && $related_query->have_posts()):

    ?>
    <section class="single-related-section"
        data-related-offset="<?php echo esc_attr(count($selected_ids)); ?>"
        data-related-has-more="<?php echo count($selected_ids) >= $related_count ? '1' : '0'; ?>">
        <div class="section-header-row">
            <h3 class="related-section-title">🔍 کالاهای مرتبط و پیشنهادی</h3>
            <?php if (!empty($breadcrumbs)):
                $last_bc = end($breadcrumbs);
                $cat_link = is_array($last_bc) ? ($last_bc['url'] ?? '#') : '#';
            ?>
                <a href="<?php echo esc_url($cat_link); ?>" class="view-all-link">مشاهده همه کالاهای این دسته ←</a>
            <?php endif; ?>
        </div>
        <div class="evazar-archive-grid related-products-grid" data-related-grid>
            <?php echo evazar_theme_render_related_product_cards($related_query->posts); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- renderer escapes card fields by context. ?>
        </div>
        <div class="related-products-status" data-related-status role="status" aria-live="polite" aria-busy="false"></div>
        <button type="button" class="related-products-retry" data-related-retry hidden>تلاش مجدد برای بارگذاری</button>
        <div class="related-products-sentinel" data-related-sentinel aria-hidden="true"></div>
    </section>
    <?php endif; endif; ?>

</div>

<!-- EVAZAR CLEAN LIGHTBOX MODAL -->
<div id="evazar-lightbox" class="evazar-lightbox-modal" role="dialog" aria-modal="true" aria-label="گالری تصاویر کالا">
    <div class="lightbox-backdrop" id="lightbox-backdrop"></div>
    <div class="lightbox-dialog">
        <!-- Top Toolbar -->
        <div class="lightbox-toolbar">
            <div class="lightbox-info">
                <span class="lightbox-counter" id="lightbox-counter">۱ از <?php echo max(1, count($gallery_images)); ?></span>
            </div>
            <div class="lightbox-tools">
                <button type="button" class="lightbox-tool-btn lightbox-close-btn" id="lightbox-close-btn" title="بستن (Esc)">
                    <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                </button>
            </div>
        </div>

        <!-- Center Image Stage with Arrows -->
        <div class="lightbox-viewport" id="lightbox-viewport">
            <button type="button" class="lightbox-nav prev" id="lightbox-nav-prev" aria-label="تصویر قبلی">
                <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"></polyline></svg>
            </button>

            <div class="lightbox-image-stage" id="lightbox-image-stage">
                <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==" data-src="<?php echo esc_url($thumbnail_url); ?>" id="lightbox-img" class="lightbox-img lightbox-img-active" alt="<?php echo esc_attr(get_the_title()); ?>" decoding="async">
                <img id="lightbox-img-buffer" class="lightbox-img lightbox-img-buffer" alt="" aria-hidden="true" decoding="async">
            </div>

            <button type="button" class="lightbox-nav next" id="lightbox-nav-next" aria-label="تصویر بعدی">
                <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"></polyline></svg>
            </button>
        </div>

        <!-- Bottom Thumbnails Bar -->
        <?php if (!empty($gallery_images) && count($gallery_images) > 1): ?>
            <div class="lightbox-thumbs-bar">
                <div class="lightbox-thumbs-list" id="lightbox-thumbs-list">
                    <?php foreach ($gallery_images as $idx => $g_img): ?>
                        <div class="lightbox-thumb <?php echo $idx === 0 ? 'active' : ''; ?>" data-src="<?php echo esc_url($g_img); ?>" data-index="<?php echo $idx; ?>">
                            <img src="<?php echo esc_url(function_exists('evazar_cdn_image_url') ? evazar_cdn_image_url($g_img, 120) : $g_img); ?>" data-src="<?php echo esc_url(function_exists('evazar_cdn_image_url') ? evazar_cdn_image_url($g_img, 120) : $g_img); ?>" alt="تصویر <?php echo $idx + 1; ?>" width="120" height="120" loading="lazy" decoding="async" referrerpolicy="no-referrer">
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    let galleryImages = <?php echo json_encode(array_values($gallery_images), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
    let currentIndex = 0;
    const imageFallback = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="600" height="600" viewBox="0 0 600 600"><rect fill="%23f8fafc" width="600" height="600"/><path d="M180 390l85-95 70 72 55-62 110 125H180z" fill="%23e2e8f0"/><circle cx="310" cy="245" r="28" fill="%23cbd5e1"/><text x="300" y="455" text-anchor="middle" fill="%2394a3b8" font-family="sans-serif" font-size="20">تصویر کالا</text></svg>';

    function isDataImage(src) {
        return typeof src === 'string' && src.indexOf('data:image') === 0;
    }

    // Core owns retries for CDN/direct-origin images. Do not replace their network URL
    // with a local fallback during an error event; doing so would cancel retries and make
    // scroll-triggered recovery impossible. External/non-Core images retain local fallback.
    function isCoreManagedImage(img) {
        if (!img) return false;
        const recovery = img.__evazarImageRecovery;
        if (img.__evazarCoreManaged === true) return true;
        if (recovery && ['cdn-retry', 'direct', 'direct-retry', 'failed'].indexOf(recovery.stage) !== -1) return true;
        return false;
    }

    // Keep only adjacent full-size images warm in the browser cache. This avoids
    // downloading the whole gallery up front and does not alter the visible gallery DOM.
    const galleryPreloadCache = new Map();
    function preloadGalleryImage(index) {
        if (!Array.isArray(galleryImages) || galleryImages.length < 2) return;
        const normalizedIndex = (index + galleryImages.length) % galleryImages.length;
        const src = galleryImages[normalizedIndex];
        if (!src || isDataImage(src)) return;
        const mainCurrent = document.getElementById('evazar-main-img');
        const lightboxCurrent = document.getElementById('lightbox-img');
        if ((mainCurrent && (mainCurrent.currentSrc || mainCurrent.src) === src) ||
            (lightboxCurrent && (lightboxCurrent.currentSrc || lightboxCurrent.src) === src)) return;
        const existing = galleryPreloadCache.get(src);
        if (existing && (existing.status === 'pending' || existing.status === 'loaded')) return;

        const image = new Image();
        const entry = { image: image, status: 'pending', timer: null };
        galleryPreloadCache.set(src, entry);
        image.decoding = 'async';
        image.referrerPolicy = 'no-referrer';
        try { image.fetchPriority = 'low'; } catch (_) {}
        // A request interrupted by a network/VPN switch may remain pending without an
        // error event. Expire the cache entry so a later navigation can try again.
        entry.timer = window.setTimeout(function() {
            if (entry.status === 'pending' && galleryPreloadCache.get(src) === entry) {
                galleryPreloadCache.delete(src);
            }
        }, 5000);
        image.onload = function() {
            entry.status = 'loaded';
            if (entry.timer) window.clearTimeout(entry.timer);
            if (typeof image.decode === 'function') image.decode().catch(function() {});
        };
        image.onerror = function() {
            if (entry.timer) window.clearTimeout(entry.timer);
            // Do not permanently suppress retries after transient CDN/Worker failures.
            if (galleryPreloadCache.get(src) === entry) galleryPreloadCache.delete(src);
        };
        image.src = src;
        if (image.complete && image.naturalWidth > 0) {
            entry.status = 'loaded';
            if (entry.timer) window.clearTimeout(entry.timer);
        }
    }

    function preloadAdjacentGalleryImages(index) {
        if (!Array.isArray(galleryImages) || galleryImages.length < 2) return;
        // Low-priority requests for the immediate neighbors only; wrap at both ends.
        preloadGalleryImage((index + 1) % galleryImages.length);
        preloadGalleryImage((index - 1 + galleryImages.length) % galleryImages.length);
    }

    const EVAZAR_IMAGE_ROUTE_MODE = <?php echo wp_json_encode(get_option('evazar_image_route_mode', 'direct') === 'worker' ? 'worker' : 'direct'); ?>;
    function normalizeGalleryMode(mode, cdnHost) {
        const directHost = 'https://dkstatics-public.digikala.com';
        const defaultCdnHost = 'https://img.evazar.ir';
        const targetHost = EVAZAR_IMAGE_ROUTE_MODE === 'direct' ? directHost : (mode === 'normal' ? (cdnHost || defaultCdnHost) : directHost);
        const target = new URL(targetHost, window.location.href);
        const knownSourceHosts = [
            new URL(directHost).hostname.toLowerCase(),
            new URL(defaultCdnHost).hostname.toLowerCase(),
            target.hostname.toLowerCase()
        ];
        const mapUrl = function(url) {
            if (!url || typeof url !== 'string' || url.indexOf('data:image') === 0) return url;
            try {
                const parsed = new URL(url, window.location.href);
                if (knownSourceHosts.indexOf(parsed.hostname.toLowerCase()) === -1) return url;
                if (parsed.hostname.toLowerCase() === target.hostname.toLowerCase() && parsed.protocol === target.protocol && parsed.port === target.port) return url;
                parsed.protocol = target.protocol;
                parsed.hostname = target.hostname;
                parsed.port = target.port;
                return parsed.toString();
            } catch (_) { return url; }
        };

        galleryImages = galleryImages.map(mapUrl);
        document.querySelectorAll('.gallery-thumb-item[data-src], .lightbox-thumb[data-src]').forEach(function(item) {
            const value = item.getAttribute('data-src');
            if (value) item.setAttribute('data-src', mapUrl(value));
            const image = item.querySelector('img[data-src]');
            if (image) {
                const imageSource = image.getAttribute('data-src');
                if (imageSource) {
                    const mappedSource = mapUrl(imageSource);
                    image.setAttribute('data-src', mappedSource);
                    if (image.getAttribute('data-loaded') === '1') image.src = mappedSource;
                }
            }
        });

        // Keep the currently displayed full-size image aligned with the selected image mode.
        if (typeof setActiveImage === 'function' && galleryImages.length) setActiveImage(currentIndex, false);
        if (lightbox && lightbox.classList.contains('active') && typeof updateLightboxView === 'function') updateLightboxView(false);
    }

    window.addEventListener('evazar:image-mode-changed', function(event) {
        const detail = event && event.detail ? event.detail : {};
        if (detail.mode === 'normal') normalizeGalleryMode('normal', detail.cdnHost);
    });

    function attachFinalImageRecovery(img) {
        if (!img || img.__evazarRecoveryAttached) return;
        img.__evazarRecoveryAttached = true;
        img.addEventListener('error', function() {
            // Core's capture-phase handler can synchronously start the next network attempt
            // before this target-phase handler runs. Never overwrite a Core-managed request.
            if (img.__evazarDirectPending) {
                img.__evazarDirectPending = false;
                return;
            }
            if (isCoreManagedImage(img)) return;
            const src = img.currentSrc || img.src || '';
            if (isDataImage(src)) return;
            img.removeAttribute('srcset');
            img.removeAttribute('data-srcset');
            img.removeAttribute('data-lazy-srcset');
            img.setAttribute('data-evazar-image-final-fallback', '1');
            img.src = imageFallback;
        });
    }

    // Register listeners before changing src: cached images can finish very quickly.
    // Never let a stalled request/decode block gallery navigation indefinitely.
    function waitForImageReady(img, callback, nextSrc) {
        if (!img || typeof callback !== 'function') return;
        let done = false;
        let timer = null;
        const cleanup = function() {
            img.removeEventListener('load', onLoad);
            img.removeEventListener('error', onError);
            if (timer !== null) window.clearTimeout(timer);
            timer = null;
        };
        const finish = function(reason) {
            if (done) return;
            done = true;
            cleanup();
            // Do not await decode(): some browsers/network transitions can leave it pending.
            // A loaded image is safe to reveal; if still loading after timeout, reveal its
            // layer without replacing its URL so a late load or Core recovery can still work.
            callback(reason || 'ready');
        };
        const onLoad = function() {
            if (img.naturalWidth > 0) finish('loaded');
        };
        const onError = function() {
            finish('error');
        };

        attachFinalImageRecovery(img);
        img.__evazarDirectPending = false;
        img.removeAttribute('srcset');
        img.removeAttribute('data-srcset');
        img.removeAttribute('data-lazy-srcset');
        img.setAttribute('data-loaded', '1');
        img.loading = 'eager';
        img.setAttribute('data-evazar-source', nextSrc || '');
        if (nextSrc && /^https?:\/\/dkstatics-public\.digikala\.com\//i.test(nextSrc)) img.setAttribute('referrerpolicy', 'no-referrer');
        img.addEventListener('load', onLoad);
        img.addEventListener('error', onError);
        // Bound the wait. This is not treated as a network failure: keep the requested src
        // intact so a late response and the Core's recovery handlers can still complete it.
        timer = window.setTimeout(function() { finish('timeout'); }, 4000);

        if (nextSrc && (img.currentSrc || img.src || '') !== nextSrc) img.src = nextSrc;
        // `complete` may also mean a broken image; naturalWidth distinguishes success.
        if (img.complete && img.naturalWidth > 0) finish('loaded');
        else if (img.complete && img.naturalWidth === 0) onError();
    }

    function setImageSource(img, src) {
        if (!img || !src) return;
        attachFinalImageRecovery(img);
        img.__evazarDirectPending = false;
        img.setAttribute('data-evazar-source', src);
        if (/^https?:\/\/dkstatics-public\.digikala\.com\//i.test(src)) img.setAttribute('referrerpolicy', 'no-referrer');
        img.removeAttribute('srcset');
        img.removeAttribute('data-srcset');
        img.removeAttribute('data-lazy-srcset');
        img.setAttribute('data-loaded', '1');
        if ((img.currentSrc || img.src || '') !== src) img.src = src;
    }

    function crossfadeImage(activeImg, bufferImg, src, token, onVisible) {
        if (!activeImg || !bufferImg || !src) return;
        // Cancel any late-load watcher left by an older selection on this buffer element.
        if (bufferImg.__evazarLateGalleryWatch) {
            const oldWatch = bufferImg.__evazarLateGalleryWatch;
            bufferImg.removeEventListener('load', oldWatch.onLoad);
            bufferImg.removeEventListener('error', oldWatch.onError);
            bufferImg.__evazarLateGalleryWatch = null;
        }
        const currentSrc = activeImg.currentSrc || activeImg.src || '';
        if (currentSrc === src && activeImg.naturalWidth > 0) {
            if (typeof onVisible === 'function') onVisible(activeImg);
            return;
        }

        bufferImg.style.opacity = '0';
        bufferImg.setAttribute('data-transition-token', String(token));
        bufferImg.setAttribute('data-transition-source', src);

        const isCurrentTransition = function() {
            return String(bufferImg.getAttribute('data-transition-token')) === String(token) &&
                bufferImg.getAttribute('data-transition-source') === src;
        };
        const revealLoadedBuffer = function() {
            if (!isCurrentTransition() || !(bufferImg.naturalWidth > 0)) return false;
            if (typeof onVisible === 'function') onVisible(bufferImg);
            requestAnimationFrame(function() {
                if (!isCurrentTransition() || !(bufferImg.naturalWidth > 0)) return;
                activeImg.style.opacity = '0';
                bufferImg.style.opacity = '1';
            });
            return true;
        };

        // A timed-out image must not replace a still-visible, valid image with a blank layer.
        // Keep watching the real DOM image: if it loads late (including after Core recovery),
        // reveal it only if the user has not selected another thumbnail in the meantime.
        waitForImageReady(bufferImg, function(reason) {
            if (!isCurrentTransition()) return;
            if (bufferImg.naturalWidth > 0) {
                revealLoadedBuffer();
                return;
            }
            if ((reason === 'timeout' || reason === 'error') && (isCoreManagedImage(bufferImg) || !bufferImg.complete)) {
                const lateWatch = { onLoad: null, onError: null };
                const cleanupLateWatch = function() {
                    bufferImg.removeEventListener('load', lateWatch.onLoad);
                    bufferImg.removeEventListener('error', lateWatch.onError);
                    if (bufferImg.__evazarLateGalleryWatch === lateWatch) bufferImg.__evazarLateGalleryWatch = null;
                };
                lateWatch.onLoad = function() {
                    if (!isCurrentTransition()) {
                        cleanupLateWatch();
                        return;
                    }
                    if (revealLoadedBuffer()) cleanupLateWatch();
                };
                lateWatch.onError = function() {
                    // Core/final fallback listeners may replace the failed URL; keep the
                    // old visible image until that fallback (or a recovered image) is ready.
                    if (!isCurrentTransition() || (isDataImage(bufferImg.currentSrc || bufferImg.src || '') && bufferImg.complete && bufferImg.naturalWidth === 0)) {
                        cleanupLateWatch();
                    }
                };
                bufferImg.__evazarLateGalleryWatch = lateWatch;
                bufferImg.addEventListener('load', lateWatch.onLoad);
                bufferImg.addEventListener('error', lateWatch.onError);
                // Close the race where the image loaded just before listeners were attached.
                if (bufferImg.naturalWidth > 0) lateWatch.onLoad();
                return;
            }
            // A completed failed request may already have been changed to the local fallback.
            // Never switch to an empty layer; reveal only when the fallback has real dimensions.
            if (bufferImg.complete && !isDataImage(bufferImg.currentSrc || bufferImg.src || '') && !isCoreManagedImage(bufferImg)) {
                setImageSource(bufferImg, imageFallback);
                const onFallbackLoad = function() {
                    if (bufferImg.naturalWidth > 0) {
                        bufferImg.removeEventListener('load', onFallbackLoad);
                        revealLoadedBuffer();
                    }
                };
                bufferImg.addEventListener('load', onFallbackLoad);
                if (bufferImg.naturalWidth > 0) onFallbackLoad();
            }
        }, src);
    }

    // عناصر گالری
    const mainImg = document.getElementById('evazar-main-img');
    const mainImgBuffer = document.getElementById('evazar-main-img-buffer');
    let activeMainImg = mainImg;
    let idleMainImg = mainImgBuffer;
    let mainTransitionToken = 0;
    if (mainImg) attachFinalImageRecovery(mainImg);
    if (mainImgBuffer) attachFinalImageRecovery(mainImgBuffer);

    const zoomContainer = document.getElementById('evazar-zoom-container');
    const btnZoomTrigger = document.getElementById('btn-zoom-trigger');
    const thumbItems = document.querySelectorAll('.gallery-thumb-item');
    const thumbsTrack = document.getElementById('evazar-gallery-thumbs');
    const arrowPrev = document.getElementById('thumb-arrow-prev');
    const arrowNext = document.getElementById('thumb-arrow-next');

    // عناصر لایت‌باکس
    const lightbox = document.getElementById('evazar-lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxImgBuffer = document.getElementById('lightbox-img-buffer');
    let activeLightboxImg = lightboxImg;
    let idleLightboxImg = lightboxImgBuffer;
    let lightboxTransitionToken = 0;
    if (lightboxImg) attachFinalImageRecovery(lightboxImg);
    if (lightboxImgBuffer) attachFinalImageRecovery(lightboxImgBuffer);
    const lightboxBackdrop = document.getElementById('lightbox-backdrop');
    const lightboxClose = document.getElementById('lightbox-close-btn');
    const lightboxPrev = document.getElementById('lightbox-nav-prev');
    const lightboxNext = document.getElementById('lightbox-nav-next');
    const lightboxCounter = document.getElementById('lightbox-counter');
    const lightboxThumbs = document.querySelectorAll('.lightbox-thumb');
    let lastLightboxIndicatorIndex = currentIndex;

    // بزرگ‌نمایی شناور فقط در دسکتاپ با ماوس
    <?php if ($opt_zoom === '1'): ?>
    const canHoverZoom = window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    if (canHoverZoom && zoomContainer && mainImg) {
        zoomContainer.addEventListener('mousemove', function(e) {
            const targetImg = activeMainImg || mainImg;
            if (!targetImg) return;
            const rect = zoomContainer.getBoundingClientRect();
            const x = ((e.clientX - rect.left) / rect.width) * 100;
            const y = ((e.clientY - rect.top) / rect.height) * 100;
            targetImg.style.transformOrigin = x + '% ' + y + '%';
            targetImg.style.transform = 'scale(2.2)';
            zoomContainer.classList.add('is-zoomed');
        });

        zoomContainer.addEventListener('mouseleave', function() {
            [mainImg, mainImgBuffer].forEach(function(img) {
                if (!img) return;
                img.style.transformOrigin = 'center center';
                img.style.transform = 'scale(1)';
            });
            zoomContainer.classList.remove('is-zoomed');
        });
    }
    <?php endif; ?>

    // تصاویر بندانگشتی فقط وقتی وارد محدوده قابل‌مشاهده شوند دانلود می‌شوند.
    function hydrateImage(img) {
        if (!img || img.getAttribute('data-loaded') === '1') return;
        const src = img.getAttribute('data-src');
        if (!src) return;
        img.setAttribute('data-loaded', '1');
        img.src = src;
    }

    if (thumbsTrack && thumbItems.length) {
        const thumbImages = thumbsTrack.querySelectorAll('img[data-src]');
        if ('IntersectionObserver' in window) {
            const thumbObserver = new IntersectionObserver(function(entries, observer) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        hydrateImage(entry.target);
                        observer.unobserve(entry.target);
                    }
                });
            }, { root: thumbsTrack, rootMargin: '160px 160px' });
            thumbImages.forEach(function(img) { thumbObserver.observe(img); });
        } else {
            thumbImages.forEach(hydrateImage);
        }
    }

    function hydrateLightboxAssets() {
        lightboxThumbs.forEach(function(item) {
            const img = item.querySelector('img[data-src]');
            if (img) hydrateImage(img);
        });
    }

    // پس از انتخاب تصویر، تصویر انتخاب‌شده و تصویر بعدی را در نوار بندانگشتی قابل‌مشاهده نگه می‌دارد.
    // محاسبه بر اساس موقعیت واقعی عناصر است تا در RTL و مرورگرهای موبایل/دسکتاپ درست کار کند.
    function keepThumbnailAndNextVisible(track, items, index, padding, direction) {
        if (!track || !items || !items.length) return;
        const activeItem = items[index];
        if (!activeItem) return;
        const step = direction < 0 ? -1 : 1;
        const neighborIndex = Math.max(0, Math.min(items.length - 1, index + step));
        const neighborItem = items[neighborIndex] || activeItem;
        const trackRect = track.getBoundingClientRect();
        const activeRect = activeItem.getBoundingClientRect();
        const neighborRect = neighborItem.getBoundingClientRect();
        const leftEdge = Math.min(activeRect.left, neighborRect.left);
        const rightEdge = Math.max(activeRect.right, neighborRect.right);
        const leftLimit = trackRect.left + padding;
        const rightLimit = trackRect.right - padding;
        if (leftEdge >= leftLimit && rightEdge <= rightLimit) return;

        // scrollIntoView uses the track's RTL inline axis, avoiding browser-specific
        // scrollLeft sign differences when moving backwards through the thumbnails.
        try {
            neighborItem.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest',
                inline: direction < 0 ? 'start' : 'end'
            });
        } catch (_) {
            const delta = leftEdge < leftLimit
                ? leftEdge - leftLimit
                : rightEdge - rightLimit;
            track.scrollBy(delta, 0);
        }
    }

    let lastMainIndicatorIndex = currentIndex;
    function updateMainIndicators() {
        const scrollDirection = currentIndex < lastMainIndicatorIndex ? -1 : 1;
        const mobileCounter = document.getElementById('evazar-mobile-gallery-counter');
        if (mobileCounter) {
            const faNums = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
            const curFa = String(currentIndex + 1).replace(/[0-9]/g, w => faNums[+w]);
            const totFa = String(galleryImages.length).replace(/[0-9]/g, w => faNums[+w]);
            mobileCounter.textContent = curFa + ' از ' + totFa;
        }

        document.querySelectorAll('#evazar-gallery-dots .gallery-dot').forEach(function(d, dIdx) {
            d.classList.toggle('active', dIdx === currentIndex);
        });

        thumbItems.forEach(function(item) {
            const itemIdx = parseInt(item.getAttribute('data-index'), 10);
            item.classList.toggle('active', itemIdx === currentIndex);
            if (itemIdx === currentIndex && thumbsTrack) {
                keepThumbnailAndNextVisible(thumbsTrack, thumbItems, currentIndex, 12, scrollDirection);
            }
        });
        lastMainIndicatorIndex = currentIndex;
    }

    function setActiveImage(index, isInitial) {
        if (!galleryImages || galleryImages.length === 0) return;
        if (index < 0) index = galleryImages.length - 1;
        if (index >= galleryImages.length) index = 0;
        currentIndex = index;

        const src = galleryImages[currentIndex];
        // Mobile: use one stable DOM image instead of alternating two opacity layers.
        // The old double-buffer transition can leave the newly active layer invisible
        // on some mobile browsers when lazy-load/decode events are deferred.
        const isMobileGallery = window.matchMedia && window.matchMedia('(max-width: 768px)').matches;
        if (!isInitial && isMobileGallery && mainImg && src) {
            mainTransitionToken += 1;
            const token = mainTransitionToken;
            const currentDisplayedSrc = mainImg.currentSrc || mainImg.src || '';
            activeMainImg = mainImg;
            idleMainImg = mainImgBuffer;
            if (currentDisplayedSrc === src && mainImg.naturalWidth > 0) {
                mainImg.style.opacity = '1';
                mainImg.classList.add('gallery-main-img-active');
                if (mainImgBuffer) {
                    mainImgBuffer.style.opacity = '0';
                    mainImgBuffer.classList.remove('gallery-main-img-active');
                }
            } else {
                const preload = new Image();
                preload.decoding = 'async';
                preload.referrerPolicy = 'no-referrer';
                let mobileTransitionFinished = false;
                let mobileTransitionTimer = null;
                const showMobileImageSource = function(preloadSucceeded) {
                    if (mobileTransitionFinished || token !== mainTransitionToken) return;
                    if (preloadSucceeded && !(preload.naturalWidth > 0)) preloadSucceeded = false;
                    mobileTransitionFinished = true;
                    if (mobileTransitionTimer) window.clearTimeout(mobileTransitionTimer);
                    // Even if the detached preload hangs, put the real DOM image on the
                    // selected URL so the core's bounded CDN/origin recovery can handle it.
                    mainImg.removeAttribute('srcset');
                    mainImg.removeAttribute('data-srcset');
                    mainImg.removeAttribute('data-lazy-srcset');
                    mainImg.setAttribute('data-loaded', '1');
                    mainImg.setAttribute('data-index', String(index));
                    if ((mainImg.getAttribute('src') || '') !== src) mainImg.src = src;
                    mainImg.classList.add('gallery-main-img-active');
                    mainImg.style.opacity = '1';
                    if (mainImgBuffer) {
                        mainImgBuffer.classList.remove('gallery-main-img-active');
                        mainImgBuffer.style.opacity = '0';
                    }
                    if (preloadSucceeded) preloadAdjacentGalleryImages(index);
                };
                // Never let a detached Image() request block gallery switching indefinitely.
                mobileTransitionTimer = window.setTimeout(function() {
                    showMobileImageSource(false);
                }, 1800);
                preload.onload = function() {
                    if (typeof preload.decode === 'function') {
                        preload.decode().catch(function() {}).then(function() { showMobileImageSource(true); });
                    } else {
                        showMobileImageSource(true);
                    }
                };
                preload.onerror = function() { showMobileImageSource(false); };
                preload.src = src;
                if (preload.complete && preload.naturalWidth > 0) {
                    if (typeof preload.decode === 'function') preload.decode().catch(function() {}).then(function() { showMobileImageSource(true); });
                    else showMobileImageSource(true);
                }
            }
        } else if (mainImg && mainImgBuffer && src) {
            if (isInitial) {
                activeMainImg = mainImg;
                idleMainImg = mainImgBuffer;
                activeMainImg.style.opacity = '1';
                idleMainImg.style.opacity = '0';
                activeMainImg.setAttribute('data-index', currentIndex);
                attachFinalImageRecovery(activeMainImg);
            } else {
                mainTransitionToken += 1;
                const token = mainTransitionToken;
                const from = activeMainImg;
                const to = idleMainImg;
                crossfadeImage(from, to, src, token, function(visibleImg) {
                    activeMainImg = visibleImg;
                    idleMainImg = visibleImg === mainImg ? mainImgBuffer : mainImg;
                    visibleImg.setAttribute('data-index', currentIndex);
                    // Mobile CSS has dedicated active/buffer rules. Keep these classes
                    // synchronized so the CSS never pins visibility to the first image.
                    [mainImg, mainImgBuffer].forEach(function(img) {
                        if (!img) return;
                        img.classList.toggle('gallery-main-img-active', img === visibleImg);
                        img.style.transform = 'scale(1)';
                        img.style.transformOrigin = 'center center';
                    });
                    preloadAdjacentGalleryImages(currentIndex);
                });
            }
        }

        updateMainIndicators();
    }

    document.querySelectorAll('#evazar-gallery-dots .gallery-dot').forEach(function(dot) {
        dot.addEventListener('click', function(e) {
            e.stopPropagation();
            setActiveImage(parseInt(this.getAttribute('data-index'), 10), false);
        });
    });

    let isSwiping = false;
    let swipeCooldown = false;
    if (zoomContainer) {
        let touchStartX = 0;
        let touchStartY = 0;
        let touchEndX = 0;
        let touchEndY = 0;

        zoomContainer.addEventListener('touchstart', function(e) {
            if (e.touches && e.touches.length > 0) {
                touchStartX = e.touches[0].clientX;
                touchStartY = e.touches[0].clientY;
                isSwiping = false;
            }
        }, { passive: true });

        zoomContainer.addEventListener('touchmove', function(e) {
            if (e.touches && e.touches.length > 0) {
                const diffX = Math.abs(e.touches[0].clientX - touchStartX);
                const diffY = Math.abs(e.touches[0].clientY - touchStartY);
                if (diffX > 10 && diffX > diffY) isSwiping = true;
            }
        }, { passive: true });

        zoomContainer.addEventListener('touchend', function(e) {
            if (e.changedTouches && e.changedTouches.length > 0) {
                touchEndX = e.changedTouches[0].clientX;
                touchEndY = e.changedTouches[0].clientY;
                const diffX = touchStartX - touchEndX;
                const diffY = Math.abs(touchStartY - touchEndY);
                if (Math.abs(diffX) > 35 && Math.abs(diffX) > diffY) {
                    isSwiping = true;
                    swipeCooldown = true;
                    setActiveImage(diffX < 0 ? currentIndex + 1 : currentIndex - 1, false);
                    setTimeout(function() {
                        swipeCooldown = false;
                        isSwiping = false;
                    }, 350);
                }
            }
        }, { passive: true });
    }

    // Use pointerup for thumbnail selection so touch and mouse follow one path.
    // Prevent the synthetic click after a touch from selecting the same item twice.
    function selectGalleryThumbnail(item, event) {
        if (!item) return;
        if (event) {
            if (event.pointerType === 'mouse' && event.button !== 0) return;
            event.preventDefault();
            event.stopPropagation();
        }
        const index = Number.parseInt(item.getAttribute('data-index'), 10);
        if (Number.isFinite(index)) setActiveImage(index, false);
    }

    if (window.PointerEvent) {
        thumbItems.forEach(function(item) {
            item.addEventListener('pointerup', function(event) {
                selectGalleryThumbnail(this, event);
            }, { passive: false });
        });
    } else {
        // Legacy touch browsers without Pointer Events.
        thumbItems.forEach(function(item) {
            item.addEventListener('touchend', function(event) {
                selectGalleryThumbnail(this, event);
            }, { passive: false });
            item.addEventListener('click', function(event) {
                selectGalleryThumbnail(this, event);
            });
        });
    }

    if (thumbsTrack) {
        thumbsTrack.scrollLeft = 0;
        if (arrowPrev) {
            arrowPrev.addEventListener('click', function(e) {
                e.preventDefault();
                thumbsTrack.scrollBy({ left: 160, behavior: 'smooth' });
            });
        }
        if (arrowNext) {
            arrowNext.addEventListener('click', function(e) {
                e.preventDefault();
                thumbsTrack.scrollBy({ left: -160, behavior: 'smooth' });
            });
        }
    }

    function openLightbox(index) {
        if (!lightbox) return;
        if (typeof index === 'number') currentIndex = index;
        lastLightboxIndicatorIndex = currentIndex;
        hydrateLightboxAssets();
        updateLightboxView(true);
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden';
        const lightboxTrack = document.getElementById('lightbox-thumbs-list');
        if (lightboxTrack && currentIndex === 0) lightboxTrack.scrollLeft = 0;
    }

    function closeLightbox() {
        if (!lightbox) return;
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
    }

    function updateLightboxView(isInitial) {
        if (!galleryImages || galleryImages.length === 0 || !lightboxImg || !lightboxImgBuffer) return;
        if (currentIndex < 0) currentIndex = galleryImages.length - 1;
        if (currentIndex >= galleryImages.length) currentIndex = 0;

        const selectedSrc = galleryImages[currentIndex];
        if (isInitial && (isDataImage(lightboxImg.src) || !lightboxImg.naturalWidth)) {
            lightboxTransitionToken += 1;
            const token = lightboxTransitionToken;
            lightboxImg.style.opacity = '0';
            lightboxImg.setAttribute('data-transition-token', String(token));
            setImageSource(lightboxImg, selectedSrc);
            waitForImageReady(lightboxImg, function() {
                if (String(lightboxImg.getAttribute('data-transition-token')) !== String(token)) return;
                // Use the fallback only for a completed broken request, not for a merely slow
                // request; a pending image may still load after the bounded wait expires.
                if (!(lightboxImg.naturalWidth > 0) && lightboxImg.complete && !isDataImage(lightboxImg.currentSrc || lightboxImg.src || '') && !isCoreManagedImage(lightboxImg)) {
                    setImageSource(lightboxImg, imageFallback);
                }
                lightboxImg.style.opacity = '1';
                preloadAdjacentGalleryImages(currentIndex);
            }, selectedSrc);
            activeLightboxImg = lightboxImg;
            idleLightboxImg = lightboxImgBuffer;
        } else {
            lightboxTransitionToken += 1;
            const token = lightboxTransitionToken;
            const from = activeLightboxImg;
            const to = idleLightboxImg;
            crossfadeImage(from, to, selectedSrc, token, function(visibleImg) {
                activeLightboxImg = visibleImg;
                idleLightboxImg = visibleImg === lightboxImg ? lightboxImgBuffer : lightboxImg;
                preloadAdjacentGalleryImages(currentIndex);
            });
        }

        if (lightboxCounter) {
            const faNums = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
            const curFa = String(currentIndex + 1).replace(/\d/g, d => faNums[d]);
            const totalFa = String(galleryImages.length).replace(/\d/g, d => faNums[d]);
            lightboxCounter.textContent = curFa + ' از ' + totalFa;
        }

        const lightboxTrack = document.getElementById('lightbox-thumbs-list');
        const lightboxScrollDirection = currentIndex < lastLightboxIndicatorIndex ? -1 : 1;
        lightboxThumbs.forEach(function(lt) {
            const idx = parseInt(lt.getAttribute('data-index'), 10);
            lt.classList.toggle('active', idx === currentIndex);
        });
        keepThumbnailAndNextVisible(lightboxTrack, lightboxThumbs, currentIndex, 12, lightboxScrollDirection);
        lastLightboxIndicatorIndex = currentIndex;
    }

    if (btnZoomTrigger) {
        btnZoomTrigger.addEventListener('click', function(e) {
            e.stopPropagation();
            openLightbox(currentIndex);
        });
    }

    if (zoomContainer) {
        zoomContainer.addEventListener('click', function(e) {
            if (isSwiping || swipeCooldown) {
                e.preventDefault();
                e.stopPropagation();
                return;
            }
            openLightbox(currentIndex);
        });
    }

    if (lightboxClose) lightboxClose.addEventListener('click', closeLightbox);
    if (lightboxBackdrop) lightboxBackdrop.addEventListener('click', closeLightbox);

    if (lightboxPrev) {
        lightboxPrev.addEventListener('click', function(e) {
            e.stopPropagation();
            currentIndex = (currentIndex - 1 + galleryImages.length) % galleryImages.length;
            updateLightboxView(false);
            setActiveImage(currentIndex, false);
        });
    }

    if (lightboxNext) {
        lightboxNext.addEventListener('click', function(e) {
            e.stopPropagation();
            currentIndex = (currentIndex + 1) % galleryImages.length;
            updateLightboxView(false);
            setActiveImage(currentIndex, false);
        });
    }

    const lightboxViewport = document.getElementById('lightbox-viewport');
    if (lightboxViewport) {
        let lbTouchStartX = 0;
        let lbTouchStartY = 0;
        let lbTouchEndX = 0;
        let lbTouchEndY = 0;

        lightboxViewport.addEventListener('touchstart', function(e) {
            if (e.touches && e.touches.length === 1) {
                lbTouchStartX = e.touches[0].clientX;
                lbTouchStartY = e.touches[0].clientY;
            }
        }, { passive: true });

        lightboxViewport.addEventListener('touchend', function(e) {
            if (e.changedTouches && e.changedTouches.length > 0) {
                lbTouchEndX = e.changedTouches[0].clientX;
                lbTouchEndY = e.changedTouches[0].clientY;
                const diffX = lbTouchStartX - lbTouchEndX;
                const diffY = Math.abs(lbTouchStartY - lbTouchEndY);
                if (Math.abs(diffX) > 35 && Math.abs(diffX) > diffY) {
                    currentIndex = diffX < 0
                        ? (currentIndex + 1) % galleryImages.length
                        : (currentIndex - 1 + galleryImages.length) % galleryImages.length;
                    updateLightboxView(false);
                    setActiveImage(currentIndex, false);
                }
            }
        }, { passive: true });
    }

    lightboxThumbs.forEach(function(lt) {
        lt.addEventListener('click', function(e) {
            e.stopPropagation();
            currentIndex = parseInt(this.getAttribute('data-index'), 10);
            updateLightboxView(false);
            setActiveImage(currentIndex, false);
        });
    });

    document.addEventListener('keydown', function(e) {
        if (!lightbox || !lightbox.classList.contains('active')) return;
        if (e.key === 'Escape') {
            closeLightbox();
        } else if (e.key === 'ArrowRight') {
            currentIndex = (currentIndex - 1 + galleryImages.length) % galleryImages.length;
            updateLightboxView(false);
            setActiveImage(currentIndex, false);
        } else if (e.key === 'ArrowLeft') {
            currentIndex = (currentIndex + 1) % galleryImages.length;
            updateLightboxView(false);
            setActiveImage(currentIndex, false);
        }
    });

    window.addEventListener('online', function() {
        // Discard stale pending preload entries after a VPN/network change and warm only
        // the two neighboring gallery images again; visible-image recovery remains in core.
        galleryPreloadCache.forEach(function(entry, src) {
            if (entry.status === 'pending') {
                if (entry.timer) window.clearTimeout(entry.timer);
                galleryPreloadCache.delete(src);
            }
        });
        preloadAdjacentGalleryImages(currentIndex);
    });

    if (mainImg) {
        activeMainImg = mainImg;
        idleMainImg = mainImgBuffer;
        mainImg.style.opacity = '1';
        if (mainImgBuffer) mainImgBuffer.style.opacity = '0';
        const warmAdjacentAfterInitialLoad = function() {
            if (mainImg.naturalWidth > 0) preloadAdjacentGalleryImages(currentIndex);
        };
        if (mainImg.complete && mainImg.naturalWidth > 0) {
            warmAdjacentAfterInitialLoad();
        } else {
            mainImg.addEventListener('load', warmAdjacentAfterInitialLoad, { once: true });
        }
    }
    if (thumbItems.length > 0) setActiveImage(0, true);
});

// ثبت بازدید غیرمسدودکننده؛ رندر PHP دیگر DB Write ندارد.
(function() {
    const viewPostId = <?php echo intval($post_id); ?>;
    if (!viewPostId) return;
    try {
        const key = 'evazar_viewed_' + viewPostId;
        if (sessionStorage.getItem(key) === '1') return;
        sessionStorage.setItem(key, '1');
        const data = new URLSearchParams({
            action: 'evazar_track_view',
            post_id: String(viewPostId),
            nonce: <?php echo json_encode(wp_create_nonce('evazar_view_nonce')); ?>
        });
        if (navigator.sendBeacon) {
            navigator.sendBeacon(<?php echo json_encode(admin_url('admin-ajax.php')); ?>, data);
        } else {
            fetch(<?php echo json_encode(admin_url('admin-ajax.php')); ?>, {
                method: 'POST',
                body: data,
                keepalive: true,
                credentials: 'same-origin'
            }).catch(function(){});
        }
    } catch (_) {}
})();

// استعلام زنده و همگام‌سازی بلادرنگ قیمت و موجودی دیجی‌کالا (Live Price & Buybox Sync)
// نوار Sticky موبایل داخل footer.php ساخته می‌شود؛ بنابراین اجرای Live بعد از DOMContentLoaded انجام می‌شود
// تا عناصر Desktop و Mobile هر دو در زمان اعمال پاسخ وجود داشته باشند.
(function() {
    function evazarInitLiveInquiry() {
    const postId = <?php echo intval($post_id); ?>;
    const sku = <?php echo json_encode($sku); ?>;
    if (!postId || !sku) return;

    const ajaxUrl = <?php echo json_encode(admin_url('admin-ajax.php')); ?>;
    const liveNonce = <?php echo json_encode(wp_create_nonce('evazar_live_product_nonce')); ?>;

    fetch(ajaxUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: new URLSearchParams({
            action: 'evazar_live_product_inquiry',
            post_id: postId,
            sku: sku,
            nonce: liveNonce
        })
    })
    .then(res => res.json())
    .then(data => {
        if (!data || !data.success || !data.data) return;
        const d = data.data;

        // ۱. به‌روزرسانی قیمت دسکتاپ
        const mainPriceVal = document.getElementById('evazar-main-price-val');
        const mainPriceUnit = document.getElementById('evazar-main-price-unit');
        const oldPriceLine = document.getElementById('evazar-old-price-line');
        const discPill = document.getElementById('evazar-discount-pill');

        if (mainPriceVal) {
            if (d.is_available && d.price_formatted) {
                mainPriceVal.textContent = d.price_formatted;
                if (mainPriceUnit) mainPriceUnit.style.display = 'block';
            } else {
                mainPriceVal.textContent = 'ناموجود';
                if (mainPriceUnit) mainPriceUnit.style.display = 'none';
            }
        }

        const hasRealDiscount = d.is_available && d.old_price && (Number(d.old_price) > Number(d.price));

        const pHead = document.querySelector('.price-head');
        if (oldPriceLine) {
            if (hasRealDiscount && d.old_price_formatted) {
                oldPriceLine.textContent = d.old_price_formatted + ' تومان';
                oldPriceLine.style.display = 'block';
                if (pHead) pHead.style.display = 'flex';
            } else {
                oldPriceLine.style.display = 'none';
                if (pHead) pHead.style.display = 'none';
            }
        }

        if (discPill) {
            if (hasRealDiscount && d.discount_percent) {
                discPill.textContent = d.discount_percent;
                discPill.style.display = 'inline-block';
            } else {
                discPill.style.display = 'none';
            }
        }

        // ۲. به‌روزرسانی استیکر تخفیف در گالری
        const galleryDiscBadge = document.querySelector('.badge-onsale');
        if (galleryDiscBadge) {
            if (hasRealDiscount && d.discount_percent) {
                galleryDiscBadge.style.display = 'flex';
                const badgeText = galleryDiscBadge.querySelector('.badge-text');
                if (badgeText) badgeText.textContent = d.discount_percent + ' تخفیف';
            } else {
                galleryDiscBadge.style.display = 'none';
            }
        }

        // ۳. به‌روزرسانی نام فروشنده و وضعیت ارسال
        const sellerNameEl = document.getElementById('evazar-seller-name');
        const sellerRateEl = document.getElementById('evazar-seller-rate');
        if (sellerNameEl && d.seller) {
            sellerNameEl.textContent = 'فروشنده: ' + d.seller;
        }
        if (sellerRateEl) {
            if (d.seller_rating !== null && d.seller_rating !== undefined && Number(d.seller_rating) > 0) {
                const ratingNumber = Math.round(Number(d.seller_rating) * 10) / 10;
                const ratingValue = ratingNumber.toLocaleString('fa-IR', Number.isInteger(ratingNumber) ? { maximumFractionDigits: 0 } : { minimumFractionDigits: 1, maximumFractionDigits: 1 });
                sellerRateEl.textContent = 'امتیاز فروشنده: ' + ratingValue + ' از ۵';
                sellerRateEl.style.display = '';
            } else if (d.seller_rate_text && !/^\s*فروشنده\s*[:：]/u.test(String(d.seller_rate_text))) {
                sellerRateEl.textContent = d.seller_rate_text;
                sellerRateEl.style.display = '';
            } else {
                sellerRateEl.textContent = '';
                sellerRateEl.style.display = 'none';
            }
        }

        // ۴. به‌روزرسانی نوار چسبان خرید موبایل (Mobile Sticky Buybox)
        const mPriceContainer = document.querySelector('.mobile-sticky-main-price');
        let mPriceNum = document.querySelector('.mobile-sticky-main-price .price-num');
        let mPriceOut = document.querySelector('.mobile-sticky-main-price .price-out');
        let mPriceUnit = document.querySelector('.mobile-sticky-main-price .price-unit');
        const mOldPrice = document.querySelector('.mobile-sticky-old-price');
        const mDiscBadge = document.querySelector('.mobile-sticky-discount-badge');

        if (mPriceContainer) {
            if (d.is_available && d.price_formatted) {
                if (!mPriceNum) {
                    mPriceNum = document.createElement('span');
                    mPriceNum.className = 'price-num';
                    mPriceContainer.appendChild(mPriceNum);
                }
                if (!mPriceUnit) {
                    mPriceUnit = document.createElement('span');
                    mPriceUnit.className = 'price-unit';
                    mPriceUnit.textContent = 'تومان';
                    mPriceContainer.appendChild(mPriceUnit);
                }
                mPriceNum.textContent = d.price_formatted;
                mPriceNum.style.display = 'inline';
                mPriceUnit.style.display = 'inline';
                if (mPriceOut) mPriceOut.style.display = 'none';
            } else {
                if (!mPriceOut) {
                    mPriceOut = document.createElement('span');
                    mPriceOut.className = 'price-out';
                    mPriceContainer.appendChild(mPriceOut);
                }
                mPriceOut.textContent = 'ناموجود';
                mPriceOut.style.display = 'inline';
                if (mPriceNum) mPriceNum.style.display = 'none';
                if (mPriceUnit) mPriceUnit.style.display = 'none';
            }
        }

        if (mOldPrice) {
            if (hasRealDiscount && d.old_price_formatted) {
                mOldPrice.textContent = d.old_price_formatted;
                mOldPrice.style.display = 'inline';
            } else {
                mOldPrice.style.display = 'none';
            }
        }

        // ۵. به‌روزرسانی بلادرنگ امتیاز ستاره‌ای و تعداد خریداران در صفحه محصول
        const toFa = n => String(n).replace(/\d/g, digit => '۰۱۲۳۴۵۶۷۸۹'[digit]);
        if (d.rating && Number(d.rating) > 0 && d.rating_count && Number(d.rating_count) > 0) {
            let rChip = document.querySelector('.rating-chip');
            if (rChip) {
                rChip.style.display = 'inline-flex';
                const rVal = rChip.querySelector('.rating-val');
                if (rVal) rVal.textContent = toFa(d.rating);
                let rCount = rChip.querySelector('.rating-count');
                if (!rCount) {
                    rCount = document.createElement('span');
                    rCount.className = 'rating-count';
                    rChip.appendChild(rCount);
                }
                rCount.textContent = '(امتیاز ' + toFa(d.rating_count) + ' خریدار)';
            }
        } else {
            const rChip = document.querySelector('.rating-chip');
            if (rChip) rChip.style.display = 'none';
        }

        if (d.satisfaction && Number(d.satisfaction) > 0 && d.rating_count && Number(d.rating_count) > 0) {
            let satEl = document.querySelector('.satisfaction-chip');
            if (satEl) {
                satEl.style.display = 'inline-flex';
                satEl.textContent = toFa(d.satisfaction) + '٪ رضایت خریداران';
            }
        } else {
            const satEl = document.querySelector('.satisfaction-chip');
            if (satEl) satEl.style.display = 'none';
        }

        if (mDiscBadge) {
            if (hasRealDiscount && d.discount_percent) {
                mDiscBadge.textContent = d.discount_percent;
                mDiscBadge.style.display = 'inline-block';
            } else {
                mDiscBadge.style.display = 'none';
            }
        }
    })
    .catch(err => {
        // در صورت خطای شبکه، مقادیر ذخیره‌شده اولیه بدون مشکل حفظ می‌شوند
    });
    }

    function evazarScheduleLiveInquiry() {
        const run = function() {
            if ('requestIdleCallback' in window) {
                window.requestIdleCallback(evazarInitLiveInquiry, { timeout: 1800 });
            } else {
                window.setTimeout(evazarInitLiveInquiry, 1200);
            }
        };
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', run, { once: true });
        } else {
            run();
        }
    }

    evazarScheduleLiveInquiry();
})();
</script>

<?php get_footer(); ?>
