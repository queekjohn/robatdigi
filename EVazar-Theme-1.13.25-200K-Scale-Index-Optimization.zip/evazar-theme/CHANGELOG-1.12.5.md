# Changelog 1.12.5

## Related products display fix
- Preserved all existing related-products theme settings: show/hide, item count, and hide-out-of-stock.
- Fixed the availability filter for older imported products that do not yet have `_evazar_is_available`.
- Products with a valid positive current price are no longer incorrectly excluded just because the availability meta key is missing.
- Explicit availability values `1`, `yes`, and `true` remain eligible.
- No changes to the relevance scoring order.
