# QA — EVazar Theme 1.13.22

## Scope
- Price-state rendering on homepage carousels only.
- Core and Worker are unchanged.

## Static checks
- One shared helper normalizes Latin/Persian/Arabic digits and common numeric separators.
- Explicit `explicit_unavailable` state renders «ناموجود».
- Positive current price without explicit-unavailable signal renders the numeric price and currency.
- Zero/missing/invalid current price without explicit-unavailable signal renders «قیمت نامشخص».
- Old price, discount badge, price-drop badge, and savings badge are suppressed unless a valid positive current price is present.
- Five regular homepage product card renderers and the deals carousel renderer are updated.
- No query selection or metadata write path was modified.

## Limitations
- Static source/syntax validation does not replace a live WordPress rendering test against the production database.
