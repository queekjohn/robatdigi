# EVazar Theme 1.12.84 — bounded gallery image wait

- Added a 4-second bound to the product gallery/lightbox image transition wait so a stalled request cannot block gallery navigation indefinitely.
- Removed waiting on `HTMLImageElement.decode()` before revealing a loaded image; this promise is no longer allowed to hold the transition open.
- A timeout does not overwrite a still-pending image URL, preserving the possibility of a late response and the Core image-recovery path.
- Fallback is used for a completed broken image, not merely a slow request.
- Scope limited to `single-evazar_product.php` and the theme version header; no gallery markup, CSS, swipe behavior, archive filters, importer, or product data changed.
