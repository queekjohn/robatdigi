# EVazar Theme 1.13.18 — Electric home appliances category icon

- Added a dedicated washing-machine SVG icon with a small lightning marker for the exact “لوازم خانگی برقی” category name.
- The match is normalized for repeated whitespace and Persian zero-width non-joiners, while the original category name and matching logic for every other category remain unchanged.
- No stylesheet rules, card markup, product data, archive filters, product-page related-product pagination, gallery, importer, or Worker behavior changed.
- Package base: Theme 1.13.17 with related-product infinite scroll preserved.
