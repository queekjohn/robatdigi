# EVazar Theme 1.13.09 — Deals “View All” Arrow Direction

## Change
- Corrected only the arrow on the homepage Special Offers lead-card link “مشاهده همه تخفیف‌ها” to point left, consistent with the RTL “view all” links elsewhere on the homepage.
- Added a dedicated class to the SVG and marked it decorative; no navigation behavior or URL changed.

## Scope
- Changed `front-page.php`, `style.css` version metadata, and this changelog only.
- No carousel navigation arrows, product cards, image loading/lazy loading, product gallery, archive filters, importer, or other homepage sections were modified.

## Validation
- ZIP CRC/integrity verified.
- PHP syntax checked for the modified file and all theme PHP files where PHP CLI is available.
- Verified the Special Offers view-all link retains its original `href` and only its arrow polyline changes direction.
