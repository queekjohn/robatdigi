# Safe upgrade — EVazar Theme 1.13.20

- Back up the current theme, then replace the existing `evazar-theme/` folder with the folder in this ZIP. Keep the folder name unchanged.
- This release changes only the SVG mapped to the exact category `لوازم خانگی برقی`, the theme version header, and this release documentation.
- The icon now follows the same filled Material-style silhouette as the other category icons; the existing CSS controls its size, color, and hover state.
- Related-products infinite scroll from Theme 1.13.17 is preserved. That feature still requires EVazar Core 2.9.37 or newer with offset pagination support. No additional Core/Worker change or database migration is needed for this icon adjustment.
