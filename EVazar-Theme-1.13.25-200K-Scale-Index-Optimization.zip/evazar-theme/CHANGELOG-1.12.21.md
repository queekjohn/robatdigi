EVazar Theme 1.12.21
====================

Base: 1.12.15 (last known homepage build that produced a valid LCP in the user's Lighthouse test).

Only functional/theme change:
- Restored the proven 1.12.18 homepage deal-card anti-stretch rules.

Intentionally unchanged from 1.12.15:
- Homepage critical CSS strategy
- JavaScript loading/defer behavior
- Search JavaScript
- Back-to-top JavaScript
- Theme interactions JavaScript
- Responsive product-image rendering helper
- Homepage HTML structure
