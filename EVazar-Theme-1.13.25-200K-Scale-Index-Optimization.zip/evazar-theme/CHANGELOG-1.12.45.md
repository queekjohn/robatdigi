# EVazar Theme 1.12.45

- Category directory accordion controls changed to a minimal chevron (no circular button).
- Clearing category search now restores the full tree in a fully collapsed state.
- Large category branches now use bounded internal scrolling instead of expanding into very tall panels.
- No image, Failover, product gallery, lightbox, header category menu, or unrelated page logic changes.
