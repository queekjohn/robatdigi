# EVazar Theme 1.13.23 — Brand weekly featured grid

- Bumped the theme version to 1.13.23 so WordPress uses the new theme version for stylesheet/script cache keys.
- Kept the existing 1.13.22 homepage price-state fix as the base.
- Desktop-only change: the “محبوب‌ترین برندهای این هفته” featured-brand grid on `/brand/` displays eight columns at viewport widths of 1024px and above.
- No Core, Worker, database, or brand-query logic changes.
- Mobile styling and other page sections remain unchanged.
