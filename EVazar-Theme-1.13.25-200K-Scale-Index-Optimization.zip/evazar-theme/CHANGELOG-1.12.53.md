# EVazar Theme 1.12.53

- Restored lightweight infinite scroll for product lists on category and brand archive pages.
- Infinite scroll uses the existing archive filter AJAX endpoint, preserves current filters/sort, loads one page at a time, and keeps normal pagination as a fallback.
- Newly appended product images remain lazy-loaded and are exposed through a `evazar:products-appended` event for image handling observers.
- Removed the duplicate lower price input boxes visually; the underlying fields remain in the DOM so the existing slider/filter state and form submission continue to work.
- No unrelated product-card or price-drop presentation changes.
