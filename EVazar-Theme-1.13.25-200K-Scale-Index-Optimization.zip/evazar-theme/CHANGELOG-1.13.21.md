# EVazar Theme 1.13.21 — Homepage query isolation

- Prevented `evazar_push_outofstock_and_sort()` from adding archive-specific product-index and `postmeta` joins or stock-priority sorting to front-page queries.
- Preserved archive/search and archive-filter AJAX behavior; this change does not modify EVazar Core, Worker, database schema, or cache settings.
- Goal: reduce avoidable SQL work across the multiple product shelves rendered on the homepage.
- Note: this is a targeted code correction; production TTFB improvement must be measured after deployment against the same route and conditions.
