# EVazar Theme 1.13.19 — Category icon color/style consistency

- Updated the “لوازم خانگی برقی” washing-machine icon to use a bold, filled SVG glyph like the other category icons.
- The icon inherits `currentColor`: default category text/icon color is `#334155`; hover/active uses the theme primary `#ef394e` in the light theme. This keeps it adaptive instead of hard-coding black.
- Only this exact category’s SVG and the theme version/changelog metadata changed from 1.13.18. The related-products infinite-scroll code and other category mappings remain unchanged.
