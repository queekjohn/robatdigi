# EVazar Theme 1.12.39

## Homepage Brands / LCP stability

- Preserved the existing horizontal brand rail and button navigation.
- Added `scroll-padding-inline: 4px` to match the rail's 4px inline padding while keeping `scroll-snap-type: x mandatory`.
- This prevents an unnecessary initial snap adjustment during first layout, while preserving the normal post-load swipe/snap behavior.
- Reverted the experimental `VazirmatnLCP` / `font-display: block` Hero H1 change from 1.12.38 because it did not resolve the intermittent `NO_LCP` issue.
- Preserved all existing homepage product-card spacing fixes and affiliate-only functionality.
