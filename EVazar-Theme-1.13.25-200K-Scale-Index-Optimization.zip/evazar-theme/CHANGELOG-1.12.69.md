EVazar Theme 1.12.69

- Fixed the smart archive brand facet being limited to the first 120 alphabetically sorted brand terms. All non-empty brand terms are now considered before context-aware product matching, so brands such as Sony can appear in the category filter when published products in that archive are assigned to them.
- Bumped the smart-facet transient cache namespace to prevent stale brand lists from the previous implementation being reused.
- The live brand search endpoint and its context-aware filtering behavior remain unchanged.
