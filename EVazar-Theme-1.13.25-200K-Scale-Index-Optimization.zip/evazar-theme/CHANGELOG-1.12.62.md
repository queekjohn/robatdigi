# Version 1.12.62

- Fixed mobile gallery image-layer visibility by synchronizing the active image class with the layer that finishes loading.
- Removed `!important` from mobile active/buffer opacity rules so the JavaScript crossfade can control visibility.
- Made thumbnail auto-scroll direction-aware: moving backward keeps the previous thumbnail visible; moving forward keeps the next thumbnail visible.
- No changes to the lightbox image-selection flow or the gallery image URL/failover strategy.
