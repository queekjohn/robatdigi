# Safe upgrade — EVazar Theme 1.12.73

1. Preserve the existing theme backup and install on staging first.
2. Keep the directory name `evazar-theme`.
3. The image URL helper is duplicated defensively in theme/core for deployments where Core is momentarily inactive; implementations now match. With Core active, the Core implementation is the one executed.
4. Test normal image loading through `img.evazar.ir` and the existing direct fallback. Do not change or clear the `evazar_image_direct_mode` cookie manually except for a controlled staging test.
5. Product gallery, archive infinite scroll, and other product-page interactions are not intentionally modified.
