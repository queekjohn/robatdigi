# Safe upgrade — EVazar Theme 1.13.16

- Keep the theme folder name `evazar-theme`.
- This theme reads `_evazar_spec_groups` when present and falls back to the former flat feature parser for older products.
- No product data is migrated or rewritten by the theme.
- For grouped product specifications, it is compatible with Core 2.9.17+ and Worker 1.12.0+.
- For the taxonomy SEO source-reliability update, the recommended companion releases are Core 2.9.19 and Worker 1.12.1. The theme does not call the Digikala source-fetch endpoint itself: Core fetches and stores successful rewritten content in the standard WordPress term description, and this theme renders that description for `evazar_category` and `evazar_brand` archives.
- Archive descriptions are only displayed when the theme setting `evazar_opt_archive_show_desc` is enabled; they are hidden on paginated archive pages by design.
- No PHP, JavaScript, CSS, product schema, category hierarchy, or archive behavior changed in this documentation-only compatibility refresh. Reinstalling the theme is not required if Theme 1.13.16 is already active and archive descriptions are enabled.
