# EVazar Theme 1.12.94

- Reverted the desktop-only responsive width overrides added in 1.12.93 for the Special Offers product cards.
- Special Offers product cards now retain the shared fixed 205px width used by the other homepage product rails.
- No JavaScript, mobile styles, product gallery, or other carousel rules changed in this correction.
