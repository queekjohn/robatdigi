# EVazar Theme 1.12.49

- Removed the red radial-gradient halo from the homepage hero card.
- No hero image, text, search, category, image-loading, failover, gallery, or lightbox logic changed.
