# Safe upgrade — EVazar Theme 1.13.21

1. Download and retain a backup of the active `evazar-theme` folder before deployment.
2. Replace the existing theme folder with the `evazar-theme/` folder from this ZIP; keep the directory name exactly `evazar-theme`.
3. This release changes only the theme version, this documentation, and the guard in `functions.php` that skips archive stock/price SQL clauses on normal front-page requests.
4. Archive/category/brand/search sorting and filter AJAX paths remain enabled. No database migration, Core update, Worker update, or cache-setting change is required.
5. After deployment, verify the homepage shelves, category/brand archives, search, stock sorting, and price filters. Compare repeated homepage TTFB measurements; if the long delay remains, this patch was not the only cause.
