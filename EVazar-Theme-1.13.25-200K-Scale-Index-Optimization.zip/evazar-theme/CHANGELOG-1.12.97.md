# EVazar Theme 1.12.97

- Restored the established six-card navigation distance for homepage category shelves and category-tab carousels.
- Kept card-edge alignment scoped to the Special Offers rail only.
- Preserved the 205px product-card width and 12px gap.
