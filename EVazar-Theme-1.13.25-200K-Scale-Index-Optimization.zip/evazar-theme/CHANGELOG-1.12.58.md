# Evazar Theme 1.12.58

- Improved mobile gallery thumbnail selection using touch pointer events.
- Prevented duplicate synthetic click handling after a touch selection.
- Kept desktop click behavior and lightbox implementation unchanged.
- Preserved the existing gallery markup, image URLs, CDN handling, and lazy loading.

Note: syntax/package checks do not replace testing on a real mobile browser.
