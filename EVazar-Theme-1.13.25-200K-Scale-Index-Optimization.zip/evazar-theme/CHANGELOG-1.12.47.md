# EVazar Theme 1.12.47

- Removed child-category count labels from the standalone product category directory.
- On mobile homepage only, the "مشاهده همه دسته‌ها" link in the featured categories section now opens the existing full-screen category menu instead of navigating to /product-category/.
- No changes to image loading, image failover, gallery, lightbox, or product-page logic.
