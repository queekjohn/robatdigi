# EVazar Theme 1.12.88

- Homepage product rails now advance by up to six product cards per navigation click, using rendered card widths and actual CSS gaps.
- Previous/next buttons use the same six-card page step in reverse/forward directions.
- Scope is limited to homepage deal, shelf/latest-product, and category-tab product rails. No product gallery or image-loading code changed.
- Browser validation on the live site is still required.
