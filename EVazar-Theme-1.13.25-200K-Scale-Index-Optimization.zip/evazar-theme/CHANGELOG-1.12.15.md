# EVazar Theme 1.12.15

- Reverted homepage stylesheets from preload-to-stylesheet loading to normal stylesheet loading to eliminate the large first-paint visual flash and the associated CLS caused by late CSS application.
- Kept the homepage critical CSS, but removed the conflicting asynchronous CSS mechanism.
- Added intrinsic `width="360"` and `height="360"` hints to the shared responsive product-image renderer so image space is reserved before CDN responses arrive; CSS `object-fit: contain` continues to preserve the image's visual aspect ratio.
- Added `defer` strategy to the lightweight back-to-top, live-search and homepage interaction scripts.
- Delayed the rail/interaction bootstrap until the browser reaches an idle/load opportunity so initial rendering is not held up by overflow measurements on below-the-fold sections.
- Added the supplied homepage preview image as the WordPress theme `screenshot.png` and a compact `screenshot.webp` copy.
- Kept affiliate, product, import and site logic unchanged.
