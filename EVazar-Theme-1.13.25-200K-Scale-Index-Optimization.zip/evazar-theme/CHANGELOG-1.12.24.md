# EVazar Theme 1.12.24

- Restored the homepage Deals card geometry to the proven 1.12.18 `front-page.css`.
- Restored the exact 1.12.18 spacing values for the Deals section/card: section `margin-top: -8px`, product-card `padding: 8px`, and thumbnail `margin-bottom: 6px`.
- Kept the 1.12.18 card stretch fix (`align-items: flex-start`, zero product-card `min-height`/`height`, and top-aligned content).
- Kept the current 1.12.23 PHP behavior, including deferred small interaction scripts and the current intrinsic image width/height hints.
- Removed the unsuccessful 1.12.23 title-height test; the title CSS is again exactly as in the proven 1.12.18 stylesheet.
- No affiliate, product, import, search, product-data, or ordering logic changes.
