# EVazar Theme 1.12.92

- Desktop-only fix for Special Offers carousel: reserve inline space inside the rail so absolutely positioned navigation arrows do not cover the first/last product cards.
- Preserves the mobile rules, other homepage rails, and product gallery code.
- Static source and archive validation only; live browser behavior still requires testing.
