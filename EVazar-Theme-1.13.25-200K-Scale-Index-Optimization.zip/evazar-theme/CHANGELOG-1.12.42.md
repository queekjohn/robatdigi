# EVazar Theme 1.12.42

- Mobile category mega menu locks the page behind it while preserving independent internal scrolling.
- Long category names are contained and wrap safely on narrow screens.
- Duplicate category icon beside the mobile submenu heading is hidden; the primary category icon remains.
- Product sticky-bar clearance is moved from the document body into the product-page footer so no blank strip appears below the footer.
- Image/Failover and gallery crossfade logic is unchanged.
