# EVazar Theme 1.12.76 — Smart AJAX Search Restored and Expanded

- AJAX now displays real products and independent smart sections at the same time: spell correction, related search phrases, matching categories and matching brands.
- Brand matching checks the cached term name, slug, product English-brand metadata aliases, and Persian/English known aliases. It supports phrase token matching (e.g. «گوشی آیفون» → Apple) without running a term lookup for every typed token.
- Category matching scores the cached category index by exact phrase, prefix, token overlap and conservative edit-distance matching; it now supports multiword phrases such as a product type combined with a brand.
- Spelling suggestions use a transient-cached lexicon assembled from a curated base, actual category/brand terms, brand aliases and up to 2,500 recent product titles. The product-title scan runs only during lexicon cache construction (6-hour TTL), not per keypress. A short transient lock avoids concurrent rebuilds.
- Only one unambiguous word is suggested at a time. Prefixes during normal typing are not treated as spelling errors; the user query is never changed unless the user clicks the correction.
- Search cache namespace bumped to v21; category/brand term indexes bumped and invalidated when terms change.
- Related query phrases remain visible beside product hits (up to three), excluding exact duplicates of shown product titles. Categories/brands remain independent sections. Suggestion rows support Enter/Space activation.
- Existing product ranking, internal-ID/DKP/SKU handling, stock toggle, image fallback, gallery, infinite scroll and product archive logic are otherwise unchanged.

## Validation

- PHP syntax lint passed for all theme PHP files.
- Node syntax check passed for all theme JavaScript files.
- Focused static checks cover category/brand cache-version invalidation, alias matching, term-token scoring, cached spelling lexicon, single-word correction guard, UI display alongside products, keyboard activation, AJAX action/nonce contract and cache namespace.
- Full WordPress/MariaDB runtime/browser testing was not available in this build environment; staging validation is still recommended before production deployment.
