# EVazar Theme 1.12.25

## Homepage deal-card isolated intrinsic-size test

- Preserves the homepage `front-page.css` exactly as in v1.12.18.
- Removes the global `width="360" height="360"` attributes from `evazar_render_responsive_product_image()`.
- No changes to deal HTML, JavaScript, loading/eager strategy, affiliate logic, product queries, or CSS geometry.
- This isolates the only layout-relevant PHP renderer difference remaining between v1.12.18 and the newer theme versions.
