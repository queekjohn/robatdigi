EVazar Theme 1.12.71

- Fixed infinite-scroll URL synchronization on product archives, brand archives, and category archives.
- Prefetching an AJAX page no longer changes the browser address by itself.
- The address now tracks the page whose first appended product has reached the reading position; scrolling back restores the corresponding earlier page URL.
- Keeps numbered pagination links, retry/timeout behavior, AJAX filters and sorting, and mobile image-loading optimization from 1.12.70.
- Limits the change to archive-filters.js, the theme version header, and this changelog.
