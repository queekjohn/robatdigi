EVazar Theme 1.12.70

- Improved mobile infinite-scroll image readiness: the first two images in each AJAX-loaded product batch use eager loading on viewports up to 720px; all later images remain lazy-loaded. Appended images never receive high fetch priority.
- Increased the mobile infinite-scroll prefetch distance from 1500px to 2000px so the next product batch has more time to arrive during scrolling. Desktop remains at 1500px.
- Kept the existing request timeout/retry, stale-request protection, filters, sorting, pagination fallback, image CDN URL generation, and initial-page LCP priority behavior unchanged.
- Live CDN/cache timing could not be measured in the build environment because DNS resolution for evazar.ir and img.evazar.ir was unavailable; this change does not alter the CDN routing or cache configuration.
