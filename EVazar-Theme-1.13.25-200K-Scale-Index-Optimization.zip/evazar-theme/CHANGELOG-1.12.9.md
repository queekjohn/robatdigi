# Changelog 1.12.9

## Performance — Responsive Product Images
- Product-card images now use responsive CDN `srcset` variants (180/240/360/480px).
- Existing `x-oss-process` dimensions are resized to the requested card size instead of keeping an oversized source transform.
- Archive and homepage product images include explicit width/height attributes and accurate `sizes` hints.
- Only the first rendered product image on the page is `eager` with `fetchpriority="high"`; other product-card images remain lazy.

## Performance — Homepage Queries
- Non-paginated homepage `WP_Query` instances now use `no_found_rows=true` to avoid unnecessary pagination-count SQL work.

## Performance — WordPress Frontend
- WordPress emoji detection assets are disabled on the frontend because the theme targets modern browsers.
