# 1.12.65

- Mobile product gallery now updates a single stable image element after preloading, avoiding alternating double-buffer opacity layers.
- Thumbnail auto-scroll now uses RTL-aware `scrollIntoView` for both forward and reverse movement.
- Lightbox thumbnail auto-scroll tracks navigation direction explicitly.
- Desktop gallery crossfade and lightbox image-transition logic remain in place.
