# Safe upgrade — EVazar Theme 1.13.18

- Keep the theme folder name exactly `evazar-theme` when replacing the current theme folder.
- This package is based on Theme 1.13.17 and preserves related-product infinite scroll. For that feature, keep EVazar Core 2.9.37 or newer with offset pagination support.
- The only behavior change from Theme 1.13.17 is the category icon for the exact category name `لوازم خانگی برقی`; the new icon is a washing machine with a small lightning symbol.
- No database migration, Core update, Worker deployment, cache/schema change, product change, or affiliate-link change is needed for the icon itself.
- Back up the current theme before replacing it, then clear page/browser cache to see the new SVG icon.
