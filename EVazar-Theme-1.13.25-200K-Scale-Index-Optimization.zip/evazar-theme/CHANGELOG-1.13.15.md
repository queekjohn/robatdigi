# EVazar Theme 1.13.15 — Faster infinite-scroll prefetch

- Increased the archive infinite-scroll prefetch distance from 2,000px to 3,200px on mobile and from 1,500px to 2,200px on desktop.
- Preserved sequential AJAX requests, existing retry/timeout handling, filter and sort parameters, pagination URL synchronization, and the current batch size.
- No database query, product markup, SEO URL, or image-loading behavior was changed in this patch.

## Validation

- JavaScript syntax checked with Node.js.
- PHP syntax checked for the theme PHP files.
- ZIP integrity checked after packaging.
- Live-site performance and real browser behavior have not been tested by this build step.
