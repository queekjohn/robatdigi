# QA — EVazar Theme 1.13.17 (Core 2.9.37)

## Behavior added
- Product-page related cards remain rendered on the initial HTML response.
- A small deferred script observes a sentinel near the bottom of the section and requests 12 additional IDs when needed.
- The theme and Core share one relevance engine; no WooCommerce API/table is used.
- Card rendering is shared between initial output and AJAX output, each card has a product ID for client-side de-duplication, and failed requests expose a retry button.
- The endpoint checks a nonce, validates that the requested product is published and of type `evazar_product`, fixes batch size server-side, and detects older Core helpers that cannot page so repeated requests cannot loop forever.
- Archive AJAX, archive filters, importer, gallery, price updates, and Worker code were not changed.

## Checks performed
- PHP syntax: all 12 Theme PHP files passed.
- PHP syntax: all 5 Core PHP files passed.
- JavaScript syntax: new related-products script, existing archive-filters script, and packaged Worker script passed `node --check`.
- Core helper test with a mock Product Index result set passed: consecutive 12-item pages return the expected non-overlapping ID ranges; the original three-argument call still returns its prior first page; `LIMIT/OFFSET` remains parameterized.
- Archive and package roots were checked; ZIP CRC validation is part of the release packaging checks.

## Compatibility and deployment
- Required pair: Theme 1.13.17 + Core 2.9.37 or newer with the optional fourth `$offset` argument.
- Core 2.9.36 can still serve current related-product cards, but it does not support offset paging. The new Theme detects that older helper and displays a specific compatibility message instead of repeatedly loading duplicate first-page items.
- Worker deployment and database schema migration are not required.

## Not verified
- This environment did not complete a headless Chromium run reliably, so no browser-interaction claim is made.
- No live `evazar.ir` request, real production database query, mobile device test, cache test, or production deployment was performed. After installation, test a product page on desktop and mobile, watch the AJAX request in Network, confirm the offset increases by 12, inspect duplicate cards, then scroll until the endpoint returns an empty batch.
