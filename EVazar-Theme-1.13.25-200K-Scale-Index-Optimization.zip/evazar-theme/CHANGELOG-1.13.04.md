# EVazar Theme 1.13.04

- Rebased on 1.13.02 to restore the original vertically centered navigation button placement.
- Reduced desktop-only Special Offers wrapper gutters from 42px to 24px per side so a 1360px carousel wrapper can fit six 205px product cards with 12px gaps.
- Removed the 1.13.03 top navigation strip and its JavaScript button positioning/rail behavior by reverting to the 1.13.02 layout logic.
- Adjusted the two desktop arrow offsets to keep the controls in their original centered positions outside the product cards.
- Other homepage carousels and mobile layout are unchanged.
