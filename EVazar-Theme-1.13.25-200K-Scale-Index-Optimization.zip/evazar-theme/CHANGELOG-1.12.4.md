# Changelog 1.12.4

## Related products relevance
- Reworked single-product related/recommended selection.
- Highest priority is the exact deepest category combined with the same brand.
- Shared categories and same brand are scored separately so mixed-category results remain relevant.
- Products from the same category branch receive a lower relevance score.
- Only when relevant candidates are insufficient, the list is filled with the newest available products.
- Candidate categories are fetched in bulk to avoid per-product N+1 taxonomy queries.
- Existing availability/price filtering and the admin product-count setting are preserved.
