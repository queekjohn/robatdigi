# EVazar Theme — Consolidated Historical Changelog

Historical release notes consolidated from older per-version changelog files. Recent releases (1.13.12–1.13.18) remain separate.


---

<!-- consolidated from CHANGELOG-1.10.0.md -->

# EVazar Theme 1.10.0

- Availability is now determined by current price > 0.
- Worker `explicit_unavailable` is a hard override even when a stale positive price exists.
- Archive stock filter, stock ordering and live-search stock filtering use the same canonical rule.
- Product Index price remains the fast source for archive availability checks.


---

<!-- consolidated from CHANGELOG-1.10.1.md -->

# EVazar Theme 1.10.1

- وضعیت موجودی فیلتر آرشیو با قیمت فعلی (`_evazar_current_price > 0`) و override صریح `explicit_unavailable` یکسان شد.
- محاسبه تعداد موجود/کل دیگر به JOIN ناقص Product Index وابسته نیست و در زمان Backfill باعث حذف فیلتر نمی‌شود.
- کش Smart Facets به نسخه جدید منتقل شد تا نتیجه قدیمی `stock_mixed` استفاده نشود.
- فیلتر «وضعیت کالا» در آرشیو محصولات به‌صورت پایدار نمایش داده می‌شود و برای «فقط کالاهای موجود» استفاده می‌شود.
- اولویت قرار گرفتن کالاهای ناموجود در انتهای نتایج با همین منطق موجودی هماهنگ شد.


---

<!-- consolidated from CHANGELOG-1.10.10.md -->

# EVazar Theme 1.10.10

- Restored archive product-card image markup to the stable 1.10.6 behavior: lazy loading without `fetchpriority`, intrinsic width/height attributes, or eager promotion.
- Removed the 1.10.9 CSS scale workaround because it did not correct the source-image framing.
- Kept the 1.10.7 accessibility/heading improvements and other unrelated performance work intact.


---

<!-- consolidated from CHANGELOG-1.10.11.md -->

# EVazar Theme 1.10.11

- Fixed an archive price-filter state bug where the slider's smart/default maximum could be rounded into a real `max_price` form value even when the user had never enabled the price filter.
- Kept smart minimum/maximum values as UI bounds only until the user explicitly changes a price handle or numeric field.
- Made slider endpoints exact so the real smart minimum/maximum are never rounded inward by the step size.
- Hardened pagination/sort URL merging so `min_price`/`max_price` are copied only while the price filter is explicitly active; stale/default values are removed from navigation URLs.
- No changes to EVazar Core 2.8.66, Worker 1.9.9, image delivery, archive-card markup, or current performance/image behavior.


---

<!-- consolidated from CHANGELOG-1.10.2.md -->

# EVazar Theme 1.10.2

- بازطراحی کامل ظاهر فیلترهای آرشیو بدون تغییر در منطق فیلتر، AJAX یا پارامترهای فرم.
- بهبود سلسله‌مراتب بصری عنوان بخش‌ها، جستجو، چک‌باکس‌ها، سوییچ موجودی و بازه قیمت.
- بهبود فاصله‌گذاری، کنتراست، حالت‌های hover/focus و تجربه لمس در موبایل.
- حفظ فونت و رنگ‌های اصلی EVazar و سازگاری با RTL.


---

<!-- consolidated from CHANGELOG-1.10.3.md -->

# EVazar Theme 1.10.3

- بازطراحی فلش‌های جمع/باز شدن بخش‌های فیلتر.
- حذف وابستگی به کاراکتر متنی `⌃` و جایگزینی با chevron خالص CSS برای نمایش یکدست‌تر.
- بهبود حالت hover، focus و expanded/collapsed.
- بدون تغییر در منطق فیلتر، AJAX یا پارامترهای فیلتر.


---

<!-- consolidated from CHANGELOG-1.10.4.md -->

# EVazar Theme 1.10.4

- بازطراحی فلش‌های باز/بسته فیلترها.
- رفع تداخل transform روی کانتینر فلش که باعث می‌شد حالت باز و بسته از نظر بصری یکسان یا ناپایدار دیده شود.
- حالت باز: chevron رو به بالا.
- حالت بسته: chevron رو به پایین.
- منطق AJAX و عملکرد فیلترها بدون تغییر باقی مانده است.


---

<!-- consolidated from CHANGELOG-1.10.5.md -->

# EVazar Theme 1.10.5

- Fixed Lighthouse Agent Accessibility audit for the price range slider by assigning the correct `slider` ARIA role to both handles.
- Added horizontal slider semantics while preserving existing keyboard and pointer interactions.
- Reworked filter section collapse chevrons so open and closed states are visually distinct.
- Updated filter arrow markup to decorative, accessible controls.
- Synchronized `readme.txt` theme version with `style.css` (1.10.5).


---

<!-- consolidated from CHANGELOG-1.10.6.md -->

# EVazar Theme 1.10.6

- Reduced archive/home product image payloads by requesting 360px CDN variants without storing files on the host.
- Product gallery thumbnails now use 160px CDN variants while keeping the full image URL for the actual gallery.
- Lightbox thumbnails now use 120px CDN variants.
- Added intrinsic 800x800 dimensions to the main product image to reduce layout shifts.
- Archive filter CSS/JS now loads only on relevant product archive, taxonomy, search, and directory views.
- Live product price inquiry is scheduled during browser idle time with a short timeout fallback so initial rendering and image loading receive priority.
- Added a preconnect resource hint for the configured image CDN.


---

<!-- consolidated from CHANGELOG-1.10.7.md -->

# EVazar Theme 1.10.7

- Archive first two product-card images are loaded eagerly; only those two receive `fetchpriority="high"` because the measured archive LCP was the second product image.
- Remaining archive product images continue using lazy loading.
- Added intrinsic 360x360 dimensions to archive card images.
- Added a `<main id="primary">` landmark around archive content.
- Corrected archive heading hierarchy so direct sections use H2 and nested category headings use H3.
- Improved contrast for active sort controls, archive prices, discount/price-drop badges, and footer copyright text.


---

<!-- consolidated from CHANGELOG-1.10.8.md -->

# EVazar Theme 1.10.8

- Reverted the aggressive archive image prioritization introduced in 1.10.7 after real-world testing showed QUIC_NETWORK_IDLE_TIMEOUT errors on the first two product images.
- Only the first archive product image is now `loading="eager"`; all subsequent product-card images remain lazy.
- Removed archive `fetchpriority="high"` from product-card images to reduce connection/priority pressure.
- Kept 360×360 intrinsic dimensions and the existing CDN URL strategy unchanged.


---

<!-- consolidated from CHANGELOG-1.10.9.md -->

# EVazar Theme 1.10.9

- Reduced excessive white space visible inside many source product images on archive cards by applying a CSS-only `scale(1.08)` to `.archive-product-card .card-product-img`.
- Archive hover scale adjusted to `1.12` so hover no longer visually shrinks the image relative to the base scale.
- No image files are stored or regenerated; the existing `img.evazar.ir`, 360×360 CDN URL strategy, Cloudflare cache, and lazy/eager loading behavior remain unchanged.
- No changes to EVazar Core or Cloudflare Worker.


---

<!-- consolidated from CHANGELOG-1.12.0.md -->

# EVazar Theme 1.12.0

## CSS / performance optimization
- Split the monolithic `style.css` into page-scoped styles for single product, archive/search, front page, about, brand directory, and 404 pages.
- Added conditional enqueueing so page-specific CSS is sent only on the pages that use it.
- Removed only legacy CSS selectors proven absent from the theme PHP/JS source, while preserving WordPress/runtime state classes and classes generated dynamically from options.
- Kept the existing visual CSS declarations intact; this release is an organization/loading optimization rather than a redesign.
- `theme-interactions.js` is now loaded only where its homepage/archive interactions are used.
- Search CSS/JS is loaded only when the header search feature is enabled.
- Preserved the 1.11.1 duplicate mobile search fix for the 769–991px range.
- Bumped theme version to 1.12.0 for deterministic cache invalidation.


---

<!-- consolidated from CHANGELOG-1.12.1.md -->

# EVazar Theme 1.12.1

## Floating back-to-top button
- Converted the footer back-to-top control into a floating fixed button so it remains accessible while scrolling.
- On mobile single-product pages, the button is positioned above the sticky mobile buy bar and respects the device safe-area inset.
- Kept the existing smooth-scroll behavior and added an accessible label/title.
- Bumped the theme version to 1.12.1 for deterministic cache invalidation.


---

<!-- consolidated from CHANGELOG-1.12.10.md -->

# EVazar Theme 1.12.10

- Fixed excessive top/bottom white space inside archive product cards caused by forcing responsive product images to a square 360x360 intrinsic ratio.
- Responsive `srcset`/`sizes` image optimization is preserved.
- Archive product images are passed to the responsive renderer at their original URL, avoiding an unnecessary pre-transform step.
- Card layout reservation remains controlled by the existing `.card-thumb-wrap` `aspect-ratio: 1`.


---

<!-- consolidated from CHANGELOG-1.12.11.md -->

# EVazar Theme 1.12.11

- Homepage product images no longer receive `loading="eager"` or `fetchpriority="high"`.
- Keeps the responsive image (`srcset`/`sizes`) optimization from 1.12.9/1.12.10.
- Prevents below-hero product imagery from being incorrectly prioritized as the homepage LCP candidate.
- No changes to product/category/brand archive image loading behavior.


---

<!-- consolidated from CHANGELOG-1.12.12.md -->

# EVazar Theme 1.12.12

- Removed the external Digikala affiliate-logo image request from the global header to eliminate an unnecessary third-party network dependency.
- Kept the affiliate badge text intact.
- Added defensive above-the-fold visibility rules for the homepage hero so the primary H1/content remains paintable and cannot be hidden by a generic opacity/visibility rule or animation.
- Updated the theme package version to 1.12.12.


---

<!-- consolidated from CHANGELOG-1.12.14.md -->

# EVazar Theme 1.12.14

- Fixed the homepage render path for LCP by inlining critical above-the-fold CSS for the top notice, header and homepage hero.
- Converted homepage theme stylesheets (local fonts, main theme CSS, search CSS and front-page CSS) to non-blocking preload-to-stylesheet loading with a `<noscript>` fallback.
- Kept the existing full stylesheets and their cascade intact so the visual design and below-the-fold components continue to use the original CSS.
- Removed the extra homepage logo `<h1>` and replaced it with a styled non-heading element so the hero remains the sole primary homepage H1.
- Kept affiliate/product/import logic unchanged.


---

<!-- consolidated from CHANGELOG-1.12.15.md -->

# EVazar Theme 1.12.15

- Reverted homepage stylesheets from preload-to-stylesheet loading to normal stylesheet loading to eliminate the large first-paint visual flash and the associated CLS caused by late CSS application.
- Kept the homepage critical CSS, but removed the conflicting asynchronous CSS mechanism.
- Added intrinsic `width="360"` and `height="360"` hints to the shared responsive product-image renderer so image space is reserved before CDN responses arrive; CSS `object-fit: contain` continues to preserve the image's visual aspect ratio.
- Added `defer` strategy to the lightweight back-to-top, live-search and homepage interaction scripts.
- Delayed the rail/interaction bootstrap until the browser reaches an idle/load opportunity so initial rendering is not held up by overflow measurements on below-the-fold sections.
- Added the supplied homepage preview image as the WordPress theme `screenshot.png` and a compact `screenshot.webp` copy.
- Kept affiliate, product, import and site logic unchanged.


---

<!-- consolidated from CHANGELOG-1.12.2.md -->

# EVazar Theme 1.12.2

## Smart floating back-to-top button
- Moved the floating back-to-top button to the left side on desktop and mobile.
- Kept the button hidden until the user scrolls more than 400px down the page.
- Uses a lightweight passive scroll listener with `requestAnimationFrame` to avoid unnecessary work during scrolling.
- Preserved the existing mobile sticky-buybar spacing, safe-area handling, responsive sizing, and smooth-scroll behavior.
- Bumped the theme version to 1.12.2 for deterministic cache invalidation.


---

<!-- consolidated from CHANGELOG-1.12.21.md -->

EVazar Theme 1.12.21
====================

Base: 1.12.15 (last known homepage build that produced a valid LCP in the user's Lighthouse test).

Only functional/theme change:
- Restored the proven 1.12.18 homepage deal-card anti-stretch rules.

Intentionally unchanged from 1.12.15:
- Homepage critical CSS strategy
- JavaScript loading/defer behavior
- Search JavaScript
- Back-to-top JavaScript
- Theme interactions JavaScript
- Responsive product-image rendering helper
- Homepage HTML structure


---

<!-- consolidated from CHANGELOG-1.12.23.md -->

# EVazar Theme 1.12.23

- Isolated homepage deal-card geometry test based directly on 1.12.21.
- Restored full thumbnail image sizing (`width/height: 100%`, `max-width/max-height: 100%`) without cropping; this removes the artificial 90% inset.
- Removed forced two-line title height so short titles do not reserve unused vertical space.
- No changes to PHP logic, JavaScript, image loading priority, affiliate behavior, importer, search, product data, or LCP strategy.


---

<!-- consolidated from CHANGELOG-1.12.24.md -->

# EVazar Theme 1.12.24

- Restored the homepage Deals card geometry to the proven 1.12.18 `front-page.css`.
- Restored the exact 1.12.18 spacing values for the Deals section/card: section `margin-top: -8px`, product-card `padding: 8px`, and thumbnail `margin-bottom: 6px`.
- Kept the 1.12.18 card stretch fix (`align-items: flex-start`, zero product-card `min-height`/`height`, and top-aligned content).
- Kept the current 1.12.23 PHP behavior, including deferred small interaction scripts and the current intrinsic image width/height hints.
- Removed the unsuccessful 1.12.23 title-height test; the title CSS is again exactly as in the proven 1.12.18 stylesheet.
- No affiliate, product, import, search, product-data, or ordering logic changes.


---

<!-- consolidated from CHANGELOG-1.12.25.md -->

# EVazar Theme 1.12.25

## Homepage deal-card isolated intrinsic-size test

- Preserves the homepage `front-page.css` exactly as in v1.12.18.
- Removes the global `width="360" height="360"` attributes from `evazar_render_responsive_product_image()`.
- No changes to deal HTML, JavaScript, loading/eager strategy, affiliate logic, product queries, or CSS geometry.
- This isolates the only layout-relevant PHP renderer difference remaining between v1.12.18 and the newer theme versions.


---

<!-- consolidated from CHANGELOG-1.12.26.md -->

# Evazar Theme 1.12.26

## تغییرات
- افزودن گزینه فعال/غیرفعال‌کردن مستقل بنر Hero صفحه اصلی در تب تنظیمات صفحه اصلی قالب.
- وضعیت پیش‌فرض Hero فعال است تا رفتار نسخه قبلی بدون تغییر باقی بماند.
- غیرفعال‌کردن Hero فقط خروجی همان بخش را از فرانت‌اند حذف می‌کند و ترتیب سایر بخش‌های صفحه اصلی حفظ می‌شود.
- هیچ تغییری در CSS کارت‌های Deal، LCP، JavaScript، تصاویر، importer یا منطق affiliate اعمال نشده است.

## هدف تست
این گزینه برای تست مستقیم اثر وجود یا عدم وجود Hero بر `NO_LCP` صفحه اصلی اضافه شده است.


---

<!-- consolidated from CHANGELOG-1.12.3.md -->

# Changelog 1.12.3

## Back-to-top visibility fix
- Fixed the back-to-top button not appearing on product and other non-home/archive pages.
- Added a dedicated lightweight `back-to-top.js` asset loaded globally.
- Removed the back-to-top logic from the archive/home interaction bundle to avoid unnecessary coupling.
- Preserved the 400px scroll threshold, left-side positioning, mobile sticky-buybar spacing, safe-area handling, and smooth scrolling.


---

<!-- consolidated from CHANGELOG-1.12.36.md -->

# EVazar Theme 1.12.36

- Diagnostic-only patch: fixed JavaScript quoting for the LCP report transport URL in the head observer.
- No visual, layout, or production behavior changes outside the diagnostic URL.


---

<!-- consolidated from CHANGELOG-1.12.37.md -->

# EVazar Theme 1.12.37

## LCP diagnostic refinement
- Keeps the v1.12.36 head-installed LCP observer.
- Adds direct `performance.getEntriesByType("largest-contentful-paint")` inspection.
- Adds `PerformanceObserver.takeRecords()` inspection before the final report.
- No production CSS/layout/feature changes.


---

<!-- consolidated from CHANGELOG-1.12.38.md -->

# EVazar Theme 1.12.38

## LCP / Hero font stability

- Removed the temporary LCP diagnostic instrumentation from the production theme.
- Added a dedicated `VazirmatnLCP` font face for the homepage Hero H1 with `font-display: block`.
- Applied the dedicated font only to the Hero H1 when the active theme font is Vazirmatn, preventing late font-swap on the primary LCP text element.
- Preserved the existing 1.12.25+ homepage deal-card spacing fix (no restoration of 360×360 intrinsic image hints).
- No changes to homepage card layout, product rendering, affiliate behavior, or non-homepage functionality.


---

<!-- consolidated from CHANGELOG-1.12.39.md -->

# EVazar Theme 1.12.39

## Homepage Brands / LCP stability

- Preserved the existing horizontal brand rail and button navigation.
- Added `scroll-padding-inline: 4px` to match the rail's 4px inline padding while keeping `scroll-snap-type: x mandatory`.
- This prevents an unnecessary initial snap adjustment during first layout, while preserving the normal post-load swipe/snap behavior.
- Reverted the experimental `VazirmatnLCP` / `font-display: block` Hero H1 change from 1.12.38 because it did not resolve the intermittent `NO_LCP` issue.
- Preserved all existing homepage product-card spacing fixes and affiliate-only functionality.


---

<!-- consolidated from CHANGELOG-1.12.4.md -->

# Changelog 1.12.4

## Related products relevance
- Reworked single-product related/recommended selection.
- Highest priority is the exact deepest category combined with the same brand.
- Shared categories and same brand are scored separately so mixed-category results remain relevant.
- Products from the same category branch receive a lower relevance score.
- Only when relevant candidates are insufficient, the list is filled with the newest available products.
- Candidate categories are fetched in bulk to avoid per-product N+1 taxonomy queries.
- Existing availability/price filtering and the admin product-count setting are preserved.


---

<!-- consolidated from CHANGELOG-1.12.40.md -->

# EVazar Theme 1.12.40

- Product gallery and fullscreen lightbox now use double-buffered image crossfade transitions.
- The next image is fully loaded and decoded before becoming visible, eliminating the visible jump/flash during image changes.
- Product-page image recovery is now presentation-only: Core owns CDN failover, while Theme owns the final placeholder.
- Removed the duplicate browser retry to `evazar_retry=1` that could race with Core failover and delay recovery on mobile.
- Desktop hover zoom follows whichever gallery image is currently active.


---

<!-- consolidated from CHANGELOG-1.12.41.md -->

# EVazar Theme 1.12.41

- Added compatibility with Core page-wide image Direct Mode recovery.
- Product gallery image URLs now normalize back to the configured EVazar CDN when Core's 10-minute health probe confirms recovery.
- Existing double-buffered gallery/lightbox crossfade remains unchanged.


---

<!-- consolidated from CHANGELOG-1.12.42.md -->

# EVazar Theme 1.12.42

- Mobile category mega menu locks the page behind it while preserving independent internal scrolling.
- Long category names are contained and wrap safely on narrow screens.
- Duplicate category icon beside the mobile submenu heading is hidden; the primary category icon remains.
- Product sticky-bar clearance is moved from the document body into the product-page footer so no blank strip appears below the footer.
- Image/Failover and gallery crossfade logic is unchanged.


---

<!-- consolidated from CHANGELOG-1.12.43.md -->

# EVazar Theme 1.12.43

- Removed the duplicate category icon from the submenu panel header on desktop as well as mobile; the primary icon in the category sidebar remains.
- No image, Failover, gallery, Lightbox, product-page, or other UX logic was changed.


---

<!-- consolidated from CHANGELOG-1.12.44.md -->

# EVazar Theme 1.12.44

- Replaced only the standalone `/product-category/` directory UI with an isolated searchable accordion/tree.
- Preserved the existing header category mega menu and other archive/product/image logic.
- Added responsive behavior for desktop/mobile without image assets.
- Bumped theme asset version for cache busting.


---

<!-- consolidated from CHANGELOG-1.12.45.md -->

# EVazar Theme 1.12.45

- Category directory accordion controls changed to a minimal chevron (no circular button).
- Clearing category search now restores the full tree in a fully collapsed state.
- Large category branches now use bounded internal scrolling instead of expanding into very tall panels.
- No image, Failover, product gallery, lightbox, header category menu, or unrelated page logic changes.


---

<!-- consolidated from CHANGELOG-1.12.46.md -->

# EVazar Theme 1.12.46

- Replaced the local/handcraft category icon with a cleaner woven-basket style icon everywhere `evazar_get_category_icon()` maps those categories.
- Replaced category-directory accordion chevrons with a minimal CSS plus/minus control.
- No changes to image loading, image failover, gallery, lightbox, or product-page logic.


---

<!-- consolidated from CHANGELOG-1.12.47.md -->

# EVazar Theme 1.12.47

- Removed child-category count labels from the standalone product category directory.
- On mobile homepage only, the "مشاهده همه دسته‌ها" link in the featured categories section now opens the existing full-screen category menu instead of navigating to /product-category/.
- No changes to image loading, image failover, gallery, lightbox, or product-page logic.


---

<!-- consolidated from CHANGELOG-1.12.49.md -->

# EVazar Theme 1.12.49

- Removed the red radial-gradient halo from the homepage hero card.
- No hero image, text, search, category, image-loading, failover, gallery, or lightbox logic changed.


---

<!-- consolidated from CHANGELOG-1.12.5.md -->

# Changelog 1.12.5

## Related products display fix
- Preserved all existing related-products theme settings: show/hide, item count, and hide-out-of-stock.
- Fixed the availability filter for older imported products that do not yet have `_evazar_is_available`.
- Products with a valid positive current price are no longer incorrectly excluded just because the availability meta key is missing.
- Explicit availability values `1`, `yes`, and `true` remain eligible.
- No changes to the relevance scoring order.


---

<!-- consolidated from CHANGELOG-1.12.50.md -->

# EVazar Theme 1.12.50

- Mobile archive product cards: compacted the price-drop badge.
- Mobile label is now «افت قیمت» instead of the longer «افت قیمت امروز».
- Removed the emoji/icon from the mobile label while keeping the existing down-arrow SVG.
- Reduced mobile badge padding/font size so the product image remains more visible when a discount badge is also present.
- Desktop badge appearance remains unchanged.
- No JavaScript or layout logic added; infinite/AJAX-injected product cards inherit the same CSS automatically.


---

<!-- consolidated from CHANGELOG-1.12.53.md -->

# EVazar Theme 1.12.53

- Restored lightweight infinite scroll for product lists on category and brand archive pages.
- Infinite scroll uses the existing archive filter AJAX endpoint, preserves current filters/sort, loads one page at a time, and keeps normal pagination as a fallback.
- Newly appended product images remain lazy-loaded and are exposed through a `evazar:products-appended` event for image handling observers.
- Removed the duplicate lower price input boxes visually; the underlying fields remain in the DOM so the existing slider/filter state and form submission continue to work.
- No unrelated product-card or price-drop presentation changes.


---

<!-- consolidated from CHANGELOG-1.12.58.md -->

# Evazar Theme 1.12.58

- Improved mobile gallery thumbnail selection using touch pointer events.
- Prevented duplicate synthetic click handling after a touch selection.
- Kept desktop click behavior and lightbox implementation unchanged.
- Preserved the existing gallery markup, image URLs, CDN handling, and lazy loading.

Note: syntax/package checks do not replace testing on a real mobile browser.


---

<!-- consolidated from CHANGELOG-1.12.6.md -->

# Changelog 1.12.6

## Related Products — Display Fix
- Preserved the theme options for show/hide, count, and hide-out-of-stock.
- Removed the fragile availability meta constraint from the main candidate WP_Query.
- Applied the availability rule after fetching candidates, with legacy-product compatibility.
- Added category, brand, branch, and newest-product pools with lightweight scoring.
- Prevented the section from disappearing because an older product is missing availability metadata.


---

<!-- consolidated from CHANGELOG-1.12.62.md -->

# Version 1.12.62

- Fixed mobile gallery image-layer visibility by synchronizing the active image class with the layer that finishes loading.
- Removed `!important` from mobile active/buffer opacity rules so the JavaScript crossfade can control visibility.
- Made thumbnail auto-scroll direction-aware: moving backward keeps the previous thumbnail visible; moving forward keeps the next thumbnail visible.
- No changes to the lightbox image-selection flow or the gallery image URL/failover strategy.


---

<!-- consolidated from CHANGELOG-1.12.63.md -->

# Version 1.12.63

- Removed decorative icons from the price-drop banner on product pages.
- Preserved the price-drop text and amount, product gallery, and lightbox behavior.


---

<!-- consolidated from CHANGELOG-1.12.65.md -->

# 1.12.65

- Mobile product gallery now updates a single stable image element after preloading, avoiding alternating double-buffer opacity layers.
- Thumbnail auto-scroll now uses RTL-aware `scrollIntoView` for both forward and reverse movement.
- Lightbox thumbnail auto-scroll tracks navigation direction explicitly.
- Desktop gallery crossfade and lightbox image-transition logic remain in place.


---

<!-- consolidated from CHANGELOG-1.12.66.md -->

# EVazar Theme 1.12.66

- Enabled infinite scroll on the main `/product/` product archive as well as existing brand/category archives.
- Numbered pagination is visually hidden only after the infinite-scroll controller initializes; its links remain available to JavaScript.
- Increased the prefetch distance so the next batch starts loading before the visitor reaches the bottom.
- Kept the loader as the only visible loading indicator and removed visible pagination counts from infinite-scroll archives.
- Newly appended product images use asynchronous decoding; the first four images in each fetched batch are eager-loaded for faster perceived rendering, with the rest lazy-loaded.
- No gallery, lightbox, product-detail, or price-drop code changed.


---

<!-- consolidated from CHANGELOG-1.12.67.md -->

EVazar Theme 1.12.67

- Changed the archive price-filter heading to “بازه قیمت (تومان)”.
- Removed the separate “تومان” label beneath the price filter controls.
- No gallery, lightbox, product page, infinite-scroll, or filter behavior changes.


---

<!-- consolidated from CHANGELOG-1.12.68.md -->

EVazar Theme 1.12.68

- Added timeout, cancellation, generation guards, one bounded automatic retry for transient network/timeout/server errors, and a manual retry path for archive infinite scroll.
- Re-checks the sentinel after products are appended or filters replace archive content.
- Keeps appended product images lazy-loaded.
- Added a lightweight AJAX response for infinite-scroll requests, skipping filter HTML and smart-filter recomputation while preserving normal filter responses.
- Added a unique product ID tie-breaker to archive sorting to make pagination deterministic for equal sort values.
- Restores numbered pagination when infinite-scroll loading fails.
- Repaired literal escaped newlines in archive-filters.css that caused a CSS declaration parse error.


---

<!-- consolidated from CHANGELOG-1.12.69.md -->

EVazar Theme 1.12.69

- Fixed the smart archive brand facet being limited to the first 120 alphabetically sorted brand terms. All non-empty brand terms are now considered before context-aware product matching, so brands such as Sony can appear in the category filter when published products in that archive are assigned to them.
- Bumped the smart-facet transient cache namespace to prevent stale brand lists from the previous implementation being reused.
- The live brand search endpoint and its context-aware filtering behavior remain unchanged.


---

<!-- consolidated from CHANGELOG-1.12.7.md -->

# Changelog 1.12.7

## Related products — canonical availability fix
- با منطق موجودی `evazar-core` هماهنگ شد.
- `_evazar_availability_source=explicit_unavailable` تنها سیگنال صریح ناموجودی است؛ قیمت معتبر به‌تنهایی باعث حذف کالا نمی‌شود.
- نرمال‌سازی ارقام فارسی/عربی و جداکننده‌های عددی اضافه شد.
- استخرهای پشتیبان برای جلوگیری از خالی ماندن بخش حفظ شدند.
- تنظیمات خود قالب برای نمایش/تعداد/عدم نمایش ناموجودها دست‌نخورده باقی ماند.


---

<!-- consolidated from CHANGELOG-1.12.70.md -->

EVazar Theme 1.12.70

- Improved mobile infinite-scroll image readiness: the first two images in each AJAX-loaded product batch use eager loading on viewports up to 720px; all later images remain lazy-loaded. Appended images never receive high fetch priority.
- Increased the mobile infinite-scroll prefetch distance from 1500px to 2000px so the next product batch has more time to arrive during scrolling. Desktop remains at 1500px.
- Kept the existing request timeout/retry, stale-request protection, filters, sorting, pagination fallback, image CDN URL generation, and initial-page LCP priority behavior unchanged.
- Live CDN/cache timing could not be measured in the build environment because DNS resolution for evazar.ir and img.evazar.ir was unavailable; this change does not alter the CDN routing or cache configuration.


---

<!-- consolidated from CHANGELOG-1.12.71.md -->

EVazar Theme 1.12.71

- Fixed infinite-scroll URL synchronization on product archives, brand archives, and category archives.
- Prefetching an AJAX page no longer changes the browser address by itself.
- The address now tracks the page whose first appended product has reached the reading position; scrolling back restores the corresponding earlier page URL.
- Keeps numbered pagination links, retry/timeout behavior, AJAX filters and sorting, and mobile image-loading optimization from 1.12.70.
- Limits the change to archive-filters.js, the theme version header, and this changelog.


---

<!-- consolidated from CHANGELOG-1.12.72.md -->

# Evazar Theme 1.12.72 — Search/Core reconciliation

- Fixed full-page product-code searching against Product Index: wildcard matching now uses `LIKE` rather than `=` with percent characters.
- Normalized Persian/Arabic digits and DKP prefix for the main site search.
- Full-page search also matches an exact numeric internal EVazar product ID while keeping the result constrained to published `evazar_product` posts.
- Live AJAX search now removes the `DKP-` prefix correctly, so the SKU/DKP fallback can match stored numeric codes.
- Live AJAX search performs exact ID and exact DKP metadata lookups in addition to title search, respects the existing in-stock filter, and prioritizes identity matches.
- If a code/ID lookup resolves a product but ordinary title suggestions are empty, the matched product title is shown as a searchable suggestion.
- Search transient namespace advanced to `evz_srch_v18_` to avoid serving results cached before these changes.


---

<!-- consolidated from CHANGELOG-1.12.73.md -->

# EVazar Theme 1.12.73

- Aligned the theme fallback `evazar_cdn_image_url()` implementation with Core 2.9.0 so the active function's `x-oss-process` sizing behavior is consistent.
- The URL helper respects `evazar_image_direct_mode` and directs new image markup to the original Digikala image host while direct mode is active.
- Kept the page-wide image failover script, gallery behavior, lazy loading, and other product UI code unchanged.
- No theme search, archive infinite-scroll, gallery layout, or product price-display logic was otherwise changed in this version.


---

<!-- consolidated from CHANGELOG-1.12.74.md -->

# EVazar Theme 1.12.74

- Fixed the fallback CDN URL helper so size parameters modify only the `image/resize` stage and preserve subsequent OSS operations.
- Core helper remains canonical when Core is active.
- Paired with Core 2.9.1 CDN failover changes; image fallback now handles placeholder `src` and lazy `srcset` scenarios without losing source candidates.


---

<!-- consolidated from CHANGELOG-1.12.75.md -->

# EVazar Theme 1.12.75 — Product-first AJAX Search

- AJAX dropdown now returns and renders up to five real EVazar product cards with thumbnail, title, code, price and availability instead of displaying only phrase suggestions.
- Search ranking prioritizes exact DKP/SKU/internal ID matches, then exact/prefix/substring title matches, then title token coverage. Results are bounded to a small set of candidates.
- Supports partial title fragments and order-independent multiword search through WordPress search, numeric internal IDs, DKP with or without `DKP-` (including a space after the prefix), Persian/Arabic digits, separator variants, and exact alphabetic SKU values.
- Main product search adds identifier conditions inside WordPress' `posts_search` predicate rather than appending an ungrouped `OR` to the whole SQL `WHERE`; it preserves the anonymous-user `post_password` predicate and leaves non-product searches alone.
- AJAX request length is capped at 80 Unicode characters. Candidate queries skip unnecessary `found_rows` and unused post-term cache priming. Result cache uses `evz_srch_v20_` with a 60-second TTL to invalidate older results.
- Desktop/mobile requests have independent debounce/abort/stale-response tracking. Keyboard navigation targets product cards, and text highlighting escapes every original text segment before adding `<mark>` tags.
- “Did you mean?” can display when no product/category/brand result exists.
- AJAX product images include a direct-source fallback only for the known EVazar image CDN or Digikala image host. The direct URL is tried once after a CDN error, then a placeholder is shown.
- Existing categories, brands, recent/popular searches, stock-only filter and “view all results” link are retained.

## Validation

PHP lint passed for all 12 theme PHP files; Node syntax checks passed for all 4 theme JavaScript files. Focused tests covered the search SQL predicate for DKP, numeric internal ID, alphabetic SKU, non-product queries, and preserving the anonymous `post_password` condition. Static contracts for the AJAX action/nonce/products payload and image-fallback retry passed. A focused test also verified safe title highlighting with HTML-like text.

Full WordPress/MariaDB runtime and real browser/load testing were not available in this build environment. This release changes the theme's search paths only; no core, Worker or database migration is required.


---

<!-- consolidated from CHANGELOG-1.12.76.md -->

# EVazar Theme 1.12.76 — Smart AJAX Search Restored and Expanded

- AJAX now displays real products and independent smart sections at the same time: spell correction, related search phrases, matching categories and matching brands.
- Brand matching checks the cached term name, slug, product English-brand metadata aliases, and Persian/English known aliases. It supports phrase token matching (e.g. «گوشی آیفون» → Apple) without running a term lookup for every typed token.
- Category matching scores the cached category index by exact phrase, prefix, token overlap and conservative edit-distance matching; it now supports multiword phrases such as a product type combined with a brand.
- Spelling suggestions use a transient-cached lexicon assembled from a curated base, actual category/brand terms, brand aliases and up to 2,500 recent product titles. The product-title scan runs only during lexicon cache construction (6-hour TTL), not per keypress. A short transient lock avoids concurrent rebuilds.
- Only one unambiguous word is suggested at a time. Prefixes during normal typing are not treated as spelling errors; the user query is never changed unless the user clicks the correction.
- Search cache namespace bumped to v21; category/brand term indexes bumped and invalidated when terms change.
- Related query phrases remain visible beside product hits (up to three), excluding exact duplicates of shown product titles. Categories/brands remain independent sections. Suggestion rows support Enter/Space activation.
- Existing product ranking, internal-ID/DKP/SKU handling, stock toggle, image fallback, gallery, infinite scroll and product archive logic are otherwise unchanged.

## Validation

- PHP syntax lint passed for all theme PHP files.
- Node syntax check passed for all theme JavaScript files.
- Focused static checks cover category/brand cache-version invalidation, alias matching, term-token scoring, cached spelling lexicon, single-word correction guard, UI display alongside products, keyboard activation, AJAX action/nonce contract and cache namespace.
- Full WordPress/MariaDB runtime/browser testing was not available in this build environment; staging validation is still recommended before production deployment.


---

<!-- consolidated from CHANGELOG-1.12.78.md -->

# EVazar Theme 1.12.78 — ICO Favicon Upload Support

- Added a theme-level WordPress MIME allowlist entry for `.ico` files so administrators can upload favicon files through Media Library.
- Added a narrow file-type detection fallback for `.ico` uploads that checks the standard ICO header before assigning the `image/x-icon` MIME type.
- No changes to search, related products, archive filters, infinite scroll, gallery, or frontend rendering.

## Validation

- PHP syntax lint: pending package build validation.
- ICO validation is limited to files with the expected ICO header; this does not disable WordPress upload security globally.


---

<!-- consolidated from CHANGELOG-1.12.79.md -->

# EVazar Theme 1.12.79 — Favicon Output Fix

- The custom Favicon setting now outputs explicit `rel=icon` markup with an appropriate MIME type for ICO, PNG, and SVG URLs.
- When a custom theme favicon is configured, WordPress core Site Icon output is removed for that request so it cannot compete with the selected favicon.
- No search, related-products, gallery, archive-filter, or infinite-scroll code was changed.
- Browser/CDN cache may still need to be refreshed after changing the favicon.


---

<!-- consolidated from CHANGELOG-1.12.8.md -->

# Changelog 1.12.8

## Related Products — Core Product Index Engine
- انتخاب محصولات مرتبط از Theme خارج شد و به EVazar Core منتقل شد.
- Theme فقط تنظیمات نمایش/تعداد/عدم‌نمایش ناموجودها و رندر کارت‌ها را مدیریت می‌کند.
- منطق رتبه‌بندی Core: دسته/زیرشاخه + برند > دسته/زیرشاخه > دسته مشترک > شاخه مرتبط > برند > جدیدترین.
- فیلتر موجودی از `stock_status` هسته استفاده می‌کند.
- Queryهای per-candidate روی postmeta و taxonomy برای Related Products حذف شدند.


---

<!-- consolidated from CHANGELOG-1.12.81.md -->

# EVazar Theme 1.12.81

- Hide the header quick-navigation bar (categories, popular brands, special offers) on mobile single-product pages only.
- Keep the bar visible on desktop and on all other page types.
- CSS-only, scoped to `body.single-evazar_product` at viewport widths up to 768px; no product gallery or image-loading logic changed.


---

<!-- consolidated from CHANGELOG-1.12.82.md -->

# EVazar Theme 1.12.82

- Added low-priority preloading for only the immediately previous and next full-size product gallery images after the current image is ready.
- Reuses the same image URLs and browser cache for the product gallery and fullscreen lightbox.
- Failed preload requests are removed from the small in-memory cache so transient failures can retry.
- No markup, styling, swipe, gallery transition, image recovery, or lightbox navigation behavior intentionally changed.


---

<!-- consolidated from CHANGELOG-1.12.83.md -->

# EVazar Theme 1.12.83

- Prevent mobile product-gallery switching from waiting indefinitely on a detached image preload. After a bounded wait, the real gallery image is activated so core recovery can handle CDN/origin failures.
- Expire stalled adjacent-image preload entries and retry only adjacent images after the browser reports connectivity restored.
- No intended changes to gallery markup, CSS, swipe controls, lightbox layout, archive behavior, or product data.


---

<!-- consolidated from CHANGELOG-1.12.84.md -->

# EVazar Theme 1.12.84 — bounded gallery image wait

- Added a 4-second bound to the product gallery/lightbox image transition wait so a stalled request cannot block gallery navigation indefinitely.
- Removed waiting on `HTMLImageElement.decode()` before revealing a loaded image; this promise is no longer allowed to hold the transition open.
- A timeout does not overwrite a still-pending image URL, preserving the possibility of a late response and the Core image-recovery path.
- Fallback is used for a completed broken image, not merely a slow request.
- Scope limited to `single-evazar_product.php` and the theme version header; no gallery markup, CSS, swipe behavior, archive filters, importer, or product data changed.


---

<!-- consolidated from CHANGELOG-1.12.85.md -->

# EVazar Theme 1.12.85 — preserve visible image during slow gallery transitions

## Audit finding and fix
A second-pass audit found that 1.12.84 could time out and crossfade to a buffer layer before that image had loaded, temporarily hiding the previous valid image behind a blank layer.

The crossfade now keeps the current visible image in place while the selected image is pending. It reveals the selected image only after it has real intrinsic dimensions, including when it loads after a timeout or after Core recovery. Transition tokens prevent a late response from overriding a newer thumbnail selection, and late-load listeners are removed when superseded to avoid accumulating handlers.

## Scope
Only `single-evazar_product.php`, the `style.css` version header, and this changelog changed from 1.12.84. No gallery markup, CSS rules, touch gestures, archive filters, product data, or importer behavior changed.

## Validation
PHP syntax, extracted inline JavaScript syntax, ZIP integrity, and package root were checked. Static checks do not replace a live browser test on evazar.ir.


---

<!-- consolidated from CHANGELOG-1.12.86.md -->

# EVazar Theme 1.12.86 — Image recovery coordination

- Coordinates gallery and lightbox error handling with Core 2.9.9. Gallery fallback handlers no longer replace a CDN/direct request while Core is retrying it, preserving the URL and scroll-triggered recovery state.
- Desktop crossfade now keeps listening for successful late loads on Core-managed images even when an initial failed request is already `complete` with `naturalWidth === 0`; it only reveals a buffer when that buffer actually has image dimensions.
- Initial lightbox fallback no longer overwrites a Core-managed failed URL.
- Removed the gallery-thumbnail inline `onerror` that hid each thumbnail after the first failed request, before Core could complete its retry sequence.
- No gallery markup/layout, gestures, zoom behavior, archive filtering, infinite scroll, or product data logic was changed.


---

<!-- consolidated from CHANGELOG-1.12.88.md -->

# EVazar Theme 1.12.88

- Homepage product rails now advance by up to six product cards per navigation click, using rendered card widths and actual CSS gaps.
- Previous/next buttons use the same six-card page step in reverse/forward directions.
- Scope is limited to homepage deal, shelf/latest-product, and category-tab product rails. No product gallery or image-loading code changed.
- Browser validation on the live site is still required.


---

<!-- consolidated from CHANGELOG-1.12.89.md -->

# EVazar Theme 1.12.89 — Special Offers mobile card alignment

- Fixes mobile horizontal scrolling for the homepage Special Offers (`deals-showcase-box`) carousel by snapping the actual lead/product cards to the inline start.
- Root cause identified in the existing mobile CSS: `.deals-slider-wrapper` and `.deals-slider-rail` use `display: contents`, which means the showcase box—not the rail—is the actual horizontal scroll container. The prior navigation logic was measuring the rail, so it could not correct the mobile touch-scroll clipping.
- Scope is limited to the Special Offers section at viewport widths up to 768px. Other carousels, product gallery, and desktop layout are not changed by this patch.
- Static checks performed; live mobile browser verification is still required.


---

<!-- consolidated from CHANGELOG-1.12.9.md -->

# Changelog 1.12.9

## Performance — Responsive Product Images
- Product-card images now use responsive CDN `srcset` variants (180/240/360/480px).
- Existing `x-oss-process` dimensions are resized to the requested card size instead of keeping an oversized source transform.
- Archive and homepage product images include explicit width/height attributes and accurate `sizes` hints.
- Only the first rendered product image on the page is `eager` with `fetchpriority="high"`; other product-card images remain lazy.

## Performance — Homepage Queries
- Non-paginated homepage `WP_Query` instances now use `no_found_rows=true` to avoid unnecessary pagination-count SQL work.

## Performance — WordPress Frontend
- WordPress emoji detection assets are disabled on the frontend because the theme targets modern browsers.


---

<!-- consolidated from CHANGELOG-1.12.90.md -->

# EVazar Theme 1.12.90 — Special Offers card alignment on desktop and mobile

- Extends card-alignment snapping for the homepage Special Offers carousel to desktop as well as mobile.
- Desktop snap is applied to the scrolling `.deals-slider-rail`; mobile snap is applied to `.deals-showcase-box`, which becomes the actual scroll container when the rail/wrapper use `display: contents`.
- The final card uses end alignment to reduce the chance of a clipped final card at the scroll boundary.
- No product-gallery code or unrelated carousel styles were changed.
- Static source/package checks performed; live desktop/mobile browser verification remains necessary.


---

<!-- consolidated from CHANGELOG-1.12.91.md -->

# EVazar Theme 1.12.91 — Desktop Special Offers navigation

- Inspected the 1.12.90 carousel CSS and JavaScript. The desktop Special Offers rail used mandatory CSS scroll snapping while the navigation buttons also paged by six cards; those behaviors can compete over the final resting position.
- Disabled scroll snapping only on `.home-deals-section .deals-slider-rail` at desktop widths (769px and above), leaving the six-card navigation calculation unchanged.
- Preserved the mobile scroll-snap rules and did not modify product gallery code or other homepage carousels.
- Static package and syntax checks are required; live-site/browser verification has not been performed.


---

<!-- consolidated from CHANGELOG-1.12.92.md -->

# EVazar Theme 1.12.92

- Desktop-only fix for Special Offers carousel: reserve inline space inside the rail so absolutely positioned navigation arrows do not cover the first/last product cards.
- Preserves the mobile rules, other homepage rails, and product gallery code.
- Static source and archive validation only; live browser behavior still requires testing.


---

<!-- consolidated from CHANGELOG-1.12.94.md -->

# EVazar Theme 1.12.94

- Reverted the desktop-only responsive width overrides added in 1.12.93 for the Special Offers product cards.
- Special Offers product cards now retain the shared fixed 205px width used by the other homepage product rails.
- No JavaScript, mobile styles, product gallery, or other carousel rules changed in this correction.


---

<!-- consolidated from CHANGELOG-1.12.97.md -->

# EVazar Theme 1.12.97

- Restored the established six-card navigation distance for homepage category shelves and category-tab carousels.
- Kept card-edge alignment scoped to the Special Offers rail only.
- Preserved the 205px product-card width and 12px gap.


---

<!-- consolidated from CHANGELOG-1.12.99.md -->

# EVazar Theme 1.12.99

- Special Offers desktop RTL navigation now aligns to the true rail endpoint when a full six-card page would pass the available items.
- This avoids leaving a thin portion of the final product clipped at the end of a navigation step.
- Other homepage carousels and mobile behavior are unchanged.


---

<!-- consolidated from CHANGELOG-1.13.02.md -->

# EVazar Theme 1.13.02

- Fixed the desktop Special Offers viewport: navigation gutters now live on the wrapper instead of scrolling with the cards.
- Desktop rail width fits a whole number of 205px cards and 12px gaps, preventing fractional product cards at the visible edge.
- Navigation advances by the number of fully visible cards (up to six), avoiding skipped products when the viewport can fit fewer than six.
- The Next arrow is positioned beside the actual rail edge when the rail is fitted narrower than its wrapper.
- Changes are scoped to the desktop Special Offers carousel; mobile behavior and other homepage carousels retain their existing path.


---

<!-- consolidated from CHANGELOG-1.13.04.md -->

# EVazar Theme 1.13.04

- Rebased on 1.13.02 to restore the original vertically centered navigation button placement.
- Reduced desktop-only Special Offers wrapper gutters from 42px to 24px per side so a 1360px carousel wrapper can fit six 205px product cards with 12px gaps.
- Removed the 1.13.03 top navigation strip and its JavaScript button positioning/rail behavior by reverting to the 1.13.02 layout logic.
- Adjusted the two desktop arrow offsets to keep the controls in their original centered positions outside the product cards.
- Other homepage carousels and mobile layout are unchanged.


---

<!-- consolidated from CHANGELOG-1.13.05.md -->

# EVazar Theme 1.13.05

- Fixed the Special Offers carousel shrinking from six cards to five after the load-time viewport measurement.
- Expanded the red Special Offers showcase by 78px symmetrically on wide desktop viewports so six 205px cards, five 12px gaps, 2px rail paddings on both sides, and the existing arrow gutters fit together.
- Capped the desktop viewport fitting calculation at six cards. Other carousels and mobile layout are unchanged.


---

<!-- consolidated from CHANGELOG-1.13.06.md -->

# EVazar Theme 1.13.06 — Product Schema Fallback Alignment

- Suppresses standalone Product JSON-LD when the Core Rank Math integration is active, avoiding duplicate Product nodes.
- Keeps theme JSON-LD as a fallback when the Rank Math/Core integration is unavailable.
- Aligns fallback Offer data with `IRR`, the Toman-to-Rial conversion, seller metadata, affiliate destination URL and availability metadata.
- Removes a synthetic `priceValidUntil` date and external-site AggregateRating from Product structured data.
- Clarifies schema mode labels; visible user-facing product ratings remain unchanged.
- Does not modify image loading, product import, product gallery, archive filters, carousel JavaScript or CSS layout.

## Validation

- PHP syntax and ZIP integrity checks passed.
- No live deployment or Rich Results Test against the production URL was performed during package creation.


---

<!-- consolidated from CHANGELOG-1.13.07.md -->

# EVazar Theme 1.13.07 — Special Offers Width and Spacing

- Removed the 78px desktop-only width expansion that made the red Special Offers block wider than the other homepage elements.
- Reduced desktop Special Offers card gap from 12px to 4px.
- Reduced only desktop special-offer product-card width from 205px to 198px, allowing six complete cards to fit in the existing container while keeping the original arrow gutters.
- Preserved the 24px desktop wrapper gutters and 38px vertically centered arrows to avoid covering product cards.
- Changes apply only at widths of 769px and above; mobile card width, mobile scrolling, image loading, product gallery, other carousels, importer, and structured-data code are untouched.

## Layout arithmetic

Six cards: 6 × 198px + 5 × 4px gap + 4px total rail padding = 1212px.
Available rail width in the 1520px max-width shared container: 1216px.
The viewport-fit script therefore computes six whole cards without widening the red showcase.

## Validation

- CSS override is desktop-only and scoped to `.home-deals-section` descendants via the `.deals-*` selectors.
- Mobile rules for widths up to 768px are unchanged.
- JavaScript/navigation code and image-related files are unchanged.
- Package ZIP integrity and source-diff checks performed.
- Not live-tested on production; verify desktop widths after install and clear theme/page cache.


---

<!-- consolidated from CHANGELOG-1.13.08.md -->

# EVazar Theme 1.13.08 — Special Offers Navigation Overlay and Balanced Spacing

## Changes
- Removed the 24px left/right gutters previously reserved for navigation buttons in the desktop Special Offers carousel.
- Navigation buttons now overlay the first and last product cards, aligned to the rail's 8px inner padding and remaining vertically centered.
- Restored a balanced 12px gap between desktop product cards; reduced the desktop card width to 190px and set rail side padding to 8px.
- Six-card width budget: 6 × 198px + 5 × 12px + 2 × 8px = 1264px. The parent showcase width is not expanded.
- Kept mobile layout behavior and all other homepage carousels unchanged.
- Updated the desktop layout routine to compute both arrow positions from the actual rail bounds. Inline desktop positioning is cleared when switching to mobile.

## Validation
- Theme ZIP archive integrity and root folder verified (`evazar-theme/`).
- JavaScript syntax validated with `node --check`.
- Confirmed the patch touches only Special Offers CSS, the Special Offers navigation/layout JavaScript, the theme version header, and this changelog relative to 1.13.07.
- Static arithmetic verifies six 190px cards, five 12px gaps and two 8px insets occupy 1216px.

## Scope
No image loading, lazy loading, CDN, product gallery, importer, archive filter, product data, Core plugin or Worker code changed. These are source/package checks; a live browser test on the production site is still required to verify actual viewport behavior.


---

<!-- consolidated from CHANGELOG-1.13.09.md -->

# EVazar Theme 1.13.09 — Deals “View All” Arrow Direction

## Change
- Corrected only the arrow on the homepage Special Offers lead-card link “مشاهده همه تخفیف‌ها” to point left, consistent with the RTL “view all” links elsewhere on the homepage.
- Added a dedicated class to the SVG and marked it decorative; no navigation behavior or URL changed.

## Scope
- Changed `front-page.php`, `style.css` version metadata, and this changelog only.
- No carousel navigation arrows, product cards, image loading/lazy loading, product gallery, archive filters, importer, or other homepage sections were modified.

## Validation
- ZIP CRC/integrity verified.
- PHP syntax checked for the modified file and all theme PHP files where PHP CLI is available.
- Verified the Special Offers view-all link retains its original `href` and only its arrow polyline changes direction.


---

<!-- consolidated from CHANGELOG-1.13.10.md -->

# EVazar Theme 1.13.10

- Product gallery URL normalization now respects the Core image-routing setting.
- Direct mode keeps gallery, thumbnails, and lightbox images on the Digikala image host; Worker mode continues to use the configured image CDN.
- No product data, SEO markup, or carousel layout changes.
- Direct mode no longer adds a preconnect hint for img.evazar.ir; clarified the legacy CDN-domain field as Worker-mode-only.


---

<!-- consolidated from CHANGELOG-1.9.6.md -->

# EVazar Theme 1.9.6
- Archive filters and sorting use EVazar Product Index when available.
- Price and stock filtering no longer depend primarily on wp_postmeta scans.
- SKU/DKP search uses the indexed product table when available.
- Legacy fallbacks remain until index backfill is complete.


---

<!-- consolidated from CHANGELOG-1.9.7.md -->

# EVazar Theme 1.9.7
- Fixes product blackout immediately after Product Index deployment.
- Product archive/sort/filter now uses LEFT JOIN with legacy postmeta fallback for products not yet indexed.
- SKU/DKP search falls back to postmeta when an index row does not yet exist.


---

<!-- consolidated from CHANGELOG-1.9.8.md -->

# EVazar Theme 1.9.8

- Fix sort-link URLs generated during AJAX rendering so they stay on the real archive URL instead of `/wp-admin/admin-ajax.php`.
- Preserve existing brand/category/stock/price/search parameters when changing sort.
- Add a defensive JS canonicalization for legacy sort links that still point to `admin-ajax.php`.
- Keep out-of-stock products at the end of every supported sort order.
- Bump the theme version and asset cache-buster to 1.9.8.


---

<!-- consolidated from CHANGELOG-1.9.9.md -->

# EVazar Theme 1.9.9

- Separated smart price bounds from the user-selected price filter state.
- The price range remains visually inactive until the user actually selects a minimum or maximum price.
- Empty price inputs are no longer submitted through archive-filter AJAX requests.
- Archive base URL is normalized so filter/sort AJAX never treats `admin-ajax.php` or query parameters as the archive base.
- Filter count no longer double-counts the stock switch.
