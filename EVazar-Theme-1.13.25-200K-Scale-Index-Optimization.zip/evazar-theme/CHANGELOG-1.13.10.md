# EVazar Theme 1.13.10

- Product gallery URL normalization now respects the Core image-routing setting.
- Direct mode keeps gallery, thumbnails, and lightbox images on the Digikala image host; Worker mode continues to use the configured image CDN.
- No product data, SEO markup, or carousel layout changes.
- Direct mode no longer adds a preconnect hint for img.evazar.ir; clarified the legacy CDN-domain field as Worker-mode-only.
