# EVazar Theme 1.12.89 — Special Offers mobile card alignment

- Fixes mobile horizontal scrolling for the homepage Special Offers (`deals-showcase-box`) carousel by snapping the actual lead/product cards to the inline start.
- Root cause identified in the existing mobile CSS: `.deals-slider-wrapper` and `.deals-slider-rail` use `display: contents`, which means the showcase box—not the rail—is the actual horizontal scroll container. The prior navigation logic was measuring the rail, so it could not correct the mobile touch-scroll clipping.
- Scope is limited to the Special Offers section at viewport widths up to 768px. Other carousels, product gallery, and desktop layout are not changed by this patch.
- Static checks performed; live mobile browser verification is still required.
