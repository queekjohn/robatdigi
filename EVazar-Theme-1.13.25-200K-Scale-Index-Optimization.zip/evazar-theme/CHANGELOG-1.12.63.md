# Version 1.12.63

- Removed decorative icons from the price-drop banner on product pages.
- Preserved the price-drop text and amount, product gallery, and lightbox behavior.
