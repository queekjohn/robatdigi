EVazar Theme 1.12.67

- Changed the archive price-filter heading to “بازه قیمت (تومان)”.
- Removed the separate “تومان” label beneath the price filter controls.
- No gallery, lightbox, product page, infinite-scroll, or filter behavior changes.
