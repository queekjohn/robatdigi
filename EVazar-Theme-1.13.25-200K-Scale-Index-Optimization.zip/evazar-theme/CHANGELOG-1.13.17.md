# EVazar Theme 1.13.17 — Related products infinite scroll

- Product pages keep the existing initial related-product rendering and load later batches automatically as the reader approaches the end of the grid.
- Uses EVazar Core's canonical related-product ranking and 12-item AJAX batches; no WooCommerce dependency.
- Shares one escaped product-card renderer for initial HTML and AJAX results, marks cards by product ID to avoid duplicates, shows a bounded retry action on request failures, and stops when no more related products exist.
- AJAX is loaded only on product pages when the related-products setting is enabled; archive infinite scroll and filters are untouched.
- Companion Core 2.9.37 adds backward-compatible offset paging. No Worker change required.
