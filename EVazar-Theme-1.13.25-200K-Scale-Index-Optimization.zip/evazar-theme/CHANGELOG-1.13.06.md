# EVazar Theme 1.13.06 — Product Schema Fallback Alignment

- Suppresses standalone Product JSON-LD when the Core Rank Math integration is active, avoiding duplicate Product nodes.
- Keeps theme JSON-LD as a fallback when the Rank Math/Core integration is unavailable.
- Aligns fallback Offer data with `IRR`, the Toman-to-Rial conversion, seller metadata, affiliate destination URL and availability metadata.
- Removes a synthetic `priceValidUntil` date and external-site AggregateRating from Product structured data.
- Clarifies schema mode labels; visible user-facing product ratings remain unchanged.
- Does not modify image loading, product import, product gallery, archive filters, carousel JavaScript or CSS layout.

## Validation

- PHP syntax and ZIP integrity checks passed.
- No live deployment or Rich Results Test against the production URL was performed during package creation.
