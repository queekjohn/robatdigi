# EVazar Theme 1.12.99

- Special Offers desktop RTL navigation now aligns to the true rail endpoint when a full six-card page would pass the available items.
- This avoids leaving a thin portion of the final product clipped at the end of a navigation step.
- Other homepage carousels and mobile behavior are unchanged.
