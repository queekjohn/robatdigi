# EVazar Theme 1.13.20 — Category icon style alignment

- Replaced the custom washing-machine icon for the exact category `لوازم خانگی برقی` with a simple filled Material-style washing-machine glyph.
- Removed the extra lightning and layered panel details because the other category icons use single, bold filled silhouettes.
- Kept the shared 24×24 SVG viewBox, 20×20 default size, `dk-cat-icon-svg` class, and `currentColor` behavior. Existing theme CSS continues to control homepage and sidebar colors and hover behavior.
- Preserved the related-products infinite-scroll implementation from 1.13.17 without changes.
- No database, EVazar Core, Worker, price, import, archive filter, or global CSS changes.
