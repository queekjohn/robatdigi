# EVazar Theme 1.12.41

- Added compatibility with Core page-wide image Direct Mode recovery.
- Product gallery image URLs now normalize back to the configured EVazar CDN when Core's 10-minute health probe confirms recovery.
- Existing double-buffered gallery/lightbox crossfade remains unchanged.
