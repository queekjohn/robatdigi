# EVazar Theme 1.12.74

- Fixed the fallback CDN URL helper so size parameters modify only the `image/resize` stage and preserve subsequent OSS operations.
- Core helper remains canonical when Core is active.
- Paired with Core 2.9.1 CDN failover changes; image fallback now handles placeholder `src` and lazy `srcset` scenarios without losing source candidates.
