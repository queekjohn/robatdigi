# EVazar Theme 1.12.86 — Image recovery coordination

- Coordinates gallery and lightbox error handling with Core 2.9.9. Gallery fallback handlers no longer replace a CDN/direct request while Core is retrying it, preserving the URL and scroll-triggered recovery state.
- Desktop crossfade now keeps listening for successful late loads on Core-managed images even when an initial failed request is already `complete` with `naturalWidth === 0`; it only reveals a buffer when that buffer actually has image dimensions.
- Initial lightbox fallback no longer overwrites a Core-managed failed URL.
- Removed the gallery-thumbnail inline `onerror` that hid each thumbnail after the first failed request, before Core could complete its retry sequence.
- No gallery markup/layout, gestures, zoom behavior, archive filtering, infinite scroll, or product data logic was changed.
