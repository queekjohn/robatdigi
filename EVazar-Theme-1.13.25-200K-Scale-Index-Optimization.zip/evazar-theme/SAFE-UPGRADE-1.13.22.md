# Safe upgrade — EVazar Theme 1.13.22

1. Back up the active `evazar-theme` directory.
2. Replace the existing theme folder with the `evazar-theme/` folder in this ZIP; keep the directory name exactly `evazar-theme`.
3. This release changes only the theme: version, a product-price presentation helper, homepage carousel markup, status-label CSS, and release notes.
4. No Core or Worker update is required. No database migration or product metadata change occurs.
5. After deployment, inspect the homepage deals rail, newest-products shelf, and category shelves. Explicit unavailable items should say «ناموجود»; zero/missing price without a definitive unavailable signal should say «قیمت نامشخص»; valid positive prices should still display with تومان.
6. Purge LiteSpeed page cache after deployment, then reload the homepage.
