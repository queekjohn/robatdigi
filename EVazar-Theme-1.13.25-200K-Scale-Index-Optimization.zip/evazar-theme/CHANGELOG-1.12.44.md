# EVazar Theme 1.12.44

- Replaced only the standalone `/product-category/` directory UI with an isolated searchable accordion/tree.
- Preserved the existing header category mega menu and other archive/product/image logic.
- Added responsive behavior for desktop/mobile without image assets.
- Bumped theme asset version for cache busting.
