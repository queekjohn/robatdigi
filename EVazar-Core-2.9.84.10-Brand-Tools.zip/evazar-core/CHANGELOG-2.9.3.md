# EVazar Core 2.9.3 — Core/Worker Image Recovery Contract Fix

- The direct-origin retry now routes through the configured image Worker using `img=<direct URL>&evazar_direct_retry=1`.
- The Worker recognizes both `evazar_retry=1` and `evazar_direct_retry=1` as cache-bypass controls and strips retry controls from the upstream Digikala URL.
- Avoids repeating the same direct-origin browser request and finalizes the bounded final retry reliably.
- The bundled Worker is version 1.11.7 and is byte-for-byte identical to the standalone Worker release.
- Product-cache namespace remains at v1.11.5 deliberately because this is an image-only Worker update.

Validation includes PHP/JS syntax, ZIP integrity, exact bundled/standalone Worker parity, image retry contract checks, and mocked routing behavior. Live Cloudflare/site behavior still requires production smoke testing.
