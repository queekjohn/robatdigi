# Local QA — Core 2.9.83

- PHP syntax check: `taxonomy-seo-queue.php`, `evazar-core.php`.
- Source URL absent returns `state=skip`, `status=skipped_no_source_url`; queue processing maps `skip` to terminal `done`.
- Empty/unusable source text returns `state=skip`, `status=skipped_no_source`; queue processing maps `skip` to terminal `done`.
- Gemini/provider errors continue using `state=retry` and are not migrated by the source-less cleanup.
- One-time migration is constrained to `status=retry` and known deterministic source-missing error strings; other retry rows are untouched.
- Existing taxonomy description is preserved when source content is absent.
- Worker and theme unchanged. Live WordPress database and Gemini calls were not exercised.
