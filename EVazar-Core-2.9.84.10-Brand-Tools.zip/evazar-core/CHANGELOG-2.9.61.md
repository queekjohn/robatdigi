# EVazar Core 2.9.61 — Per-account Cloudflare Analytics Tokens

- Adds per-account read-only Cloudflare Analytics API tokens, keyed by Account ID.
- Keeps the legacy single-token option as a fallback for accounts without a specific token.
- Token input is write-only in the admin UI; saved tokens are never rendered back into the page. Blank input preserves mappings; `ACCOUNT_ID|DELETE` removes one mapping.
- Analytics errors remain isolated per account. Worker routing, request budgets, Gemini, images, products, and database behavior are unchanged.
