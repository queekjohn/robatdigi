# EVazar Core 2.8.84

- Bundled Cloudflare Worker version synchronized to `1.11.3`; product cache namespace follows the same version.
- Adds a dedicated HTTPS-only Gemini Worker list without repurposing the primary Worker URL used by product import, price/availability and image routes.
- Enforces conservative quota handling: structured Google `QuotaFailure` metadata and explicit daily/per-day signals identify daily quota; RPM/TPM quota IDs are not misclassified. Daily quota stops all Gemini routing until the official Pacific reset. Generic 429 honors `Retry-After` / Google `retryDelay` without shortening a provider-specified wait.
- HTTP 400/401/403/404 configuration/permission errors do not fail over to another Worker. Network and non-503 Worker failures may fail over after bounded retries. An upstream 503 pauses globally and honors `Retry-After` / `retryDelay`; a clear missing-secret 503 is treated as a configuration error.
- Manual testing no longer bypasses provider quota/rate-limit cooldowns.
- Adds a global Core request lock to prevent concurrent Gemini calls and returns affected queue items to pending without incrementing retry counts.
- Adds a bounded operational log that excludes API keys and prompts, and displays recent Gemini status in settings.
- Worker proxy forwards upstream `Retry-After` without exposing other upstream headers.
