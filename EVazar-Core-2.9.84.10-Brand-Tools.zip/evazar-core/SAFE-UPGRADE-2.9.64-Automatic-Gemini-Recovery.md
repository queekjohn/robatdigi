# Safe upgrade — EVazar Core 2.9.64 / Worker 1.13.8

1. Back up WordPress files and database before replacing the plugin.
2. Install the Core ZIP with the `evazar-core/` plugin folder intact.
3. Deploy `digikala-worker.js` from Worker 1.13.8 to each Gemini Worker that should use explicit upstream 5xx recovery. Keep all existing Worker Secrets and bindings unchanged; do not paste tokens into code.
4. Existing `EVAZAR_INTERNAL_TOKEN`, `GEMINI_API_KEY`, and the existing `EVAZAR_GEMINI_IDEMPOTENCY` Durable Object binding/migration are unchanged. No new binding is required.
5. After upgrading, open the queue page once, then monitor a small batch. Verify that an unknown transport result returns to pending after the safety interval and that a confirmed upstream 5xx sets a temporary Worker cooldown.
6. If an older Worker deployment is not updated, Core retains its conservative fallback: only a saved Durable Object result can distinguish a definitive upstream 5xx from an ambiguous HTTP/edge response.

This release does not modify existing products, queue contents, API tokens, model settings, or Worker URLs. Do not delete the previous plugin/Worker package until the first production batch has been verified.
