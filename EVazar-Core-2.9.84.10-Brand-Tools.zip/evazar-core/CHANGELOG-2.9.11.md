# EVazar Core 2.9.11 — Image-origin final fallback

- Fixed direct-origin fallback for Worker URLs using `?img=<encoded source>`; the source URL is now safely unwrapped and validated against `dkstatics-public.digikala.com`.
- If the bounded forced Worker retry still returns a non-image/error response, the same image gets one final direct-origin browser request.
- If that fails, recovery remains bounded; later scroll/connectivity recovery can retry through the Worker, with the existing cooldown and retry budget.
- No page-wide image mode, product metadata, archive filtering, importer, or gallery layout changes. Theme 1.12.86 and Worker 1.11.8 remain compatible.
