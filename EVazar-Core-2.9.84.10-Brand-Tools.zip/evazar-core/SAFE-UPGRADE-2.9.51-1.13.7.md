# Safe upgrade — EVazar Core 2.9.51 / Worker 1.13.7

1. Back up the WordPress database and the current `evazar-core` plugin directory.
2. Install `EVazar-Core-2.9.51-Gemini-Report-Local-Time.zip` as a new versioned Core release. Its plugin header must report `2.9.51` after activation.
3. Do not change Cloudflare Secrets. Worker 1.13.7 source is unchanged and does not need redeployment for this timezone-display fix.
4. Set the desired timezone under WordPress Settings → General → Timezone. The Gemini report follows this setting; if it is UTC, the report will be UTC.
5. Open the Gemini report and compare one new event's displayed time with the configured WordPress local time. `until` cooldown timestamps should use the same site timezone. Pacific quota-reset labels are intentionally Pacific-specific.
6. The stored timestamps are not rewritten. Roll back the Core plugin to your backup if the report format or admin page behaves unexpectedly.

Local checks passed as described in the QA report; production verification is still required.
