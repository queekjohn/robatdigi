# EVazar Core 2.9.50 — maintenance rebuild (same release label)

- Preserve queue retry generation across signed internal parallel sub-requests so an invalid completed batch gets a new idempotency request ID on the next attempt.
- In sequential Worker-aware mode, an `AI_BATCH_OUTPUT_INVALID` failure now defers/retries only the affected chunk and continues with later chunks, rather than postponing all unattempted chunks after the first malformed response.
- Parallel child failures preserve the specific `AI_BATCH_OUTPUT_INVALID` queue code instead of masking it as a generic batch failure.
- In sequential mode, a Worker-specific quota/rate/temporary-unavailable/busy response no longer stops later batches if other Workers remain eligible; only the current chunk is deferred. When no eligible Worker remains, the queue still pauses safely.
- Show the bounded, sanitized parser validation reason directly in the `batch_output_invalid` event message.
- Automatically distribute Gemini-only product batches across eligible Workers when at least two Worker URLs are configured; use cURL-multi if available, otherwise rotate sequentially across eligible Workers.
- Keep automatic single-product Gemini requests blocked. Explicit manual single-product tests remain supported.
- Core label remains 2.9.50 and Worker label 1.13.7 as requested; Worker source is unchanged.

Local tests only. This rebuild has not been exercised against the live site or production Gemini.

- Extend PHP runtime before the batch-collection loop; if the host still enforces a short execution limit, conservatively cap the run to one complete AI batch and expose the effective PHP limit in `batch_dispatch_plan`.
- Make `batch_dispatch_plan` report `parallel`, `serial-balanced-fallback`, or `single-worker-batch` based on the actual chosen path rather than transport availability alone.
- Gemini operational event timestamps, cooldown-until values, and nearby operational-log timestamps now render using the WordPress site's configured timezone via `wp_date()`/`wp_timezone()` instead of `date_i18n()`'s legacy offset behavior. Stored Unix timestamps and Pacific-specific daily-quota reset labels are unchanged.
