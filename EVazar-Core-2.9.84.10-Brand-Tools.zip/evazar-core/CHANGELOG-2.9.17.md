# EVazar Core 2.9.17 — Grouped Product Specifications

- Stores source specification section titles and rows in the additive `_evazar_spec_groups` JSON metadata.
- Continues writing `_evazar_key_features` for compatibility with the existing editor and legacy readers.
- Includes the same Worker 1.12.0 source in `worker/digikala-worker.js` and consumes `product.spec_groups`; falls back to flat `product.specs` for older Workers and malformed grouped payloads.
- Passes group headings into the AI context and preserves source grouping for the theme.
- Uses the precise canonical label `ظرفیت حافظه داخلی` rather than shortening it to `حافظه داخلی`.
- Retains existing group metadata if a re-import provides no usable specifications.
