# EVazar Core 2.9.83 — Taxonomy Source Terminal Skip

- Deterministic missing-source cases (`skipped_no_source_url`, `skipped_no_source`) now finish as terminal skips rather than entering retry. No Gemini request is made for these terms.
- Added a one-time migration that moves existing retry rows with known source-missing errors to `done` and records a terminal term-meta status.
- Temporary Gemini/provider failures and unrelated retry states remain retryable. Existing valid/manual taxonomy descriptions remain untouched.
- Worker and theme do not require changes.
