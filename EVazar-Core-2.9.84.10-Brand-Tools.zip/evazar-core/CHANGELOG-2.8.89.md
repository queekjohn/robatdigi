# EVazar Core 2.8.89 — Multi-Worker quota audit

- Aligns Gemini compliance documentation with the 2.8.88 per-Worker daily-quota failover implementation.
- Clarifies failover is only for independently authorized Google projects/quotas; multiple keys sharing the same project quota are not independent capacity.
- Worker source remains byte-for-byte compatible with the existing 1.11.3 proxy; it forwards upstream status/body and Retry-After, while Core makes the failover decision.
- No product import, queue, image, theme, or unrelated Worker behavior changed in this audit release.
