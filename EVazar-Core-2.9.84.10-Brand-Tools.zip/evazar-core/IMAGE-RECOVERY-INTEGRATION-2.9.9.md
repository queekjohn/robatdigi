# Core + Theme image-recovery integration

Recommended compatible pair: Core 2.9.9 + Theme 1.12.86 + existing Worker 1.11.8.

Core exposes `__evazarCoreManaged` and owns bounded per-image retries; theme error handlers defer to that ownership rather than swapping network `src` to a data placeholder. The theme still uses its local placeholder for images not managed by Core. On failed managed images, the network URL remains attached so Core can recover it after scroll/connectivity events.
