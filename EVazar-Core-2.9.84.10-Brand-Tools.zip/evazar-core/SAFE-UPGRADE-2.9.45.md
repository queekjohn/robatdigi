# Safe upgrade — Core 2.9.45

1. Back up the current plugin directory and database.
2. Deploy Worker 1.13.5 first, including the Durable Object class and migration.
3. Configure the binding named `EVAZAR_GEMINI_IDEMPOTENCY` pointing to class `GeminiIdempotencyDO`.
4. Keep the existing `EVAZAR_INTERNAL_TOKEN` and `GEMINI_API_KEY` secrets. Do not expose either secret.
5. Deploy Core 2.9.45 after the Worker status endpoint responds with `status: not_found` for a random test request ID.
6. Test with one small batch and verify `idempotency_recovered` appears when simulating a lost response.

Important: Cloudflare Durable Objects require a class migration. Do not merely paste the JS into a Worker that lacks the namespace binding. The Worker remains backward-compatible when the binding is absent, but automatic ambiguous-outcome recovery will not work.
