# Safe upgrade — EVazar Core 2.9.52 / Worker 1.13.7

1. Back up the WordPress database and the existing `evazar-core` plugin directory.
2. Install `EVazar-Core-2.9.52-Worker-401-Auth-Diagnostic.zip`. Confirm the plugin header reports `2.9.52`.
3. Do not deploy or modify the Worker for this Core-side diagnostic fix. Keep the existing Gemini API key and internal-token values private.
4. In WordPress EVazar Core settings, compare the value under “توکن داخلی ارتباط با Worker” with the Cloudflare Worker Secret `EVAZAR_INTERNAL_TOKEN` on each configured Worker. They must match exactly; do not paste either value into chat or logs. `GEMINI_API_KEY` is a separate secret.
5. If a Worker returns its exact local `401 Unauthorized` body, Core now logs `worker_auth_failed`, excludes that Worker for five minutes, and returns the assigned batch to the queue. This is a safety cooldown, not a repair of the mismatched secret.
6. Run one small batch and inspect the new Gemini events. If a different 401 body is returned, Core will keep it in the generic authorization/configuration category because it may originate upstream.
7. Local syntax/packaging tests are not a live production test. Roll back the plugin directory backup if the admin page or queue behaves unexpectedly.
