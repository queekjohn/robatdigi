# Safe upgrade — EVazar Core 2.9.41

1. Back up the current `evazar-core/` folder and WordPress database.
2. Replace the existing `evazar-core/` folder with this package; keep its folder name unchanged.
3. Do not publish or replace any Cloudflare Worker. Core's embedded Worker remains byte-identical to Worker 1.13.4.
4. Product batching stays disabled unless `evazar_ai_product_batch_enabled` is explicitly set to `yes`.
5. When testing batching, use Gemini-only mode and start with 5 products. Check output-to-DKP mapping and queue statuses before increasing the batch size.
6. This release changes only temporary quota-probe handling in the batch queue path; no database migration is required.

No live production import or real Gemini API call was performed during package verification.
