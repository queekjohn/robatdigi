# Safe upgrade — EVazar Core 2.9.22

1. Back up the currently installed EVazar Core plugin and database before replacing the plugin.
2. Install `EVazar-Core-2.9.22-Dynamic-Taxonomy-Prompts.zip` through WordPress Plugins → Add New → Upload Plugin.
3. Open the EVazar Core settings once. The one-time migration replaces only the exact legacy category/brand prompt values identified in the supplied backup. Custom prompts that differ from those known legacy values are preserved.
4. Check the category and brand prompt fields. Their structures should be dynamic: no mandatory 2–3 paragraph format and no required H2/H3 pattern.
5. In the single-term taxonomy processor, choose Category and ID `1842` (ماشین لباسشویی دوو). Review the source URL and process only this item.
6. Inspect the result for specific, non-generic headings and content grounded in the source. Do not run the bulk category/brand action during this test.
7. Only after reviewing the category result, test one independent brand using the same single-term processor.

Product prompt and product rewriting code are unchanged. The plugin update does not regenerate or rewrite existing category/brand descriptions on its own. The source text is now appended in a delimited block and treated as data, not instructions.
