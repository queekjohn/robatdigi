# Local QA — Core 2.9.84

- Added aggregate status fields `done_no_source_url`, `done_no_source_text`, and `done_other`; source-specific figures are subsets of `done`.
- Admin queue status text includes final/terminal row counts alongside active states.
- Legacy migration processes up to five batches of 500 rows per request and only sets the completion option once a separate query confirms no matching legacy retry rows remain.
- PHP lint, ZIP integrity, and static assertions are run during packaging.
- Not tested against the live WordPress database, live Digikala endpoints, or Gemini.
