# EVazar Core 2.9.12 — Product Schema Currency and Deduplication

- Corrected Offer currency to ISO 4217 `IRR` and converts stored Toman price to Rials (x10).
- Uses seller metadata and the affiliate destination URL rather than marking EVazar as the seller.
- Applies the theme's schema enable/mode options to the Rank Math JSON-LD integration.
- Removes the synthetic `priceValidUntil` date and third-party AggregateRating markup.
- Omits `validFrom`, return policy and shipping costs unless reliable source data becomes available.
- Theme standalone Product JSON-LD is suppressed when this Core/Rank Math schema integration is active, avoiding duplicate Product nodes.

## Validation

- PHP syntax and ZIP integrity checks passed.
- This package was not deployed to the live site; Rich Results Test and Search Console validation must be run after installation.
