# QA — EVazar Core 2.9.63

Static checks performed:
- PHP syntax lint for all plugin PHP files.
- ZIP integrity and expected plugin folder structure.
- Source checks for Analytics snapshot persistence, UTC day boundary, 15-minute cron hook, per-script plus account-level GraphQL accounting, account-level analytics threshold guard, internal atomic reservation, and OpenAI pool routing.
- Mocked routing test: with account A at 90,995 requests and account B at 372 against an 85,000 cap, Core selected Worker B; a second mocked test selected the lower-usage Worker when both were under the cap.

Not performed: live WordPress/cPanel deployment, Cloudflare API calls using the user's tokens, or production request sampling.

Operational notes:
- Save both Analytics account/URL rows and per-account tokens.
- Visit the admin settings page once after upgrade so WP-Cron can schedule its 15-minute refresh.
- Press “به‌روزرسانی آمار حساب‌ها” once for an immediate baseline.
- If an account reaches the configured threshold, all of its mapped Worker URLs stay excluded for the current UTC day even if a later Analytics read appears lower, preventing a delayed/sampled response from re-enabling it prematurely.
- This affects requests routed by EVazar Core. Browser requests directly to a custom image hostname such as `img.evazar.ir` do not pass through the Core router and are not rerouted by this change.
