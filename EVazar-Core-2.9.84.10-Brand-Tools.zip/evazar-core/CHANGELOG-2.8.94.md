# EVazar Core 2.8.94 — Import History Status Card Layout

- Removes the separate prominent history button from the top of the import queue page.
- Adds “محصولات وارد شده ۲۴ ساعت گذشته” as the fifth clickable status card, after the four existing cards.
- Matches the existing card layout, spacing, radius, border, shadow, and count typography; preserves the history filter and query behavior.
- No changes to queue processing, worker routing, importer behavior, or database schema.
