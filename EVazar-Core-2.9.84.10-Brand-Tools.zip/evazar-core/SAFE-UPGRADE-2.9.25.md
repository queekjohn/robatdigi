> Historical note: these instructions describe 2.9.25. Google Search grounding was removed in Core 2.9.27; use `SAFE-UPGRADE-2.9.27.md` for current deployment.

# Safe upgrade — EVazar Core 2.9.25

1. Back up the current Core plugin and database.
2. Upload/replace Core through WordPress. The plugin header version changes to 2.9.25.
3. No Cloudflare Worker redeployment is required: the existing proxy forwards the request JSON to Gemini, including the optional `tools: [{"google_search": {}}]` field. The tool is added by Core only for taxonomy content requests.
4. The separate third-party search key setting and active API integration have been removed. There is no additional search-service account or key to configure.
5. The existing taxonomy web-research toggle now enables/disables Gemini's built-in Google Search for category and brand descriptions. The tool is used only if the selected engine actually sends the request to Gemini and the model decides search is useful.
6. Product prompts and normal product requests do not receive the Google Search tool.
7. Upgrade does not rewrite existing terms and does not run batch processing.
8. Test only taxonomy term ID 1842. Check the saved HTML, the public page, research status and administrator-only source list.
9. Do not run bulk processing until the single-term test is approved.
