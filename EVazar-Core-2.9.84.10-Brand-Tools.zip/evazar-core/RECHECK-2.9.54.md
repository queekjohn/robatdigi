# Recheck — EVazar Core 2.9.54

- Changed only the product-page AJAX inquiry freshness argument and successful-result transient TTL, plus version identifiers and release documents.
- Scheduled background batch remains unchanged in behavior: `evazar_inquire_product_price((int)$post_id, true)`.
- Worker cache path remains unchanged. Normal worker fetches can use `caches.default`; fresh requests skip it.
- No live-site tests or production API calls were made.
