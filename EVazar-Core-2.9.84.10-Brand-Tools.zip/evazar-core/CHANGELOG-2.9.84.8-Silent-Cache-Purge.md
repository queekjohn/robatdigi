# EVazar Core 2.9.84.8 — Silent Cache Purging & Multi-Layer Notice Suppression

## Summary of Changes
1. **Silent Origin Purge (`cache-purge.php`)**:
   - Replaced noisy `do_action('litespeed_purge_url', ...)` with direct native LiteSpeed Web Server purge response headers (`X-LiteSpeed-Purge: url=/...`) and silent internal tag registration (`do_action('litespeed_purge', 'URL.' . ...)`).
   - Prevents LiteSpeed Cache's `Admin_Display::succeed` from generating automated notices for every imported/updated product.

2. **Server-Side Output Buffer Suppression (`cache-purge.php`)**:
   - Added buffer wrappers around `admin_notices` and `all_admin_notices` (priorities `-99999` to `99999`) to dynamically intercept and remove any rendered LiteSpeed URL purge notices (`پاکسازی /url ...` and `Purged /url ...`).
   - Ensures zero admin notice leakage regardless of how or when LiteSpeed or other plugins trigger URL purges.

3. **Database Option & Transient Cleanup (`cache-purge.php`)**:
   - Added filters and automated cleanup hooks on `litespeed.admin_display.messages` and `litespeed_messages` at `admin_init` and `shutdown` to prevent stale notices from accumulating in `wp_options`.

4. **Client-Side Safety Net (`cache-purge.php`)**:
   - Injected scoped CSS and a lightweight DOM `MutationObserver` in `admin_head` to instantaneously dismiss any dynamic or AJAX-injected notices on the queue manager and admin dashboard screens.

5. **Version Bump**:
   - `evazar-core.php`: Bumped to `2.9.84.8`.
