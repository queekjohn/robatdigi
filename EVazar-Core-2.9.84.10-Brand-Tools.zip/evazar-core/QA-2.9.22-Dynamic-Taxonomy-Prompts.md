# QA — 2.9.22 Dynamic Taxonomy Prompts

1. Install the Core ZIP only after taking the usual backup.
2. Visit the admin once to trigger the one-time prompt migration.
3. Confirm category and brand prompt fields no longer contain fixed 2–3 paragraph / fixed H2-H3 instructions.
4. Confirm custom prompts that differ from the known legacy defaults remain untouched.
5. Test one category (term ID 1842, ماشین لباسشویی دوو) using the single-term processor; do not run the full batch.
6. Inspect source method, source character count, generated HTML, and the absence of generic/repeated headings.
7. Test one independent brand only after reviewing the category result.
8. Confirm the product prompt field and product rewriting behavior are unchanged.
9. Confirm existing taxonomy descriptions are not rewritten merely by plugin upgrade.
