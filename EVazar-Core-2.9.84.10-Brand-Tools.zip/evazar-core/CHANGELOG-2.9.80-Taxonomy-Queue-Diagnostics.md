# EVazar Core 2.9.80 — Taxonomy Queue Diagnostics

- Added an administrator-only queue status endpoint and a `بررسی وضعیت صف‌ها` control to the batch processor UI. It reports category/brand pending, due, retry, processing counts and next scheduled hook without exposing prompts, content, tokens, or API keys.
- Added throttled `taxonomy_batch_waiting_minimum` events when the queue runner executes but fewer than two same-type items are due.
- Added throttled `taxonomy_batch_preflight_blocked` events with a compact per-term preflight status summary when fewer than two items survive source/configuration/content validation.
- Added `taxonomy_queue_schedule_failed` diagnostics if WordPress rejects registration of a recurring taxonomy queue hook.
- Kept minimum batch size of 2, 2–5 same-type items per Gemini request, separate category/brand queues, existing product import path, and current retry backoff policy unchanged.

Local syntax/static tests are performed for this package; live WordPress Cron, DB state, Worker deployment, and Gemini calls must still be verified in the target site.
