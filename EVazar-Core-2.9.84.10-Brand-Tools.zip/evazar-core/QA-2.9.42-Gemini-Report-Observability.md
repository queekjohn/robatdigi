# QA — EVazar Core 2.9.42 Gemini report observability

## Changes
- Added report columns for request purpose, product count and member DKPs.
- Added safe DKP-list propagation from batch request context to operational log events. DKPs are digits-only, unique and capped at 10. No titles, prompts or secrets are logged.
- Older log records remain readable and gracefully show an em dash where the newly available DKP list is absent.
- No Worker or database schema change.

## Checks
- PHP syntax check required for every top-level Core PHP file.
- Report label mapping covers product batch, single-product import, batch single-product and fallback request, and taxonomy SEO.
- Unit harness verifies DKP sanitization, de-duplication and cap of 10.
- Packaged Worker source is byte-identical to the source shipped with the 2.9.41 baseline; Worker is not modified by this release.
- ZIP integrity and exact root folder `evazar-core/` checked.

## Limitation
No production deployment or live WordPress database was available. This release improves visibility into requests; it does not change the request flow.
