# Deploy EVazar Cloudflare Worker 1.13.13

1. Open the Worker code for each endpoint configured for Gemini in EVazar Core.
2. Replace its source with `digikala-worker.js` from this package and publish it.
3. Preserve existing `EVAZAR_INTERNAL_TOKEN`, `GEMINI_API_KEY`, and any optional `EVAZAR_GEMINI_IDEMPOTENCY` binding; do not create or delete secrets for this update.
4. Update **every configured Gemini Worker** before installing Core 2.9.81 or newer. The 2.9.82 source-retry timing fix does not require a Worker code change if 1.13.13 is already deployed. Old Workers intentionally reject the new `taxonomy_seo_single` request purpose.
5. Confirm the endpoint returns `X-Evazar-Worker-Version: 1.13.13` after deployment.

Core 2.9.81 sends 2–5 same-type category/brand terms as `taxonomy_seo_batch`. Only after the 30-second coalescing window or when preflight leaves exactly one eligible term does it use `taxonomy_seo_single`. This single-item exception is restricted by count, taxonomy type, and the stable `gm-taxsingle-` request-ID prefix. Product import batch policy is unchanged.
