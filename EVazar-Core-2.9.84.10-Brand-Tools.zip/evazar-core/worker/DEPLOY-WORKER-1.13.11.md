# Deploy EVazar Cloudflare Worker 1.13.11

1. Install EVazar Core 2.9.75 first, then deploy this script to every primary Digikala Worker configured in Core.
2. Replace the Cloudflare Worker script with `digikala-worker.js` from this release.
3. Preserve the existing `EVAZAR_INTERNAL_TOKEN` secret separately in each Worker environment. Never paste it into source code or send it in logs.
4. Do not change Core daily budget settings while validating.
5. Confirm responses include `X-Evazar-Worker-Version: 1.13.11`.

This version distinguishes proxy-generated network errors (`source_fetch_failed`) from actual upstream HTTP 5xx (`source_server_error`), rate limiting (`source_rate_limited`) and genuine double-404 product-not-found (`product_not_found`). Upstream-supplied diagnostic headers are cleared before the proxy sets its own trusted diagnostics.

Deployment has not been performed against the live Cloudflare environment.
