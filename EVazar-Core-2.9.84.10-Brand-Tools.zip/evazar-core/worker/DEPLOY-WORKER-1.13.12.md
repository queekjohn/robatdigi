# Deploy EVazar Cloudflare Worker 1.13.12

1. Upgrade EVazar Core to 2.9.79 first, or deploy Core and all Workers in the same maintenance window.
2. Replace the Worker script with `digikala-worker.js` from this release on **every configured Gemini Worker endpoint** in Core.
3. Preserve each endpoint's existing `EVAZAR_INTERNAL_TOKEN` and `GEMINI_API_KEY` secrets. Keep keys in Cloudflare Worker secrets only.
4. After deployment, confirm the response header `X-Evazar-Worker-Version: 1.13.12` on each endpoint.
5. Core will send a new `taxonomy_seo_batch` request purpose. The Worker enforces a batch size of 2–5 and a single taxonomy type (`category` or `brand`). Product import batch validation remains unchanged.

Do not update only one Worker: the Core may route taxonomy batches to any configured eligible endpoint. Live Cloudflare deployment has not been performed by this release build.
