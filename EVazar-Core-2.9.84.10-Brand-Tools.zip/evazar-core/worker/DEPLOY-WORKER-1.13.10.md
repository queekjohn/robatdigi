# Deploy EVazar Cloudflare Worker 1.13.10

1. First install EVazar Core 2.9.74, then deploy this script to every primary Digikala Worker configured in Core.
2. Replace the Worker script with `digikala-worker.js` from this package.
3. Keep the existing `EVAZAR_INTERNAL_TOKEN` secret configured separately in each Worker environment. Never paste the secret into source code or send it in logs.
4. Do not change Core's daily budget settings while checking this release.
5. After deploying, verify that responses contain `X-Evazar-Worker-Version: 1.13.10`. The Core price/stock log will start displaying diagnostic codes and HTTP status on subsequent automatic runs.

Worker 1.13.10 distinguishes a true product 404 (both Digikala API versions return 404) from upstream throttling, server failures, network failures, and invalid JSON. A source-side failure is returned with `X-Evazar-Error-Scope: source`, allowing Core to keep a responsive Worker eligible for later requests.
