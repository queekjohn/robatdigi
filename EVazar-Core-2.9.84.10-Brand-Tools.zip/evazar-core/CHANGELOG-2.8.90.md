# EVazar Core 2.8.90 — Gemini quota audit logging fix

- Logs local quota-cooldown blocks in the Gemini operational report even when no HTTP request is sent to a Worker.
- Logs when the post-reset quota health probe is already in progress.
- Fixes the request-scoped manual single-product test flag so an explicit manual import can make one real daily-quota check; rate-limit cooldown remains enforced.
- Keeps per-Worker daily-quota failover behavior unchanged and clarifies reset time in the user-facing error.
- No theme, product schema, queue scheduling, image proxy, or unrelated import behavior changed.
