# Safe upgrade — EVazar Core 2.9.19

1. Back up the database and existing `evazar-core` directory.
2. Deploy Worker 1.12.1 first from the companion ZIP. Keep all current Worker secrets, routes, custom domains and environment variables. Confirm `X-Evazar-Worker-Version: 1.12.1`.
3. Replace the existing `evazar-core` plugin directory with this release. Keep the directory name; do not install a second copy.
4. Clear WordPress/page caches after deployment.
5. Run the existing “تولید محتوای سئو برای دسته‌ها و برندهای خالی” action in controlled batches. Each run attempts at most four eligible terms. It may need multiple runs to reach the target categories; recently failing terms are cooled down to prevent repeated requests.
6. First test the exact examples: washing-machine category, washing-machine/Daewoo landing and Daewoo brand. Check `_evazar_ai_content_source_url`, `_evazar_ai_content_source_method`, `_evazar_ai_content_source_chars`, `_evazar_ai_content_status` and `_evazar_ai_content_last_error` on each term if the admin result reports a skip/error.
7. Do not begin bulk processing if any target reports `skipped_no_source`, `skipped_no_source_url`, `error_ai` or `error_save`. Share the recorded status/source method/error first.

This release does not change term names/slugs/hierarchy and does not mass-edit products. Curated/manual descriptions and manual-lock terms are preserved. Existing verified AI-generated descriptions from older engine versions may be refreshed only when their recorded output still matches the stored text; manually changed text is not treated as safe to overwrite. Failed source/AI attempts preserve the current description.
