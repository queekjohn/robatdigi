# EVazar Core 2.9.2 — Independent Image Recovery

- Replaced page-wide image failover with per-image recovery: normal CDN request, one cache-bypass retry, then direct-origin fallback and one bounded direct retry.
- Removed the 10-minute persistent Direct Mode behavior; stale Direct Mode cookies are cleared and no longer influence PHP image URLs.
- Added per-image watchdogs for visible/eager images to recover genuinely stalled requests without redirecting all page images.
- Added support for images inserted by archive/AJAX/infinite-scroll updates.
- Preserved product gallery rendering and did not change product/image data or database schema.
- Worker 1.11.6 additionally strips the retry control parameter before contacting Digikala and never caches failed/non-image responses.

## Validation

- PHP syntax and JavaScript syntax checks are expected to pass before release packaging.
- Mock tests cover CDN error -> forced CDN retry -> direct fallback, direct retry bounds, and failure isolation.
- Production network behavior must still be smoke-tested after deploying the same Worker version to every configured image/product Worker.
