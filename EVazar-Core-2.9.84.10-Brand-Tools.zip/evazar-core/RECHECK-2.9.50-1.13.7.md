# Deep recheck — EVazar Core 2.9.50 / Worker 1.13.7

## Source-level findings and applied fixes
1. **Retry identity:** batch request identity hashes each queue row's `retries` generation. The signed internal parallel payload serializes it and the child handler restores it, so a malformed completed response gets a new request ID after the queue increments retries.
2. **Worker-aware allocation:** Core computes the per-run claim ceiling from the user queue cap, batch size, eligible Worker count, and configured concurrency. It uses cURL-multi waves when the WordPress Requests cURL transport is available; otherwise it assigns chunks in sequential round-robin order.
3. **Sequential invalid-output handling:** previously, one fully invalid HTTP-200 response could defer all remaining claimed chunks and increment retry counters for products never sent. Now only the affected chunk is retried and later chunks are attempted.
4. **Worker-scoped cooldown handling:** a quota/rate/temporary-unavailable/busy response from one assigned Worker no longer stops later chunks when another Worker is eligible. The current chunk is deferred; later chunks continue. If no eligible Worker remains, the unsent tail is deferred safely.
5. **PHP runtime safety:** the queue attempts to extend PHP execution to 300 seconds before collecting product checkpoints. If the effective `max_execution_time` remains under 180 seconds, the run is conservatively capped at one complete AI batch; the effective limit and pre/post-guard capacity appear in `batch_dispatch_plan`. This avoids claiming 20–50 rows in a request likely to time out during sequential product preparation.
6. **Parallel error specificity:** the parent preserves `AI_BATCH_OUTPUT_INVALID` from an internal child instead of masking it as generic `AI_BATCH_FAILED`; queue retries still increment, generating a fresh request ID.
7. **Visible parse diagnostics:** the sanitized parser reason (maximum 220 characters) is included in `batch_output_invalid` message text. Raw model response, prompts and API secrets are not logged.
8. **No automatic single-product Gemini requests:** Core gates product queue requests to 2–10 unique DKPs, defers singleton rows for pairing, and blocks the legacy auto-fallback purposes. Worker independently rejects automatic singleton calls; the explicit manual one-product test and taxonomy SEO remain separate.
9. **No loss during partitioning:** the chunker rebalances tails such as 10+1 to 9+2 where possible; otherwise the lone item is deferred without a Gemini call.

## Local verification
- PHP syntax: all plugin PHP files passed `php -l`.
- JavaScript syntax: standalone Worker passed `node --check`.
- The Worker embedded in Core equals the standalone Worker JS byte-for-byte; Worker ZIP contains the same JS.
- Core ZIP, Worker ZIP and release ZIP pass integrity checks; the release ZIP contains the same Core/Worker artifacts as standalone downloads.
- Exhaustive chunk-partition harness tested input lengths 0–150 and batch sizes 2–10; no loss/duplicate IDs and no invalid chunk sizes were observed.
- Static regression checks verified retry-generation payload round-trip, distinct retry identities, batch-only guards, sequential invalid-output continuation, per-Worker cooldown continuation, specific parallel invalid-output errors, and dispatch diagnostics.
- **Local time display:** event and cooldown timestamps are formatted from unchanged Unix epoch values using the WordPress configured timezone; Pacific quota-reset status remains explicitly Pacific.
- Capacity arithmetic checked: queue cap 50 / batch 10 gives 30 products with 3 eligible Workers, 20 with 2, 10 with 1; queue cap 10 limits one run to 10 even if more Workers are ready. The short-PHP-limit guard is separately source-checked.

## Operational limits
These are source-level/local checks, not production integration tests. The live WordPress database/settings, real cURL-multi transport, deployed Cloudflare Worker versions, actual API quotas, and live Gemini output were not exercised. Worker eligibility is calculated from configured URLs and Core's recorded quota/rate cooldowns/locks; it is not a live health probe. After deployment, use `batch_dispatch_plan`, `batch_dispatch_wave`, or `batch_worker_assigned` to confirm effective capacity and real assignment. A network result marked ambiguous can still risk duplicate provider usage after recovery; the log warns about this case.
