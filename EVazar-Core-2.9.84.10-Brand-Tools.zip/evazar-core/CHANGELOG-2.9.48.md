# EVazar Core 2.9.48 — Queue Auto-Continuation

- Adds a separate one-off WordPress Cron hook that schedules a separate follow-up for the next queue batch about 15 seconds later when eligible `pending` rows remain, or near the earliest retry time when all pending rows are deferred.
- Keeps the configured recurring queue cron as a safety net and limits each PHP request to one batch even if both cron hooks become due together.
- Suppresses rapid follow-up scheduling while Gemini quota/rate/concurrency pause is active and when no pending rows are ready; if deferred pending rows exist, it schedules the next wake-up near their earliest due time.
- Hardens stale-claim recovery with compare-and-set conditions (`id`, `status`, `claim_token`, `claimed_at`, and cutoff) so a claim that changed after inspection is not reset.
- Does not change Worker code or database schema.

Note: WordPress Cron is traffic-triggered unless an external cron invokes it. The 15-second follow-up is a scheduled due time, not a guarantee of execution at exactly 15 seconds.
