# QA — EVazar Core 2.9.41 + Worker 1.13.4

## Core/Worker contract
- Core calls `/ai/gemini/gemini-3.5-flash-lite` using the existing JSON body contract (`system_instruction`, `contents`, `generationConfig`).
- Worker 1.13.4 pins the upstream model to `gemini-3.5-flash-lite`, removes client-supplied credentials/tools and forwards the remaining generation request body. The batched request uses the same contract; no Worker modification is needed.
- Core's embedded `worker/digikala-worker.js` SHA-256 is checked against the standalone Worker 1.13.4 package.

## Checks
- PHP lint: all top-level Core PHP files pass.
- Node syntax: Worker JS passes `node --check`.
- Batch parser tests: valid mapping, missing item, duplicate DKP rejection, unknown DKP rejection pass.
- Mock batch generator: one logical request returns independent outputs keyed by DKP.
- ZIP archive integrity and root folder `evazar-core/` pass.
- Added temporary quota-probe pause classification; transient errors with missing retry metadata defer for 60 seconds without increasing retry count.

## Not tested
No live WordPress database, real Gemini request, real Worker deployment, or production browser session was used.
