# QA — Core 2.9.46 / Worker 1.13.6

Static checks to run before deployment:
- `php -l evazar-core.php`
- `php -l importer.php`
- `php -l queue-manager.php`
- `node --check digikala-worker.js`
- `unzip -t` on both release ZIPs

Recovery logic reviewed:
- HTTP 200 + extracted text: persist as succeeded and replay without another Gemini request.
- HTTP 429: Core marks the attempt failed (not uncertain), applies daily quota or rate cooldown, and defers queue rows without retry increment. Worker stores the 429 and permits a new upstream attempt only after retry delay.
- HTTP 4xx except 429: definitive rejection is surfaced; same request ID continues replaying the saved response, preventing duplicate upstream calls.
- HTTP 5xx or transport ambiguity: fail-closed; no blind retry.
- DO still returns `processing` / `uncertain` when execution state cannot safely be resolved.

Not tested live: Cloudflare Durable Object transactions/migration, WordPress DB conditional updates, Google response formats, and end-to-end queue finalization. Production deployment must follow SAFE-UPGRADE-2.9.46.md.
