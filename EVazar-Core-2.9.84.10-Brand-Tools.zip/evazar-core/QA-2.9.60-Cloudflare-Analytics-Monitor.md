# QA — EVazar Core 2.9.60

- PHP syntax checks pass for all top-level Core PHP files.
- Core ZIP integrity passes.
- Worker source is unchanged from 2.9.58 / 2.9.59.
- Only code change from 2.9.59: plugin version header and exact API-token permission wording.
- Official Cloudflare guidance for GraphQL Analytics API tokens: Account → Account Analytics → Read.
- No live Cloudflare API credentials, WordPress runtime, or production site were available; no live end-to-end test was performed.
- Analytics can lag and is not an exact real-time or billable quota meter. Keep the Core local budget enabled.


Superseded by 2.9.61 for per-account multi-token support.
