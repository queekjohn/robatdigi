# EVazar Core 2.8.80

- Restored page-wide browser image failover: the first real `img.evazar.ir` image failure or active-load timeout switches all current-page product images to `dkstatics-public.digikala.com`.
- Added a 10-minute Direct CDN mode with a real image probe against the normal `img.evazar.ir` path at the end of each window.
- Probe success clears Direct Mode for subsequent pages and notifies the product gallery; probe failure renews Direct Mode for another 10 minutes.
- No browser-side `evazar_retry=1` is used; the failover cycle runs once per mode window to avoid race conditions and duplicate recovery requests.
- Direct-CDN errors are not used to immediately cancel the 10-minute mode; Theme keeps its final per-image Placeholder recovery.
- Zero-host-storage architecture and the Cloudflare Worker remain unchanged.
