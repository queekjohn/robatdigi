# QA — EVazar Core 2.9.21

## Checks performed

- PHP syntax (`php -l`) passed for every PHP file in the plugin package.
- JavaScript syntax checks (`node --check`) passed for both inline scripts after substituting the runtime WordPress nonce expression.
- Target preview handler is read-only and allows only `evazar_category` / `evazar_brand` for users with `manage_options` and a valid nonce.
- Target process handler validates taxonomy + term ID and reads the canonical term name from WordPress.
- Content lock always stops the operation.
- Manual content is not overwritten. The opt-in regenerate flag is honored only when `evazar_term_description_is_recorded_ai_content()` verifies the current description against saved AI-output metadata.
- The new interface shows the resolved source URL and saved source method/character count before processing; after an attempt it shows status, source/output lengths, and last error.
- Worker file was not changed; API source retrieval behavior from Core 2.9.20 remains in place.

## Not yet verified

- This package has not been deployed to the live WordPress site in this environment.
- Live AJAX behavior, WordPress role/nonce flow, and one real AI rewrite must be tested on the site after installation.
- First test should target only term ID 1842 after selecting the correct taxonomy and confirming the displayed term name/source URL. Do not run the bulk action until the one-term result is confirmed.
