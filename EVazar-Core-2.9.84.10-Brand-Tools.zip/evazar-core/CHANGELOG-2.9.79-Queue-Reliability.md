# EVazar Core 2.9.79 — Taxonomy Queue Reliability

- Raises the PHP execution allowance for taxonomy queue callbacks so source-page fallback work is less likely to be interrupted by the hosting default. Stale processing leases still recover automatically.
- Uses a stable request ID for identical taxonomy batch inputs, incorporating type, term ID, original description hash, source hash, and prompt hash. This supports replay protection when the Worker’s optional `EVAZAR_GEMINI_IDEMPOTENCY` Durable Object binding is configured.
- Releases any surviving claim when fewer than two rows remain after batch selection; no Gemini request is sent, and the claim does not consume a retry attempt.
- Core/Worker contract and Theme 1.13.23 integration remain unchanged.

Local syntax, queue, parser, Worker mock-upstream, package integrity, and version-alignment tests passed. Live WordPress/MySQL, Cloudflare deployment, and Gemini calls were not performed.
