# EVazar Core 2.9.42 — Gemini batch observability

- The Gemini operational report now shows request purpose, product count and the DKP members for batch requests.
- Product DKP lists are sanitized (digits only), unique, and capped at 10 entries; prompts, product titles and API credentials are not added to logs.
- Existing operational events retain compatibility. Previously saved events can show purpose and batch size if that metadata was already recorded, but older events will not gain DKP lists retroactively.
- No change to the Gemini prompt, batch generation, queue behavior, Worker source, database schema or product records.
