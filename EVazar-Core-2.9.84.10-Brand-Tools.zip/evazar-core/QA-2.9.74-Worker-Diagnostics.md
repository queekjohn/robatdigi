# QA — EVazar Core 2.9.74 / Worker 1.13.10

## Scope
Core Worker dispatch, source-error classification, and the existing bounded stock-sync log. Import queue behavior and import locks were not modified.

## Static checks to run before release
- PHP syntax check for all plugin PHP files.
- Node syntax check for `worker/digikala-worker.js`.
- ZIP integrity and package folder layout.

## Behavior changes
- No candidate due to cooldown or daily budget returns a specific diagnostic without an outbound request.
- Worker HTTP failures include status/scope in the product stock-sync log.
- Upstream source failures do not mark a responsive Worker as unhealthy; requests rotate on subsequent products instead of cascading to the whole Worker pool.
- Product-specific 404 does not cool down the Worker pool.
- Source-side failures are labeled as source failures, not product-not-found; they do not poison a healthy Worker cooldown.
- Legacy ambiguous HTTP 404 triggers at most one alternate-worker retry.
- Stale/busy product results are marked deferred instead of successful.

## Not live-tested
This package has not been deployed to the live WordPress or Cloudflare environments. Confirm the first 10–20 sync records after deployment, and verify Worker version header is `1.13.10`.
