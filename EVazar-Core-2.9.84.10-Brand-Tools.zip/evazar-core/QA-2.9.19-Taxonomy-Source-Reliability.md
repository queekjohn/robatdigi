# QA — EVazar Core 2.9.19 / Worker 1.12.1

## Changes validated

- Exact child source path `/search/category-washing-machines/daewoo/` can be reconstructed from a legacy parent-only URL plus stored product breadcrumb and English brand slug.
- Brand `Daewoo` source resolves to `/brand/daewoo/` even when its legacy stored URL pointed at a category.
- Source-page Worker route accepts safe relative `/search/` and `/brand/` paths and rejects absolute/external paths, protocol-relative paths, traversal and unsupported paths before upstream fetch.
- Nested filtered categories request the exact public page and do not fall back to the root category API text.
- Source text parser selects editorial prose from a fixture and excludes navigation, product-grid and footer noise; it rejects anti-bot challenge pages.
- Custom category/brand prompts without `{source_content}` have the exact fetched source appended. Prompts with the placeholder substitute it and do not leave the placeholder token behind.
- Generated-output ownership checks recognize unchanged stored AI output and reject a manually modified version.
- Status handling retains existing descriptions when source retrieval, AI generation or saving fails.
- Embedded Worker source is byte-identical to standalone Worker 1.12.1.

## Automated checks

- PHP syntax: `importer.php`, `queue-manager.php`, `batch-processor.php`, `evazar-core.php`.
- JavaScript syntax: `node --check digikala-worker.js`.
- Helper/path tests: source URL safety, parent-vs-child resolution, generated brand-child URL, editorial HTML extraction, challenge rejection, custom prompt source injection, and manual-content ownership.
- Worker tests: exact source-page proxy plus unsafe-path rejection.

## Limits

Tests are local and use mocked WordPress/HTTP responses for the source-path and Worker route checks. The release has not been deployed against the live WordPress database or live Worker endpoint from this environment. Final proof still requires running the three target terms on the site and checking their recorded source URL/method/status metadata.
