# EVazar Core 2.9.59 — Cloudflare Workers Analytics Monitor

- Adds an admin-only Cloudflare GraphQL Analytics monitor for configured primary Worker accounts.
- Adds account ID + matching Worker URL mapping and a separate read-only Analytics API token setting.
- Displays account-wide Workers request totals for the current UTC day when manually refreshed.
- Existing primary Worker pool, internal per-URL budget, Gemini routing, image delivery, and product behavior remain unchanged.
- Analytics are informational and may lag; local Core limits remain enabled as the conservative dispatch guard.
