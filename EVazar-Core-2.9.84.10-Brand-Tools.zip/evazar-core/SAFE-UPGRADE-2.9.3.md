# Safe upgrade — EVazar Core 2.9.3

1. Back up the current Core plugin folder and save the currently deployed Worker scripts.
2. Replace `evazar-core/` with this package; do not use a version-suffixed folder name.
3. Deploy `worker/digikala-worker.js` (Worker 1.11.7) to every configured EVazar image/product Worker endpoint. Keep existing secrets and host bindings unchanged.
4. The separate Worker ZIP contains the same JavaScript as the Core package. Do not deploy different Worker variants to the configured endpoints.
5. Test normal CDN success, forced CDN retry, direct fallback, direct retry through Worker, cards, product gallery, `srcset`, lazy images, and infinite-scroll additions.
6. Roll back both Core and Worker versions together if the post-deploy smoke test shows a regression.
