# Core 2.9.81 / Worker 1.13.13 — Taxonomy Queue Coalescing

- Fixed a permanent singleton stall: one ready category/brand no longer gets requeued forever.
- Added a 30-second coalescing window and rescheduled nudge for a lone ready queue item.
- Sends 2–5 ready terms of the same type in one taxonomy batch; only when preflight leaves exactly one eligible term does it use the explicit guarded `taxonomy_seo_single` Worker contract.
- Worker validates singleton size/count/type and stable `gm-taxsingle-` request ID separately from the 2–5 batch contract.
- Category and brand remain separate; product importer only enqueues terms that were newly created, preserving valid existing descriptions.
- Failed source preflight does not trigger Gemini; source/config retry backoff is retained.
