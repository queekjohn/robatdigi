# QA report — EVazar Core 2.9.44 Parallel Gemini Product Batches

## Expected behavior
- With queue batch size 25, Gemini product batch size 5, parallel mode enabled and parallelism set to 5, eligible product AI entries are divided into up to five 5-product chunks and dispatched in one cURL-multi wave to five distinct configured Worker URLs.
- A new wave is started only after the prior wave's responses are processed. If fewer Workers are healthy/free or fewer chunks remain, concurrency is lower than five.
- If a Worker is busy, in cooldown, or returns a definitive rate/quota rejection, its assigned sub-batch is deferred rather than silently sent to a sibling Worker.
- If a request outcome is ambiguous, Core does not automatically retry/fail over the same sub-batch. Queue rows are marked as outcome unknown for manual inspection.
- Existing product batch mode remains sequential when parallel mode is off.
- The parallel toggle defaults to off and requires the existing product-batch toggle plus Gemini-only engine mode.

## Static/package validation performed
- PHP syntax validation passed for all 5 top-level PHP files.
- Worker JavaScript `node --check` passed.
- Embedded `worker/digikala-worker.js` is byte-identical to standalone Worker 1.13.4 from `EVazar-Worker-1.13.4-No-ChatGPT-No-Research-Clean.zip`.
- Static assertions passed for: parallel toggle default-off behavior; queue sub-batching; distinct Worker selection; HMAC timestamp/nonce/signature validation; cURL multi requirement; per-DKP locks; per-Worker locks; stable idempotency ledger; assigned Worker propagation to primary and fallback requests; ambiguous-outcome fail-closed behavior.
- ZIP CRC/integrity and plugin-root checks passed.

## Not performed / deployment dependency
- No live WordPress database or production REST loopback test was available.
- The build container does not expose PHP `curl_multi_init`, so real parallel HTTP behavior could not be executed in this environment. Production PHP must have cURL and `curl_multi_init()` for parallel mode; otherwise it intentionally defers work and sends no parallel Gemini request.
- The signed loopback POST to `rest_url('evazar/v1/internal-product-ai-batch')` must be reachable from the production host over HTTPS. A hosting firewall, Cloudflare rule, REST restriction or loopback failure will fail closed and defer work. Validate first with parallelism 2 before using 5.
- No real Gemini API request was made in this build. The report does not assert production-time performance or quota behavior.
