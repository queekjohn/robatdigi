# EVazar Core 2.8.96 — Gemini Request Correlation Logging

- Added one correlation ID per logical Gemini generation request and reused it across Worker attempts and retries.
- Added product DKP to product-import Gemini operational events; taxonomy requests record purpose and term ID instead.
- Added per-attempt sequence, Worker index, initial/failover route, per-Worker retry index, and retry flag.
- Added safe events for transport failures, HTTP failures, and invalid responses so a failed first Worker and successful fallback can be linked.
- Added `X-EVazar-Request-ID` request header for optional downstream tracing. No prompt, product title, or API key is logged or sent in this identifier.
- Kept event retention capped at 80 entries.
