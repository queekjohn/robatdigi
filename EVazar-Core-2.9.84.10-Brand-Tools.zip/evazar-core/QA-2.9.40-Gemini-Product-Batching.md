# QA — EVazar Core 2.9.40 Gemini product batching

## Package / static checks
- All top-level Core PHP files pass `php -l`.
- Embedded Worker JavaScript passes `node --check`.
- Embedded Worker source is byte-identical to standalone Worker 1.13.4.
- Batch-response parser harness: 4/4 checks passed:
  - valid DKP-keyed output maps to independent product JSON objects;
  - missing product output is detected;
  - duplicate DKP output is rejected;
  - unknown DKPs are ignored and cannot be mapped to queue products;
- Batch-generation harness: one mocked Gemini call produced independent responses for two DKPs, and the call metadata showed `purpose=product_import_batch` with `batch_size=2`.
- The generated package ZIP is checked for archive integrity and exact root folder.

## Source-level flow checks
- Batching is opt-in and disabled by default.
- Collection happens only inside queued imports, for `gemini_only` mode with product AI enabled.
- Output mapping uses DKP, not response-array order.
- A single product reaching the batch stage due to skipped/non-AI queue rows falls back to the existing single-product request contract.
- Each product resumes through the original product-save and indexing code after the AI response is supplied.
- Queue rows held for batching retain the active claim token until each item's outcome is finalized.
- Gemini quota / rate-limit / temporary-unavailability errors defer unresolved rows without increasing retries.
- No schema migration or Worker change was introduced.

## Not tested
- No live WordPress database, production queue, real Gemini API, or live `evazar.ir` browser session was exercised.
- This build-level QA does not establish production timing, token consumption, or content quality. Those require a controlled, small queue run after deployment.
