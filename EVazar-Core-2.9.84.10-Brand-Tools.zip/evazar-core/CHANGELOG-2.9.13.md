# EVazar Core 2.9.13

- Added a Core setting for image routing: direct Digikala CDN (default) or Cloudflare Worker/Image CDN.
- The canonical image URL helper now respects the selected route, including resized URLs.
- In direct mode, the Core does not emit the Worker image-recovery script, preventing image display from probing `img.evazar.ir`.
- Import/price Worker configuration and Gemini Worker rotation are unchanged.
