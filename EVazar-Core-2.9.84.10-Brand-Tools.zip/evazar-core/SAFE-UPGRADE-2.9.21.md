# Safe upgrade — EVazar Core 2.9.21

1. Back up the currently installed Core plugin and database.
2. Install `EVazar-Core-2.9.21-Single-Term-Taxonomy-Processor.zip` as a WordPress plugin replacement.
3. Open Products → تنظیمات افیلیت, then find the panel **آزمایش یا بازنویسی یک دسته / برند** above the bulk tool.
4. Choose the taxonomy (category or brand), enter the term ID, and click **بررسی مورد**. Confirm the displayed canonical name and source URL before processing.
5. Click **پردازش فقط همین مورد** to run one term. Leave the regenerate checkbox off unless the preview confirms AI-owned existing content and you explicitly want a fresh AI rewrite. Manually authored and locked descriptions remain protected.
6. Do not click the bulk action while testing the API source change.

Admin URL: `/wp-admin/edit.php?post_type=evazar_product&page=evazar-affiliate-settings`

No database migration is required. The plugin's bundled Worker remains the one from Core 2.9.20 (Worker 1.12.4); this release adds only the single-term taxonomy interface and its guarded AJAX handling.
