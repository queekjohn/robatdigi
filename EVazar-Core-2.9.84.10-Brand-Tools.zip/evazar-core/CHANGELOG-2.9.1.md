# EVazar Core 2.9.1

- Fixed OSS image resize parsing so dimensions are confined to `image/resize` and later operations such as `quality` retain their position.
- Explicit admin AI rewrite is now a one-shot opt-in flag. Routine existing-product reimports keep skipping Gemini; valid AI output is checkpointed before index sync so retries do not spend Gemini quota twice. The flag is cleared only after index sync succeeds.
- Rewrite queue includes `_evazar_sku`, `_sku` and legacy `_evazar_dk_id`, normalizes DKP values and does not count failed queue inserts as success.
- Browser image fallback preserves and maps lazy `data-srcset`, `data-lazy-srcset` and live `srcset`; it finds a CDN URL even when the current `src` is a placeholder.
- Product Index sync failures are tracked with bounded exponential backoff and retry attempts; retry rows do not starve normal backfill. Full table schema upgrade is not run on every five-minute backfill batch.
- Product Index version bumped to 1.2.1 to refresh canonical and legacy identities incrementally.
- Hardened browser failover for placeholder/lazy-loaded images: directizes and preserves all relevant `srcset`/lazy attributes, and can promote the first valid direct candidate to `src` when the prior `src` is only a placeholder.
- Explicit bulk AI rewrite no longer deletes existing excerpts/metadata before valid AI output; existing content survives AI/network failures and is cleared only along the successful rewrite path.
