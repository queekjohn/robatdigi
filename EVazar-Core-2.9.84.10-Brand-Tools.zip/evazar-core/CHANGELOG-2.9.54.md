# EVazar Core 2.9.54 — Product-page price cache optimization

## Changes
- Public product-page live inquiry now calls the existing local transient cache instead of forcing a fresh fetch on every page view.
- The successful-result transient lifetime is aligned from 90 seconds to 120 seconds, matching the Worker product cache window.
- The scheduled background stock/price synchronization continues to call `evazar_inquire_product_price($post_id, true)`, so scheduled freshness checks still bypass both the local transient and the Worker product cache.
- Updated plugin version metadata and internal parallel-batch User-Agent to `2.9.54`.

## Expected behavior
- Repeated visits to the same product within 120 seconds can be served by WordPress's local transient without making another request to the Cloudflare Worker.
- If the local transient expires but the Worker cache remains valid, the Worker may return its cached source response.
- A successful background sync also refreshes the local transient. Failures are not cached as successful price data.

## Safety and scope
- No Worker code, Gemini settings, API keys, Worker secrets, queue batching, or background schedule interval changed.
- Background price/stock refresh remains `fresh=1` and is intentionally not cache-short-circuited.
- Worker remains `1.13.7`; deploy only the Core ZIP.
