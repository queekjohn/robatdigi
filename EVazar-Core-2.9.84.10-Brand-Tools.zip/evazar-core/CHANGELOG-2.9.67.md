# EVazar Core 2.9.67

- Restored the queue setting “حداکثر محصولات قابل پردازش در هر نوبت”.
- Added a separate option `evazar_queue_max_products_per_run`, default 25, range 5–50.
- The configured number is a hard upper bound; eligible Worker count, parallelism, PHP runtime guard, and Gemini chunk size may reduce actual work per run.
- Kept the legacy `evazar_queue_batch_size` option synchronized for compatibility.
- Kept Worker code unchanged (1.13.9); this is a Core UI/queue-cap fix only.
