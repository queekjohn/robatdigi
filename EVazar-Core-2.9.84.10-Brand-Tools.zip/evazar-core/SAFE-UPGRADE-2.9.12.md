# Safe upgrade notes — EVazar Core 2.9.12

## Scope

This release updates only Product/Offer structured data:
- Uses ISO 4217 `IRR` and converts the stored Toman price to Rials.
- Identifies the imported seller and affiliate destination instead of claiming EVazar is the seller.
- Respects `evazar_opt_schema_enable` and `evazar_opt_schema_mode`.
- Removes generated/fabricated price validity dates and third-party AggregateRating markup.

No image CDN, Worker, importer, database schema, archive query, product UI, gallery or lazy-loading logic is changed.

## Deployment

1. Back up the current `evazar-core/` directory and database.
2. Replace the existing plugin directory with `evazar-core/` from `EVazar-Core-2.9.12-Product-Schema-Currency-Fix.zip`; do not create a version-suffixed directory.
3. Install the paired Theme 1.13.06 so the standalone theme JSON-LD does not duplicate the Rank Math Product node.
4. Clear the HTML/page cache and run Rich Results Test on representative product pages.

## Known intentional omissions

`shippingDetails`, `hasMerchantReturnPolicy`, and `validFrom` are not emitted because the available product metadata does not authoritatively describe the external seller's shipping/return terms or the actual start of the current price. Do not add placeholder values to suppress warnings.

## Validation limits

Package/static checks only. The release has not been installed on the live site, and Search Console recrawl has not occurred.
