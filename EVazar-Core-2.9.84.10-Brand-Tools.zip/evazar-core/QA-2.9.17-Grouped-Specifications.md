# QA — EVazar Core 2.9.17 (Grouped Specifications)

## Contract

- Worker 1.12.0 returns both `product.specs` (flat, backward compatible) and `product.spec_groups` (group title plus rows).
- Core 2.9.17 normalizes each group independently, saves the grouped JSON in `_evazar_spec_groups`, and continues saving `_evazar_key_features` for legacy readers and the editor.
- Flat rows missing from a partial grouped payload are retained in an untitled fallback group rather than silently dropped.
- When no usable source specifications arrive, existing feature data/group metadata is preserved.

## Validations performed

- PHP syntax check across the Core package passed.
- Direct API grouped extraction test passed for multiple groups and multi-value attributes.
- Core contract test passed: Worker groups are preserved while legacy flat features remain available.
- Partial grouped payload test passed: extra rows from the flat fallback are retained without inventing a group.
- Exact label check passed: `ظرفیت حافظه داخلی` is not shortened to the ambiguous `حافظه داخلی`.
- Embedded Worker source matches the standalone Worker 1.12.0 source byte-for-byte.

## Not yet verified

This package has not been installed against the live WordPress database or tested with a live Digikala response. Re-import a sample product after deploying Core, Worker, and Theme together to confirm the actual source group titles and rows.
