# EVazar Core 2.8.86

- Adds a dedicated **گزارش Gemini** submenu under the EVazar Products admin menu.
- Makes the report discoverable even when no Gemini events have been recorded yet.
- Displays quota/rate cooldown status and up to 80 operational events without exposing API keys or prompts.
- No changes to product import logic, queue processing, Gemini cooldown policy, image CDN, or theme files.
