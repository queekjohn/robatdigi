# EVazar Core 2.9.64 — Queue Retry and Gemini 5xx Recovery

- Fixed queue `next_attempt_at` / stale-claim timestamps to consistently use the WordPress site timezone, matching the SQL checks that use `current_time('mysql')`.
- Recent overlapping uncertain requests now defer through the normal queue cooldown without incrementing retry generation or claiming manual review is required.
- Recovered, explicitly stored upstream HTTP 5xx responses are classified as retryable; ambiguous transport failures remain protected and auto-return to the queue after the safety window.
- In serial batch dispatch, only the batch that was actually sent gets a new retry generation after an unknown result. Later, unsent batches return to the queue without incrementing retries.
- Capped generic queue retry backoff at 10 minutes (exponential), while preserving provider `Retry-After` and daily quota cooldowns.
- Updated Worker to 1.13.8: the exact upstream 5xx response is stored as retryable in the existing Durable Object and marked with `X-Evazar-Gemini-Outcome: retryable`. Network exceptions remain `uncertain`.
- No database schema migration or new Cloudflare binding is introduced. Existing `EVAZAR_GEMINI_IDEMPOTENCY` binding, if already configured, remains compatible.
