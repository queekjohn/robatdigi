# Safe upgrade — EVazar Core 2.9.84.2

1. Back up the current `evazar-core` plugin and the WordPress database.
2. Ensure **every** Gemini Worker URL configured under `evazar_gemini_worker_urls` runs Worker **1.13.13.1** or newer with 15-product batch support. If Worker 1.13.13.1 is already deployed to all configured Gemini Workers, no Worker redeployment is needed for this capacity-only update.
3. Replace the plugin using `EVazar-Core-2.9.84.2-Queue-Capacity-75.zip` (the ZIP root remains `evazar-core/`).
4. On the first WordPress `init`, a one-time migration sets `evazar_queue_max_products_per_run` and its legacy companion option to 75. The queue settings screen should show 75.
5. For a 75-product run, the setup needs five unique Gemini Worker URLs that are eligible (not in cooldown / busy), cURL-multi support, and PHP runtime extension to at least 180 seconds. If these safety prerequisites are missing, the run is capped to 15 products and the rest remain queued for a later run.
6. Check the Gemini operation log for `batch_dispatch_plan` and `batch_dispatch_wave`: the target path is five batches × 15 products, assigned to five distinct Workers.

This is local static/unit QA only. It has not been tested against the production WordPress database, live Cloudflare deployment, or real Gemini responses.
