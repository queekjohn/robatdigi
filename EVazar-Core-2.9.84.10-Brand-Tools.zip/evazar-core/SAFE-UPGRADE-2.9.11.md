# Safe upgrade notes — EVazar Core 2.9.11

## Scope

This is a narrow image-recovery patch for the image failover logic only.

- Correctly unwraps Worker image URLs that use `?img=<encoded Digikala URL>` before trying the direct origin.
- Validates the unwrapped origin as HTTPS on `dkstatics-public.digikala.com`; it does not accept arbitrary hosts.
- If a forced Worker retry still returns an error/non-image response, makes one final direct browser request for that individual image.
- Keeps the existing bounded scroll/connectivity recovery budget and cooldown if the final direct request also fails.
- Does not switch all page images to direct mode, alter product data, change gallery layout, or change archive filtering/import logic.

## Deployment

1. Back up the current `evazar-core/` folder.
2. Replace it with the `evazar-core/` folder from `EVazar-Core-2.9.11-Image-Origin-Fallback.zip` (do not use a version-suffixed folder name).
3. Keep Theme 1.12.86 and Worker 1.11.8 unchanged for this patch.
4. Clear page/cache layers that cache HTML or plugin assets, then test a category and product gallery on desktop and mobile.

## Validation limits

Automated Chromium tests used mocked network responses to force Worker errors and direct-origin recovery. This does not replace testing against the live Cloudflare Worker and Digikala origin after deployment.
