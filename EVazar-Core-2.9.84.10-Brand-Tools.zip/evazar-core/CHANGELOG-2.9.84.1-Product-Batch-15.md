# Core 2.9.84.1 — Product AI batch size 15

- Raises the automatic product Gemini batch ceiling from 10 to 15 consistently across settings, queue partitioning, internal parallel REST payload validation, request-context checks, request headers, logging, and the Cloudflare Worker policy gate.
- One-time migration sets `evazar_ai_product_batch_size` to 15 on the first WordPress `init` after upgrade; the admin can later change it to any supported value from 2 to 15.
- Keeps automatic singleton fallback blocked. A previously deferred singleton retry remains the only guarded one-product exception.
- Adds conservative JSON-value extraction for valid JSON surrounded by harmless prose/fences. It does not repair malformed/truncated JSON or weaken per-product DKP/content validation; failed batches continue through the existing queue retry path.
- Product batch work remains limited by the existing queue claim cap (50 products) and eligible Worker/parallelism limits.
