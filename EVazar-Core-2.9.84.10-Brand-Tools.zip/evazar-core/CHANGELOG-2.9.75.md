# EVazar Core 2.9.75 / Worker 1.13.11 — Network Diagnostic Correction

- Corrects Worker 1.13.10's classification of synthetic 502/504 responses created by the guarded fetch wrapper: network failures are now reported as `source_fetch_failed`, distinct from real upstream HTTP 5xx responses (`source_server_error`).
- Captures bounded proxy-generated upstream network error categories from both v2 and v1 API attempts and includes them in the diagnostic message.
- Clears upstream-provided `X-Evazar-*` proxy diagnostic headers before setting trusted local diagnostics, so the upstream cannot forge the proxy's error classification.
- Keeps true double-404 as `product_not_found`, and keeps rate limit / source server failures separate. The Worker pool is not cooled down for source-scope responses.
- Core price/stock log schema and bounded worker diagnostics from 2.9.74 are retained. Import queue code and import locks are unchanged.
