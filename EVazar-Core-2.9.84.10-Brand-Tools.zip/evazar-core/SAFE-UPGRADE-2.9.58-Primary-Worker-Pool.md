# Safe upgrade — EVazar Core 2.9.58

1. Back up the current EVazar Core plugin and database.
2. Install the Core ZIP while retaining the existing legacy Worker URL and token.
3. First test with the new Worker URL list empty; behavior should remain compatible with the legacy setting.
4. Deploy the same supported Worker code to a second, separate Cloudflare account and configure its internal token.
5. Add both Worker base URLs, one per line, in EVazar Core settings. Ensure the two URLs belong to different accounts.
6. Start with the default 85,000 per-URL Core budget; reduce it if either account has other traffic.
7. Test one product import and one price refresh, then inspect logs and both Cloudflare usage dashboards before increasing queue concurrency.
8. Roll back by clearing the URL list; the legacy single URL remains the fallback.
