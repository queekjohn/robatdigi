# Safe upgrade notes — EVazar Core 2.9.9

- Intended to work with EVazar Theme 1.12.86 and remains compatible with the existing image Worker 1.11.8.
- Replaces the existing `evazar-core/` folder; do not create a version-suffixed plugin folder.
- Take a backup of the existing plugin first. No database schema migration is included.
- Validation in the bundled report covers static checks and browser-simulated image-failure flows. Production VPN/network tests still need to be performed on real devices.
