# Safe upgrade — EVazar Core 2.9.5

This is a focused image-recovery timing update over 2.9.4. It changes only the image failover JavaScript embedded in `evazar-core.php` and the plugin version metadata/changelog.

Recommended verification after installation:
1. Purge page/CDN cache and test a product page and a category with infinite scroll.
2. In DevTools Network, filter to Img and block one `img.evazar.ir` image request; verify the affected image falls back without breaking the product gallery.
3. Test on mobile and desktop with cache disabled. A slow CDN image should begin fallback after about 1.3s on mobile or 1.8s on desktop for visible/eager images.

Note: these are fallback trigger times, not guaranteed total display times. If both the Worker/CDN and the original image host are unavailable or slow, the browser still cannot display the image until a reachable source responds.
