# EVazar Core 2.9.63 — Cloudflare Analytics Adaptive Worker Routing

- Connected same-day Cloudflare Workers Analytics snapshots to primary Worker selection.
- Accounts at the configured daily threshold are skipped; Core's atomic per-URL counter remains as a fallback guard.
- Load selection prefers the least-used eligible Cloudflare account when fresh Analytics is available for all candidates.
- Analytics reads both per-script usage (for visibility) and account-wide usage (for quota safety); custom hostnames use conservative account-level metrics.
- Added a 15-minute WP-Cron refresh; outgoing requests never call Analytics synchronously.
- Routed OpenAI requests through the primary Worker pool instead of pinning them to the legacy URL.
