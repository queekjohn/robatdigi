# EVazar Core 2.9.60 — Cloudflare Analytics Permission Guidance

- Clarifies the exact Cloudflare API token permission: Account Analytics → Read.
- No routing, request budgeting, Gemini, image, product, or database behavior changed from 2.9.59.
- Cloudflare Analytics remains informational; the local Primary Worker budget stays active.
