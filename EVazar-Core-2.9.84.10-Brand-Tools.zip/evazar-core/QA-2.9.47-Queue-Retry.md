# QA — EVazar Core 2.9.47 / existing Worker 1.13.6

## Static checks
- PHP syntax: all top-level Core PHP files pass `php -l`.
- Worker JavaScript: `node --check` passes for standalone and bundled Worker sources.
- Bundled Worker source remains byte-for-byte identical to the existing Worker 1.13.6 source; no Worker redeployment is required.
- Queue failure handlers have no fixed five-attempt terminal cutoff.
- Stale processing recovery schedules `pending` with capped exponential backoff.
- Unknown-outcome branches increment `retries`; batch identity includes retry generation; old uncertain ledger overlaps are ignored only after the cooldown.
- Core ZIP root is exactly `evazar-core/`; ZIP integrity passes.

## Not tested live
- No production WordPress database, Cloudflare deployment, or live Gemini call was performed. Verify a normal successful import and a controlled retry in production after backup.
