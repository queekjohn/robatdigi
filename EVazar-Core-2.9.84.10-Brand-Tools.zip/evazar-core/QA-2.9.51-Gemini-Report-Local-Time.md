# QA — EVazar Core 2.9.51 / Worker 1.13.7

## Version/package checks
- WordPress plugin header reports version `2.9.51`.
- Internal parallel-batch User-Agent label is aligned to `2.9.51`.
- The embedded Worker source matches the standalone Worker 1.13.7 JavaScript byte-for-byte.
- The release uses a new versioned filename and does not overwrite the 2.9.50 file path.

## Local-time report checks
- Gemini report event timestamps (`time`) and cooldown-until (`until`) are formatted from stored Unix timestamps using the WordPress-configured timezone via `wp_date()` / `wp_timezone()`.
- Timezone regression cases previously exercised and retained in this code path: UTC, America/New_York daylight and standard time, America/Los_Angeles, Asia/Tehran, zero/absent timestamp, and fallback timezone.
- Pacific-specific quota-reset labels remain explicitly Pacific; raw stored timestamps are not rewritten.

## Existing queue safeguards carried forward
- Invalid batch output remains on the batch retry path with retry generation reflected in request identity; no automatic single-product Gemini fallback is reintroduced.
- Worker-aware distribution, dispatch-plan / assignment diagnostics, cooldown handling, queue capacity guard, and singleton deferral remain in the source carried forward from the 2.9.50 maintenance build.

## Checks run for this versioned package
- PHP syntax checks: all 5 plugin PHP files passed `php -l`.
- Node syntax check for Worker JavaScript.
- ZIP integrity checks for Core, Worker, and complete release archive.
- Archive content checks for plugin header, User-Agent label, report formatter, and Core/standalone Worker byte equality.

## Limitations
These are local source/package checks. They do not prove the live site's WordPress timezone setting, current deployed Core/Worker versions, available quotas, or production Gemini behavior. Verify the report after installing this version.
