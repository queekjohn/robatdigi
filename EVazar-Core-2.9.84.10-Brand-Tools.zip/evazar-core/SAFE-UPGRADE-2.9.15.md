# Safe upgrade — EVazar Core 2.9.15

## Scope

This version corrects specification extraction/normalization during imports only. It preserves the existing `_evazar_key_features` text format consumed by the EVazar theme and the Core product metabox. It adds no tables, options, scheduled jobs, or one-time database migrations.

## Recommended deployment

1. Back up the current `evazar-core/` plugin directory and database.
2. Replace the existing plugin directory with the `evazar-core/` folder from `EVazar-Core-2.9.15-Specification-Normalization.zip`. Keep the directory name `evazar-core`; do not create a version-suffixed plugin folder.
3. Do not replace the theme or deploy the bundled Worker as part of this release; neither is changed by 2.9.15.
4. Re-import one test product that has several specification groups, and check the product page plus the product metabox.
5. If the test succeeds, let normal queued imports use the update. This release does not automatically rewrite the existing catalog.

## Expected behavior

- Direct API fallback extracts specifications from all groups.
- Worker and direct API output are normalized with the same rules.
- Exact duplicated rows disappear; distinct or conflicting rows are retained.
- Empty or malformed upstream specifications do not erase an already-populated feature list.
- Numeric values, capacities, model names, and hyphens are retained.

## Validation performed

- PHP syntax validation passed for all plugin PHP files.
- Focused CLI tests passed for multi-group extraction, Persian/English aliases, exact duplicate removal, and preserving a model value such as `X1605 - 2`.
- Package-level tests only; this archive has not been installed on the live EVazar site and was not tested against live Digikala responses.
