# Safe upgrade — EVazar Core 2.9.49

1. Take a database and plugin-file backup before replacing the Core plugin.
2. Replace/update the `evazar-core` plugin using this ZIP. The ZIP root folder is `evazar-core`.
3. No database schema migration and no Cloudflare Worker redeployment are part of this change.
4. For adaptive per-Worker capacity, ensure all three options are enabled/configured in the AI settings: product batching, parallel Gemini batches, and the desired products-per-Gemini-request value (for example 10); set parallel requests to the desired ceiling (for example 5).
5. In Queue Settings, set the maximum products per run (for example 50). Core will cap each run to the configured AI batch size multiplied by the number of currently eligible Workers.
6. Watch the Gemini operations log for `batch_output_invalid`. If it appears, the response was HTTP-successful but no product result passed validation; the batch is returned to normal queue retry handling instead of triggering N immediate single-product requests.

This package has passed static PHP syntax and ZIP integrity checks only; it has not been live-tested against the production database or Gemini API.
