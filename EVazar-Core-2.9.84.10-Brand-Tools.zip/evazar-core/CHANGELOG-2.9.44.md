# EVazar Core 2.9.44 — Parallel Gemini Product Batches

- Adds an opt-in parallel mode for product-AI batches. If the queue claims 25 products and the Gemini request batch size is 5, Core divides the eligible AI work into five independent 5-product sub-batches and sends up to five signed internal WordPress requests concurrently.
- Each sub-batch is pinned to one distinct configured Gemini Worker URL in the wave. The Gemini engine does not fail over an assigned parallel sub-batch to a sibling Worker; definitive rate/quota rejection defers that sub-batch instead of stealing another sub-batch's Worker assignment.
- Uses the bundled WordPress Requests multi-request interface with the cURL multi transport. If true concurrent transport, HMAC configuration, valid HTTPS loopback endpoint, or valid Worker assignments are unavailable, Core fails closed and defers the unsent work.
- Adds a signed internal REST route using HMAC derived from the existing internal Worker token and WordPress auth salt. Request timestamp, one-time nonce, signature, payload size, entry structure, unique DKPs and configured Worker assignment are validated. No additional Worker secret or deployment is required.
- Preserves the 2.9.43 persistent idempotency ledger, stable per-sub-batch request IDs, atomic DKP locks, per-Worker locks, cached-success replay and conservative treatment of ambiguous outcomes.
- Fallback calls for a missing product output remain pinned to the same sub-batch's Worker, preventing them from taking a Worker assigned to a sibling sub-batch.
- The parallel setting defaults to off; product batching must also be explicitly enabled and the engine must be `gemini_only`. Maximum parallelism is configurable from 1 to 5.
- Worker 1.13.4 is unchanged. No product index, prompt content, product schema, pricing, image logic, theme, or database schema changes are made by this version.
