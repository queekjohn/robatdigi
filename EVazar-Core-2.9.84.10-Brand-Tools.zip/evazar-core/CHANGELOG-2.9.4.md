# EVazar Core 2.9.4 — Non-image Origin Retry Fix

- Worker retries upstream 2xx responses that have a non-image Content-Type (for example, an HTML anti-bot/challenge response).
- Removes forced one-year upstream fetch caching before MIME validation; only successfully validated image responses enter caches.
- Recovery requests return no-store at the public response layer, ensuring a requested retry reaches the Worker.
- Failed image responses expose safe diagnostics: Worker version, origin status, and upstream Content-Type.
- Bundled Worker is version 1.11.8 and matches the standalone release byte-for-byte.
- Existing per-image recovery order, host allowlist, product-cache namespace, and theme/gallery files are unchanged.

Validation performed: PHP lint, JavaScript syntax check, ZIP CRC checks, bundle parity, and mocked runtime cases including HTML 200 then valid image, persistent non-image response, 404 retry, and disallowed host rejection. Production Cloudflare/origin behavior must still be verified after deployment.
