# EVazar Core 2.9.22 — Dynamic Taxonomy Prompts

- Reworked category and brand SEO prompts to choose structure dynamically instead of forcing recurring paragraph counts or H2/H3 layouts.
- Added a conservative one-time migration: only the exact known legacy category/brand prompt values are replaced; custom prompts remain unchanged.
- Taxonomy source content is now appended in an explicit `SOURCE_TEXT_BEGIN` / `SOURCE_TEXT_END` block and treated as untrusted data, reducing instruction injection risk.
- Product prompt and product rewriting flow are unchanged.
- No existing taxonomy descriptions are regenerated or modified by this update.
