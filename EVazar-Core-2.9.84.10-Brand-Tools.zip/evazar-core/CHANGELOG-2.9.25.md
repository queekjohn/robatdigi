# EVazar Core 2.9.25 — Native Gemini Google Search grounding

- Replaced the external taxonomy web-search integration with Gemini API built-in `google_search` grounding.
- Removed the third-party search API call, its settings field, API-key handling and credits display.
- Search grounding is attached only when a Gemini request is tagged `purpose=taxonomy_seo` and the taxonomy web-research toggle is enabled. Product prompts and product-request payloads remain unchanged.
- Grounding queries and source titles/URLs returned by Gemini are stored as private term metadata for administrator review; they are not appended to public descriptions.
- Existing Cloudflare Workers remain compatible because the current Worker proxy passes through the Gemini request body; no Worker redeployment is needed.
- Existing custom category/brand prompts are retained; only exact shipped 2.9.24 prompts are migrated to 2.9.25 defaults.
- No bulk rewrite is triggered on upgrade.
