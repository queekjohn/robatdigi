# EVazar Core 2.9.24 — Better taxonomy content and independent web research

- Taxonomy output length is guided by measured word count of useful source text (usually 85–115%; limited extension only for useful, evidence-backed additions).
- Category/brand text uses independent editorial structure and natural paragraph splitting, not sentence-by-sentence rewriting.
- Official Latin spellings and model codes are preserved only when verified; otherwise the precise Persian name is used instead of inventing English names.
- Added optional external web research for taxonomy requests only. Search snippets are passed to the content model as untrusted reference data; search failure falls back to the existing verified source. This implementation is superseded by Gemini built-in Google Search grounding in 2.9.25.
- Search titles/URLs and query status are stored as private term meta for internal audit and are never appended to customer-visible descriptions. The single-term admin test report shows whether results were supplied to the model, the credit count, and result title/URLs for admin verification only.
- Added a final output guard for echoed research/source blocks, reference sections, links, and raw URLs in category/brand descriptions.
- Product prompts and product requests are unchanged.
- One-time migration updates only exact shipped 2.9.22 default taxonomy prompts; customized prompts are preserved.
