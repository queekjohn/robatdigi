# EVazar Core 2.8.79

- Image failover now switches immediately only the image that actually failed.
- Removed the previous Worker retry race from the browser failover path.
- Critical/high-priority images now have a light timeout watchdog: on mobile the Direct CDN fallback starts after 2.2s of an unresolved CDN request; desktop uses 3.2s.
- Direct CDN mode is persisted with a 10-minute cookie only after a Direct CDN image successfully loads.
- Subsequent page renders can start directly from DigiKala CDN without waiting for DOMContentLoaded.
- Direct CDN failure clears the temporary direct mode.
- Zero Host Storage architecture is preserved.
