# EVazar Core 2.9.9 — Core/theme image-recovery coordination

- Adds `img.__evazarCoreManaged` to mark image elements whose CDN/direct recovery is handled by Core, allowing gallery handlers to avoid replacing retrying image URLs with local placeholders.
- On image errors, re-syncs stale `loaded`/`failed` state only if the image source signature actually changed. This prevents an old success state from blocking recovery when gallery code reuses an `<img>` before MutationObserver processing, while preserving a failed image’s bounded scroll-retry state.
- Keeps the 2.9.8 bounded scroll/resize recovery policy: at most 2 extra attempts per unchanged source, at least 5 seconds apart.
- No Worker deployment, database changes, archive changes, or product data changes required.
