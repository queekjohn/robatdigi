# EVazar Core 2.9.78 — Async Taxonomy SEO Batches

- Product import now only creates/finds categories and brands and attaches their IDs to the product. SEO generation for a taxonomy term created by import is enqueued and does not block the product-import path.
- Category and brand SEO content use independent queues and schedules. A Gemini request contains 2–5 categories or 2–5 brands of the same type; singleton requests are intentionally not sent.
- Each term has a unique database queue key and an atomic processing claim. Missing/invalid entries are retried individually after the batch response; malformed whole-batch responses are retried as a batch. There is no immediate singleton fallback.
- A category or brand that already exists is linked to new products without automatic SEO regeneration. Existing manual and locked descriptions are preserved. The admin bulk queue only enqueues terms eligible for missing/stale AI content.
- Legacy AI-generated descriptions whose status was accidentally changed to `skipped_manual` are recognized when their saved output hash proves ownership, preventing redundant generation.
- Repeated bulk queue actions do not reset items already pending, processing, or in retry backoff. Configured excluded terms and disabled taxonomy-AI mode are not repeatedly queued from the bulk UI.
- Worker contract 1.13.12 recognizes `taxonomy_seo_batch` and independently rejects singleton, mixed-type, malformed-count, and >5-item batches. Product-batch policy remains unchanged.
- Queue table is created/upgraded automatically. No manual SQL migration or new secret is required.

Local syntax, parser/policy and regression tests passed. This release was not installed against the live WordPress site and did not call the live Gemini API.
