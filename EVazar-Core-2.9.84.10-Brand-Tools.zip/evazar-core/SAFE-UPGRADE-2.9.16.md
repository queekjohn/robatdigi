# Safe upgrade — EVazar Core 2.9.16 + Worker 1.11.9

## Deployment order

1. Back up the current `evazar-core/` plugin directory and database.
2. Deploy `EVazar-Worker-1.11.9-Specification-Alignment.zip` to the Cloudflare Worker endpoint(s) used by EVazar for product extraction. Preserve existing secrets, routes, and custom-domain bindings; do not delete `EVAZAR_INTERNAL_TOKEN` or `GEMINI_API_KEY`.
3. Confirm the product endpoint response contains `version: "1.11.9"` and the `X-Evazar-Worker-Version: 1.11.9` header.
4. Replace the existing plugin directory with the `evazar-core/` folder from `EVazar-Core-2.9.16-Worker-Specification-Alignment.zip`. Keep the directory name `evazar-core`; do not create a second plugin folder.
5. Test re-import on one known product that has multiple specification groups. Compare the Worker JSON `product.specs` with the saved `_evazar_key_features` and rendered product page.
6. Check the Gemini endpoint on the deployed Worker still authenticates with the existing token and responds normally before resuming bulk imports.

## Compatibility

- Worker output remains `product.specs: [{ title, value }]`, which is the contract consumed by Core.
- Core and bundled Worker use the same Worker source and version.
- Product cache key uses `v=1.11.9` to avoid stale cached specifications.
- The public storage format `_evazar_key_features` is retained; no migration or automatic backfill occurs.
- Do not change Gemini secrets, model settings, Worker URLs, routes, or CDN bindings during deployment.

## Rollback

Keep the current Core plugin folder/database backup and prior Worker source. If the test fails, restore both the previous Core release and previous Worker source; rolling back only one side would leave the versions temporarily mismatched.
