# EVazar Core 2.9.20 — Exact Category+Brand SEO API Source

- Adds retrieval from Digikala's exact `/discovery/api/v1/categories/{category}/brands/{brand}/products` endpoint for filtered category+brand source pages.
- Validates returned category and brand codes against the requested source path before accepting SEO content.
- Extracts source text from `data.seo.content` and `data.category_brand.description`; retains exact HTML fallback if API data is missing or mismatched.
- Avoids assigning a parent category's SEO text to a filtered child page.
- Bundles Worker 1.12.4 with a strict allowlist for the category+brand API path.
- Existing successful AI content is not automatically invalidated by this source retrieval change.
- No product import, price sync, image delivery, product taxonomy hierarchy, or database schema changes.
