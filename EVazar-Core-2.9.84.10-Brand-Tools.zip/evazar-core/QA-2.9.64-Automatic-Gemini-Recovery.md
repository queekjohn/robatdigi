# QA — EVazar Core 2.9.64 / Worker 1.13.8

## Checks performed
- PHP syntax lint for every PHP file in the Core package.
- JavaScript syntax validation with `node --check`.
- Confirmed all queue-generated `next_attempt_at`, retry, and stale-claim datetimes use the WordPress site timezone helper; remaining `gmdate()` uses are intentionally UTC history/report fields.
- Confirmed the queue overlap path returns a cooldown error, not a manual-review-only outcome, and does not increase retry generation while waiting for the prior safety window.
- Confirmed stored upstream 5xx responses from Durable Object are interpreted as retryable; responses without a confirmed upstream marker remain uncertain.
- Simulated Durable Object responses: upstream 503 is recorded as retryable with `Retry-After` and the outcome header; a second request inside the cooldown does not call upstream again; retry after expiry calls upstream again and replaces the state with the new outcome.
- Confirmed serial-mode batches that were not sent are returned to pending without increasing their retry count.
- Verified Core embeds the exact same Worker source as the standalone 1.13.8 file.
- ZIP integrity, expected top-level plugin folder, and SHA-256 manifest checked.

## Not performed
- No installation on the live WordPress site.
- No requests made to the user's live Worker URLs or Gemini API.
- Production Cloudflare bindings/secrets and live request traffic were not accessible for verification.

## Expected behavior
- Ambiguous connection failures remain protected from immediate duplicate dispatch but automatically return to the queue after the safety interval.
- Confirmed upstream 5xx causes a short Worker cooldown and automatic retry via the normal queue; it does not require manual requeue.
- A definitive upstream 503 response is not confused with a connection timeout. The latter still follows the conservative uncertain-outcome path.
