# EVazar Core 2.9.84.2 — Queue capacity 75

- Raises the configured per-run queue ceiling from 50 to 75 products.
- Adds a one-time WordPress option migration setting `evazar_queue_max_products_per_run` (and legacy `evazar_queue_batch_size`) to 75.
- Preserves 15 products per individual Gemini request and the five-Worker parallelism cap.
- Allows up to five 15-product chunks in one wave when five eligible Workers, cURL-multi, and sufficient PHP runtime are available.
- Uses a safe 15-product per-run fallback when cURL-multi is unavailable or PHP cannot extend the runtime to at least 180 seconds.
- Keeps existing retry, invalid-JSON, quota cooldown, and no-single-product-fan-out behavior unchanged.
- No schema/database table migration is required; only WordPress options are updated once.
