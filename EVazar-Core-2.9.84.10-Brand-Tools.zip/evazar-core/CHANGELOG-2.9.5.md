# EVazar Core 2.9.5 — Faster Image Recovery

- Reduced visible/eager image watchdog from 4.2s to 1.3s on mobile and from 5.2s to 1.8s on desktop.
- Reduced the bounded timeout for each recovery attempt from 5.2s to 2.8s.
- When a CDN image stalls and times out, switch that image directly to the original image host instead of retrying the same CDN first.
- Preserve one cache-bypass CDN retry for explicit image errors (for example a 502), then fall back to the original host.
- Changes are isolated to the existing per-image recovery script; no gallery, archive, lazy-loading, or layout code was changed.
