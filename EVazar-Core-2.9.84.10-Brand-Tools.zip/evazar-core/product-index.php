<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Evazar Product Index 1.0
 * هدف: خارج کردن فیلتر/مرتب‌سازی‌های پرتکرار از wp_postmeta و فراهم‌کردن
 * یک ایندکس سریع و قابل توسعه برای 50k+ کالا.
 */
const EVAZAR_PRODUCT_INDEX_DB_VERSION = '1.3.0';

function evazar_product_index_table() {
    global $wpdb;
    return $wpdb->prefix . 'evazar_product_index';
}
function evazar_product_category_index_table() {
    global $wpdb;
    return $wpdb->prefix . 'evazar_product_category_index';
}

function evazar_product_index_ensure_tables() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $charset = $wpdb->get_charset_collate();
    $products = evazar_product_index_table();
    $categories = evazar_product_category_index_table();
    $sql1 = "CREATE TABLE {$products} (
        product_id bigint(20) unsigned NOT NULL,
        dkp varchar(64) NOT NULL DEFAULT '',
        sku varchar(64) NOT NULL DEFAULT '',
        brand_id bigint(20) unsigned NOT NULL DEFAULT 0,
        price decimal(18,2) NOT NULL DEFAULT 0,
        old_price decimal(18,2) NOT NULL DEFAULT 0,
        discount smallint unsigned NOT NULL DEFAULT 0,
        stock_status tinyint NOT NULL DEFAULT 0,
        availability_source varchar(32) NOT NULL DEFAULT '',
        stock_checked_at bigint(20) unsigned NOT NULL DEFAULT 0,
        views bigint(20) unsigned NOT NULL DEFAULT 0,
        rating decimal(4,2) NOT NULL DEFAULT 0,
        rating_count bigint(20) unsigned NOT NULL DEFAULT 0,
        satisfaction smallint unsigned NOT NULL DEFAULT 0,
        post_date datetime NULL DEFAULT NULL,
        updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        index_version varchar(20) NOT NULL DEFAULT '1.2.1',
        PRIMARY KEY (product_id),
        KEY dkp (dkp),
        KEY sku (sku),
        KEY brand_id (brand_id),
        KEY price (price),
        KEY stock_status (stock_status),
        KEY availability_source (availability_source),
        KEY stock_checked_at (stock_checked_at),
        KEY rating (rating),
        KEY satisfaction (satisfaction),
        KEY post_date (post_date),
        KEY stock_price (stock_status, price),
        KEY stock_date (stock_status, post_date),
        KEY stock_views (stock_status, views),
        KEY stock_rating (stock_status, rating_count),
        KEY stock_satisfaction (stock_status, satisfaction)
    ) {$charset};";
    $sql2 = "CREATE TABLE {$categories} (
        product_id bigint(20) unsigned NOT NULL,
        category_id bigint(20) unsigned NOT NULL,
        PRIMARY KEY (product_id, category_id),
        KEY category_id (category_id),
        KEY product_id (product_id)
    ) {$charset};";
    dbDelta($sql1);
    dbDelta($sql2);
    update_option('evazar_product_index_db_version', EVAZAR_PRODUCT_INDEX_DB_VERSION, false);
}

function evazar_product_index_maybe_upgrade() {
    if (get_option('evazar_product_index_db_version') !== EVAZAR_PRODUCT_INDEX_DB_VERSION) {
        evazar_product_index_ensure_tables();
    }
}

function evazar_product_index_schedule_backfill() {
    $event = wp_get_scheduled_event('evazar_product_index_backfill');
    if (!$event) {
        wp_schedule_event(time() + 120, 'evazar_stock_5min', 'evazar_product_index_backfill');
    }
}
function evazar_product_index_clear_schedule() {
    $timestamp = wp_next_scheduled('evazar_product_index_backfill');
    while ($timestamp) {
        wp_unschedule_event($timestamp, 'evazar_product_index_backfill');
        $timestamp = wp_next_scheduled('evazar_product_index_backfill');
    }
}
add_action('init', function() {
    if (function_exists('evazar_product_index_schedule_backfill')) {
        evazar_product_index_schedule_backfill();
    }
}, 21);

function evazar_product_index_normalize_number($value) {
    $raw = (string)$value;
    $raw = str_replace(['٬', ',', '،', ' '], '', $raw);
    $raw = strtr($raw, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
    return is_numeric($raw) ? (float)$raw : 0.0;
}

function evazar_product_index_availability_source_for_post($post_id) {
    $source = sanitize_key((string)get_post_meta($post_id, '_evazar_availability_source', true));
    $allowed = ['explicit_unavailable','explicit_available','fallback'];
    return in_array($source, $allowed, true) ? $source : '';
}

function evazar_product_index_stock_status_for_post($post_id) {
    $price = evazar_product_index_normalize_number(get_post_meta($post_id, '_evazar_current_price', true));
    $source = evazar_product_index_availability_source_for_post($post_id);
    if ($source === 'explicit_unavailable') return 0;
    return $price > 0 ? 1 : 0;
}


function evazar_product_index_mark_sync_failure($post_id, $code) {
    $post_id = absint($post_id);
    if (!$post_id) return;
    $code = sanitize_key((string) $code);
    $now = time();
    $previous_code = (string) get_post_meta($post_id, '_evazar_product_index_sync_error', true);
    $previous_retry = (int) get_post_meta($post_id, '_evazar_product_index_sync_next_retry', true);
    $attempts = max(0, (int) get_post_meta($post_id, '_evazar_product_index_sync_attempts', true));

    // Repeated save hooks in one request must not consume the retry budget or keep pushing backoff forward.
    if ($previous_code === $code && $previous_retry > $now && $attempts > 0) return;

    $attempts = min(5, $attempts + 1);
    $delay = min(DAY_IN_SECONDS, 300 * (2 ** max(0, $attempts - 1)));
    update_post_meta($post_id, '_evazar_product_index_sync_error', $code);
    update_post_meta($post_id, '_evazar_product_index_sync_attempts', $attempts);
    update_post_meta($post_id, '_evazar_product_index_sync_next_retry', $now + $delay);
}

function evazar_product_index_clear_sync_failure($post_id) {
    $post_id = absint($post_id);
    if (!$post_id) return;
    delete_post_meta($post_id, '_evazar_product_index_sync_error');
    delete_post_meta($post_id, '_evazar_product_index_sync_attempts');
    delete_post_meta($post_id, '_evazar_product_index_sync_next_retry');
}

/**
 * همگام‌سازی سبک وضعیت لحظه‌ای کالا با Product Index.
 *
 * این مسیر فقط فیلدهایی را که Live Inquiry تغییر می‌دهد به‌روزرسانی می‌کند
 * و عمداً سراغ taxonomy/category sync نمی‌رود تا فشار DB حداقل باشد.
 */
function evazar_product_index_sync_live_status($post_id) {
    global $wpdb;
    $post_id = absint($post_id);
    if (!$post_id || get_post_type($post_id) !== 'evazar_product') return false;
    if (!evazar_product_index_exists()) {
        evazar_product_index_mark_sync_failure($post_id, 'index_table_missing');
        return false;
    }

    $products = evazar_product_index_table();
    $price = evazar_product_index_normalize_number(get_post_meta($post_id, '_evazar_current_price', true));
    $old_price = evazar_product_index_normalize_number(get_post_meta($post_id, '_evazar_old_price', true));
    $discount = max(0, (int) evazar_product_index_normalize_number(get_post_meta($post_id, '_evazar_discount_percent', true)));
    $stock = evazar_product_index_stock_status_for_post($post_id);
    $source = evazar_product_index_availability_source_for_post($post_id);
    $checked = max(0, (int) get_post_meta($post_id, '_evazar_last_stock_check', true));

    $update_result = $wpdb->query($wpdb->prepare(
        "UPDATE {$products}
         SET price=%f,
             old_price=%f,
             discount=%d,
             stock_status=%d,
             availability_source=%s,
             stock_checked_at=%d,
             updated_at=NOW()
         WHERE product_id=%d",
        $price, $old_price, $discount, $stock, $source, $checked, $post_id
    ));
    if ($update_result === false) {
        evazar_product_index_mark_sync_failure($post_id, 'live_status_update_failed');
        error_log('[EVazar Product Index] Live-status SQL update failed for product ID ' . $post_id . '.');
        return false;
    }

    // صفر ردیف تغییرکرده می‌تواند به معنی یکسان بودن داده‌ها یا نبودن ردیف باشد؛ تفکیک می‌کنیم.
    if ((int) $wpdb->rows_affected === 0) {
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT product_id FROM {$products} WHERE product_id=%d LIMIT 1",
            $post_id
        ));
        if ($wpdb->last_error !== '') {
            evazar_product_index_mark_sync_failure($post_id, 'live_status_existence_check_failed');
            error_log('[EVazar Product Index] Live-status existence check failed for product ID ' . $post_id . '.');
            return false;
        }
        if ($exists === null) {
            return evazar_product_index_sync($post_id);
        }
    }

    do_action('evazar_product_index_synced', $post_id);
    return true;
}

function evazar_product_index_sync($post_id) {
    global $wpdb;
    $post_id = absint($post_id);
    if (!$post_id || get_post_type($post_id) !== 'evazar_product') return false;
    $post = get_post($post_id);
    if (!$post) return false;
    $products = evazar_product_index_table();
    $categories = evazar_product_category_index_table();

    $dkp = get_post_meta($post_id, '_evazar_sku', true) ?: get_post_meta($post_id, '_sku', true);
    if (!$dkp) $dkp = get_post_meta($post_id, '_evazar_dk_id', true); // legacy product identity
    if (!$dkp) {
        $url = get_post_meta($post_id, '_evazar_dk_url', true);
        if ($url && preg_match('/dkp-(\d+)/i', $url, $m)) $dkp = $m[1];
    }
    $dkp = trim((string) $dkp);
    if (preg_match('/(?:^|\b)DKP\s*[-:#]?\s*(\d+)\b/i', $dkp, $legacy_match)) {
        $dkp = $legacy_match[1];
    }
    $sku = (string)($dkp ?: get_post_meta($post_id, '_sku', true));
    $brand_id = 0;
    $brand_terms = wp_get_object_terms($post_id, 'evazar_brand', ['fields'=>'ids']);
    if (is_wp_error($brand_terms)) {
        evazar_product_index_mark_sync_failure($post_id, 'brand_term_lookup_failed');
        error_log('[EVazar Product Index] Brand-term lookup failed for product ID ' . $post_id . '; index sync stopped before writing.');
        return false;
    }
    if (!empty($brand_terms)) $brand_id = (int)$brand_terms[0];
    $category_ids = wp_get_object_terms($post_id, 'evazar_category', ['fields'=>'ids']);
    if (is_wp_error($category_ids)) {
        evazar_product_index_mark_sync_failure($post_id, 'category_term_lookup_failed');
        error_log('[EVazar Product Index] Category-term lookup failed for product ID ' . $post_id . '; index sync stopped before writing.');
        return false;
    }

    $stock = evazar_product_index_stock_status_for_post($post_id);
    $availability_source = evazar_product_index_availability_source_for_post($post_id);
    $stock_checked = (int)get_post_meta($post_id, '_evazar_last_stock_check', true);
    $data = [
        'product_id'=>(int)$post_id,
        'dkp'=>sanitize_text_field((string)$dkp),
        'sku'=>sanitize_text_field((string)$sku),
        'brand_id'=>$brand_id,
        'price'=>evazar_product_index_normalize_number(get_post_meta($post_id,'_evazar_current_price',true)),
        'old_price'=>evazar_product_index_normalize_number(get_post_meta($post_id,'_evazar_old_price',true)),
        'discount'=>max(0,(int)evazar_product_index_normalize_number(get_post_meta($post_id,'_evazar_discount_percent',true))),
        'stock_status'=>$stock,
        'availability_source'=>$availability_source,
        'stock_checked_at'=>max(0,$stock_checked),
        'views'=>max(0,(int)get_post_meta($post_id,'_evazar_views_count',true)),
        'rating'=>evazar_product_index_normalize_number(get_post_meta($post_id,'_evazar_rating',true)),
        'rating_count'=>max(0,(int)get_post_meta($post_id,'_evazar_rating_count',true)),
        'satisfaction'=>max(0,(int)get_post_meta($post_id,'_evazar_satisfaction',true)),
        'post_date'=>($post->post_date && $post->post_date !== '0000-00-00 00:00:00') ? $post->post_date : null,
        'index_version'=>EVAZAR_PRODUCT_INDEX_DB_VERSION,
    ];
    $replace_result = $wpdb->replace($products, $data, ['%d','%s','%s','%d','%f','%f','%d','%d','%s','%d','%d','%f','%d','%d','%s','%s']);
    if ($replace_result === false) {
        evazar_product_index_mark_sync_failure($post_id, 'product_row_replace_failed');
        error_log('[EVazar Product Index] Product-index REPLACE failed for product ID ' . $post_id . '.');
        return false;
    }

    // ابتدا رابطه‌های فعلی را اضافه می‌کنیم؛ فقط پس از موفقیت INSERT رابطه‌های منسوخ حذف می‌شوند.
    // در صورت خطای درج، دسته‌های قبلی باقی می‌مانند و ایندکس خالی نمی‌شود.
    $normalized_category_ids = array_values(array_unique(array_filter(array_map('absint', (array) $category_ids))));
    if ($normalized_category_ids) {
        $values = [];
        $placeholders = [];
        foreach ($normalized_category_ids as $cid) {
            $placeholders[] = '(%d,%d)';
            $values[] = $post_id;
            $values[] = $cid;
        }
        $insert_result = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO {$categories} (product_id, category_id) VALUES " . implode(',', $placeholders),
            ...$values
        ));
        if ($insert_result === false) {
            evazar_product_index_mark_sync_failure($post_id, 'category_index_insert_failed');
            error_log('[EVazar Product Index] Category-index insert failed for product ID ' . $post_id . '; existing category relationships were preserved.');
            return false;
        }

        $not_in = implode(',', array_fill(0, count($normalized_category_ids), '%d'));
        $delete_sql = $wpdb->prepare(
            "DELETE FROM {$categories} WHERE product_id=%d AND category_id NOT IN ({$not_in})",
            ...array_merge([$post_id], $normalized_category_ids)
        );
        $delete_result = $wpdb->query($delete_sql);
    } else {
        // خالی بودن آرایه تنها پس از موفقیت خواندن taxonomy تایید شده است.
        $delete_result = $wpdb->delete($categories, ['product_id'=>$post_id], ['%d']);
    }
    if ($delete_result === false) {
        evazar_product_index_mark_sync_failure($post_id, 'category_index_cleanup_failed');
        error_log('[EVazar Product Index] Stale category-index cleanup failed for product ID ' . $post_id . '; current category relationships were kept.');
        return false;
    }
    evazar_product_index_clear_sync_failure($post_id);
    do_action('evazar_product_index_synced', $post_id);
    return true;
}

add_action('set_object_terms', function($object_id, $terms, $tt_ids, $taxonomy) {
    if (get_post_type($object_id) === 'evazar_product' && in_array($taxonomy, ['evazar_category','evazar_brand'], true)) {
        evazar_product_index_sync((int)$object_id);
    }
}, 20, 4);
add_action('save_post_evazar_product', function($post_id, $post, $update) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (wp_is_post_revision($post_id)) return;
    evazar_product_index_sync((int)$post_id);
}, 20, 3);

function evazar_product_index_backfill_batch($limit = 250) {
    global $wpdb;
    $products = evazar_product_index_table();
    $categories = evazar_product_category_index_table();

    // Cheap checks every batch; full dbDelta runs only if version or table state requires it.
    $products_exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($products))) === $products);
    $categories_exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($categories))) === $categories);
    if (get_option('evazar_product_index_db_version') !== EVAZAR_PRODUCT_INDEX_DB_VERSION || !$products_exists || !$categories_exists) {
        evazar_product_index_ensure_tables();
    }

    $ids = $wpdb->get_col($wpdb->prepare(
        "SELECT p.ID
         FROM {$wpdb->posts} p
         LEFT JOIN {$products} i ON i.product_id=p.ID AND i.index_version=%s
         WHERE p.post_type='evazar_product' AND p.post_status='publish'
           AND (
             (i.product_id IS NULL AND NOT EXISTS (
                SELECT 1 FROM {$wpdb->postmeta} pm_failed
                WHERE pm_failed.post_id=p.ID AND pm_failed.meta_key='_evazar_product_index_sync_error'
             ))
             OR EXISTS (
                SELECT 1 FROM {$wpdb->postmeta} pm_sync_err
                WHERE pm_sync_err.post_id=p.ID AND pm_sync_err.meta_key='_evazar_product_index_sync_error'
                  AND COALESCE((SELECT CAST(pm_retry.meta_value AS UNSIGNED) FROM {$wpdb->postmeta} pm_retry WHERE pm_retry.post_id=p.ID AND pm_retry.meta_key='_evazar_product_index_sync_next_retry' ORDER BY pm_retry.meta_id ASC LIMIT 1),0) <= %d
                  AND COALESCE((SELECT CAST(pm_tries.meta_value AS UNSIGNED) FROM {$wpdb->postmeta} pm_tries WHERE pm_tries.post_id=p.ID AND pm_tries.meta_key='_evazar_product_index_sync_attempts' ORDER BY pm_tries.meta_id ASC LIMIT 1),0) < 5
             )
           )
         ORDER BY p.ID ASC LIMIT %d",
        EVAZAR_PRODUCT_INDEX_DB_VERSION, time(), max(1, min(500, (int) $limit))
    ));
    if ($wpdb->last_error !== '') {
        error_log('[EVazar Product Index] Backfill selection failed; no rows will be synced in this batch.');
        return 0;
    }
    $synced = 0;
    foreach ((array) $ids as $id) {
        if (evazar_product_index_sync((int) $id)) $synced++;
    }
    return $synced;
}
add_action('evazar_product_index_backfill', function() { evazar_product_index_backfill_batch(250); });

/**
 * Canonical Related Product Engine.
 *
 * Theme should only render the returned IDs. Product selection is based on the
 * Core Product Index so availability and ranking have one source of truth.
 */
function evazar_get_related_product_ids($post_id, $limit = 4, $hide_outofstock = true, $offset = 0) {
    global $wpdb;

    $post_id = absint($post_id);
    $limit = max(1, min(50, (int)$limit));
    // Offset represents the position in the final ranked list, not a SQL candidate window.
    // Keep pagination bounded so a public AJAX request cannot force a deep unbounded scan.
    $offset = max(0, (int)$offset);
    if (!$post_id || get_post_type($post_id) !== 'evazar_product') return [];
    if (!evazar_product_index_exists()) return [];
    $max_ranked_candidates = 500;
    if ($offset >= $max_ranked_candidates) return [];

    // A short-lived per-product cache avoids re-running the aggregate/sort for every
    // scroll batch. Common visits cache 120 IDs; the window expands only when a visitor
    // scrolls deeper. This bounds both SQL output and transient size for high traffic.
    $cache_key = 'evazar_rel_rank_' . md5($post_id . ':' . ($hide_outofstock ? '1' : '0'));
    $required_count = min($max_ranked_candidates, $offset + $limit);
    $cache_payload = get_transient($cache_key);
    if (is_array($cache_payload) && isset($cache_payload['ids'], $cache_payload['complete']) && is_array($cache_payload['ids'])) {
        $cached_ids = array_values(array_unique(array_filter(array_map('absint', $cache_payload['ids']))));
        $cache_complete = !empty($cache_payload['complete']);
        if ($cache_complete || count($cached_ids) >= $required_count) {
            return array_slice($cached_ids, $offset, $limit);
        }
    }
    $candidate_limit = min($max_ranked_candidates, max(120, $offset + $limit + 12));

    $products = evazar_product_index_table();
    $categories = evazar_product_category_index_table();
    $posts = $wpdb->posts;

    $current_category_ids = wp_get_object_terms($post_id, 'evazar_category', ['fields'=>'ids']);
    if (is_wp_error($current_category_ids)) $current_category_ids = [];
    $current_category_ids = array_values(array_unique(array_filter(array_map('absint', (array)$current_category_ids))));

    $deepest_category_id = 0;
    $deepest_depth = -1;
    foreach ($current_category_ids as $category_id) {
        $depth = count((array)get_ancestors($category_id, 'evazar_category'));
        if ($depth > $deepest_depth) {
            $deepest_depth = $depth;
            $deepest_category_id = $category_id;
        }
    }

    $exact_category_ids = $current_category_ids;
    if ($deepest_category_id > 0) {
        $children = get_term_children($deepest_category_id, 'evazar_category');
        if (!is_wp_error($children)) $exact_category_ids = array_merge($exact_category_ids, array_map('absint', (array)$children));
    }
    $exact_category_ids = array_values(array_unique(array_filter(array_map('absint', $exact_category_ids))));

    $branch_category_ids = [];
    if ($deepest_category_id > 0) {
        $deepest_term = get_term($deepest_category_id, 'evazar_category');
        $branch_root_id = ($deepest_term && !is_wp_error($deepest_term) && !empty($deepest_term->parent))
            ? absint($deepest_term->parent)
            : $deepest_category_id;
        if ($branch_root_id > 0) {
            $branch_category_ids[] = $branch_root_id;
            $branch_children = get_term_children($branch_root_id, 'evazar_category');
            if (!is_wp_error($branch_children)) $branch_category_ids = array_merge($branch_category_ids, array_map('absint', (array)$branch_children));
        }
    }
    $branch_category_ids = array_values(array_unique(array_filter(array_map('absint', $branch_category_ids))));

    $brand_id = 0;
    $brand_terms = wp_get_object_terms($post_id, 'evazar_brand', ['fields'=>'ids']);
    if (!is_wp_error($brand_terms) && !empty($brand_terms)) $brand_id = absint($brand_terms[0]);
    if ($brand_id <= 0) {
        $brand_name = trim((string)get_post_meta($post_id, '_evazar_brand', true));
        if ($brand_name !== '') {
            $brand_term = get_term_by('name', $brand_name, 'evazar_brand');
            if (!$brand_term) $brand_term = get_term_by('slug', sanitize_title($brand_name), 'evazar_brand');
            if ($brand_term && !is_wp_error($brand_term)) $brand_id = absint($brand_term->term_id);
        }
    }

    $score_parts = ['0'];
    $score_params = [];

    if ($exact_category_ids) {
        $ph = implode(',', array_fill(0, count($exact_category_ids), '%d'));
        $score_parts[] = "CASE WHEN SUM(CASE WHEN cat_idx.category_id IN ({$ph}) THEN 1 ELSE 0 END) > 0 THEN 120 ELSE 0 END";
        foreach ($exact_category_ids as $id) $score_params[] = $id;
    }
    if ($current_category_ids) {
        $ph = implode(',', array_fill(0, count($current_category_ids), '%d'));
        $score_parts[] = "LEAST(60, SUM(CASE WHEN cat_idx.category_id IN ({$ph}) THEN 25 ELSE 0 END))";
        foreach ($current_category_ids as $id) $score_params[] = $id;
    }
    if ($branch_category_ids) {
        $ph = implode(',', array_fill(0, count($branch_category_ids), '%d'));
        $score_parts[] = "CASE WHEN SUM(CASE WHEN cat_idx.category_id IN ({$ph}) THEN 1 ELSE 0 END) > 0 THEN 25 ELSE 0 END";
        foreach ($branch_category_ids as $id) $score_params[] = $id;
    }
    if ($brand_id > 0) {
        $score_parts[] = 'CASE WHEN idx.brand_id = %d THEN 70 ELSE 0 END';
        $score_params[] = $brand_id;
    }

    $where = [
        "p.post_type = 'evazar_product'",
        "p.post_status = 'publish'",
        $wpdb->prepare('p.ID <> %d', $post_id),
    ];
    if ($hide_outofstock) $where[] = 'idx.stock_status = 1';

    $score_sql = '(' . implode(' + ', $score_parts) . ')';
    $sql = "SELECT idx.product_id, {$score_sql} AS relevance_score, idx.post_date
            FROM {$products} idx
            INNER JOIN {$posts} p ON p.ID = idx.product_id
            LEFT JOIN {$categories} cat_idx ON cat_idx.product_id = idx.product_id
            WHERE " . implode(' AND ', $where) . "
            GROUP BY idx.product_id
            ORDER BY relevance_score DESC, idx.post_date DESC, idx.product_id DESC
            LIMIT %d";

    // Retrieve the ranked window once (at most 500 IDs), cache it briefly, and apply
    // page offsets in PHP. Older three-argument callers still receive the first page.
    $rows = $wpdb->get_results($wpdb->prepare($sql, ...array_merge($score_params, [$candidate_limit])));
    if ($wpdb->last_error !== '') {
        error_log('[EVazar Product Index] Related-product ranking query failed; returning no related IDs.');
        return [];
    }

    $ranked_ids = [];
    foreach ((array)$rows as $row) {
        $id = absint($row->product_id ?? 0);
        if ($id > 0 && $id !== $post_id) $ranked_ids[] = $id;
    }
    $ranked_ids = array_values(array_unique($ranked_ids));
    $cache_payload = [
        'ids' => $ranked_ids,
        // Fewer rows than the requested SQL window proves there are no more candidates.
        'complete' => count((array)$rows) < $candidate_limit,
    ];
    set_transient($cache_key, $cache_payload, 12 * HOUR_IN_SECONDS);

    return array_slice($ranked_ids, $offset, $limit);
}

function evazar_product_index_exists() {
    global $wpdb;
    static $exists = null;
    if ($exists !== null) return $exists;
    $table = evazar_product_index_table();
    $exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table);
    return $exists;
}
