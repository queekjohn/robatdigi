# EVazar Core 2.9.77 — Purpose-Isolated Worker Cooldowns

- Price/stock lookups now use a dedicated `stock_sync` cooldown namespace. A source/import/AI-proxy failure that pauses a Worker in its own request channel no longer blocks scheduled price/stock synchronization.
- Product import source requests and the legacy OpenAI proxy use explicit channel names; other existing callers preserve the legacy default namespace.
- Responses explicitly marked `X-Evazar-Error-Scope: source` are handled as upstream-source failures before generic HTTP 429 cooldown logic, so a source-side 429 does not mark a healthy Worker unavailable.
- Cloudflare daily-account budget checks and atomic request accounting remain shared intentionally because they protect the actual account-wide Workers request allowance. The isolation is for transient/error cooldowns, not a bypass of Cloudflare limits.
- Existing safe stock-sync behavior remains: if both Worker endpoints actually return errors in the stock-sync channel, the batch defers, preserves saved price/stock, and retries instead of treating the product as unavailable.
- Core-only release. Worker JavaScript remains 1.13.11; no DB schema migration or setting changes are required.

Validation is local/static only; no live WordPress/Cloudflare requests were performed.
