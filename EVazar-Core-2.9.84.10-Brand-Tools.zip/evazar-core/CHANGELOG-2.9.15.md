# EVazar Core 2.9.15 — Product Specification Normalization

## Changes

- The direct Digikala API fallback now reads attributes from every `specifications` group, not only `specifications[0]`.
- Worker-provided and direct-API specifications now pass through the same conservative normalization path.
- Common specification labels are standardized (for example `RAM` / `حافظهٔ رم` → `حافظه رم`, and equivalent screen-size labels → `اندازه صفحه‌نمایش`). Unknown labels are retained after safe whitespace and Arabic/Persian character normalization.
- Exact duplicate rows are removed only when both normalized label and value match. Conflicting values for the same label are preserved rather than guessed or discarded.
- Technical values, numbers, units, model identifiers, and meaningful hyphens are not rewritten by an AI model. Whitespace and Arabic/Persian character forms are normalized only.
- The import path no longer uses a global `str_replace('- ', '', ...)` on the complete specification text, which could remove meaningful hyphens from values.
- If the latest source response contains no usable specifications, an existing non-empty specification list is preserved instead of being erased.

## Scope

- Importer and plugin version only; no database schema changes.
- No changes to image routing, queue behavior, product identity, pricing, AI model selection, theme, or Worker code.
- Specification normalization happens on new imports and products that are imported/updated again. Existing products are not bulk-migrated by this release.
