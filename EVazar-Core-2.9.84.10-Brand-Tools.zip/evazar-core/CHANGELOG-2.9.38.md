# EVazar Core 2.9.38 — Dashboard import overview and related-ranking cache

- Adds a lightweight, administrator-only widget to the WordPress main Dashboard with queued/pending/processing/completed/failed counts, published product count, successful imports in the last hour/24 hours/7 days, and last successful import time.
- Reads the existing `evazar_import_queue` and `evazar_import_history` tables; no new table or schema migration is introduced.
- Queue states are aggregated in one SQL query. Import-history statistics use the existing `imported_at` index and a 30-second transient cache; successful imports and administrative queue actions invalidate the cache.
- Optimizes related-product infinite scroll: ranked product IDs are cached briefly (60 seconds), normally in a 120-ID window that expands only when the visitor scrolls farther, up to the existing 500-candidate safety ceiling.
- Pagination offsets now slice the final deterministic ranked ID list, so each batch maps to the expected page and repeated requests do not re-run the scoring query while the short-lived cache is valid.
- No Worker changes, product-data changes, taxonomy edits, or database schema changes.
