# QA — EVazar Core 2.9.50 / Worker 1.13.7 (maintenance rebuild)

## Fixes reviewed
- Retry generation is preserved in the signed internal payload and restored in the internal child request; the batch identity hashes each queue item's `retries` value.
- When a completed batch response is invalid, the retry increment changes the next batch/request ID and avoids replaying the same cached malformed response indefinitely.
- In sequential balanced mode, `AI_BATCH_OUTPUT_INVALID` only defers the failed chunk and the loop continues to attempt other planned chunks using the next eligible Worker. It no longer increments retry counters for unsent chunks or stops the run merely because one HTTP-200 response was malformed.
- Parallel child responses preserve `AI_BATCH_OUTPUT_INVALID` through parent queue finalization instead of masking it as generic `AI_BATCH_FAILED`; retry generation still increments, so the next attempt has a new request ID.
- A Worker-scoped quota/rate/temporary-unavailable/busy error now defers only the affected chunk and continues with the remaining chunks when other Workers still qualify. If no eligible Worker remains, the whole unsent tail is deferred. Global quota pauses, ledger/auth failures and ambiguous outcomes remain fail-closed.
- Parser validation reason is included in the visible `batch_output_invalid` log message, bounded and sanitized; raw model response and secrets are not logged.
- Automatic one-product Gemini requests remain blocked in Core and Worker; explicit manual single-product test path and taxonomy SEO purpose remain separate.
- Worker-aware allocation is enabled automatically for Gemini-only batching when >=2 Worker URLs are configured. cURL-multi is used if available; otherwise sequential balanced assignment is used.
- `batch_dispatch_plan`, `batch_dispatch_wave`, and `batch_worker_assigned` describe capacity and selected hosts.
- Queue runtime is extended before sequential product preparation; if the hosting provider still reports a PHP execution limit under 180 seconds, one run is conservatively capped at one complete AI batch. The effective limit and pre/post-guard capacity are logged.

## Checks
- `php -l`: all plugin PHP files passed.
- Local-time display regression check: Gemini event `time` and `until` are formatted from stored Unix timestamps with `wp_date()` and the WordPress configured timezone; the test harness passed for UTC, `America/New_York` during daylight and standard time, `America/Los_Angeles`, and `Asia/Tehran`. Pacific-specific quota reset labels remain explicitly Pacific.
- `node --check`: standalone Worker passed.
- Worker code embedded in Core matches standalone Worker 1.13.7 byte-for-byte.
- Archive integrity (`unzip -t`) passed for Core, Worker, and release bundle.
- Exhaustive source-extracted batch partition test: lengths 0–150 and batch sizes 2–10; no item loss/duplication and no chunk outside 2–10; singleton rows are deferred.
- Static retry-generation and payload round-trip assertions passed.
- Static sequential invalid-output branch check passed: only current chunk finalizes, offset advances, loop continues.
- Static policy checks passed for the no-auto-single rule.
- Capacity arithmetic examples passed: queue limit 50, size 10, eligible Workers 3 => 30 products / 3 chunks; 2 => 20 / 2; 1 => 10 / 1; queue limit 10 => 10 / 1.

## Limits
These are source-level/local checks, not production integration tests. Actual number of Workers used depends on saved WordPress settings, active cooldown/locks, and whether cURL-multi is available on the host. Use `batch_dispatch_plan` to verify the configured/effective count and the `batch_dispatch_wave` or `batch_worker_assigned` events to see actual allocation. No live Gemini response was generated during QA.
