# Safe upgrade — EVazar Core 2.9.23

1. Back up the current Core plugin and database.
2. Install `EVazar-Core-2.9.23-Source-Output-Guard.zip` through WordPress Plugins → Add New → Upload Plugin.
3. Do not run mass taxonomy processing. Existing descriptions are not rewritten merely by plugin upgrade.
4. Test one category/brand using the single-term processor and inspect the result before any broader processing.
