# QA report — EVazar Core 2.9.16 / Worker 1.11.9

## Static checks

- Worker response contract retained: `success`, `version`, `product.specs` entries with `title` and `value`.
- Core bundled Worker source is identical to standalone Worker source.
- Worker code reports version 1.11.9; product cache namespace bumped to v1.11.9.
- PHP syntax checks and Worker JavaScript syntax checks passed.
- Focused normalization tests passed for all groups, `title/name`, `values/value`, empty `values` fallback, empty `title`/`value` with `name`/`values` fallback, nested array values, duplicate removal, conflicting values retention, Persian label normalization, scalar/array values, and values ending in a hyphen.

## Not performed

- Not installed on the live site.
- Not deployed to Cloudflare.
- No live Digikala API or live product-page test was run in this environment.

## Deployment verification required

Deploy Worker 1.11.9 first, verify version header and product JSON, then install Core 2.9.16 and re-import one representative product before resuming bulk imports.
