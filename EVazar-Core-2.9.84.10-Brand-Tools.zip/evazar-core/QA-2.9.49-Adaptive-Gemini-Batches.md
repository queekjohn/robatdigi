# EVazar Core 2.9.49 — QA Report

## Static validation
- All PHP files in the Core package passed `php -l`.
- ZIP integrity passed `unzip -t`.
- Core plugin version header is 2.9.49.
- Worker source was not changed; no Worker redeployment is included.

## Behavior changes
- In parallel product-batch mode, the queue's per-run claim limit is capped at `eligible Worker count × configured products per Gemini request`, also bounded by configured queue batch size and parallelism.
- Eligibility excludes Worker quota cooldowns, rate cooldowns, and active Worker locks. If no Worker is eligible, no queue rows are claimed.
- When a batch receives a response but none of its product outputs pass validation, Core logs safe diagnostic metadata and retries the chunk through queue handling instead of immediately sending one separate Gemini request per product.
- Partial invalid/missing outputs still use the existing per-product fallback for only the affected products.

## Example
With queue batch size 50, AI batch size 10, parallelism 5:
- 5 eligible Workers: up to 50 products claimed for that run.
- 3 eligible Workers: up to 30 products claimed.
- 2 eligible Workers: up to 20 products claimed.
- 1 eligible Worker: up to 10 products claimed.
- 0 eligible Workers: no products claimed.

Remaining products are left pending for the existing follow-up/cron processing.

## Not verified live
- No live WordPress database, production cron, Cloudflare Worker, or Gemini request was run from this environment.
- PHP syntax and archive checks do not establish live behavioral correctness. Test on the production site after backup, watching one controlled batch and the Gemini operations log.
