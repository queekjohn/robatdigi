# QA — EVazar Core 2.9.20 / Worker 1.12.4

## Findings driving this change

The original HTML fetch returned a 13,746-byte Next.js `/routing/` shell with HTTP 200. The user then captured Digikala's exact category+brand products API response, which includes the relevant SEO text under `data.seo.content` and/or `data.category_brand.description`.

## Changes

- Filtered category source pages are queried through the exact category+brand API path first.
- Category slug is translated from public `category-washing-machines` path slug to API `washing-machines` code.
- Response is trusted only if both `data.category.code` and `data.brand.code` exactly match the source URL.
- HTML source-page fallback remains available; parent-category content is never silently substituted.
- Successful-content engine marker remains unchanged so existing AI-generated descriptions are not made stale solely by this source-transport fix.
- No database schema migration or product import/price/image behavior change is included.

## Local verification

- Worker JavaScript syntax check and mock routing tests pass.
- PHP syntax checks pass for plugin PHP files.
- A mocked PHP test executes the shipped Core helper and confirms `category-washing-machines` maps to API code `washing-machines`, SEO text is extracted, and a mismatched brand response is rejected.
- Static checks confirm expected source fields and preservation of exact HTML fallback.
- Core embedded Worker is byte-identical to standalone Worker 1.12.4.

## Live verification still required

1. Deploy Worker 1.12.4 and confirm the dedicated API proxy test returns JSON with matching category and brand codes.
2. Install Core 2.9.20.
3. Run exactly one controlled attempt for the existing `ماشین لباسشویی دوو` term.
4. Verify `_evazar_ai_content_source_method = api_category_brand_seo_content`, `_evazar_ai_content_source_chars > 0`, and inspect the saved rewritten description.
5. Do not run bulk content generation until this passes.
