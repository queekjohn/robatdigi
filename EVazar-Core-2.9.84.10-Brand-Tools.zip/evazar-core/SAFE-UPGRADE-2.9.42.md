# Safe upgrade — EVazar Core 2.9.42

1. Back up the current `evazar-core/` folder and WordPress database.
2. Replace the existing `evazar-core/` folder with this package; preserve that folder name exactly.
3. Do not republish or replace the Cloudflare Worker. The Worker source is unchanged.
4. This release is observability-only: it does not change queue claiming, batch sizes, prompts, response parsing or product saving. No database migration is required.
5. Open Products → Gemini report. The request-purpose and product-count columns should be visible. A genuine five-item batch should show purpose `بازنویسی دسته‌ای محصولات` and product count `5`; the DKP column will list member DKPs for requests logged after this upgrade.
6. Old events can show purpose/count if previously stored by Core 2.9.40/2.9.41, but cannot show DKPs because the old logger discarded the DKP list.

No live WordPress production test or real Gemini request was performed during package validation.
