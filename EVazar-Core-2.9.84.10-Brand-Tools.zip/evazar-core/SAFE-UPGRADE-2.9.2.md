# Safe upgrade — EVazar Core 2.9.2

1. Back up the current Core plugin folder and database. No schema change is made by this release.
2. Replace the existing `evazar-core/` folder; do not install a version-suffixed folder.
3. Deploy the bundled `worker/digikala-worker.js` (Worker 1.11.6) to every Cloudflare Worker endpoint used by EVazar. Keep existing secrets and route/domain bindings unchanged.
4. Purge only `img.evazar.ir` image cache if stale negative responses persist; do not purge unrelated page/product caches by default.
5. Test a product card, product gallery, responsive image, lazy-loaded image, and image loaded after archive infinite scroll. Verify a CDN failure affects only that image and direct retry does not loop.
6. Roll back code/Worker version if any unrelated image/gallery behavior changes.
