# QA — EVazar Core 2.9.68

- Plugin header version: 2.9.68.
- Root cause confirmed in 2.9.67: queue shutdown scheduled a one-off follow-up about 15 seconds later when pending products remained, bypassing the configured recurring cron interval.
- Both recurring cron and follow-up handlers now share `evazar_queue_next_auto_run_at` and automatic runs are gated against it.
- Manual queue runs remain available and update the next allowed automatic run time.
- On first admin initialization after upgrade, old recurring/follow-up events are cleared and the recurring event is re-created with the saved interval.
- Local PHP syntax checks and ZIP integrity checks required before release.
- Not tested against the production WordPress site or live Gemini Workers.
