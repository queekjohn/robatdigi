# Safe upgrade — EVazar Core 2.9.4

1. Back up the active Core plugin folder and current Cloudflare Worker source.
2. Replace the plugin directory using the folder name `evazar-core` (do not create a version-suffixed directory).
3. Deploy `worker/digikala-worker.js` version 1.11.8 to each configured Worker that serves the EVazar image proxy. The Core bundle and standalone Worker ZIP contain identical source.
4. Preserve all existing custom-domain/route bindings and Secrets.
5. Verify a failing image request's `X-Evazar-Worker-Version` header shows `1.11.8`. For a persistent non-image origin response, inspect `X-Evazar-Origin-Status` and `X-Evazar-Origin-Content-Type`.
6. Test a normal image, one isolated CDN failure, a 200 HTML origin response, product gallery, responsive `srcset`, lazy-loaded images and images added via infinite scroll.
7. Roll back Core and Worker together if the production smoke test shows regressions.
