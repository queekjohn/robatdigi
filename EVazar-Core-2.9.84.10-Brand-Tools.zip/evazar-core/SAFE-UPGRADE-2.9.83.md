# Safe upgrade — Core 2.9.83

Replace the `evazar-core` plugin folder with this version. No Worker or theme update is required. On the first WordPress request, a one-time migration marks existing retry rows with known missing-source errors as terminal `done` skips. It does not change Gemini/provider retry rows or valid descriptions.

Expected log when any rows are migrated: `taxonomy_source_less_marked_done`. New deterministic source-missing terms should show `skipped_no_source` or `skipped_no_source_url` and should not recur in retry.
