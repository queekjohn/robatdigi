# QA — EVazar Core 2.9.52 / Worker 1.13.7

## Source checks
- Plugin header version is `2.9.52`; parallel request User-Agent updated to `EVazar-Core-Parallel-Batch/2.9.52`.
- The exact Worker 1.13.7 auth-guard response `{"success":false,"message":"Unauthorized."}` with HTTP 401 is classified as `worker_auth_failed`.
- That branch logs a Core/Worker internal-token mismatch diagnosis, sets a five-minute Worker-scoped cooldown, and never labels this exact pre-upstream response as a Gemini API-key rejection.
- Assigned-worker dispatch defers the chunk and terminally marks the request ID as deferred; unassigned dispatch retains the same lease/request ID and continues only because the exact Worker auth guard proves no Gemini call occurred.
- `gemini_worker_auth_failed` is recognized by the queue pause/defer logic and the Worker-scoped pause handling.
- The Worker source remains unchanged at 1.13.7.

## Scope limitation
No WordPress production site, live Cloudflare Worker, Gemini API call, or Cloudflare/Gemini console was accessed. Actual token equality and deployed behavior must be confirmed on the user's configuration.
