# QA — 2.9.23 Source Output Guard

1. Back up Core and the database before installation.
2. Confirm the product prompt field and product rewriting path are unchanged.
3. Run a single taxonomy test only; do not launch the batch processor.
4. Verify the public-facing term description contains only returned HTML content, never source-block labels.
5. Verify an AI response containing the full source verbatim is rejected with status `error_ai_source_echo`, preserving the old description.
6. Verify a normal rewritten response is stored as usual.
