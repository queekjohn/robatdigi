# EVazar Core — Consolidated Historical Changelog

> Historical notes consolidated from older per-version changelog files. The recent Core release changelogs remain as separate files. This document-only consolidation does not change executable plugin or Worker code.


<!-- consolidated from worker/CHANGELOG-1.9.9.md -->

# EVazar Worker 1.9.9

- Added controlled retries for transient Digikala image-origin/network failures.
- Added status-aware cache TTLs so 5xx responses are not cached as image assets.
- Added CDN cache-control metadata with stale-if-error guidance.
- Added upstream cache diagnostics via `X-Evazar-CDN-Cache`.
- Kept the local Cache API as a fast per-edge L1 while retaining `fetch()` caching for the origin subrequest.


---

<!-- consolidated from CHANGELOG-2.8.61.md -->

# EVazar Core 2.8.61
- Product Index: price, stock, brand, SKU/DKP, views, rating and satisfaction index tables.
- Incremental Product Index backfill: 250 products per scheduled run.
- Import and live-price/stock sync update the product index.
- Stock sync remains 50 products every 5 minutes and now correctly passes force-fresh to the Worker.
- OpenAI is Worker-first when Cloudflare Worker + internal token are configured; local OpenAI key is optional in this mode.


---

<!-- consolidated from CHANGELOG-2.8.62.md -->

# EVazar Core 2.8.62
- Product Index migration now recreates tables when missing even if the stored DB version is already current.
- Backfill cron is re-ensured on normal init so plugin updates do not depend on activation hooks.


---

<!-- consolidated from CHANGELOG-2.8.63.md -->

# EVazar Core 2.8.63

- Persist Worker `availability_source` in `_evazar_availability_source`.
- Product Index DB bumped to 1.1.0 with an `availability_source` column.
- Product Index `stock_status` now derives from current price > 0, with `explicit_unavailable` as a hard override.
- Initial imports and live stock/price sync store the availability source for consistent filtering and sorting.


---

<!-- consolidated from CHANGELOG-2.8.64.md -->

# EVazar Core 2.8.64

- Added automatic queue retry with exponential backoff (up to 4 automatic retries; 5th failure remains failed).
- Added `next_attempt_at` to queue items so failed/stuck jobs do not retry immediately and create request bursts.
- Improved stale-claim recovery: stuck jobs are requeued safely and eventually marked failed instead of looping forever.
- Queue claims now respect `next_attempt_at`.
- Manual retry resets retry scheduling state.
- Added price/stock sync reliability metadata: `_evazar_price_sync_status`, `_evazar_price_sync_failed_at`, `_evazar_price_sync_error`, `_evazar_price_sync_last_success`.
- A failed live price inquiry no longer overwrites valid existing price/stock data.
- Preserved the existing Theme → Core → Worker contract; no Worker change required.


---

<!-- consolidated from CHANGELOG-2.8.65.md -->

# EVazar Core 2.8.65

- Extended `evazar_cdn_image_url()` with optional size variants for zero-host-storage image delivery.
- Added safe Digikala OSS resize URL generation for 120/160/360/800px image variants.
- Existing URLs remain unchanged when no size is requested.
- Synchronized the embedded Cloudflare Worker with Worker 1.9.9.


---

<!-- consolidated from CHANGELOG-2.8.66.md -->

# EVazar Core 2.8.66

- Preserves existing Digikala OSS `x-oss-process` transformations when generating CDN image URLs.
- Size variants are only added when the source URL has no existing image-processing directive.
- Restores the previous archive/product visual framing while keeping zero-host-storage CDN delivery.
- Keeps the embedded Cloudflare Worker at 1.9.9.


---

<!-- consolidated from CHANGELOG-2.8.67.md -->

# EVazar Core 2.8.67

- Replaces fixed 24-hour Gemini quota cooldown with Google's documented daily RPD reset at 00:00 Pacific time.
- Treats `quota_exceeded`/daily-quota 429 separately from transient RPM/TPM 429 errors.
- Prevents queue claims in Gemini-only mode while all Gemini Workers are in quota cooldown.
- When a batch encounters a Gemini daily-quota stop, unprocessed claimed items are returned to `pending` without increasing retry count and deferred until the next quota reset.
- Cloudflare Worker code is unchanged.


---

<!-- consolidated from CHANGELOG-2.8.68.md -->

# EVazar Core 2.8.68

- Adds a post-reset Gemini quota Health Check.
- After a daily quota cooldown expires, only one real Gemini request is allowed to probe whether Google has actually released the quota.
- Concurrent queue runs are blocked from sending duplicate post-reset probe requests.
- If the probe still receives a daily-quota 429, the Gemini cooldown is restored instead of continuing requests.
- If the probe succeeds, the current reset cycle is marked healthy and the queue continues normally.
- If the probe fails for a temporary non-quota reason, the probe lock is released so a later queue run can retry without creating a false daily cooldown.
- Cloudflare Worker code is unchanged.


---

<!-- consolidated from CHANGELOG-2.8.69.md -->

# EVazar Core 2.8.69

- واردات دستی «یک محصول» از صفحه مدیریت از Cooldown سهمیه Gemini صف خودکار مستثنی شد.
- این مسیر یک درخواست واقعی به Gemini/Worker ارسال می‌کند تا کاربر بتواند بعد از Reset وضعیت سهمیه را عملاً تست کند.
- اگر درخواست دستی موفق شود، Cooldown همان Worker و Cooldown سراسری صف پاک می‌شود و صف در اجرای بعدی می‌تواند ادامه دهد.
- اگر درخواست دستی با Daily Quota 429 مواجه شود، همان سازوکار تشخیص و Cooldown قبلی حفظ می‌شود.
- Health Check و منطق Cron/صف خودکار بدون تغییر باقی مانده‌اند.
- Cloudflare Worker هیچ تغییری نکرده است.


---

<!-- consolidated from CHANGELOG-2.8.70.md -->

# EVazar Core 2.8.70

- Gemini model name is normalized before every Worker request.
- Fixed malformed model names such as `-3.5-flash-lite` and `3.5-flash-lite`.
- Updated Gemini settings to use currently supported model IDs, with `gemini-3.5-flash-lite` as the default.
- Removed shut-down Gemini 2.0/1.5 options from the settings UI.
- Cloudflare Worker updated to v1.10.0 with the same defensive model normalization.
- Gemini quota/cooldown and manual single-product bypass logic preserved.


---

<!-- consolidated from CHANGELOG-2.8.72.md -->

# Evazar Core 2.8.72

- Product-page live inquiry now forces a fresh Worker/Digikala check, bypassing the local 90-second inquiry transient.
- Live availability detection checks other sellable variants when `default_variant` is incomplete.
- Explicit unavailable signals always override positive/fallback signals.
- Bundled Cloudflare Worker updated to 1.11.1.
- Plugin header version synchronized to 2.8.72.


---

<!-- consolidated from CHANGELOG-2.8.73.md -->

# Evazar Core 2.8.73

- Live Inquiry now performs a lightweight per-product Product Index synchronization after a successful live check.
- Only price, old price, discount, stock status, availability source, and stock-check timestamp are updated in the existing index row.
- No Product Index rebuild and no additional Digikala/Worker request are performed for this synchronization.
- If the product is missing from the index, only that single product is fully indexed as a fallback.
- Preserves the existing 2.8.72 live-availability detection and bundled Worker changes.


---

<!-- consolidated from CHANGELOG-2.8.74.md -->

# EVazar Core 2.8.74

- Live product inquiry now uses `fresh=1` on the public product-page AJAX request.
- Cloudflare Worker bumped to `1.11.2`; fresh product requests bypass the Worker Product Cache and use a new cache namespace.
- Added `X-Evazar-Fresh` and clearer cache diagnostics to product responses.
- Preserved the lightweight per-product Product Index synchronization from 2.8.73.
- No full Product Index rebuild and no extra Digikala request is performed for the index sync itself.


---

<!-- consolidated from CHANGELOG-2.8.75.md -->

# EVazar Core 2.8.75

- Added a canonical Related Product Engine backed by the Product Index.
- Related ranking uses category, branch, brand and publication date without per-candidate postmeta queries.
- Out-of-stock filtering uses the Core Product Index `stock_status` value.
- Theme integration is ID-only: the Theme renders products while Core owns recommendation logic.


---

<!-- consolidated from CHANGELOG-2.8.76.md -->

# EVazar Core 2.8.76

- Added a database-level unique constraint for queue `dkp` values, with a safe one-time duplicate cleanup before the index is created.
- `/existing-dkps` now separates imported products, active queue items, completed queue records and failed/retryable items, while keeping the legacy `dkps` field for Harvester 1.6.0 compatibility.
- Failed queue records are automatically requeued when their DKP is harvested again; completed records are only reactivated when the corresponding product is not actually present in WordPress.
- Queue ingest now checks each batch in bulk and no longer relies on stale per-DKP queue caches.
- Concurrent queue-ingest requests cannot create duplicate queue rows once the unique index is active.


---

<!-- consolidated from CHANGELOG-2.8.77.md -->

# EVazar Core 2.8.77

- Added browser-side image failover for the zero-host-storage image architecture.
- Normal path remains `img.evazar.ir` / Cloudflare Worker; the first failed Evazar CDN image automatically switches the page to `dkstatics-public.digikala.com`.
- Failover also rewrites `src`, `srcset` and common lazy-loading attributes so lazy-loaded and responsive images do not switch back to the failed CDN path.
- A short `sessionStorage` cooldown keeps subsequent pages on direct Digikala images after a detected CDN path failure, then automatically returns to the normal proxy path after 10 minutes.
- No Cloudflare Worker change is required for this client-side failover.
- Virtual EVazar thumbnails now pass through the Evazar CDN helper so they participate in the same failover architecture.


---

<!-- consolidated from CHANGELOG-2.8.78.md -->

# EVazar Core 2.8.78

- Image failover now switches only the image that actually failed instead of rewriting every image on the page.
- Removed the document-wide MutationObserver from the failover path to reduce main-thread and network churn on image-heavy pages.
- Existing pages can still use a short sessionStorage direct-CDN cooldown, but it rewrites only the images already present in the DOM.
- Removed stopImmediatePropagation from the image error handler so other legitimate image handlers are not interrupted.
- Preserved the zero-host-storage architecture and the direct Digikala fallback.


---

<!-- consolidated from CHANGELOG-2.8.79.md -->

# EVazar Core 2.8.79

- Image failover now switches immediately only the image that actually failed.
- Removed the previous Worker retry race from the browser failover path.
- Critical/high-priority images now have a light timeout watchdog: on mobile the Direct CDN fallback starts after 2.2s of an unresolved CDN request; desktop uses 3.2s.
- Direct CDN mode is persisted with a 10-minute cookie only after a Direct CDN image successfully loads.
- Subsequent page renders can start directly from DigiKala CDN without waiting for DOMContentLoaded.
- Direct CDN failure clears the temporary direct mode.
- Zero Host Storage architecture is preserved.


---

<!-- consolidated from CHANGELOG-2.8.80.md -->

# EVazar Core 2.8.80

- Restored page-wide browser image failover: the first real `img.evazar.ir` image failure or active-load timeout switches all current-page product images to `dkstatics-public.digikala.com`.
- Added a 10-minute Direct CDN mode with a real image probe against the normal `img.evazar.ir` path at the end of each window.
- Probe success clears Direct Mode for subsequent pages and notifies the product gallery; probe failure renews Direct Mode for another 10 minutes.
- No browser-side `evazar_retry=1` is used; the failover cycle runs once per mode window to avoid race conditions and duplicate recovery requests.
- Direct-CDN errors are not used to immediately cancel the 10-minute mode; Theme keeps its final per-image Placeholder recovery.
- Zero-host-storage architecture and the Cloudflare Worker remain unchanged.


---

<!-- consolidated from CHANGELOG-2.8.81.md -->

# EVazar Core 2.8.81

## Image Failover — AJAX / Dynamic Product Grids

- Fixed page-wide image failover for WoodMart AJAX product pagination and product-grid refreshes.
- Added handling for `wdLoadMoreLoadProducts`, `wdShopPageInit`, and `wdArrowsLoadProducts` after dynamically loaded products are inserted.
- Added a lightweight `MutationObserver` for newly inserted image/source nodes.
- When Direct Mode is active, newly injected images are immediately switched to the direct Digikala CDN instead of requesting `img.evazar.ir` first.
- Existing images are also directized when an active 10-minute Direct Mode is detected.
- Kept the existing 10-minute Direct Mode, health probe, and no-browser-retry architecture unchanged.
- Observer watches DOM additions only; it does not observe attribute changes, avoiding mutation loops and unnecessary CPU work.


---

<!-- consolidated from CHANGELOG-2.8.82.md -->

# EVazar Core 2.8.82

- Coordinates image failover with the EVazar theme Infinite Scroll.
- Listens for `evazar:archive-products-appended` and `evazar:archive-results-replaced`.
- Processes dynamically appended archive images immediately without polling.
- Existing Direct Mode, watchdog and MutationObserver behavior remains unchanged.


---

<!-- consolidated from CHANGELOG-2.8.84.md -->

# EVazar Core 2.8.84

- Bundled Cloudflare Worker version synchronized to `1.11.3`; product cache namespace follows the same version.
- Adds a dedicated HTTPS-only Gemini Worker list without repurposing the primary Worker URL used by product import, price/availability and image routes.
- Enforces conservative quota handling: structured Google `QuotaFailure` metadata and explicit daily/per-day signals identify daily quota; RPM/TPM quota IDs are not misclassified. Daily quota stops all Gemini routing until the official Pacific reset. Generic 429 honors `Retry-After` / Google `retryDelay` without shortening a provider-specified wait.
- HTTP 400/401/403/404 configuration/permission errors do not fail over to another Worker. Network and non-503 Worker failures may fail over after bounded retries. An upstream 503 pauses globally and honors `Retry-After` / `retryDelay`; a clear missing-secret 503 is treated as a configuration error.
- Manual testing no longer bypasses provider quota/rate-limit cooldowns.
- Adds a global Core request lock to prevent concurrent Gemini calls and returns affected queue items to pending without incrementing retry counts.
- Adds a bounded operational log that excludes API keys and prompts, and displays recent Gemini status in settings.
- Worker proxy forwards upstream `Retry-After` without exposing other upstream headers.


---

<!-- consolidated from CHANGELOG-2.8.85.md -->

# EVazar Core 2.8.85

- Moves the dedicated Gemini Worker URL list into the Cloudflare Worker settings section so it is visible beside the primary Worker URL.
- Labels the primary Worker URL clearly to avoid accidentally replacing product/import/image routing.
- Keeps Gemini quota cooldown behavior intact; this release does not bypass a genuine Google daily quota.
- No changes to product import, image CDN, product data, or theme files.


---

<!-- consolidated from CHANGELOG-2.8.86.md -->

# EVazar Core 2.8.86

- Adds a dedicated **گزارش Gemini** submenu under the EVazar Products admin menu.
- Makes the report discoverable even when no Gemini events have been recorded yet.
- Displays quota/rate cooldown status and up to 80 operational events without exposing API keys or prompts.
- No changes to product import logic, queue processing, Gemini cooldown policy, image CDN, or theme files.


---

<!-- consolidated from CHANGELOG-2.8.87.md -->

# EVazar Core 2.8.87

- Adds server clock diagnostics (Pacific, UTC, Unix epoch) to the Gemini operations page.
- Displays the next calculated Pacific reset and warns when the host clock is likely behind the quota reset.
- Does not clear cooldowns or change Gemini request/quota behavior.


---

<!-- consolidated from CHANGELOG-2.8.88.md -->

# EVazar Core 2.8.88

- Fixes Gemini multi-Worker quota failover: a daily quota error marks only the affected Worker and continues to the next configured Worker.
- The global daily-quota cooldown is applied only when every configured Gemini Worker is in its own quota cooldown.
- Reconciles a stale global cooldown when at least one configured Worker has no per-Worker quota cooldown, allowing it to be tested.
- Temporary 429/rate-limit cooldown behavior is unchanged and remains global.
- Each configured Worker must have its own valid `GEMINI_API_KEY` secret; WordPress API-key textarea values are not forwarded in Worker mode.


---

<!-- consolidated from CHANGELOG-2.8.89.md -->

# EVazar Core 2.8.89 — Multi-Worker quota audit

- Aligns Gemini compliance documentation with the 2.8.88 per-Worker daily-quota failover implementation.
- Clarifies failover is only for independently authorized Google projects/quotas; multiple keys sharing the same project quota are not independent capacity.
- Worker source remains byte-for-byte compatible with the existing 1.11.3 proxy; it forwards upstream status/body and Retry-After, while Core makes the failover decision.
- No product import, queue, image, theme, or unrelated Worker behavior changed in this audit release.


---

<!-- consolidated from CHANGELOG-2.8.90.md -->

# EVazar Core 2.8.90 — Gemini quota audit logging fix

- Logs local quota-cooldown blocks in the Gemini operational report even when no HTTP request is sent to a Worker.
- Logs when the post-reset quota health probe is already in progress.
- Fixes the request-scoped manual single-product test flag so an explicit manual import can make one real daily-quota check; rate-limit cooldown remains enforced.
- Keeps per-Worker daily-quota failover behavior unchanged and clarifies reset time in the user-facing error.
- No theme, product schema, queue scheduling, image proxy, or unrelated import behavior changed.


---

<!-- consolidated from CHANGELOG-2.8.91.md -->

# EVazar Core 2.8.91 — Gemini quota and worker failover correction

- Separates per-Worker temporary HTTP 429/503 cooldowns from daily quota cooldowns.
- A non-daily HTTP 429 no longer stops the entire Gemini route immediately: the affected Worker is cooled down using Retry-After/retryDelay and the next eligible configured Worker is tried.
- A daily quota 429 cools only the affected Worker; a global daily stop is set only when all configured Workers are individually daily-quota blocked.
- When all eligible Workers are temporarily limited/unavailable, queue items are deferred until the earliest valid retry time without incrementing product retries.
- Adds diagnostic logging of safe Google quota identifiers/status, without storing API keys, prompts, or raw response bodies.
- Logs queue-level quota pauses even when no HTTP request is sent, with event de-duplication to avoid log spam.
- Separates concurrent-request cooldown from provider rate-limit cooldown and corrects queue messages so a concurrency pause is not reported as daily quota exhaustion.
- Migrates a legacy global 429 cooldown to a per-Worker cooldown when the prior operation log identifies the affected endpoint and another configured Worker is available.
- Adds a per-Worker status table to the Gemini operational report.
- No product schema, theme, image proxy, product gallery, or unrelated import behavior changed.


---

<!-- consolidated from CHANGELOG-2.8.92.md -->

# EVazar Core 2.8.92 — Import History (Last 24 Hours)

- Adds a new Import Queue tab: «محصولات وارد شده ۲۴ ساعت گذشته».
- Records successful queue imports in a dedicated indexed history table, storing one most-recent successful import per DKP.
- The history is independent of the current queue status and is preserved when queue items are requeued or the queue itself is cleared.
- Shows the latest 50 items with Digikala URL, successful import time, product ID, and an edit link when the product is available.
- One-time best-effort backfill from current completed queue records updated within the last 24 hours, without guessing older/requeued timestamps.
- Keeps the existing four queue status filters and their processing behavior unchanged.


---

<!-- consolidated from CHANGELOG-2.8.93.md -->

# EVazar Core 2.8.93 — Import History Visibility Fix

- Makes the 24-hour import-history entry prominent near the top of the queue page, with its count even when zero.
- Explicitly ensures the history table during page rendering, so replacing plugin files on an already-active installation does not rely only on the activation hook.
- Keeps the original status filter and history query; no changes to import/worker processing behavior.


---

<!-- consolidated from CHANGELOG-2.8.94.md -->

# EVazar Core 2.8.94 — Import History Status Card Layout

- Removes the separate prominent history button from the top of the import queue page.
- Adds “محصولات وارد شده ۲۴ ساعت گذشته” as the fifth clickable status card, after the four existing cards.
- Matches the existing card layout, spacing, radius, border, shadow, and count typography; preserves the history filter and query behavior.
- No changes to queue processing, worker routing, importer behavior, or database schema.


---

<!-- consolidated from CHANGELOG-2.8.95.md -->

# EVazar Core 2.8.95 — Manual Import Statistics Sync

- Fixes single-product manual imports not appearing in the queue's completed count or 24-hour imported-product history.
- On successful manual import, records the DKP/product/time in the durable history table and mirrors the item as `completed` in the import queue, clearing stale retry/error/claim state.
- Adds one-time recovery from successful entries still present in the rolling 50-entry importer log, preserving their original timestamps (limited to the previous 24 hours).
- Keeps queue worker history recording unchanged; a unique DKP history row means repeated imports update the last successful import time rather than duplicating the product count.
- Includes explicit admin feedback if either statistics write fails; product-import success remains success.


---

<!-- consolidated from CHANGELOG-2.8.96.md -->

# EVazar Core 2.8.96 — Gemini Request Correlation Logging

- Added one correlation ID per logical Gemini generation request and reused it across Worker attempts and retries.
- Added product DKP to product-import Gemini operational events; taxonomy requests record purpose and term ID instead.
- Added per-attempt sequence, Worker index, initial/failover route, per-Worker retry index, and retry flag.
- Added safe events for transport failures, HTTP failures, and invalid responses so a failed first Worker and successful fallback can be linked.
- Added `X-EVazar-Request-ID` request header for optional downstream tracing. No prompt, product title, or API key is logged or sent in this identifier.
- Kept event retention capped at 80 entries.


---

<!-- consolidated from CHANGELOG-2.8.97.md -->

# EVazar Core 2.8.97 — DKP Duplicate-Import Guard

- Added an atomic per-DKP MariaDB advisory lock around every importer entry point used by manual import and the queue. Concurrent imports of the same DKP fail closed before Worker/Gemini requests.
- Replaced URL-only lookup with fresh canonical matching across `_evazar_sku`, `_sku`, and common legacy URL variants.
- Removed reliance on cached positive/negative lookup results during product creation.
- Existing duplicate records are logged for review; no product is automatically deleted, merged, unpublished, or otherwise altered by the duplicate guard. If multiple records already share a DKP, the oldest published match is selected deterministically for update.
- This release does not perform database migrations and does not repair existing duplicate records automatically.


---

<!-- consolidated from CHANGELOG-2.8.98.md -->

# EVazar Core 2.8.98 — Product Search, IDs, and Index Reliability

- Added a visible internal product ID column in the WordPress “All EVazar Products” list, linking directly to the editor.
- Added a visible Digikala DKP column, distinct from the internal WordPress product ID.
- Extended EVazar product-list and eligible public site-search queries to search by title/content (native WordPress behavior), internal numeric product ID, `_evazar_sku`, `_sku`, and Digikala URL; supports Persian/Arabic digits and `DKP-123456` notation.
- Updated product-admin search placeholder to state supported search keys.
- Replaced `current_time('timestamp')` with Unix `time()` for `_evazar_last_stock_check` values written during import.
- Hardened the importer to fail closed if the final product-identity lookup returns an error, instead of mistakenly proceeding to insert.
- Product-index sync functions now return failure and log a low-detail diagnostic when SQL writes/reads fail; previously they could report success without confirming the write.
- Existing duplicate products and historic timestamps are not modified automatically. No database schema migration or data deletion is included.
- Added an administrator-only, nonce-protected row action to re-sync one product and its category index from canonical WordPress product metadata; useful for safely repairing an index mismatch without direct SQL.
- If brand/category term lookup fails, the index sync stops before writing/deleting category-index rows rather than interpreting a database error as an empty taxonomy.


---

<!-- consolidated from CHANGELOG-2.8.99.md -->

# EVazar Core 2.8.99 — Cross-module reconciliation

- Kept internal product ID / DKP columns and admin product search for title, ID, DKP, SKU, and source URL.
- Restricted the additional `posts_search` filter to the admin product list; public search uses the theme's optimized Product Index path to avoid redundant correlated meta scans.
- Included legacy `_evazar_dk_id` in identity lookup used by the duplicate guard.
- Propagated Product Index sync failures from import so queue/history do not mark an unindexed import as completely successful.
- Live price inquiry now records index-sync success/failure in its response and logs a failed sync.
- Queue items encountering an already-held DKP lock are deferred 60 seconds without increasing retries.
- Category-index sync inserts current relationships before removing stale ones; SQL failures no longer delete prior category associations first.
- No products are deleted/merged and no historic timestamps are bulk-modified.


---

<!-- consolidated from CHANGELOG-2.9.0.md -->

# EVazar Core 2.9.0

## Safety and consistency
- Gemini model is now fixed to `gemini-3.5-flash-lite`; stale option values and caller-supplied model names are ignored, and settings saves normalize to the same model.
- Re-import of an existing DKP skips AI generation while refreshing source-derived product data. Existing product description, pros/cons, and Rank Math fields are preserved unless absent.
- Legacy `_evazar_dk_id` values are now considered by the duplicate lookup and Product Index canonical DKP fallback.
- Product Index version is bumped to `1.2.0` so the scheduled backfill refreshes existing published rows from canonical/legacy metadata.
- A failed or unavailable live Product Index sync no longer clears a previous sync error or writes a false `ok` status. The live response still includes the fresh source price and reports index status separately.
- Product import fails visibly if index sync is unavailable or unsuccessful.
- Core CDN image URL transformation resizes an existing `x-oss-process` to the requested card size and honors the page's 10-minute direct-image failover mode.
- Embedded Worker is synchronized to Worker `1.11.4`, which only calls Gemini `gemini-3.5-flash-lite`.

## Safety notes
- No database records are deleted or merged.
- No bulk rewriting of historical stock timestamps is performed.
- Duplicate `dkp` database uniqueness is not added while the known duplicate DKP still exists; the importer lock remains the guard for concurrent importer requests.


---

<!-- consolidated from CHANGELOG-2.9.1.md -->

# EVazar Core 2.9.1

- Fixed OSS image resize parsing so dimensions are confined to `image/resize` and later operations such as `quality` retain their position.
- Explicit admin AI rewrite is now a one-shot opt-in flag. Routine existing-product reimports keep skipping Gemini; valid AI output is checkpointed before index sync so retries do not spend Gemini quota twice. The flag is cleared only after index sync succeeds.
- Rewrite queue includes `_evazar_sku`, `_sku` and legacy `_evazar_dk_id`, normalizes DKP values and does not count failed queue inserts as success.
- Browser image fallback preserves and maps lazy `data-srcset`, `data-lazy-srcset` and live `srcset`; it finds a CDN URL even when the current `src` is a placeholder.
- Product Index sync failures are tracked with bounded exponential backoff and retry attempts; retry rows do not starve normal backfill. Full table schema upgrade is not run on every five-minute backfill batch.
- Product Index version bumped to 1.2.1 to refresh canonical and legacy identities incrementally.
- Hardened browser failover for placeholder/lazy-loaded images: directizes and preserves all relevant `srcset`/lazy attributes, and can promote the first valid direct candidate to `src` when the prior `src` is only a placeholder.
- Explicit bulk AI rewrite no longer deletes existing excerpts/metadata before valid AI output; existing content survives AI/network failures and is cleared only along the successful rewrite path.


---

<!-- consolidated from CHANGELOG-2.9.2.md -->

# EVazar Core 2.9.2 — Independent Image Recovery

- Replaced page-wide image failover with per-image recovery: normal CDN request, one cache-bypass retry, then direct-origin fallback and one bounded direct retry.
- Removed the 10-minute persistent Direct Mode behavior; stale Direct Mode cookies are cleared and no longer influence PHP image URLs.
- Added per-image watchdogs for visible/eager images to recover genuinely stalled requests without redirecting all page images.
- Added support for images inserted by archive/AJAX/infinite-scroll updates.
- Preserved product gallery rendering and did not change product/image data or database schema.
- Worker 1.11.6 additionally strips the retry control parameter before contacting Digikala and never caches failed/non-image responses.

## Validation

- PHP syntax and JavaScript syntax checks are expected to pass before release packaging.
- Mock tests cover CDN error -> forced CDN retry -> direct fallback, direct retry bounds, and failure isolation.
- Production network behavior must still be smoke-tested after deploying the same Worker version to every configured image/product Worker.


---

<!-- consolidated from CHANGELOG-2.9.3.md -->

# EVazar Core 2.9.3 — Core/Worker Image Recovery Contract Fix

- The direct-origin retry now routes through the configured image Worker using `img=<direct URL>&evazar_direct_retry=1`.
- The Worker recognizes both `evazar_retry=1` and `evazar_direct_retry=1` as cache-bypass controls and strips retry controls from the upstream Digikala URL.
- Avoids repeating the same direct-origin browser request and finalizes the bounded final retry reliably.
- The bundled Worker is version 1.11.7 and is byte-for-byte identical to the standalone Worker release.
- Product-cache namespace remains at v1.11.5 deliberately because this is an image-only Worker update.

Validation includes PHP/JS syntax, ZIP integrity, exact bundled/standalone Worker parity, image retry contract checks, and mocked routing behavior. Live Cloudflare/site behavior still requires production smoke testing.


---

<!-- consolidated from CHANGELOG-2.9.4.md -->

# EVazar Core 2.9.4 — Non-image Origin Retry Fix

- Worker retries upstream 2xx responses that have a non-image Content-Type (for example, an HTML anti-bot/challenge response).
- Removes forced one-year upstream fetch caching before MIME validation; only successfully validated image responses enter caches.
- Recovery requests return no-store at the public response layer, ensuring a requested retry reaches the Worker.
- Failed image responses expose safe diagnostics: Worker version, origin status, and upstream Content-Type.
- Bundled Worker is version 1.11.8 and matches the standalone release byte-for-byte.
- Existing per-image recovery order, host allowlist, product-cache namespace, and theme/gallery files are unchanged.

Validation performed: PHP lint, JavaScript syntax check, ZIP CRC checks, bundle parity, and mocked runtime cases including HTML 200 then valid image, persistent non-image response, 404 retry, and disallowed host rejection. Production Cloudflare/origin behavior must still be verified after deployment.


---

<!-- consolidated from CHANGELOG-2.9.5.md -->

# EVazar Core 2.9.5 — Faster Image Recovery

- Reduced visible/eager image watchdog from 4.2s to 1.3s on mobile and from 5.2s to 1.8s on desktop.
- Reduced the bounded timeout for each recovery attempt from 5.2s to 2.8s.
- When a CDN image stalls and times out, switch that image directly to the original image host instead of retrying the same CDN first.
- Preserve one cache-bypass CDN retry for explicit image errors (for example a 502), then fall back to the original host.
- Changes are isolated to the existing per-image recovery script; no gallery, archive, lazy-loading, or layout code was changed.


---

<!-- consolidated from CHANGELOG-2.9.7.md -->

# EVazar Core 2.9.7

- Treat complete images with zero intrinsic width as failed, not successful, in bounded image recovery timers.
- On browser connectivity restoration, retry failed visible/eager images individually through the Worker with a unique recovery URL. Lazy/off-screen images are not mass-reloaded.


---

<!-- consolidated from CHANGELOG-2.9.8.md -->

# EVazar Core 2.9.8 — bounded scroll-triggered image recovery

- Reattempts images that already exhausted their normal CDN/direct recovery chain when the user scrolls/resizes, even if no browser `online` event fires after a VPN route change.
- Includes lazy-loaded images that were recently near the viewport for a 10-second grace period, so a failed image can still recover immediately after the user scrolls past it.
- Shares one strict post-failure retry budget across scroll/resize and connectivity events: at most 2 retries per unchanged image source, at least 5 seconds apart.
- Adds a per-image unique `evazar_reconnect` query token while preserving the Worker's `evazar_direct_retry=1` recovery path. No page reload, page-wide failover, archive changes, product changes, or new Worker deployment.
- Resets the retry budget when the image source changes or successfully loads.


---

<!-- consolidated from CHANGELOG-2.9.9.md -->

# EVazar Core 2.9.9 — Core/theme image-recovery coordination

- Adds `img.__evazarCoreManaged` to mark image elements whose CDN/direct recovery is handled by Core, allowing gallery handlers to avoid replacing retrying image URLs with local placeholders.
- On image errors, re-syncs stale `loaded`/`failed` state only if the image source signature actually changed. This prevents an old success state from blocking recovery when gallery code reuses an `<img>` before MutationObserver processing, while preserving a failed image’s bounded scroll-retry state.
- Keeps the 2.9.8 bounded scroll/resize recovery policy: at most 2 extra attempts per unchanged source, at least 5 seconds apart.
- No Worker deployment, database changes, archive changes, or product data changes required.


---

<!-- consolidated from CHANGELOG-2.9.10.md -->

# EVazar Core 2.9.10 — image recovery lifecycle coordination

- Fixes image load observation: `load` events from `<img>` do not bubble to `window`; Core now listens on `document` in capture phase so successful retries transition to `loaded`, timers are cleared, and retry budgets reset.
- Retains the Core/theme ownership marker and source-signature synchronization from 2.9.9.
- Keeps bounded scroll recovery from 2.9.8 and coordination with Theme 1.12.86.
- No Worker deployment, database changes, or product-data changes required.


---

<!-- consolidated from CHANGELOG-2.9.11.md -->

# EVazar Core 2.9.11 — Image-origin final fallback

- Fixed direct-origin fallback for Worker URLs using `?img=<encoded source>`; the source URL is now safely unwrapped and validated against `dkstatics-public.digikala.com`.
- If the bounded forced Worker retry still returns a non-image/error response, the same image gets one final direct-origin browser request.
- If that fails, recovery remains bounded; later scroll/connectivity recovery can retry through the Worker, with the existing cooldown and retry budget.
- No page-wide image mode, product metadata, archive filtering, importer, or gallery layout changes. Theme 1.12.86 and Worker 1.11.8 remain compatible.


---

<!-- consolidated from CHANGELOG-2.9.12.md -->

# EVazar Core 2.9.12 — Product Schema Currency and Deduplication

- Corrected Offer currency to ISO 4217 `IRR` and converts stored Toman price to Rials (x10).
- Uses seller metadata and the affiliate destination URL rather than marking EVazar as the seller.
- Applies the theme's schema enable/mode options to the Rank Math JSON-LD integration.
- Removes the synthetic `priceValidUntil` date and third-party AggregateRating markup.
- Omits `validFrom`, return policy and shipping costs unless reliable source data becomes available.
- Theme standalone Product JSON-LD is suppressed when this Core/Rank Math schema integration is active, avoiding duplicate Product nodes.

## Validation

- PHP syntax and ZIP integrity checks passed.
- This package was not deployed to the live site; Rich Results Test and Search Console validation must be run after installation.


---

<!-- consolidated from CHANGELOG-2.9.13.md -->

# EVazar Core 2.9.13

- Added a Core setting for image routing: direct Digikala CDN (default) or Cloudflare Worker/Image CDN.
- The canonical image URL helper now respects the selected route, including resized URLs.
- In direct mode, the Core does not emit the Worker image-recovery script, preventing image display from probing `img.evazar.ir`.
- Import/price Worker configuration and Gemini Worker rotation are unchanged.


---

<!-- consolidated from CHANGELOG-2.9.14.md -->

# EVazar Core 2.9.14 — Product Prompt Authority Fix

- The saved product prompt remains the authority for writing style and SEO content.
- Removed hard-coded legacy instructions that forced headings policy, 5–7 pros, price, and “authenticity guarantee” wording after the administrator prompt.
- Kept the JSON keys required by the importer parser, without overriding the saved prompt’s content instructions.
- Simplified the fallback meta description to avoid unsupported price/authenticity claims.
- No database schema, queue, worker, product identity, or image-routing changes.

Note: the exact current WordPress option value is stored in the live site database and is not included in a plugin ZIP. The default prompt editor text is therefore not rewritten to an unknown prompt; this change ensures the runtime does not append the identified conflicting legacy instructions.
