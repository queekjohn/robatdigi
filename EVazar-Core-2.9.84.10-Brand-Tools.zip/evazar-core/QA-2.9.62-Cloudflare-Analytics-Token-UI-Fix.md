# QA — EVazar Core 2.9.62

- Updated the settings label and helper text to distinguish account/Worker mappings from account/token mappings.
- Verified sanitizer still requires a valid 32-character hexadecimal account ID and a non-empty token.
- Existing stored tokens and the legacy single-token fallback remain unchanged.
- Static PHP lint and ZIP integrity checks required before installation. No live Cloudflare credentials or production WordPress runtime are available; no live API or production test is claimed.
