# EVazar Core 2.9.76 — Cooldown-Aware Stock Sync Deferral

- When no primary Worker can be used because the pool is in temporary cooldown, scheduled price/stock sync now defers the current product instead of marking it as a product/source failure.
- The batch cursor remains on the same product; the last-attempt timestamp and prior price/stock sync status are preserved when no network request was sent.
- The batch continuation is moved to the nearest recorded cooldown expiry (with a conservative fallback for legacy cooldown transients) and the recurring five-minute hook cannot bypass an active defer window.
- Per-Worker cooldown records now retain a safe reason, HTTP code, and expiry. The price/stock log displays available details without exposing full URLs or tokens.
- Daily-budget and capacity-only skips are deferred as well; product import code, import queue data, import locks, and Worker 1.13.11 JavaScript are unchanged.

Validation is local/static: PHP syntax, Worker JavaScript syntax, archive integrity, and source-level regression assertions. No live WordPress or Cloudflare environment was exercised.
