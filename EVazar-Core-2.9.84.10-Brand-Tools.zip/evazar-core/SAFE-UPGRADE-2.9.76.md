# Safe upgrade — EVazar Core 2.9.76

1. Back up the current `evazar-core` plugin folder and the WordPress database.
2. Replace the existing plugin folder with `evazar-core/` from this archive. This is a Core-only update for an installation already running Worker 1.13.11; it does not require redeploying the unchanged Worker script.
3. Preserve all current settings, including the `EVAZAR_INTERNAL_TOKEN` secret stored separately in Cloudflare. Do not paste tokens into the script or logs.
4. Do not manually clear cooldowns or increase the daily budget during validation.
5. Let the next price/stock cycle run. When the entire pool is in cooldown, logs should say `به تعویق افتاده`, show each available Worker's reason/HTTP code and approximate retry delay, preserve existing prices/stock, and resume the same product after the wait instead of writing a false product failure.
6. After a successful HTTP 200, verify that the product is reported as `موفق` or `بدون تغییر` with `Worker 1.13.11`.

This release does not change `queue-manager.php`, import queue state, import locks, or Cloudflare Worker source. Existing cooldown transients from 2.9.75 are supported; their original cause may be unavailable until they expire.

Rollback: restore the backed-up plugin directory. Do not roll back Worker 1.13.11 unless a separate Worker regression is demonstrated.
