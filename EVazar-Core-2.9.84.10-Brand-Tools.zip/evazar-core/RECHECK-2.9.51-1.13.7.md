# Release recheck — EVazar Core 2.9.51 / Worker 1.13.7

## Changes in this version
This release increments the Core version number for the Gemini report local-time display correction. It is based on the current reviewed 2.9.50 code and retains that code's queue batching, retry/idempotency, worker-aware allocation, and automatic-singleton blocking behavior. Worker remains unchanged at 1.13.7.

## Source checks
- `evazar-core.php` plugin header version is 2.9.51.
- Queue parallel request User-Agent identifies Core 2.9.51.
- Gemini report formatter uses the WordPress timezone and formats epoch timestamps without altering stored values.
- Embedded Worker and standalone Worker source compare byte-for-byte.

## Scope and limitation
Archive integrity, syntax and source-identity are locally testable. This recheck does not include a live WordPress admin session, deployed Cloudflare state, or an actual Gemini API request.
