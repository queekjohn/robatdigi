# EVazar Core 2.9.84.3 — LiteSpeed Targeted Cache Purge

## Changes

- Added native LiteSpeed Web Server HTML-cache purge support through `X-LiteSpeed-Purge: url=/exact/path`, so the WordPress LiteSpeed Cache plugin is not required for this mechanism.
- Purges the front page, exact product URL, currently assigned category/brand archives, and captured previous category/brand archive URLs after a confirmed Product Index sync on import/update.
- Defers pending purge work when Product Index sync fails. The marker is consumed only after a later successful index sync.
- Any real price/stock/rating change invalidates the exact product URL, front page, and related category/brand archives; unchanged checks do not trigger cache purges.
- Purges the relevant exact category or brand URL when an EVazar taxonomy term is created or edited.
- Retains compatibility hooks for LiteSpeed Cache (if installed), WP Rocket, WP Super Cache, W3 Total Cache, and Nginx Helper.
- Persists purge paths if output headers cannot be sent or code runs in CLI. HTTP requests re-arm the bounded queue. The queue keeps up to 2,000 exact same-site paths and processes up to 60 paths per response.
- No wildcard purge or global cache flush is performed.

## Not changed

- The worker is unchanged; Worker 1.13.13.1 remains compatible with Core's 15-product requests / 75-product queue capacity.
- This plugin package does not edit the site's `.htaccess`. Set the native page-cache TTL separately if required.
