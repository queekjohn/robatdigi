# Historical safe-upgrade note — EVazar Core 2.9.24

This guide is superseded by `SAFE-UPGRADE-2.9.25.md`. For the current taxonomy web-research mechanism, follow the 2.9.25 guide; no separate search API key is required.
