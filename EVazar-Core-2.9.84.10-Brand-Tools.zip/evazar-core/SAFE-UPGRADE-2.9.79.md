# Safe upgrade — EVazar Core 2.9.79 / Worker 1.13.12

1. Back up the current `evazar-core` folder and WordPress database.
2. Deploy Worker 1.13.12 to every configured Gemini Worker endpoint before Core upgrade. Keep existing secrets and bindings unchanged.
3. Replace the `evazar-core` plugin folder with this package. The taxonomy queue table and schedules are managed by the plugin; no manual SQL migration is required.
4. Category and brand SEO are independent queues, each dispatching only 2–5 same-type terms. Existing descriptions are preserved and existing taxonomy terms are not automatically re-enqueued by product import.
5. Stable taxonomy request IDs help replay protection only when the optional `EVAZAR_GEMINI_IDEMPOTENCY` Durable Object binding is configured on each Worker. Without that binding, Core still prevents concurrent duplicate term claims, but an uncertain network outcome may be retried after stale-lease recovery.
6. WordPress Cron execution depends on site traffic or a configured system cron. The queues do not block product import synchronously; strict simultaneous execution of category and brand PHP callbacks is not guaranteed by WP-Cron alone.

This release has been tested locally only. It was not installed on the live site and did not call live Gemini or Cloudflare.
