<?php
if (!defined('ABSPATH')) exit;

// ==========================================
// Single-term diagnostic/rewrite UI (Admin Settings)
// ==========================================
add_action('evazar_core_settings_page_bottom', 'evazar_ai_single_term_processor_ui', 5);
function evazar_ai_single_term_processor_ui() {
    if (!current_user_can('manage_options')) return;
    $nonce = wp_create_nonce('evazar_batch_nonce');
    ?>
    <div style="background:#fff; padding:22px; border:1px solid #c3c4c7; margin-top:26px; border-radius:6px; border-right:4px solid #2271b1; direction:rtl;">
        <h2 style="margin-top:0; font-size:1.25em;">آزمایش یا بازنویسی یک دسته / برند</h2>
        <p style="line-height:1.8; margin-bottom:14px;">برای بررسی یک ترم شناسه و نوع را وارد کنید. درخواست پردازش به صف همان نوع می‌رود و فقط همراه حداقل یک مورد دیگر به Gemini ارسال می‌شود.</p>
        <div style="display:flex; gap:12px; align-items:flex-end; flex-wrap:wrap;">
            <label style="display:flex; flex-direction:column; gap:6px; min-width:150px;">
                <span>شناسه ترم (ID)</span>
                <input id="evazar-single-term-id" type="number" min="1" step="1" inputmode="numeric" placeholder="مثلاً 1842" style="min-width:150px;" />
            </label>
            <label style="display:flex; flex-direction:column; gap:6px; min-width:190px;">
                <span>نوع مورد</span>
                <select id="evazar-single-term-taxonomy" style="min-width:190px;">
                    <option value="evazar_category">دسته‌بندی</option>
                    <option value="evazar_brand">برند</option>
                </select>
            </label>
            <button type="button" id="evazar-single-term-preview" class="button">بررسی مورد</button>
            <button type="button" id="evazar-single-term-process" class="button button-primary" disabled>افزودن به صف سئو</button>
        </div>
        <label style="display:block; margin-top:14px; line-height:1.8;">
            <input type="checkbox" id="evazar-single-term-force-ai" value="1" />
            بازنویسی دوباره در صورت تشخیص قطعی محتوای قبلیِ تولیدشده توسط AI (متن دستی و موارد قفل‌شده همچنان محافظت می‌شوند)
        </label>
        <pre id="evazar-single-term-details" style="display:none; white-space:pre-wrap; overflow-wrap:anywhere; background:#f6f7f7; border:1px solid #dcdcde; border-radius:4px; padding:12px; margin:14px 0 0; font:13px/1.9 monospace;"></pre>
        <p style="margin:10px 0 0; color:#646970;">نکته: این ابزار فقط همان شناسه را بررسی می‌کند. اگر توضیحات دستی یا قفل‌شده باشد، افزونه آن را بازنویسی نمی‌کند.</p>
    </div>
    <script>
    jQuery(function($){
        var nonce = <?php echo wp_json_encode($nonce); ?>;
        var $id = $('#evazar-single-term-id');
        var $tax = $('#evazar-single-term-taxonomy');
        var $preview = $('#evazar-single-term-preview');
        var $process = $('#evazar-single-term-process');
        var $force = $('#evazar-single-term-force-ai');
        var $details = $('#evazar-single-term-details');
        var inspected = null;
        var busy = false;

        function showMessage(message) {
            $details.text(String(message || 'پاسخی دریافت نشد.')).show();
        }
        function invalidatePreview() {
            inspected = null;
            $process.prop('disabled', true);
            $details.hide().text('');
        }
        $id.add($tax).on('change input', invalidatePreview);

        $preview.on('click', function(){
            if (busy) return;
            var termId = parseInt($id.val(), 10);
            if (!termId || termId < 1) { showMessage('شناسه معتبر نیست.'); return; }
            busy = true;
            $preview.prop('disabled', true).text('در حال بررسی...');
            $process.prop('disabled', true);
            showMessage('در حال دریافت اطلاعات مورد...');
            $.post(ajaxurl, {
                action: 'evazar_batch_preview_single_term',
                term_id: termId,
                tax: $tax.val(),
                _wpnonce: nonce
            }).done(function(res){
                if (!res || !res.success || !res.data) {
                    showMessage(res && res.data && res.data.message ? res.data.message : 'مورد پیدا نشد یا درخواست رد شد.');
                    return;
                }
                inspected = res.data;
                var d = res.data;
                var lines = [
                    'نام: ' + d.name,
                    'شناسه: ' + d.term_id,
                    'نوع: ' + (d.taxonomy === 'evazar_brand' ? 'برند' : 'دسته‌بندی'),
                    'توضیحات فعلی: ' + d.description_chars + ' نویسه',
                    'وضعیت محتوا: ' + (d.content_status || 'ثبت نشده'),
                    'محتوا متعلق به AI است: ' + (d.ai_owned ? 'بله، با تطبیق اثر محتوا' : 'خیر / قابل تأیید نیست'),
                    'قفل محتوا: ' + (d.locked ? 'فعال؛ بازنویسی متوقف خواهد شد' : 'غیرفعال'),
                    'آخرین روش دریافت منبع: ' + (d.source_method || 'ثبت نشده'),
                    'تعداد نویسه منبع در آخرین تلاش: ' + (d.source_chars || '0'),
                    'تعداد نمونه محصولات در آخرین تولید: ' + (typeof d.sample_product_count !== 'undefined' ? d.sample_product_count : '0'),
                    'نام نمونه محصولات در آخرین تولید: ' + (d.sample_product_titles || 'هنوز ثبت نشده'),
                    'آدرس منبع دیجی‌کالا: ' + (d.source_url || 'پیدا نشد')
                ];
                showMessage(lines.join('\n'));
                $process.prop('disabled', false);
            }).fail(function(xhr){
                var message = xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message;
                showMessage(message || 'خطای ارتباط با سرور هنگام بررسی مورد.');
            }).always(function(){
                busy = false;
                $preview.prop('disabled', false).text('بررسی مورد');
            });
        });

        $process.on('click', function(){
            if (busy || !inspected) return;
            var force = $force.is(':checked');
            var confirmText = 'مورد «' + inspected.name + '» با شناسه ' + inspected.term_id + ' به صف هم‌نوع خود اضافه شود؟ برای جلوگیری از درخواست تکی، تا آماده شدن مورد دوم منتظر می‌ماند.';
            if (force) confirmText += '\nفقط محتوای قبلی که به‌طور قطعی متعلق به AI تشخیص داده شود مجاز به بازنویسی است؛ این درخواست هم در batch هم‌نوع اجرا می‌شود.';
            if (!window.confirm(confirmText)) return;
            busy = true;
            $preview.prop('disabled', true);
            $process.prop('disabled', true).text('در حال افزودن به صف...');
            showMessage('مورد به صف اضافه می‌شود؛ درخواست Gemini مستقل برای یک مورد ارسال نخواهد شد.');
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                timeout: 90000,
                data: {
                    action: 'evazar_batch_process_single_term',
                    term_id: inspected.term_id,
                    tax: inspected.taxonomy,
                    force_ai_rewrite: force ? '1' : '0',
                    _wpnonce: nonce
                }
            }).done(function(res){
                var d = res && res.data ? res.data : {};
                var lines = [
                    'نتیجه: ' + (d.message || (res && res.success ? 'عملیات پایان یافت.' : 'پردازش موفق نبود.')),
                    'وضعیت: ' + (d.status || 'نامشخص'),
                    'شناسه: ' + (d.term_id || inspected.term_id),
                    'روش دریافت منبع: ' + (d.source_method || 'ثبت نشده'),
                    'نویسه‌های منبع: ' + (typeof d.source_chars !== 'undefined' ? d.source_chars : 'ثبت نشده'),
                    'نمونه محصولات استفاده‌شده: ' + (typeof d.sample_product_count !== 'undefined' ? d.sample_product_count : 'ثبت نشده'),
                    'نام محصولات نمونه: ' + (d.sample_product_titles || 'ثبت نشده'),
                    'نویسه‌های خروجی ذخیره‌شده: ' + (typeof d.output_chars !== 'undefined' ? d.output_chars : 'ثبت نشده'),
                    'آدرس منبع دیجی‌کالا: ' + (d.source_url || inspected.source_url || 'پیدا نشد'),
                    'خطای جزئیات: ' + (d.last_error || 'ندارد / ثبت نشده')
                ];
                showMessage(lines.join('\n'));
                // Refresh the preview so its metadata reflects the just-completed attempt.
                inspected = {term_id: inspected.term_id, taxonomy: inspected.taxonomy, name: inspected.name};
                $process.prop('disabled', true);
            }).fail(function(xhr){
                var d = xhr.responseJSON && xhr.responseJSON.data ? xhr.responseJSON.data : {};
                showMessage((d.message || 'خطای ارتباط/مهلت درخواست هنگام پردازش.') + '\n' + (d.status ? 'وضعیت: ' + d.status : ''));
            }).always(function(){
                busy = false;
                $preview.prop('disabled', false).text('بررسی مورد');
                $process.text('افزودن به صف سئو');
            });
        });
    });
    </script>
    <?php
}

// ==========================================
// Taxonomy SEO Batch Queue UI
// ==========================================
add_action('evazar_core_settings_page_bottom', 'evazar_ai_batch_processor_ui');
function evazar_ai_batch_processor_ui() {
    if (!current_user_can('manage_options')) return;
    ?>
    <div style="background:#fff; padding:25px; border:1px solid #ccd0d4; margin-top:40px; border-radius:4px; border-right:4px solid #2271b1; direction:rtl;">
        <h2 style="margin-top:0; font-size:1.3em;">صف دسته‌ای محتوای سئوی دسته‌ها و برندها</h2>
        <p style="font-size:14px; line-height:1.8;">فقط موارد فاقد محتوای معتبر به صف اضافه می‌شوند. دسته‌ها و برندها در صف‌های جدا پردازش می‌شوند؛ هر درخواست Gemini شامل ۲ تا ۵ مورد هم‌نوع است. محتوای دستی، قفل‌شده و محتوای معتبر فعلی تغییر نمی‌کند و واردسازی محصول منتظر این صف نمی‌ماند.</p>
        <button id="evazar-run-batch" class="button button-primary button-large" style="margin-top:10px;">افزودن موارد فاقد محتوای معتبر به صف سئو</button>
        <button id="evazar-check-taxonomy-queue" class="button button-secondary button-large" style="margin-top:10px; margin-right:6px;">بررسی وضعیت صف‌ها</button>
        <div id="evazar-batch-status" style="margin-top:15px; font-weight:bold; color:#0071a1; font-size:15px;"></div>
        <div id="evazar-taxonomy-queue-status" role="status" aria-live="polite" style="margin-top:10px; line-height:1.9; white-space:pre-line;"></div>
    </div>
    <script>
    jQuery(function($){
        $('#evazar-run-batch').on('click', function(e){
            e.preventDefault();
            var $btn = $(this), $status = $('#evazar-batch-status');
            $btn.prop('disabled', true);
            $status.text('در حال بررسی موارد فاقد محتوا و افزودن به صف...');
            $.post(ajaxurl, {
                action: 'evazar_queue_missing_taxonomy_seo',
                _wpnonce: '<?php echo wp_create_nonce("evazar_batch_nonce"); ?>'
            }).done(function(res){
                if (res && res.success && res.data) {
                    var d = res.data;
                    $status.text('به صف اضافه شد: ' + (d.queued || 0) + ' مورد؛ ' + (d.deferred || 0) + ' مورد به‌دلیل فاصله امن تلاش مجدد عقب افتاد. هر نوع جدا و با حداقل دو مورد ارسال می‌شود.');
                } else {
                    $status.text((res && res.data && res.data.message) || 'افزودن موارد به صف ناموفق بود.');
                }
            }).fail(function(xhr){
                var d = xhr.responseJSON && xhr.responseJSON.data ? xhr.responseJSON.data : {};
                $status.text(d.message || 'خطای ارتباط هنگام افزودن موارد به صف.');
            }).always(function(){ $btn.prop('disabled', false); });
        });
        $('#evazar-check-taxonomy-queue').on('click', function(e){
            e.preventDefault();
            var $btn = $(this), $out = $('#evazar-taxonomy-queue-status');
            $btn.prop('disabled', true);
            $out.text('در حال خواندن وضعیت صف‌ها...');
            $.post(ajaxurl, {
                action: 'evazar_taxonomy_seo_queue_status',
                _wpnonce: '<?php echo wp_create_nonce("evazar_batch_nonce"); ?>'
            }).done(function(res){
                if (!res || !res.success || !res.data) {
                    $out.text((res && res.data && res.data.message) || 'خواندن وضعیت صف ناموفق بود.');
                    return;
                }
                var d = res.data;
                function line(label, q) {
                    var next = q.next_cron_at ? new Date(q.next_cron_at * 1000).toLocaleString() : 'ثبت نشده';
                    var nudge = q.next_nudge_at ? new Date(q.next_nudge_at * 1000).toLocaleString() : 'ثبت نشده';
                    var retry = q.next_retry_at ? new Date(q.next_retry_at * 1000).toLocaleString() : '—';
                    return label + ': کل=' + q.total + '، نهایی‌شده=' + q.done + ' (بدون نشانی منبع=' + q.done_no_source_url + '؛ بدون متن منبع=' + q.done_no_source_text + '؛ سایر نهایی‌ها=' + q.done_other + ')، موعد اجرا رسیده=' + q.due + '، pending=' + q.pending + '، retry=' + q.retry + '، درحال‌پردازش=' + q.processing + '\nاجرای دوره‌ای بعدی: ' + next + '؛ اجرای فوری: ' + nudge + '\nنزدیک‌ترین زمان retry: ' + retry;
                }
                var msg = line('دسته‌ها', d.category) + '\n\n' + line('برندها', d.brand);
                if (d.wp_cron_disabled) msg += '\n\nهشدار: DISABLE_WP_CRON فعال است؛ باید Cron واقعی سرور تنظیم شده باشد.';
                if (d.category.cron_overdue || d.brand.cron_overdue) msg += '\n\nهشدار: دست‌کم یک رویداد دوره‌ای بیش از ۲ دقیقه از موعدش گذشته؛ اجرای واقعی WP-Cron را بررسی کنید.';
                $out.text(msg);
            }).fail(function(xhr){
                var d = xhr.responseJSON && xhr.responseJSON.data ? xhr.responseJSON.data : {};
                $out.text(d.message || 'خطا هنگام خواندن وضعیت صف‌ها.');
            }).always(function(){ $btn.prop('disabled', false); });
        });
    });
    </script>
    <?php
}

// ==========================================
// AJAX endpoints
// ==========================================
add_action('wp_ajax_evazar_batch_preview_single_term', 'evazar_batch_preview_single_term_callback');
function evazar_batch_preview_single_term_callback() {
    check_ajax_referer('evazar_batch_nonce', '_wpnonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'اجازهٔ لازم برای این عملیات وجود ندارد.'], 403);
    }

    $term_id = isset($_POST['term_id']) ? absint($_POST['term_id']) : 0;
    $taxonomy = isset($_POST['tax']) ? sanitize_key(wp_unslash($_POST['tax'])) : '';
    if ($term_id < 1 || !in_array($taxonomy, ['evazar_category', 'evazar_brand'], true)) {
        wp_send_json_error(['message' => 'شناسه یا نوع مورد معتبر نیست.'], 400);
    }

    $term = get_term($term_id, $taxonomy);
    if (!$term || is_wp_error($term)) {
        wp_send_json_error(['message' => 'موردی با این شناسه در نوع انتخاب‌شده پیدا نشد. شناسه و نوع دسته/برند را بررسی کنید.'], 404);
    }

    $context_type = ($taxonomy === 'evazar_brand') ? 'brand' : 'category';
    $brand_en = ($taxonomy === 'evazar_brand') ? (string) get_term_meta($term_id, '_evazar_brand_en', true) : '';
    if (!function_exists('evazar_resolve_term_source_path')) require_once plugin_dir_path(__FILE__) . 'importer.php';
    $source_path = evazar_resolve_term_source_path($term_id, $taxonomy, $context_type, $brand_en);
    $description = (string) $term->description;
    $ai_owned = function_exists('evazar_term_description_is_recorded_ai_content')
        ? evazar_term_description_is_recorded_ai_content($term_id, $description)
        : false;

    wp_send_json_success([
        'term_id' => (int) $term->term_id,
        'taxonomy' => $taxonomy,
        'name' => (string) $term->name,
        'slug' => (string) $term->slug,
        'description_chars' => mb_strlen(trim(wp_strip_all_tags($description)), 'UTF-8'),
        'content_status' => (string) get_term_meta($term_id, '_evazar_ai_content_status', true),
        'source_method' => (string) get_term_meta($term_id, '_evazar_ai_content_source_method', true),
        'source_chars' => (int) get_term_meta($term_id, '_evazar_ai_content_source_chars', true),
        'sample_product_count' => (int) get_term_meta($term_id, '_evazar_ai_content_sample_product_count', true),
        'sample_product_titles' => implode(' | ', array_map('strval', (array) json_decode((string) get_term_meta($term_id, '_evazar_ai_content_sample_product_titles', true), true))),
        'source_url' => $source_path !== '' ? 'https://www.digikala.com' . $source_path : '',
        'locked' => get_term_meta($term_id, '_evazar_lock_seo_content', true) === 'yes',
        'ai_owned' => (bool) $ai_owned,
    ]);
}

add_action('wp_ajax_evazar_batch_fetch_terms', 'evazar_batch_fetch_terms_callback');
function evazar_batch_fetch_terms_callback() {
    check_ajax_referer('evazar_batch_nonce', '_wpnonce');
    if (!current_user_can('manage_options')) wp_send_json_error();

    $terms = get_terms([
        'taxonomy' => ['evazar_category', 'evazar_brand'],
        'hide_empty' => false,
        'fields' => 'all'
    ]);
    
    $result = [];
    foreach ($terms as $t) {
        $result[] = [
            'term_id' => $t->term_id,
            'taxonomy' => $t->taxonomy,
            'name' => $t->name
        ];
    }
    
    wp_send_json_success(['terms' => $result]);
}

add_action('wp_ajax_evazar_batch_process_single_term', 'evazar_batch_process_single_term_callback');
function evazar_batch_process_single_term_callback() {
    check_ajax_referer('evazar_batch_nonce', '_wpnonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['status' => 'forbidden', 'message' => 'اجازهٔ لازم برای این عملیات وجود ندارد.'], 403);
    }

    $term_id = isset($_POST['term_id']) ? absint($_POST['term_id']) : 0;
    $taxonomy = isset($_POST['tax']) ? sanitize_key(wp_unslash($_POST['tax'])) : '';
    $force_requested = isset($_POST['force_ai_rewrite']) && (string) wp_unslash($_POST['force_ai_rewrite']) === '1';
    if ($term_id < 1 || !in_array($taxonomy, ['evazar_category', 'evazar_brand'], true)) {
        wp_send_json_error(['status' => 'invalid_request', 'message' => 'شناسه یا نوع مورد معتبر نیست.'], 400);
    }

    $term = get_term($term_id, $taxonomy);
    if (!$term || is_wp_error($term)) {
        wp_send_json_error(['status' => 'invalid_term', 'message' => 'موردی با این شناسه در نوع انتخاب‌شده پیدا نشد.'], 404);
    }
    // The term's canonical name is always read from WordPress, never trusted from the browser.
    $name = (string) $term->name;
    $brand_en = ($taxonomy === 'evazar_brand') ? (string) get_term_meta($term_id, '_evazar_brand_en', true) : '';

    // A content lock always wins, including when a force rewrite of known AI content was requested.
    if (get_term_meta($term_id, '_evazar_lock_seo_content', true) === 'yes') {
        wp_send_json_error(['status' => 'skipped_locked', 'message' => 'محتوا قفل دستی دارد؛ هیچ تغییری اعمال نشد.', 'term_id' => $term_id, 'taxonomy' => $taxonomy]);
    }

    // Force mode may refresh only a description whose current text can be positively matched to recorded AI output.
    $existing_desc = trim(wp_strip_all_tags((string) $term->description));
    $is_fallback = function_exists('evazar_is_taxonomy_fallback_description')
        ? evazar_is_taxonomy_fallback_description($term->description)
        : (mb_strpos($existing_desc, 'راهنمای خرید و بررسی تخصصی جدیدترین مدل‌های') !== false);
    $old_ai_engine = (string) get_term_meta($term_id, '_evazar_ai_content_engine_version', true);
    $old_ai_status = (string) get_term_meta($term_id, '_evazar_ai_content_status', true);
    $description_is_ai_owned = function_exists('evazar_term_description_is_recorded_ai_content')
        ? evazar_term_description_is_recorded_ai_content($term_id, $term->description)
        : false;
    $is_outdated_auto_generated = ($description_is_ai_owned && ($old_ai_engine !== '2.9.19' || !in_array($old_ai_status, ['generated', 'skipped_manual'], true)));
    $force_ai_rewrite = ($force_requested && $description_is_ai_owned);
    if ($force_requested && !$description_is_ai_owned && $existing_desc !== '' && !$is_fallback) {
        // Do not expose/overwrite possible manual text: clear force mode and let the regular guard report skipped_manual.
        $force_ai_rewrite = false;
    }
    if (!empty($existing_desc) && !$is_fallback && !$is_outdated_auto_generated && !$force_ai_rewrite) {
        wp_send_json_success([
            'status' => 'skipped_existing',
            'message' => $description_is_ai_owned
                ? 'محتوای معتبر AI از قبل موجود است؛ بدون تغییر حفظ شد.'
                : 'توضیحات دستی یا غیرقابل‌تأیید است؛ بدون تغییر حفظ شد.',
            'term_id' => $term_id,
            'taxonomy' => $taxonomy,
            'ai_owned' => (bool) $description_is_ai_owned,
        ]);
        return;
    }

    // ۳. بررسی لیست برندها یا کلمات مستثنی
    $raw_kw = get_option('evazar_ai_taxonomy_exclude_keywords', 'متفرقه, miscellaneous, عمومی');
    $kw_arr = array_filter(array_map('trim', explode(',', (string)$raw_kw)));
    $slug = $term->slug ?? '';
    foreach ($kw_arr as $kw) {
        if (!empty($kw) && (mb_stripos($name, $kw) !== false || stripos($slug, $kw) !== false)) {
            wp_send_json_success(['status' => 'skipped_excluded', 'message' => 'در لیست مستثنی']);
            return;
        }
    }
    
    if (!function_exists('evazar_taxonomy_seo_enqueue_term')) {
        require_once plugin_dir_path(__FILE__) . 'taxonomy-seo-queue.php';
    }
    // This admin tool queues work; it never sends a singleton Gemini request. The queue batches
    // only same-type terms (brand with brand, category with category) and preserves manual text.
    $queued = evazar_taxonomy_seo_enqueue_term($term_id, $taxonomy, $force_ai_rewrite, 0, true);
    if ($queued) {
        wp_send_json_success([
            'status' => 'queued',
            'message' => 'مورد به صف سئوی همین نوع اضافه شد؛ درخواست Gemini فقط وقتی حداقل دو مورد هم‌نوع آماده باشند ارسال می‌شود.',
            'term_id' => $term_id,
            'taxonomy' => $taxonomy,
            'batch_minimum' => 2,
        ]);
        return;
    }
    $current_term = get_term($term_id, $taxonomy);
    $current_desc = $current_term && !is_wp_error($current_term) ? (string) $current_term->description : '';
    $current_ai_owned = function_exists('evazar_term_description_is_recorded_ai_content')
        ? evazar_term_description_is_recorded_ai_content($term_id, $current_desc)
        : false;
    $current_plain = trim(wp_strip_all_tags($current_desc));
    $current_fallback = function_exists('evazar_is_taxonomy_fallback_description') && evazar_is_taxonomy_fallback_description($current_desc);
    $message = (get_term_meta($term_id, '_evazar_lock_seo_content', true) === 'yes')
        ? 'محتوا قفل دستی دارد؛ هیچ تغییری اعمال نشد.'
        : (($current_plain !== '' && !$current_fallback && !$force_ai_rewrite)
            ? ($current_ai_owned ? 'محتوای معتبر AI از قبل وجود دارد؛ بدون تغییر حفظ شد.' : 'توضیحات موجود دستی یا غیرقابل‌تأیید است؛ بدون تغییر حفظ شد.')
            : 'مورد در صف پردازش است یا در حال حاضر واجد شرایط صف نیست.');
    wp_send_json_success(['status' => 'skipped_existing', 'message' => $message, 'term_id' => $term_id, 'taxonomy' => $taxonomy]);
    return;


}
