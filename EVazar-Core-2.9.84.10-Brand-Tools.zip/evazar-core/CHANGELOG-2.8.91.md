# EVazar Core 2.8.91 — Gemini quota and worker failover correction

- Separates per-Worker temporary HTTP 429/503 cooldowns from daily quota cooldowns.
- A non-daily HTTP 429 no longer stops the entire Gemini route immediately: the affected Worker is cooled down using Retry-After/retryDelay and the next eligible configured Worker is tried.
- A daily quota 429 cools only the affected Worker; a global daily stop is set only when all configured Workers are individually daily-quota blocked.
- When all eligible Workers are temporarily limited/unavailable, queue items are deferred until the earliest valid retry time without incrementing product retries.
- Adds diagnostic logging of safe Google quota identifiers/status, without storing API keys, prompts, or raw response bodies.
- Logs queue-level quota pauses even when no HTTP request is sent, with event de-duplication to avoid log spam.
- Separates concurrent-request cooldown from provider rate-limit cooldown and corrects queue messages so a concurrency pause is not reported as daily quota exhaustion.
- Migrates a legacy global 429 cooldown to a per-Worker cooldown when the prior operation log identifies the affected endpoint and another configured Worker is available.
- Adds a per-Worker status table to the Gemini operational report.
- No product schema, theme, image proxy, product gallery, or unrelated import behavior changed.
