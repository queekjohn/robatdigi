# EVazar Core 2.9.56 — Release Files

- `EVazar-Core-2.9.56-Admin-Requeue-Capacity-Guard.zip`: installable WordPress plugin.
- `EVazar-Worker-1.13.7-Strict-Batch-Only.js`: source of the unchanged Worker for audit/reference only; do not redeploy for this Core-only change.
- `CHANGELOG-2.9.56.md`: change summary.
- `QA-2.9.56-Admin-Requeue-Capacity-Guard.md`: local QA report and limitations.
- `SAFE-UPGRADE-2.9.56.md`: safe-upgrade steps.
- `RECHECK-2.9.56-1.13.7.md`: Core/Worker compatibility recheck.
