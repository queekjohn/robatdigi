# Local QA — EVazar Core 2.9.84.1 / Worker 1.13.13.1

Static/local checks performed after patching:
- PHP syntax checks for all six top-level Core PHP files and relevant bundled includes.
- JavaScript syntax check for the external Worker and the Core-bundled Worker.
- ZIP integrity checks for Core, Worker, and combined release.
- Static assertions that product-batch ceilings are 15 across UI, queue partitioning, parallel REST payload guard, context/dispatch guards, headers, logs, embedded Worker and external Worker.
- Parser unit cases: valid object; fenced JSON; prefix/suffix prose around valid JSON; escaped quotes/braces inside strings; malformed JSON rejection; incomplete/truncated JSON rejection; DKP output validation and missing product identification.
- External and bundled Worker source hashes match exactly.

Not tested: production WordPress/database, real Cloudflare deployment, live Gemini responses or live queue processing.
