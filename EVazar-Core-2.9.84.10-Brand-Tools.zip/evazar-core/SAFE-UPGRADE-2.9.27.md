# Safe upgrade — EVazar Core 2.9.27 / Worker 1.12.6

1. Back up the current EVazar Core plugin and the database before installing.
2. Replace the plugin with `EVazar-Core-2.9.27-No-Grounding.zip`. Do not delete the plugin manually first.
3. Deploy Worker 1.12.6 to each of the three configured Gemini Worker services. Preserve existing `GEMINI_API_KEY`, `EVAZAR_INTERNAL_TOKEN`, routes, domains, and bindings. Do not change the image CDN domain or product/image routes.
4. Restore all three Gemini Worker URLs to Core's Worker list after all three are updated and pass the version check.
5. Confirm the AI settings no longer show the taxonomy Google Search grounding option.
6. Test only taxonomy term ID 1842 (washing machine Daewoo). The report should no longer contain research-engine/source-count fields; it should show source method, source characters, output characters, final status, and errors.
7. Confirm public taxonomy description is HTML text only and includes no source URL or source-block markers.
8. Product import/rewrite remains unchanged. Do not run batch taxonomy processing until the one-term test is accepted.

Rollback: restore the saved previous Core ZIP and the previously saved Worker scripts. Restore the Worker URLs/settings if they were changed during testing.
