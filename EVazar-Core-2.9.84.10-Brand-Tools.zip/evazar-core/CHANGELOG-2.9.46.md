# EVazar Core 2.9.46 — Gemini recovery hardening

- Recovered stored HTTP 429 responses are classified as quota cooldown or rate limiting instead of leaving the ledger indefinitely uncertain.
- The queue receives an explicit `resume_at` and returns affected rows to `pending` without incrementing retry counts.
- Recovered definitive non-429 4xx responses release the Core uncertainty lock while the Worker continues to replay the same stored response for that stable request ID.
- Stored 5xx responses remain fail-closed and are not blindly reissued.
- Bundled Worker is 1.13.6 and includes delayed retry support for definitive 429 responses.

This package has static validation only. It has not been deployed to Cloudflare or tested against the production WordPress database.
