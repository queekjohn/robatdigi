# Safe upgrade — Core 2.9.46 + Worker 1.13.6

1. Back up the current Core plugin and database.
2. Deploy Worker 1.13.6 to each configured Gemini Worker. Keep existing `EVAZAR_INTERNAL_TOKEN` and `GEMINI_API_KEY` secrets unchanged.
3. Confirm the Durable Object binding `EVAZAR_GEMINI_IDEMPOTENCY` points to `GeminiIdempotencyDO` and the migration is active. A JS upload alone is not enough.
4. Smoke-test authenticated status lookup for a random request ID: it should return `status: not_found`. Do not use a real production request ID for testing.
5. Install Core 2.9.46 after Worker checks pass.
6. Run one small batch and inspect the Gemini event log. Do not restart the large queue until the test confirms successful replay and 429 cooldown behavior.

Rollback: restore the Core backup. Do not remove the Durable Object namespace or binding while unresolved request IDs may still exist.

Validation limitation: no live Cloudflare, Gemini API, or production database integration test was possible during build.
