# Safe upgrade — Core 2.9.35 / Worker 1.13.4

1. Back up the WordPress database and current Worker source.
2. Worker 1.13.4 only changes the version marker/header compared with the already tested Worker 1.13.3. If 1.13.3 is already deployed and healthy, redeploying the Worker is optional.
3. Update Core to 2.9.35 without deleting the existing plugin first.
4. The manual ChatGPT panel and Tavily UI/actions are removed. Old Tavily options and research metadata are cleaned up once; public descriptions and product rows are not altered.
5. On direct upgrade from 2.9.33, category/brand AI stays disabled until an administrator explicitly enables it. If 2.9.34 was already installed, the current setting is preserved. Verify the chosen engine/quota before enabling.
6. Do not use the batch rewrite button during initial testing. Test only one category/brand after selecting an acceptable provider.
7. Product prompt v7, product importer, price/image paths, and existing Gemini/OpenAI API proxy routes are preserved.
