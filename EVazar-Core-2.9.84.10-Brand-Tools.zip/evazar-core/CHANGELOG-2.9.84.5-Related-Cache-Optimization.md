# EVazar Core 2.9.84.5 — Related Products Cache Optimization

## Fix
- Increased related products ranking query transient TTL from 60 seconds to 12 hours (`12 * HOUR_IN_SECONDS`) in `product-index.php`.
- Eliminates repeated heavy relevance-score SQL ranking joins during uncached single product page visits.
- Preserves existing targeted cache invalidation and all Core 2.9.84.4 features.
