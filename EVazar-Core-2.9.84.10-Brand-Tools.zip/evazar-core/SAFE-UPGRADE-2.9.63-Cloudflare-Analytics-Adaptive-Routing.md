# Safe upgrade — 2.9.63

1. Take a database + plugin backup before deploying to the live site.
2. Upload/replace the `evazar-core` plugin folder with the contents of this package. Do not change the legacy Worker URL or `EVAZAR_INTERNAL_TOKEN`.
3. Confirm both primary Worker URLs remain listed, and each account ID is paired with its matching Worker URL in the Analytics accounts field. Keep one matching, read-only Analytics API token per account.
4. Open the Core settings page once after upgrade; this schedules the Analytics polling cron. Press the Analytics refresh button once to seed today's usage snapshot.
5. Review the panel's Analytics count, Core count, and effective routing usage per Worker. When an account reaches the threshold, Core will stop routing new managed requests to all mapped Worker URLs in that account for the rest of the UTC day.

Rollback: restore the prior `evazar-core` plugin version. The legacy single Worker URL and the existing settings are retained for compatibility.

No live deployment or real Cloudflare API call is included in this package build.
