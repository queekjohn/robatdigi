# QA checklist — Core 2.9.27 / Worker 1.12.6

- [ ] PHP syntax passes for all PHP files.
- [ ] The settings screen has no taxonomy Google Search / web research checkbox.
- [ ] `evazar_call_gemini_engine()` does not attach `tools` or taxonomy-specific grounding headers.
- [ ] Grounding metadata parsing and research fields are absent from the active admin processing report.
- [ ] Worker 1.12.6 deletes `tools` and `toolConfig` from Gemini request bodies, even if sent by an older Core.
- [ ] Worker response does not expose `X-Evazar-Google-Search-Tool`.
- [ ] Worker GET health response reports version 1.12.6 and never reveals secret values.
- [ ] Category term 1842 is tested alone; failed output preserves the previous description.
- [ ] Product prompt, import, price-sync, image routes, cache behavior, and `img.evazar.ir` are unchanged.
