# EVazar Core 2.9.23 — Prevent taxonomy source text from leaking

- Taxonomy AI responses now have an explicit cleanup step for echoed source-block delimiters.
- If the model repeats the complete verified source text without delimiters, the response is rejected and the existing term description is preserved.
- Category/brand prompts and product prompt behavior are otherwise unchanged from 2.9.22.
