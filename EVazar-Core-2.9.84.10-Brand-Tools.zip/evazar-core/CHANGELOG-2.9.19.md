# EVazar Core 2.9.19 — Reliable Category/Brand Source Mapping

- Normalizes and saves each breadcrumb's Digikala source URL separately; does not reuse the final breadcrumb URL for all terms.
- Adds a source-map revision marker and lazily repairs older category paths from product breadcrumbs/brand identity without changing WordPress category names, slugs or hierarchy.
- Stores the exact filtered landing URL for generated category+brand terms, such as `/search/category-washing-machines/daewoo/`.
- Adds a validated exact public-page fallback through Worker `source_page`; filtered child categories never silently reuse the parent's API SEO text.
- Guarantees the fetched source is included even if an older custom category/brand prompt lacks `{source_content}`; mandatory source-fidelity rules are applied after custom prompts.
- Distinguishes no-source, unavailable API, AI error, invalid output, save failure, manual/locked content, and successful generation using term metadata.
- Adds ownership verification for prior AI output so source-fix retries can refresh verifiably AI-generated copy without overwriting edited/manual descriptions.
- Fixes source URL resolution in single-term processing and makes the batch report attempted/successful/no-source/error counts rather than conflating skips with success.
- Bundles Worker 1.12.1 with Core; product schema, image routing, price sync and the category taxonomy structure remain unchanged.
