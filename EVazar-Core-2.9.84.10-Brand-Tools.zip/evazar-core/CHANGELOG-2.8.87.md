# EVazar Core 2.8.87

- Adds server clock diagnostics (Pacific, UTC, Unix epoch) to the Gemini operations page.
- Displays the next calculated Pacific reset and warns when the host clock is likely behind the quota reset.
- Does not clear cooldowns or change Gemini request/quota behavior.
