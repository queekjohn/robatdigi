# Local QA — EVazar Core 2.9.84.2 / Worker 1.13.13.1

## Passed locally
- `php -l` passed for all six top-level Core PHP files.
- `node --check` passed for both the external Worker and the Core-bundled Worker.
- Runtime unit harness extracted and exercised the actual adaptive-capacity function:
  - 1 eligible Worker → 15 products
  - 2 → 30
  - 3 → 45
  - 4 → 60
  - 5 → 75
  - 0 eligible Workers → 0
  - explicit lower cap and lower parallelism are respected
- Runtime unit harness extracted and exercised the actual partitioner: 75 inputs produce exactly five chunks of 15, with no unpaired tail.
- Static checks verify the queue ceiling and admin input cap are 75, the one-time migration sets the per-run option to 75, the per-request size remains 15, and safe fallback guards remain in place.
- External and bundled Worker source hashes match exactly.
- ZIP integrity checks pass for Core, Worker, and combined release.

## Deliberate safety fallback
- If cURL-multi is unavailable, a run is capped to one 15-product batch rather than claiming 75 entries for serial processing.
- If PHP cannot extend runtime to at least 180 seconds, a run is capped to one 15-product batch.
- Fewer than five eligible Workers yield the adaptive capacity (15/30/45/60) instead of assuming all five are usable.

## Not tested
- No production WordPress database, production PHP runtime, live Cloudflare publish, or actual Gemini API calls were performed.
