# EVazar Core 2.9.73 — Stock Sync Logs

- Added a dedicated admin page under Products → گزارش قیمت و موجودی.
- Stores the latest 100 automatic price/stock check events, including timestamp, product, SKU/DKP, previous/current price and stock state, result, reason, and duration.
- Added status filters and an explicit admin-only, nonce-protected clear action.
- Logging is independent of the product import queue and does not issue additional Worker requests.
- Keeps the existing 2.9.72 chunked stock-sync workflow.
