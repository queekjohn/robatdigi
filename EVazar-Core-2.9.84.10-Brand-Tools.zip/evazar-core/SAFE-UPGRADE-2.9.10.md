# Safe upgrade notes — EVazar Core 2.9.10

Compatible with EVazar Theme 1.12.86 and existing image Worker 1.11.8. Replace the existing `evazar-core/` folder after backing it up. No schema migration is included. Static checks and browser-simulated image failures were run; production VPN transitions still need testing on real devices.
