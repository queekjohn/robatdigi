# QA — EVazar Core 2.9.59

- Added read-only Cloudflare GraphQL Workers Analytics query for each configured account.
- Configuration rows use `32-character Account ID|https://worker-url.workers.dev`; the Worker URL must also exist in the primary Worker pool.
- Uses a separate Cloudflare Analytics API token; do not reuse `EVAZAR_INTERNAL_TOKEN`. Token needs read access to Workers Analytics for every configured account.
- Counts account-level Workers invocation analytics for the current UTC day; analytics can lag and are not a guaranteed real-time or billable quota meter. Keep the local Core budget enabled.
- No credentials were supplied; no live API call, WordPress runtime test, or production deployment was performed.
- PHP syntax checked locally; preserve a backup before installing.
