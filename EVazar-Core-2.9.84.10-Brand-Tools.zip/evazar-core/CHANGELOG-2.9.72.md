# EVazar Core 2.9.72 — Safe Stock Sync Chunks

- Stock/price synchronization now processes at most two products per PHP request and continues through separate WP-Cron events.
- Preserves the existing 5-minute stock-sync schedule and up-to-50-product cycle snapshot.
- Adds a separate last-attempt timestamp so repeated Worker/source failures do not permanently starve later products.
- Adds last-batch outcome counters in the `evazar_stock_batch_last_run` option.
- Does not modify product-import queue handlers, import locks, Worker code, or product creation behavior.
