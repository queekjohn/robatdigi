# EVazar Core 2.9.16 — Worker Specification Contract Alignment

## Changes

- Aligns the bundled Worker with the standalone Worker release 1.11.9.
- Worker specification extraction accepts `title` or `name`, and `values` or `value`; scalar and array values are handled conservatively.
- Stops stripping trailing punctuation from specification values at the Worker layer, which could alter meaningful model identifiers or values.
- Bumps the Worker product-cache namespace to `v1.11.9` so previously cached product JSON cannot mask the improved extraction behavior.
- Core also accepts alternate `name`/`label` and `values` fields from Worker payloads; empty `title`/`value` fields fall back safely.
- Direct API fallback now uses `value` when `values` exists but is empty, improving parity with Worker extraction.
- Shared Core-side normalization/storage remains unchanged and compatible with `_evazar_key_features`.

## Scope

No database schema, scheduled task, queue, product identity, price, AI model, theme, or SEO changes. Existing product records are not bulk-modified. New behavior takes effect on subsequent imports or product re-imports.
