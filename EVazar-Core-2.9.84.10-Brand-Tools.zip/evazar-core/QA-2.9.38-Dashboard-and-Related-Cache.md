# QA — Core 2.9.38 dashboard and related-products performance

## Dashboard widget
- [x] Uses `wp_dashboard_setup` and is registered only for users with `manage_options`.
- [x] Queue status counts use one aggregate SQL query rather than one full count query per status.
- [x] History query is bounded to the last seven days and uses the existing `imported_at` index.
- [x] Statistics are transient-cached for 30 seconds and cache is invalidated by successful-import recording and admin queue actions.
- [x] Product total is explicitly labelled as published `evazar_product` items.
- [x] Links target the existing queue filters/product list; no new admin action or permission path was added.
- [x] No new table, index, cron event, API endpoint, or external request.

## Related-product ranking
- [x] Old three-argument helper calls remain valid and default to offset zero.
- [x] Final sorting remains deterministic by relevance, indexed post date, and product ID.
- [x] Ranking results are cached for 60 seconds; initial cache window is 120 IDs, then grows as the offset advances, capped at 500.
- [x] Offsets are applied to the final ranked ID list, not to an oversized candidate window; a database error returns no IDs and is not cached.
- [x] In-stock filtering and category/brand scoring logic remain unchanged.
- [x] No WooCommerce APIs or product-index schema changes.

## Static validation
- PHP syntax checks are required for all PHP files in the Core ZIP.
- Worker JS is unchanged and not part of this release.
- ZIP integrity and package root are verified after packaging.

## Limits
- Not live-tested against the production WordPress database or browser. Transient cache freshness, SQL timing, query plan/index use, and actual dashboard rendering must be confirmed on the site after deployment.
