# EVazar Core 2.9.82 — Taxonomy Source Retry Next-Cycle Fix

- Source preflight failures now retry from the next queue cycle: 60 seconds after the first failure, then 2m, 4m, 8m, capped at 15m after repeated failures. The former 12-hour source delay is removed.
- One-time migration detects queued source-preflight errors previously scheduled more than two minutes out and moves only those rows to a near-term retry, then schedules the matching category/brand nudge.
- Gemini quota/provider `resume_at` handling, missing-key/configuration delay, non-source temporary retry policy, category/brand separation, singleton coalescing, product import, and Worker 1.13.13 contract remain unchanged.
- Migration is idempotent and does not clear retry attempts or change existing term descriptions/content.
