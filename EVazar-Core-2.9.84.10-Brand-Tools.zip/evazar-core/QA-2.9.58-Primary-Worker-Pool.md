# QA — EVazar Core 2.9.58 Primary Worker Pool

## Scope
- Extensible URL pool for primary Worker calls: product import, raw price/product lookup, Digikala source-page proxy, taxonomy API, and category+brand API.
- Round-robin cursor; atomic per-URL daily reservation; configurable 1,000–99,000 daily budget (default 85,000); UTC reset.
- GET failover on transport errors, HTTP 429, auth/route errors, and transient server errors.
- Legacy single-URL setting and existing fallback behavior retained. Gemini Worker logic and image-delivery logic are unchanged.

## Static validation
- PHP syntax checked for `evazar-core.php` and `importer.php`.
- Diff review against 2.9.56 confirms unrelated Gemini, live-price, taxonomy-log, and cache behavior is preserved.
- Zip integrity, package structure, and SHA-256 checksums verified.

## Operational caveats
- Each URL intended to add Free quota must belong to a different Cloudflare account. Two URLs in one account share the same account quota.
- The budget counts only requests sent by this WordPress installation; it cannot see traffic from other scripts or services in the same Cloudflare account. Leave enough headroom or lower the budget if other traffic exists.
- No live WordPress/Cloudflare deployment or end-to-end API test was performed.
