> Historical QA for 2.9.26. The Google Search grounding feature described here was removed in 2.9.27. Use `QA-2.9.27-Removal-Grounding.md` for current behavior.

# QA — Core 2.9.26 / Worker 1.12.5

## Static checks
- Core request body adds `tools: [{google_search: {}}]` only for enabled taxonomy research.
- Core labels taxonomy requests with authenticated-purpose headers and a positive term ID.
- Worker only forwards the built-in `google_search` tool when both taxonomy headers are valid.
- Worker strips tool configuration from non-taxonomy Gemini requests and any extra tools.
- Worker forwards the native Gemini JSON response unchanged and exposes only safe diagnostic headers.
- Worker remains secured by `X-Evazar-Internal-Token`; the Gemini API key remains a Worker Secret.
- Core embedded Worker source is byte-identical to standalone Worker source.
- PHP and JS syntax checks pass; mocked Worker tests cover authorized taxonomy, product/non-taxonomy, missing term ID and invalid JSON cases.

## Live verification still required
- Deploy Worker 1.12.5 to all Gemini Worker URLs configured in Core (currently three) and verify `X-Evazar-Worker-Version: 1.12.5` from each instance.
- Install Core 2.9.26 and run a single-term test on term ID 1842.
- Confirm the operations log includes `google_search_tool_forwarded`, and inspect returned search metadata. A forwarded tool does not guarantee Google actually executed a search; verify grounding metadata.
- Confirm public category description contains no raw source block, URLs, citations or grounding metadata.
- Do not run bulk processing until the single-term test passes.
