# Safe upgrade — EVazar Core 2.9.54

1. Take a current WordPress files/database backup, or preserve the current Core ZIP for rollback.
2. In WordPress Admin, open **Plugins → Add New Plugin → Upload Plugin** and upload `EVazar-Core-2.9.54-Live-Price-Cache-Optimization.zip`.
3. If WordPress offers it, choose **Replace current with uploaded**.
4. Confirm the active EVazar Core version is `2.9.54`.
5. Check a product page: a successful result should be reusable for 120 seconds from the local transient; scheduled price/stock sync must remain enabled and force-fresh.
6. No Worker deployment, Gemini API-key change, or secret change is required. Worker remains `1.13.7`.

Rollback: reinstall the preserved prior Core ZIP if the product-page inquiry has unexpected behavior.
