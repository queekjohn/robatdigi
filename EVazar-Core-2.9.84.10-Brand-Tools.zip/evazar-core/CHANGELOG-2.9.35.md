# EVazar Core 2.9.35 — Clean no-research workflow

- Removes the manual ChatGPT copy/paste UI and related AJAX actions.
- Removes the active external-research UI/actions; the old Tavily settings, transient cache, and research metadata are cleaned up once.
- Restores the normal single-term and optional batch taxonomy processor, while leaving category/brand AI disabled by default on direct upgrade from 2.9.33 to prevent surprise API calls.
- If 2.9.34 was already installed, the currently selected taxonomy AI toggle is preserved.
- The standard authenticated Gemini/OpenAI API proxies remain for existing Core AI workflows; they are not a ChatGPT subscription login.
- Product prompt v7, product-import flow, price/image handling, and product-specific processing are unchanged.
