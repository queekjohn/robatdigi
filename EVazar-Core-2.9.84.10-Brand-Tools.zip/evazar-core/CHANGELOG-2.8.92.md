# EVazar Core 2.8.92 — Import History (Last 24 Hours)

- Adds a new Import Queue tab: «محصولات وارد شده ۲۴ ساعت گذشته».
- Records successful queue imports in a dedicated indexed history table, storing one most-recent successful import per DKP.
- The history is independent of the current queue status and is preserved when queue items are requeued or the queue itself is cleared.
- Shows the latest 50 items with Digikala URL, successful import time, product ID, and an edit link when the product is available.
- One-time best-effort backfill from current completed queue records updated within the last 24 hours, without guessing older/requeued timestamps.
- Keeps the existing four queue status filters and their processing behavior unchanged.
