# Safe upgrade — EVazar Core 2.9.77

1. Back up the current `evazar-core` plugin folder and the WordPress database.
2. Replace the installed plugin folder with `evazar-core/` from this ZIP. This is a Core-only update from 2.9.76; do not redeploy the unchanged Worker script.
3. Keep all existing Worker URLs, tokens, and daily-budget settings unchanged. No token or secret belongs in the source code.
4. The update separates cooldowns by request purpose. A generic/import/AI-proxy cooldown will no longer block the `stock_sync` request channel. Shared Cloudflare account-level daily budget protection remains active.
5. Run the next scheduled price/stock cycle and review its logs. If a Worker returns HTTP 502 from the stock-sync endpoint itself, that Worker will still receive a stock-sync-only temporary cooldown; if every configured endpoint actually returns 502, the batch will safely defer and retain stored price/stock until retry. This update separates channels; it does not repair an underlying Worker runtime or upstream failure.
6. Confirm a successful HTTP 200 is logged as `موفق` or `بدون تغییر`, and a temporary all-worker failure is logged as deferred rather than falsely changing availability.

Rollback: restore the backed-up plugin directory. Existing generic cooldown transients are retained for their original channel; stock sync uses its independent namespace and does not need manual transient deletion.
