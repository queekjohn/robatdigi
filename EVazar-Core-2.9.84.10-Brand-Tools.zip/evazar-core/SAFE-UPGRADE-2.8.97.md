# Safe upgrade notes — EVazar Core 2.8.97

## Scope
This build only changes the product import identity/locking path. It does not delete, merge, unpublish, rename, or otherwise modify existing products automatically. It does not execute database migrations.

## Required safe deployment
1. Back up the live database and current `evazar-core` plugin directory.
2. Install the plugin folder from this ZIP as `evazar-core` (keep the directory name unchanged).
3. Run one manual import for a known existing DKP and confirm the existing post ID is updated rather than a new post created.
4. If two requests for the same DKP overlap, the second should stop before Worker/Gemini requests with `DKP_IMPORT_IN_PROGRESS`; let the normal retry/manual reattempt run after the first completes.
5. Confirm the import log contains no `DKP_IMPORT_LOCK_UNAVAILABLE` or `DKP_LOOKUP_FAILED` events.

## Important
The database backup previously audited contains two published posts (IDs 2459 and 2460) sharing DKP `22044713`. This guard will deterministically select the oldest published match (expected ID 2459 in that snapshot) for future importer updates, and logs the conflicting IDs. It deliberately leaves both existing records untouched. Review their terms, image metadata, SEO metadata, and inbound references before manually retiring the duplicate; do not delete a post based only on title/SKU equality.

## Validation performed on this package
- PHP syntax lint on all PHP files.
- Static checks that importer calls go through the lock wrapper, product lookup supports SKU/index/URL matches, negative lookup caching is removed, and no deletion/merge SQL is introduced.
- ZIP integrity test.

A WordPress/MariaDB runtime or staging site was not available here, so deployment must be validated on staging before production.
