# Safe upgrade — EVazar Core 2.9.20

1. Back up the current Core plugin ZIP and deployed main Worker script.
2. Deploy Worker 1.12.4 to the existing main Worker URL. Preserve all Secrets, bindings, routes, custom domains, and environment values.
3. Test the dedicated category+brand API proxy URL from `README-DEPLOY.md`. Proceed only if it returns HTTP 200 JSON and category/brand diagnostic headers match.
4. Install Core 2.9.20. Do not launch bulk taxonomy content generation.
5. Run one controlled generation attempt for the existing `ماشین لباسشویی دوو` taxonomy term.
6. Verify term metadata: `_evazar_ai_content_source_method` should be `api_category_brand_seo_content`; `_evazar_ai_content_source_chars` must be above zero; status should end in `generated` or a clearly recorded AI/save error.
7. Confirm `_evazar_ai_content_source_url` points to `/search/category-washing-machines/daewoo/`, and manually review the saved HTML.
8. If the source method is not recorded or source character count remains zero, stop and share the source method/error, HTTP response, and Worker version. Do not start batch processing.
9. Rollback by restoring the previous Core plugin and main Worker script from backups.
