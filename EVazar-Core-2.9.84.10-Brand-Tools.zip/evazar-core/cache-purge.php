<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Targeted public page-cache invalidation for EVazar.
 *
 * With the LiteSpeed Cache WP plugin installed, use its documented URL-purge API.
 * Without it, send LiteSpeed Web Server's native X-LiteSpeed-Purge response header.
 * We never issue a wildcard/full-cache purge here.
 */
if (!defined('EVAZAR_LSCACHE_PURGE_BATCH_LIMIT')) {
    define('EVAZAR_LSCACHE_PURGE_BATCH_LIMIT', 60);
}

function evazar_lscache_normalize_purge_path($url) {
    $url = trim((string) $url);
    if ($url === '' || strpos($url, "\r") !== false || strpos($url, "\n") !== false) return '';

    $parts = wp_parse_url($url);
    if (!is_array($parts)) return '';

    $home = wp_parse_url(home_url('/'));
    if (!is_array($home)) return '';

    if (!empty($parts['host'])) {
        $url_host = strtolower((string) $parts['host']);
        $home_host = strtolower((string) ($home['host'] ?? ''));
        $url_host = preg_replace('/^www\./i', '', $url_host);
        $home_host = preg_replace('/^www\./i', '', $home_host);
        if ($url_host === '' || $url_host !== $home_host) return '';
        if (!empty($parts['scheme']) && !in_array(strtolower((string)$parts['scheme']), ['http', 'https'], true)) return '';
    } elseif (strpos($url, '/') !== 0) {
        return '';
    }

    $path = isset($parts['path']) ? (string) $parts['path'] : '/';
    if ($path === '' || $path[0] !== '/' || strpos($path, "\0") !== false || strpos($path, '\\') !== false) return '';

    // Normalize percent-encoded and Persian path segments exactly as a browser URL path.
    $decoded = rawurldecode($path);
    $segments = explode('/', $decoded);
    foreach ($segments as $segment) {
        if ($segment === '.' || $segment === '..') return '';
    }
    $encoded_segments = array_map('rawurlencode', $segments);
    $normalized = implode('/', $encoded_segments);
    if ($normalized === '') $normalized = '/';
    if ($normalized[0] !== '/') $normalized = '/' . $normalized;
    return $normalized;
}

function evazar_lscache_send_purge_path($path) {
    $path = evazar_lscache_normalize_purge_path($path);
    if ($path === '' || headers_sent() || PHP_SAPI === 'cli') return false;

    // 1. Native LiteSpeed Web Server purge by exact URL path; false appends repeated purge headers.
    // This is processed directly by LiteSpeed Web Server without generating noisy admin notices.
    header('X-LiteSpeed-Purge: url=' . $path, false);

    // 2. If the LiteSpeed Cache plugin is active, register the exact URL tag silently via 'litespeed_purge'
    // rather than 'litespeed_purge_url' (which triggers Admin_Display::succeed and spams the WP Admin UI).
    if (defined('LSCWP_V') && has_action('litespeed_purge')) {
        do_action('litespeed_purge', 'URL.' . home_url($path));
    }

    return true;
}


function evazar_lscache_schedule_purge_queue() {
    // Schedule from any entry point. If a CLI cron invokes the event, the processor
    // preserves the queue without rescheduling; the next HTTP request then re-arms it.
    if (!wp_next_scheduled('evazar_lscache_process_purge_queue')) {
        wp_schedule_single_event(time() + 30, 'evazar_lscache_process_purge_queue');
    }
}

function evazar_lscache_rearm_purge_queue() {
    if (PHP_SAPI === 'cli') return;
    $queue = get_option('evazar_lscache_purge_queue', []);
    if (is_array($queue) && !empty($queue)) {
        evazar_lscache_schedule_purge_queue();
    }
}
add_action('init', 'evazar_lscache_rearm_purge_queue', 20);

function evazar_lscache_store_purge_queue($paths) {
    $paths = array_values(array_unique(array_filter(array_map('evazar_lscache_normalize_purge_path', (array) $paths))));
    if (!$paths) return;

    $queue = get_option('evazar_lscache_purge_queue', []);
    if (!is_array($queue)) $queue = [];
    // Put just-requested paths first so a full safety queue does not discard the newest
    // homepage/category invalidations in favor of old entries.
    $queue = array_values(array_unique(array_merge($paths, $queue)));

    // Guard storage growth in case server headers remain unavailable for a long time.
    if (count($queue) > 2000) {
        $queue = array_slice($queue, 0, 2000);
        error_log('[EVazar Cache] Native LiteSpeed purge queue reached its 2000-URL safety limit.');
    }
    update_option('evazar_lscache_purge_queue', $queue, false);
    evazar_lscache_schedule_purge_queue();
}

function evazar_lscache_purge_urls($urls) {
    static $seen_this_request = [];
    $paths = [];
    foreach ((array) $urls as $url) {
        $path = evazar_lscache_normalize_purge_path($url);
        if ($path === '' || isset($seen_this_request[$path])) continue;
        $seen_this_request[$path] = true;
        $paths[] = $path;
    }
    if (!$paths) return ['sent' => 0, 'queued' => 0];

    $sent_count = isset($GLOBALS['evazar_lscache_purge_sent_count']) ? (int)$GLOBALS['evazar_lscache_purge_sent_count'] : 0;
    $sent = 0;
    $queued = [];
    foreach ($paths as $path) {
        if ($sent_count >= EVAZAR_LSCACHE_PURGE_BATCH_LIMIT || !evazar_lscache_send_purge_path($path)) {
            $queued[] = $path;
            continue;
        }
        $sent++;
        $sent_count++;
    }
    $GLOBALS['evazar_lscache_purge_sent_count'] = $sent_count;
    if ($queued) evazar_lscache_store_purge_queue($queued);
    return ['sent' => $sent, 'queued' => count($queued)];
}

function evazar_lscache_process_purge_queue() {
    if (PHP_SAPI === 'cli') {
        // Keep the persistent queue intact. The init hook will re-arm it during a web request.
        return;
    }
    $queue = get_option('evazar_lscache_purge_queue', []);
    if (!is_array($queue) || !$queue) {
        delete_option('evazar_lscache_purge_queue');
        return;
    }

    $queue = array_values(array_unique(array_filter(array_map('evazar_lscache_normalize_purge_path', $queue))));
    $sent_count = 0;
    $remaining = [];
    foreach ($queue as $path) {
        if ($sent_count >= EVAZAR_LSCACHE_PURGE_BATCH_LIMIT) {
            $remaining[] = $path;
            continue;
        }
        if (!evazar_lscache_send_purge_path($path)) {
            $remaining[] = $path;
            continue;
        }
        $sent_count++;
    }

    if ($remaining) {
        update_option('evazar_lscache_purge_queue', array_values(array_unique($remaining)), false);
        evazar_lscache_schedule_purge_queue();
    } else {
        delete_option('evazar_lscache_purge_queue');
    }
}
add_action('evazar_lscache_process_purge_queue', 'evazar_lscache_process_purge_queue');

function evazar_lscache_get_product_archive_urls($post_id) {
    $post_id = absint($post_id);
    if (!$post_id || get_post_type($post_id) !== 'evazar_product') return [];

    $urls = [];
    foreach (['evazar_category', 'evazar_brand'] as $taxonomy) {
        $terms = wp_get_object_terms($post_id, $taxonomy, ['fields' => 'all']);
        if (is_wp_error($terms) || !is_array($terms)) continue;
        foreach ($terms as $term) {
            if (!is_object($term) || empty($term->term_id)) continue;
            $term_url = get_term_link($term, $taxonomy);
            if (is_wp_error($term_url) || !is_string($term_url) || $term_url === '') continue;
            $path = evazar_lscache_normalize_purge_path($term_url);
            if ($path !== '') $urls[] = $path;
        }
    }
    return array_values(array_unique($urls));
}

function evazar_lscache_purge_product_urls($post_id, $include_archives = true, $force = false) {
    $post_id = absint($post_id);
    if (!$post_id || get_post_type($post_id) !== 'evazar_product') return ['sent' => 0, 'queued' => 0];

    $urls = [];
    if ($include_archives) {
        // 1. Homepage Throttle (default 1 hour = 3600s):
        // Prevents continuous robot imports (e.g. 450/hr) from wiping out the homepage cache every few seconds.
        $home_key = 'evz_lsc_purge_th_home';
        $should_purge_home = (bool) $force || (get_transient($home_key) === false);
        if ($should_purge_home) {
            $urls[] = home_url('/');
            $home_ttl = (int) apply_filters('evazar_lscache_home_purge_throttle', 3600);
            if ($home_ttl > 0) {
                set_transient($home_key, time(), $home_ttl);
            }
        }

        // 2. All-Products Shop Archive Throttle (/product/, default 1 hour = 3600s):
        $shop_key = 'evz_lsc_purge_th_shop';
        $should_purge_shop = (bool) $force || (get_transient($shop_key) === false);
        if ($should_purge_shop && function_exists('get_post_type_archive_link')) {
            $archive_url = get_post_type_archive_link('evazar_product');
            if (is_string($archive_url) && $archive_url !== '') {
                $urls[] = $archive_url;
                $shop_ttl = (int) apply_filters('evazar_lscache_shop_purge_throttle', 3600);
                if ($shop_ttl > 0) {
                    set_transient($shop_key, time(), $shop_ttl);
                }
            }
        }
    }

    // 3. Single product URL: ALWAYS purge immediately on update so changes reflect without delay.
    $product_url = get_permalink($post_id);
    if (is_string($product_url) && $product_url !== '') $urls[] = $product_url;

    // 4. Categories & Brands Archive Throttle (default 30 minutes = 1800s per term):
    // Prevents products in the same category during a batch import from repeatedly invalidating the category archive.
    if ($include_archives) {
        foreach (['evazar_category', 'evazar_brand'] as $taxonomy) {
            $terms = wp_get_object_terms($post_id, $taxonomy, ['fields' => 'all']);
            if (is_wp_error($terms) || !is_array($terms)) continue;
            foreach ($terms as $term) {
                if (!is_object($term) || empty($term->term_id)) continue;
                $term_key = 'evz_lsc_purge_th_t_' . (int) $term->term_id;
                $should_purge_term = (bool) $force || (get_transient($term_key) === false);
                if ($should_purge_term) {
                    $term_url = get_term_link($term, $taxonomy);
                    if (!is_wp_error($term_url) && is_string($term_url) && $term_url !== '') {
                        $urls[] = $term_url;
                        $term_ttl = (int) apply_filters('evazar_lscache_term_purge_throttle', 1800, $term->term_id, $taxonomy);
                        if ($term_ttl > 0) {
                            set_transient($term_key, time(), $term_ttl);
                        }
                    }
                }
            }
        }
    }

    return evazar_lscache_purge_urls($urls);
}

function evazar_mark_product_cache_purge_pending($post_id, $scope = 'archives', $previous_archive_urls = []) {
    $post_id = absint($post_id);
    if (!$post_id || get_post_type($post_id) !== 'evazar_product') return false;
    $scope = ($scope === 'product') ? 'product' : 'archives';
    $current = (string) get_post_meta($post_id, '_evazar_cache_purge_pending', true);
    // A previously requested archive purge must not be downgraded to product-only.
    if ($current === 'archives') $scope = 'archives';
    update_post_meta($post_id, '_evazar_cache_purge_pending', $scope);

    // Keep archive paths from before taxonomy reassignment. When the Product Index
    // sync succeeds, purge both the old and current term pages so removed products
    // disappear from the previous category/brand archives as well.
    $existing_paths = get_post_meta($post_id, '_evazar_cache_purge_pending_urls', true);
    if (!is_array($existing_paths)) $existing_paths = [];
    $new_paths = [];
    foreach ((array) $previous_archive_urls as $url) {
        $path = evazar_lscache_normalize_purge_path($url);
        if ($path !== '') $new_paths[] = $path;
    }
    $all_paths = array_values(array_unique(array_merge($new_paths, $existing_paths)));
    if ($all_paths) {
        update_post_meta($post_id, '_evazar_cache_purge_pending_urls', array_slice($all_paths, 0, 100));
    }
    return true;
}

function evazar_process_product_cache_purge_pending($post_id) {
    $post_id = absint($post_id);
    if (!$post_id || get_post_type($post_id) !== 'evazar_product') return false;
    $scope = (string) get_post_meta($post_id, '_evazar_cache_purge_pending', true);
    if (!in_array($scope, ['product', 'archives'], true)) return false;
    if (!function_exists('evazar_purge_product_cache')) return false;

    // Purge current product/current term paths, then any prior term archives kept
    // from before taxonomy reassignment. The path list is site-local and bounded.
    evazar_purge_product_cache($post_id, $scope === 'archives');
    $previous_paths = get_post_meta($post_id, '_evazar_cache_purge_pending_urls', true);
    if (is_array($previous_paths) && $previous_paths) {
        evazar_lscache_purge_urls($previous_paths);
    }
    delete_post_meta($post_id, '_evazar_cache_purge_pending');
    delete_post_meta($post_id, '_evazar_cache_purge_pending_urls');
    return true;
}

function evazar_lscache_on_product_index_synced($post_id) {
    evazar_process_product_cache_purge_pending($post_id);
}
add_action('evazar_product_index_synced', 'evazar_lscache_on_product_index_synced', 20, 1);

function evazar_lscache_purge_term_archive($term_id, $taxonomy) {
    $term_id = absint($term_id);
    if (!$term_id || !in_array($taxonomy, ['evazar_category', 'evazar_brand'], true)) return;
    $term = get_term($term_id, $taxonomy);
    if (!$term || is_wp_error($term)) return;
    $url = get_term_link($term, $taxonomy);
    if (is_wp_error($url) || !is_string($url) || $url === '') return;
    evazar_lscache_purge_urls([$url]);
}
add_action('created_evazar_category', function($term_id) { evazar_lscache_purge_term_archive($term_id, 'evazar_category'); }, 20, 1);
add_action('edited_evazar_category', function($term_id) { evazar_lscache_purge_term_archive($term_id, 'evazar_category'); }, 20, 1);
add_action('created_evazar_brand', function($term_id) { evazar_lscache_purge_term_archive($term_id, 'evazar_brand'); }, 20, 1);
add_action('edited_evazar_brand', function($term_id) { evazar_lscache_purge_term_archive($term_id, 'evazar_brand'); }, 20, 1);


/**
 * One-time cleanup after installing 2.9.84.4.
 * The previous release did not target the custom post-type archive /product/.
 * Use an uncached admin response to request an exact purge of the homepage and
 * all-products archive once, so the already-stale cache entry is not left behind
 * until the next product import. No wildcard purge is issued.
 */
function evazar_lscache_purge_product_archive_after_9844_upgrade() {
    if (PHP_SAPI === 'cli' || !function_exists('is_admin') || !is_admin()) return;
    if (!function_exists('current_user_can') || !current_user_can('manage_options')) return;
    if (get_option('evazar_lscache_9844_initial_purge_done', false)) return;

    $targets = [home_url('/')];
    if (function_exists('get_post_type_archive_link')) {
        $archive_url = get_post_type_archive_link('evazar_product');
        if (is_string($archive_url) && $archive_url !== '') $targets[] = $archive_url;
    }

    $result = evazar_lscache_purge_urls($targets);
    $issued = (int)($result['sent'] ?? 0) + (int)($result['queued'] ?? 0);
    if ($issued > 0) {
        update_option('evazar_lscache_9844_initial_purge_done', time(), false);
        error_log('[EVazar Cache] Core 2.9.84.4 one-time homepage/product-archive purge requested; sent=' . (int)($result['sent'] ?? 0) . ', queued=' . (int)($result['queued'] ?? 0) . '.');
    }
}
add_action('admin_init', 'evazar_lscache_purge_product_archive_after_9844_upgrade', 5);

/**
 * LiteSpeed Cache Notice Suppression:
 * When LiteSpeed Cache purges URLs during automated robot imports or updates,
 * LiteSpeed can queue admin notices (e.g. "پاکسازی /url ...").
 *
 * We implement a bulletproof 4-layer suppression strategy:
 * Layer 1: Bypass noisy litespeed_purge_url API at origin (handled above in evazar_lscache_send_purge_path).
 * Layer 2: Filter option/transient storage in database.
 * Layer 3: Server-side Output Buffer on admin_notices & all_admin_notices to strip any rendered purge notices.
 * Layer 4: Client-side CSS + DOM MutationObserver in admin_head to eliminate AJAX-injected notices instantly.
 */

// --- Layer 2: Filter and clean database options & transients ---
function evazar_lscache_filter_admin_display_messages($messages) {
    if (!is_array($messages) || empty($messages)) return $messages;
    $filtered = [];
    foreach ($messages as $key => $item) {
        $msg_str = is_array($item) ? ($item['msg'] ?? '') : (string) $item;
        if (strpos($msg_str, '/url ') !== false || strpos($msg_str, 'پاکسازی /url') !== false || strpos($msg_str, 'purge_url') !== false || strpos($msg_str, 'Purged /url') !== false) {
            continue; // Suppress automated URL purge notices
        }
        $filtered[$key] = $item;
    }
    return $filtered;
}
add_filter('option_litespeed.admin_display.messages', 'evazar_lscache_filter_admin_display_messages', 20);
add_filter('option_litespeed_messages', 'evazar_lscache_filter_admin_display_messages', 20);

function evazar_lscache_clean_persisted_admin_notices() {
    foreach (['litespeed.admin_display.messages', 'litespeed_messages'] as $opt) {
        $messages = get_option($opt);
        if (!is_array($messages) || empty($messages)) continue;

        $clean = evazar_lscache_filter_admin_display_messages($messages);
        if (count($clean) !== count($messages)) {
            if (empty($clean)) {
                delete_option($opt);
            } else {
                update_option($opt, $clean, false);
            }
        }
    }
}
add_action('admin_init', 'evazar_lscache_clean_persisted_admin_notices', 1);
add_action('shutdown', 'evazar_lscache_clean_persisted_admin_notices', 999);

// --- Layer 3: Server-side Output Buffering on Admin Notices ---
function evazar_lscache_start_admin_notices_buffer() {
    ob_start('evazar_lscache_filter_admin_notices_html');
}
function evazar_lscache_end_admin_notices_buffer() {
    if (ob_get_level() > 0) {
        ob_end_flush();
    }
}
function evazar_lscache_filter_admin_notices_html($html) {
    if (!is_string($html) || $html === '') return $html;
    $pattern = '/<div[^>]*class=[\'"][^\'"]*notice[^\'"]*[\'"][^>]*>(?:(?!<\/div>).)*?(?:پاکسازی\s*\/url|\/url\s*\/product|\/url\s*\/|Purged\s*\/url)(?:(?!<\/div>).)*?<\/div>\s*/si';
    return preg_replace($pattern, '', $html);
}
add_action('admin_notices', 'evazar_lscache_start_admin_notices_buffer', -99999);
add_action('admin_notices', 'evazar_lscache_end_admin_notices_buffer', 99999);
add_action('all_admin_notices', 'evazar_lscache_start_admin_notices_buffer', -99999);
add_action('all_admin_notices', 'evazar_lscache_end_admin_notices_buffer', 99999);

// --- Layer 4: Client-side CSS + DOM Observer in WP Admin Head ---
function evazar_lscache_suppress_purge_notices_admin_assets() {
    ?>
    <style id="evazar-suppress-purge-notices">
        div.notice:has(p:contains("پاکسازی /url")),
        div.notice.is-dismissible:has([class*="litespeed"]):has(p:contains("/url")),
        .notice-success[data-lscwp-purge="url"] {
            display: none !important;
        }
    </style>
    <script id="evazar-suppress-purge-notices-js">
        (function() {
            function removePurgeNotices() {
                var notices = document.querySelectorAll('.notice, .notice-success, .is-dismissible');
                for (var i = 0; i < notices.length; i++) {
                    var el = notices[i];
                    var txt = el.textContent || '';
                    if ((txt.indexOf('پاکسازی') !== -1 && txt.indexOf('/url') !== -1) || txt.indexOf('Purged /url') !== -1) {
                        el.remove();
                    }
                }
            }
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', removePurgeNotices);
            } else {
                removePurgeNotices();
            }
            if (typeof MutationObserver !== 'undefined') {
                var obs = new MutationObserver(function() {
                    removePurgeNotices();
                });
                obs.observe(document.body || document.documentElement, { childList: true, subtree: true });
            }
        })();
    </script>
    <?php
}
add_action('admin_head', 'evazar_lscache_suppress_purge_notices_admin_assets', 999);


