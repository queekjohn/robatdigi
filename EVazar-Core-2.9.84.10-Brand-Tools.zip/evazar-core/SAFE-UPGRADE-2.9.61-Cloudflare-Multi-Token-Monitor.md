# Safe upgrade — EVazar Core 2.9.61

1. Take a current database and plugin backup before upgrading.
2. Install the Core ZIP using the normal WordPress plugin update flow; do not replace the Worker source for this change.
3. In Core settings, add one line per account in the analytics-token field: `ACCOUNT_ID|API_TOKEN`. Tokens are account-scoped and require Account Analytics → Read.
4. Save settings. Existing single-token configuration is preserved as fallback.
5. Refresh analytics and confirm each account reports independently. Analytics can be delayed and is informational; keep the Core request budget enabled.
