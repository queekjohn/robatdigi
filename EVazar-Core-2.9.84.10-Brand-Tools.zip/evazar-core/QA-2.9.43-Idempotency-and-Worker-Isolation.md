# QA report — Core 2.9.43

## Intended invariants
- A stable request ID has one ledger row, enforced by a verified unique database index.
- If the idempotency ledger table or unique index cannot be created/verified, product batch dispatch fails closed before making an HTTP call.
- Two concurrent calls for the same request ID cannot both acquire the ledger lease.
- Sorted atomic per-DKP options prevent differently shaped concurrent batches from sending overlapping DKPs at the same time.
- Only one active request per configured Worker URL can hold that Worker lock. Different URLs have independent locks.
- `succeeded` requests replay the stored provider response and do not call `wp_remote_post` again.
- A stale `sending` state is changed to `uncertain`; it is never resent automatically.
- Transport failures / generic 503 / 5xx are treated as `GEMINI_OUTCOME_UNKNOWN`; queue items become failed without increasing retries, so a later cron does not automatically repeat the same request.
- After ambiguous outcomes, the affected Worker lock is not released immediately; it remains until the conservative lock timeout, preventing another request from reaching a possibly still-running Worker too quickly.
- Explicit 429 rejections and a Worker response clearly stating that `GEMINI_API_KEY` is missing can advance to another Worker because generation did not take place through that Worker.
- The queue's existing database claim token remains the owner for queue-row finalization.
- Worker 1.13.4 is unchanged and its embedded copy matches the standalone Worker baseline.

## Validation performed in this build
- PHP syntax validation for all five top-level PHP files.
- Static assertions for table/index verification, ledger unique key, stable batch IDs, same-request replay, per-DKP locks, per-Worker locks, ambiguous-outcome fail-closed behavior, and queue no-retry handling.
- Diff check against Core 2.9.42: executable changes are limited to `importer.php`, `queue-manager.php`, and `evazar-core.php`; documentation files added for this version.
- ZIP integrity and plugin-root checks.

## Not performed
- No live WordPress database migration or real Gemini API calls were available in this build environment.
- Simultaneous requests and the newly-created table must be validated on the actual hosting/database before increasing concurrency. WP options locking relies on the site's database uniqueness constraints and should be monitored during the controlled production test.
