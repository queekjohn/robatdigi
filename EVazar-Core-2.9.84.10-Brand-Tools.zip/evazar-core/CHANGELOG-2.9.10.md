# EVazar Core 2.9.10 — image recovery lifecycle coordination

- Fixes image load observation: `load` events from `<img>` do not bubble to `window`; Core now listens on `document` in capture phase so successful retries transition to `loaded`, timers are cleared, and retry budgets reset.
- Retains the Core/theme ownership marker and source-signature synchronization from 2.9.9.
- Keeps bounded scroll recovery from 2.9.8 and coordination with Theme 1.12.86.
- No Worker deployment, database changes, or product-data changes required.
