# EVazar Core 2.9.47 — Reliable queue retry

- Queue failures no longer become terminal solely because five attempts were reached. Failed attempts remain `pending` and are retried with exponential backoff capped at six hours.
- Stale `processing` claims also return to `pending` with capped backoff instead of becoming terminal `failed` after five attempts.
- An unknown Gemini outcome increments the queue retry generation. The next attempt gets a new deterministic request ID, so a missing Durable Object binding cannot permanently replay the same Core ledger `uncertain` row.
- Older uncertain ledger entries stop blocking a fresh retry after the cooldown (at least 120 seconds). This explicitly accepts possible repeat Gemini quota consumption; DKP identity/duplicate checks remain in place.
- The existing Worker 1.13.6 remains compatible and unchanged. Durable Object is optional; no new binding, migration, or database schema change is required.
- Existing rows already marked `failed` are not mass-requeued automatically. Use the existing “retry failed” queue action when you want to retry historical failures.
