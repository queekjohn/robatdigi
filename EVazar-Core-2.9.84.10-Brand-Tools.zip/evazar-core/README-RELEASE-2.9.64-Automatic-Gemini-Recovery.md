# EVazar Core 2.9.64 / Worker 1.13.8 release

- `EVazar-Core-2.9.64-Gemini-Auto-Recovery-Queue-Fix.zip`: WordPress plugin installer.
- `EVazar-Worker-1.13.8-Gemini-Transient-Retry.zip`: standalone Cloudflare Worker deployment source and instructions.
- Queue time calculation now uses WordPress site timezone consistently; retry windows will no longer be compared against PHP-default timezone timestamps.
- Transient upstream 5xx responses are retryable; actual transport ambiguity remains guarded and is auto-retried through the queue after a defined safety period.
- Static and simulated tests passed. Live deployment and live API requests were not performed.
