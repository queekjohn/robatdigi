# EVazar Core 2.9.40 — Gemini product-batch pilot

## Added
- Optional Gemini-only batching for queued product rewrites: multiple prepared product inputs can be sent in one Gemini request.
- Configurable batch size from 2 to 10; default is 5.
- Batch mode is disabled by default and requires explicit enablement in EVazar Affiliate Settings.
- Each generated response must include the exact product DKP. Unknown, duplicate, missing, or empty-review outputs are rejected; only products without a valid batch output fall back to the existing single-product request path.
- Successful responses resume each product through the existing product parser, content sanitization, fresh DKP identity check, product save, indexing, and queue-history handling.
- Gemini operational logs identify `product_import_batch` calls and record the batch size.

## Safety / compatibility
- Batching runs only for queued product imports when AI is enabled and the engine mode is exactly `gemini_only`.
- Manual single-product imports and all other AI engine modes retain the existing single-product pathway.
- Quota/rate-limit/temporary-unavailability errors defer unresolved batch queue rows without incrementing retries and stop further requests for that batch run.
- If the set of product IDs or selected primary record changes between prompt preparation and resume, the item fails closed and is retried instead of applying the response to a changed product identity.
- Only the resume state required by the existing post-AI save path is retained, limiting extra PHP memory use in batch mode.
- No database schema migration or product-table change is required.
- No Cloudflare Worker update is required; the existing Worker request contract is unchanged.
