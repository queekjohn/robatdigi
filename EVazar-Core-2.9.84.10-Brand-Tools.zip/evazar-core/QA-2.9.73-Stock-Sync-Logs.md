# QA — EVazar Core 2.9.73

- PHP syntax validation: run against all PHP files in the release.
- ZIP integrity: checked after packaging.
- Source scope: only `importer.php` logging/UI and `evazar-core.php` plugin version changed relative to 2.9.72, plus changelog/QA notes.
- Log retention: array is truncated to 100 events on each write.
- Access: admin page and clear action require `manage_options`; clear action also validates a nonce.
- Import queue: no queue hooks, queue locks, Worker calls, or import functions changed.
- Live WordPress behavior has not been exercised in this environment.
