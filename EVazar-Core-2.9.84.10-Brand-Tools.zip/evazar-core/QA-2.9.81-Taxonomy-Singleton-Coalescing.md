# QA — EVazar Core 2.9.81 / Worker 1.13.13

## Local tests performed

- PHP syntax: all 6 PHP files in the Core package passed `php -l`.
- JavaScript syntax: standalone Worker and embedded Core Worker passed `node --check`.
- Core queue integration simulation:
  - 1 old/ready category -> exactly 1 `taxonomy_seo_single` call and queue row completes.
  - 2 ready categories -> exactly 1 `taxonomy_seo_batch` call with size 2; both rows complete.
  - Existing non-empty manual description -> no AI call; description remains unchanged.
  - Fresh singleton (<30 seconds) -> waits without consuming an attempt; after window -> singleton request is allowed.
  - In a two-row batch where one has no valid source URL -> valid one proceeds as a controlled singleton; invalid source remains in retry, no Gemini request for that invalid term.
- Worker contract simulation with mocked Gemini `fetch`:
  - valid `taxonomy_seo_single` -> accepted and exactly 1 mocked upstream call.
  - valid 2-item `taxonomy_seo_batch` -> accepted and exactly 1 mocked upstream call.
  - singleton with bad request-ID prefix -> HTTP 400 and 0 upstream calls.
  - batch purpose with size 1 -> HTTP 400 and 0 upstream calls.
  - invalid taxonomy type -> HTTP 400 and 0 upstream calls.
- Embedded Worker and standalone Worker compared byte-for-byte.
- ZIP integrity, package contents, and SHA-256 checked after packaging.

## Behavioral scope

- Categories and brands remain in separate queues and prompts.
- Import only enqueues a taxonomy term when the term is newly created; existing valid descriptions are not re-generated during product import.
- Retries due to missing/invalid source remain scheduled with the existing source backoff. They do not trigger Gemini unless preflight returns usable source text.
- Theme/template does not need a change because taxonomy descriptions and public archive contracts are unchanged.

## Not tested here

No live WordPress database, WP-Cron/hosting scheduler, deployed Cloudflare Worker, or real Gemini account was available in this local environment.
