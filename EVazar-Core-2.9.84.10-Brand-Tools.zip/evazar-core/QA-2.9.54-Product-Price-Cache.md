# QA — EVazar Core 2.9.54 / Worker 1.13.7

## Implemented
- [x] Public AJAX handler `evazar_ajax_live_product_inquiry()` calls `evazar_inquire_product_price($post_id, false)`.
- [x] Successful local result transient TTL is 120 seconds.
- [x] Scheduled event `evazar_sync_stock_batch` still calls `evazar_inquire_product_price((int)$post_id, true)`.
- [x] `fresh=1` is still only added by `evazar_fetch_raw_product_data()` when `force_fresh` is true.
- [x] Plugin header and parallel-batch User-Agent use `2.9.54`; Worker remains `1.13.7`.

## Local checks
- PHP syntax checks passed for all PHP files in the plugin.
- Static assertions verified the public AJAX path is cache-enabled and the scheduled sync path remains force-fresh.
- Release ZIP structure and ZIP integrity verified.
- No production-site request was executed from this environment.

## Important distinction
WordPress's 120-second transient can avoid the Worker request altogether for repeat product inquiries during its lifetime. The Worker cache mainly avoids repeated upstream Digikala fetches when a request does reach the Worker; it does not itself eliminate the incoming Worker invocation.
