# Safe upgrade — product batch size 15

1. Back up the current Core plugin and database.
2. First deploy `EVazar-Cloudflare-Worker-1.13.13.1-Product-Batch-15.zip` to **every** Gemini Worker URL configured in Core. The new Worker remains compatible with the old Core's 2–10 batches, so this order avoids a window in which Core sends 15 items to an old Worker.
3. Then upload `EVazar-Core-2.9.84.1-Product-Batch-15.zip` as a plugin replacement (the internal plugin folder remains `evazar-core`). The Core and Worker policy must match; deploying only one side can cause 400 batch-size policy errors.
4. On the first WordPress request after Core upgrade, it changes `evazar_ai_product_batch_size` to 15 once. Confirm the “تعداد محصولات هر درخواست Gemini” setting displays 15.
5. Run a controlled import and check the Gemini operation logs: batch size should be 15, successful responses should include all expected DKPs, and an invalid/partial JSON response should leave the whole batch queued for retry rather than fan it out into single-product requests.
6. Do not change Worker parallelism during the first test. Existing queue ceiling and eligible-worker limits remain in force.

This package is based on the exact Core 2.9.84 / Worker 1.13.13 baseline supplied for this task. It does not include unrelated later-version changes.
