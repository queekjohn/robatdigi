# EVazar Core 2.9.7

- Treat complete images with zero intrinsic width as failed, not successful, in bounded image recovery timers.
- On browser connectivity restoration, retry failed visible/eager images individually through the Worker with a unique recovery URL. Lazy/off-screen images are not mass-reloaded.
