# EVazar Core 2.9.58

- Adds an extensible primary Worker URL pool for Digikala product, price, and taxonomy-source requests.
- Uses round-robin dispatch, atomic per-URL daily reservations, cooldowns, and GET failover.
- Keeps the legacy single Worker setting and historic fallback behavior for compatibility.
- Gemini Worker pool, image delivery logic, product processing, and unrelated queue behavior remain unchanged.
