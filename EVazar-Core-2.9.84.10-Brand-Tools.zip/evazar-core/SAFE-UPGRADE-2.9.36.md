# Safe upgrade — EVazar Core 2.9.36

1. Back up the WordPress database and current Core plugin directory.
2. Update only the `evazar-core` plugin from this package. No Cloudflare Worker deployment is required.
3. Keep current AI provider/API settings and saved category/brand prompts. Custom prompts are retained; the new product sample block is appended by the shared prompt builder.
4. Run a single-category test and a single-brand test, not a batch job. In the result panel, check the number and titles of sampled products.
5. Confirm that product names/specs match the selected taxonomy and that the public description does not repeat the raw sample block. Only then consider broader runs.

This release performs no DB schema migration. It reads up to 48 candidate posts using the custom `evazar_product` post type and custom taxonomy relationships, then passes at most 10 products to the taxonomy-generation prompt. During first import into a category, the current product is supplied explicitly as a candidate even if its term assignment occurs later in the import flow. The helper itself does not change product posts, product descriptions, prices, or stock values.
