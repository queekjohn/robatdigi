# QA — EVazar Core 2.9.53 / Worker 1.13.7

## Implemented
- [x] `taxonomy_seo` request context carries `taxonomy_type`, `taxonomy`, `term_name`, and `term_id` through Gemini request-context normalization.
- [x] Operational log stores safe, bounded taxonomy metadata: type allowlist (`category`/`brand`), sanitized taxonomy slug, sanitized term name (maximum 180 Unicode characters when mbstring is present), and numeric term ID.
- [x] Report table has a new `مورد هدف` column, which renders the type, name, and ID only for taxonomy-content events; product-request rows show an em dash.
- [x] Historic records are left untouched and remain readable.
- [x] Core plugin header and parallel-batch User-Agent use `2.9.53`; Worker stays at `1.13.7`.

## Local checks
- [x] `php -l` passed for `importer.php`, `evazar-core.php`, and `queue-manager.php`.
- [x] Static checks confirmed the taxonomy context is passed from the taxonomy content generator into `evazar_call_ai_api`, preserved by `evazar_gemini_prepare_request_context`, written by `evazar_gemini_log_event`, and rendered in the report.
- [x] Release ZIP integrity checked with `unzip -t`.
- [x] Previous version files kept intact; new files use `2.9.53` names.

## Not performed
- Live WordPress admin test and live Gemini requests were not run from this environment.
