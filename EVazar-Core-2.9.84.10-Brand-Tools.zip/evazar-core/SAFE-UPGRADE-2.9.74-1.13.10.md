# Safe upgrade — Core 2.9.74 / Worker 1.13.10

1. Back up the current `evazar-core` plugin directory and its database.
2. Upload/replace the `evazar-core` plugin folder with this release first. Do not delete the old folder before retaining a backup. Core 2.9.74 is backward compatible with Worker 1.13.9 and stops legacy ambiguous 404s from poisoning the cooldown pool.
3. Then deploy the script from `worker/digikala-worker.js` to each configured Cloudflare Worker, preserving each worker's existing `EVAZAR_INTERNAL_TOKEN` environment secret. Do not copy the token into source code.
4. Do not change daily budget settings while testing. Old cooldowns left by the previous Core can remain active for up to their previous 90-second expiry; allow up to 2 minutes before judging the new behavior.
5. After 10–15 minutes, inspect Products → EVazar → Price & Stock Logs. Error rows should show a diagnostic code and, when available, HTTP status instead of only `worker_or_source_unavailable`.
6. Confirm recent successful rows have fresh durations, Worker response status is 200, and error rows preserve stored prices/stock.

Rollback: restore the backed-up plugin directory. If reverting Worker, restore the previous `digikala-worker.js`; Core 2.9.74 is backward compatible with legacy Worker responses but diagnostics will be less detailed until Worker 1.13.10 is deployed.

Note: This upgrade does not change the product-import queue data or delete queued items.
