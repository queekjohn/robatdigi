# EVazar Core 2.9.84.6 — Product Index Composite Keys for 200K+ Products

## Optimization
- Upgraded `EVAZAR_PRODUCT_INDEX_DB_VERSION` to `1.3.0`.
- Added multi-column composite B-Tree indexes to `evazar_product_index` table:
  - `stock_price (stock_status, price)`
  - `stock_date (stock_status, post_date)`
  - `stock_views (stock_status, views)`
  - `stock_rating (stock_status, rating_count)`
  - `stock_satisfaction (stock_status, satisfaction)`
- Allows MySQL to execute archive sorts (cheapest, newest, bestseller, most viewed, highest rated) with stock-priority as index-only scans without temporary filesort, supporting 200,000+ catalog scale.
