# Safe upgrade — EVazar Core 2.9.38

1. Back up the current `evazar-core/` plugin directory and database before replacing files.
2. Replace the existing `evazar-core/` folder with this package. Do not install a version-suffixed folder alongside it.
3. Keep the current Theme 1.13.20; no Theme update is required for the dashboard widget or the related-product ranking cache.
4. No Worker deployment or database migration is required. The feature uses the existing queue/history/product-index tables.
5. Open **Dashboard → وضعیت واردات ایوازار** and verify counts against **محصولات → صف واردات**. Counts are cached for at most 30 seconds; recording a successful import and using queue admin actions invalidates the cache immediately.
6. Test a published product page with related products enabled. Scroll through several batches, ensure IDs do not repeat, then confirm the related list stops when it reaches the available candidates. The short-lived ranking cache expires after 60 seconds, so stock/taxonomy changes may take up to about a minute to affect the selected IDs.
7. Validation in this release is static/package validation only; perform live browser/database checks after installation.
