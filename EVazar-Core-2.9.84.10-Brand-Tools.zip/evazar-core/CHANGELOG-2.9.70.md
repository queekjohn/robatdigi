# EVazar Core 2.9.70 — Retry Continuation Guard Fix

- Fixed a cross-hook throttle conflict: a follow-up event may bypass the regular interval only when a retryable product is actually due.
- Due failed products are prioritized over untouched backlog, while WAITING_FOR_BATCH_PARTNER still follows its dedicated eligibility rules.
- Ordinary recurring cron and non-retry follow-ups continue to honor the configured interval.
- WordPress-local queue datetime parsing and Pacific Gemini quota reset logic are unchanged from 2.9.69.
- No Worker code changes.
