# Safe upgrade — EVazar Core 2.9.53

1. Take a current backup of the WordPress files and database, or at minimum preserve the existing EVazar Core ZIP so rollback is possible.
2. In WordPress Admin, open **Plugins → Add New Plugin → Upload Plugin** and upload `EVazar-Core-2.9.53-Taxonomy-Target-Logging.zip`, then select **Replace current with uploaded** if WordPress offers that option.
3. Confirm the EVazar Core plugin version is `2.9.53`.
4. Trigger one eligible category-content request and one eligible brand-content request.
5. Open the Gemini operational report and verify the `مورد هدف` column shows type, name, and term ID for each new taxonomy-content event.
6. Existing report rows were not backfilled and may still show `—` in `مورد هدف`.

No Worker deployment or Gemini API-key change is required for this Core-only logging update. Worker remains `1.13.7`.
