# Safe upgrade — EVazar Core 2.9.80

1. Back up the current `evazar-core` directory and the WordPress database.
2. Replace the `evazar-core` plugin directory with this package. No Worker or theme change is required for these queue diagnostics; keep the already deployed compatible Worker 1.13.12.
3. Open EVazar Core settings and press `بررسی وضعیت صف‌ها`. It reports separate category and brand queue counts and the next recurring cron timestamps.
4. If `due` is at least 2 but no `taxonomy_batch_dispatch` appears, inspect `taxonomy_batch_preflight_blocked` for the exact preflight statuses/term IDs. If the status page says `DISABLE_WP_CRON` is active, confirm a real server cron is calling `wp-cron.php`. If a next cron timestamp is missing, check `taxonomy_queue_schedule_failed` and WordPress cron settings.
5. Expected dispatch logs are `taxonomy_batch_dispatch` followed by `taxonomy_batch_completed`. No singleton request is sent.

The status endpoint is restricted to users with `manage_options` and uses the existing batch nonce. It exposes queue metadata only, not API secrets, prompts or descriptions.
