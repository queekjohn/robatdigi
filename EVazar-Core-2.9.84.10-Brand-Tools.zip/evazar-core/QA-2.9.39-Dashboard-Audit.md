# QA — Core 2.9.39 dashboard correction

- [x] Latest successful import timestamp no longer gets hidden by the rolling 7-day filter.
- [x] Query failures are distinguished from legitimate zero counts.
- [x] Dashboard cache is not invalidated per successfully imported product, preventing repeated aggregate scans during bursts; queue admin actions still clear it.
- [x] No database schema or index changes.
- [x] Related-product paging/cache implementation retained from 2.9.38.
- [x] PHP syntax and ZIP integrity checked after packaging.
- [ ] Live WordPress database, rendered admin widget, and production SQL timings are not available in this environment.
