# Safe upgrade — EVazar Core 2.9.0

1. Take a database and plugin-files backup.
2. Install on a staging copy first. Do not clean up the existing duplicate product IDs automatically.
3. After first load, Product Index DB version changes to `1.2.0`. Existing published products with an older `index_version` are refreshed gradually by the scheduled backfill (250 rows per batch by default); it is not a single full-table rewrite.
4. Check the products admin search by internal ID, numeric DKP, `DKP-` prefixed DKP, and product name.
5. Test an existing product re-import: the source/price refresh may run, but AI rewriting must be skipped and existing curated content/SEO must remain.
6. Test a new product: only `gemini-3.5-flash-lite` may be called. If Gemini quota is exhausted, normal quota/cooldown behavior still applies.
7. Test live price inquiry: the displayed response should show the newly fetched price even if index sync fails, but `_evazar_price_sync_status` must remain `error` and the error must not be cleared.
8. Test `img.evazar.ir` normally and with a controlled failure in staging. After a real CDN image error the theme/core failover script should switch images to `dkstatics-public.digikala.com`; after the 10-minute window a health probe checks whether CDN routing can resume.
9. Inspect the Worker deployment response header `X-Evazar-Worker-Version` and confirm `1.11.4`; updating the Core ZIP does not deploy the Cloudflare Worker automatically.

This package has not been installed on the live site. Run these checks on staging before production rollout.
