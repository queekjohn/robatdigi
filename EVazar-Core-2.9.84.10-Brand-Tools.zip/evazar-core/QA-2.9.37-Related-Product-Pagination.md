# QA — Core 2.9.37 related-product pagination

- [x] Old calls remain valid: `(post_id, limit, hide_outofstock)` still default to offset zero.
- [x] Query has deterministic ordering before `LIMIT/OFFSET`: relevance score descending, post date descending, product ID descending.
- [x] Offset is a prepared integer argument, not interpolated into SQL.
- [x] Product type/status and stock filters remain in the canonical index query.
- [x] No WooCommerce APIs or schema changes introduced.
- [ ] Live production data and actual database execution require post-deployment validation.
