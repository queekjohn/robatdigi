# Safe upgrade — EVazar Core 2.9.48

1. Back up the WordPress database and current `wp-content/plugins/evazar-core` directory.
2. Replace the plugin files with this package, keeping the folder name exactly `evazar-core`.
3. Do not redeploy or modify Worker 1.13.6; this release changes Core only.
4. Keep the current queue interval and batch size initially (for example, 5 minutes and 50 rows).
5. Test with a small queue: after one batch, confirm a single follow-up event is scheduled if eligible pending rows remain, or near the earliest retry time when pending rows are deferred; verify the queue does not schedule rapid follow-ups while Gemini is paused.
6. Verify a normal import, a deferred item, and an item with a genuinely stale claim. Do not manually reset rows that are actively being processed.

WordPress Cron note: a 15-second scheduled event runs when WordPress Cron is triggered. If `DISABLE_WP_CRON` is enabled and the server cron invokes `wp-cron.php` only every 5 minutes, the follow-up will run on that next invocation, not necessarily at 15 seconds.
