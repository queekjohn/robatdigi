# EVazar Core 2.9.36

- Category and brand AI generation now includes up to 10 representative published EVazar products from the relevant custom taxonomy.
- Uses the custom `evazar_product` post type plus `evazar_category` or `evazar_brand`; does not depend on WooCommerce.
- Supplies product title, SKU, and up to six existing specification/key-feature entries per sample. Prices and full product descriptions are not sent.
- Samples are selected from a bounded window of at most 48 relevant published products, then sampled across that window to avoid always taking only the latest few. During first import into a new category, the current imported product is explicitly included because its taxonomy relationship may not yet have been written.
- Sample products are framed as supplementary data, not representative of every item; data-like or instruction-like text is treated as untrusted input.
- The single-term diagnostic panel records and displays the sample count and titles used on the most recent generation.
- No product records are changed. Product prompt v7, product import, prices, stock, images, worker/API contracts and external research providers remain unchanged.
- Taxonomy length-rule wording uses “کلمه” rather than “واژه”.
