# Safe upgrade — Core 2.9.75 / Worker 1.13.11

1. Back up the current `evazar-core` plugin directory and the database.
2. Replace the plugin folder with this release. It retains Core 2.9.74 stock-sync diagnostics and updates the embedded Worker script/version metadata; the embedded script is not automatically deployed to Cloudflare by WordPress.
3. Deploy `worker/digikala-worker.js` from this release to every primary Digikala Worker configured in Core. Preserve each existing `EVAZAR_INTERNAL_TOKEN` secret separately in Cloudflare. Never put the secret into the source file.
4. Do not change Worker budget/quota settings while validating. Existing cooldown transients may persist up to their expiry; allow about two minutes after upload before interpreting a fresh run.
5. Confirm deployed Worker responses include `X-Evazar-Worker-Version: 1.13.11`. After 10–15 minutes inspect Products → EVazar → Price & Stock Logs. Network failures should now say `source_fetch_failed`, actual upstream 5xx `source_server_error`, source rate limiting `source_rate_limited`, and genuine double-404 `product_not_found`.
6. Confirm failure rows retain existing prices and stock. Do not manually clear prices or delete queue rows to retry.

Rollback: restore the backed-up plugin folder and previous Worker source. This release does not change import queue data or the import-queue locks.
