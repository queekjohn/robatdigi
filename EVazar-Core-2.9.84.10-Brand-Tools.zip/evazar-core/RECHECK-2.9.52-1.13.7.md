# Release recheck — EVazar Core 2.9.52 / Worker 1.13.7

- [x] Core plugin header version is 2.9.52.
- [x] Parallel request User-Agent identifies Core 2.9.52.
- [x] Source contains exact-body detection for the Worker's pre-upstream `401 Unauthorized` guard.
- [x] Internal-auth rejection is reported as `worker_auth_failed`, with Worker-only cooldown and queue deferral.
- [x] Queue pause/error allowlists include `gemini_worker_auth_failed`.
- [x] Core-side change only; Worker stays 1.13.7.
- [ ] Live validation on evazar.ir remains to be done after installing Core.
