# EVazar Core 2.8.99 — Cross-module reconciliation

- Kept internal product ID / DKP columns and admin product search for title, ID, DKP, SKU, and source URL.
- Restricted the additional `posts_search` filter to the admin product list; public search uses the theme's optimized Product Index path to avoid redundant correlated meta scans.
- Included legacy `_evazar_dk_id` in identity lookup used by the duplicate guard.
- Propagated Product Index sync failures from import so queue/history do not mark an unindexed import as completely successful.
- Live price inquiry now records index-sync success/failure in its response and logs a failed sync.
- Queue items encountering an already-held DKP lock are deferred 60 seconds without increasing retries.
- Category-index sync inserts current relationships before removing stale ones; SQL failures no longer delete prior category associations first.
- No products are deleted/merged and no historic timestamps are bulk-modified.
