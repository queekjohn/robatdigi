# Release recheck — EVazar Core 2.9.53 / Worker 1.13.7

- [x] Plugin header version is `2.9.53`.
- [x] Parallel batch User-Agent identifies Core `2.9.53`.
- [x] Taxonomy term context is supplied by `evazar_ai_ensure_term_seo_content()`.
- [x] `evazar_gemini_prepare_request_context()` preserves the taxonomy context.
- [x] `evazar_gemini_log_event()` stores sanitized taxonomy context.
- [x] Gemini report includes the new `مورد هدف` column.
- [x] No Worker source change; Worker version remains `1.13.7`.
- [x] PHP syntax and ZIP integrity checks passed locally.
- [ ] Live WordPress/Gemini validation remains for deployment.
