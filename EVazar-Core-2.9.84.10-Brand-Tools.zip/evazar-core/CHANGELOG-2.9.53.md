# EVazar Core 2.9.53 — Gemini taxonomy target logging

## Changes
- Gemini operation-log events for `taxonomy_seo` now retain the term's display name, numeric term ID, taxonomy type (`category` or `brand`), and internal taxonomy slug.
- The Gemini report adds a dedicated **مورد هدف** column showing type, name, and ID for category/brand content requests.
- Existing events are preserved; old log records are not modified or backfilled and will show no target details if the original event did not store them.
- Updated the parallel-batch request User-Agent and plugin version metadata to `2.9.53`.

## Safety and scope
- No Gemini prompt, API key, worker secret, worker code, queue scheduling, product-batch payload, or content-generation logic was changed.
- Worker remains version `1.13.7`.
