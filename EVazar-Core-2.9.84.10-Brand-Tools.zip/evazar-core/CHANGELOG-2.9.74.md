# EVazar Core 2.9.74 — Worker Diagnostics and Source Error Contract

- Adds concise, actionable per-product diagnostics for Worker-pool exhaustion, cooldown exclusions, daily budget exclusions, transport failures, HTTP failures, invalid JSON, and missing product payloads. Tokens and full URLs are never written to the stock-sync log.
- Stops treating a product-specific HTTP 404 as a reason to cool down a Worker when the Worker marks it with `X-Evazar-Error-Scope: product`. Legacy Worker 404 responses no longer cool down a Worker and are tried against another configured endpoint.
- Source-side errors do not cool down a healthy Worker or fan out to every endpoint; the next product rotates through the pool. Legacy ambiguous 404 gets at most one alternate-Worker retry.
- Worker 1.13.10 distinguishes true double-404 product-not-found from upstream rate limits, upstream server errors, network failures, and malformed upstream payloads.
- Stock-sync admin logs show the real diagnostic code and HTTP status. A concurrent/stale response is now marked `deferred`, never as a successful fresh inquiry.
- Tightens stock-sync continuation scheduling from 15 to 8 seconds. Import queue logic and locks are unchanged.
