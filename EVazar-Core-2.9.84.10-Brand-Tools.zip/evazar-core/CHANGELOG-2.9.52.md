# EVazar Core 2.9.52 — Worker-side 401 diagnostics

- Detect the exact Worker 1.13.7 pre-proxy response `{"success":false,"message":"Unauthorized."}` separately from Gemini API authorization errors.
- Log `worker_auth_failed` when the internal `X-Evazar-Internal-Token` check rejects the request before Gemini is called. Do not misreport this exact response as a Gemini API-key failure.
- Put the affected Worker into a five-minute temporary cooldown and defer assigned batches so the queue can select another eligible Worker on the next attempt. In unassigned dispatch mode, a confirmed pre-upstream auth rejection may safely continue to the next Worker using the same request ID.
- Keep all keys and tokens out of logs. No Worker source change or deployment is required.
- This release does not prove the live Worker configuration; the Core internal token and the target Worker's `EVAZAR_INTERNAL_TOKEN` Secret must still match exactly.
