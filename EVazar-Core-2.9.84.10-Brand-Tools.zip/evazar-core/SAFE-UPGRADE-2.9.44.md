# Safe upgrade — EVazar Core 2.9.44

1. Back up the current `evazar-core/` directory and the WordPress database.
2. Install the Core ZIP by replacing the existing `evazar-core/` folder. Preserve the exact folder name; do not create a nested `evazar-core/evazar-core/` directory.
3. Do not deploy a Worker. Keep all existing Gemini Worker URLs, Worker 1.13.4 code, `EVAZAR_INTERNAL_TOKEN`/Core internal token setting, and each Worker's `GEMINI_API_KEY` secret unchanged.
4. After installation, leave **پردازش موازی دسته‌های Gemini** off initially. Keep product batch size 5 and the queue interval at its current value.
5. Verify that the PHP runtime has cURL and `curl_multi_init()`. This is required for actual concurrency. Also verify the site can make an HTTPS loopback POST to its own `rest_url('evazar/v1/internal-product-ai-batch')`; Core signs these requests using the existing internal token and WordPress auth salt. No secret should be added manually.
6. Confirm these settings before testing: engine mode `gemini_only`; product batching enabled; Gemini product batch size `5`; queue batch size `25` (or a smaller controlled value); parallel mode enabled only for the test; max concurrent requests initially `2`.
7. Run one controlled queue operation. Expected: for 10 eligible AI products and parallelism 2, two 5-product sub-batches run at a time. Confirm success events include `purpose=product_import_batch`, `batch_size=5`, 5 DKPs, and distinct Worker hosts for batches in the same wave. Then verify the saved content of all products.
8. If the first test succeeds, set parallelism to 5 and test a queue batch of 25 eligible AI products. Expected: up to five Gemini batch requests in the first wave, each with five DKPs and a different Worker URL. If some products do not need AI or some Workers are cooling down, the actual number of requests/workers will be lower.
9. Watch for `GEMINI_PARALLEL_UNAVAILABLE`, `GEMINI_PARALLEL_AUTH_FAILED`, `GEMINI_WORKERS_BUSY`, or `GEMINI_OUTCOME_UNKNOWN`. If the first two appear, turn parallel mode off and inspect loopback/REST/cURL support before retrying. Do not bulk-retry `GEMINI_OUTCOME_UNKNOWN`; Gemini may have processed the request even if Core did not receive the response.
10. Leave the concurrency value at 2 if the hosting plan shows elevated Entry Processes, CPU, or PHP-FPM usage. Only keep 5-way parallelism after several successful waves and per-Worker quota review.

Rollback: turn parallel mode off first, then restore the previous `evazar-core/` directory if needed. No Worker rollback or database rollback is required. The additive request-ledger records/options from 2.9.43 remain in place; do not restore a full old database snapshot because that would undo later product imports.
