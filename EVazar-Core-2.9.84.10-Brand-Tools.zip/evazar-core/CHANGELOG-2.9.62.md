# EVazar Core 2.9.62 — Cloudflare Analytics Token UI Fix

- Renamed the misleading analytics field label to explicitly indicate per-account tokens.
- Clarified that the accounts field expects `ACCOUNT_ID|Worker URL`, while the token field expects `ACCOUNT_ID|API_TOKEN`.
- Added an explicit warning that a bare API token is ignored because it cannot be safely mapped when multiple accounts are configured.
- No routing, Worker secrets, product data, queue, or database behavior changed.
