# EVazar Core 2.9.49 — Adaptive Gemini Batch Capacity

- In parallel Gemini batch mode, caps each queue run to one configured AI batch per currently eligible Worker (respecting quota cooldown, rate cooldown, and Worker locks). Remaining products stay pending for the existing automatic follow-up.
- If every product in a Gemini batch has an invalid/missing parsed output, prevents the batch from immediately generating one single-product request per item. Logs safe diagnostic metadata and returns the batch to queue retry handling.
- Partial batch responses still use per-product fallback only for the missing/invalid items.
- Does not modify Worker code or database schema.

## Validation
- PHP syntax checks are run for the Core PHP files.
- This package has not been deployed or tested against the live WordPress database or live Gemini endpoints.
