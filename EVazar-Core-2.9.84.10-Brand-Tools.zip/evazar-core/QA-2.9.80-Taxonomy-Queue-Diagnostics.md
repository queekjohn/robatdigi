# QA — EVazar Core 2.9.80 Taxonomy Queue Diagnostics

## Local checks performed after the final edits
- `php -l` passed for all 6 PHP files in the Core package.
- `node --check` passed for the embedded Cloudflare Worker JavaScript.
- Extracted inline JavaScript for the taxonomy queue admin UI passed `node --check` after replacing the PHP nonce interpolation with a test literal.
- A local PHP harness with WordPress/database stubs passed for queue-count aggregation and the administrator AJAX status payload, including separate category/brand counts and scheduled-hook timestamps.
- Static regression checks passed for the minimum batch size, separate category/brand queue hooks, the preflight-blocked diagnostic event, the waiting-for-two-items diagnostic event, and the admin status endpoint.
- Embedded Worker compared byte-for-byte with the existing Core 2.9.79 / Worker 1.13.12 release. It is unchanged.
- Theme 1.13.23 source is unchanged; the diagnostics button lives in the Core settings screen and adds no front-end theme dependency.

## Expected live diagnostics
- `taxonomy_batch_waiting_minimum`: the scheduled runner did execute, but fewer than 2 same-type rows were due.
- `taxonomy_batch_preflight_blocked`: rows were claimed, but fewer than 2 survived validation; message includes compact term-ID/status outcomes.
- `taxonomy_queue_schedule_failed`: WordPress refused to schedule the recurring taxonomy queue event.
- In the admin page, use `بررسی وضعیت صف‌ها` to compare category/brand pending, due, retry, processing counts and next scheduled hook times. `due` means the retry/pending time has arrived; it does not mean that source validation has passed.

## Not tested live
The local harness does not connect to the production WordPress database, actual WP-Cron spawn/execution, the deployed Cloudflare Workers, or Gemini. Those must be verified after deployment.
