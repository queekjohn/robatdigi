# EVazar Core 2.8.88

- Fixes Gemini multi-Worker quota failover: a daily quota error marks only the affected Worker and continues to the next configured Worker.
- The global daily-quota cooldown is applied only when every configured Gemini Worker is in its own quota cooldown.
- Reconciles a stale global cooldown when at least one configured Worker has no per-Worker quota cooldown, allowing it to be tested.
- Temporary 429/rate-limit cooldown behavior is unchanged and remains global.
- Each configured Worker must have its own valid `GEMINI_API_KEY` secret; WordPress API-key textarea values are not forwarded in Worker mode.
