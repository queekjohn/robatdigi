# EVazar Core 2.8.97 — DKP Duplicate-Import Guard

- Added an atomic per-DKP MariaDB advisory lock around every importer entry point used by manual import and the queue. Concurrent imports of the same DKP fail closed before Worker/Gemini requests.
- Replaced URL-only lookup with fresh canonical matching across `_evazar_sku`, `_sku`, and common legacy URL variants.
- Removed reliance on cached positive/negative lookup results during product creation.
- Existing duplicate records are logged for review; no product is automatically deleted, merged, unpublished, or otherwise altered by the duplicate guard. If multiple records already share a DKP, the oldest published match is selected deterministically for update.
- This release does not perform database migrations and does not repair existing duplicate records automatically.
