# EVazar Core 2.9.0

## Safety and consistency
- Gemini model is now fixed to `gemini-3.5-flash-lite`; stale option values and caller-supplied model names are ignored, and settings saves normalize to the same model.
- Re-import of an existing DKP skips AI generation while refreshing source-derived product data. Existing product description, pros/cons, and Rank Math fields are preserved unless absent.
- Legacy `_evazar_dk_id` values are now considered by the duplicate lookup and Product Index canonical DKP fallback.
- Product Index version is bumped to `1.2.0` so the scheduled backfill refreshes existing published rows from canonical/legacy metadata.
- A failed or unavailable live Product Index sync no longer clears a previous sync error or writes a false `ok` status. The live response still includes the fresh source price and reports index status separately.
- Product import fails visibly if index sync is unavailable or unsuccessful.
- Core CDN image URL transformation resizes an existing `x-oss-process` to the requested card size and honors the page's 10-minute direct-image failover mode.
- Embedded Worker is synchronized to Worker `1.11.4`, which only calls Gemini `gemini-3.5-flash-lite`.

## Safety notes
- No database records are deleted or merged.
- No bulk rewriting of historical stock timestamps is performed.
- Duplicate `dkp` database uniqueness is not added while the known duplicate DKP still exists; the importer lock remains the guard for concurrent importer requests.
