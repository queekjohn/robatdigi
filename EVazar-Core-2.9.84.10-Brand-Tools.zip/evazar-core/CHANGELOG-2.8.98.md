# EVazar Core 2.8.98 — Product Search, IDs, and Index Reliability

- Added a visible internal product ID column in the WordPress “All EVazar Products” list, linking directly to the editor.
- Added a visible Digikala DKP column, distinct from the internal WordPress product ID.
- Extended EVazar product-list and eligible public site-search queries to search by title/content (native WordPress behavior), internal numeric product ID, `_evazar_sku`, `_sku`, and Digikala URL; supports Persian/Arabic digits and `DKP-123456` notation.
- Updated product-admin search placeholder to state supported search keys.
- Replaced `current_time('timestamp')` with Unix `time()` for `_evazar_last_stock_check` values written during import.
- Hardened the importer to fail closed if the final product-identity lookup returns an error, instead of mistakenly proceeding to insert.
- Product-index sync functions now return failure and log a low-detail diagnostic when SQL writes/reads fail; previously they could report success without confirming the write.
- Existing duplicate products and historic timestamps are not modified automatically. No database schema migration or data deletion is included.
- Added an administrator-only, nonce-protected row action to re-sync one product and its category index from canonical WordPress product metadata; useful for safely repairing an index mismatch without direct SQL.
- If brand/category term lookup fails, the index sync stops before writing/deleting category-index rows rather than interpreting a database error as an empty taxonomy.
