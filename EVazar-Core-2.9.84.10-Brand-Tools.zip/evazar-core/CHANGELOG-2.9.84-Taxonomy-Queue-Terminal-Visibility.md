# EVazar Core 2.9.84 — Queue Terminal Visibility

- The taxonomy SEO queue status now reports terminal (`done`) rows, including source URL missing, source text unavailable, and other terminal rows. Source-specific counts are subsets of the terminal count.
- The legacy source-less retry migration processes bounded chunks (up to 2,500 rows per WordPress request) and only records completion after verifying no matching legacy rows remain. More than 500 matching rows no longer become stranded by a premature completion marker.
- Core logic, worker API contract, product imports, and theme output are otherwise unchanged.
