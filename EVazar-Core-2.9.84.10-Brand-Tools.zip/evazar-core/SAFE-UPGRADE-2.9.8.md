# Safe upgrade — EVazar Core 2.9.8

This focused release updates the image-recovery JavaScript embedded in `evazar-core.php`.

## What changed

- Failed visible/eager images can retry when scrolling or resizing, even if switching the VPN/IP did not produce a browser `online` event.
- Recently visible lazy images have a 10-second grace window so they can recover if they fail just after being scrolled past.
- The post-failure retry budget is limited to two additional retries per unchanged image source, at least five seconds apart, shared across scroll/resize and connectivity events.
- Failed request state captures the selected browser URL at failure time, preventing a late `currentSrc` update from clearing the state before the next retry.

## Deployment

1. Keep a backup of the current `evazar-core/` plugin folder.
2. Replace the existing plugin folder with the package's `evazar-core/` folder; do not create a version-suffixed folder.
3. Purge the site's page cache and any HTML/JS cache, then open a category page with browser DevTools Network filtered to `Img`.
4. On a test device, simulate a slow/blocked image request or change the VPN/network, scroll through the affected products, and verify only failed/recently-visible images retry.

## Scope and limitations

- No theme files, product data, database schema, filters, infinite-scroll code, or Cloudflare Worker logic were changed.
- No Worker deployment is required; the existing `evazar_direct_retry=1` path is retained.
- PHP syntax, JavaScript syntax, ZIP integrity, and eight simulated image-recovery scenarios passed for this package. These checks do not replace testing on the live site with a real mobile VPN/network transition. If both the Worker and the source image host are unreachable, no browser-side code can display the image until a source becomes reachable.
