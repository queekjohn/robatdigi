# Safe upgrade — Core 2.9.84

Replace the existing `evazar-core` plugin folder with this version. No database table schema change is required. The queue diagnostics are read-only; the legacy source-less migration only transitions rows with known deterministic source-missing retry errors to the terminal `done` state. It does not delete queue rows. Worker 1.13.13 and the theme do not need updating for this change.
