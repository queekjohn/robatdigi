# EVazar Core 2.9.18 — Source-Based Taxonomy SEO Foundation

- Added source URL resolution for category and brand taxonomy terms using Digikala breadcrumbs and English brand identity.
- Added source-text retrieval from category/brand SEO API fields with public-page fallback.
- Added taxonomy AI status/error/source metadata to distinguish successful rewrites from missing source text, disabled settings, skipped manual descriptions and AI failures.
- Added category/brand source-fidelity guardrails and conservative HTML sanitization for AI output.
- Preserved existing descriptions when source retrieval or AI generation fails.
