# EVazar Core 2.9.21 — Single-term taxonomy processor

- Adds an admin panel to inspect and process exactly one `evazar_category` or `evazar_brand` term by its ID.
- Provides a read-only preview of the canonical term name, description length, lock state, AI-ownership verification, saved source method/length, and resolved Digikala URL before processing.
- Single-term results display the final status, source method, source character count, output character count, source URL, and saved error detail.
- Adds an opt-in regenerate checkbox for descriptions positively verified as existing AI output. It never bypasses the manual-content protection or a term content lock.
- Hardens the targeted AJAX path by validating taxonomy and term ID and using the canonical WordPress term name rather than trusting a browser-supplied name.
- Keeps the all-terms batch operation separate; no product import, product pricing, image delivery, queue, or database schema changes.
