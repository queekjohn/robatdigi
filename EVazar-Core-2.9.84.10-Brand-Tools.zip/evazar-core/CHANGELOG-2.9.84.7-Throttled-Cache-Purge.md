# EVazar Core 2.9.84.7 — Smart Cache Purge Throttling & Notice Spam Suppression

## Problem Solved
- Continuous automated robot imports (~450 products/hour, ~32,000 imports/24h) were executing `evazar_lscache_purge_product_urls($post_id, true)` after every single imported item.
- Every run unconditionally purged the homepage (`/`) and shop archive (`/product/`), invalidating the entire public cache every 2.6 to 8 seconds. This prevented LiteSpeed Cache from achieving high hit rates and caused cold cache spikes.
- Each call fired `do_action('litespeed_purge_url', ...)`, flooding `litespeed.admin_display.messages` in `wp_options` and bombarding the WordPress admin with dozens of green notices (`پاکسازی /url /`, `پاکسازی /url /product`, etc.).

## Changes Made
1. **Purge Throttling (`cache-purge.php`)**:
   - **Homepage (`/`)**: Throttled to at most once per 60 minutes (`apply_filters('evazar_lscache_home_purge_throttle', 3600)`).
   - **All-Products Archive (`/product/`)**: Throttled to at most once per 60 minutes (`apply_filters('evazar_lscache_shop_purge_throttle', 3600)`).
   - **Taxonomy Archives (Categories & Brands)**: Throttled to at most once per 30 minutes per term (`apply_filters('evazar_lscache_term_purge_throttle', 1800)`).
   - **Single Product URLs (`/product/slug`)**: Remains instantaneous with zero throttling on product updates.
2. **Admin Notice Suppression (`cache-purge.php`)**:
   - Added filter on `option_litespeed.admin_display.messages` to strip automated URL purge notices from display.
   - Added automatic cleanup on `admin_init` and `shutdown` to keep `wp_options` lean and clean.
3. **Core Version Bump**:
   - `evazar-core.php`: Bumped to `2.9.84.7`.
