# EVazar Core 2.9.8 — bounded scroll-triggered image recovery

- Reattempts images that already exhausted their normal CDN/direct recovery chain when the user scrolls/resizes, even if no browser `online` event fires after a VPN route change.
- Includes lazy-loaded images that were recently near the viewport for a 10-second grace period, so a failed image can still recover immediately after the user scrolls past it.
- Shares one strict post-failure retry budget across scroll/resize and connectivity events: at most 2 retries per unchanged image source, at least 5 seconds apart.
- Adds a per-image unique `evazar_reconnect` query token while preserving the Worker's `evazar_direct_retry=1` recovery path. No page reload, page-wide failover, archive changes, product changes, or new Worker deployment.
- Resets the retry budget when the image source changes or successfully loads.
