# Safe upgrade — EVazar Core 2.9.1

1. Back up the database and current plugin folder; test in staging first.
2. Product Index version 1.2.1 triggers a bounded incremental refresh (250 products per scheduled batch). No products are removed or merged.
3. Failed index syncs get up to five automatic retries with exponential backoff; persistent failures stay marked for manual review.
4. Explicit AI rewrite sets `_evazar_force_ai_rewrite`; `_evazar_force_ai_rewrite_done` checkpoints successfully saved AI content so a later index retry will not invoke Gemini a second time.
5. Confirm a resize URL like `image/resize,m_lfit,h_800/quality,q_90` becomes `image/resize,m_lfit,h_360,w_360/quality,q_90` when size 360 is requested.
6. Separately deploy Worker 1.11.5 to Cloudflare and verify `X-Evazar-Worker-Version: 1.11.5`. Core update does not deploy the Worker.
