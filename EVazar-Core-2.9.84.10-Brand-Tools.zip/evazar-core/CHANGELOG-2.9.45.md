# EVazar Core 2.9.45 — Gemini outcome recovery

- Adds Worker Durable Object status lookup for requests whose HTTP result was lost.
- Recovers a completed Gemini response into the Core idempotency ledger without another Gemini call.
- Moves ambiguous queue rows to a delayed recovery attempt (120 seconds); retries use the deterministic batch request ID.
- If Worker status cannot be verified, the safety lock remains; no blind retry is performed.
- Requires Worker 1.13.5 deployed with Durable Object binding/migration. Without that binding, ambiguous requests remain safely blocked.
