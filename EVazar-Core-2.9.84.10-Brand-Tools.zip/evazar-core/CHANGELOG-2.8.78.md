# EVazar Core 2.8.78

- Image failover now switches only the image that actually failed instead of rewriting every image on the page.
- Removed the document-wide MutationObserver from the failover path to reduce main-thread and network churn on image-heavy pages.
- Existing pages can still use a short sessionStorage direct-CDN cooldown, but it rewrites only the images already present in the DOM.
- Removed stopImmediatePropagation from the image error handler so other legitimate image handlers are not interrupted.
- Preserved the zero-host-storage architecture and the direct Digikala fallback.
