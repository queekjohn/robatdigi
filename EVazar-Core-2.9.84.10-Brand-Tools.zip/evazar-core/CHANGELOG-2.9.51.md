# EVazar Core 2.9.51 — Gemini report local-time display

- Bump the plugin release version from 2.9.50 to 2.9.51 for the local-time report correction; the release retains the batch-only Gemini safeguards and queue/Worker-aware retry fixes from the 2.9.50 maintenance build.
- Gemini report event timestamps, cooldown-until values, and related operational-log timestamps display in the timezone configured in WordPress (Settings → General → Timezone), using the existing `wp_date()` / `wp_timezone()` formatter.
- Stored timestamps remain unchanged. Pacific-specific daily-quota reset labels remain explicitly Pacific.
- Worker source is unchanged at 1.13.7; no Worker redeployment is required for this display-only change.

Local source/packaging checks only. No production WordPress, deployed Cloudflare Worker, or live Gemini request was run during this release packaging.
