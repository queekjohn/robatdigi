# Safe upgrade — EVazar Core 2.9.50 maintenance rebuild / Worker 1.13.7

1. Back up the WordPress database and current EVazar Core plugin folder.
2. Replace Core with `EVazar-Core-2.9.50-Strict-Gemini-Batch-Only.zip`. The version label remains 2.9.50 by request; this is a maintenance rebuild of the same release line.
3. Do not modify Worker Secrets. Worker source has not changed; existing Worker 1.13.7 deployments do not need to be redeployed for this Core-only patch.
4. Confirm AI mode is `gemini_only`, products/request is 10, queue cap is 50 if you want maximum automatic capacity, and concurrency ceiling is 5.
5. Run a controlled 20–30 product test. With 3 eligible Workers, queue cap 50 and size 10, `batch_dispatch_plan` should normally show capacity 30 and 3 chunks. It also shows the effective PHP execution-time limit. If the host refuses the 300-second extension and keeps a limit under 180 seconds, this run is deliberately capped to one complete AI batch to avoid PHP termination during sequential product preparation. `batch_dispatch_wave` lists concurrent selected hosts; `batch_worker_assigned` shows sequential fallback assignments.
6. For a malformed HTTP-200 output, `batch_output_invalid` should contain a validation reason; only the failed chunk should be deferred, and subsequent chunks should still be tried in sequential balanced mode. The next attempt must use a new `gm-batch-*` ID after `retries` increases.
7. Confirm no automatic `gm-fallback-*` calls appear. Manual one-product tests remain explicit admin actions only.
8. Production has not been tested by this build process. Keep the test limited until the log behavior matches expectations; if not, pause the queue and restore the backup.
