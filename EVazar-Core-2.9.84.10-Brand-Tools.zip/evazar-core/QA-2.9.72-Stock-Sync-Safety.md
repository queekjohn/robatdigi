# QA — EVazar Core 2.9.72

## Scope
Only `importer.php` stock/price synchronization scheduling and its callback, plus the plugin version and release notes. Product-import queue logic and Worker source are unchanged.

## Checks
- Stock schedule remains every 300 seconds.
- Each PHP invocation attempts at most two products, limiting exposure to the configured 8-second Worker timeout.
- A continuation is queued before the chunk starts, so a hard PHP timeout does not normally strand the snapshot.
- A chunk lock has a short expiry; the state snapshot has a longer expiry.
- `_evazar_last_stock_attempt` is separate from `_evazar_last_stock_check`, which continues to represent a successful stock check.
- Last batch results are stored in `evazar_stock_batch_last_run`.

## Operational caveat
WP-Cron must execute for scheduled work to run. This package was source-checked; it has not been installed on or runtime-tested against the live WordPress site. Test first with a backup and verify the last-run option and product metadata after deployment.
