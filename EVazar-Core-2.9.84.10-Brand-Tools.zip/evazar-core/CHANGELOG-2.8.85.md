# EVazar Core 2.8.85

- Moves the dedicated Gemini Worker URL list into the Cloudflare Worker settings section so it is visible beside the primary Worker URL.
- Labels the primary Worker URL clearly to avoid accidentally replacing product/import/image routing.
- Keeps Gemini quota cooldown behavior intact; this release does not bypass a genuine Google daily quota.
- No changes to product import, image CDN, product data, or theme files.
