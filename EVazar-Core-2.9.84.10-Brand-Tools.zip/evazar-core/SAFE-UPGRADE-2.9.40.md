# Safe upgrade — EVazar Core 2.9.40

1. Back up the current `evazar-core/` plugin folder and the WordPress database.
2. Install this package by replacing the existing `evazar-core/` folder. Keep the folder name unchanged.
3. Do not publish or replace any Cloudflare Worker for this version; the embedded Worker remains byte-identical to Worker 1.13.4.
4. After upgrade, product batching remains **disabled** by default. The existing queue and single-product import behavior continue until an administrator explicitly enables the option.
5. The new settings are under **Products → EVazar Affiliate Settings → AI**:
   - Select the engine mode **Gemini only**.
   - Enable **Batch processing of product content (experimental)**.
   - Start with batch size **5**.
6. Before enabling it on a production queue, verify the next eligible queue rows are intended for import. A batch processes normal queue items and saves successful products to the live catalog.
7. Start with one small queue run and inspect the Gemini operational log. Confirm a `product_import_batch` event has the expected `batch_size`, all corresponding queue items finish or return to pending on an error, and product content remains associated with the correct DKP.
8. If any issue occurs, uncheck the batch-processing option. This returns subsequent queue runs to the prior single-product AI path; no schema rollback is needed.

## Compatibility
- No WooCommerce dependency or tables are introduced.
- No database migration or product data cleanup runs during upgrade.
- Existing AI prompts and normal product-response parsing are retained.
- No live database, production-browser, or real Gemini request was available during local package checks; complete the one-small-run verification after installation.
