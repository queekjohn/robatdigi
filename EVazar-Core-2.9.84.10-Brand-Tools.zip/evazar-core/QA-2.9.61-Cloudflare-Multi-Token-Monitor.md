# QA — EVazar Core 2.9.61

- Added `evazar_cf_analytics_tokens`, an account-ID-keyed token map.
- Each analytics account uses its matching token; the legacy `evazar_cf_analytics_token` is used only as fallback.
- Missing token or API failure is recorded per account and does not abort other account checks.
- Token textarea does not echo secrets. Blank submission preserves saved mappings; `ACCOUNT_ID|DELETE` removes a mapping.
- Static PHP syntax and ZIP integrity checks are required before release. No live Cloudflare credentials or production WordPress runtime are available, so no live API or production end-to-end test is claimed.
