# Safe upgrade — EVazar Core 2.9.78 / Worker 1.13.12

1. Back up the current `evazar-core` plugin folder and the WordPress database.
2. Upload/replace the `evazar-core` folder from the Core ZIP. On the first subsequent WordPress request, the plugin creates its taxonomy SEO queue table and registers separate category/brand cron events.
3. Deploy `digikala-worker.js` version 1.13.12 to **every configured Gemini Worker endpoint** used by EVazar. All endpoints must be updated: Core will send the new `taxonomy_seo_batch` purpose to any eligible Worker, and older Workers intentionally reject unknown purposes.
4. Keep each Worker’s existing `EVAZAR_INTERNAL_TOKEN` and Gemini API secret unchanged. Do not put secrets in source code or logs.
5. Ensure Core settings have AI enabled and taxonomy SEO enabled before expecting Gemini taxonomy batches. The queue does not send singleton requests: at least two due categories or at least two due brands are required for each request.
6. Watch the Gemini operations log for `taxonomy_batch_dispatch` and `taxonomy_batch_completed`; each event represents a batch request, and the term IDs are recorded separately from product DKPs.
7. If rolling back, roll back Core and all Workers together. Core 2.9.77 with Worker 1.13.11 does not support the new taxonomy batch contract.

## Safety guarantees

- Existing categories/brands are not automatically re-enqueued by product import. They are simply attached to the product.
- Existing manual or locked descriptions are preserved; queue save also re-checks the term lock and description hash after generation.
- A missing or invalid item in a structured response is retried without a new single-item Gemini request.
- Cron timing depends on normal WordPress traffic/cron execution. Product import does not synchronously wait for taxonomy SEO processing, but this package does not install an external system cron.

Live WordPress, Cloudflare deployment, and real Gemini calls were not performed in local QA.
