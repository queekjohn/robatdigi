# Safe upgrade — EVazar Core 2.9.50 maintenance rebuild / Worker 1.13.7

1. Back up the WordPress database and existing Core plugin folder.
2. Install the rebuilt `EVazar-Core-2.9.50-Strict-Gemini-Batch-Only.zip`. The plugin version string remains 2.9.50 by request; this is a replacement build for the same release line.
3. Do not change or reveal any Cloudflare Secret. The Worker source remains version 1.13.7 and unchanged in behavior; Core embeds the exact same Worker source. Existing Worker deployments do not need to be redeployed for this Core-only fix.
4. Confirm AI mode is `gemini_only`, automatic product batching is enabled by policy, products/request is 10 (or your chosen 2–10), per-run queue cap is 50 if you want the maximum available capacity, and concurrency ceiling is 5.
5. Run a controlled test with at least 20–30 products and three known-eligible Workers. Review `batch_dispatch_plan`; expected: queue cap 50, batch size 10, eligible workers 3, concurrency ceiling 5, effective capacity 30, planned chunks 3. Review `batch_dispatch_wave` to confirm distinct Worker hosts were assigned.
6. If cURL-multi is not available, Core now uses sequential round-robin assignment to eligible Workers; `batch_worker_assigned` logs should show rotation.
7. Force an invalid batch output only in a safe test environment if possible. On the next retry, verify the request ID changes with the queue retry generation and does not endlessly replay the old malformed response.
8. Confirm no automatic `gm-fallback-*` single-product requests appear. A one-product manual test must remain an explicit admin action and is independent of automatic queue behavior.
9. If the test passes, resume larger batches. If not, pause the queue and restore the backed-up plugin ZIP/database state as appropriate.
10. Gemini report timestamps use the timezone configured at WordPress Settings → General → Timezone. If it is set to UTC, the panel will correctly continue to show UTC; select the intended site timezone there to see local time. No Worker redeployment is needed for this display-only change.

No live site test has been completed by this build process; do not treat the local QA as a production verification.
