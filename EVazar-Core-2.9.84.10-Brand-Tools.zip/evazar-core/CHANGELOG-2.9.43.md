# EVazar Core 2.9.43 — Batch Idempotency and Worker Isolation

- Adds a persistent request ledger for product-batch Gemini requests and per-item fallback calls. The ledger is validated after `dbDelta`; if its table or unique `request_id` index is unavailable, Core fails closed and sends no batch request.
- Batch request IDs are deterministic from queue row identity, DKP, and prompt hashes; prompt text and API keys are not stored in the ledger.
- Successful provider response text is retained for 30 days and replayed without a new Gemini request.
- Adds atomic per-DKP locks, acquired in sorted order, so concurrently running or differently shaped batches cannot dispatch overlapping product IDs at the same time.
- Adds atomic per-Worker locks shared by the product-batch path and the existing Gemini path. Concurrent requests may use different free Workers, but a Worker cannot be assigned another active request while its lock is held.
- After transport timeouts, generic 503/5xx, or other ambiguous outcomes, the request is marked uncertain, the affected Worker lock is retained until its conservative timeout expires, and the same batch is not automatically failed over to another Worker.
- Queue items with ambiguous outcomes become `GEMINI_OUTCOME_UNKNOWN` without incrementing retry counts. A human must inspect the product state and Gemini log before explicitly clearing the matching uncertain request.
- Definitive Gemini 429 / missing Worker secret responses can fail over because they indicate that generation was not completed through that Worker.
- Worker 1.13.4 is unchanged; all configured Worker URLs and secrets remain as-is.

No product-index, prompt, pricing, image, import schema, or theme code is changed. One internal ledger table is created/verified by `dbDelta`; it stores request IDs, DKPs, state, Worker, and response text only.
