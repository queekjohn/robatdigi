# EVazar Core 2.8.81

## Image Failover — AJAX / Dynamic Product Grids

- Fixed page-wide image failover for WoodMart AJAX product pagination and product-grid refreshes.
- Added handling for `wdLoadMoreLoadProducts`, `wdShopPageInit`, and `wdArrowsLoadProducts` after dynamically loaded products are inserted.
- Added a lightweight `MutationObserver` for newly inserted image/source nodes.
- When Direct Mode is active, newly injected images are immediately switched to the direct Digikala CDN instead of requesting `img.evazar.ir` first.
- Existing images are also directized when an active 10-minute Direct Mode is detected.
- Kept the existing 10-minute Direct Mode, health probe, and no-browser-retry architecture unchanged.
- Observer watches DOM additions only; it does not observe attribute changes, avoiding mutation loops and unnecessary CPU work.
