# EVazar Core 2.8.95 — Manual Import Statistics Sync

- Fixes single-product manual imports not appearing in the queue's completed count or 24-hour imported-product history.
- On successful manual import, records the DKP/product/time in the durable history table and mirrors the item as `completed` in the import queue, clearing stale retry/error/claim state.
- Adds one-time recovery from successful entries still present in the rolling 50-entry importer log, preserving their original timestamps (limited to the previous 24 hours).
- Keeps queue worker history recording unchanged; a unique DKP history row means repeated imports update the last successful import time rather than duplicating the product count.
- Includes explicit admin feedback if either statistics write fails; product-import success remains success.
