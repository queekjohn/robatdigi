# EVazar Core 2.9.27 — Remove Gemini Google Search Grounding

- Removed the taxonomy Google Search grounding toggle from WordPress settings.
- Removed `google_search` tool injection, taxonomy-only grounding headers, response-header diagnostics, and grounding-source metadata parsing.
- Taxonomy requests now use only the fetched verified source supplied to Gemini. The prompt explicitly forbids pretending that web research was performed.
- Added conservative one-time prompt migration: only exact built-in taxonomy prompts from 2.9.24/2.9.25 are replaced with source-only prompts. Customized prompts are preserved, with an appended no-web-research constraint.
- Product prompts and normal product payloads are unchanged.
- Updated the bundled Worker to 1.12.6; the Worker strips Gemini `tools` and `toolConfig` from every Gemini request.
- No taxonomy/product content is regenerated automatically during upgrade.
