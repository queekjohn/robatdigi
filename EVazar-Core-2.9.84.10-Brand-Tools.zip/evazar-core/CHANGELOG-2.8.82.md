# EVazar Core 2.8.82

- Coordinates image failover with the EVazar theme Infinite Scroll.
- Listens for `evazar:archive-products-appended` and `evazar:archive-results-replaced`.
- Processes dynamically appended archive images immediately without polling.
- Existing Direct Mode, watchdog and MutationObserver behavior remains unchanged.
