# EVazar Core 2.9.69 — Retry Continuation and Timezone Safety

- Retryable products that are due can schedule a short continuation instead of waiting for the regular queue interval (including a configured 60-minute interval).
- Continuation remains gated by Gemini quota/rate-limit availability checks; it does not create a hot loop while all Workers are paused.
- Parsing retry timestamps now explicitly uses the WordPress site timezone instead of PHP's default timezone.
- Gemini daily quota reset remains based on `America/Los_Angeles` (Pacific), independent of WordPress local time.
- Per-Worker cooldowns remain isolated; a Worker 503 does not itself create a global pause.
