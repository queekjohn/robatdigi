> Historical QA for 2.9.25. This feature is intentionally disabled/removed in 2.9.27.

# QA — EVazar Core 2.9.25

- [ ] PHP syntax passes for all PHP files.
- [ ] No active code calls an external search API or renders a third-party search API-key field.
- [ ] A one-time cleanup removes the previously saved third-party search key option if present.
- [ ] Research toggle on adds `tools: [{"google_search": {}}]` only when request purpose is `taxonomy_seo` and term ID is valid.
- [ ] Product-generation requests have no added tools field and product prompts remain byte-identical to 2.9.24.
- [ ] Existing Workers forward the request body and do not remove the `tools` property.
- [ ] Grounding metadata is only read/stored for taxonomy requests, as private term metadata.
- [ ] `webSearchQueries` and `groundingChunks` are converted to private query/source metadata when returned by Gemini.
- [ ] Source titles/URLs are shown only in the admin single-term result; raw source text, URLs and source lists are not appended to public term descriptions.
- [ ] If Gemini does not trigger search, status is reported as `not_used`; if the API provides no metadata after a successful non-Gemini route, status is `not_reported`.
- [ ] Output length and official model naming rules remain in taxonomy prompt; prompt migration changes only exact 2.9.24 defaults and preserves customized prompts.
- [ ] Existing term descriptions are not rewritten merely by plugin upgrade.
- [ ] Test manually only on term ID 1842; no bulk processing.
