# QA — EVazar Core 2.9.76

- `php -l` passed for every PHP file in the plugin.
- `node --check` passed for the embedded Worker JavaScript (version remains 1.13.11).
- Static assertions confirm: cooldown payloads include expiry/reason/HTTP code; cooldown-only pool rejection records `attempted=0`; fresh scheduled sync returns a deferred signal for pool-capacity skips before it writes failure metadata; the batch restores `_evazar_last_stock_attempt`, keeps `state.offset` on the current product, and schedules a continuation at the retry time.
- Static assertions confirm the main importer/stock synchronizer remains separate from `queue-manager.php`; `queue-manager.php` contents are unchanged relative to 2.9.75.
- ZIP integrity tested. The release bundle's Worker script is byte-identical to `worker/digikala-worker.js` embedded in Core and its reported version is 1.13.11.

Limitations: no live Worker calls, live transient/object-cache behavior, real WP-Cron execution, or production database were tested. Existing cooldown transients from older releases have no stored cause; if still active they are shown as `legacy_cooldown_unknown` until they expire. New cooldowns store their own diagnostic cause.
