# Safe upgrade — EVazar Core 2.9.37

1. Back up the database and current `evazar-core/` directory.
2. Replace the existing plugin folder with `evazar-core/` from this package; do not create a version-suffixed folder.
3. No database schema migration or Cloudflare Worker deployment is required.
4. The only runtime logic change is an optional offset argument in the related-product ID helper. Existing callers that pass the original three arguments behave as before.
5. Pair with Theme 1.13.17 to enable scroll-loading on product pages.
