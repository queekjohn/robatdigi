# Safe upgrade — EVazar Core 2.9.43

1. Back up the current `evazar-core/` directory and WordPress database.
2. Install the Core ZIP by replacing the existing `evazar-core/` folder; preserve the exact folder name.
3. Do not deploy a new Worker. Keep Worker 1.13.4, all configured Worker URLs, `EVAZAR_INTERNAL_TOKEN`, and each `GEMINI_API_KEY` secret unchanged.
4. Keep product batch size at 5 and leave the current cron interval unchanged during the first controlled tests.
5. After installation, check the Gemini Ops page and configured Worker status. The internal request ledger table is created/verified lazily; if it cannot be verified, Core intentionally blocks new batched provider calls.
6. Run only one controlled batch first. Verify a single `product_import_batch` event with `batch_size=5`, the five expected DKPs, and `success`.
7. Only after that succeeds, test concurrency with two queue runs close together. Expected behavior: unique rows are claimed once, overlapping DKP batches are blocked before Gemini, and different batches may use different free Worker URLs. Do not start five-way concurrency until the two-run test is clean.
8. If `GEMINI_OUTCOME_UNKNOWN` appears, do not use bulk retry. The provider may have processed the request without the response reaching Core. Inspect the five products and Gemini log first; only then use the precise manual recovery control for that exact uncertain request, understanding that a new send can consume quota again.
9. Observe per-Worker “busy” status for up to the configured timeout plus 2 minutes after an ambiguous network result; this is intentional fail-closed behavior.

Rollback: if unexpected queue blocking occurs, restore the previously backed-up Core directory only. The new ledger table and lock options are additive and can remain unused by Core 2.9.42. Do not restore the whole database snapshot blindly, because that would also undo later product imports and other site activity. No Worker rollback is required because Worker code is unchanged.
