# EVazar Core 2.9.71

## Queue dashboard: successful imports in the last hour
- Added a new card to the Import Queue page showing the number of products successfully imported during the last hour.
- The card opens a dedicated view of the most recent successful imports from that one-hour window.
- Kept the existing 24-hour counter and view unchanged.
- Included the one-hour count in the queue action AJAX response so the displayed count can refresh after queue actions.
- Counts use the existing import-history table and UTC timestamps, consistent with the 24-hour metric.

## Scope
- Dashboard/UI and its existing import-history query only; no worker, queue scheduling, retry, or import processing behavior changed.
