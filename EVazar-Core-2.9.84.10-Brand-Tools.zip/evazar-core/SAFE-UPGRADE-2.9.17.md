# Safe upgrade — EVazar Core 2.9.17

- Back up the plugin directory and database before replacing the plugin.
- This release adds `_evazar_spec_groups`; it does not remove or rename `_evazar_key_features`.
- No bulk migration runs on activation. Existing products will show grouped headings after re-import with Worker 1.12.0 (or through direct API grouped extraction).
- Pair with Worker 1.12.0 and Theme 1.13.16 for end-to-end grouped display.
- Manual changes to the flat Features field remove saved group metadata only when the text actually changes, allowing the theme to fall back safely.
