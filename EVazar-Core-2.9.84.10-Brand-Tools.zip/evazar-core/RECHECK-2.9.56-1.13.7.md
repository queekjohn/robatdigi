# Recheck — Core 2.9.56 / Worker 1.13.7

- Core plugin header: `2.9.56`.
- Worker version: `1.13.7` (unchanged).
- Core's embedded `worker/digikala-worker.js` matches the standalone `EVazar-Worker-1.13.7-Strict-Batch-Only.js` byte-for-byte; SHA-256: `3e780016f477b3ff09f02e746b17069ed1c52f0628c5e26d392af2937b41a2ed`.
- The automatic Gemini batch request headers/limits were not changed in this patch.
- The queue admission and admin bulk retry/rewrite paths use the existing Core capacity lock and capacity-waiting table.
- PHP lint, local mocked capacity/admin-action tests, Worker syntax check, and ZIP integrity checks passed.
- No live WordPress database or Cloudflare deployment was tested in this turn.
