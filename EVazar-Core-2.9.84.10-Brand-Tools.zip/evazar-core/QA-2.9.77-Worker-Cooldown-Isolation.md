# QA — EVazar Core 2.9.77

- PASS — `php -l` for all 5 PHP files.
- PASS — `node --check` for the embedded Worker JavaScript (1.13.11).
- PASS — Static regression checks: request helper accepts a purpose; cooldown key, read, and error writes use the same purpose; `import_source`, `ai_proxy`, and `stock_sync` are wired to their intended calls.
- PASS — HTTP 429 with `X-Evazar-Error-Scope: source` bypasses Worker cooldown handling and is reported as a source failure.
- PASS — Stock-sync defer logic and retry scheduling remain present.
- PASS — `queue-manager.php` is byte-identical to 2.9.76.
- PASS — Embedded Worker script is byte-identical to 2.9.76; Worker version remains 1.13.11.
- PASS — Package integrity and expected top-level `evazar-core/` directory validated.

Limitations: tests are static/local. No live Worker, WordPress database, production transient/object cache, or WP-Cron execution was exercised. HTTP 502 returned directly by every stock-sync Worker endpoint will still prevent a fresh lookup until service recovers; this patch prevents cooldown sharing across request purposes but does not repair a Worker/runtime or upstream failure.
