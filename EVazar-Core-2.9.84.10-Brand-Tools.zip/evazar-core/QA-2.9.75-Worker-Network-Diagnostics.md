# QA — EVazar Core 2.9.75 / Worker 1.13.11

## Checks performed
- PHP syntax check: all five PHP files in this plugin pass `php -l`.
- JavaScript syntax check: Worker passes `node --check`.
- Contract tests: product not found (v2+v1 genuine 404), upstream rate-limited (429), upstream server error (real 500/502), synthetic network failures (fetch rejected/timeout), and successful fresh product response.
- Package checks: ZIP archive integrity verified; embedded Worker is byte-identical to the standalone and combined-package Worker script.

## Network/source classification contract
- Genuine v2=404 and v1=404 => HTTP 404, scope `product`, code `product_not_found`.
- Genuine upstream 429 => HTTP 503, scope `source`, code `source_rate_limited`.
- Genuine upstream HTTP 5xx => HTTP 503, scope `source`, code `source_server_error`.
- Proxy-generated network-failure responses => HTTP 503, scope `source`, code `source_fetch_failed`.
- Valid product payload => HTTP 200 and `X-Evazar-Worker-Version: 1.13.11`.

## Not live-tested
Not deployed to the live Cloudflare or WordPress environment. Verify the response header version and the first 10–20 stock-sync events after deployment.
