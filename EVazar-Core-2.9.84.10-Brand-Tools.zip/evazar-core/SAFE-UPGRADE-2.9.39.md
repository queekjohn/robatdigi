# Safe upgrade — EVazar Core 2.9.39

1. Back up the existing `evazar-core/` plugin directory and database before replacing files.
2. Replace the existing `evazar-core/` folder with this package; do not install a version-suffixed duplicate folder.
3. Keep Theme 1.13.20. It remains compatible; no Worker deployment or database migration is required.
4. Open Dashboard and verify the status cards against Products → Import Queue. A successful import may take up to 30 seconds to appear in the cached dashboard counts; explicit queue admin actions clear the cache.
5. Test related-product scrolling on a published product page. The related ranking cache lasts up to 60 seconds, and the public list is bounded to 500 candidates.
6. This release has static/source validation only; production database query plans and the live WordPress dashboard must be checked after deployment.
