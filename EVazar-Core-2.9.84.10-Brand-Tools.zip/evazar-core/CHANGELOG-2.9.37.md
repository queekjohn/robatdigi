# EVazar Core 2.9.37 — Related-product pagination

- Adds an optional fourth `$offset` argument to `evazar_get_related_product_ids()`. Existing three-argument calls retain their behavior.
- Applies offset to the canonical Product Index query after the existing relevance ranking, using a deterministic order (relevance, publication date, product ID).
- Enables the Theme's scroll-triggered related-product batches without using WooCommerce APIs or changing product data/index schema.
- No database migration, Worker deployment, import, pricing, stock, image, taxonomy-generation, or prompt changes.
