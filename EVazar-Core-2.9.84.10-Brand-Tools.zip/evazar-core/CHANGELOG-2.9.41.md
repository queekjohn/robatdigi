# EVazar Core 2.9.41 — Gemini batch pause handling

- Retains the opt-in Gemini product batching pilot from 2.9.40.
- Treats `gemini_quota_probe_busy` as a temporary pause during batch processing instead of a product failure.
- When a temporary Gemini error omits retry metadata, retries are deferred for 60 seconds rather than being delayed for a full day. Daily quota cooldown behavior remains unchanged.
- No Worker source, database schema, import prompt, product index, or table definition changed.

## Validation
- PHP syntax checked for all top-level Core PHP files.
- Batch parser and generator mock harnesses pass.
- Embedded Worker remains byte-identical to standalone Worker 1.13.4.
- No live WordPress database or real Gemini API request was available; production testing is still required.
