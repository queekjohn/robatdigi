# EVazar Core 2.9.68 — Queue Cron Interval Enforcement

- Fixes automatic queue continuation bypassing the configured cron interval through 15-second follow-up events.
- Enforces a shared not-before timestamp across recurring cron and one-off follow-up callbacks.
- Manual “Run queue now” remains available and schedules the next automatic slot using the configured interval.
- Changing the interval reschedules the recurring event; upgrading to this version also migrates older scheduled events and clears stale follow-ups.
- The initial recurring run now waits for the configured interval instead of being scheduled after 30 seconds.
- No Worker code or database schema changes.
