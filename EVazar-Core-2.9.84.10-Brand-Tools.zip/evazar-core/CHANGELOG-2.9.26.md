# EVazar Core 2.9.26 — Google Search / Worker contract alignment

- Adds authenticated request headers identifying Core taxonomy requests (`X-Evazar-Request-Purpose`, `X-Evazar-Term-ID`).
- Reads the Worker diagnostic header `X-Evazar-Google-Search-Tool` and logs when the built-in Google Search tool was forwarded or blocked.
- Does not alter product prompts or add tools to product requests.
- Bundles Worker 1.12.5 source for an exact matching deployment; the embedded file is byte-identical to the standalone Worker package.
- Core upgrade does not trigger content regeneration or bulk work.
