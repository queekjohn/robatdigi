# EVazar Core 2.8.93 — Import History Visibility Fix

- Makes the 24-hour import-history entry prominent near the top of the queue page, with its count even when zero.
- Explicitly ensures the history table during page rendering, so replacing plugin files on an already-active installation does not rely only on the activation hook.
- Keeps the original status filter and history query; no changes to import/worker processing behavior.
