# Safe upgrade — EVazar Core 2.9.47

1. Back up the WordPress database and current `evazar-core/` plugin folder.
2. Install Core 2.9.47 by replacing the existing `evazar-core/` folder with the package's `evazar-core/` folder.
3. Do not replace or redeploy the Cloudflare Worker; existing Worker 1.13.6 is compatible. Keep `EVAZAR_INTERNAL_TOKEN`, `GEMINI_API_KEY`, Worker URLs, and model settings unchanged. No Durable Object binding is required.
4. Do not change Theme settings, batch size, parallelism, Worker URLs, or Gemini secrets as part of this upgrade.
5. Start with a small queue batch and confirm a successful import. Then observe a retryable failure in Gemini Ops/queue logs; confirm the row returns to `pending` with `next_attempt_at` set.
6. Products that were already `failed` before this update remain failed until you use the existing retry-failed queue action. Do not mass-retry old uncertain rows without reviewing current quota availability.

## Behavior and tradeoff
- Non-quota errors and stale claims retry indefinitely with exponential backoff capped at six hours. Persistent configuration/product errors will remain pending; fix the underlying cause to let them succeed.
- 429/quota cooldown handling remains authoritative and is not overridden by the generic retry policy.
- If Gemini's prior outcome is unknown and no Durable Object is configured, a fresh request may consume quota again if the first request actually completed. The product duplicate guard remains in place.
- No new DB schema or migration is introduced.

## Validation boundary
PHP/JavaScript syntax, archive integrity, source parity and static regression assertions are checked. No live WordPress database or production Gemini request was executed during packaging.
