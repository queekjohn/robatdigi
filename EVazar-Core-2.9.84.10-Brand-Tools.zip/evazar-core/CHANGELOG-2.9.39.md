# EVazar Core 2.9.39

- Corrected the dashboard's “last successful import” value so it reads the latest history timestamp even when it is older than seven days. The rolling 7-day range remains bounded for recent-period counts.
- Dashboard queue metrics now show an em dash plus a warning if their SQL read fails instead of presenting a query failure as a real zero. History metrics behave the same way.
- Successful imports no longer invalidate the dashboard aggregate transient for every product during large import bursts; statistics remain at most 30 seconds stale. Explicit queue admin actions still invalidate the cache.
- Preserved Core 2.9.38 dashboard functionality and the related-product ranking window/cache. No schema, Worker, or Theme changes.
