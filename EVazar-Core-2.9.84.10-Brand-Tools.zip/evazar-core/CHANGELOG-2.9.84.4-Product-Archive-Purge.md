# EVazar Core 2.9.84.4 — Product Archive Cache Purge

## Fix
- Added the custom post type archive URL returned by `get_post_type_archive_link('evazar_product')` to targeted purge when a product change affects public archives. In this site's CPT configuration (`has_archive => true`, rewrite slug `product`), this is `/product/`.
- Keeps existing targeted purge of homepage, product permalink, category/brand archives, and previous taxonomy archives.
- Does not issue a wildcard or whole-cache purge.
- Retains the Core 2.9.84.3 features, including 15-product request size and 75-product queue capacity.

## Validation
- Plugin PHP syntax and explicit `/product/` archive path selection tested locally.
- Real LiteSpeed/Cloudflare purge acceptance must be verified on the live host; origin response headers do not provide an acknowledgement that a purge was completed.
