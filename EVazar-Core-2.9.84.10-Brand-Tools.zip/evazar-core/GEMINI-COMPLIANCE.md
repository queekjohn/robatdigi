# EVazar Gemini routing: operational safeguards

## Scope
- Gemini Worker URLs are stored separately in `evazar_gemini_worker_urls` (one HTTPS URL per line).
- The existing `evazar_cf_worker_url` remains the primary Worker URL for product import and other existing paths. If the Gemini list is empty, Core falls back to the legacy URL for compatibility.
- Gemini API keys stay in each Cloudflare Worker environment secret (`GEMINI_API_KEY`); never paste secrets into Worker URLs, prompts, source files, or operational logs.

## Error behavior
- Daily quota exhaustion: only the affected Worker is cooled down. Core continues to another configured Worker if it is eligible. If all configured Workers have daily-quota cooldowns, stop Gemini routing until the next Pacific midnight reset.
- HTTP 429 without explicit daily-quota metadata: treat it as temporary rate limiting, honor `Retry-After`, then Google `retryDelay` when present, otherwise wait 60 seconds (minimum 15 seconds). The cooldown is per Worker; other eligible configured Workers may be tried. If all quota-eligible Workers are temporarily blocked, pause the queue until the earliest retry time.
- HTTP 503 or a missing Worker `GEMINI_API_KEY`: cool down that Worker and try the next configured Worker. If all eligible Workers are unavailable, defer the queue until the earliest retry time.
- HTTP 400/401/403/404: log a configuration/request error and stop rather than blindly retrying malformed requests, authorization failures, or unsupported models.
- Network errors may fail over to another configured Worker after bounded retry of the same Worker.
- An explicit one-product admin import may test current quota despite a daily-quota cooldown, but it never bypasses temporary rate-limit or in-flight-concurrency protection.
- A global Core request lock prevents simultaneous Gemini calls. Queue items affected by quota/rate-limit cooldowns return to pending without increasing retry counts.

## Logging and limits
- The operational report displays per-Worker states (ready, temporary cooldown, daily quota cooldown) and the most recent 80 events.
- Logs may include Worker host, event type, HTTP code, safe Google quota identifiers, and cooldown time. They must never contain API keys, prompt bodies, or full raw provider responses.
- Queue pause transitions are logged even when no HTTP request is sent; repeated Cron checks are de-duplicated.
- The dashboard does not claim to know exact remaining Google quota; local request counts cannot establish provider-side remaining quota.
- Worker rotation is for availability across independently authorized projects/quotas, not to evade Google restrictions. Google quotas may be shared by keys from the same project. Configure only projects/keys you are entitled to use and comply with the applicable Google API terms and quota settings.

## Production verification
1. Confirm every Worker has the intended `GEMINI_API_KEY` Secret and shared internal token.
2. Confirm whether configured Workers map to separate Google projects in AI Studio/Google Cloud.
3. Test low-volume cases and inspect the Gemini operational report and queue state.
4. Do not manually clear provider-issued cooldowns to continue after an actual quota/rate-limit response.
