# QA — EVazar Core 2.9.82 / Worker 1.13.13

- `php -l` all PHP files in Core package.
- Source retry delay values asserted: attempt 1=60s; 2=120s; 3=240s; attempt 4=480s; repeated failures cap at 900s.
- Queue simulation asserts a source preflight failure is retained as `retry` and re-eligible on the next one-minute queue pass, without a Gemini call for invalid source.
- One-time migration simulation asserts only known source-error retry rows with far-future `next_attempt_at` are moved near-term; unrelated retry rows are untouched; matching nudge is scheduled; rerunning migration makes no further change.
- ZIP integrity and SHA-256 verified after build.

Not tested: live WordPress DB/WP-Cron execution, real Digikala requests, deployed Cloudflare, or real Gemini quota behavior.
