# QA report — EVazar Core 2.9.15

## Automated checks

- `php -l` passed for each PHP file in the plugin package.
- Synthetic direct-API payload with three specification groups was parsed across all groups.
- `RAM` and `حافظهٔ رم` normalized to one canonical label.
- Screen-size aliases normalized to `اندازه صفحه‌نمایش`.
- A duplicate row with identical label/value was removed.
- The model value `X1605 - 2` retained its hyphen.
- Empty and malformed rows were discarded without inventing replacements.
- Prompt format remains bullet-prefixed; stored format remains newline-separated `Label: Value`, compatible with the existing theme parser.

## Limitations

- No live site, WordPress database, or live Digikala API call was available during validation.
- Previously imported products are not migrated automatically.
- This release standardizes known labels and whitespace; it deliberately does not use Gemini to semantically rewrite feature values.
